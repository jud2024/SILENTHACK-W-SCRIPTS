import {
    s as c,
    K as m,
    L as i,
    c as _,
    M as u
} from "./scheduler.DXu26z7T.js";
import {
    S as l,
    i as f,
    c as g,
    a as d,
    m as w,
    t as b,
    b as O,
    d as $
} from "./index.Dz_MmNB3.js";
import {
    g as h,
    a as A
} from "./spread.CgU5AtxT.js";
import {
    g as v
} from "./context.C4qMQqMz.js";
import {
    A as D
} from "./index.Cp95w4vW.js";

function S(n) {
    let t, s;
    const o = [{
        variant: "dropdown"
    }, {
        isOpen: n[0].isOpen
    }, n[2]];
    let a = {};
    for (let e = 0; e < o.length; e += 1) a = m(a, o[e]);
    return t = new D({
        props: a
    }), {
        c() {
            g(t.$$.fragment)
        },
        l(e) {
            d(t.$$.fragment, e)
        },
        m(e, r) {
            w(t, e, r), s = !0
        },
        p(e, [r]) {
            const p = r & 5 ? h(o, [o[0], r & 1 && {
                isOpen: e[0].isOpen
            }, r & 4 && A(e[2])]) : {};
            t.$set(p)
        },
        i(e) {
            s || (b(t.$$.fragment, e), s = !0)
        },
        o(e) {
            O(t.$$.fragment, e), s = !1
        },
        d(e) {
            $(t, e)
        }
    }
}

function j(n, t, s) {
    const o = [];
    let a = i(t, o),
        e, r = v();
    return _(n, r, p => s(0, e = p)), n.$$set = p => {
        t = m(m({}, t), u(p)), s(2, a = i(t, o))
    }, [e, r, a]
}
class M extends l {
    constructor(t) {
        super(), f(this, t, j, S, c, {})
    }
}
export {
    M as D
};