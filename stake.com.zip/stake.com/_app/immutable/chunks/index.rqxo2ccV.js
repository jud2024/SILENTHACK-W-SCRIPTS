import {
    s as g,
    m as d,
    j as p,
    i as _,
    a as b,
    u as h,
    g as y,
    b as k,
    e as v,
    d as S,
    f as T,
    F as f,
    V as w
} from "./scheduler.DXu26z7T.js";
import {
    S as C,
    i as j,
    t as c,
    b as m
} from "./index.Dz_MmNB3.js";
import {
    g as q
} from "./index.D7nbRHfU.js";

function A(r) {
    let e;
    const a = r[3].default,
        t = b(a, r, r[2], null);
    return {
        c() {
            t && t.c()
        },
        l(l) {
            t && t.l(l)
        },
        m(l, s) {
            t && t.m(l, s), e = !0
        },
        p(l, s) {
            t && t.p && (!e || s & 4) && h(t, a, l, l[2], e ? k(a, l[2], s, null) : y(l[2]), null)
        },
        i(l) {
            e || (c(t, l), e = !0)
        },
        o(l) {
            m(t, l), e = !1
        },
        d(l) {
            t && t.d(l)
        }
    }
}

function E(r) {
    let e, a, t;
    const l = r[3].default,
        s = b(l, r, r[2], null);
    return {
        c() {
            e = v("span"), s && s.c(), this.h()
        },
        l(n) {
            e = S(n, "SPAN", {
                style: !0,
                class: !0
            });
            var o = T(e);
            s && s.l(o), o.forEach(_), this.h()
        },
        h() {
            f(e, "style", a = "max-width: " + r[1] + "; " + r[0]), f(e, "class", "svelte-17o987"), w(e, "is-truncate", r[1])
        },
        m(n, o) {
            p(n, e, o), s && s.m(e, null), t = !0
        },
        p(n, o) {
            s && s.p && (!t || o & 4) && h(s, l, n, n[2], t ? k(l, n[2], o, null) : y(n[2]), null), (!t || o & 1 && a !== (a = "max-width: " + n[1] + "; " + n[0])) && f(e, "style", a)
        },
        i(n) {
            t || (c(s, n), t = !0)
        },
        o(n) {
            m(s, n), t = !1
        },
        d(n) {
            n && _(e), s && s.d(n)
        }
    }
}

function F(r) {
    let e, a, t, l;
    const s = [E, A],
        n = [];

    function o(i, u) {
        return i[1] ? 0 : 1
    }
    return e = o(r), a = n[e] = s[e](r), {
        c() {
            a.c(), t = d()
        },
        l(i) {
            a.l(i), t = d()
        },
        m(i, u) {
            n[e].m(i, u), p(i, t, u), l = !0
        },
        p(i, [u]) {
            a.p(i, u)
        },
        i(i) {
            l || (c(a), l = !0)
        },
        o(i) {
            m(a), l = !1
        },
        d(i) {
            i && _(t), n[e].d(i)
        }
    }
}

function N(r, e, a) {
    let {
        $$slots: t = {},
        $$scope: l
    } = e, {
        style: s = ""
    } = e, n = q();
    return r.$$set = o => {
        "style" in o && a(0, s = o.style), "$$scope" in o && a(2, l = o.$$scope)
    }, [s, n, l, t]
}
class B extends C {
    constructor(e) {
        super(), j(this, e, N, F, g, {
            style: 0
        })
    }
}
export {
    B as T
};