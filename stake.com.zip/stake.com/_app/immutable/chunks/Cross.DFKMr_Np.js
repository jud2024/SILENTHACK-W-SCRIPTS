import {
    s as m,
    C as f,
    H as u,
    D as h,
    f as _,
    E as g,
    i as c,
    F as r,
    j as v,
    n as o
} from "./scheduler.DXu26z7T.js";
import {
    S as L,
    i as y
} from "./index.Dz_MmNB3.js";

function d(n) {
    let t, e, a = ` <title>${n[1]||""}</title> <path d="m54.827 16.187-7.014-7.014L32 24.987 16.187 9.173l-7.014 7.014L24.987 32 9.173 47.813l7.014 7.014L32 39.013l15.813 15.814 7.014-7.014L39.013 32l15.814-15.813Z"></path>`,
        i;
    return {
        c() {
            t = f("svg"), e = new u(!0), this.h()
        },
        l(s) {
            t = h(s, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var l = _(t);
            e = g(l, !0), l.forEach(c), this.h()
        },
        h() {
            e.a = null, r(t, "fill", "currentColor"), r(t, "viewBox", "0 0 64 64"), r(t, "class", i = "svg-icon " + n[2]), r(t, "style", n[0])
        },
        m(s, l) {
            v(s, t, l), e.m(a, t)
        },
        p(s, [l]) {
            l & 2 && a !== (a = ` <title>${s[1]||""}</title> <path d="m54.827 16.187-7.014-7.014L32 24.987 16.187 9.173l-7.014 7.014L24.987 32 9.173 47.813l7.014 7.014L32 39.013l15.813 15.814 7.014-7.014L39.013 32l15.814-15.813Z"></path>`) && e.p(a), l & 4 && i !== (i = "svg-icon " + s[2]) && r(t, "class", i), l & 1 && r(t, "style", s[0])
        },
        i: o,
        o,
        d(s) {
            s && c(t)
        }
    }
}

function C(n, t, e) {
    let {
        style: a = ""
    } = t, {
        alt: i = ""
    } = t, {
        class: s = ""
    } = t;
    return n.$$set = l => {
        "style" in l && e(0, a = l.style), "alt" in l && e(1, i = l.alt), "class" in l && e(2, s = l.class)
    }, [a, i, s]
}
class B extends L {
    constructor(t) {
        super(), y(this, t, C, d, m, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    B as C
};