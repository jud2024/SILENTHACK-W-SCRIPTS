import {
    s as b,
    m as f,
    j as s,
    n as m,
    i as c,
    c as h,
    t as _,
    h as d,
    l as y,
    e as v,
    d as k,
    S as p
} from "./scheduler.DXu26z7T.js";
import {
    S as D,
    i as C
} from "./index.Dz_MmNB3.js";
import {
    i as F
} from "./index.B4-7gKq3.js";

function S(i) {
    let t;
    return {
        c() {
            t = _("Invalid FormattedDate.")
        },
        l(n) {
            t = d(n, "Invalid FormattedDate.")
        },
        m(n, e) {
            s(n, t, e)
        },
        p: m,
        d(n) {
            n && c(t)
        }
    }
}

function N(i) {
    let t = i[2].date(new Date(i[0]), i[1]) + "",
        n;
    return {
        c() {
            n = _(t)
        },
        l(e) {
            n = d(e, t)
        },
        m(e, a) {
            s(e, n, a)
        },
        p(e, a) {
            a & 7 && t !== (t = e[2].date(new Date(e[0]), e[1]) + "") && y(n, t)
        },
        d(e) {
            e && c(n)
        }
    }
}

function g(i) {
    let t, n = "N/A";
    return {
        c() {
            t = v("span"), t.textContent = n
        },
        l(e) {
            t = k(e, "SPAN", {
                "data-svelte-h": !0
            }), p(t) !== "svelte-mgbc10" && (t.textContent = n)
        },
        m(e, a) {
            s(e, t, a)
        },
        p: m,
        d(e) {
            e && c(t)
        }
    }
}

function w(i) {
    let t;

    function n(r, o) {
        return r[0] === null ? g : r[0] ? N : S
    }
    let e = n(i),
        a = e(i);
    return {
        c() {
            a.c(), t = f()
        },
        l(r) {
            a.l(r), t = f()
        },
        m(r, o) {
            a.m(r, o), s(r, t, o)
        },
        p(r, [o]) {
            e === (e = n(r)) && a ? a.p(r, o) : (a.d(1), a = e(r), a && (a.c(), a.m(t.parentNode, t)))
        },
        i: m,
        o: m,
        d(r) {
            r && c(t), a.d(r)
        }
    }
}

function A(i, t, n) {
    let e, a;
    h(i, F, l => n(2, a = l));
    let {
        value: r
    } = t, {
        short: o = !1
    } = t, {
        format: u = void 0
    } = t;
    return i.$$set = l => {
        "value" in l && n(0, r = l.value), "short" in l && n(3, o = l.short), "format" in l && n(4, u = l.format)
    }, i.$$.update = () => {
        i.$$.dirty & 24 && n(1, e = u || (o ? {
            day: "numeric",
            month: "numeric",
            year: "numeric"
        } : {
            month: "long",
            day: "numeric",
            year: "numeric"
        }))
    }, [r, e, a, o, u]
}
class x extends D {
    constructor(t) {
        super(), C(this, t, A, w, b, {
            value: 0,
            short: 3,
            format: 4
        })
    }
}
export {
    x as F
};