import {
    f as w,
    a as E,
    b as g,
    _ as b
} from "./tslib.es6.CYhxggkG.js";

function l(e) {
    return typeof e == "function"
}

function k(e) {
    var t = function(n) {
            Error.call(n), n.stack = new Error().stack
        },
        r = e(t);
    return r.prototype = Object.create(Error.prototype), r.prototype.constructor = r, r
}
var S = k(function(e) {
    return function(r) {
        e(this), this.message = r ? r.length + ` errors occurred during unsubscription:
` + r.map(function(n, i) {
            return i + 1 + ") " + n.toString()
        }).join(`
  `) : "", this.name = "UnsubscriptionError", this.errors = r
    }
});

function O(e, t) {
    if (e) {
        var r = e.indexOf(t);
        0 <= r && e.splice(r, 1)
    }
}
var m = function() {
        function e(t) {
            this.initialTeardown = t, this.closed = !1, this._parentage = null, this._finalizers = null
        }
        return e.prototype.unsubscribe = function() {
            var t, r, n, i, o;
            if (!this.closed) {
                this.closed = !0;
                var s = this._parentage;
                if (s)
                    if (this._parentage = null, Array.isArray(s)) try {
                        for (var u = w(s), c = u.next(); !c.done; c = u.next()) {
                            var f = c.value;
                            f.remove(this)
                        }
                    } catch (a) {
                        t = {
                            error: a
                        }
                    } finally {
                        try {
                            c && !c.done && (r = u.return) && r.call(u)
                        } finally {
                            if (t) throw t.error
                        }
                    } else s.remove(this);
                var p = this.initialTeardown;
                if (l(p)) try {
                    p()
                } catch (a) {
                    o = a instanceof S ? a.errors : [a]
                }
                var T = this._finalizers;
                if (T) {
                    this._finalizers = null;
                    try {
                        for (var d = w(T), h = d.next(); !h.done; h = d.next()) {
                            var Y = h.value;
                            try {
                                A(Y)
                            } catch (a) {
                                o = o ? ? [], a instanceof S ? o = E(E([], g(o)), g(a.errors)) : o.push(a)
                            }
                        }
                    } catch (a) {
                        n = {
                            error: a
                        }
                    } finally {
                        try {
                            h && !h.done && (i = d.return) && i.call(d)
                        } finally {
                            if (n) throw n.error
                        }
                    }
                }
                if (o) throw new S(o)
            }
        }, e.prototype.add = function(t) {
            var r;
            if (t && t !== this)
                if (this.closed) A(t);
                else {
                    if (t instanceof e) {
                        if (t.closed || t._hasParent(this)) return;
                        t._addParent(this)
                    }(this._finalizers = (r = this._finalizers) !== null && r !== void 0 ? r : []).push(t)
                }
        }, e.prototype._hasParent = function(t) {
            var r = this._parentage;
            return r === t || Array.isArray(r) && r.includes(t)
        }, e.prototype._addParent = function(t) {
            var r = this._parentage;
            this._parentage = Array.isArray(r) ? (r.push(t), r) : r ? [r, t] : t
        }, e.prototype._removeParent = function(t) {
            var r = this._parentage;
            r === t ? this._parentage = null : Array.isArray(r) && O(r, t)
        }, e.prototype.remove = function(t) {
            var r = this._finalizers;
            r && O(r, t), t instanceof e && t._removeParent(this)
        }, e.EMPTY = function() {
            var t = new e;
            return t.closed = !0, t
        }(), e
    }(),
    D = m.EMPTY;

function M(e) {
    return e instanceof m || e && "closed" in e && l(e.remove) && l(e.add) && l(e.unsubscribe)
}

function A(e) {
    l(e) ? e() : e.unsubscribe()
}
var U = {
        onUnhandledError: null,
        onStoppedNotification: null,
        Promise: void 0,
        useDeprecatedSynchronousErrorHandling: !1,
        useDeprecatedNextContext: !1
    },
    R = {
        setTimeout: function(e, t) {
            for (var r = [], n = 2; n < arguments.length; n++) r[n - 2] = arguments[n];
            return setTimeout.apply(void 0, E([e, t], g(r)))
        },
        clearTimeout: function(e) {
            var t = R.delegate;
            return ((t == null ? void 0 : t.clearTimeout) || clearTimeout)(e)
        },
        delegate: void 0
    };

function B(e) {
    R.setTimeout(function() {
        var t = U.onUnhandledError;
        if (t) t(e);
        else throw e
    })
}

function j() {}

function y(e) {
    e()
}
var x = function(e) {
        b(t, e);

        function t(r) {
            var n = e.call(this) || this;
            return n.isStopped = !1, r ? (n.destination = r, M(r) && r.add(n)) : n.destination = V, n
        }
        return t.create = function(r, n, i) {
            return new P(r, n, i)
        }, t.prototype.next = function(r) {
            this.isStopped || this._next(r)
        }, t.prototype.error = function(r) {
            this.isStopped || (this.isStopped = !0, this._error(r))
        }, t.prototype.complete = function() {
            this.isStopped || (this.isStopped = !0, this._complete())
        }, t.prototype.unsubscribe = function() {
            this.closed || (this.isStopped = !0, e.prototype.unsubscribe.call(this), this.destination = null)
        }, t.prototype._next = function(r) {
            this.destination.next(r)
        }, t.prototype._error = function(r) {
            try {
                this.destination.error(r)
            } finally {
                this.unsubscribe()
            }
        }, t.prototype._complete = function() {
            try {
                this.destination.complete()
            } finally {
                this.unsubscribe()
            }
        }, t
    }(m),
    H = Function.prototype.bind;

function _(e, t) {
    return H.call(e, t)
}
var z = function() {
        function e(t) {
            this.partialObserver = t
        }
        return e.prototype.next = function(t) {
            var r = this.partialObserver;
            if (r.next) try {
                r.next(t)
            } catch (n) {
                v(n)
            }
        }, e.prototype.error = function(t) {
            var r = this.partialObserver;
            if (r.error) try {
                r.error(t)
            } catch (n) {
                v(n)
            } else v(t)
        }, e.prototype.complete = function() {
            var t = this.partialObserver;
            if (t.complete) try {
                t.complete()
            } catch (r) {
                v(r)
            }
        }, e
    }(),
    P = function(e) {
        b(t, e);

        function t(r, n, i) {
            var o = e.call(this) || this,
                s;
            if (l(r) || !r) s = {
                next: r ? ? void 0,
                error: n ? ? void 0,
                complete: i ? ? void 0
            };
            else {
                var u;
                o && U.useDeprecatedNextContext ? (u = Object.create(r), u.unsubscribe = function() {
                    return o.unsubscribe()
                }, s = {
                    next: r.next && _(r.next, u),
                    error: r.error && _(r.error, u),
                    complete: r.complete && _(r.complete, u)
                }) : s = r
            }
            return o.destination = new z(s), o
        }
        return t
    }(x);

function v(e) {
    B(e)
}

function L(e) {
    throw e
}
var V = {
        closed: !0,
        next: j,
        error: L,
        complete: j
    },
    q = function() {
        return typeof Symbol == "function" && Symbol.observable || "@@observable"
    }();

function G(e) {
    return e
}

function J(e) {
    return e.length === 0 ? G : e.length === 1 ? e[0] : function(r) {
        return e.reduce(function(n, i) {
            return i(n)
        }, r)
    }
}
var I = function() {
    function e(t) {
        t && (this._subscribe = t)
    }
    return e.prototype.lift = function(t) {
        var r = new e;
        return r.source = this, r.operator = t, r
    }, e.prototype.subscribe = function(t, r, n) {
        var i = this,
            o = Q(t) ? t : new P(t, r, n);
        return y(function() {
            var s = i,
                u = s.operator,
                c = s.source;
            o.add(u ? u.call(o, c) : c ? i._subscribe(o) : i._trySubscribe(o))
        }), o
    }, e.prototype._trySubscribe = function(t) {
        try {
            return this._subscribe(t)
        } catch (r) {
            t.error(r)
        }
    }, e.prototype.forEach = function(t, r) {
        var n = this;
        return r = F(r), new r(function(i, o) {
            var s = new P({
                next: function(u) {
                    try {
                        t(u)
                    } catch (c) {
                        o(c), s.unsubscribe()
                    }
                },
                error: o,
                complete: i
            });
            n.subscribe(s)
        })
    }, e.prototype._subscribe = function(t) {
        var r;
        return (r = this.source) === null || r === void 0 ? void 0 : r.subscribe(t)
    }, e.prototype[q] = function() {
        return this
    }, e.prototype.pipe = function() {
        for (var t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
        return J(t)(this)
    }, e.prototype.toPromise = function(t) {
        var r = this;
        return t = F(t), new t(function(n, i) {
            var o;
            r.subscribe(function(s) {
                return o = s
            }, function(s) {
                return i(s)
            }, function() {
                return n(o)
            })
        })
    }, e.create = function(t) {
        return new e(t)
    }, e
}();

function F(e) {
    var t;
    return (t = e ? ? U.Promise) !== null && t !== void 0 ? t : Promise
}

function K(e) {
    return e && l(e.next) && l(e.error) && l(e.complete)
}

function Q(e) {
    return e && e instanceof x || K(e) && M(e)
}

function W(e) {
    return l(e == null ? void 0 : e.lift)
}

function tr(e) {
    return function(t) {
        if (W(t)) return t.lift(function(r) {
            try {
                return e(r, this)
            } catch (n) {
                this.error(n)
            }
        });
        throw new TypeError("Unable to lift unknown Observable type")
    }
}

function er(e, t, r, n, i) {
    return new X(e, t, r, n, i)
}
var X = function(e) {
        b(t, e);

        function t(r, n, i, o, s, u) {
            var c = e.call(this, r) || this;
            return c.onFinalize = s, c.shouldUnsubscribe = u, c._next = n ? function(f) {
                try {
                    n(f)
                } catch (p) {
                    r.error(p)
                }
            } : e.prototype._next, c._error = o ? function(f) {
                try {
                    o(f)
                } catch (p) {
                    r.error(p)
                } finally {
                    this.unsubscribe()
                }
            } : e.prototype._error, c._complete = i ? function() {
                try {
                    i()
                } catch (f) {
                    r.error(f)
                } finally {
                    this.unsubscribe()
                }
            } : e.prototype._complete, c
        }
        return t.prototype.unsubscribe = function() {
            var r;
            if (!this.shouldUnsubscribe || this.shouldUnsubscribe()) {
                var n = this.closed;
                e.prototype.unsubscribe.call(this), !n && ((r = this.onFinalize) === null || r === void 0 || r.call(this))
            }
        }, t
    }(x),
    Z = k(function(e) {
        return function() {
            e(this), this.name = "ObjectUnsubscribedError", this.message = "object unsubscribed"
        }
    }),
    $ = function(e) {
        b(t, e);

        function t() {
            var r = e.call(this) || this;
            return r.closed = !1, r.currentObservers = null, r.observers = [], r.isStopped = !1, r.hasError = !1, r.thrownError = null, r
        }
        return t.prototype.lift = function(r) {
            var n = new C(this, this);
            return n.operator = r, n
        }, t.prototype._throwIfClosed = function() {
            if (this.closed) throw new Z
        }, t.prototype.next = function(r) {
            var n = this;
            y(function() {
                var i, o;
                if (n._throwIfClosed(), !n.isStopped) {
                    n.currentObservers || (n.currentObservers = Array.from(n.observers));
                    try {
                        for (var s = w(n.currentObservers), u = s.next(); !u.done; u = s.next()) {
                            var c = u.value;
                            c.next(r)
                        }
                    } catch (f) {
                        i = {
                            error: f
                        }
                    } finally {
                        try {
                            u && !u.done && (o = s.return) && o.call(s)
                        } finally {
                            if (i) throw i.error
                        }
                    }
                }
            })
        }, t.prototype.error = function(r) {
            var n = this;
            y(function() {
                if (n._throwIfClosed(), !n.isStopped) {
                    n.hasError = n.isStopped = !0, n.thrownError = r;
                    for (var i = n.observers; i.length;) i.shift().error(r)
                }
            })
        }, t.prototype.complete = function() {
            var r = this;
            y(function() {
                if (r._throwIfClosed(), !r.isStopped) {
                    r.isStopped = !0;
                    for (var n = r.observers; n.length;) n.shift().complete()
                }
            })
        }, t.prototype.unsubscribe = function() {
            this.isStopped = this.closed = !0, this.observers = this.currentObservers = null
        }, Object.defineProperty(t.prototype, "observed", {
            get: function() {
                var r;
                return ((r = this.observers) === null || r === void 0 ? void 0 : r.length) > 0
            },
            enumerable: !1,
            configurable: !0
        }), t.prototype._trySubscribe = function(r) {
            return this._throwIfClosed(), e.prototype._trySubscribe.call(this, r)
        }, t.prototype._subscribe = function(r) {
            return this._throwIfClosed(), this._checkFinalizedStatuses(r), this._innerSubscribe(r)
        }, t.prototype._innerSubscribe = function(r) {
            var n = this,
                i = this,
                o = i.hasError,
                s = i.isStopped,
                u = i.observers;
            return o || s ? D : (this.currentObservers = null, u.push(r), new m(function() {
                n.currentObservers = null, O(u, r)
            }))
        }, t.prototype._checkFinalizedStatuses = function(r) {
            var n = this,
                i = n.hasError,
                o = n.thrownError,
                s = n.isStopped;
            i ? r.error(o) : s && r.complete()
        }, t.prototype.asObservable = function() {
            var r = new I;
            return r.source = this, r
        }, t.create = function(r, n) {
            return new C(r, n)
        }, t
    }(I),
    C = function(e) {
        b(t, e);

        function t(r, n) {
            var i = e.call(this) || this;
            return i.destination = r, i.source = n, i
        }
        return t.prototype.next = function(r) {
            var n, i;
            (i = (n = this.destination) === null || n === void 0 ? void 0 : n.next) === null || i === void 0 || i.call(n, r)
        }, t.prototype.error = function(r) {
            var n, i;
            (i = (n = this.destination) === null || n === void 0 ? void 0 : n.error) === null || i === void 0 || i.call(n, r)
        }, t.prototype.complete = function() {
            var r, n;
            (n = (r = this.destination) === null || r === void 0 ? void 0 : r.complete) === null || n === void 0 || n.call(r)
        }, t.prototype._subscribe = function(r) {
            var n, i;
            return (i = (n = this.source) === null || n === void 0 ? void 0 : n.subscribe(r)) !== null && i !== void 0 ? i : D
        }, t
    }($),
    N = {
        now: function() {
            return (N.delegate || Date).now()
        },
        delegate: void 0
    };
export {
    I as O, m as S, l as a, O as b, er as c, N as d, q as e, $ as f, P as g, U as h, G as i, j as n, tr as o, B as r
};