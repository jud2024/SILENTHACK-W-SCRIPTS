const e = {
    kind: "Document",
    definitions: [{
        kind: "OperationDefinition",
        operation: "query",
        name: {
            kind: "Name",
            value: "kuratorGameQuery"
        },
        variableDefinitions: [{
            kind: "VariableDefinition",
            variable: {
                kind: "Variable",
                name: {
                    kind: "Name",
                    value: "query"
                }
            },
            type: {
                kind: "NonNullType",
                type: {
                    kind: "NamedType",
                    name: {
                        kind: "Name",
                        value: "String"
                    }
                }
            }
        }, {
            kind: "VariableDefinition",
            variable: {
                kind: "Variable",
                name: {
                    kind: "Name",
                    value: "active"
                }
            },
            type: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "Boolean"
                }
            }
        }, {
            kind: "VariableDefinition",
            variable: {
                kind: "Variable",
                name: {
                    kind: "Name",
                    value: "isMobile"
                }
            },
            type: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "Boolean"
                }
            }
        }, {
            kind: "VariableDefinition",
            variable: {
                kind: "Variable",
                name: {
                    kind: "Name",
                    value: "offset"
                }
            },
            type: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "Int"
                }
            },
            defaultValue: {
                kind: "IntValue",
                value: "0"
            }
        }, {
            kind: "VariableDefinition",
            variable: {
                kind: "Variable",
                name: {
                    kind: "Name",
                    value: "limit"
                }
            },
            type: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "Int"
                }
            },
            defaultValue: {
                kind: "IntValue",
                value: "25"
            }
        }],
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "kuratorGameQuery"
                },
                arguments: [{
                    kind: "Argument",
                    name: {
                        kind: "Name",
                        value: "query"
                    },
                    value: {
                        kind: "Variable",
                        name: {
                            kind: "Name",
                            value: "query"
                        }
                    }
                }, {
                    kind: "Argument",
                    name: {
                        kind: "Name",
                        value: "active"
                    },
                    value: {
                        kind: "Variable",
                        name: {
                            kind: "Name",
                            value: "active"
                        }
                    }
                }, {
                    kind: "Argument",
                    name: {
                        kind: "Name",
                        value: "isMobile"
                    },
                    value: {
                        kind: "Variable",
                        name: {
                            kind: "Name",
                            value: "isMobile"
                        }
                    }
                }, {
                    kind: "Argument",
                    name: {
                        kind: "Name",
                        value: "offset"
                    },
                    value: {
                        kind: "Variable",
                        name: {
                            kind: "Name",
                            value: "offset"
                        }
                    }
                }, {
                    kind: "Argument",
                    name: {
                        kind: "Name",
                        value: "limit"
                    },
                    value: {
                        kind: "Variable",
                        name: {
                            kind: "Name",
                            value: "limit"
                        }
                    }
                }],
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "FragmentSpread",
                        name: {
                            kind: "Name",
                            value: "GameKuratorGame"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "isBlocked"
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "SoftswissProvider"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SoftswissProvider"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "name"
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "SoftswissGame"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SoftswissGame"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "edge"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "extId"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "availableCurrencies"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "provider"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "FragmentSpread",
                        name: {
                            kind: "Name",
                            value: "SoftswissProvider"
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "EvolutionGame"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "EvolutionGame"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "name"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "category"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "id"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "name"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "edge"
                }
            }, {
                kind: "Field",
                alias: {
                    kind: "Name",
                    value: "currencies"
                },
                name: {
                    kind: "Name",
                    value: "availableCurrencies"
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "GameKuratorThirdPartyGame"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "GameKuratorThirdPartyGame"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "edge"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "extId"
                }
            }, {
                kind: "Field",
                alias: {
                    kind: "Name",
                    value: "thirdPartyGameAvailableCurrencies"
                },
                name: {
                    kind: "Name",
                    value: "availableCurrencies"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "provider"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "id"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "name"
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "GameKuratorGame"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "GameKuratorGame"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "name"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "slug"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "type"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "thumbnailUrl"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "edge"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "description"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "active"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "icon"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "isFavourite"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "showMultiplierLeaderboard"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "showProfitLeaderboard"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "isDemoEnabled"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "data"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "__typename"
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SoftswissGame"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "FragmentSpread",
                                name: {
                                    kind: "Name",
                                    value: "SoftswissGame"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "EvolutionGame"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "FragmentSpread",
                                name: {
                                    kind: "Name",
                                    value: "EvolutionGame"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "GameKuratorThirdPartyGame"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "FragmentSpread",
                                name: {
                                    kind: "Name",
                                    value: "GameKuratorThirdPartyGame"
                                }
                            }]
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "groupGames"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "id"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "group"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "id"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "translation"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "type"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "slug"
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }]
};
export {
    e as K
};