import {
    s as j,
    C as Q,
    H as X,
    D as x,
    f as I,
    E as ee,
    i as d,
    F as k,
    j as F,
    n as w,
    m as H,
    O as q,
    P as G,
    w as ve,
    a as te,
    u as le,
    g as ne,
    b as ie,
    e as S,
    d as A,
    W as ae,
    r as be,
    I as O,
    k as B,
    t as P,
    h as D,
    l as R,
    c as ke,
    V as Y,
    a1 as ye
} from "./scheduler.DXu26z7T.js";
import {
    S as L,
    i as W,
    g as T,
    b as u,
    e as N,
    t as c,
    c as g,
    a as $,
    m as v,
    d as b
} from "./index.Dz_MmNB3.js";
import {
    e as re
} from "./each.DvgCmocI.js";
import {
    g as Fe
} from "./index.Ci34scWy.js";
import "./index.ByMdEFI5.js";
import {
    V as Me,
    a as we,
    b as Ze,
    c as Ie,
    d as Ee,
    e as Ce,
    f as Se,
    g as Ae,
    h as Ve,
    i as Pe,
    j as De,
    k as ze,
    l as Be,
    m as Oe,
    n as Re,
    o as Te,
    p as Ne,
    q as He,
    r as je,
    s as Le
} from "./VIPSilver.CnTTpkRN.js";
import {
    F as We
} from "./index.DUHuGv4r.js";
import "./index.B3dW9TVs.js";
import {
    az as h
} from "./index.B4-7gKq3.js";
import {
    T as Ue
} from "./index.CYsK4uyl.js";
import {
    H as Je
} from "./index.u8ZD9oiA.js";
import {
    B as qe
} from "./button.BwmFDw8u.js";
import {
    a as Ge
} from "./index.B81orGJm.js";
import {
    g as Ye
} from "./helpers.CobRd3cj.js";
import {
    F as Ke,
    c as Qe,
    g as Xe
} from "./vip.rsPZMLqI.js";

function xe(a) {
    let e, l, t = ` <title>${a[1]||""}</title> <path d="m11.307 70.242 1.17 7.611C14.232 87.804 28.866 96 48.77 96c19.905 0 34.536-8.196 36.294-18.147l1.17-7.61H11.307Z" fill="#EE556C"></path><path d="M48.77 85.462c18.147 0 32.196-6.438 37.464-15.219l2.928-24.585H8.38l2.928 24.585c5.268 8.781 19.317 15.22 37.464 15.22h-.003Z" fill="#FFF8E7"></path><path d="M89.16 45.659c0 10.023-18.083 18.147-40.388 18.147s-40.39-8.124-40.39-18.147c0-10.023 18.085-18.147 40.39-18.147S89.16 35.636 89.16 45.659Z" fill="#fff"></path><path d="M89.16 45.659c0 9.95-18.146 18.147-40.388 18.147-22.242 0-40.39-8.196-40.39-18.147 0-9.951 11.707-22.245 40.39-22.245S89.16 35.12 89.16 45.659Z" fill="#EE556C"></path><path d="M48.77 0c-2.34 0-7.611 13.463 0 13.463 7.61 0 2.34-13.463 0-13.463Z" fill="#FFC05C"></path><path d="m58.134 32.78-5.853 1.755c-1.755 0-3.513-.585-4.098-2.34s.585-2.928 1.755-3.513l5.853-1.755c1.755-.585 3.513 0 4.098 1.755s-.585 3.513-1.755 4.098Z" fill="#17FCFC"></path><path d="m20.67 39.803-4.098 1.17c-1.755.584-3.513-.585-4.098-1.755-.585-1.756.585-3.514 2.34-4.099l4.098-1.17c1.755-.584 3.513.586 3.513 1.756.585 1.755 0 3.513-1.755 4.098Zm55.608 4.682-2.34-5.268c-.585-1.755 0-3.513 1.755-4.098s3.513 0 4.098 1.755l2.34 5.268c.585 1.755 0 3.513-1.755 4.098-1.755 0-3.513-.585-4.098-1.755Z" fill="#8AFF64"></path><path d="m60.477 56.779-3.513-1.755c-1.755-.585-2.34-2.34-1.17-4.098.585-1.755 2.34-2.34 4.098-1.17l3.513 1.755c1.17.585 1.755 2.34 1.17 4.098-1.17 1.17-2.928 1.755-4.098 1.17Z" fill="#FDAA14"></path><path d="M43.5 16.976v26.34c0 1.17 1.17 3.513 5.268 3.513s5.268-2.34 5.268-3.513v-26.34H43.5Z" fill="#FFF8E7"></path><path d="M54.036 16.976c0 1.293-2.358 2.34-5.268 2.34-2.91 0-5.268-1.047-5.268-2.34s2.358-2.34 5.268-2.34c2.91 0 5.268 1.047 5.268 2.34Z" fill="#fff"></path><path d="M65.742 4.683c-2.34 0-6.438 11.706 0 11.706s1.755-11.706 0-11.706Z" fill="#FFC05C"></path><path d="M61.06 18.731v22.245c0 1.17 1.17 2.928 4.684 2.928 3.513 0 4.683-1.755 4.683-2.928V18.731H61.06Z" fill="#FFF8E7"></path><path d="M70.427 18.731c0 .97-2.097 1.755-4.683 1.755s-4.684-.786-4.684-1.755c0-.969 2.098-1.755 4.684-1.755 2.586 0 4.683.786 4.683 1.755Z" fill="#fff"></path><path d="M31.205 4.683c-2.34 0-6.438 11.706 0 11.706s2.34-11.706 0-11.706Z" fill="#FFC05C"></path><path d="M27.111 18.731v22.245c0 1.17 1.17 2.928 4.683 2.928s4.098-1.755 4.098-2.928V18.731h-8.78Z" fill="#FFF8E7"></path><path d="M35.303 18.731c0 .97-1.833 1.755-4.098 1.755-2.265 0-4.098-.786-4.098-1.755 0-.969 1.833-1.755 4.098-1.755 2.265 0 4.098.786 4.098 1.755Z" fill="#fff"></path><path d="M64.572 80.779c-2.928 0-5.853-1.17-7.61-2.928-2.34-2.34-5.854-3.513-9.367-2.928-3.513 0-6.438 1.17-9.366 3.513s-6.438 2.928-9.95 1.755c-3.514-1.173-7.024-8.196-9.952-10.536S6.621 67.9 6.621 60.874c0-1.17.585-2.928 2.34-3.513 1.755 0 2.928.585 3.513 2.34s3.513 2.34 8.781 4.683c5.268 2.928 5.268 9.95 9.366 10.536 5.853 1.17 8.781-5.268 16.977-5.268 4.683 0 9.366 1.17 12.88 4.098 1.17 1.17 2.927 1.755 4.682 1.755 2.34 0 3.513-1.755 5.853-4.683 1.755-2.34 3.513-4.683 5.268-6.438 1.755-1.17 7.023-2.34 9.366-2.34 1.755 0 2.928.585 3.513 1.755.585 1.755 0 2.928-1.755 3.513-2.34 1.17-5.268 0-8.196 1.755-4.683 2.928-4.683 11.12-14.634 11.706l-.003.006Z" fill="#FFC05C"></path><path d="m39.402 52.096-5.268 2.928c-1.755.585-3.513 0-4.098-1.17-.585-1.755 0-3.513 1.17-4.098l5.268-2.928c1.755-.585 3.513 0 4.098 1.17 1.17 1.755.585 3.513-1.17 4.098Z" fill="#17FCFC"></path>`,
        n;
    return {
        c() {
            e = Q("svg"), l = new X(!0), this.h()
        },
        l(i) {
            e = x(i, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var s = I(e);
            l = ee(s, !0), s.forEach(d), this.h()
        },
        h() {
            l.a = null, k(e, "fill", "none"), k(e, "viewBox", "0 0 96 96"), k(e, "class", n = "svg-icon " + a[2]), k(e, "style", a[0])
        },
        m(i, s) {
            F(i, e, s), l.m(t, e)
        },
        p(i, [s]) {
            s & 2 && t !== (t = ` <title>${i[1]||""}</title> <path d="m11.307 70.242 1.17 7.611C14.232 87.804 28.866 96 48.77 96c19.905 0 34.536-8.196 36.294-18.147l1.17-7.61H11.307Z" fill="#EE556C"></path><path d="M48.77 85.462c18.147 0 32.196-6.438 37.464-15.219l2.928-24.585H8.38l2.928 24.585c5.268 8.781 19.317 15.22 37.464 15.22h-.003Z" fill="#FFF8E7"></path><path d="M89.16 45.659c0 10.023-18.083 18.147-40.388 18.147s-40.39-8.124-40.39-18.147c0-10.023 18.085-18.147 40.39-18.147S89.16 35.636 89.16 45.659Z" fill="#fff"></path><path d="M89.16 45.659c0 9.95-18.146 18.147-40.388 18.147-22.242 0-40.39-8.196-40.39-18.147 0-9.951 11.707-22.245 40.39-22.245S89.16 35.12 89.16 45.659Z" fill="#EE556C"></path><path d="M48.77 0c-2.34 0-7.611 13.463 0 13.463 7.61 0 2.34-13.463 0-13.463Z" fill="#FFC05C"></path><path d="m58.134 32.78-5.853 1.755c-1.755 0-3.513-.585-4.098-2.34s.585-2.928 1.755-3.513l5.853-1.755c1.755-.585 3.513 0 4.098 1.755s-.585 3.513-1.755 4.098Z" fill="#17FCFC"></path><path d="m20.67 39.803-4.098 1.17c-1.755.584-3.513-.585-4.098-1.755-.585-1.756.585-3.514 2.34-4.099l4.098-1.17c1.755-.584 3.513.586 3.513 1.756.585 1.755 0 3.513-1.755 4.098Zm55.608 4.682-2.34-5.268c-.585-1.755 0-3.513 1.755-4.098s3.513 0 4.098 1.755l2.34 5.268c.585 1.755 0 3.513-1.755 4.098-1.755 0-3.513-.585-4.098-1.755Z" fill="#8AFF64"></path><path d="m60.477 56.779-3.513-1.755c-1.755-.585-2.34-2.34-1.17-4.098.585-1.755 2.34-2.34 4.098-1.17l3.513 1.755c1.17.585 1.755 2.34 1.17 4.098-1.17 1.17-2.928 1.755-4.098 1.17Z" fill="#FDAA14"></path><path d="M43.5 16.976v26.34c0 1.17 1.17 3.513 5.268 3.513s5.268-2.34 5.268-3.513v-26.34H43.5Z" fill="#FFF8E7"></path><path d="M54.036 16.976c0 1.293-2.358 2.34-5.268 2.34-2.91 0-5.268-1.047-5.268-2.34s2.358-2.34 5.268-2.34c2.91 0 5.268 1.047 5.268 2.34Z" fill="#fff"></path><path d="M65.742 4.683c-2.34 0-6.438 11.706 0 11.706s1.755-11.706 0-11.706Z" fill="#FFC05C"></path><path d="M61.06 18.731v22.245c0 1.17 1.17 2.928 4.684 2.928 3.513 0 4.683-1.755 4.683-2.928V18.731H61.06Z" fill="#FFF8E7"></path><path d="M70.427 18.731c0 .97-2.097 1.755-4.683 1.755s-4.684-.786-4.684-1.755c0-.969 2.098-1.755 4.684-1.755 2.586 0 4.683.786 4.683 1.755Z" fill="#fff"></path><path d="M31.205 4.683c-2.34 0-6.438 11.706 0 11.706s2.34-11.706 0-11.706Z" fill="#FFC05C"></path><path d="M27.111 18.731v22.245c0 1.17 1.17 2.928 4.683 2.928s4.098-1.755 4.098-2.928V18.731h-8.78Z" fill="#FFF8E7"></path><path d="M35.303 18.731c0 .97-1.833 1.755-4.098 1.755-2.265 0-4.098-.786-4.098-1.755 0-.969 1.833-1.755 4.098-1.755 2.265 0 4.098.786 4.098 1.755Z" fill="#fff"></path><path d="M64.572 80.779c-2.928 0-5.853-1.17-7.61-2.928-2.34-2.34-5.854-3.513-9.367-2.928-3.513 0-6.438 1.17-9.366 3.513s-6.438 2.928-9.95 1.755c-3.514-1.173-7.024-8.196-9.952-10.536S6.621 67.9 6.621 60.874c0-1.17.585-2.928 2.34-3.513 1.755 0 2.928.585 3.513 2.34s3.513 2.34 8.781 4.683c5.268 2.928 5.268 9.95 9.366 10.536 5.853 1.17 8.781-5.268 16.977-5.268 4.683 0 9.366 1.17 12.88 4.098 1.17 1.17 2.927 1.755 4.682 1.755 2.34 0 3.513-1.755 5.853-4.683 1.755-2.34 3.513-4.683 5.268-6.438 1.755-1.17 7.023-2.34 9.366-2.34 1.755 0 2.928.585 3.513 1.755.585 1.755 0 2.928-1.755 3.513-2.34 1.17-5.268 0-8.196 1.755-4.683 2.928-4.683 11.12-14.634 11.706l-.003.006Z" fill="#FFC05C"></path><path d="m39.402 52.096-5.268 2.928c-1.755.585-3.513 0-4.098-1.17-.585-1.755 0-3.513 1.17-4.098l5.268-2.928c1.755-.585 3.513 0 4.098 1.17 1.17 1.755.585 3.513-1.17 4.098Z" fill="#17FCFC"></path>`) && l.p(t), s & 4 && n !== (n = "svg-icon " + i[2]) && k(e, "class", n), s & 1 && k(e, "style", i[0])
        },
        i: w,
        o: w,
        d(i) {
            i && d(e)
        }
    }
}

function et(a, e, l) {
    let {
        style: t = ""
    } = e, {
        alt: n = ""
    } = e, {
        class: i = ""
    } = e;
    return a.$$set = s => {
        "style" in s && l(0, t = s.style), "alt" in s && l(1, n = s.alt), "class" in s && l(2, i = s.class)
    }, [t, n, i]
}
class tt extends L {
    constructor(e) {
        super(), W(this, e, et, xe, j, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}

function lt(a) {
    let e, l, t = ` <title>${a[1]||""}</title> <path d="M44.977.002s4.876 23.762-7.92 20.717c0 0-7.621 13.096-7.621 25.892s-13.396 3.66-9.751-6.706c0 0-21.932 18.272 1.23 40.819 0 0 .6 3.66-6.105 0 0 0 7.32 15.226 32.297 15.226 24.978 0 31.023-12.78 31.023-12.78h-4.26s21.93-14.013 6.09-43.88c0 0-1.215 8.536-6.09 7.32-4.876-1.214.6-15.225-3-23.146-3.6-7.92-17.102-20.117-25.893-23.462Z" fill="#DE2A42"></path><path d="M21.47 20.419c-1.266 3.54-3.129 6.578-5.493 9.155l.018-.02c-2.34 2.67-.615 9.134-.615 9.134s9.75-9.135 6.09-18.27Z" fill="#DE2A42"></path><path d="M50.108 16.144s1.215 8.535-4.876 13.41c-6.09 4.876-9.136 14.612-10.35 24.978-1.216 10.366-10.366 12.796-15.242 4.26 0 0-4.875 29.238 27.422 37.158 0 0 21.317-1.215 29.238-24.362 0 0-5.475 1.83-5.475-2.43s3.645-5.49 1.215-13.411c0 0-7.306 6.09-10.351-2.43-3.045-8.521 8.52-19.502-11.581-37.173Z" fill="#FED43F"></path><path d="M52.477 45.996s-9 7.32-12.12 18.285c-3.12 10.965-8.52 10.965-8.52 10.965s2.43 19.5 15.225 20.7c12.795 1.2 17.67-18.885 17.67-18.885s-4.275-1.815-3.66-8.52c0 0-13.395 1.83-8.595-22.545Z" fill="#fff"></path>`,
        n;
    return {
        c() {
            e = Q("svg"), l = new X(!0), this.h()
        },
        l(i) {
            e = x(i, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var s = I(e);
            l = ee(s, !0), s.forEach(d), this.h()
        },
        h() {
            l.a = null, k(e, "fill", "none"), k(e, "viewBox", "0 0 96 96"), k(e, "class", n = "svg-icon " + a[2]), k(e, "style", a[0])
        },
        m(i, s) {
            F(i, e, s), l.m(t, e)
        },
        p(i, [s]) {
            s & 2 && t !== (t = ` <title>${i[1]||""}</title> <path d="M44.977.002s4.876 23.762-7.92 20.717c0 0-7.621 13.096-7.621 25.892s-13.396 3.66-9.751-6.706c0 0-21.932 18.272 1.23 40.819 0 0 .6 3.66-6.105 0 0 0 7.32 15.226 32.297 15.226 24.978 0 31.023-12.78 31.023-12.78h-4.26s21.93-14.013 6.09-43.88c0 0-1.215 8.536-6.09 7.32-4.876-1.214.6-15.225-3-23.146-3.6-7.92-17.102-20.117-25.893-23.462Z" fill="#DE2A42"></path><path d="M21.47 20.419c-1.266 3.54-3.129 6.578-5.493 9.155l.018-.02c-2.34 2.67-.615 9.134-.615 9.134s9.75-9.135 6.09-18.27Z" fill="#DE2A42"></path><path d="M50.108 16.144s1.215 8.535-4.876 13.41c-6.09 4.876-9.136 14.612-10.35 24.978-1.216 10.366-10.366 12.796-15.242 4.26 0 0-4.875 29.238 27.422 37.158 0 0 21.317-1.215 29.238-24.362 0 0-5.475 1.83-5.475-2.43s3.645-5.49 1.215-13.411c0 0-7.306 6.09-10.351-2.43-3.045-8.521 8.52-19.502-11.581-37.173Z" fill="#FED43F"></path><path d="M52.477 45.996s-9 7.32-12.12 18.285c-3.12 10.965-8.52 10.965-8.52 10.965s2.43 19.5 15.225 20.7c12.795 1.2 17.67-18.885 17.67-18.885s-4.275-1.815-3.66-8.52c0 0-13.395 1.83-8.595-22.545Z" fill="#fff"></path>`) && l.p(t), s & 4 && n !== (n = "svg-icon " + i[2]) && k(e, "class", n), s & 1 && k(e, "style", i[0])
        },
        i: w,
        o: w,
        d(i) {
            i && d(e)
        }
    }
}

function nt(a, e, l) {
    let {
        style: t = ""
    } = e, {
        alt: n = ""
    } = e, {
        class: i = ""
    } = e;
    return a.$$set = s => {
        "style" in s && l(0, t = s.style), "alt" in s && l(1, n = s.alt), "class" in s && l(2, i = s.class)
    }, [t, n, i]
}
class it extends L {
    constructor(e) {
        super(), W(this, e, nt, lt, j, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}

function at(a) {
    let e, l, t = ` <title>${a[1]||""}</title> <path d="M71.48 11.227c4.467 0 5.424 5.066 5.424 12.808 0 7.741 2.194 37.426 2.194 37.426L66.05 38.001V17.65c0-3.71 1.675-6.424 5.425-6.424h.003Z" fill="#fff"></path><path d="M66.054 18.687c3.231 6.942 7.78 16.838 3.989 17.515-3.792.676-3.99-8.418-3.99-8.418v-9.097Z" fill="#AAC1D1"></path><path d="M71.64 41.352c-3.99-3.552 7.501 21.267 7.46 20.19 0 0-2.194-29.646-2.194-37.427 0-7.062-.718-11.97-4.228-12.726 4.03 7.78 2.714 33.476-1.039 29.963Z" fill="#AAC1D1"></path><path d="M52.847.095c6.425-1.197 7.622 9.097 10.333 19.95C65.89 30.9 78.262 50.01 79.138 61.7l-7.621-1.834-19.95-35.11s-2.395-14.403-2.715-18.634a4.827 4.827 0 0 1 3.962-6.02l.027-.004.006-.003Zm-6.541 86.58c-7.742 5.985-2.275 10.175 4.309 9.178 6.583-.996 32.198-10.973 31.92-17.715 0-14.804-36.23 8.537-36.23 8.537Z" fill="#fff"></path><path d="M78.22 73.15c4.468.718-6.224 16.757-26.414 13.845-20.19-2.911 20.387-14.761 26.414-13.846Z" fill="#AAC1D1"></path><path d="M54.362 41.909c-3.633-5.354-9.692-8.828-16.56-8.828-.913 0-1.813.063-2.693.18l.102-.013c-8.582.255-15.944 5.225-19.61 12.401l-.06.129c-2.354 4.27 0 10.853 5.426 8.498 5.425-2.355 8.498-6.622 15.082-6.305 5.168.461 9.186 4.77 9.186 10.019 0 .167-.003.335-.011.5v-.024c-.036 5.308-3.998 9.68-9.124 10.369l-.054.006c-5.746 0-5.746-5.946-9.495-9.136-3.75-3.19-7.981-5.626-11.77-3.75-3.788 1.876 1.197 15.56 7.221 21.866 4.668 4.946 14.205 11.97 32.519 9.336 18.314-2.633 24.897-16.796 24.738-25.615-.158-8.819-18.633-31.68-27.928-43.531C43.272 8.396 37.407 3.088 33.535 4.964c-3.872 1.876-3.75 7.98.997 14.564 4.746 6.584 19.83 22.384 19.83 22.384v-.003Z" fill="#fff"></path><path d="M37.485 46.098c-14.124-1.996-13.128 6.305-19.591 8.498a5.033 5.033 0 0 0 3.103-.332l-.033.012c5.587-2.313 8.498-6.622 15.082-6.305 5.168.46 9.186 4.77 9.186 10.019 0 .167-.002.335-.011.5v-.025c-.036 5.309-3.998 9.681-9.124 10.37l-.054.005h-.111a5.494 5.494 0 0 1-3.878-1.598 10.58 10.58 0 0 0 7.592 3.2c3.86 0 7.241-2.063 9.097-5.145l.026-.048c3.232-6.903 2.873-17.275-11.29-19.151h.006Zm12.29-9.055s6.503 6.305 7.981 5.946c1.478-.36 2.954-6.784-14.363-12.966l6.382 7.02Zm15.202-1.039c1.915.877 2.753-.996-1.158-4.548S52.846 20.405 52.846 20.405l12.131 15.6Z" fill="#AAC1D1"></path>`,
        n;
    return {
        c() {
            e = Q("svg"), l = new X(!0), this.h()
        },
        l(i) {
            e = x(i, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var s = I(e);
            l = ee(s, !0), s.forEach(d), this.h()
        },
        h() {
            l.a = null, k(e, "fill", "none"), k(e, "viewBox", "0 0 96 96"), k(e, "class", n = "svg-icon " + a[2]), k(e, "style", a[0])
        },
        m(i, s) {
            F(i, e, s), l.m(t, e)
        },
        p(i, [s]) {
            s & 2 && t !== (t = ` <title>${i[1]||""}</title> <path d="M71.48 11.227c4.467 0 5.424 5.066 5.424 12.808 0 7.741 2.194 37.426 2.194 37.426L66.05 38.001V17.65c0-3.71 1.675-6.424 5.425-6.424h.003Z" fill="#fff"></path><path d="M66.054 18.687c3.231 6.942 7.78 16.838 3.989 17.515-3.792.676-3.99-8.418-3.99-8.418v-9.097Z" fill="#AAC1D1"></path><path d="M71.64 41.352c-3.99-3.552 7.501 21.267 7.46 20.19 0 0-2.194-29.646-2.194-37.427 0-7.062-.718-11.97-4.228-12.726 4.03 7.78 2.714 33.476-1.039 29.963Z" fill="#AAC1D1"></path><path d="M52.847.095c6.425-1.197 7.622 9.097 10.333 19.95C65.89 30.9 78.262 50.01 79.138 61.7l-7.621-1.834-19.95-35.11s-2.395-14.403-2.715-18.634a4.827 4.827 0 0 1 3.962-6.02l.027-.004.006-.003Zm-6.541 86.58c-7.742 5.985-2.275 10.175 4.309 9.178 6.583-.996 32.198-10.973 31.92-17.715 0-14.804-36.23 8.537-36.23 8.537Z" fill="#fff"></path><path d="M78.22 73.15c4.468.718-6.224 16.757-26.414 13.845-20.19-2.911 20.387-14.761 26.414-13.846Z" fill="#AAC1D1"></path><path d="M54.362 41.909c-3.633-5.354-9.692-8.828-16.56-8.828-.913 0-1.813.063-2.693.18l.102-.013c-8.582.255-15.944 5.225-19.61 12.401l-.06.129c-2.354 4.27 0 10.853 5.426 8.498 5.425-2.355 8.498-6.622 15.082-6.305 5.168.461 9.186 4.77 9.186 10.019 0 .167-.003.335-.011.5v-.024c-.036 5.308-3.998 9.68-9.124 10.369l-.054.006c-5.746 0-5.746-5.946-9.495-9.136-3.75-3.19-7.981-5.626-11.77-3.75-3.788 1.876 1.197 15.56 7.221 21.866 4.668 4.946 14.205 11.97 32.519 9.336 18.314-2.633 24.897-16.796 24.738-25.615-.158-8.819-18.633-31.68-27.928-43.531C43.272 8.396 37.407 3.088 33.535 4.964c-3.872 1.876-3.75 7.98.997 14.564 4.746 6.584 19.83 22.384 19.83 22.384v-.003Z" fill="#fff"></path><path d="M37.485 46.098c-14.124-1.996-13.128 6.305-19.591 8.498a5.033 5.033 0 0 0 3.103-.332l-.033.012c5.587-2.313 8.498-6.622 15.082-6.305 5.168.46 9.186 4.77 9.186 10.019 0 .167-.002.335-.011.5v-.025c-.036 5.309-3.998 9.681-9.124 10.37l-.054.005h-.111a5.494 5.494 0 0 1-3.878-1.598 10.58 10.58 0 0 0 7.592 3.2c3.86 0 7.241-2.063 9.097-5.145l.026-.048c3.232-6.903 2.873-17.275-11.29-19.151h.006Zm12.29-9.055s6.503 6.305 7.981 5.946c1.478-.36 2.954-6.784-14.363-12.966l6.382 7.02Zm15.202-1.039c1.915.877 2.753-.996-1.158-4.548S52.846 20.405 52.846 20.405l12.131 15.6Z" fill="#AAC1D1"></path>`) && l.p(t), s & 4 && n !== (n = "svg-icon " + i[2]) && k(e, "class", n), s & 1 && k(e, "style", i[0])
        },
        i: w,
        o: w,
        d(i) {
            i && d(e)
        }
    }
}

function rt(a, e, l) {
    let {
        style: t = ""
    } = e, {
        alt: n = ""
    } = e, {
        class: i = ""
    } = e;
    return a.$$set = s => {
        "style" in s && l(0, t = s.style), "alt" in s && l(1, n = s.alt), "class" in s && l(2, i = s.class)
    }, [t, n, i]
}
class st extends L {
    constructor(e) {
        super(), W(this, e, rt, at, j, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}

function ot(a) {
    let e, l;
    return e = new Me({
        props: {
            style: a[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(t) {
            $(e.$$.fragment, t)
        },
        m(t, n) {
            v(e, t, n), l = !0
        },
        p(t, n) {
            const i = {};
            n & 2 && (i.style = t[1]), e.$set(i)
        },
        i(t) {
            l || (c(e.$$.fragment, t), l = !0)
        },
        o(t) {
            u(e.$$.fragment, t), l = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function ft(a) {
    let e, l;
    return e = new we({
        props: {
            style: a[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(t) {
            $(e.$$.fragment, t)
        },
        m(t, n) {
            v(e, t, n), l = !0
        },
        p(t, n) {
            const i = {};
            n & 2 && (i.style = t[1]), e.$set(i)
        },
        i(t) {
            l || (c(e.$$.fragment, t), l = !0)
        },
        o(t) {
            u(e.$$.fragment, t), l = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function ct(a) {
    let e, l;
    return e = new Ze({
        props: {
            style: a[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(t) {
            $(e.$$.fragment, t)
        },
        m(t, n) {
            v(e, t, n), l = !0
        },
        p(t, n) {
            const i = {};
            n & 2 && (i.style = t[1]), e.$set(i)
        },
        i(t) {
            l || (c(e.$$.fragment, t), l = !0)
        },
        o(t) {
            u(e.$$.fragment, t), l = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function ut(a) {
    let e, l;
    return e = new Ie({
        props: {
            style: a[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(t) {
            $(e.$$.fragment, t)
        },
        m(t, n) {
            v(e, t, n), l = !0
        },
        p(t, n) {
            const i = {};
            n & 2 && (i.style = t[1]), e.$set(i)
        },
        i(t) {
            l || (c(e.$$.fragment, t), l = !0)
        },
        o(t) {
            u(e.$$.fragment, t), l = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function mt(a) {
    let e, l;
    return e = new Ee({
        props: {
            style: a[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(t) {
            $(e.$$.fragment, t)
        },
        m(t, n) {
            v(e, t, n), l = !0
        },
        p(t, n) {
            const i = {};
            n & 2 && (i.style = t[1]), e.$set(i)
        },
        i(t) {
            l || (c(e.$$.fragment, t), l = !0)
        },
        o(t) {
            u(e.$$.fragment, t), l = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function pt(a) {
    let e, l;
    return e = new Ce({
        props: {
            style: a[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(t) {
            $(e.$$.fragment, t)
        },
        m(t, n) {
            v(e, t, n), l = !0
        },
        p(t, n) {
            const i = {};
            n & 2 && (i.style = t[1]), e.$set(i)
        },
        i(t) {
            l || (c(e.$$.fragment, t), l = !0)
        },
        o(t) {
            u(e.$$.fragment, t), l = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function _t(a) {
    let e, l;
    return e = new Se({
        props: {
            style: a[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(t) {
            $(e.$$.fragment, t)
        },
        m(t, n) {
            v(e, t, n), l = !0
        },
        p(t, n) {
            const i = {};
            n & 2 && (i.style = t[1]), e.$set(i)
        },
        i(t) {
            l || (c(e.$$.fragment, t), l = !0)
        },
        o(t) {
            u(e.$$.fragment, t), l = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function ht(a) {
    let e, l;
    return e = new Ae({
        props: {
            style: a[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(t) {
            $(e.$$.fragment, t)
        },
        m(t, n) {
            v(e, t, n), l = !0
        },
        p(t, n) {
            const i = {};
            n & 2 && (i.style = t[1]), e.$set(i)
        },
        i(t) {
            l || (c(e.$$.fragment, t), l = !0)
        },
        o(t) {
            u(e.$$.fragment, t), l = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function dt(a) {
    let e, l;
    return e = new Ve({
        props: {
            style: a[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(t) {
            $(e.$$.fragment, t)
        },
        m(t, n) {
            v(e, t, n), l = !0
        },
        p(t, n) {
            const i = {};
            n & 2 && (i.style = t[1]), e.$set(i)
        },
        i(t) {
            l || (c(e.$$.fragment, t), l = !0)
        },
        o(t) {
            u(e.$$.fragment, t), l = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function gt(a) {
    let e, l;
    return e = new Pe({
        props: {
            style: a[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(t) {
            $(e.$$.fragment, t)
        },
        m(t, n) {
            v(e, t, n), l = !0
        },
        p(t, n) {
            const i = {};
            n & 2 && (i.style = t[1]), e.$set(i)
        },
        i(t) {
            l || (c(e.$$.fragment, t), l = !0)
        },
        o(t) {
            u(e.$$.fragment, t), l = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function $t(a) {
    let e, l;
    return e = new De({
        props: {
            style: a[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(t) {
            $(e.$$.fragment, t)
        },
        m(t, n) {
            v(e, t, n), l = !0
        },
        p(t, n) {
            const i = {};
            n & 2 && (i.style = t[1]), e.$set(i)
        },
        i(t) {
            l || (c(e.$$.fragment, t), l = !0)
        },
        o(t) {
            u(e.$$.fragment, t), l = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function vt(a) {
    let e, l;
    return e = new ze({
        props: {
            style: a[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(t) {
            $(e.$$.fragment, t)
        },
        m(t, n) {
            v(e, t, n), l = !0
        },
        p(t, n) {
            const i = {};
            n & 2 && (i.style = t[1]), e.$set(i)
        },
        i(t) {
            l || (c(e.$$.fragment, t), l = !0)
        },
        o(t) {
            u(e.$$.fragment, t), l = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function bt(a) {
    let e, l;
    return e = new Be({
        props: {
            style: a[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(t) {
            $(e.$$.fragment, t)
        },
        m(t, n) {
            v(e, t, n), l = !0
        },
        p(t, n) {
            const i = {};
            n & 2 && (i.style = t[1]), e.$set(i)
        },
        i(t) {
            l || (c(e.$$.fragment, t), l = !0)
        },
        o(t) {
            u(e.$$.fragment, t), l = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function kt(a) {
    let e, l;
    return e = new Oe({
        props: {
            style: a[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(t) {
            $(e.$$.fragment, t)
        },
        m(t, n) {
            v(e, t, n), l = !0
        },
        p(t, n) {
            const i = {};
            n & 2 && (i.style = t[1]), e.$set(i)
        },
        i(t) {
            l || (c(e.$$.fragment, t), l = !0)
        },
        o(t) {
            u(e.$$.fragment, t), l = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function yt(a) {
    let e, l;
    return e = new Re({
        props: {
            style: a[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(t) {
            $(e.$$.fragment, t)
        },
        m(t, n) {
            v(e, t, n), l = !0
        },
        p(t, n) {
            const i = {};
            n & 2 && (i.style = t[1]), e.$set(i)
        },
        i(t) {
            l || (c(e.$$.fragment, t), l = !0)
        },
        o(t) {
            u(e.$$.fragment, t), l = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function Ft(a) {
    let e, l;
    return e = new Te({
        props: {
            style: a[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(t) {
            $(e.$$.fragment, t)
        },
        m(t, n) {
            v(e, t, n), l = !0
        },
        p(t, n) {
            const i = {};
            n & 2 && (i.style = t[1]), e.$set(i)
        },
        i(t) {
            l || (c(e.$$.fragment, t), l = !0)
        },
        o(t) {
            u(e.$$.fragment, t), l = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function Mt(a) {
    let e, l;
    return e = new Ne({
        props: {
            style: a[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(t) {
            $(e.$$.fragment, t)
        },
        m(t, n) {
            v(e, t, n), l = !0
        },
        p(t, n) {
            const i = {};
            n & 2 && (i.style = t[1]), e.$set(i)
        },
        i(t) {
            l || (c(e.$$.fragment, t), l = !0)
        },
        o(t) {
            u(e.$$.fragment, t), l = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function wt(a) {
    let e, l;
    return e = new He({
        props: {
            style: a[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(t) {
            $(e.$$.fragment, t)
        },
        m(t, n) {
            v(e, t, n), l = !0
        },
        p(t, n) {
            const i = {};
            n & 2 && (i.style = t[1]), e.$set(i)
        },
        i(t) {
            l || (c(e.$$.fragment, t), l = !0)
        },
        o(t) {
            u(e.$$.fragment, t), l = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function Zt(a) {
    let e, l;
    return e = new it({
        props: {
            style: a[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(t) {
            $(e.$$.fragment, t)
        },
        m(t, n) {
            v(e, t, n), l = !0
        },
        p(t, n) {
            const i = {};
            n & 2 && (i.style = t[1]), e.$set(i)
        },
        i(t) {
            l || (c(e.$$.fragment, t), l = !0)
        },
        o(t) {
            u(e.$$.fragment, t), l = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function It(a) {
    let e, l;
    return e = new st({
        props: {
            style: a[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(t) {
            $(e.$$.fragment, t)
        },
        m(t, n) {
            v(e, t, n), l = !0
        },
        p(t, n) {
            const i = {};
            n & 2 && (i.style = t[1]), e.$set(i)
        },
        i(t) {
            l || (c(e.$$.fragment, t), l = !0)
        },
        o(t) {
            u(e.$$.fragment, t), l = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function Et(a) {
    let e, l;
    return e = new tt({
        props: {
            style: a[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(t) {
            $(e.$$.fragment, t)
        },
        m(t, n) {
            v(e, t, n), l = !0
        },
        p(t, n) {
            const i = {};
            n & 2 && (i.style = t[1]), e.$set(i)
        },
        i(t) {
            l || (c(e.$$.fragment, t), l = !0)
        },
        o(t) {
            u(e.$$.fragment, t), l = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function Ct(a) {
    let e, l;
    return e = new je({
        props: {
            style: a[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(t) {
            $(e.$$.fragment, t)
        },
        m(t, n) {
            v(e, t, n), l = !0
        },
        p(t, n) {
            const i = {};
            n & 2 && (i.style = t[1]), e.$set(i)
        },
        i(t) {
            l || (c(e.$$.fragment, t), l = !0)
        },
        o(t) {
            u(e.$$.fragment, t), l = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function St(a) {
    let e, l;
    return e = new Le({
        props: {
            style: a[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(t) {
            $(e.$$.fragment, t)
        },
        m(t, n) {
            v(e, t, n), l = !0
        },
        p(t, n) {
            const i = {};
            n & 2 && (i.style = t[1]), e.$set(i)
        },
        i(t) {
            l || (c(e.$$.fragment, t), l = !0)
        },
        o(t) {
            u(e.$$.fragment, t), l = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function At(a) {
    let e, l, t, n;
    const i = [St, Ct, Et, It, Zt, wt, Mt, Ft, yt, kt, bt, vt, $t, gt, dt, ht, _t, pt, mt, ut, ct, ft, ot],
        s = [];

    function m(r, o) {
        return r[0] === "vip-none" ? 0 : r[0] === "vip-bronze" ? 1 : r[0] === "birthday-emoji" ? 2 : r[0] === "owner" ? 3 : r[0] === "emoji-highroller" ? 4 : r[0] === "vip-silver" ? 5 : r[0] === "vip-gold" ? 6 : r[0] === "vip-platinum-1" ? 7 : r[0] === "vip-platinum-2" ? 8 : r[0] === "vip-platinum-3" ? 9 : r[0] === "vip-platinum-4" ? 10 : r[0] === "vip-platinum-5" ? 11 : r[0] === "vip-platinum-6" ? 12 : r[0] === "vip-diamond-1" ? 13 : r[0] === "vip-diamond-2" ? 14 : r[0] === "vip-diamond-3" ? 15 : r[0] === "vip-diamond-4" ? 16 : r[0] === "vip-diamond-5" ? 17 : r[0] === "vip-obsidian-1" ? 18 : r[0] === "vip-obsidian-2" ? 19 : r[0] === "vip-opal-1" ? 20 : r[0] === "vip-opal-2" ? 21 : r[0] === "vip-plutonium-1" ? 22 : -1
    }
    return ~(e = m(a)) && (l = s[e] = i[e](a)), {
        c() {
            l && l.c(), t = H()
        },
        l(r) {
            l && l.l(r), t = H()
        },
        m(r, o) {
            ~e && s[e].m(r, o), F(r, t, o), n = !0
        },
        p(r, [o]) {
            let f = e;
            e = m(r), e === f ? ~e && s[e].p(r, o) : (l && (T(), u(s[f], 1, 1, () => {
                s[f] = null
            }), N()), ~e ? (l = s[e], l ? l.p(r, o) : (l = s[e] = i[e](r), l.c()), c(l, 1), l.m(t.parentNode, t)) : l = null)
        },
        i(r) {
            n || (c(l), n = !0)
        },
        o(r) {
            u(l), n = !1
        },
        d(r) {
            r && d(t), ~e && s[e].d(r)
        }
    }
}

function Vt(a, e, l) {
    let {
        icon: t
    } = e, {
        style: n
    } = e;
    return a.$$set = i => {
        "icon" in i && l(0, t = i.icon), "style" in i && l(1, n = i.style)
    }, [t, n]
}
class ge extends L {
    constructor(e) {
        super(), W(this, e, Vt, At, j, {
            icon: 0,
            style: 1
        })
    }
}
const Pt = a => ({}),
    se = a => ({});

function Dt(a) {
    let e, l;
    return e = new Je({
        props: {
            $$slots: {
                tooltip: [Nt],
                default: [Tt]
            },
            $$scope: {
                ctx: a
            }
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(t) {
            $(e.$$.fragment, t)
        },
        m(t, n) {
            v(e, t, n), l = !0
        },
        p(t, n) {
            const i = {};
            n & 16387 && (i.$$scope = {
                dirty: n,
                ctx: t
            }), e.$set(i)
        },
        i(t) {
            l || (c(e.$$.fragment, t), l = !0)
        },
        o(t) {
            u(e.$$.fragment, t), l = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function zt(a) {
    let e, l, t, n, i;
    return l = new qe({
        props: {
            builders: [{
                action: a[10]
            }],
            $$slots: {
                default: [Wt]
            },
            $$scope: {
                ctx: a
            }
        }
    }), l.$on("click", a[11]), {
        c() {
            e = S("div"), g(l.$$.fragment), this.h()
        },
        l(s) {
            e = A(s, "DIV", {
                class: !0
            });
            var m = I(e);
            $(l.$$.fragment, m), m.forEach(d), this.h()
        },
        h() {
            k(e, "class", "inline-flex")
        },
        m(s, m) {
            F(s, e, m), v(l, e, null), t = !0, n || (i = [ae(e, "mouseover", a[12]), ae(e, "mouseleave", a[13])], n = !0)
        },
        p(s, m) {
            const r = {};
            m & 8 && (r.builders = [{
                action: s[10]
            }]), m & 16387 && (r.$$scope = {
                dirty: m,
                ctx: s
            }), l.$set(r)
        },
        i(s) {
            t || (c(l.$$.fragment, s), t = !0)
        },
        o(s) {
            u(l.$$.fragment, s), t = !1
        },
        d(s) {
            s && d(e), b(l), n = !1, be(i)
        }
    }
}

function Bt(a) {
    let e, l = JSON.stringify(a[0]) + "",
        t;
    return {
        c() {
            e = S("span"), t = P(l), this.h()
        },
        l(n) {
            e = A(n, "SPAN", {
                class: !0
            });
            var i = I(e);
            t = D(i, l), i.forEach(d), this.h()
        },
        h() {
            k(e, "class", "svelte-nc081s")
        },
        m(n, i) {
            F(n, e, i), B(e, t)
        },
        p(n, i) {
            i & 1 && l !== (l = JSON.stringify(n[0]) + "") && R(t, l)
        },
        i: w,
        o: w,
        d(n) {
            n && d(e)
        }
    }
}

function Ot(a) {
    let e, l = a[0].i + "",
        t;
    return {
        c() {
            e = S("div"), t = P(l), this.h()
        },
        l(n) {
            e = A(n, "DIV", {
                class: !0,
                style: !0
            });
            var i = I(e);
            t = D(i, l), i.forEach(d), this.h()
        },
        h() {
            k(e, "class", "tag-text"), O(e, "font-size", "var(--text-size-" + a[1] + ")")
        },
        m(n, i) {
            F(n, e, i), B(e, t)
        },
        p(n, i) {
            i & 1 && l !== (l = n[0].i + "") && R(t, l), i & 2 && O(e, "font-size", "var(--text-size-" + n[1] + ")")
        },
        i: w,
        o: w,
        d(n) {
            n && d(e)
        }
    }
}

function Rt(a) {
    let e, l;
    return e = new ge({
        props: {
            icon: a[0].i.icon,
            style: "font-size: var(--text-size-" + a[1] + ");"
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(t) {
            $(e.$$.fragment, t)
        },
        m(t, n) {
            v(e, t, n), l = !0
        },
        p(t, n) {
            const i = {};
            n & 1 && (i.icon = t[0].i.icon), n & 2 && (i.style = "font-size: var(--text-size-" + t[1] + ");"), e.$set(i)
        },
        i(t) {
            l || (c(e.$$.fragment, t), l = !0)
        },
        o(t) {
            u(e.$$.fragment, t), l = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function Tt(a) {
    let e, l, t, n;
    const i = [Rt, Ot, Bt],
        s = [];

    function m(r, o) {
        return typeof r[0].i == "object" && "icon" in r[0].i ? 0 : "i" in r[0] ? 1 : 2
    }
    return l = m(a), t = s[l] = i[l](a), {
        c() {
            e = S("span"), t.c(), this.h()
        },
        l(r) {
            e = A(r, "SPAN", {
                class: !0,
                style: !0
            });
            var o = I(e);
            t.l(o), o.forEach(d), this.h()
        },
        h() {
            k(e, "class", "wrap svelte-nc081s"), O(e, "color", "color" in a[0] ? a[0].color : "")
        },
        m(r, o) {
            F(r, e, o), s[l].m(e, null), n = !0
        },
        p(r, o) {
            let f = l;
            l = m(r), l === f ? s[l].p(r, o) : (T(), u(s[f], 1, 1, () => {
                s[f] = null
            }), N(), t = s[l], t ? t.p(r, o) : (t = s[l] = i[l](r), t.c()), c(t, 1), t.m(e, null)), (!n || o & 1) && O(e, "color", "color" in r[0] ? r[0].color : "")
        },
        i(r) {
            n || (c(t), n = !0)
        },
        o(r) {
            u(t), n = !1
        },
        d(r) {
            r && d(e), s[l].d()
        }
    }
}

function oe(a) {
    let e = a[0].name + "",
        l;
    return {
        c() {
            l = P(e)
        },
        l(t) {
            l = D(t, e)
        },
        m(t, n) {
            F(t, l, n)
        },
        p(t, n) {
            n & 1 && e !== (e = t[0].name + "") && R(l, e)
        },
        d(t) {
            t && d(l)
        }
    }
}

function Nt(a) {
    let e, l = "name" in a[0] && oe(a);
    return {
        c() {
            e = S("span"), l && l.c(), this.h()
        },
        l(t) {
            e = A(t, "SPAN", {
                slot: !0,
                class: !0
            });
            var n = I(e);
            l && l.l(n), n.forEach(d), this.h()
        },
        h() {
            k(e, "slot", "tooltip"), k(e, "class", "svelte-nc081s")
        },
        m(t, n) {
            F(t, e, n), l && l.m(e, null)
        },
        p(t, n) {
            "name" in t[0] ? l ? l.p(t, n) : (l = oe(t), l.c(), l.m(e, null)) : l && (l.d(1), l = null)
        },
        d(t) {
            t && d(e), l && l.d()
        }
    }
}

function Ht(a) {
    let e, l = JSON.stringify(a[0]) + "",
        t;
    return {
        c() {
            e = S("span"), t = P(l), this.h()
        },
        l(n) {
            e = A(n, "SPAN", {
                class: !0
            });
            var i = I(e);
            t = D(i, l), i.forEach(d), this.h()
        },
        h() {
            k(e, "class", "svelte-nc081s")
        },
        m(n, i) {
            F(n, e, i), B(e, t)
        },
        p(n, i) {
            i & 1 && l !== (l = JSON.stringify(n[0]) + "") && R(t, l)
        },
        i: w,
        o: w,
        d(n) {
            n && d(e)
        }
    }
}

function jt(a) {
    let e, l = a[0].i + "",
        t;
    return {
        c() {
            e = S("div"), t = P(l), this.h()
        },
        l(n) {
            e = A(n, "DIV", {
                class: !0,
                style: !0
            });
            var i = I(e);
            t = D(i, l), i.forEach(d), this.h()
        },
        h() {
            k(e, "class", "tag-text"), O(e, "font-size", "var(--text-size-" + a[1] + ")")
        },
        m(n, i) {
            F(n, e, i), B(e, t)
        },
        p(n, i) {
            i & 1 && l !== (l = n[0].i + "") && R(t, l), i & 2 && O(e, "font-size", "var(--text-size-" + n[1] + ")")
        },
        i: w,
        o: w,
        d(n) {
            n && d(e)
        }
    }
}

function Lt(a) {
    let e, l;
    return e = new ge({
        props: {
            icon: a[0].i.icon,
            style: "font-size: var(--text-size-" + a[1] + ");"
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(t) {
            $(e.$$.fragment, t)
        },
        m(t, n) {
            v(e, t, n), l = !0
        },
        p(t, n) {
            const i = {};
            n & 1 && (i.icon = t[0].i.icon), n & 2 && (i.style = "font-size: var(--text-size-" + t[1] + ");"), e.$set(i)
        },
        i(t) {
            l || (c(e.$$.fragment, t), l = !0)
        },
        o(t) {
            u(e.$$.fragment, t), l = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function Wt(a) {
    let e, l, t, n;
    const i = [Lt, jt, Ht],
        s = [];

    function m(r, o) {
        return typeof r[0].i == "object" && "icon" in r[0].i ? 0 : "i" in r[0] ? 1 : 2
    }
    return l = m(a), t = s[l] = i[l](a), {
        c() {
            e = S("span"), t.c(), this.h()
        },
        l(r) {
            e = A(r, "SPAN", {
                class: !0,
                style: !0
            });
            var o = I(e);
            t.l(o), o.forEach(d), this.h()
        },
        h() {
            k(e, "class", "wrap svelte-nc081s"), O(e, "color", "color" in a[0] ? a[0].color : "")
        },
        m(r, o) {
            F(r, e, o), s[l].m(e, null), n = !0
        },
        p(r, o) {
            let f = l;
            l = m(r), l === f ? s[l].p(r, o) : (T(), u(s[f], 1, 1, () => {
                s[f] = null
            }), N(), t = s[l], t ? t.p(r, o) : (t = s[l] = i[l](r), t.c()), c(t, 1), t.m(e, null)), (!n || o & 1) && O(e, "color", "color" in r[0] ? r[0].color : "")
        },
        i(r) {
            n || (c(t), n = !0)
        },
        o(r) {
            u(t), n = !1
        },
        d(r) {
            r && d(e), s[l].d()
        }
    }
}

function fe(a) {
    let e, l;
    return e = new Ue({
        props: {
            parentNode: a[3],
            $$slots: {
                default: [Gt]
            },
            $$scope: {
                ctx: a
            }
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(t) {
            $(e.$$.fragment, t)
        },
        m(t, n) {
            v(e, t, n), l = !0
        },
        p(t, n) {
            const i = {};
            n & 8 && (i.parentNode = t[3]), n & 16401 && (i.$$scope = {
                dirty: n,
                ctx: t
            }), e.$set(i)
        },
        i(t) {
            l || (c(e.$$.fragment, t), l = !0)
        },
        o(t) {
            u(e.$$.fragment, t), l = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function ce(a) {
    let e = a[0].name + "",
        l;
    return {
        c() {
            l = P(e)
        },
        l(t) {
            l = D(t, e)
        },
        m(t, n) {
            F(t, l, n)
        },
        p(t, n) {
            n & 1 && e !== (e = t[0].name + "") && R(l, e)
        },
        d(t) {
            t && d(l)
        }
    }
}

function Ut(a) {
    let e;
    return {
        c() {
            e = P("expires never")
        },
        l(l) {
            e = D(l, "expires never")
        },
        m(l, t) {
            F(l, e, t)
        },
        p: w,
        i: w,
        o: w,
        d(l) {
            l && d(e)
        }
    }
}

function Jt(a) {
    let e, l, t;
    return l = new We({
        props: {
            value: a[4].expireAt
        }
    }), {
        c() {
            e = P("expires at: "), g(l.$$.fragment)
        },
        l(n) {
            e = D(n, "expires at: "), $(l.$$.fragment, n)
        },
        m(n, i) {
            F(n, e, i), v(l, n, i), t = !0
        },
        p(n, i) {
            const s = {};
            i & 16 && (s.value = n[4].expireAt), l.$set(s)
        },
        i(n) {
            t || (c(l.$$.fragment, n), t = !0)
        },
        o(n) {
            u(l.$$.fragment, n), t = !1
        },
        d(n) {
            n && d(e), b(l, n)
        }
    }
}

function ue(a) {
    let e, l = a[4].message + "",
        t;
    return {
        c() {
            e = P("Reason: "), t = P(l)
        },
        l(n) {
            e = D(n, "Reason: "), t = D(n, l)
        },
        m(n, i) {
            F(n, e, i), F(n, t, i)
        },
        p(n, i) {
            i & 16 && l !== (l = n[4].message + "") && R(t, l)
        },
        d(n) {
            n && (d(e), d(t))
        }
    }
}

function qt(a) {
    var z;
    let e, l, t, n, i, s, m, r = "name" in a[0] && ce(a);
    const o = [Jt, Ut],
        f = [];

    function p(y, M) {
        var Z, V;
        return (Z = y[4]) != null && Z.expireAt ? 0 : ((V = y[4]) == null ? void 0 : V.expireAt) === null ? 1 : -1
    }~(n = p(a)) && (i = f[n] = o[n](a));
    let _ = ((z = a[4]) == null ? void 0 : z.message) && ue(a);
    return {
        c() {
            e = S("div"), l = S("div"), r && r.c(), t = q(), i && i.c(), s = q(), _ && _.c()
        },
        l(y) {
            e = A(y, "DIV", {});
            var M = I(e);
            l = A(M, "DIV", {});
            var Z = I(l);
            r && r.l(Z), t = G(Z), i && i.l(Z), Z.forEach(d), s = G(M), _ && _.l(M), M.forEach(d)
        },
        m(y, M) {
            F(y, e, M), B(e, l), r && r.m(l, null), B(l, t), ~n && f[n].m(l, null), B(e, s), _ && _.m(e, null), m = !0
        },
        p(y, M) {
            var V;
            "name" in y[0] ? r ? r.p(y, M) : (r = ce(y), r.c(), r.m(l, t)) : r && (r.d(1), r = null);
            let Z = n;
            n = p(y), n === Z ? ~n && f[n].p(y, M) : (i && (T(), u(f[Z], 1, 1, () => {
                f[Z] = null
            }), N()), ~n ? (i = f[n], i ? i.p(y, M) : (i = f[n] = o[n](y), i.c()), c(i, 1), i.m(l, null)) : i = null), (V = y[4]) != null && V.message ? _ ? _.p(y, M) : (_ = ue(y), _.c(), _.m(e, null)) : _ && (_.d(1), _ = null)
        },
        i(y) {
            m || (c(i), m = !0)
        },
        o(y) {
            u(i), m = !1
        },
        d(y) {
            y && d(e), r && r.d(), ~n && f[n].d(), _ && _.d()
        }
    }
}

function Gt(a) {
    let e;
    const l = a[9].tooltip,
        t = te(l, a, a[14], se),
        n = t || qt(a);
    return {
        c() {
            n && n.c()
        },
        l(i) {
            n && n.l(i)
        },
        m(i, s) {
            n && n.m(i, s), e = !0
        },
        p(i, s) {
            t ? t.p && (!e || s & 16384) && le(t, l, i, i[14], e ? ie(l, i[14], s, Pt) : ne(i[14]), se) : n && n.p && (!e || s & 17) && n.p(i, e ? s : -1)
        },
        i(i) {
            e || (c(n, i), e = !0)
        },
        o(i) {
            u(n, i), e = !1
        },
        d(i) {
            n && n.d(i)
        }
    }
}

function Yt(a) {
    let e, l, t, n, i;
    const s = [zt, Dt],
        m = [];

    function r(f, p) {
        return 1
    }
    e = r(), l = m[e] = s[e](a);
    let o = a[2] && fe(a);
    return {
        c() {
            l.c(), t = q(), o && o.c(), n = H()
        },
        l(f) {
            l.l(f), t = G(f), o && o.l(f), n = H()
        },
        m(f, p) {
            m[e].m(f, p), F(f, t, p), o && o.m(f, p), F(f, n, p), i = !0
        },
        p(f, [p]) {
            l.p(f, p), f[2] ? o ? (o.p(f, p), p & 4 && c(o, 1)) : (o = fe(f), o.c(), c(o, 1), o.m(n.parentNode, n)) : o && (T(), u(o, 1, 1, () => {
                o = null
            }), N())
        },
        i(f) {
            i || (c(l), c(o), i = !0)
        },
        o(f) {
            u(l), u(o), i = !1
        },
        d(f) {
            f && (d(t), d(n)), m[e].d(f), o && o.d(f)
        }
    }
}

function Kt(a, e, l) {
    let t, {
            $$slots: n = {},
            $$scope: i
        } = e,
        {
            tag: s
        } = e,
        {
            user: m
        } = e,
        {
            fontSize: r = "default"
        } = e,
        o, f = !1,
        p, _ = !1;
    const z = () => {
            clearTimeout(o), l(2, f = !0)
        },
        y = () => {
            _ || (clearTimeout(o), l(2, f = !1), _ = !1)
        },
        M = () => {
            clearTimeout(o), l(2, f = !0), _ = !0, o = setTimeout(() => {
                l(2, f = !1)
            }, 5e3)
        };
    ve(() => {
        clearTimeout(o)
    });
    const Z = E => {
            l(3, p = E)
        },
        V = () => {
            M()
        },
        U = () => {
            z()
        },
        C = () => {
            y()
        };
    return a.$$set = E => {
        "tag" in E && l(0, s = E.tag), "user" in E && l(8, m = E.user), "fontSize" in E && l(1, r = E.fontSize), "$$scope" in E && l(14, i = E.$$scope)
    }, a.$$.update = () => {
        var E;
        a.$$.dirty & 257 && l(4, t = (E = m == null ? void 0 : m.roles) == null ? void 0 : E.find(K => {
            if (K.name === h.sportsbookFraudForceFlagged && "name" in s && s.name === "Sports FF" || K.name === h.casinoFraudForceFlagged && "name" in s && s.name === "Casino FF") return !0;
            if ("name" in s) return K.name === s.name
        }))
    }, [s, r, f, p, t, z, y, M, m, n, Z, V, U, C, i]
}
class Qt extends L {
    constructor(e) {
        super(), W(this, e, Kt, Yt, j, {
            tag: 0,
            user: 8,
            fontSize: 1
        })
    }
}
const Xt = a => {
        const l = [...a].sort((n, i) => n.rank < i.rank ? 1 : -1)[0];
        return l != null && l.flag && l.flag in Ke ? [{
            name: Qe(l == null ? void 0 : l.flag),
            i: {
                icon: Xe(l == null ? void 0 : l.flag)
            }
        }] : []
    },
    J = a => typeof a == "number" && a < 10,
    xt = a => {
        const e = Xt((a == null ? void 0 : a.flags) || []);
        let l = [];
        return l = [...l, ...e], (J(a == null ? void 0 : a.leaderboardDailyWageredRank) || J(a == null ? void 0 : a.leaderboardDailyProfitRank)) && l.push({
            name: "playerOfTheDay",
            i: {
                icon: "emoji-player-of-the-day"
            }
        }), (J(a == null ? void 0 : a.leaderboardWeeklyWageredRank) || J(a == null ? void 0 : a.leaderboardWeeklyProfitRank)) && l.push({
            name: "playerOfTheWeek",
            i: {
                icon: "emoji-player-of-the-week"
            }
        }), a != null && a.isHighroller && l.push({
            name: "highroller",
            i: {
                icon: "emoji-highroller"
            }
        }), l
    },
    $e = {
        [h.sportsbookFraudForceFlagged]: {
            i: "🙅",
            name: "Sports FF"
        },
        [h.casinoFraudForceFlagged]: {
            i: "🙅‍♂️",
            name: "Casino FF"
        }
    },
    me = [h.root, h.owner, h.whitelisted, h.abuser, h.fiatKycRequired, h.bonusAbuser, h.rainAbuser, ...Object.keys($e)],
    pe = {
        noRole: [...me, h.frozen, h.banned, h.houseExcluded, h.suspended, h.suspendedSanctions, h.suspendedTipping],
        hasRole: me
    },
    _e = {
        [h.root]: "#ff9d02",
        [h.owner]: "#ff9d02",
        [h.admin]: "#ff9d02",
        [h.supportManager]: "#00E449",
        [h.sportsbookManager]: "#00E449",
        [h.communityManager]: "#ff9d02",
        [h.supportSenior]: "#00E449",
        [h.support]: "#00E449",
        [h.vipManager]: "#7f46fd",
        [h.developer]: "#ff9d02",
        [h.moderator]: "#3179F6",
        [h.bot]: "#3179F6",
        [h.whitelisted]: "#3179F6",
        [h.frozen]: "#ff0000",
        [h.banned]: "#ff0000",
        [h.houseExcluded]: "#ff0000",
        [h.suspended]: "#ff0000",
        [h.suspendedLevel1]: "#ff0000",
        [h.suspendedLevel2]: "#ff0000",
        [h.suspendedLevel3]: "#ff0000",
        [h.suspendedSportsbook]: "#ff0000",
        [h.suspendedSanctions]: "#FFA500"
    },
    e1 = a => {
        if (!a) return {
            isBirthday: !1,
            years: null
        };
        const e = new Date,
            l = new Date(a),
            t = e.getFullYear() - l.getFullYear();
        return {
            isBirthday: !!(t && e.getDate() === l.getDate() && e.getMonth() === l.getMonth()),
            years: t
        }
    },
    t1 = ({
        user: a,
        meta: e,
        showIsMe: l
    }) => {
        var z, y, M, Z, V, U;
        const t = (a == null ? void 0 : a.isMuted) || !1,
            n = e.hasRole ? pe.hasRole : pe.noRole,
            i = e.id === (a == null ? void 0 : a.id),
            s = xt(a),
            m = ((a == null ? void 0 : a.roles) || []).some(C => C.name === h.owner),
            {
                isBirthday: r,
                years: o
            } = e1((a == null ? void 0 : a.createdAt) || !1),
            f = ((a == null ? void 0 : a.roles) || []).filter(C => !n.includes(C.name)).map(C => ({
                i: `${C.name[0].toUpperCase()}`,
                name: C.name,
                color: C.name in _e ? _e[C.name] : "inherit"
            })),
            p = ((a == null ? void 0 : a.roles) || []).map(C => $e[C.name]);
        return [...s, l && i && {
            i: "ME",
            name: "Me",
            color: "var(--white)"
        }, m && {
            i: {
                icon: "owner"
            },
            name: a == null ? void 0 : a.name,
            color: "inherit"
        }, r && !Ge && {
            i: {
                icon: "birthday-emoji"
            },
            name: o ? `${Ye(o)} Birthday` : "",
            color: "inherit"
        }, ...p, ...f, t && {
            i: "M",
            name: (y = (z = a == null ? void 0 : a.community) == null ? void 0 : z.muteList) != null && y[0] ? `Reason: "${(Z=(M=a==null?void 0:a.community)==null?void 0:M.muteList)==null?void 0:Z[0].message}" Expires: ${(U=(V=a==null?void 0:a.community)==null?void 0:V.muteList)==null?void 0:U[0].expireAt}` : "Muted",
            color: "inherit"
        }].filter(Boolean)
    };

function he(a, e, l) {
    const t = a.slice();
    return t[9] = e[l], t
}

function l1(a) {
    let e;
    const l = a[8].default,
        t = te(l, a, a[7], null);
    return {
        c() {
            t && t.c()
        },
        l(n) {
            t && t.l(n)
        },
        m(n, i) {
            t && t.m(n, i), e = !0
        },
        p(n, i) {
            t && t.p && (!e || i & 128) && le(t, l, n, n[7], e ? ie(l, n[7], i, null) : ne(n[7]), null)
        },
        i(n) {
            e || (c(t, n), e = !0)
        },
        o(n) {
            u(t, n), e = !1
        },
        d(n) {
            t && t.d(n)
        }
    }
}

function n1(a) {
    let e, l, t, n = re(a[3]),
        i = [];
    for (let o = 0; o < n.length; o += 1) i[o] = de(he(a, n, o));
    const s = o => u(i[o], 1, 1, () => {
            i[o] = null
        }),
        m = a[8].default,
        r = te(m, a, a[7], null);
    return {
        c() {
            e = S("div");
            for (let o = 0; o < i.length; o += 1) i[o].c();
            l = q(), r && r.c(), this.h()
        },
        l(o) {
            e = A(o, "DIV", {
                class: !0
            });
            var f = I(e);
            for (let p = 0; p < i.length; p += 1) i[p].l(f);
            l = G(f), r && r.l(f), f.forEach(d), this.h()
        },
        h() {
            k(e, "class", "user-tags svelte-smmarv"), Y(e, "boxed", a[2] === "boxed")
        },
        m(o, f) {
            F(o, e, f);
            for (let p = 0; p < i.length; p += 1) i[p] && i[p].m(e, null);
            B(e, l), r && r.m(e, null), t = !0
        },
        p(o, f) {
            if (f & 15) {
                n = re(o[3]);
                let p;
                for (p = 0; p < n.length; p += 1) {
                    const _ = he(o, n, p);
                    i[p] ? (i[p].p(_, f), c(i[p], 1)) : (i[p] = de(_), i[p].c(), c(i[p], 1), i[p].m(e, l))
                }
                for (T(), p = n.length; p < i.length; p += 1) s(p);
                N()
            }
            r && r.p && (!t || f & 128) && le(r, m, o, o[7], t ? ie(m, o[7], f, null) : ne(o[7]), null), (!t || f & 4) && Y(e, "boxed", o[2] === "boxed")
        },
        i(o) {
            if (!t) {
                for (let f = 0; f < n.length; f += 1) c(i[f]);
                c(r, o), t = !0
            }
        },
        o(o) {
            i = i.filter(Boolean);
            for (let f = 0; f < i.length; f += 1) u(i[f]);
            u(r, o), t = !1
        },
        d(o) {
            o && d(e), ye(i, o), r && r.d(o)
        }
    }
}

function de(a) {
    let e, l, t;
    return l = new Qt({
        props: {
            tag: a[9],
            user: a[0],
            fontSize: a[1]
        }
    }), {
        c() {
            e = S("span"), g(l.$$.fragment), this.h()
        },
        l(n) {
            e = A(n, "SPAN", {
                class: !0
            });
            var i = I(e);
            $(l.$$.fragment, i), i.forEach(d), this.h()
        },
        h() {
            k(e, "class", "svelte-smmarv"), Y(e, "box", a[2] === "boxed")
        },
        m(n, i) {
            F(n, e, i), v(l, e, null), t = !0
        },
        p(n, i) {
            const s = {};
            i & 8 && (s.tag = n[9]), i & 1 && (s.user = n[0]), i & 2 && (s.fontSize = n[1]), l.$set(s), (!t || i & 4) && Y(e, "box", n[2] === "boxed")
        },
        i(n) {
            t || (c(l.$$.fragment, n), t = !0)
        },
        o(n) {
            u(l.$$.fragment, n), t = !1
        },
        d(n) {
            n && d(e), b(l)
        }
    }
}

function i1(a) {
    let e, l, t, n;
    const i = [n1, l1],
        s = [];

    function m(r, o) {
        return r[3].length !== 0 ? 0 : 1
    }
    return e = m(a), l = s[e] = i[e](a), {
        c() {
            l.c(), t = H()
        },
        l(r) {
            l.l(r), t = H()
        },
        m(r, o) {
            s[e].m(r, o), F(r, t, o), n = !0
        },
        p(r, [o]) {
            let f = e;
            e = m(r), e === f ? s[e].p(r, o) : (T(), u(s[f], 1, 1, () => {
                s[f] = null
            }), N(), l = s[e], l ? l.p(r, o) : (l = s[e] = i[e](r), l.c()), c(l, 1), l.m(t.parentNode, t))
        },
        i(r) {
            n || (c(l), n = !0)
        },
        o(r) {
            u(l), n = !1
        },
        d(r) {
            r && d(t), s[e].d(r)
        }
    }
}

function a1(a, e, l) {
    let t, n, {
            $$slots: i = {},
            $$scope: s
        } = e,
        {
            user: m
        } = e,
        {
            showIsMe: r = !1
        } = e,
        {
            fontSize: o = "default"
        } = e,
        {
            variant: f = void 0
        } = e;
    const {
        meta: p
    } = Fe();
    return ke(a, p, _ => l(6, n = _)), a.$$set = _ => {
        "user" in _ && l(0, m = _.user), "showIsMe" in _ && l(5, r = _.showIsMe), "fontSize" in _ && l(1, o = _.fontSize), "variant" in _ && l(2, f = _.variant), "$$scope" in _ && l(7, s = _.$$scope)
    }, a.$$.update = () => {
        a.$$.dirty & 97 && l(3, t = t1({
            showIsMe: r,
            user: m,
            meta: n
        }).filter(_ => _ && "name" in _ ? _.name !== "betaCrash" : !0))
    }, [m, o, f, t, p, r, n, s, i]
}
class k1 extends L {
    constructor(e) {
        super(), W(this, e, a1, i1, j, {
            user: 0,
            showIsMe: 5,
            fontSize: 1,
            variant: 2
        })
    }
}
export {
    k1 as U
};