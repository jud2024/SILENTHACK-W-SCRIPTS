import {
    w as p
} from "./index.C2-CG2CN.js";
const o = p();
export {
    o as p
};