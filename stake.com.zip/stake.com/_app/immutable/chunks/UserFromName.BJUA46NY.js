import {
    s as _,
    m as c,
    j as p,
    i as b,
    c as F,
    n as S
} from "./scheduler.DXu26z7T.js";
import {
    S as y,
    i as h,
    g as D,
    b as s,
    e as I,
    t as u,
    c as f,
    a as v,
    m as N,
    d as g
} from "./index.Dz_MmNB3.js";
import "./index.B3dW9TVs.js";
import {
    U as T
} from "./index.B1J2NdFH.js";
import {
    P as U
} from "./index.B1KDSkU5.js";
import {
    o as P,
    q as V
} from "./urql-svelte.Jmuk7rkA.js";
const q = {
    kind: "Document",
    definitions: [{
        kind: "OperationDefinition",
        operation: "query",
        name: {
            kind: "Name",
            value: "Tags"
        },
        variableDefinitions: [{
            kind: "VariableDefinition",
            variable: {
                kind: "Variable",
                name: {
                    kind: "Name",
                    value: "userId"
                }
            },
            type: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "String"
                }
            }
        }, {
            kind: "VariableDefinition",
            variable: {
                kind: "Variable",
                name: {
                    kind: "Name",
                    value: "name"
                }
            },
            type: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "String"
                }
            }
        }],
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "user"
                },
                arguments: [{
                    kind: "Argument",
                    name: {
                        kind: "Name",
                        value: "userId"
                    },
                    value: {
                        kind: "Variable",
                        name: {
                            kind: "Name",
                            value: "userId"
                        }
                    }
                }, {
                    kind: "Argument",
                    name: {
                        kind: "Name",
                        value: "name"
                    },
                    value: {
                        kind: "Variable",
                        name: {
                            kind: "Name",
                            value: "name"
                        }
                    }
                }],
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "FragmentSpread",
                        name: {
                            kind: "Name",
                            value: "UserTags"
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "UserTags"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "User"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "name"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "isMuted"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "isRainproof"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "isIgnored"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "isHighroller"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "isSportHighroller"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "leaderboardDailyProfitRank"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "leaderboardDailyWageredRank"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "leaderboardWeeklyProfitRank"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "leaderboardWeeklyWageredRank"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "flags"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "flag"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "rank"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "createdAt"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "roles"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "name"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "expireAt"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "message"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "createdAt"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "preferenceHideBets"
                }
            }]
        }
    }]
};

function w(m) {
    var i, d;
    let e, n;
    return e = new T({
        props: {
            user: ((d = (i = m[2]) == null ? void 0 : i.data) == null ? void 0 : d.user) || null,
            style: m[0],
            variant: m[1],
            showGhostPreference: !0
        }
    }), {
        c() {
            f(e.$$.fragment)
        },
        l(t) {
            v(e.$$.fragment, t)
        },
        m(t, r) {
            N(e, t, r), n = !0
        },
        p(t, r) {
            var a, l;
            const o = {};
            r & 4 && (o.user = ((l = (a = t[2]) == null ? void 0 : a.data) == null ? void 0 : l.user) || null), r & 1 && (o.style = t[0]), r & 2 && (o.variant = t[1]), e.$set(o)
        },
        i(t) {
            n || (u(e.$$.fragment, t), n = !0)
        },
        o(t) {
            s(e.$$.fragment, t), n = !1
        },
        d(t) {
            g(e, t)
        }
    }
}

function A(m) {
    let e, n;
    return e = new U({
        props: {
            width: "6ch"
        }
    }), {
        c() {
            f(e.$$.fragment)
        },
        l(i) {
            v(e.$$.fragment, i)
        },
        m(i, d) {
            N(e, i, d), n = !0
        },
        p: S,
        i(i) {
            n || (u(e.$$.fragment, i), n = !0)
        },
        o(i) {
            s(e.$$.fragment, i), n = !1
        },
        d(i) {
            g(e, i)
        }
    }
}

function R(m) {
    let e, n, i, d;
    const t = [A, w],
        r = [];

    function o(a, l) {
        return a[2].fetching ? 0 : 1
    }
    return e = o(m), n = r[e] = t[e](m), {
        c() {
            n.c(), i = c()
        },
        l(a) {
            n.l(a), i = c()
        },
        m(a, l) {
            r[e].m(a, l), p(a, i, l), d = !0
        },
        p(a, [l]) {
            let k = e;
            e = o(a), e === k ? r[e].p(a, l) : (D(), s(r[k], 1, 1, () => {
                r[k] = null
            }), I(), n = r[e], n ? n.p(a, l) : (n = r[e] = t[e](a), n.c()), u(n, 1), n.m(i.parentNode, i))
        },
        i(a) {
            d || (u(n), d = !0)
        },
        o(a) {
            s(n), d = !1
        },
        d(a) {
            a && b(i), r[e].d(a)
        }
    }
}

function W(m, e, n) {
    let i, {
            name: d = void 0
        } = e,
        {
            userId: t = void 0
        } = e,
        {
            style: r = void 0
        } = e,
        {
            variant: o = "link"
        } = e;
    const a = P(q, {
        name: d,
        userId: t
    }, {
        requestPolicy: "network-only"
    });
    return F(m, a, l => n(2, i = l)), d && V(a), m.$$set = l => {
        "name" in l && n(4, d = l.name), "userId" in l && n(5, t = l.userId), "style" in l && n(0, r = l.style), "variant" in l && n(1, o = l.variant)
    }, [r, o, i, a, d, t]
}
class M extends y {
    constructor(e) {
        super(), h(this, e, W, R, _, {
            name: 4,
            userId: 5,
            style: 0,
            variant: 1
        })
    }
}
export {
    M as U
};