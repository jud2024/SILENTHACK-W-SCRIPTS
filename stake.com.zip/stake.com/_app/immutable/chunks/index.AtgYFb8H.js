import {
    s as K,
    a as Je,
    e as D,
    d as y,
    f as w,
    i as u,
    F as m,
    I as te,
    j as M,
    a3 as xe,
    u as Ge,
    g as Ke,
    b as Qe,
    q as et,
    O as I,
    m as q,
    P,
    c as ee,
    o as tt,
    k as p,
    n as ue,
    t as me,
    h as de,
    V as Pe,
    l as he,
    C as z,
    D as N
} from "./scheduler.DXu26z7T.js";
import {
    S as Q,
    i as U,
    t as v,
    b,
    c as V,
    a as S,
    m as B,
    g as re,
    e as le,
    d as H
} from "./index.Dz_MmNB3.js";
import {
    e as G,
    u as ve,
    o as be
} from "./each.DvgCmocI.js";
import {
    P as rt
} from "./index.BHHo1fl5.js";
import {
    cn as lt,
    bd as st,
    bZ as nt,
    N as it,
    A as at,
    i as Ue,
    h as $e,
    p as ot,
    J as ft
} from "./index.B4-7gKq3.js";
import {
    m as ct,
    d as Ee
} from "./index.lhCIiKC2.js";
import {
    r as ut
} from "./resizeObserver.A9wvMie0.js";
import {
    F as mt,
    M as dt
} from "./messages.CGOEYt_d.js";
import {
    d as ht
} from "./index.C2-CG2CN.js";
import {
    S as pt,
    m as oe,
    B as _t,
    D as $t
} from "./index.CuBfB3P7.js";
import "./index.ByMdEFI5.js";
import {
    P as j
} from "./index.B1KDSkU5.js";
import "./index.B3dW9TVs.js";
import {
    B as gt
} from "./button.BwmFDw8u.js";
import {
    S as vt
} from "./index.DCSb0LMW.js";
import {
    T as bt
} from "./index.D7nbRHfU.js";
import {
    L as kt
} from "./index.DJurAkTj.js";
import {
    p as wt
} from "./paths.RTtAVJV7.js";
import {
    r as Ct
} from "./scrollTopContainer.DLbcGdPu.js";
import {
    c as Et
} from "./createPagination.nV30wPMr.js";
const Lt = o => ({
        sortedList: o & 16,
        colSize: o & 8,
        columns: o & 2
    }),
    Ze = o => ({
        sortedList: o[4],
        colSize: o[3],
        columns: o[1]
    });

function Vt(o) {
    let e, s, t, i, r;
    const a = o[7].default,
        l = Je(a, o, o[6], Ze);
    return {
        c() {
            e = D("div"), l && l.c(), this.h()
        },
        l(n) {
            e = y(n, "DIV", {
                class: !0,
                style: !0
            });
            var f = w(e);
            l && l.l(f), f.forEach(u), this.h()
        },
        h() {
            m(e, "class", "masonry-container svelte-c239xw"), te(e, "display", o[0].length === 1 ? "block" : "flex")
        },
        m(n, f) {
            M(n, e, f), l && l.m(e, null), t = !0, i || (r = xe(s = ut.call(null, e, o[8])), i = !0)
        },
        p(n, [f]) {
            l && l.p && (!t || f & 90) && Ge(l, a, n, n[6], t ? Qe(a, n[6], f, Lt) : Ke(n[6]), Ze), (!t || f & 1) && te(e, "display", n[0].length === 1 ? "block" : "flex"), s && et(s.update) && f & 4 && s.update.call(null, n[8])
        },
        i(n) {
            t || (v(l, n), t = !0)
        },
        o(n) {
            b(l, n), t = !1
        },
        d(n) {
            n && u(e), l && l.d(n), i = !1, r()
        }
    }
}

function St(o, e, s) {
    let t, {
        $$slots: i = {},
        $$scope: r
    } = e;
    const a = (_, c) => c.reduceRight(($, k, E) => k < _ ? $ : E, c.length) + 1;
    let {
        breakPoints: l = []
    } = e, {
        list: n = []
    } = e, f = 1, h = 0, d = 0;
    const g = _ => s(2, h = _.width);
    return o.$$set = _ => {
        "breakPoints" in _ && s(5, l = _.breakPoints), "list" in _ && s(0, n = _.list), "$$scope" in _ && s(6, r = _.$$scope)
    }, o.$$.update = () => {
        o.$$.dirty & 36 && s(1, f = (() => {
            const _ = a(h, l);
            return _ === 0 ? 1 : _
        })()), o.$$.dirty & 6 && s(3, d = h / f), o.$$.dirty & 3 && s(4, t = (() => {
            const _ = f,
                c = [];
            for (let $ = 0; $ < _; $++) c.push([]);
            return n.reduce(($, k, E) => ($[E % _].push(k), $), c)
        })())
    }, [n, f, h, d, t, l, r, i, g]
}
class Xe extends Q {
    constructor(e) {
        super(), U(this, e, St, Vt, K, {
            breakPoints: 5,
            list: 0
        })
    }
}

function Bt(o) {
    let e, s;
    const t = o[2].default,
        i = Je(t, o, o[1], null);
    return {
        c() {
            e = D("div"), i && i.c(), this.h()
        },
        l(r) {
            e = y(r, "DIV", {
                class: !0,
                style: !0
            });
            var a = w(e);
            i && i.l(a), a.forEach(u), this.h()
        },
        h() {
            m(e, "class", "column svelte-13tzx2i"), te(e, "max-width", o[0] + "px"), te(e, "width", "100%")
        },
        m(r, a) {
            M(r, e, a), i && i.m(e, null), s = !0
        },
        p(r, [a]) {
            i && i.p && (!s || a & 2) && Ge(i, t, r, r[1], s ? Qe(t, r[1], a, null) : Ke(r[1]), null), (!s || a & 1) && te(e, "max-width", r[0] + "px")
        },
        i(r) {
            s || (v(i, r), s = !0)
        },
        o(r) {
            b(i, r), s = !1
        },
        d(r) {
            r && u(e), i && i.d(r)
        }
    }
}

function Ht(o, e, s) {
    let {
        $$slots: t = {},
        $$scope: i
    } = e, {
        colSize: r = 0
    } = e;
    return o.$$set = a => {
        "colSize" in a && s(0, r = a.colSize), "$$scope" in a && s(1, i = a.$$scope)
    }, [r, i, t]
}
class Ye extends Q {
    constructor(e) {
        super(), U(this, e, Ht, Bt, K, {
            colSize: 0
        })
    }
}

function ze(o) {
    let e, s;
    return e = new dt({
        props: {
            sport: o[5],
            fixture: o[3],
            removeBackground: !0
        }
    }), {
        c() {
            V(e.$$.fragment)
        },
        l(t) {
            S(e.$$.fragment, t)
        },
        m(t, i) {
            B(e, t, i), s = !0
        },
        p(t, i) {
            const r = {};
            i & 8 && (r.fixture = t[3]), e.$set(r)
        },
        i(t) {
            s || (v(e.$$.fragment, t), s = !0)
        },
        o(t) {
            b(e.$$.fragment, t), s = !1
        },
        d(t) {
            H(e, t)
        }
    }
}

function Dt(o) {
    var a;
    let e, s, t, i;
    e = new pt({
        props: {
            bet: o[1],
            iid: o[2],
            displayMatchStatisticsButton: !0
        }
    }), e.$on("cashout", o[7]);
    let r = o[4] && ((a = o[1]) == null ? void 0 : a.outcomes.length) === 1 && ze(o);
    return {
        c() {
            V(e.$$.fragment), s = I(), r && r.c(), t = q()
        },
        l(l) {
            S(e.$$.fragment, l), s = P(l), r && r.l(l), t = q()
        },
        m(l, n) {
            B(e, l, n), M(l, s, n), r && r.m(l, n), M(l, t, n), i = !0
        },
        p(l, [n]) {
            var h;
            const f = {};
            n & 2 && (f.bet = l[1]), n & 4 && (f.iid = l[2]), e.$set(f), l[4] && ((h = l[1]) == null ? void 0 : h.outcomes.length) === 1 ? r ? (r.p(l, n), n & 18 && v(r, 1)) : (r = ze(l), r.c(), v(r, 1), r.m(t.parentNode, t)) : r && (re(), b(r, 1, 1, () => {
                r = null
            }), le())
        },
        i(l) {
            i || (v(e.$$.fragment, l), v(r), i = !0)
        },
        o(l) {
            b(e.$$.fragment, l), b(r), i = !1
        },
        d(l) {
            l && (u(s), u(t)), H(e, l), r && r.d(l)
        }
    }
}

function yt(o, e, s) {
    var g, _, c, $, k;
    let t, {
            removeBetFromList: i
        } = e,
        {
            bet: r
        } = e,
        {
            iid: a
        } = e,
        l = (c = (_ = (g = r == null ? void 0 : r.outcomes) == null ? void 0 : g[0]) == null ? void 0 : _.fixture) == null ? void 0 : c.tournament.category.sport.slug,
        n = (k = ($ = r == null ? void 0 : r.outcomes) == null ? void 0 : $[0]) == null ? void 0 : k.fixture,
        f = n ? ? void 0,
        h = ht(ct, E => E.some(C => (C == null ? void 0 : C.fixtureId) === (n == null ? void 0 : n.id) && (C == null ? void 0 : C.betId) === (r == null ? void 0 : r.id)));
    ee(o, h, E => s(4, t = E)), tt(() => {
        if (n && n.status !== lt.ended) {
            const E = at();
            let C = st(E.subscription(mt, {
                fixtureId: n == null ? void 0 : n.id,
                provider: (n == null ? void 0 : n.provider) ? ? nt.betradar
            }), it(({
                data: F
            }) => {
                let A = F == null ? void 0 : F.sportFixture;
                A && s(3, f = { ...f,
                    ...A
                })
            }));
            return () => {
                C.unsubscribe()
            }
        }
    });
    const d = () => {
        i && i(r.id)
    };
    return o.$$set = E => {
        "removeBetFromList" in E && s(0, i = E.removeBetFromList), "bet" in E && s(1, r = E.bet), "iid" in E && s(2, a = E.iid)
    }, [i, r, a, f, t, l, h, d]
}
class We extends Q {
    constructor(e) {
        super(), U(this, e, yt, Dt, K, {
            removeBetFromList: 0,
            bet: 1,
            iid: 2
        })
    }
}

function Mt(o) {
    let e, s, t, i, r, a, l, n, f, h, d, g, _;
    return t = new j({
        props: {
            width: "18ch",
            height: "1em"
        }
    }), r = new j({
        props: {
            width: "12ch",
            height: "1em"
        }
    }), n = new j({
        props: {
            width: "14ch",
            height: "1em"
        }
    }), h = new j({
        props: {
            width: "4ch",
            height: "1em"
        }
    }), g = new j({
        props: {
            width: "6ch",
            height: "1em"
        }
    }), {
        c() {
            e = D("div"), s = D("div"), V(t.$$.fragment), i = I(), V(r.$$.fragment), a = I(), l = D("div"), V(n.$$.fragment), f = I(), V(h.$$.fragment), d = I(), V(g.$$.fragment), this.h()
        },
        l(c) {
            e = y(c, "DIV", {
                class: !0
            });
            var $ = w(e);
            s = y($, "DIV", {
                class: !0
            });
            var k = w(s);
            S(t.$$.fragment, k), i = P(k), S(r.$$.fragment, k), k.forEach(u), a = P($), l = y($, "DIV", {
                class: !0
            });
            var E = w(l);
            S(n.$$.fragment, E), f = P(E), S(h.$$.fragment, E), E.forEach(u), d = P($), S(g.$$.fragment, $), $.forEach(u), this.h()
        },
        h() {
            m(s, "class", "title-wrapper svelte-vxlfor"), m(l, "class", "odds-wrapper svelte-vxlfor"), m(e, "class", "overview svelte-vxlfor")
        },
        m(c, $) {
            M(c, e, $), p(e, s), B(t, s, null), p(s, i), B(r, s, null), p(e, a), p(e, l), B(n, l, null), p(l, f), B(h, l, null), p(e, d), B(g, e, null), _ = !0
        },
        p: ue,
        i(c) {
            _ || (v(t.$$.fragment, c), v(r.$$.fragment, c), v(n.$$.fragment, c), v(h.$$.fragment, c), v(g.$$.fragment, c), _ = !0)
        },
        o(c) {
            b(t.$$.fragment, c), b(r.$$.fragment, c), b(n.$$.fragment, c), b(h.$$.fragment, c), b(g.$$.fragment, c), _ = !1
        },
        d(c) {
            c && u(e), H(t), H(r), H(n), H(h), H(g)
        }
    }
}
class It extends Q {
    constructor(e) {
        super(), U(this, e, null, Mt, K, {})
    }
}

function Pt(o) {
    let e, s;
    return e = new $t({}), {
        c() {
            V(e.$$.fragment)
        },
        l(t) {
            S(e.$$.fragment, t)
        },
        m(t, i) {
            B(e, t, i), s = !0
        },
        i(t) {
            s || (v(e.$$.fragment, t), s = !0)
        },
        o(t) {
            b(e.$$.fragment, t), s = !1
        },
        d(t) {
            H(e, t)
        }
    }
}

function Zt(o) {
    let e, s, t, i, r, a, l, n, f, h, d, g, _, c, $, k, E = o[2]._(oe.stake) + "",
        C, F, A, O, se, T, fe = o[2]._(oe.payout) + "",
        pe, ke, ne, X, we, ie, ce = o[2]._(oe.odds) + "",
        _e, Ce, ae, Y, J;
    return r = new j({
        props: {
            width: "15ch"
        }
    }), l = new gt({
        props: {
            variant: "subtle-link",
            disabled: !0,
            $$slots: {
                default: [Pt]
            },
            $$scope: {
                ctx: o
            }
        }
    }), g = new It({}), c = new _t({
        props: {
            variant: o[1]
        }
    }), O = new j({
        props: {
            width: "10ch",
            style: "margin-bottom: var(--space-1);"
        }
    }), X = new j({
        props: {
            width: "10ch",
            style: "margin-bottom: var(--space-1);"
        }
    }), Y = new j({
        props: {
            width: "4ch",
            height: "1em",
            style: "margin-bottom: var(--space-1);"
        }
    }), {
        c() {
            e = D("div"), s = D("div"), t = D("div"), i = D("div"), V(r.$$.fragment), a = I(), V(l.$$.fragment), n = I(), f = D("div"), h = D("div"), d = D("div"), V(g.$$.fragment), _ = I(), V(c.$$.fragment), $ = I(), k = D("span"), C = me(E), F = I(), A = D("div"), V(O.$$.fragment), se = I(), T = D("span"), pe = me(fe), ke = I(), ne = D("span"), V(X.$$.fragment), we = I(), ie = D("div"), _e = me(ce), Ce = I(), ae = D("div"), V(Y.$$.fragment), this.h()
        },
        l(L) {
            e = y(L, "DIV", {
                class: !0
            });
            var R = w(e);
            s = y(R, "DIV", {
                class: !0
            });
            var W = w(s);
            t = y(W, "DIV", {
                class: !0
            });
            var x = w(t);
            i = y(x, "DIV", {
                class: !0
            });
            var Le = w(i);
            S(r.$$.fragment, Le), Le.forEach(u), a = P(x), S(l.$$.fragment, x), x.forEach(u), n = P(W), f = y(W, "DIV", {
                class: !0
            });
            var Z = w(f);
            h = y(Z, "DIV", {
                class: !0
            });
            var Ve = w(h);
            d = y(Ve, "DIV", {
                class: !0
            });
            var Se = w(d);
            S(g.$$.fragment, Se), Se.forEach(u), Ve.forEach(u), _ = P(Z), S(c.$$.fragment, Z), $ = P(Z), k = y(Z, "SPAN", {
                class: !0
            });
            var Be = w(k);
            C = de(Be, E), Be.forEach(u), F = P(Z), A = y(Z, "DIV", {
                class: !0
            });
            var He = w(A);
            S(O.$$.fragment, He), He.forEach(u), se = P(Z), T = y(Z, "SPAN", {
                class: !0
            });
            var De = w(T);
            pe = de(De, fe), De.forEach(u), ke = P(Z), ne = y(Z, "SPAN", {
                class: !0
            });
            var ye = w(ne);
            S(X.$$.fragment, ye), ye.forEach(u), we = P(Z), ie = y(Z, "DIV", {
                class: !0
            });
            var Me = w(ie);
            _e = de(Me, ce), Me.forEach(u), Ce = P(Z), ae = y(Z, "DIV", {
                class: !0
            });
            var Ie = w(ae);
            S(Y.$$.fragment, Ie), Ie.forEach(u), Z.forEach(u), W.forEach(u), R.forEach(u), this.h()
        },
        h() {
            m(i, "class", "date-time svelte-ed9n5k"), m(t, "class", "header svelte-ed9n5k"), m(d, "class", "ticket svelte-ed9n5k"), m(h, "class", "bet-outcome-list svelte-ed9n5k"), m(k, "class", "total-stake-label svelte-ed9n5k"), m(A, "class", "total-stake svelte-ed9n5k"), m(T, "class", "payout-label svelte-ed9n5k"), m(ne, "class", "payout svelte-ed9n5k"), m(ie, "class", "total-odds-label svelte-ed9n5k"), m(ae, "class", "total-odds svelte-ed9n5k"), m(f, "class", "content svelte-ed9n5k"), Pe(f, "stacked", o[0]), m(s, "class", "record svelte-ed9n5k"), m(e, "class", "sport-bet-preview svelte-ed9n5k")
        },
        m(L, R) {
            M(L, e, R), p(e, s), p(s, t), p(t, i), B(r, i, null), p(t, a), B(l, t, null), p(s, n), p(s, f), p(f, h), p(h, d), B(g, d, null), p(f, _), B(c, f, null), p(f, $), p(f, k), p(k, C), p(f, F), p(f, A), B(O, A, null), p(f, se), p(f, T), p(T, pe), p(f, ke), p(f, ne), B(X, ne, null), p(f, we), p(f, ie), p(ie, _e), p(f, Ce), p(f, ae), B(Y, ae, null), J = !0
        },
        p(L, [R]) {
            const W = {};
            R & 8 && (W.$$scope = {
                dirty: R,
                ctx: L
            }), l.$set(W);
            const x = {};
            R & 2 && (x.variant = L[1]), c.$set(x), (!J || R & 4) && E !== (E = L[2]._(oe.stake) + "") && he(C, E), (!J || R & 4) && fe !== (fe = L[2]._(oe.payout) + "") && he(pe, fe), (!J || R & 4) && ce !== (ce = L[2]._(oe.odds) + "") && he(_e, ce), (!J || R & 1) && Pe(f, "stacked", L[0])
        },
        i(L) {
            J || (v(r.$$.fragment, L), v(l.$$.fragment, L), v(g.$$.fragment, L), v(c.$$.fragment, L), v(O.$$.fragment, L), v(X.$$.fragment, L), v(Y.$$.fragment, L), J = !0)
        },
        o(L) {
            b(r.$$.fragment, L), b(l.$$.fragment, L), b(g.$$.fragment, L), b(c.$$.fragment, L), b(O.$$.fragment, L), b(X.$$.fragment, L), b(Y.$$.fragment, L), J = !1
        },
        d(L) {
            L && u(e), H(r), H(l), H(g), H(c), H(O), H(X), H(Y)
        }
    }
}

function zt(o, e, s) {
    let t;
    ee(o, Ue, a => s(2, t = a));
    let {
        stacked: i = !0
    } = e, {
        logoVariant: r = "light"
    } = e;
    return o.$$set = a => {
        "stacked" in a && s(0, i = a.stacked), "logoVariant" in a && s(1, r = a.logoVariant)
    }, [i, r, t]
}
class Nt extends Q {
    constructor(e) {
        super(), U(this, e, zt, Zt, K, {
            stacked: 0,
            logoVariant: 1
        })
    }
}

function At(o) {
    let e, s, t, i, r, a, l, n, f, h, d, g, _, c, $, k;
    return {
        c() {
            e = z("svg"), s = z("path"), t = z("path"), i = z("path"), r = z("path"), a = z("path"), l = z("path"), n = z("path"), f = z("path"), h = z("path"), d = z("path"), g = z("path"), _ = z("path"), c = z("path"), $ = z("path"), k = z("path"), this.h()
        },
        l(E) {
            e = N(E, "svg", {
                width: !0,
                height: !0,
                viewBox: !0,
                fill: !0,
                xmlns: !0
            });
            var C = w(e);
            s = N(C, "path", {
                d: !0,
                fill: !0
            }), w(s).forEach(u), t = N(C, "path", {
                d: !0,
                fill: !0
            }), w(t).forEach(u), i = N(C, "path", {
                d: !0,
                fill: !0
            }), w(i).forEach(u), r = N(C, "path", {
                d: !0,
                fill: !0
            }), w(r).forEach(u), a = N(C, "path", {
                d: !0,
                fill: !0
            }), w(a).forEach(u), l = N(C, "path", {
                d: !0,
                fill: !0
            }), w(l).forEach(u), n = N(C, "path", {
                d: !0,
                fill: !0
            }), w(n).forEach(u), f = N(C, "path", {
                d: !0,
                fill: !0
            }), w(f).forEach(u), h = N(C, "path", {
                d: !0,
                fill: !0
            }), w(h).forEach(u), d = N(C, "path", {
                d: !0,
                fill: !0
            }), w(d).forEach(u), g = N(C, "path", {
                d: !0,
                fill: !0
            }), w(g).forEach(u), _ = N(C, "path", {
                d: !0,
                fill: !0
            }), w(_).forEach(u), c = N(C, "path", {
                d: !0,
                fill: !0
            }), w(c).forEach(u), $ = N(C, "path", {
                d: !0,
                fill: !0
            }), w($).forEach(u), k = N(C, "path", {
                d: !0,
                fill: !0
            }), w(k).forEach(u), C.forEach(u), this.h()
        },
        h() {
            m(s, "d", "M23.7401 25.1095H16.4071V21.6539C16.4071 20.4152 23.7401 20.4152 23.7401 21.6539V25.1095Z"), m(s, "fill", "#69E244"), m(t, "d", "M63.8036 24.3578H16.1963C12.0405 24.3578 8.67151 27.7259 8.67151 31.8807C8.67151 36.0355 12.0405 39.4036 16.1963 39.4036H63.8036C67.9594 39.4036 71.3284 36.0355 71.3284 31.8807C71.3284 27.7259 67.9594 24.3578 63.8036 24.3578Z"), m(t, "fill", "#263742"), m(i, "d", "M63.8419 29.4741H16.1617C14.8315 29.4741 13.7532 30.5515 13.7532 31.8807C13.7532 33.2098 14.8315 34.2873 16.1617 34.2873H63.8419C65.1721 34.2873 66.2504 33.2098 66.2504 31.8807C66.2504 30.5515 65.1721 29.4741 63.8419 29.4741Z"), m(i, "fill", "#0C1D29"), m(r, "d", "M63.5963 77.4917V31.5643H16.4071V77.4917C17.7916 77.4917 18.9154 78.6155 18.9154 80H23.3374C23.3374 78.6155 24.4612 77.4917 25.8457 77.4917C27.2302 77.4917 28.354 78.6155 28.354 80H32.7761C32.7761 78.6155 33.8998 77.4917 35.2843 77.4917C36.6689 77.4917 37.7926 78.6155 37.7926 80H42.2147C42.2147 78.6155 43.3384 77.4917 44.7229 77.4917C46.1075 77.4917 47.2312 78.6155 47.2312 80H51.6533C51.6533 78.6155 52.777 77.4917 54.1615 77.4917C55.5461 77.4917 56.6698 78.6155 56.6698 80H61.0919C61.0919 78.6155 62.2156 77.4917 63.6002 77.4917H63.5963Z"), m(r, "fill", "#334552"), m(a, "d", "M32.2509 24.354C38.976 24.354 44.4278 18.9022 44.4278 12.177C44.4278 5.45183 38.976 0 32.2509 0C25.5257 0 20.0739 5.45183 20.0739 12.177C20.0739 18.9022 25.5257 24.354 32.2509 24.354Z"), m(a, "fill", "#263742"), m(l, "d", "M23.8704 3.34824C22.8233 4.34157 21.9489 5.52284 21.3046 6.84984L24.2999 4.61388L23.8704 3.34824Z"), m(l, "fill", "#3C8725"), m(n, "d", "M29.3356 8.18066L27.6135 13.7111L32.3463 17.0593L36.9908 13.5961L35.1307 8.10779L29.3356 8.18066Z"), m(n, "fill", "#0C1D29"), m(f, "d", "M43.369 17.1437L42.0266 17.159L40.9182 20.722C41.9307 19.698 42.7668 18.4937 43.369 17.1437Z"), m(f, "fill", "#0C1D29"), m(h, "d", "M41.9882 10.8807L44.3507 10.85C44.0861 8.41461 43.0889 6.15179 41.5548 4.3262L40.1281 5.38857L41.9882 10.8769V10.8807Z"), m(h, "fill", "#0C1D29"), m(d, "d", "M35.0924 1.82945L35.5219 0.452581C35.1 0.333688 34.6705 0.237806 34.2256 0.164936C32.3578 -0.141886 30.5207 -0.0076516 28.8179 0.494769L29.2934 1.90232L35.0885 1.82945H35.0924Z"), m(d, "fill", "#0C1D29"), m(g, "d", "M21.8223 13.4541L20.1425 13.4733C20.3879 15.7745 21.2854 17.9222 22.6737 19.6941L23.6824 18.9424L21.8223 13.4541Z"), m(g, "fill", "#3C8725"), m(_, "d", "M28.7218 22.5092L28.3459 23.7097C28.9634 23.9168 29.6078 24.0817 30.2751 24.1929C31.9166 24.4614 33.5312 24.3885 35.0538 24.028L34.5131 22.4364L28.718 22.5092H28.7218Z"), m(_, "fill", "#3C8725"), m(c, "d", "M54.1156 18.9041C54.1156 20.4305 53.4904 21.8074 52.4818 22.793C52.2401 23.0346 51.9755 23.2494 51.6917 23.4374C50.8249 24.0165 49.7856 24.354 48.6657 24.354C46.8784 24.354 45.2906 23.4949 44.3011 22.1679C44.1401 21.9569 43.9981 21.7383 43.8754 21.5082C43.4497 20.7335 43.2119 19.8475 43.2119 18.9041C43.2119 17.9606 43.4497 17.0746 43.8754 16.2999C43.9981 16.0698 44.1401 15.8512 44.3011 15.6402C45.2906 14.3132 46.8784 13.4541 48.6657 13.4541C49.7856 13.4541 50.8249 13.7916 51.6917 14.3708C51.9755 14.5587 52.2401 14.7735 52.4818 15.0151C53.4904 16.0008 54.1156 17.3776 54.1156 18.9041Z"), m(c, "fill", "#334552"), m($, "d", "M49.3791 20.7258H49.5248V19.9588H49.0761C49.0147 19.7401 48.9687 19.5177 48.9457 19.2876H49.3676V18.5205H48.9457C48.9687 18.2904 49.0147 18.068 49.0761 17.8494H49.5248V17.0823H49.3791C49.9812 15.9432 51.1356 15.134 52.4818 15.0151C52.2402 14.7735 51.9755 14.5587 51.6917 14.3708C50.265 14.7313 49.0952 15.7476 48.5276 17.0823H47.8795V17.8494H48.2822C48.2323 18.068 48.1978 18.2904 48.1786 18.5205H47.7184V19.2876H48.1786C48.1978 19.5177 48.2323 19.7401 48.2822 19.9588H47.8795V20.7258H48.5276C49.0952 22.0605 50.265 23.0768 51.6917 23.4373C51.9755 23.2494 52.2402 23.0346 52.4818 22.793C51.1356 22.6741 49.9812 21.8649 49.3791 20.7258Z"), m($, "fill", "#263742"), m(k, "d", "M46.0078 19.2876V18.5206H45.6204C45.6012 18.2904 45.5629 18.068 45.513 17.8494H45.8467V17.0823H45.2676C45.0374 16.5415 44.7076 16.0506 44.3011 15.6403C44.14 15.8512 43.9981 16.0698 43.8754 16.2999C44.0863 16.5339 44.2704 16.7985 44.42 17.0823H44.2014V17.8494H44.723C44.7843 18.068 44.8303 18.2904 44.8534 18.5206H44.3624V19.2876H44.8534C44.8303 19.5177 44.7843 19.7402 44.723 19.9588H44.2014V20.7258H44.42C44.2704 21.0096 44.0863 21.2743 43.8754 21.5082C43.9981 21.7383 44.14 21.957 44.3011 22.1679C44.7076 21.7575 45.0374 21.2666 45.2676 20.7258H45.8467V19.9588H45.513C45.5629 19.7402 45.6012 19.5177 45.6204 19.2876H46.0078Z"), m(k, "fill", "#263742"), m(e, "width", "80"), m(e, "height", "80"), m(e, "viewBox", "0 0 80 80"), m(e, "fill", "none"), m(e, "xmlns", "http://www.w3.org/2000/svg")
        },
        m(E, C) {
            M(E, e, C), p(e, s), p(e, t), p(e, i), p(e, r), p(e, a), p(e, l), p(e, n), p(e, f), p(e, h), p(e, d), p(e, g), p(e, _), p(e, c), p(e, $), p(e, k)
        },
        p: ue,
        i: ue,
        o: ue,
        d(E) {
            E && u(e)
        }
    }
}
class Ft extends Q {
    constructor(e) {
        super(), U(this, e, null, At, K, {})
    }
}
const ge = {
    betslip: $e._("Bet Slip is Empty"),
    active: $e._("No Active Bets"),
    settled: $e._("No Settled Bets"),
    cta: $e._("Start Betting Now!")
};

function Ot(o) {
    let e = o[1]._(ge[o[0]]) + "",
        s;
    return {
        c() {
            s = me(e)
        },
        l(t) {
            s = de(t, e)
        },
        m(t, i) {
            M(t, s, i)
        },
        p(t, i) {
            i & 3 && e !== (e = t[1]._(ge[t[0]]) + "") && he(s, e)
        },
        d(t) {
            t && u(s)
        }
    }
}

function Rt(o) {
    let e = o[1]._(ge.cta) + "",
        s;
    return {
        c() {
            s = me(e)
        },
        l(t) {
            s = de(t, e)
        },
        m(t, i) {
            M(t, s, i)
        },
        p(t, i) {
            i & 2 && e !== (e = t[1]._(ge.cta) + "") && he(s, e)
        },
        d(t) {
            t && u(s)
        }
    }
}

function qt(o) {
    let e, s, t, i;
    return e = new bt({
        props: {
            variant: "subtle",
            $$slots: {
                default: [Ot]
            },
            $$scope: {
                ctx: o
            }
        }
    }), t = new kt({
        props: {
            to: wt.sportRoot,
            $$slots: {
                default: [Rt]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            V(e.$$.fragment), s = I(), V(t.$$.fragment)
        },
        l(r) {
            S(e.$$.fragment, r), s = P(r), S(t.$$.fragment, r)
        },
        m(r, a) {
            B(e, r, a), M(r, s, a), B(t, r, a), i = !0
        },
        p(r, a) {
            const l = {};
            a & 7 && (l.$$scope = {
                dirty: a,
                ctx: r
            }), e.$set(l);
            const n = {};
            a & 6 && (n.$$scope = {
                dirty: a,
                ctx: r
            }), t.$set(n)
        },
        i(r) {
            i || (v(e.$$.fragment, r), v(t.$$.fragment, r), i = !0)
        },
        o(r) {
            b(e.$$.fragment, r), b(t.$$.fragment, r), i = !1
        },
        d(r) {
            r && u(s), H(e, r), H(t, r)
        }
    }
}

function Tt(o) {
    let e, s;
    return e = new Ft({}), {
        c() {
            V(e.$$.fragment)
        },
        l(t) {
            S(e.$$.fragment, t)
        },
        m(t, i) {
            B(e, t, i), s = !0
        },
        i(t) {
            s || (v(e.$$.fragment, t), s = !0)
        },
        o(t) {
            b(e.$$.fragment, t), s = !1
        },
        d(t) {
            H(e, t)
        }
    }
}

function jt(o) {
    let e, s;
    return e = new vt({
        props: {
            $$slots: {
                icon: [Tt],
                default: [qt]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            V(e.$$.fragment)
        },
        l(t) {
            S(e.$$.fragment, t)
        },
        m(t, i) {
            B(e, t, i), s = !0
        },
        p(t, [i]) {
            const r = {};
            i & 7 && (r.$$scope = {
                dirty: i,
                ctx: t
            }), e.$set(r)
        },
        i(t) {
            s || (v(e.$$.fragment, t), s = !0)
        },
        o(t) {
            b(e.$$.fragment, t), s = !1
        },
        d(t) {
            H(e, t)
        }
    }
}

function Jt(o, e, s) {
    let t;
    ee(o, Ue, r => s(1, t = r));
    let {
        mode: i = "betslip"
    } = e;
    return o.$$set = r => {
        "mode" in r && s(0, i = r.mode)
    }, [i, t]
}
class Gt extends Q {
    constructor(e) {
        super(), U(this, e, Jt, jt, K, {
            mode: 0
        })
    }
}

function Ne(o, e, s) {
    const t = o.slice();
    return t[13] = e[s], t[15] = s, t
}

function Ae(o, e, s) {
    const t = o.slice();
    return t[16] = e[s], t
}

function Fe(o, e, s) {
    const t = o.slice();
    return t[13] = e[s], t[15] = s, t
}

function Oe(o, e, s) {
    const t = o.slice();
    return t[16] = e[s], t
}

function Kt(o) {
    let e, s;
    return e = new Xe({
        props: {
            breakPoints: [650, 1e3],
            list: o[1],
            $$slots: {
                default: [xt, ({
                    sortedList: t,
                    colSize: i,
                    columns: r
                }) => ({
                    11: t,
                    12: i,
                    19: r
                }), ({
                    sortedList: t,
                    colSize: i,
                    columns: r
                }) => (t ? 2048 : 0) | (i ? 4096 : 0) | (r ? 524288 : 0)]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            V(e.$$.fragment)
        },
        l(t) {
            S(e.$$.fragment, t)
        },
        m(t, i) {
            B(e, t, i), s = !0
        },
        p(t, i) {
            const r = {};
            i & 2 && (r.list = t[1]), i & 8919042 && (r.$$scope = {
                dirty: i,
                ctx: t
            }), e.$set(r)
        },
        i(t) {
            s || (v(e.$$.fragment, t), s = !0)
        },
        o(t) {
            b(e.$$.fragment, t), s = !1
        },
        d(t) {
            H(e, t)
        }
    }
}

function Qt(o) {
    let e, s;
    return e = new Gt({
        props: {
            mode: "active"
        }
    }), {
        c() {
            V(e.$$.fragment)
        },
        l(t) {
            S(e.$$.fragment, t)
        },
        m(t, i) {
            B(e, t, i), s = !0
        },
        p: ue,
        i(t) {
            s || (v(e.$$.fragment, t), s = !0)
        },
        o(t) {
            b(e.$$.fragment, t), s = !1
        },
        d(t) {
            H(e, t)
        }
    }
}

function Ut(o) {
    let e, s;
    return e = new Xe({
        props: {
            breakPoints: [650, 1e3],
            list: o[6],
            $$slots: {
                default: [tr, ({
                    sortedList: t,
                    colSize: i
                }) => ({
                    11: t,
                    12: i
                }), ({
                    sortedList: t,
                    colSize: i
                }) => (t ? 2048 : 0) | (i ? 4096 : 0)]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            V(e.$$.fragment)
        },
        l(t) {
            S(e.$$.fragment, t)
        },
        m(t, i) {
            B(e, t, i), s = !0
        },
        p(t, i) {
            const r = {};
            i & 8394752 && (r.$$scope = {
                dirty: i,
                ctx: t
            }), e.$set(r)
        },
        i(t) {
            s || (v(e.$$.fragment, t), s = !0)
        },
        o(t) {
            b(e.$$.fragment, t), s = !1
        },
        d(t) {
            H(e, t)
        }
    }
}

function Xt(o) {
    let e = [],
        s = new Map,
        t, i, r = G(o[11]);
    const a = l => `col_${l[15]}`;
    for (let l = 0; l < r.length; l += 1) {
        let n = Ne(o, r, l),
            f = a(n);
        s.set(f, e[l] = qe(f, n))
    }
    return {
        c() {
            for (let l = 0; l < e.length; l += 1) e[l].c();
            t = q()
        },
        l(l) {
            for (let n = 0; n < e.length; n += 1) e[n].l(l);
            t = q()
        },
        m(l, n) {
            for (let f = 0; f < e.length; f += 1) e[f] && e[f].m(l, n);
            M(l, t, n), i = !0
        },
        p(l, n) {
            n & 6176 && (r = G(l[11]), re(), e = ve(e, n, a, 1, l, r, s, t.parentNode, be, qe, t, Ne), le())
        },
        i(l) {
            if (!i) {
                for (let n = 0; n < r.length; n += 1) v(e[n]);
                i = !0
            }
        },
        o(l) {
            for (let n = 0; n < e.length; n += 1) b(e[n]);
            i = !1
        },
        d(l) {
            l && u(t);
            for (let n = 0; n < e.length; n += 1) e[n].d(l)
        }
    }
}

function Yt(o) {
    var i, r;
    let e, s, t;
    return s = new We({
        props: {
            removeBetFromList: o[5],
            bet: o[1][0],
            iid: (r = (i = o[1][0]) == null ? void 0 : i.bet) == null ? void 0 : r.iid
        }
    }), {
        c() {
            e = D("div"), V(s.$$.fragment), this.h()
        },
        l(a) {
            e = y(a, "DIV", {
                style: !0
            });
            var l = w(e);
            S(s.$$.fragment, l), l.forEach(u), this.h()
        },
        h() {
            te(e, "width", o[19] === 1 ? "100%" : "50%")
        },
        m(a, l) {
            M(a, e, l), B(s, e, null), t = !0
        },
        p(a, l) {
            var f, h;
            const n = {};
            l & 2 && (n.bet = a[1][0]), l & 2 && (n.iid = (h = (f = a[1][0]) == null ? void 0 : f.bet) == null ? void 0 : h.iid), s.$set(n), (!t || l & 524288) && te(e, "width", a[19] === 1 ? "100%" : "50%")
        },
        i(a) {
            t || (v(s.$$.fragment, a), t = !0)
        },
        o(a) {
            b(s.$$.fragment, a), t = !1
        },
        d(a) {
            a && u(e), H(s)
        }
    }
}

function Re(o, e) {
    var r, a;
    let s, t, i;
    return t = new We({
        props: {
            removeBetFromList: e[5],
            bet: e[16],
            iid: (a = (r = e[16]) == null ? void 0 : r.bet) == null ? void 0 : a.iid
        }
    }), {
        key: o,
        first: null,
        c() {
            s = D("div"), V(t.$$.fragment), this.h()
        },
        l(l) {
            s = y(l, "DIV", {});
            var n = w(s);
            S(t.$$.fragment, n), n.forEach(u), this.h()
        },
        h() {
            this.first = s
        },
        m(l, n) {
            M(l, s, n), B(t, s, null), i = !0
        },
        p(l, n) {
            var h, d;
            e = l;
            const f = {};
            n & 2048 && (f.bet = e[16]), n & 2048 && (f.iid = (d = (h = e[16]) == null ? void 0 : h.bet) == null ? void 0 : d.iid), t.$set(f)
        },
        i(l) {
            i || (v(t.$$.fragment, l), i = !0)
        },
        o(l) {
            b(t.$$.fragment, l), i = !1
        },
        d(l) {
            l && u(s), H(t)
        }
    }
}

function Wt(o) {
    let e = [],
        s = new Map,
        t, i, r = G(o[13]);
    const a = l => l[16].id;
    for (let l = 0; l < r.length; l += 1) {
        let n = Ae(o, r, l),
            f = a(n);
        s.set(f, e[l] = Re(f, n))
    }
    return {
        c() {
            for (let l = 0; l < e.length; l += 1) e[l].c();
            t = I()
        },
        l(l) {
            for (let n = 0; n < e.length; n += 1) e[n].l(l);
            t = P(l)
        },
        m(l, n) {
            for (let f = 0; f < e.length; f += 1) e[f] && e[f].m(l, n);
            M(l, t, n), i = !0
        },
        p(l, n) {
            n & 2080 && (r = G(l[13]), re(), e = ve(e, n, a, 1, l, r, s, t.parentNode, be, Re, t, Ae), le())
        },
        i(l) {
            if (!i) {
                for (let n = 0; n < r.length; n += 1) v(e[n]);
                i = !0
            }
        },
        o(l) {
            for (let n = 0; n < e.length; n += 1) b(e[n]);
            i = !1
        },
        d(l) {
            l && u(t);
            for (let n = 0; n < e.length; n += 1) e[n].d(l)
        }
    }
}

function qe(o, e) {
    let s, t, i;
    return t = new Ye({
        props: {
            colSize: e[12],
            $$slots: {
                default: [Wt]
            },
            $$scope: {
                ctx: e
            }
        }
    }), {
        key: o,
        first: null,
        c() {
            s = q(), V(t.$$.fragment), this.h()
        },
        l(r) {
            s = q(), S(t.$$.fragment, r), this.h()
        },
        h() {
            this.first = s
        },
        m(r, a) {
            M(r, s, a), B(t, r, a), i = !0
        },
        p(r, a) {
            e = r;
            const l = {};
            a & 4096 && (l.colSize = e[12]), a & 8390656 && (l.$$scope = {
                dirty: a,
                ctx: e
            }), t.$set(l)
        },
        i(r) {
            i || (v(t.$$.fragment, r), i = !0)
        },
        o(r) {
            b(t.$$.fragment, r), i = !1
        },
        d(r) {
            r && u(s), H(t, r)
        }
    }
}

function xt(o) {
    let e, s, t, i;
    const r = [Yt, Xt],
        a = [];

    function l(n, f) {
        return n[1].length === 1 ? 0 : 1
    }
    return e = l(o), s = a[e] = r[e](o), {
        c() {
            s.c(), t = q()
        },
        l(n) {
            s.l(n), t = q()
        },
        m(n, f) {
            a[e].m(n, f), M(n, t, f), i = !0
        },
        p(n, f) {
            let h = e;
            e = l(n), e === h ? a[e].p(n, f) : (re(), b(a[h], 1, 1, () => {
                a[h] = null
            }), le(), s = a[e], s ? s.p(n, f) : (s = a[e] = r[e](n), s.c()), v(s, 1), s.m(t.parentNode, t))
        },
        i(n) {
            i || (v(s), i = !0)
        },
        o(n) {
            b(s), i = !1
        },
        d(n) {
            n && u(t), a[e].d(n)
        }
    }
}

function Te(o, e) {
    let s, t, i;
    return t = new Nt({}), {
        key: o,
        first: null,
        c() {
            s = D("div"), V(t.$$.fragment), this.h()
        },
        l(r) {
            s = y(r, "DIV", {});
            var a = w(s);
            S(t.$$.fragment, a), a.forEach(u), this.h()
        },
        h() {
            this.first = s
        },
        m(r, a) {
            M(r, s, a), B(t, s, null), i = !0
        },
        p(r, a) {},
        i(r) {
            i || (v(t.$$.fragment, r), i = !0)
        },
        o(r) {
            b(t.$$.fragment, r), i = !1
        },
        d(r) {
            r && u(s), H(t)
        }
    }
}

function er(o) {
    let e = [],
        s = new Map,
        t, i, r = G(o[13]);
    const a = l => l[16].id;
    for (let l = 0; l < r.length; l += 1) {
        let n = Oe(o, r, l),
            f = a(n);
        s.set(f, e[l] = Te(f))
    }
    return {
        c() {
            for (let l = 0; l < e.length; l += 1) e[l].c();
            t = I()
        },
        l(l) {
            for (let n = 0; n < e.length; n += 1) e[n].l(l);
            t = P(l)
        },
        m(l, n) {
            for (let f = 0; f < e.length; f += 1) e[f] && e[f].m(l, n);
            M(l, t, n), i = !0
        },
        p(l, n) {
            n & 2048 && (r = G(l[13]), re(), e = ve(e, n, a, 1, l, r, s, t.parentNode, be, Te, t, Oe), le())
        },
        i(l) {
            if (!i) {
                for (let n = 0; n < r.length; n += 1) v(e[n]);
                i = !0
            }
        },
        o(l) {
            for (let n = 0; n < e.length; n += 1) b(e[n]);
            i = !1
        },
        d(l) {
            l && u(t);
            for (let n = 0; n < e.length; n += 1) e[n].d(l)
        }
    }
}

function je(o, e) {
    let s, t, i;
    return t = new Ye({
        props: {
            colSize: e[12],
            $$slots: {
                default: [er]
            },
            $$scope: {
                ctx: e
            }
        }
    }), {
        key: o,
        first: null,
        c() {
            s = q(), V(t.$$.fragment), this.h()
        },
        l(r) {
            s = q(), S(t.$$.fragment, r), this.h()
        },
        h() {
            this.first = s
        },
        m(r, a) {
            M(r, s, a), B(t, r, a), i = !0
        },
        p(r, a) {
            e = r;
            const l = {};
            a & 4096 && (l.colSize = e[12]), a & 8390656 && (l.$$scope = {
                dirty: a,
                ctx: e
            }), t.$set(l)
        },
        i(r) {
            i || (v(t.$$.fragment, r), i = !0)
        },
        o(r) {
            b(t.$$.fragment, r), i = !1
        },
        d(r) {
            r && u(s), H(t, r)
        }
    }
}

function tr(o) {
    let e = [],
        s = new Map,
        t, i, r = G(o[11]);
    const a = l => `col_${l[15]}`;
    for (let l = 0; l < r.length; l += 1) {
        let n = Fe(o, r, l),
            f = a(n);
        s.set(f, e[l] = je(f, n))
    }
    return {
        c() {
            for (let l = 0; l < e.length; l += 1) e[l].c();
            t = q()
        },
        l(l) {
            for (let n = 0; n < e.length; n += 1) e[n].l(l);
            t = q()
        },
        m(l, n) {
            for (let f = 0; f < e.length; f += 1) e[f] && e[f].m(l, n);
            M(l, t, n), i = !0
        },
        p(l, n) {
            n & 6144 && (r = G(l[11]), re(), e = ve(e, n, a, 1, l, r, s, t.parentNode, be, je, t, Fe), le())
        },
        i(l) {
            if (!i) {
                for (let n = 0; n < r.length; n += 1) v(e[n]);
                i = !0
            }
        },
        o(l) {
            for (let n = 0; n < e.length; n += 1) b(e[n]);
            i = !1
        },
        d(l) {
            l && u(t);
            for (let n = 0; n < e.length; n += 1) e[n].d(l)
        }
    }
}

function rr(o) {
    let e, s, t, i, r, a, l;
    const n = [Ut, Qt, Kt],
        f = [];

    function h(d, g) {
        return d[0].loading ? 0 : d[1].length === 0 ? 1 : 2
    }
    return t = h(o), i = f[t] = n[t](o), a = new rt({
        props: {
            pagination: o[2],
            listLength: o[1].length
        }
    }), {
        c() {
            e = D("div"), s = D("div"), i.c(), r = I(), V(a.$$.fragment), this.h()
        },
        l(d) {
            e = y(d, "DIV", {
                class: !0
            });
            var g = w(e);
            s = y(g, "DIV", {
                class: !0
            });
            var _ = w(s);
            i.l(_), _.forEach(u), g.forEach(u), r = P(d), S(a.$$.fragment, d), this.h()
        },
        h() {
            m(s, "class", "betlist-scroll svelte-1ibqorg"), m(e, "class", "betlist svelte-1ibqorg")
        },
        m(d, g) {
            M(d, e, g), p(e, s), f[t].m(s, null), M(d, r, g), B(a, d, g), l = !0
        },
        p(d, [g]) {
            let _ = t;
            t = h(d), t === _ ? f[t].p(d, g) : (re(), b(f[_], 1, 1, () => {
                f[_] = null
            }), le(), i = f[t], i ? i.p(d, g) : (i = f[t] = n[t](d), i.c()), v(i, 1), i.m(s, null));
            const c = {};
            g & 2 && (c.listLength = d[1].length), a.$set(c)
        },
        i(d) {
            l || (v(i), v(a.$$.fragment, d), l = !0)
        },
        o(d) {
            b(i), b(a.$$.fragment, d), l = !1
        },
        d(d) {
            d && (u(e), u(r)), f[t].d(), H(a, d)
        }
    }
}
const lr = 20;

function sr(o, e, s) {
    let t, i, r, a, l;
    ee(o, Ee, c => s(0, a = c)), ee(o, ot, c => s(10, l = c));
    let n = 0;
    const f = Et({
            initial: {
                limit: lr
            },
            refetch: async c => {
                c.offset > n && (n = c.offset, await Ee.loadMore({
                    load: {
                        fetch,
                        page: l
                    },
                    variables: c,
                    combine: ($, k) => {
                        var C, F, A, O, se, T;
                        return {
                            user: { ...k.user,
                                activeSwishBetList: [...((C = $ == null ? void 0 : $.user) == null ? void 0 : C.activeSwishBetList) ? ? [], ...((F = k == null ? void 0 : k.user) == null ? void 0 : F.activeSwishBetList) ? ? []],
                                activeSportBets: [...((A = $ == null ? void 0 : $.user) == null ? void 0 : A.activeSportBets) ? ? [], ...((O = k == null ? void 0 : k.user) == null ? void 0 : O.activeSportBets) ? ? []],
                                activeRacingBets: [...((se = $ == null ? void 0 : $.user) == null ? void 0 : se.activeRacingBets) ? ? [], ...((T = k == null ? void 0 : k.user) == null ? void 0 : T.activeRacingBets) ? ? []]
                            }
                        }
                    }
                }))
            }
        }),
        {
            limit: h,
            offset: d
        } = f;
    ee(o, h, c => s(7, i = c)), ee(o, d, c => s(8, r = c));
    const g = c => {
        Ee.removeBet(c)
    };
    ft(d, () => {
        Ct()
    });
    const _ = [{
        id: "loading_1"
    }, {
        id: "loading_2"
    }, {
        id: "loading_3"
    }, {
        id: "loading_4"
    }, {
        id: "loading_5"
    }, {
        id: "loading_6"
    }, {
        id: "loading_7"
    }, {
        id: "loading_8"
    }, {
        id: "loading_9"
    }];
    return o.$$.update = () => {
        var c, $, k, E, C, F;
        o.$$.dirty & 385 && s(1, t = [...(($ = (c = a == null ? void 0 : a.data) == null ? void 0 : c.user) == null ? void 0 : $.activeSportBets) || [], ...((E = (k = a == null ? void 0 : a.data) == null ? void 0 : k.user) == null ? void 0 : E.activeSwishBetList) || [], ...((F = (C = a == null ? void 0 : a.data) == null ? void 0 : C.user) == null ? void 0 : F.activeRacingBets) || []].sort((A, O) => +new Date(O.createdAt) - +new Date(A.createdAt)).slice(r, r + i) || [])
    }, [a, t, f, h, d, g, _, i, r]
}
class Lr extends Q {
    constructor(e) {
        super(), U(this, e, sr, rr, K, {})
    }
}
export {
    Gt as B, Ye as C, Nt as L, Xe as M, We as S, Lr as a, lr as b
};