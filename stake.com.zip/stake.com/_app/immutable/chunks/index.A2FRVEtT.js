import {
    s as D,
    C as ye,
    H as Be,
    D as ke,
    f as w,
    E as Ee,
    i as d,
    F as v,
    j as g,
    n as y,
    a9 as Ye,
    m as h,
    c as M,
    w as je,
    e as C,
    d as I,
    t as L,
    h as R,
    l as F,
    K as U,
    Q as $,
    V as x,
    L as ee,
    M as He,
    a1 as W,
    O as Z,
    P as q,
    S as Ke,
    G as Se
} from "./scheduler.DXu26z7T.js";
import {
    S as O,
    i as P,
    g as p,
    b as _,
    e as b,
    t as u,
    c as B,
    a as k,
    m as E,
    d as S
} from "./index.Dz_MmNB3.js";
import {
    e as T
} from "./each.DvgCmocI.js";
import {
    g as ze
} from "./spread.CgU5AtxT.js";
import {
    o as Ge
} from "./index.CgjaLSob.js";
import {
    S as te,
    B as Ue,
    i as Y,
    h as A
} from "./index.B4-7gKq3.js";
import "./index.ByMdEFI5.js";
import {
    T as Ze
} from "./index.D7nbRHfU.js";
import {
    C as K
} from "./index.CAbJJJ2j.js";
import {
    W as z
} from "./Wallet.B4hgSvlS.js";
import {
    V as Te
} from "./index.B81orGJm.js";
import {
    b as N,
    f as we,
    g as qe,
    h as Qe,
    x as Oe,
    p as Je,
    i as Xe
} from "./index.lhCIiKC2.js";
import {
    n as G
} from "./index.DGKYLdH2.js";
import {
    s as Q
} from "./index.1CTKaDY2.js";
import {
    b as Pe
} from "./variables.CIGccMR5.js";
import {
    M as $e,
    n as xe
} from "./interpreter.CJhK2JTN.js";

function et(s) {
    let e, l, t = ` <title>${s[1]||""}</title> <path d="M48.51 65.684 18.192 15.158h60.632L48.509 65.684Z" fill="#FF2247"></path>`,
        n;
    return {
        c() {
            e = ye("svg"), l = new Be(!0), this.h()
        },
        l(o) {
            e = ke(o, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var r = w(e);
            l = Ee(r, !0), r.forEach(d), this.h()
        },
        h() {
            l.a = null, v(e, "fill", "none"), v(e, "viewBox", "0 0 96 80"), v(e, "class", n = "svg-icon " + s[2]), v(e, "style", s[0])
        },
        m(o, r) {
            g(o, e, r), l.m(t, e)
        },
        p(o, [r]) {
            r & 2 && t !== (t = ` <title>${o[1]||""}</title> <path d="M48.51 65.684 18.192 15.158h60.632L48.509 65.684Z" fill="#FF2247"></path>`) && l.p(t), r & 4 && n !== (n = "svg-icon " + o[2]) && v(e, "class", n), r & 1 && v(e, "style", o[0])
        },
        i: y,
        o: y,
        d(o) {
            o && d(e)
        }
    }
}

function tt(s, e, l) {
    let {
        style: t = ""
    } = e, {
        alt: n = ""
    } = e, {
        class: o = ""
    } = e;
    return s.$$set = r => {
        "style" in r && l(0, t = r.style), "alt" in r && l(1, n = r.alt), "class" in r && l(2, o = r.class)
    }, [t, n, o]
}
class Ae extends O {
    constructor(e) {
        super(), P(this, e, tt, et, D, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}

function lt(s) {
    let e, l, t = ` <title>${s[1]||""}</title> <path d="m48.507 15.158 30.316 50.526H18.191l30.316-50.526Z" fill="#00E700"></path>`,
        n;
    return {
        c() {
            e = ye("svg"), l = new Be(!0), this.h()
        },
        l(o) {
            e = ke(o, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var r = w(e);
            l = Ee(r, !0), r.forEach(d), this.h()
        },
        h() {
            l.a = null, v(e, "fill", "none"), v(e, "viewBox", "0 0 96 80"), v(e, "class", n = "svg-icon " + s[2]), v(e, "style", s[0])
        },
        m(o, r) {
            g(o, e, r), l.m(t, e)
        },
        p(o, [r]) {
            r & 2 && t !== (t = ` <title>${o[1]||""}</title> <path d="m48.507 15.158 30.316 50.526H18.191l30.316-50.526Z" fill="#00E700"></path>`) && l.p(t), r & 4 && n !== (n = "svg-icon " + o[2]) && v(e, "class", n), r & 1 && v(e, "style", o[0])
        },
        i: y,
        o: y,
        d(o) {
            o && d(e)
        }
    }
}

function nt(s, e, l) {
    let {
        style: t = ""
    } = e, {
        alt: n = ""
    } = e, {
        class: o = ""
    } = e;
    return s.$$set = r => {
        "style" in r && l(0, t = r.style), "alt" in r && l(1, n = r.alt), "class" in r && l(2, o = r.class)
    }, [t, n, o]
}
class Ne extends O {
    constructor(e) {
        super(), P(this, e, nt, lt, D, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}

function it(s) {
    let e, l, t, n, o;
    const r = [ot, st],
        c = [];

    function i(a, f) {
        return a[2] === "increased" ? 0 : 1
    }
    return l = i(s), t = c[l] = r[l](s), {
        c() {
            e = C("div"), t.c(), this.h()
        },
        l(a) {
            e = I(a, "DIV", {
                class: !0
            });
            var f = w(e);
            t.l(f), f.forEach(d), this.h()
        },
        h() {
            v(e, "class", n = "static-arrow " + s[2] + " align-" + s[1] + " svelte-hfoo7h")
        },
        m(a, f) {
            g(a, e, f), c[l].m(e, null), o = !0
        },
        p(a, f) {
            let m = l;
            l = i(a), l !== m && (p(), _(c[m], 1, 1, () => {
                c[m] = null
            }), b(), t = c[l], t || (t = c[l] = r[l](a), t.c()), u(t, 1), t.m(e, null)), (!o || f & 6 && n !== (n = "static-arrow " + a[2] + " align-" + a[1] + " svelte-hfoo7h")) && v(e, "class", n)
        },
        i(a) {
            o || (u(t), o = !0)
        },
        o(a) {
            _(t), o = !1
        },
        d(a) {
            a && d(e), c[l].d()
        }
    }
}

function rt(s) {
    let e, l, t, n, o;
    const r = [at, ct],
        c = [];

    function i(a, f) {
        return a[2] === "increased" ? 0 : a[2] === "decreased" ? 1 : -1
    }
    return ~(l = i(s)) && (t = c[l] = r[l](s)), {
        c() {
            e = C("div"), t && t.c(), this.h()
        },
        l(a) {
            e = I(a, "DIV", {
                class: !0
            });
            var f = w(e);
            t && t.l(f), f.forEach(d), this.h()
        },
        h() {
            v(e, "class", n = "arrow-odds " + s[2] + " align-" + s[1] + " svelte-hfoo7h")
        },
        m(a, f) {
            g(a, e, f), ~l && c[l].m(e, null), o = !0
        },
        p(a, f) {
            let m = l;
            l = i(a), l !== m && (t && (p(), _(c[m], 1, 1, () => {
                c[m] = null
            }), b()), ~l ? (t = c[l], t || (t = c[l] = r[l](a), t.c()), u(t, 1), t.m(e, null)) : t = null), (!o || f & 6 && n !== (n = "arrow-odds " + a[2] + " align-" + a[1] + " svelte-hfoo7h")) && v(e, "class", n)
        },
        i(a) {
            o || (u(t), o = !0)
        },
        o(a) {
            _(t), o = !1
        },
        d(a) {
            a && d(e), ~l && c[l].d()
        }
    }
}

function st(s) {
    let e, l;
    return e = new Ae({}), {
        c() {
            B(e.$$.fragment)
        },
        l(t) {
            k(e.$$.fragment, t)
        },
        m(t, n) {
            E(e, t, n), l = !0
        },
        i(t) {
            l || (u(e.$$.fragment, t), l = !0)
        },
        o(t) {
            _(e.$$.fragment, t), l = !1
        },
        d(t) {
            S(e, t)
        }
    }
}

function ot(s) {
    let e, l;
    return e = new Ne({}), {
        c() {
            B(e.$$.fragment)
        },
        l(t) {
            k(e.$$.fragment, t)
        },
        m(t, n) {
            E(e, t, n), l = !0
        },
        i(t) {
            l || (u(e.$$.fragment, t), l = !0)
        },
        o(t) {
            _(e.$$.fragment, t), l = !1
        },
        d(t) {
            S(e, t)
        }
    }
}

function ct(s) {
    let e, l;
    return e = new Ae({}), {
        c() {
            B(e.$$.fragment)
        },
        l(t) {
            k(e.$$.fragment, t)
        },
        m(t, n) {
            E(e, t, n), l = !0
        },
        i(t) {
            l || (u(e.$$.fragment, t), l = !0)
        },
        o(t) {
            _(e.$$.fragment, t), l = !1
        },
        d(t) {
            S(e, t)
        }
    }
}

function at(s) {
    let e, l;
    return e = new Ne({}), {
        c() {
            B(e.$$.fragment)
        },
        l(t) {
            k(e.$$.fragment, t)
        },
        m(t, n) {
            E(e, t, n), l = !0
        },
        i(t) {
            l || (u(e.$$.fragment, t), l = !0)
        },
        o(t) {
            _(e.$$.fragment, t), l = !1
        },
        d(t) {
            S(e, t)
        }
    }
}

function ft(s) {
    let e, l, t, n;
    const o = [rt, it],
        r = [];

    function c(i, a) {
        return !i[0] || typeof i[3] == "number" ? 0 : i[2] ? 1 : -1
    }
    return ~(e = c(s)) && (l = r[e] = o[e](s)), {
        c() {
            l && l.c(), t = h()
        },
        l(i) {
            l && l.l(i), t = h()
        },
        m(i, a) {
            ~e && r[e].m(i, a), g(i, t, a), n = !0
        },
        p(i, [a]) {
            let f = e;
            e = c(i), e === f ? ~e && r[e].p(i, a) : (l && (p(), _(r[f], 1, 1, () => {
                r[f] = null
            }), b()), ~e ? (l = r[e], l ? l.p(i, a) : (l = r[e] = o[e](i), l.c()), u(l, 1), l.m(t.parentNode, t)) : l = null)
        },
        i(i) {
            n || (u(l), n = !0)
        },
        o(i) {
            _(l), n = !1
        },
        d(i) {
            i && d(t), ~e && r[e].d(i)
        }
    }
}

function ut(s, e, l) {
    let t;
    M(s, Ge, m => l(7, t = m));
    let {
        odds: n
    } = e, {
        persistent: o = !1
    } = e, {
        align: r = "right"
    } = e, {
        initialDirection: c = void 0
    } = e, i = c, a, f = n;
    return je(() => {
        a && clearTimeout(a)
    }), s.$$set = m => {
        "odds" in m && l(4, n = m.odds), "persistent" in m && l(0, o = m.persistent), "align" in m && l(1, r = m.align), "initialDirection" in m && l(5, c = m.initialDirection)
    }, s.$$.update = () => {
        s.$$.dirty & 221 && n !== f && (clearTimeout(a), l(2, i = n > f ? "increased" : "decreased"), l(6, f = n), l(3, a = setTimeout(() => {
            if (!o) l(2, i = void 0);
            else switch (t) {
                case te.any:
                    l(2, i = void 0);
                    break;
                case te.higher:
                    {
                        i === "increased" && l(2, i = void 0);
                        break
                    }
            }
            l(3, a = void 0)
        }, 3200)))
    }, [o, r, i, a, n, c, f, t]
}
class De extends O {
    constructor(e) {
        super(), P(this, e, ut, ft, Ye, {
            odds: 4,
            persistent: 0,
            align: 1,
            initialDirection: 5
        })
    }
}
const _t = Ue("oddsFormat", "decimal"),
    dt = s => {
        let e = null,
            l = s.toString().indexOf("E");
        l === -1 && (l = s.toString().indexOf("e")), l === -1 ? e = s.toString() : e = s.toString().substring(0, l);
        let t = null;
        const n = e.toString().indexOf(".");
        n === -1 ? t = e : n === 0 ? t = e.substring(1, e.length) : n < e.length && (t = e.substring(0, n) + e.substring(n + 1, e.length));
        let o = t;
        const r = o.toString().length,
            c = s;
        let i = c.toString().length;
        c === 0 && (i = 0);
        const a = r - i;
        let f;
        for (f = a; f > 0 && o % 2 === 0; f--) o /= 2;
        for (f = a; f > 0 && o % 5 === 0; f--) o /= 5;
        return o
    },
    mt = s => {
        const l = [0, 1],
            t = [1, 0],
            n = dt(s);
        let o = s,
            r;
        const c = NaN,
            i = Math.pow(10, -12) / 2;
        for (let a = 2; a < 1e3; a++) {
            const f = Math.floor(o);
            if (l[a] = f * l[a - 1] + l[a - 2], Math.abs(l[a]) > n) return;
            if (t[a] = f * t[a - 1] + t[a - 2], r = l[a] / t[a], Math.abs(r - s) < i || r === c) return `${l[a].toString()}/${t[a].toString()}`;
            o = 1 / (o - f)
        }
    },
    Ce = s => s >= 2 ? (s - 1) * 100 : -100 / (s - 1),
    gt = s => Ce(s) / 100,
    ht = s => s > 2 ? -1 / (s - 1) : s - 1,
    pt = {
        decimal: ({
            odds: s,
            format: e
        }) => e(s, {
            maximumFractionDigits: 2,
            minimumFractionDigits: 2
        }),
        fractional: ({
            odds: s
        }) => mt(s - 1) || "",
        american: ({
            odds: s,
            format: e
        }) => `${s>=2?"+":""}${e(Ce(s),{maximumFractionDigits:0,minimumFractionDigits:0})}`,
        indonesian: ({
            odds: s,
            format: e
        }) => `${s>=2?"+":""}${e(gt(s),{maximumFractionDigits:2,minimumFractionDigits:0})}`,
        hongkong: ({
            odds: s,
            format: e
        }) => `+${e(s-1,{maximumFractionDigits:2,minimumFractionDigits:0})}`,
        malaysian: ({
            odds: s,
            format: e
        }) => `${s<=2?"+":""}${e(ht(s),{maximumFractionDigits:2,minimumFractionDigits:0})}`
    };

function bt(s) {
    let e;
    return {
        c() {
            e = L(s[2])
        },
        l(l) {
            e = R(l, s[2])
        },
        m(l, t) {
            g(l, e, t)
        },
        p(l, t) {
            t & 4 && F(e, l[2])
        },
        d(l) {
            l && d(e)
        }
    }
}

function vt(s) {
    let e, l;
    return e = new Ze({
        props: {
            variant: s[0],
            weight: s[1],
            $$slots: {
                default: [bt]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            B(e.$$.fragment)
        },
        l(t) {
            k(e.$$.fragment, t)
        },
        m(t, n) {
            E(e, t, n), l = !0
        },
        p(t, [n]) {
            const o = {};
            n & 1 && (o.variant = t[0]), n & 2 && (o.weight = t[1]), n & 68 && (o.$$scope = {
                dirty: n,
                ctx: t
            }), e.$set(o)
        },
        i(t) {
            l || (u(e.$$.fragment, t), l = !0)
        },
        o(t) {
            _(e.$$.fragment, t), l = !1
        },
        d(t) {
            S(e, t)
        }
    }
}

function yt(s, e, l) {
    let t, n, o;
    M(s, Y, a => l(4, n = a)), M(s, _t, a => l(5, o = a));
    let {
        odds: r
    } = e, {
        variant: c = "highlighted"
    } = e, {
        weight: i = "bold"
    } = e;
    return s.$$set = a => {
        "odds" in a && l(3, r = a.odds), "variant" in a && l(0, c = a.variant), "weight" in a && l(1, i = a.weight)
    }, s.$$.update = () => {
        s.$$.dirty & 56 && l(2, t = pt[o]({
            odds: r,
            format: (a, f) => n.number(a, f)
        }))
    }, [c, i, t, r, n, o]
}
class Ie extends O {
    constructor(e) {
        super(), P(this, e, yt, vt, D, {
            odds: 3,
            variant: 0,
            weight: 1
        })
    }
}

function le(s, e, l) {
    const t = s.slice();
    return t[5] = e[l], t[7] = l, t
}

function Bt(s) {
    let e, l, t = T(s[0]),
        n = [];
    for (let r = 0; r < t.length; r += 1) n[r] = ie(le(s, t, r));
    const o = r => _(n[r], 1, 1, () => {
        n[r] = null
    });
    return {
        c() {
            for (let r = 0; r < n.length; r += 1) n[r].c();
            e = h()
        },
        l(r) {
            for (let c = 0; c < n.length; c += 1) n[c].l(r);
            e = h()
        },
        m(r, c) {
            for (let i = 0; i < n.length; i += 1) n[i] && n[i].m(r, c);
            g(r, e, c), l = !0
        },
        p(r, c) {
            if (c & 15) {
                t = T(r[0]);
                let i;
                for (i = 0; i < t.length; i += 1) {
                    const a = le(r, t, i);
                    n[i] ? (n[i].p(a, c), u(n[i], 1)) : (n[i] = ie(a), n[i].c(), u(n[i], 1), n[i].m(e.parentNode, e))
                }
                for (p(), i = t.length; i < n.length; i += 1) o(i);
                b()
            }
        },
        i(r) {
            if (!l) {
                for (let c = 0; c < t.length; c += 1) u(n[c]);
                l = !0
            }
        },
        o(r) {
            n = n.filter(Boolean);
            for (let c = 0; c < n.length; c += 1) _(n[c]);
            l = !1
        },
        d(r) {
            r && d(e), W(n, r)
        }
    }
}

function kt(s) {
    let e, l, t, n;
    return e = new Ie({
        props: {
            variant: s[1] ? "highlighted" : "action",
            odds: s[0]
        }
    }), t = new De({
        props: {
            align: s[3],
            persistent: s[2],
            odds: s[0]
        }
    }), {
        c() {
            B(e.$$.fragment), l = Z(), B(t.$$.fragment)
        },
        l(o) {
            k(e.$$.fragment, o), l = q(o), k(t.$$.fragment, o)
        },
        m(o, r) {
            E(e, o, r), g(o, l, r), E(t, o, r), n = !0
        },
        p(o, r) {
            const c = {};
            r & 2 && (c.variant = o[1] ? "highlighted" : "action"), r & 1 && (c.odds = o[0]), e.$set(c);
            const i = {};
            r & 8 && (i.align = o[3]), r & 4 && (i.persistent = o[2]), r & 1 && (i.odds = o[0]), t.$set(i)
        },
        i(o) {
            n || (u(e.$$.fragment, o), u(t.$$.fragment, o), n = !0)
        },
        o(o) {
            _(e.$$.fragment, o), _(t.$$.fragment, o), n = !1
        },
        d(o) {
            o && d(l), S(e, o), S(t, o)
        }
    }
}

function ne(s) {
    let e, l = "/ ";
    return {
        c() {
            e = C("span"), e.textContent = l
        },
        l(t) {
            e = I(t, "SPAN", {
                "data-svelte-h": !0
            }), Ke(e) !== "svelte-1vw36fp" && (e.textContent = l)
        },
        m(t, n) {
            g(t, e, n)
        },
        d(t) {
            t && d(e)
        }
    }
}

function ie(s) {
    let e, l, t, n, o, r;
    e = new Ie({
        props: {
            variant: s[1] ? "highlighted" : "action",
            odds: s[5]
        }
    }), t = new De({
        props: {
            align: s[3],
            persistent: s[2],
            odds: s[5]
        }
    });
    let c = s[7] !== s[0].length - 1 && ne();
    return {
        c() {
            B(e.$$.fragment), l = Z(), B(t.$$.fragment), n = Z(), c && c.c(), o = h()
        },
        l(i) {
            k(e.$$.fragment, i), l = q(i), k(t.$$.fragment, i), n = q(i), c && c.l(i), o = h()
        },
        m(i, a) {
            E(e, i, a), g(i, l, a), E(t, i, a), g(i, n, a), c && c.m(i, a), g(i, o, a), r = !0
        },
        p(i, a) {
            const f = {};
            a & 2 && (f.variant = i[1] ? "highlighted" : "action"), a & 1 && (f.odds = i[5]), e.$set(f);
            const m = {};
            a & 8 && (m.align = i[3]), a & 4 && (m.persistent = i[2]), a & 1 && (m.odds = i[5]), t.$set(m), i[7] !== i[0].length - 1 ? c || (c = ne(), c.c(), c.m(o.parentNode, o)) : c && (c.d(1), c = null)
        },
        i(i) {
            r || (u(e.$$.fragment, i), u(t.$$.fragment, i), r = !0)
        },
        o(i) {
            _(e.$$.fragment, i), _(t.$$.fragment, i), r = !1
        },
        d(i) {
            i && (d(l), d(n), d(o)), S(e, i), S(t, i), c && c.d(i)
        }
    }
}

function Et(s) {
    let e, l, t, n;
    const o = [kt, Bt],
        r = [];

    function c(f, m) {
        return typeof f[0] == "number" ? 0 : 1
    }
    l = c(s), t = r[l] = o[l](s);
    let i = [{
            class: "odds"
        }, {
            "data-test": "odds"
        }, s[4]],
        a = {};
    for (let f = 0; f < i.length; f += 1) a = U(a, i[f]);
    return {
        c() {
            e = C("div"), t.c(), this.h()
        },
        l(f) {
            e = I(f, "DIV", {
                class: !0,
                "data-test": !0
            });
            var m = w(e);
            t.l(m), m.forEach(d), this.h()
        },
        h() {
            $(e, a), x(e, "svelte-bbfzn7", !0)
        },
        m(f, m) {
            g(f, e, m), r[l].m(e, null), n = !0
        },
        p(f, [m]) {
            let V = l;
            l = c(f), l === V ? r[l].p(f, m) : (p(), _(r[V], 1, 1, () => {
                r[V] = null
            }), b(), t = r[l], t ? t.p(f, m) : (t = r[l] = o[l](f), t.c()), u(t, 1), t.m(e, null)), $(e, a = ze(i, [{
                class: "odds"
            }, {
                "data-test": "odds"
            }, m & 16 && f[4]])), x(e, "svelte-bbfzn7", !0)
        },
        i(f) {
            n || (u(t), n = !0)
        },
        o(f) {
            _(t), n = !1
        },
        d(f) {
            f && d(e), r[l].d()
        }
    }
}

function St(s, e, l) {
    const t = ["odds", "selected", "persistent", "alignArrow"];
    let n = ee(e, t),
        {
            odds: o
        } = e,
        {
            selected: r = !1
        } = e,
        {
            persistent: c = !1
        } = e,
        {
            alignArrow: i = "right"
        } = e;
    return s.$$set = a => {
        e = U(U({}, e), He(a)), l(4, n = ee(e, t)), "odds" in a && l(0, o = a.odds), "selected" in a && l(1, r = a.selected), "persistent" in a && l(2, c = a.persistent), "alignArrow" in a && l(3, i = a.alignArrow)
    }, [o, r, c, i, n]
}
class Nl extends O {
    constructor(e) {
        super(), P(this, e, St, Et, D, {
            odds: 0,
            selected: 1,
            persistent: 2,
            alignArrow: 3
        })
    }
}
const j = {
    singleBetTitle: A._("Single Bet"),
    singleBetBody: {
        id: "Your single bet worth {value} has been placed successfully!"
    },
    singleBetsTitle: A._("Single Bets"),
    singleBetsBody: {
        id: "Your {count} single bets worth {value} have been placed successfully!"
    }
};

function re(s, e, l) {
    const t = s.slice();
    return t[6] = e[l], t
}

function se(s) {
    let e, l, t = T(s[3]),
        n = [];
    for (let r = 0; r < t.length; r += 1) n[r] = oe(re(s, t, r));
    const o = r => _(n[r], 1, 1, () => {
        n[r] = null
    });
    return {
        c() {
            e = C("span");
            for (let r = 0; r < n.length; r += 1) n[r].c()
        },
        l(r) {
            e = I(r, "SPAN", {});
            var c = w(e);
            for (let i = 0; i < n.length; i += 1) n[i].l(c);
            c.forEach(d)
        },
        m(r, c) {
            g(r, e, c);
            for (let i = 0; i < n.length; i += 1) n[i] && n[i].m(e, null);
            l = !0
        },
        p(r, c) {
            if (c & 15) {
                t = T(r[3]);
                let i;
                for (i = 0; i < t.length; i += 1) {
                    const a = re(r, t, i);
                    n[i] ? (n[i].p(a, c), u(n[i], 1)) : (n[i] = oe(a), n[i].c(), u(n[i], 1), n[i].m(e, null))
                }
                for (p(), i = t.length; i < n.length; i += 1) o(i);
                b()
            }
        },
        i(r) {
            if (!l) {
                for (let c = 0; c < t.length; c += 1) u(n[c]);
                l = !0
            }
        },
        o(r) {
            n = n.filter(Boolean);
            for (let c = 0; c < n.length; c += 1) _(n[c]);
            l = !1
        },
        d(r) {
            r && d(e), W(n, r)
        }
    }
}

function Tt(s) {
    let e, l;
    return e = new K({
        props: {
            value: s[1],
            currency: s[2]
        }
    }), {
        c() {
            B(e.$$.fragment)
        },
        l(t) {
            k(e.$$.fragment, t)
        },
        m(t, n) {
            E(e, t, n), l = !0
        },
        p(t, n) {
            const o = {};
            n & 2 && (o.value = t[1]), n & 4 && (o.currency = t[2]), e.$set(o)
        },
        i(t) {
            l || (u(e.$$.fragment, t), l = !0)
        },
        o(t) {
            _(e.$$.fragment, t), l = !1
        },
        d(t) {
            S(e, t)
        }
    }
}

function wt(s) {
    let e;
    return {
        c() {
            e = L(s[0])
        },
        l(l) {
            e = R(l, s[0])
        },
        m(l, t) {
            g(l, e, t)
        },
        p(l, t) {
            t & 1 && F(e, l[0])
        },
        i: y,
        o: y,
        d(l) {
            l && d(e)
        }
    }
}

function Ot(s) {
    let e = s[6] + "",
        l;
    return {
        c() {
            l = L(e)
        },
        l(t) {
            l = R(t, e)
        },
        m(t, n) {
            g(t, l, n)
        },
        p(t, n) {
            n & 8 && e !== (e = t[6] + "") && F(l, e)
        },
        i: y,
        o: y,
        d(t) {
            t && d(l)
        }
    }
}

function oe(s) {
    let e, l, t, n;
    const o = [Ot, wt, Tt],
        r = [];

    function c(i, a) {
        return typeof i[6] == "string" ? 0 : i[6][0] === "count" ? 1 : i[6][0] === "value" ? 2 : -1
    }
    return ~(e = c(s)) && (l = r[e] = o[e](s)), {
        c() {
            l && l.c(), t = h()
        },
        l(i) {
            l && l.l(i), t = h()
        },
        m(i, a) {
            ~e && r[e].m(i, a), g(i, t, a), n = !0
        },
        p(i, a) {
            let f = e;
            e = c(i), e === f ? ~e && r[e].p(i, a) : (l && (p(), _(r[f], 1, 1, () => {
                r[f] = null
            }), b()), ~e ? (l = r[e], l ? l.p(i, a) : (l = r[e] = o[e](i), l.c()), u(l, 1), l.m(t.parentNode, t)) : l = null)
        },
        i(i) {
            n || (u(l), n = !0)
        },
        o(i) {
            _(l), n = !1
        },
        d(i) {
            i && d(t), ~e && r[e].d(i)
        }
    }
}

function Pt(s) {
    let e, l, t = s[3] && se(s);
    return {
        c() {
            t && t.c(), e = h()
        },
        l(n) {
            t && t.l(n), e = h()
        },
        m(n, o) {
            t && t.m(n, o), g(n, e, o), l = !0
        },
        p(n, [o]) {
            n[3] ? t ? (t.p(n, o), o & 8 && u(t, 1)) : (t = se(n), t.c(), u(t, 1), t.m(e.parentNode, e)) : t && (p(), _(t, 1, 1, () => {
                t = null
            }), b())
        },
        i(n) {
            l || (u(t), l = !0)
        },
        o(n) {
            _(t), l = !1
        },
        d(n) {
            n && d(e), t && t.d(n)
        }
    }
}

function At(s, e, l) {
    let t, n;
    M(s, Y, a => l(4, n = a));
    let {
        count: o = 0
    } = e, {
        amount: r
    } = e, {
        currency: c
    } = e;
    const i = o > 1;
    return s.$$set = a => {
        "count" in a && l(0, o = a.count), "amount" in a && l(1, r = a.amount), "currency" in a && l(2, c = a.currency)
    }, s.$$.update = () => {
        s.$$.dirty & 16 && l(3, t = n.message(i ? j.singleBetsBody.id : j.singleBetBody.id))
    }, [o, r, c, t, n]
}
let Nt = class extends O {
    constructor(e) {
        super(), P(this, e, At, Pt, D, {
            count: 0,
            amount: 1,
            currency: 2
        })
    }
};
const ce = s => {
        const e = s.count > 1,
            l = {
                props: s,
                icon: z,
                sound: "money",
                type: "positive",
                body: Nt
            };
        return e ? { ...l,
            title: j.singleBetsTitle
        } : { ...l,
            title: j.singleBetTitle
        }
    },
    J = {
        content: {
            id: "Your {value} multi bet has been placed successfully!"
        },
        title: A._("Multi Placed")
    },
    Dt = { ...J,
        content: {
            id: "Your {value} parlay has been placed successfully!"
        },
        title: A._("Parlay Placed")
    },
    Ct = {
        stake: J,
        canada: Dt
    },
    Me = Ct[Te] || J;

function ae(s, e, l) {
    const t = s.slice();
    return t[4] = e[l], t
}

function fe(s) {
    let e, l, t = T(s[2]),
        n = [];
    for (let r = 0; r < t.length; r += 1) n[r] = ue(ae(s, t, r));
    const o = r => _(n[r], 1, 1, () => {
        n[r] = null
    });
    return {
        c() {
            e = C("span");
            for (let r = 0; r < n.length; r += 1) n[r].c()
        },
        l(r) {
            e = I(r, "SPAN", {});
            var c = w(e);
            for (let i = 0; i < n.length; i += 1) n[i].l(c);
            c.forEach(d)
        },
        m(r, c) {
            g(r, e, c);
            for (let i = 0; i < n.length; i += 1) n[i] && n[i].m(e, null);
            l = !0
        },
        p(r, c) {
            if (c & 7) {
                t = T(r[2]);
                let i;
                for (i = 0; i < t.length; i += 1) {
                    const a = ae(r, t, i);
                    n[i] ? (n[i].p(a, c), u(n[i], 1)) : (n[i] = ue(a), n[i].c(), u(n[i], 1), n[i].m(e, null))
                }
                for (p(), i = t.length; i < n.length; i += 1) o(i);
                b()
            }
        },
        i(r) {
            if (!l) {
                for (let c = 0; c < t.length; c += 1) u(n[c]);
                l = !0
            }
        },
        o(r) {
            n = n.filter(Boolean);
            for (let c = 0; c < n.length; c += 1) _(n[c]);
            l = !1
        },
        d(r) {
            r && d(e), W(n, r)
        }
    }
}

function It(s) {
    let e, l;
    return e = new K({
        props: {
            value: s[0],
            currency: s[1]
        }
    }), {
        c() {
            B(e.$$.fragment)
        },
        l(t) {
            k(e.$$.fragment, t)
        },
        m(t, n) {
            E(e, t, n), l = !0
        },
        p(t, n) {
            const o = {};
            n & 1 && (o.value = t[0]), n & 2 && (o.currency = t[1]), e.$set(o)
        },
        i(t) {
            l || (u(e.$$.fragment, t), l = !0)
        },
        o(t) {
            _(e.$$.fragment, t), l = !1
        },
        d(t) {
            S(e, t)
        }
    }
}

function Mt(s) {
    let e = s[4] + "",
        l;
    return {
        c() {
            l = L(e)
        },
        l(t) {
            l = R(t, e)
        },
        m(t, n) {
            g(t, l, n)
        },
        p(t, n) {
            n & 4 && e !== (e = t[4] + "") && F(l, e)
        },
        i: y,
        o: y,
        d(t) {
            t && d(l)
        }
    }
}

function ue(s) {
    let e, l, t, n;
    const o = [Mt, It],
        r = [];

    function c(i, a) {
        return typeof i[4] == "string" ? 0 : i[4][0] === "value" ? 1 : -1
    }
    return ~(e = c(s)) && (l = r[e] = o[e](s)), {
        c() {
            l && l.c(), t = h()
        },
        l(i) {
            l && l.l(i), t = h()
        },
        m(i, a) {
            ~e && r[e].m(i, a), g(i, t, a), n = !0
        },
        p(i, a) {
            let f = e;
            e = c(i), e === f ? ~e && r[e].p(i, a) : (l && (p(), _(r[f], 1, 1, () => {
                r[f] = null
            }), b()), ~e ? (l = r[e], l ? l.p(i, a) : (l = r[e] = o[e](i), l.c()), u(l, 1), l.m(t.parentNode, t)) : l = null)
        },
        i(i) {
            n || (u(l), n = !0)
        },
        o(i) {
            _(l), n = !1
        },
        d(i) {
            i && d(t), ~e && r[e].d(i)
        }
    }
}

function Lt(s) {
    let e, l, t = s[2] && fe(s);
    return {
        c() {
            t && t.c(), e = h()
        },
        l(n) {
            t && t.l(n), e = h()
        },
        m(n, o) {
            t && t.m(n, o), g(n, e, o), l = !0
        },
        p(n, [o]) {
            n[2] ? t ? (t.p(n, o), o & 4 && u(t, 1)) : (t = fe(n), t.c(), u(t, 1), t.m(e.parentNode, e)) : t && (p(), _(t, 1, 1, () => {
                t = null
            }), b())
        },
        i(n) {
            l || (u(t), l = !0)
        },
        o(n) {
            _(t), l = !1
        },
        d(n) {
            n && d(e), t && t.d(n)
        }
    }
}

function Rt(s, e, l) {
    let t, n;
    M(s, Y, c => l(3, n = c));
    let {
        amount: o
    } = e, {
        currency: r
    } = e;
    return s.$$set = c => {
        "amount" in c && l(0, o = c.amount), "currency" in c && l(1, r = c.currency)
    }, s.$$.update = () => {
        s.$$.dirty & 8 && l(2, t = n.message(Me.content.id) ? ? [])
    }, [o, r, t, n]
}
let Ft = class extends O {
    constructor(e) {
        super(), P(this, e, Rt, Lt, D, {
            amount: 0,
            currency: 1
        })
    }
};
const Vt = s => ({
        title: Me.title,
        body: Ft,
        props: s,
        icon: z,
        sound: "money",
        type: "positive"
    }),
    H = {
        singleBetTitlePartial: A._("Partial Single Bet"),
        singleBetBodyPartial: {
            id: "Your single bet worth {value} has been partially accepted!"
        },
        singleBetsTitlePartial: A._("Partial Single Bets"),
        singleBetsBodyPartial: {
            id: "Your {count} single bets worth {value} have been partially accepted!"
        }
    };

function _e(s, e, l) {
    const t = s.slice();
    return t[6] = e[l], t
}

function de(s) {
    let e, l, t = T(s[3]),
        n = [];
    for (let r = 0; r < t.length; r += 1) n[r] = me(_e(s, t, r));
    const o = r => _(n[r], 1, 1, () => {
        n[r] = null
    });
    return {
        c() {
            e = C("span");
            for (let r = 0; r < n.length; r += 1) n[r].c()
        },
        l(r) {
            e = I(r, "SPAN", {});
            var c = w(e);
            for (let i = 0; i < n.length; i += 1) n[i].l(c);
            c.forEach(d)
        },
        m(r, c) {
            g(r, e, c);
            for (let i = 0; i < n.length; i += 1) n[i] && n[i].m(e, null);
            l = !0
        },
        p(r, c) {
            if (c & 15) {
                t = T(r[3]);
                let i;
                for (i = 0; i < t.length; i += 1) {
                    const a = _e(r, t, i);
                    n[i] ? (n[i].p(a, c), u(n[i], 1)) : (n[i] = me(a), n[i].c(), u(n[i], 1), n[i].m(e, null))
                }
                for (p(), i = t.length; i < n.length; i += 1) o(i);
                b()
            }
        },
        i(r) {
            if (!l) {
                for (let c = 0; c < t.length; c += 1) u(n[c]);
                l = !0
            }
        },
        o(r) {
            n = n.filter(Boolean);
            for (let c = 0; c < n.length; c += 1) _(n[c]);
            l = !1
        },
        d(r) {
            r && d(e), W(n, r)
        }
    }
}

function Wt(s) {
    let e, l;
    return e = new K({
        props: {
            value: s[1],
            currency: s[2]
        }
    }), {
        c() {
            B(e.$$.fragment)
        },
        l(t) {
            k(e.$$.fragment, t)
        },
        m(t, n) {
            E(e, t, n), l = !0
        },
        p(t, n) {
            const o = {};
            n & 2 && (o.value = t[1]), n & 4 && (o.currency = t[2]), e.$set(o)
        },
        i(t) {
            l || (u(e.$$.fragment, t), l = !0)
        },
        o(t) {
            _(e.$$.fragment, t), l = !1
        },
        d(t) {
            S(e, t)
        }
    }
}

function Yt(s) {
    let e;
    return {
        c() {
            e = L(s[0])
        },
        l(l) {
            e = R(l, s[0])
        },
        m(l, t) {
            g(l, e, t)
        },
        p(l, t) {
            t & 1 && F(e, l[0])
        },
        i: y,
        o: y,
        d(l) {
            l && d(e)
        }
    }
}

function jt(s) {
    let e = s[6] + "",
        l;
    return {
        c() {
            l = L(e)
        },
        l(t) {
            l = R(t, e)
        },
        m(t, n) {
            g(t, l, n)
        },
        p(t, n) {
            n & 8 && e !== (e = t[6] + "") && F(l, e)
        },
        i: y,
        o: y,
        d(t) {
            t && d(l)
        }
    }
}

function me(s) {
    let e, l, t, n;
    const o = [jt, Yt, Wt],
        r = [];

    function c(i, a) {
        return typeof i[6] == "string" ? 0 : i[6][0] === "count" ? 1 : i[6][0] === "value" ? 2 : -1
    }
    return ~(e = c(s)) && (l = r[e] = o[e](s)), {
        c() {
            l && l.c(), t = h()
        },
        l(i) {
            l && l.l(i), t = h()
        },
        m(i, a) {
            ~e && r[e].m(i, a), g(i, t, a), n = !0
        },
        p(i, a) {
            let f = e;
            e = c(i), e === f ? ~e && r[e].p(i, a) : (l && (p(), _(r[f], 1, 1, () => {
                r[f] = null
            }), b()), ~e ? (l = r[e], l ? l.p(i, a) : (l = r[e] = o[e](i), l.c()), u(l, 1), l.m(t.parentNode, t)) : l = null)
        },
        i(i) {
            n || (u(l), n = !0)
        },
        o(i) {
            _(l), n = !1
        },
        d(i) {
            i && d(t), ~e && r[e].d(i)
        }
    }
}

function Ht(s) {
    let e, l, t = s[3] && de(s);
    return {
        c() {
            t && t.c(), e = h()
        },
        l(n) {
            t && t.l(n), e = h()
        },
        m(n, o) {
            t && t.m(n, o), g(n, e, o), l = !0
        },
        p(n, [o]) {
            n[3] ? t ? (t.p(n, o), o & 8 && u(t, 1)) : (t = de(n), t.c(), u(t, 1), t.m(e.parentNode, e)) : t && (p(), _(t, 1, 1, () => {
                t = null
            }), b())
        },
        i(n) {
            l || (u(t), l = !0)
        },
        o(n) {
            _(t), l = !1
        },
        d(n) {
            n && d(e), t && t.d(n)
        }
    }
}

function Kt(s, e, l) {
    let t, n;
    M(s, Y, a => l(4, n = a));
    let {
        count: o = 0
    } = e, {
        amount: r
    } = e, {
        currency: c
    } = e;
    const i = o > 1;
    return s.$$set = a => {
        "count" in a && l(0, o = a.count), "amount" in a && l(1, r = a.amount), "currency" in a && l(2, c = a.currency)
    }, s.$$.update = () => {
        s.$$.dirty & 16 && l(3, t = n.message(i ? H.singleBetsBodyPartial.id : H.singleBetBodyPartial.id))
    }, [o, r, c, t, n]
}
let zt = class extends O {
    constructor(e) {
        super(), P(this, e, Kt, Ht, D, {
            count: 0,
            amount: 1,
            currency: 2
        })
    }
};
const ge = s => {
        const e = s.count > 1,
            l = {
                props: s,
                icon: z,
                sound: "money",
                type: "positive",
                body: zt
            };
        return e ? { ...l,
            title: H.singleBetsTitlePartial
        } : { ...l,
            title: H.singleBetTitlePartial
        }
    },
    X = {
        contentPartial: {
            id: "Your {value} multi bet has been partially placed!"
        },
        titlePartial: A._("Partial Multi Placed")
    },
    Gt = { ...X,
        contentPartial: {
            id: "Your {value} parlay has been partially placed!"
        },
        titlePartial: A._("Partial Parlay Placed")
    },
    Ut = {
        stake: X,
        canada: Gt
    },
    Le = Ut[Te] || X;

function he(s, e, l) {
    const t = s.slice();
    return t[4] = e[l], t
}

function pe(s) {
    let e, l, t = T(s[2]),
        n = [];
    for (let r = 0; r < t.length; r += 1) n[r] = be(he(s, t, r));
    const o = r => _(n[r], 1, 1, () => {
        n[r] = null
    });
    return {
        c() {
            e = C("span");
            for (let r = 0; r < n.length; r += 1) n[r].c()
        },
        l(r) {
            e = I(r, "SPAN", {});
            var c = w(e);
            for (let i = 0; i < n.length; i += 1) n[i].l(c);
            c.forEach(d)
        },
        m(r, c) {
            g(r, e, c);
            for (let i = 0; i < n.length; i += 1) n[i] && n[i].m(e, null);
            l = !0
        },
        p(r, c) {
            if (c & 7) {
                t = T(r[2]);
                let i;
                for (i = 0; i < t.length; i += 1) {
                    const a = he(r, t, i);
                    n[i] ? (n[i].p(a, c), u(n[i], 1)) : (n[i] = be(a), n[i].c(), u(n[i], 1), n[i].m(e, null))
                }
                for (p(), i = t.length; i < n.length; i += 1) o(i);
                b()
            }
        },
        i(r) {
            if (!l) {
                for (let c = 0; c < t.length; c += 1) u(n[c]);
                l = !0
            }
        },
        o(r) {
            n = n.filter(Boolean);
            for (let c = 0; c < n.length; c += 1) _(n[c]);
            l = !1
        },
        d(r) {
            r && d(e), W(n, r)
        }
    }
}

function Zt(s) {
    let e, l;
    return e = new K({
        props: {
            value: s[0],
            currency: s[1]
        }
    }), {
        c() {
            B(e.$$.fragment)
        },
        l(t) {
            k(e.$$.fragment, t)
        },
        m(t, n) {
            E(e, t, n), l = !0
        },
        p(t, n) {
            const o = {};
            n & 1 && (o.value = t[0]), n & 2 && (o.currency = t[1]), e.$set(o)
        },
        i(t) {
            l || (u(e.$$.fragment, t), l = !0)
        },
        o(t) {
            _(e.$$.fragment, t), l = !1
        },
        d(t) {
            S(e, t)
        }
    }
}

function qt(s) {
    let e = s[4] + "",
        l;
    return {
        c() {
            l = L(e)
        },
        l(t) {
            l = R(t, e)
        },
        m(t, n) {
            g(t, l, n)
        },
        p(t, n) {
            n & 4 && e !== (e = t[4] + "") && F(l, e)
        },
        i: y,
        o: y,
        d(t) {
            t && d(l)
        }
    }
}

function be(s) {
    let e, l, t, n;
    const o = [qt, Zt],
        r = [];

    function c(i, a) {
        return typeof i[4] == "string" ? 0 : i[4][0] === "value" ? 1 : -1
    }
    return ~(e = c(s)) && (l = r[e] = o[e](s)), {
        c() {
            l && l.c(), t = h()
        },
        l(i) {
            l && l.l(i), t = h()
        },
        m(i, a) {
            ~e && r[e].m(i, a), g(i, t, a), n = !0
        },
        p(i, a) {
            let f = e;
            e = c(i), e === f ? ~e && r[e].p(i, a) : (l && (p(), _(r[f], 1, 1, () => {
                r[f] = null
            }), b()), ~e ? (l = r[e], l ? l.p(i, a) : (l = r[e] = o[e](i), l.c()), u(l, 1), l.m(t.parentNode, t)) : l = null)
        },
        i(i) {
            n || (u(l), n = !0)
        },
        o(i) {
            _(l), n = !1
        },
        d(i) {
            i && d(t), ~e && r[e].d(i)
        }
    }
}

function Qt(s) {
    let e, l, t = s[2] && pe(s);
    return {
        c() {
            t && t.c(), e = h()
        },
        l(n) {
            t && t.l(n), e = h()
        },
        m(n, o) {
            t && t.m(n, o), g(n, e, o), l = !0
        },
        p(n, [o]) {
            n[2] ? t ? (t.p(n, o), o & 4 && u(t, 1)) : (t = pe(n), t.c(), u(t, 1), t.m(e.parentNode, e)) : t && (p(), _(t, 1, 1, () => {
                t = null
            }), b())
        },
        i(n) {
            l || (u(t), l = !0)
        },
        o(n) {
            _(t), l = !1
        },
        d(n) {
            n && d(e), t && t.d(n)
        }
    }
}

function Jt(s, e, l) {
    let t, n;
    M(s, Y, c => l(3, n = c));
    let {
        amount: o
    } = e, {
        currency: r
    } = e;
    return s.$$set = c => {
        "amount" in c && l(0, o = c.amount), "currency" in c && l(1, r = c.currency)
    }, s.$$.update = () => {
        s.$$.dirty & 8 && l(2, t = n.message(Le.contentPartial.id) ? ? [])
    }, [o, r, t, n]
}
class Xt extends O {
    constructor(e) {
        super(), P(this, e, Jt, Qt, D, {
            amount: 0,
            currency: 1
        })
    }
}
const $t = s => ({
        title: Le.titlePartial,
        body: Xt,
        props: s,
        icon: z,
        sound: "money",
        type: "positive"
    }),
    xt = (s, e) => {
        window.innerWidth >= Pe.sidebarFullWidth && Q.set("betslip"), N.add(e.bet)
    },
    el = (s, e) => {
        N.remove(e.bet)
    },
    tl = () => {
        we.repeatStake()
    },
    ll = () => {
        N.removeEachWaySelections()
    },
    nl = () => {
        N.removeAll()
    },
    il = (s, e) => {
        e.type !== "RETAIN_FAILED_SELECTION" && N.removeBetResponses()
    },
    rl = () => {
        N.removeSuccessfulBets()
    },
    sl = (s, e) => {
        we.replaceBets(e.bets)
    },
    ol = () => {
        window.innerWidth >= Pe.sidebarFullWidth && Q.set("betslip")
    },
    cl = () => {
        Q.set("betslip")
    },
    al = Object.freeze(Object.defineProperty({
        __proto__: null,
        addBet: xt,
        changeToMultiTab: ll,
        removeAllBets: nl,
        removeBet: el,
        removeBetResponses: il,
        removeSuccessfulBets: rl,
        repeatStake: tl,
        replaceBets: sl,
        switchToBetSlip: cl,
        switchToBetSlipOnDesktop: ol
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    fl = () => Se(qe).length > 1,
    ul = () => Se(Qe) === !1,
    _l = Object.freeze(Object.defineProperty({
        __proto__: null,
        hasMultipleIdententicalFixtureBets: fl,
        hasNoBetsWithChangedOdds: ul
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    ve = {
        on: {
            SPORTSBOOK_RECONNECT: "idle"
        }
    },
    dl = {
        id: "betslipMachine",
        initial: "betSlip",
        states: {
            betSlip: {
                initial: "single",
                id: "betslip",
                states: {
                    single: {
                        id: "single",
                        initial: "idle",
                        on: {
                            SPORTSBOOK_DISCONNECT: "#single.disconnected"
                        },
                        states: {
                            idle: {
                                on: {
                                    TO_MULTI: {
                                        actions: "changeToMultiTab",
                                        target: "#multi"
                                    },
                                    REPEAT_STAKE: {
                                        actions: "repeatStake"
                                    },
                                    SINGLE_BET: {
                                        target: "fetching"
                                    },
                                    ADD_BET: {
                                        actions: ["addBet", "switchToBetSlipOnDesktop"]
                                    },
                                    REMOVE_BET: {
                                        actions: "removeBet"
                                    },
                                    CLEAR_SELECTION: {
                                        actions: "removeAllBets"
                                    },
                                    REPLACE_BETS: {
                                        actions: ["replaceBets", "switchToBetSlip"],
                                        target: "#single"
                                    }
                                }
                            },
                            fetching: {
                                entry: "removeBetResponses",
                                invoke: {
                                    src: "placeSingleBet",
                                    onDone: {
                                        target: "completedBet",
                                        actions: (s, e) => {
                                            var n, o, r, c, i;
                                            const {
                                                data: l
                                            } = e, t = l.filter(a => {
                                                var f;
                                                return ((f = a.state.response) == null ? void 0 : f.type) === "success"
                                            });
                                            if (t.length !== 0) {
                                                const [a] = t, f = a.state.response.bet.currency, m = ((n = a.state.response) == null ? void 0 : n.type) === "success" && ((r = (o = a.state.response) == null ? void 0 : o.bet) == null ? void 0 : r.__typename) === "RacingBet" && (((i = (c = a.state.response) == null ? void 0 : c.bet) == null ? void 0 : i.refundAmount) || 0) > 0, V = t.reduce((Ve, We) => Ve + We.state.response.bet.amount, 0);
                                                G.open((m ? ge : ce)({
                                                    count: t.length,
                                                    currency: f,
                                                    amount: V
                                                }))
                                            }
                                        }
                                    }
                                }
                            },
                            completedBet: {
                                exit: ["removeBetResponses"],
                                on: {
                                    RETAIN_SELECTION: {
                                        target: "idle"
                                    },
                                    TO_MULTI: {
                                        target: "#multi",
                                        actions: "removeAllBets"
                                    },
                                    RETAIN_FAILED_SELECTION: {
                                        target: "idle",
                                        actions: "removeSuccessfulBets"
                                    },
                                    CLEAR_SELECTION: {
                                        target: "idle",
                                        actions: "removeAllBets"
                                    },
                                    ADD_BET: {
                                        actions: ["removeAllBets", "switchToBetSlipOnDesktop", "addBet"],
                                        target: "idle"
                                    },
                                    REMOVE_BET: {
                                        actions: "removeBet",
                                        target: "idle"
                                    },
                                    REPLACE_BETS: {
                                        actions: ["replaceBets", "switchToBetSlip"],
                                        target: "idle"
                                    }
                                }
                            },
                            disconnected: {
                                id: "#single.disconnected",
                                ...ve
                            }
                        }
                    },
                    multi: {
                        id: "multi",
                        initial: "idle",
                        on: {
                            SPORTSBOOK_DISCONNECT: "#multi.disconnected"
                        },
                        states: {
                            idle: {
                                on: {
                                    TO_SINGLE: {
                                        target: "#single"
                                    },
                                    MULTI_BET: {
                                        target: "fetching"
                                    },
                                    ADD_BET: {
                                        actions: ["addBet", "switchToBetSlipOnDesktop"]
                                    },
                                    CLEAR_SELECTION: {
                                        actions: "removeAllBets"
                                    },
                                    REMOVE_BET: {
                                        actions: "removeBet"
                                    },
                                    REPLACE_BETS: {
                                        actions: ["replaceBets", "switchToBetSlip"]
                                    }
                                }
                            },
                            fetching: {
                                entry: "removeBetResponses",
                                invoke: {
                                    src: "placeMultiBet",
                                    onDone: {
                                        target: "completedBet",
                                        actions: (s, e) => {
                                            const {
                                                data: l
                                            } = e, t = "partial" in l.variables && l.variables.partial;
                                            if (l.type === "success") {
                                                const {
                                                    currency: n,
                                                    amount: o
                                                } = l.variables;
                                                l.bets.length === 1 ? G.open((t ? ge : ce)({
                                                    count: 1,
                                                    currency: n,
                                                    amount: o
                                                })) : G.open((t ? $t : Vt)({
                                                    amount: o,
                                                    currency: n
                                                }))
                                            }
                                            N.replaceAll(e.data.bets)
                                        }
                                    },
                                    onError: {
                                        target: "idle"
                                    }
                                }
                            },
                            completedBet: {
                                exit: () => {
                                    N.removeBetResponses()
                                },
                                on: {
                                    TO_SINGLE: {
                                        actions: "removeAllBets",
                                        target: "#single"
                                    },
                                    RETAIN_SELECTION: {
                                        target: "idle"
                                    },
                                    RETAIN_FAILED_SELECTION: {
                                        target: "idle"
                                    },
                                    CLEAR_SELECTION: {
                                        actions: "removeAllBets",
                                        target: "idle"
                                    },
                                    ADD_BET: {
                                        actions: ["removeAllBets", "addBet"],
                                        target: "idle"
                                    },
                                    REMOVE_BET: {
                                        actions: "removeAllBets",
                                        target: "idle"
                                    },
                                    REPLACE_BETS: {
                                        actions: ["replaceBets", "switchToBetSlip"],
                                        target: "idle"
                                    }
                                }
                            },
                            disconnected: {
                                id: "#multi.disconnected",
                                ...ve
                            }
                        }
                    }
                }
            }
        }
    },
    Re = $e(dl, {
        services: {
            placeMultiBet: Je,
            placeSingleBet: Xe
        },
        guards: _l,
        actions: al
    }),
    Fe = xe(Re, {
        deferEvents: !0
    });
Fe.onTransition(s => {
    s.changed && Oe.set(s.value)
});
Oe.set(Re.initialState.value);
Fe.start();
export {
    Ae as M, Nl as O, Ie as a, pt as b, Ne as c, _t as o, Fe as s
};