import {
    s as Y,
    e as N,
    O as U,
    d as b,
    f as $,
    P,
    i as c,
    F as E,
    j as h,
    k as C,
    t as H,
    h as G,
    l as Z,
    c as re,
    m as B,
    V as A,
    n as ce,
    I as R,
    a as ue,
    u as de,
    g as me,
    b as fe,
    w as bt,
    a1 as At,
    o as Lt
} from "./scheduler.DXu26z7T.js";
import {
    S as x,
    i as ee,
    c as y,
    a as T,
    m as D,
    t as k,
    g as z,
    b as v,
    e as W,
    d as M
} from "./index.Dz_MmNB3.js";
import {
    e as Q,
    u as se,
    o as oe
} from "./each.DvgCmocI.js";
import {
    L as ie
} from "./index.DJurAkTj.js";
import {
    g as Fe
} from "./context.BYnTbg5S.js";
import {
    b as Ut,
    c as $t,
    d as Ne
} from "./fixture.DfNw968C.js";
import {
    h as Pt,
    i as wt,
    _ as ke,
    bd as yt,
    bZ as Se,
    N as Tt,
    A as Dt,
    Z as qt,
    aK as $e,
    bp as jt
} from "./index.B4-7gKq3.js";
import "./index.ByMdEFI5.js";
import {
    A as zt
} from "./ArrowTailForward.B3djnWLZ.js";
import {
    a as ve
} from "./index.Cn-rinD1.js";
import {
    g as Mt,
    a as Et,
    P as we,
    b as ye,
    c as Te,
    d as Wt
} from "./group.DFY3aPRQ.js";
import {
    F as Rt,
    a as It,
    m as ne
} from "./index.BBjbzRMH.js";
import {
    P as X
} from "./index.B1KDSkU5.js";
import {
    g as Kt
} from "./index.CUgLGuIE.js";
import {
    T as le
} from "./index.D7nbRHfU.js";
import {
    S as Ht
} from "./SportBetOutcome.GMTGMAV5.js";
import {
    T as he
} from "./index.CTIl3dBv.js";
import {
    a as Gt
} from "./index.CY6-K88d.js";
import {
    w as Zt
} from "./index.C2-CG2CN.js";
import {
    T as De
} from "./index.rqxo2ccV.js";
import {
    L as Jt
} from "./Lock.CRzw2MJX.js";
import {
    F as Qt
} from "./index.DCTjP2Ha.js";

function Xt(s) {
    let e, i;
    return {
        c() {
            e = N("span"), i = H(s[1])
        },
        l(t) {
            e = b(t, "SPAN", {});
            var n = $(e);
            i = G(n, s[1]), n.forEach(c)
        },
        m(t, n) {
            h(t, e, n), C(e, i)
        },
        p(t, n) {
            n & 2 && Z(i, t[1])
        },
        d(t) {
            t && c(e)
        }
    }
}

function Me(s) {
    let e, i;
    return e = new zt({
        props: {
            style: "transform: scale(0.7);"
        }
    }), {
        c() {
            y(e.$$.fragment)
        },
        l(t) {
            T(e.$$.fragment, t)
        },
        m(t, n) {
            D(e, t, n), i = !0
        },
        i(t) {
            i || (k(e.$$.fragment, t), i = !0)
        },
        o(t) {
            v(e.$$.fragment, t), i = !1
        },
        d(t) {
            M(e, t)
        }
    }
}

function Yt(s) {
    let e, i, t, n;
    i = new ie({
        props: {
            active: !1,
            variant: "subtle-link",
            size: "sm",
            to: s[0],
            $$slots: {
                default: [Xt]
            },
            $$scope: {
                ctx: s
            }
        }
    });
    let l = !s[2] && Me();
    return {
        c() {
            e = N("li"), y(i.$$.fragment), t = U(), l && l.c(), this.h()
        },
        l(a) {
            e = b(a, "LI", {
                class: !0
            });
            var r = $(e);
            T(i.$$.fragment, r), t = P(r), l && l.l(r), r.forEach(c), this.h()
        },
        h() {
            E(e, "class", "svelte-7s0pqi")
        },
        m(a, r) {
            h(a, e, r), D(i, e, null), C(e, t), l && l.m(e, null), n = !0
        },
        p(a, [r]) {
            const o = {};
            r & 1 && (o.to = a[0]), r & 10 && (o.$$scope = {
                dirty: r,
                ctx: a
            }), i.$set(o), a[2] ? l && (z(), v(l, 1, 1, () => {
                l = null
            }), W()) : l ? r & 4 && k(l, 1) : (l = Me(), l.c(), k(l, 1), l.m(e, null))
        },
        i(a) {
            n || (k(i.$$.fragment, a), k(l), n = !0)
        },
        o(a) {
            v(i.$$.fragment, a), v(l), n = !1
        },
        d(a) {
            a && c(e), M(i), l && l.d()
        }
    }
}

function xt(s, e, i) {
    let {
        url: t
    } = e, {
        name: n
    } = e, {
        isLast: l
    } = e;
    return s.$$set = a => {
        "url" in a && i(0, t = a.url), "name" in a && i(1, n = a.name), "isLast" in a && i(2, l = a.isLast)
    }, [t, n, l]
}
class Vt extends x {
    constructor(e) {
        super(), ee(this, e, xt, Yt, Y, {
            url: 0,
            name: 1,
            isLast: 2
        })
    }
}
const Ee = {
    outrights: Pt._("Outrights")
};

function Ie(s, e, i) {
    const t = s.slice();
    return t[7] = e[i], t[9] = i, t
}

function Ve(s, e) {
    let i, t, n;
    return t = new Vt({
        props: {
            url: e[5](e[9]),
            name: e[7].name,
            isLast: e[0] ? !1 : e[1] || e[2].length - 1 === e[9]
        }
    }), {
        key: s,
        first: null,
        c() {
            i = B(), y(t.$$.fragment), this.h()
        },
        l(l) {
            i = B(), T(t.$$.fragment, l), this.h()
        },
        h() {
            this.first = i
        },
        m(l, a) {
            h(l, i, a), D(t, l, a), n = !0
        },
        p(l, a) {
            e = l;
            const r = {};
            a & 8 && (r.url = e[5](e[9])), a & 8 && (r.name = e[7].name), a & 15 && (r.isLast = e[0] ? !1 : e[1] || e[2].length - 1 === e[9]), t.$set(r)
        },
        i(l) {
            n || (k(t.$$.fragment, l), n = !0)
        },
        o(l) {
            v(t.$$.fragment, l), n = !1
        },
        d(l) {
            l && c(i), M(t, l)
        }
    }
}

function Ce(s) {
    let e, i;
    return e = new Vt({
        props: {
            url: s[0],
            name: s[4]._(Ee.outrights),
            isLast: !0
        }
    }), {
        c() {
            y(e.$$.fragment)
        },
        l(t) {
            T(e.$$.fragment, t)
        },
        m(t, n) {
            D(e, t, n), i = !0
        },
        p(t, n) {
            const l = {};
            n & 1 && (l.url = t[0]), n & 16 && (l.name = t[4]._(Ee.outrights)), e.$set(l)
        },
        i(t) {
            i || (k(e.$$.fragment, t), i = !0)
        },
        o(t) {
            v(e.$$.fragment, t), i = !1
        },
        d(t) {
            M(e, t)
        }
    }
}

function ei(s) {
    let e, i, t = [],
        n = new Map,
        l, a, r = Q(s[3]);
    const o = d => d[9];
    for (let d = 0; d < r.length; d += 1) {
        let f = Ie(s, r, d),
            m = o(f);
        n.set(m, t[d] = Ve(m, f))
    }
    let u = s[0] && Ce(s);
    return {
        c() {
            e = N("div"), i = N("ul");
            for (let d = 0; d < t.length; d += 1) t[d].c();
            l = U(), u && u.c(), this.h()
        },
        l(d) {
            e = b(d, "DIV", {
                class: !0
            });
            var f = $(e);
            i = b(f, "UL", {
                class: !0
            });
            var m = $(i);
            for (let _ = 0; _ < t.length; _ += 1) t[_].l(m);
            l = P(m), u && u.l(m), m.forEach(c), f.forEach(c), this.h()
        },
        h() {
            E(i, "class", "breadcrumb svelte-g9g3ep"), E(e, "class", "wrapper svelte-g9g3ep")
        },
        m(d, f) {
            h(d, e, f), C(e, i);
            for (let m = 0; m < t.length; m += 1) t[m] && t[m].m(i, null);
            C(i, l), u && u.m(i, null), a = !0
        },
        p(d, [f]) {
            f & 47 && (r = Q(d[3]), z(), t = se(t, f, o, 1, d, r, n, i, oe, Ve, l, Ie), W()), d[0] ? u ? (u.p(d, f), f & 1 && k(u, 1)) : (u = Ce(d), u.c(), k(u, 1), u.m(i, null)) : u && (z(), v(u, 1, 1, () => {
                u = null
            }), W())
        },
        i(d) {
            if (!a) {
                for (let f = 0; f < r.length; f += 1) k(t[f]);
                k(u), a = !0
            }
        },
        o(d) {
            for (let f = 0; f < t.length; f += 1) v(t[f]);
            v(u), a = !1
        },
        d(d) {
            d && c(e);
            for (let f = 0; f < t.length; f += 1) t[f].d();
            u && u.d()
        }
    }
}

function ti(s, e, i) {
    let t, n;
    re(s, wt, d => i(4, n = d));
    let {
        outrightUrl: l = ""
    } = e, {
        mobileView: a = !1
    } = e, {
        list: r
    } = e, {
        sportType: o = "sport"
    } = e;
    const u = d => Ut(a ? r.map(f => f.slug) : r.slice(0, d + 1).map(f => f.slug), o);
    return s.$$set = d => {
        "outrightUrl" in d && i(0, l = d.outrightUrl), "mobileView" in d && i(1, a = d.mobileView), "list" in d && i(2, r = d.list), "sportType" in d && i(6, o = d.sportType)
    }, s.$$.update = () => {
        s.$$.dirty & 6 && i(3, t = a ? r.slice(r.length - 1) : r)
    }, [l, a, r, t, n, u, o]
}
class Ct extends x {
    constructor(e) {
        super(), ee(this, e, ti, ei, Y, {
            outrightUrl: 0,
            mobileView: 1,
            list: 2,
            sportType: 6
        })
    }
}

function ii(s) {
    let e;
    return {
        c() {
            e = H(s[5])
        },
        l(i) {
            e = G(i, s[5])
        },
        m(i, t) {
            h(i, e, t)
        },
        p: ce,
        d(i) {
            i && c(e)
        }
    }
}

function ni(s) {
    let e, i = s[0].marketCount + "",
        t;
    return {
        c() {
            e = H("+"), t = H(i)
        },
        l(n) {
            e = G(n, "+"), t = G(n, i)
        },
        m(n, l) {
            h(n, e, l), h(n, t, l)
        },
        p(n, l) {
            l & 1 && i !== (i = n[0].marketCount + "") && Z(t, i)
        },
        d(n) {
            n && (c(e), c(t))
        }
    }
}

function li(s) {
    let e, i, t, n, l, a, r, o, u, d, f;
    return n = new ie({
        props: {
            variant: "link",
            to: s[3],
            class: "mb-1",
            $$slots: {
                default: [ii]
            },
            $$scope: {
                ctx: s
            }
        }
    }), r = new Ct({
        props: {
            list: s[2],
            outrightUrl: s[3],
            mobileView: s[1]
        }
    }), d = new ie({
        props: {
            variant: "subtle-link",
            to: s[3],
            $$slots: {
                default: [ni]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            e = N("div"), i = N("div"), t = N("span"), y(n.$$.fragment), l = U(), a = N("div"), y(r.$$.fragment), o = U(), u = N("span"), y(d.$$.fragment), this.h()
        },
        l(m) {
            e = b(m, "DIV", {
                class: !0
            });
            var _ = $(e);
            i = b(_, "DIV", {});
            var g = $(i);
            t = b(g, "SPAN", {
                class: !0
            });
            var p = $(t);
            T(n.$$.fragment, p), p.forEach(c), l = P(g), a = b(g, "DIV", {
                class: !0
            });
            var w = $(a);
            T(r.$$.fragment, w), w.forEach(c), g.forEach(c), o = P(_), u = b(_, "SPAN", {
                class: !0
            });
            var F = $(u);
            T(d.$$.fragment, F), F.forEach(c), _.forEach(c), this.h()
        },
        h() {
            E(t, "class", "name svelte-6rcll6"), E(a, "class", "breadcrumb svelte-6rcll6"), E(u, "class", "market-count svelte-6rcll6"), E(e, "class", "outright-preview svelte-6rcll6"), A(e, "stacked", s[1])
        },
        m(m, _) {
            h(m, e, _), C(e, i), C(i, t), D(n, t, null), C(i, l), C(i, a), D(r, a, null), C(e, o), C(e, u), D(d, u, null), f = !0
        },
        p(m, [_]) {
            const g = {};
            _ & 64 && (g.$$scope = {
                dirty: _,
                ctx: m
            }), n.$set(g);
            const p = {};
            _ & 2 && (p.mobileView = m[1]), r.$set(p);
            const w = {};
            _ & 65 && (w.$$scope = {
                dirty: _,
                ctx: m
            }), d.$set(w), (!f || _ & 2) && A(e, "stacked", m[1])
        },
        i(m) {
            f || (k(n.$$.fragment, m), k(r.$$.fragment, m), k(d.$$.fragment, m), f = !0)
        },
        o(m) {
            v(n.$$.fragment, m), v(r.$$.fragment, m), v(d.$$.fragment, m), f = !1
        },
        d(m) {
            m && c(e), M(n), M(r), M(d)
        }
    }
}

function ai(s, e, i) {
    var u, d;
    let t, {
        fixture: n
    } = e;
    const l = $t(n.tournament),
        a = Ne(n);
    let r = Fe();
    re(s, r, f => i(1, t = f));
    let o = ((u = n.data) == null ? void 0 : u.__typename) !== "SportFixtureDataMatch" ? (d = n.data) == null ? void 0 : d.name : "";
    return s.$$set = f => {
        "fixture" in f && i(0, n = f.fixture)
    }, [n, t, l, a, r, o]
}
class Ot extends x {
    constructor(e) {
        super(), ee(this, e, ai, li, Y, {
            fixture: 0
        })
    }
}

function ri(s) {
    let e, i, t, n, l, a, r, o;
    return n = new X({
        props: {
            width: "8ch",
            height: "1.05em"
        }
    }), r = new X({
        props: {
            width: "3ch",
            height: "1em"
        }
    }), {
        c() {
            e = N("button"), i = N("div"), t = N("div"), y(n.$$.fragment), l = U(), a = N("div"), y(r.$$.fragment), this.h()
        },
        l(u) {
            e = b(u, "BUTTON", {
                class: !0
            });
            var d = $(e);
            i = b(d, "DIV", {
                class: !0
            });
            var f = $(i);
            t = b(f, "DIV", {
                class: !0
            });
            var m = $(t);
            T(n.$$.fragment, m), m.forEach(c), l = P(f), a = b(f, "DIV", {
                class: !0
            });
            var _ = $(a);
            T(r.$$.fragment, _), _.forEach(c), f.forEach(c), d.forEach(c), this.h()
        },
        h() {
            E(t, "class", "name loading svelte-1yo4ude"), E(a, "class", "odds loading svelte-1yo4ude"), E(i, "class", "outcome-content loading svelte-1yo4ude"), A(i, "horizontal", s[0]), E(e, "class", "outcome svelte-1yo4ude"), A(e, "stacked", s[0])
        },
        m(u, d) {
            h(u, e, d), C(e, i), C(i, t), D(n, t, null), C(i, l), C(i, a), D(r, a, null), o = !0
        },
        p(u, [d]) {
            (!o || d & 1) && A(i, "horizontal", u[0]), (!o || d & 1) && A(e, "stacked", u[0])
        },
        i(u) {
            o || (k(n.$$.fragment, u), k(r.$$.fragment, u), o = !0)
        },
        o(u) {
            v(n.$$.fragment, u), v(r.$$.fragment, u), o = !1
        },
        d(u) {
            u && c(e), M(n), M(r)
        }
    }
}

function si(s, e, i) {
    let {
        stacked: t = !1
    } = e;
    return s.$$set = n => {
        "stacked" in n && i(0, t = n.stacked)
    }, [t]
}
class oi extends x {
    constructor(e) {
        super(), ee(this, e, si, ri, Y, {
            stacked: 0
        })
    }
}

function Oe(s, e, i) {
    const t = s.slice();
    return t[6] = e[i], t
}

function Be(s, e) {
    let i, t, n;
    return t = new oi({
        props: {
            stacked: !1
        }
    }), {
        key: s,
        first: null,
        c() {
            i = B(), y(t.$$.fragment), this.h()
        },
        l(l) {
            i = B(), T(t.$$.fragment, l), this.h()
        },
        h() {
            this.first = i
        },
        m(l, a) {
            h(l, i, a), D(t, l, a), n = !0
        },
        p(l, a) {},
        i(l) {
            n || (k(t.$$.fragment, l), n = !0)
        },
        o(l) {
            v(t.$$.fragment, l), n = !1
        },
        d(l) {
            l && c(i), M(t, l)
        }
    }
}

function ui(s) {
    let e, i, t, n, l, a = [],
        r = new Map,
        o;
    t = new X({
        props: {
            width: "6ch",
            height: "0.8rem"
        }
    });
    let u = Q(ke.range(0, s[0]));
    const d = f => f[6];
    for (let f = 0; f < u.length; f += 1) {
        let m = Oe(s, u, f),
            _ = d(m);
        r.set(_, a[f] = Be(_))
    }
    return {
        c() {
            e = N("div"), i = N("div"), y(t.$$.fragment), n = U(), l = N("div");
            for (let f = 0; f < a.length; f += 1) a[f].c();
            this.h()
        },
        l(f) {
            e = b(f, "DIV", {
                class: !0,
                style: !0
            });
            var m = $(e);
            i = b(m, "DIV", {
                style: !0
            });
            var _ = $(i);
            T(t.$$.fragment, _), _.forEach(c), m.forEach(c), n = P(f), l = b(f, "DIV", {
                class: !0,
                style: !0
            });
            var g = $(l);
            for (let p = 0; p < a.length; p += 1) a[p].l(g);
            g.forEach(c), this.h()
        },
        h() {
            R(i, "text-align", "center"), R(i, "margin-top", s[1] ? "var(--space-1)" : "0"), E(e, "class", "market-name svelte-19bjww6"), R(e, "--area", "marketName" + (s[3] || 0)), A(e, "light", s[4]), E(l, "class", "outcomes svelte-19bjww6"), R(l, "--area", "outcomes" + (s[3] || 0)), A(l, "stacked", s[2] && !s[1])
        },
        m(f, m) {
            h(f, e, m), C(e, i), D(t, i, null), h(f, n, m), h(f, l, m);
            for (let _ = 0; _ < a.length; _ += 1) a[_] && a[_].m(l, null);
            o = !0
        },
        p(f, [m]) {
            (!o || m & 2) && R(i, "margin-top", f[1] ? "var(--space-1)" : "0"), (!o || m & 8) && R(e, "--area", "marketName" + (f[3] || 0)), (!o || m & 16) && A(e, "light", f[4]), m & 1 && (u = Q(ke.range(0, f[0])), z(), a = se(a, m, d, 1, f, u, r, l, oe, Be, null, Oe), W()), (!o || m & 8) && R(l, "--area", "outcomes" + (f[3] || 0)), (!o || m & 6) && A(l, "stacked", f[2] && !f[1])
        },
        i(f) {
            if (!o) {
                k(t.$$.fragment, f);
                for (let m = 0; m < u.length; m += 1) k(a[m]);
                o = !0
            }
        },
        o(f) {
            v(t.$$.fragment, f);
            for (let m = 0; m < a.length; m += 1) v(a[m]);
            o = !1
        },
        d(f) {
            f && (c(e), c(n), c(l)), M(t);
            for (let m = 0; m < a.length; m += 1) a[m].d()
        }
    }
}

function di(s, e, i) {
    let t, {
            outcomeCount: n
        } = e,
        {
            stacked: l = !1
        } = e,
        {
            isMulti: a
        } = e,
        {
            variant: r
        } = e,
        {
            index: o
        } = e;
    return s.$$set = u => {
        "outcomeCount" in u && i(0, n = u.outcomeCount), "stacked" in u && i(1, l = u.stacked), "isMulti" in u && i(2, a = u.isMulti), "variant" in u && i(5, r = u.variant), "index" in u && i(3, o = u.index)
    }, s.$$.update = () => {
        s.$$.dirty & 32 && i(4, t = r === "light")
    }, [n, l, a, o, t, r]
}
class mi extends x {
    constructor(e) {
        super(), ee(this, e, di, ui, Y, {
            outcomeCount: 0,
            stacked: 1,
            isMulti: 2,
            variant: 5,
            index: 3
        })
    }
}

function Ae(s, e, i) {
    const t = s.slice();
    return t[10] = e[i], t
}

function Le(s) {
    let e, i, t, n, l;
    return i = new X({
        props: {
            width: "2ch",
            style: "margin-right: 0.1rem"
        }
    }), n = new X({
        props: {
            width: "2ch"
        }
    }), {
        c() {
            e = N("div"), y(i.$$.fragment), t = U(), y(n.$$.fragment), this.h()
        },
        l(a) {
            e = b(a, "DIV", {
                style: !0
            });
            var r = $(e);
            T(i.$$.fragment, r), t = P(r), T(n.$$.fragment, r), r.forEach(c), this.h()
        },
        h() {
            R(e, "grid-area", "marketCount"), R(e, "margin", "0 0 0 auto"), A(e, "light", s[5])
        },
        m(a, r) {
            h(a, e, r), D(i, e, null), C(e, t), D(n, e, null), l = !0
        },
        p(a, r) {
            (!l || r & 32) && A(e, "light", a[5])
        },
        i(a) {
            l || (k(i.$$.fragment, a), k(n.$$.fragment, a), l = !0)
        },
        o(a) {
            v(i.$$.fragment, a), v(n.$$.fragment, a), l = !1
        },
        d(a) {
            a && c(e), M(i), M(n)
        }
    }
}

function Ue(s) {
    let e;
    return {
        c() {
            e = N("div"), this.h()
        },
        l(i) {
            e = b(i, "DIV", {
                class: !0,
                style: !0
            }), $(e).forEach(c), this.h()
        },
        h() {
            E(e, "class", "line svelte-id4nl7"), R(e, "grid-area", "line"), A(e, "light", s[5])
        },
        m(i, t) {
            h(i, e, t)
        },
        p(i, t) {
            t & 32 && A(e, "light", i[5])
        },
        d(i) {
            i && c(e)
        }
    }
}

function Pe(s) {
    let e;
    return {
        c() {
            e = N("div"), this.h()
        },
        l(i) {
            e = b(i, "DIV", {
                class: !0,
                style: !0
            }), $(e).forEach(c), this.h()
        },
        h() {
            E(e, "class", "line svelte-id4nl7"), R(e, "grid-area", "line2"), A(e, "light", s[5])
        },
        m(i, t) {
            h(i, e, t)
        },
        p(i, t) {
            t & 32 && A(e, "light", i[5])
        },
        d(i) {
            i && c(e)
        }
    }
}

function fi(s) {
    let e, i, t, n, l, a, r, o, u, d, f;
    t = new X({
        props: {
            width: "10ch",
            height: "1rem"
        }
    }), a = new X({
        props: {
            width: "10ch",
            height: "1rem"
        }
    });
    let m = !s[4] && qe(),
        _ = (s[2] || s[3]) && je(),
        g = !s[3] && s[4] === !1 && ze();
    return {
        c() {
            e = N("div"), i = N("div"), y(t.$$.fragment), n = U(), l = N("div"), y(a.$$.fragment), r = U(), m && m.c(), o = U(), _ && _.c(), u = U(), g && g.c(), d = B(), this.h()
        },
        l(p) {
            e = b(p, "DIV", {
                class: !0
            });
            var w = $(e);
            i = b(w, "DIV", {});
            var F = $(i);
            T(t.$$.fragment, F), F.forEach(c), n = P(w), l = b(w, "DIV", {
                style: !0
            });
            var I = $(l);
            T(a.$$.fragment, I), I.forEach(c), w.forEach(c), r = P(p), m && m.l(p), o = P(p), _ && _.l(p), u = P(p), g && g.l(p), d = B(), this.h()
        },
        h() {
            R(l, "margin-top", "0.5rem"), E(e, "class", "teams stacked svelte-id4nl7")
        },
        m(p, w) {
            h(p, e, w), C(e, i), D(t, i, null), C(e, n), C(e, l), D(a, l, null), h(p, r, w), m && m.m(p, w), h(p, o, w), _ && _.m(p, w), h(p, u, w), g && g.m(p, w), h(p, d, w), f = !0
        },
        p(p, w) {
            p[4] ? m && (z(), v(m, 1, 1, () => {
                m = null
            }), W()) : m ? w & 16 && k(m, 1) : (m = qe(), m.c(), k(m, 1), m.m(o.parentNode, o)), p[2] || p[3] ? _ ? w & 12 && k(_, 1) : (_ = je(), _.c(), k(_, 1), _.m(u.parentNode, u)) : _ && (z(), v(_, 1, 1, () => {
                _ = null
            }), W()), !p[3] && p[4] === !1 ? g ? w & 24 && k(g, 1) : (g = ze(), g.c(), k(g, 1), g.m(d.parentNode, d)) : g && (z(), v(g, 1, 1, () => {
                g = null
            }), W())
        },
        i(p) {
            f || (k(t.$$.fragment, p), k(a.$$.fragment, p), k(m), k(_), k(g), f = !0)
        },
        o(p) {
            v(t.$$.fragment, p), v(a.$$.fragment, p), v(m), v(_), v(g), f = !1
        },
        d(p) {
            p && (c(e), c(r), c(o), c(u), c(d)), M(t), M(a), m && m.d(p), _ && _.d(p), g && g.d(p)
        }
    }
}

function ci(s) {
    let e, i, t, n, l;
    return t = new X({
        props: {
            width: 6 + Math.floor(Math.random() * 8) + "ch",
            height: "1.1rem"
        }
    }), {
        c() {
            e = N("div"), i = N("div"), y(t.$$.fragment), this.h()
        },
        l(a) {
            e = b(a, "DIV", {
                class: !0,
                style: !0
            });
            var r = $(e);
            i = b(r, "DIV", {
                class: !0,
                style: !0
            });
            var o = $(i);
            T(t.$$.fragment, o), o.forEach(c), r.forEach(c), this.h()
        },
        h() {
            E(i, "class", "teams svelte-id4nl7"), R(i, "display", "flex"), E(e, "class", "fixture svelte-id4nl7"), E(e, "style", n = "display: flex; " + (s[3] ? "padding-bottom: var(--space-1);" : ""))
        },
        m(a, r) {
            h(a, e, r), C(e, i), D(t, i, null), l = !0
        },
        p(a, r) {
            (!l || r & 8 && n !== (n = "display: flex; " + (a[3] ? "padding-bottom: var(--space-1);" : ""))) && E(e, "style", n)
        },
        i(a) {
            l || (k(t.$$.fragment, a), l = !0)
        },
        o(a) {
            v(t.$$.fragment, a), l = !1
        },
        d(a) {
            a && c(e), M(t)
        }
    }
}

function qe(s) {
    let e, i, t, n, l, a, r, o, u, d, f;
    return t = new X({
        props: {
            width: "2ch"
        }
    }), l = new X({
        props: {
            width: "2ch"
        }
    }), o = new X({
        props: {
            width: "2ch"
        }
    }), d = new X({
        props: {
            width: "2ch"
        }
    }), {
        c() {
            e = N("div"), i = N("div"), y(t.$$.fragment), n = U(), y(l.$$.fragment), a = U(), r = N("div"), y(o.$$.fragment), u = U(), y(d.$$.fragment), this.h()
        },
        l(m) {
            e = b(m, "DIV", {
                class: !0
            });
            var _ = $(e);
            i = b(_, "DIV", {
                class: !0
            });
            var g = $(i);
            T(t.$$.fragment, g), n = P(g), T(l.$$.fragment, g), g.forEach(c), a = P(_), r = b(_, "DIV", {
                class: !0
            });
            var p = $(r);
            T(o.$$.fragment, p), u = P(p), T(d.$$.fragment, p), p.forEach(c), _.forEach(c), this.h()
        },
        h() {
            E(i, "class", "fixture-score-item svelte-id4nl7"), E(r, "class", "fixture-score-item svelte-id4nl7"), E(e, "class", "fixture-score fixture-score-loading svelte-id4nl7")
        },
        m(m, _) {
            h(m, e, _), C(e, i), D(t, i, null), C(i, n), D(l, i, null), C(e, a), C(e, r), D(o, r, null), C(r, u), D(d, r, null), f = !0
        },
        i(m) {
            f || (k(t.$$.fragment, m), k(l.$$.fragment, m), k(o.$$.fragment, m), k(d.$$.fragment, m), f = !0)
        },
        o(m) {
            v(t.$$.fragment, m), v(l.$$.fragment, m), v(o.$$.fragment, m), v(d.$$.fragment, m), f = !1
        },
        d(m) {
            m && c(e), M(t), M(l), M(o), M(d)
        }
    }
}

function je(s) {
    let e, i, t;
    return i = new X({
        props: {
            height: "1.1em",
            width: "25ch"
        }
    }), {
        c() {
            e = N("div"), y(i.$$.fragment), this.h()
        },
        l(n) {
            e = b(n, "DIV", {
                class: !0
            });
            var l = $(e);
            T(i.$$.fragment, l), l.forEach(c), this.h()
        },
        h() {
            E(e, "class", "breadcrumb svelte-id4nl7")
        },
        m(n, l) {
            h(n, e, l), D(i, e, null), t = !0
        },
        i(n) {
            t || (k(i.$$.fragment, n), t = !0)
        },
        o(n) {
            v(i.$$.fragment, n), t = !1
        },
        d(n) {
            n && c(e), M(i)
        }
    }
}

function ze(s) {
    let e, i, t;
    return i = new X({
        props: {
            width: "2ch"
        }
    }), {
        c() {
            e = N("div"), y(i.$$.fragment), this.h()
        },
        l(n) {
            e = b(n, "DIV", {
                class: !0
            });
            var l = $(e);
            T(i.$$.fragment, l), l.forEach(c), this.h()
        },
        h() {
            E(e, "class", "market-count svelte-id4nl7")
        },
        m(n, l) {
            h(n, e, l), D(i, e, null), t = !0
        },
        i(n) {
            t || (k(i.$$.fragment, n), t = !0)
        },
        o(n) {
            v(i.$$.fragment, n), t = !1
        },
        d(n) {
            n && c(e), M(i)
        }
    }
}

function We(s) {
    let e = [],
        i = new Map,
        t, n, l = Q(ke.range(0, s[9]));
    const a = r => r[10];
    for (let r = 0; r < l.length; r += 1) {
        let o = Ae(s, l, r),
            u = a(o);
        i.set(u, e[r] = Re(u, o))
    }
    return {
        c() {
            for (let r = 0; r < e.length; r += 1) e[r].c();
            t = B()
        },
        l(r) {
            for (let o = 0; o < e.length; o += 1) e[o].l(r);
            t = B()
        },
        m(r, o) {
            for (let u = 0; u < e.length; u += 1) e[u] && e[u].m(r, o);
            h(r, t, o), n = !0
        },
        p(r, o) {
            o & 531 && (l = Q(ke.range(0, r[9])), z(), e = se(e, o, a, 1, r, l, i, t.parentNode, oe, Re, t, Ae), W())
        },
        i(r) {
            if (!n) {
                for (let o = 0; o < l.length; o += 1) k(e[o]);
                n = !0
            }
        },
        o(r) {
            for (let o = 0; o < e.length; o += 1) v(e[o]);
            n = !1
        },
        d(r) {
            r && c(t);
            for (let o = 0; o < e.length; o += 1) e[o].d(r)
        }
    }
}

function Re(s, e) {
    let i, t, n;
    return t = new mi({
        props: {
            index: e[10],
            variant: e[1],
            stacked: e[4],
            isMulti: e[0],
            outcomeCount: 2
        }
    }), {
        key: s,
        first: null,
        c() {
            i = B(), y(t.$$.fragment), this.h()
        },
        l(l) {
            i = B(), T(t.$$.fragment, l), this.h()
        },
        h() {
            this.first = i
        },
        m(l, a) {
            h(l, i, a), D(t, l, a), n = !0
        },
        p(l, a) {
            e = l;
            const r = {};
            a & 2 && (r.variant = e[1]), a & 16 && (r.stacked = e[4]), a & 1 && (r.isMulti = e[0]), t.$set(r)
        },
        i(l) {
            n || (k(t.$$.fragment, l), n = !0)
        },
        o(l) {
            v(t.$$.fragment, l), n = !1
        },
        d(l) {
            l && c(i), M(t, l)
        }
    }
}

function ki(s) {
    let e, i, t, n, l, a, r, o, u, d, f;
    t = new X({
        props: {
            width: "13ch",
            height: "1.1rem",
            style: "margin-bottom: " + (s[4] ? "var(--space-2)" : "0")
        }
    });
    let m = s[4] && Le(s),
        _ = !s[3] && !s[0] && !s[4] && Ue(s),
        g = !s[3] && !s[0] && !s[4] && Pe(s);
    const p = [ci, fi],
        w = [];

    function F(S, V) {
        return S[4] || S[3] ? 0 : 1
    }
    o = F(s), u = w[o] = p[o](s);
    let I = !s[3] && We(s);
    return {
        c() {
            e = N("div"), i = N("div"), y(t.$$.fragment), n = U(), m && m.c(), l = U(), _ && _.c(), a = U(), g && g.c(), r = U(), u.c(), d = U(), I && I.c(), this.h()
        },
        l(S) {
            e = b(S, "DIV", {
                class: !0,
                style: !0
            });
            var V = $(e);
            i = b(V, "DIV", {
                style: !0
            });
            var L = $(i);
            T(t.$$.fragment, L), L.forEach(c), n = P(V), m && m.l(V), l = P(V), _ && _.l(V), a = P(V), g && g.l(V), r = P(V), u.l(V), d = P(V), I && I.l(V), V.forEach(c), this.h()
        },
        h() {
            R(i, "grid-area", "misc"), A(i, "light", s[5]), E(e, "class", "fixture-preview svelte-id4nl7"), R(e, "--areas", s[7]), R(e, "--column-count", s[6]), A(e, "stacked", s[4])
        },
        m(S, V) {
            h(S, e, V), C(e, i), D(t, i, null), C(e, n), m && m.m(e, null), C(e, l), _ && _.m(e, null), C(e, a), g && g.m(e, null), C(e, r), w[o].m(e, null), C(e, d), I && I.m(e, null), f = !0
        },
        p(S, [V]) {
            const L = {};
            V & 16 && (L.style = "margin-bottom: " + (S[4] ? "var(--space-2)" : "0")), t.$set(L), (!f || V & 32) && A(i, "light", S[5]), S[4] ? m ? (m.p(S, V), V & 16 && k(m, 1)) : (m = Le(S), m.c(), k(m, 1), m.m(e, l)) : m && (z(), v(m, 1, 1, () => {
                m = null
            }), W()), !S[3] && !S[0] && !S[4] ? _ ? _.p(S, V) : (_ = Ue(S), _.c(), _.m(e, a)) : _ && (_.d(1), _ = null), !S[3] && !S[0] && !S[4] ? g ? g.p(S, V) : (g = Pe(S), g.c(), g.m(e, r)) : g && (g.d(1), g = null);
            let J = o;
            o = F(S), o === J ? w[o].p(S, V) : (z(), v(w[J], 1, 1, () => {
                w[J] = null
            }), W(), u = w[o], u ? u.p(S, V) : (u = w[o] = p[o](S), u.c()), k(u, 1), u.m(e, d)), S[3] ? I && (z(), v(I, 1, 1, () => {
                I = null
            }), W()) : I ? (I.p(S, V), V & 8 && k(I, 1)) : (I = We(S), I.c(), k(I, 1), I.m(e, null)), (!f || V & 128) && R(e, "--areas", S[7]), (!f || V & 64) && R(e, "--column-count", S[6]), (!f || V & 16) && A(e, "stacked", S[4])
        },
        i(S) {
            f || (k(t.$$.fragment, S), k(m), k(u), k(I), f = !0)
        },
        o(S) {
            v(t.$$.fragment, S), v(m), v(u), v(I), f = !1
        },
        d(S) {
            S && c(e), M(t), m && m.d(), _ && _.d(), g && g.d(), w[o].d(), I && I.d()
        }
    }
}

function _i(s, e, i) {
    let t, n, l, a, r = Fe();
    re(s, r, _ => i(4, a = _));
    let {
        isMulti: o = !0
    } = e, {
        variant: u = "transparent"
    } = e, {
        displayBreadcrumb: d = !1
    } = e, {
        isSearchFixture: f = !1
    } = e;
    const m = o ? 3 : 1;
    return s.$$set = _ => {
        "isMulti" in _ && i(0, o = _.isMulti), "variant" in _ && i(1, u = _.variant), "displayBreadcrumb" in _ && i(2, d = _.displayBreadcrumb), "isSearchFixture" in _ && i(3, f = _.isSearchFixture)
    }, s.$$.update = () => {
        s.$$.dirty & 28 && i(7, t = Mt({
            stacked: a,
            marketsLength: m,
            displayBreadcrumb: d,
            isSearchFixture: f
        })), s.$$.dirty & 16 && i(6, n = Et(a, m)), s.$$.dirty & 2 && i(5, l = u === "light")
    }, [o, u, d, f, a, l, n, t, r, m]
}
class vi extends x {
    constructor(e) {
        super(), ee(this, e, _i, ki, Y, {
            isMulti: 0,
            variant: 1,
            displayBreadcrumb: 2,
            isSearchFixture: 3
        })
    }
}

function Ke(s) {
    var a, r, o;
    let e, i, t, n = s[2] && He(s),
        l = (((a = s[1]) == null ? void 0 : a.status) === "live" || ((r = s[1]) == null ? void 0 : r.status) === "suspended" || ((o = s[1]) == null ? void 0 : o.status) === "ended") && Ge(s);
    return {
        c() {
            e = N("div"), n && n.c(), i = U(), l && l.c(), this.h()
        },
        l(u) {
            e = b(u, "DIV", {
                class: !0
            });
            var d = $(e);
            n && n.l(d), i = P(d), l && l.l(d), d.forEach(c), this.h()
        },
        h() {
            E(e, "class", "fixture-score-wrapper svelte-qyo8l9")
        },
        m(u, d) {
            h(u, e, d), n && n.m(e, null), C(e, i), l && l.m(e, null), t = !0
        },
        p(u, d) {
            var f, m, _;
            u[2] ? n ? (n.p(u, d), d & 4 && k(n, 1)) : (n = He(u), n.c(), k(n, 1), n.m(e, i)) : n && (z(), v(n, 1, 1, () => {
                n = null
            }), W()), ((f = u[1]) == null ? void 0 : f.status) === "live" || ((m = u[1]) == null ? void 0 : m.status) === "suspended" || ((_ = u[1]) == null ? void 0 : _.status) === "ended" ? l ? (l.p(u, d), d & 2 && k(l, 1)) : (l = Ge(u), l.c(), k(l, 1), l.m(e, null)) : l && (z(), v(l, 1, 1, () => {
                l = null
            }), W())
        },
        i(u) {
            t || (k(n), k(l), t = !0)
        },
        o(u) {
            v(n), v(l), t = !1
        },
        d(u) {
            u && c(e), n && n.d(), l && l.d()
        }
    }
}

function He(s) {
    let e, i, t, n;
    const l = [pi, hi],
        a = [];

    function r(o, u) {
        var d, f;
        return ((f = (d = o[1]) == null ? void 0 : d.eventStatus) == null ? void 0 : f.__typename) === "EsportFixtureEventStatus" ? 0 : 1
    }
    return e = r(s), i = a[e] = l[e](s), {
        c() {
            i.c(), t = B()
        },
        l(o) {
            i.l(o), t = B()
        },
        m(o, u) {
            a[e].m(o, u), h(o, t, u), n = !0
        },
        p(o, u) {
            let d = e;
            e = r(o), e === d ? a[e].p(o, u) : (z(), v(a[d], 1, 1, () => {
                a[d] = null
            }), W(), i = a[e], i ? i.p(o, u) : (i = a[e] = l[e](o), i.c()), k(i, 1), i.m(t.parentNode, t))
        },
        i(o) {
            n || (k(i), n = !0)
        },
        o(o) {
            v(i), n = !1
        },
        d(o) {
            o && c(t), a[e].d(o)
        }
    }
}

function hi(s) {
    let e, i, t, n, l;
    return i = new le({
        props: {
            weight: "semibold",
            lineHeight: "none",
            $$slots: {
                default: [gi]
            },
            $$scope: {
                ctx: s
            }
        }
    }), n = new le({
        props: {
            weight: "semibold",
            lineHeight: "none",
            $$slots: {
                default: [Si]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            e = N("div"), y(i.$$.fragment), t = U(), y(n.$$.fragment), this.h()
        },
        l(a) {
            e = b(a, "DIV", {
                class: !0
            });
            var r = $(e);
            T(i.$$.fragment, r), t = P(r), T(n.$$.fragment, r), r.forEach(c), this.h()
        },
        h() {
            E(e, "class", "score-wrapper svelte-qyo8l9")
        },
        m(a, r) {
            h(a, e, r), D(i, e, null), C(e, t), D(n, e, null), l = !0
        },
        p(a, r) {
            const o = {};
            r & 264 && (o.$$scope = {
                dirty: r,
                ctx: a
            }), i.$set(o);
            const u = {};
            r & 264 && (u.$$scope = {
                dirty: r,
                ctx: a
            }), n.$set(u)
        },
        i(a) {
            l || (k(i.$$.fragment, a), k(n.$$.fragment, a), l = !0)
        },
        o(a) {
            v(i.$$.fragment, a), v(n.$$.fragment, a), l = !1
        },
        d(a) {
            a && c(e), M(i), M(n)
        }
    }
}

function pi(s) {
    let e, i, t, n, l;
    return i = new le({
        props: {
            weight: "semibold",
            lineHeight: "none",
            $$slots: {
                default: [Fi]
            },
            $$scope: {
                ctx: s
            }
        }
    }), n = new le({
        props: {
            weight: "semibold",
            lineHeight: "none",
            $$slots: {
                default: [Ni]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            e = N("div"), y(i.$$.fragment), t = U(), y(n.$$.fragment), this.h()
        },
        l(a) {
            e = b(a, "DIV", {
                class: !0
            });
            var r = $(e);
            T(i.$$.fragment, r), t = P(r), T(n.$$.fragment, r), r.forEach(c), this.h()
        },
        h() {
            E(e, "class", "score-wrapper svelte-qyo8l9")
        },
        m(a, r) {
            h(a, e, r), D(i, e, null), C(e, t), D(n, e, null), l = !0
        },
        p(a, r) {
            const o = {};
            r & 258 && (o.$$scope = {
                dirty: r,
                ctx: a
            }), i.$set(o);
            const u = {};
            r & 258 && (u.$$scope = {
                dirty: r,
                ctx: a
            }), n.$set(u)
        },
        i(a) {
            l || (k(i.$$.fragment, a), k(n.$$.fragment, a), l = !0)
        },
        o(a) {
            v(i.$$.fragment, a), v(n.$$.fragment, a), l = !1
        },
        d(a) {
            a && c(e), M(i), M(n)
        }
    }
}

function gi(s) {
    var t;
    let e = (typeof s[3] == "number" ? s[3] ? ? "" : ((t = s[3]) == null ? void 0 : t.homeScore) ? ? "") + "",
        i;
    return {
        c() {
            i = H(e)
        },
        l(n) {
            i = G(n, e)
        },
        m(n, l) {
            h(n, i, l)
        },
        p(n, l) {
            var a;
            l & 8 && e !== (e = (typeof n[3] == "number" ? n[3] ? ? "" : ((a = n[3]) == null ? void 0 : a.homeScore) ? ? "") + "") && Z(i, e)
        },
        d(n) {
            n && c(i)
        }
    }
}

function Si(s) {
    var t;
    let e = (typeof s[3] == "number" ? s[3] ? ? "" : ((t = s[3]) == null ? void 0 : t.awayScore) ? ? "") + "",
        i;
    return {
        c() {
            i = H(e)
        },
        l(n) {
            i = G(n, e)
        },
        m(n, l) {
            h(n, i, l)
        },
        p(n, l) {
            var a;
            l & 8 && e !== (e = (typeof n[3] == "number" ? n[3] ? ? "" : ((a = n[3]) == null ? void 0 : a.awayScore) ? ? "") + "") && Z(i, e)
        },
        d(n) {
            n && c(i)
        }
    }
}

function Fi(s) {
    var t, n, l, a;
    let e = (((n = (t = s[1].eventStatus) == null ? void 0 : t.scoreboard) == null ? void 0 : n.homeKills) ? ? ((a = (l = s[1].eventStatus) == null ? void 0 : l.scoreboard) == null ? void 0 : a.homeWonRounds) ? ? "") + "",
        i;
    return {
        c() {
            i = H(e)
        },
        l(r) {
            i = G(r, e)
        },
        m(r, o) {
            h(r, i, o)
        },
        p(r, o) {
            var u, d, f, m;
            o & 2 && e !== (e = (((d = (u = r[1].eventStatus) == null ? void 0 : u.scoreboard) == null ? void 0 : d.homeKills) ? ? ((m = (f = r[1].eventStatus) == null ? void 0 : f.scoreboard) == null ? void 0 : m.homeWonRounds) ? ? "") + "") && Z(i, e)
        },
        d(r) {
            r && c(i)
        }
    }
}

function Ni(s) {
    var t, n, l, a;
    let e = (((n = (t = s[1].eventStatus) == null ? void 0 : t.scoreboard) == null ? void 0 : n.awayKills) ? ? ((a = (l = s[1].eventStatus) == null ? void 0 : l.scoreboard) == null ? void 0 : a.awayWonRounds) ? ? "") + "",
        i;
    return {
        c() {
            i = H(e)
        },
        l(r) {
            i = G(r, e)
        },
        m(r, o) {
            h(r, i, o)
        },
        p(r, o) {
            var u, d, f, m;
            o & 2 && e !== (e = (((d = (u = r[1].eventStatus) == null ? void 0 : u.scoreboard) == null ? void 0 : d.awayKills) ? ? ((m = (f = r[1].eventStatus) == null ? void 0 : f.scoreboard) == null ? void 0 : m.awayWonRounds) ? ? "") + "") && Z(i, e)
        },
        d(r) {
            r && c(i)
        }
    }
}

function Ge(s) {
    let e, i, t, n, l;
    return i = new le({
        props: {
            variant: "warn",
            weight: "semibold",
            lineHeight: "none",
            $$slots: {
                default: [bi]
            },
            $$scope: {
                ctx: s
            }
        }
    }), n = new le({
        props: {
            variant: "warn",
            weight: "semibold",
            lineHeight: "none",
            $$slots: {
                default: [$i]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            e = N("div"), y(i.$$.fragment), t = U(), y(n.$$.fragment), this.h()
        },
        l(a) {
            e = b(a, "DIV", {
                class: !0
            });
            var r = $(e);
            T(i.$$.fragment, r), t = P(r), T(n.$$.fragment, r), r.forEach(c), this.h()
        },
        h() {
            E(e, "class", "score-wrapper live svelte-qyo8l9")
        },
        m(a, r) {
            h(a, e, r), D(i, e, null), C(e, t), D(n, e, null), l = !0
        },
        p(a, r) {
            const o = {};
            r & 288 && (o.$$scope = {
                dirty: r,
                ctx: a
            }), i.$set(o);
            const u = {};
            r & 272 && (u.$$scope = {
                dirty: r,
                ctx: a
            }), n.$set(u)
        },
        i(a) {
            l || (k(i.$$.fragment, a), k(n.$$.fragment, a), l = !0)
        },
        o(a) {
            v(i.$$.fragment, a), v(n.$$.fragment, a), l = !1
        },
        d(a) {
            a && c(e), M(i), M(n)
        }
    }
}

function bi(s) {
    let e;
    return {
        c() {
            e = H(s[5])
        },
        l(i) {
            e = G(i, s[5])
        },
        m(i, t) {
            h(i, e, t)
        },
        p(i, t) {
            t & 32 && Z(e, i[5])
        },
        d(i) {
            i && c(e)
        }
    }
}

function $i(s) {
    let e;
    return {
        c() {
            e = H(s[4])
        },
        l(i) {
            e = G(i, s[4])
        },
        m(i, t) {
            h(i, e, t)
        },
        p(i, t) {
            t & 16 && Z(e, i[4])
        },
        d(i) {
            i && c(e)
        }
    }
}

function wi(s) {
    let e, i, t = !s[0] && s[6] !== "none" && Ke(s);
    return {
        c() {
            t && t.c(), e = B()
        },
        l(n) {
            t && t.l(n), e = B()
        },
        m(n, l) {
            t && t.m(n, l), h(n, e, l), i = !0
        },
        p(n, [l]) {
            !n[0] && n[6] !== "none" ? t ? (t.p(n, l), l & 1 && k(t, 1)) : (t = Ke(n), t.c(), k(t, 1), t.m(e.parentNode, e)) : t && (z(), v(t, 1, 1, () => {
                t = null
            }), W())
        },
        i(n) {
            i || (k(t), i = !0)
        },
        o(n) {
            v(t), i = !1
        },
        d(n) {
            n && c(e), t && t.d(n)
        }
    }
}

function yi(s, e, i) {
    let t, n, l, a, r, {
            stacked: o = !1
        } = e,
        {
            fixture: u
        } = e,
        d = Kt(u.tournament.category.sport.slug, "scoring").preview;
    return s.$$set = f => {
        "stacked" in f && i(0, o = f.stacked), "fixture" in f && i(1, u = f.fixture)
    }, s.$$.update = () => {
        var f, m, _;
        s.$$.dirty & 2 && i(5, t = ((f = u == null ? void 0 : u.eventStatus) == null ? void 0 : f.homeScore) ? ? ""), s.$$.dirty & 2 && i(4, n = ((m = u == null ? void 0 : u.eventStatus) == null ? void 0 : m.awayScore) ? ? ""), s.$$.dirty & 2 && i(7, l = d === "periods" ? (_ = u == null ? void 0 : u.eventStatus) == null ? void 0 : _.periodScores : void 0), s.$$.dirty & 128 && i(3, a = l ? l[l.length - 1] : 0), s.$$.dirty & 130 && i(2, r = d === "periods" && l !== null && ((u == null ? void 0 : u.status) === "live" || (u == null ? void 0 : u.status) === "suspended" || (u == null ? void 0 : u.status) === "ended"))
    }, [o, u, r, a, n, t, d, l]
}
class Ti extends x {
    constructor(e) {
        super(), ee(this, e, yi, wi, Y, {
            stacked: 0,
            fixture: 1
        })
    }
}

function Di(s) {
    let e, i, t, n, l = s[11].includes("line"),
        a, r = s[11].includes("line2"),
        o, u, d, f, m = s[11].includes("breadcrumb"),
        _, g, p;
    t = new Rt({
        props: {
            showFullDate: s[1],
            fixture: s[0],
            stacked: s[2]
        }
    });
    let w = l && Ze(s),
        F = r && Je(s);
    const I = [Ii, Ei],
        S = [];

    function V(O, q) {
        return O[2] || O[5] ? 0 : 1
    }
    u = V(s), d = S[u] = I[u](s);
    let L = m && tt(s);
    const J = s[18].default,
        j = ue(J, s, s[19], null);
    let K = !s[5] && it(s);
    return {
        c() {
            e = N("div"), i = N("div"), y(t.$$.fragment), n = U(), w && w.c(), a = U(), F && F.c(), o = U(), d.c(), f = U(), L && L.c(), _ = U(), j && j.c(), g = U(), K && K.c(), this.h()
        },
        l(O) {
            e = b(O, "DIV", {
                class: !0,
                "data-test": !0,
                style: !0
            });
            var q = $(e);
            i = b(q, "DIV", {
                class: !0
            });
            var te = $(i);
            T(t.$$.fragment, te), te.forEach(c), n = P(q), w && w.l(q), a = P(q), F && F.l(q), o = P(q), d.l(q), f = P(q), L && L.l(q), _ = P(q), j && j.l(q), g = P(q), K && K.l(q), q.forEach(c), this.h()
        },
        h() {
            E(i, "class", "misc svelte-9txh06"), A(i, "light", s[9]), E(e, "class", "fixture-preview svelte-9txh06"), E(e, "data-test", "fixture-preview"), R(e, "--areas", s[11]), R(e, "--column-count", s[10]), A(e, "stacked", s[2])
        },
        m(O, q) {
            h(O, e, q), C(e, i), D(t, i, null), C(e, n), w && w.m(e, null), C(e, a), F && F.m(e, null), C(e, o), S[u].m(e, null), C(e, f), L && L.m(e, null), C(e, _), j && j.m(e, null), C(e, g), K && K.m(e, null), p = !0
        },
        p(O, q) {
            const te = {};
            q & 2 && (te.showFullDate = O[1]), q & 1 && (te.fixture = O[0]), q & 4 && (te.stacked = O[2]), t.$set(te), (!p || q & 512) && A(i, "light", O[9]), q & 2048 && (l = O[11].includes("line")), l ? w ? w.p(O, q) : (w = Ze(O), w.c(), w.m(e, a)) : w && (w.d(1), w = null), q & 2048 && (r = O[11].includes("line2")), r ? F ? F.p(O, q) : (F = Je(O), F.c(), F.m(e, o)) : F && (F.d(1), F = null);
            let pe = u;
            u = V(O), u === pe ? S[u].p(O, q) : (z(), v(S[pe], 1, 1, () => {
                S[pe] = null
            }), W(), d = S[u], d ? d.p(O, q) : (d = S[u] = I[u](O), d.c()), k(d, 1), d.m(e, f)), q & 2048 && (m = O[11].includes("breadcrumb")), m ? L ? (L.p(O, q), q & 2048 && k(L, 1)) : (L = tt(O), L.c(), k(L, 1), L.m(e, _)) : L && (z(), v(L, 1, 1, () => {
                L = null
            }), W()), j && j.p && (!p || q & 524288) && de(j, J, O, O[19], p ? fe(J, O[19], q, null) : me(O[19]), null), O[5] ? K && (z(), v(K, 1, 1, () => {
                K = null
            }), W()) : K ? (K.p(O, q), q & 32 && k(K, 1)) : (K = it(O), K.c(), k(K, 1), K.m(e, null)), (!p || q & 2048) && R(e, "--areas", O[11]), (!p || q & 1024) && R(e, "--column-count", O[10]), (!p || q & 4) && A(e, "stacked", O[2])
        },
        i(O) {
            p || (k(t.$$.fragment, O), k(d), k(L), k(j, O), k(K), p = !0)
        },
        o(O) {
            v(t.$$.fragment, O), v(d), v(L), v(j, O), v(K), p = !1
        },
        d(O) {
            O && c(e), M(t), w && w.d(), F && F.d(), S[u].d(), L && L.d(), j && j.d(O), K && K.d()
        }
    }
}

function Mi(s) {
    let e, i;
    return e = new vi({
        props: {
            variant: s[6],
            isMulti: s[3],
            isSearchFixture: s[5]
        }
    }), {
        c() {
            y(e.$$.fragment)
        },
        l(t) {
            T(e.$$.fragment, t)
        },
        m(t, n) {
            D(e, t, n), i = !0
        },
        p(t, n) {
            const l = {};
            n & 64 && (l.variant = t[6]), n & 8 && (l.isMulti = t[3]), n & 32 && (l.isSearchFixture = t[5]), e.$set(l)
        },
        i(t) {
            i || (k(e.$$.fragment, t), i = !0)
        },
        o(t) {
            v(e.$$.fragment, t), i = !1
        },
        d(t) {
            M(e, t)
        }
    }
}

function Ze(s) {
    let e;
    return {
        c() {
            e = N("div"), this.h()
        },
        l(i) {
            e = b(i, "DIV", {
                class: !0,
                style: !0
            }), $(e).forEach(c), this.h()
        },
        h() {
            E(e, "class", "line svelte-9txh06"), R(e, "grid-area", "line"), A(e, "light", s[9])
        },
        m(i, t) {
            h(i, e, t)
        },
        p(i, t) {
            t & 512 && A(e, "light", i[9])
        },
        d(i) {
            i && c(e)
        }
    }
}

function Je(s) {
    let e;
    return {
        c() {
            e = N("div"), this.h()
        },
        l(i) {
            e = b(i, "DIV", {
                class: !0,
                style: !0
            }), $(e).forEach(c), this.h()
        },
        h() {
            E(e, "class", "line svelte-9txh06"), R(e, "grid-area", "line2"), A(e, "light", s[9])
        },
        m(i, t) {
            h(i, e, t)
        },
        p(i, t) {
            t & 512 && A(e, "light", i[9])
        },
        d(i) {
            i && c(e)
        }
    }
}

function Ei(s) {
    let e, i, t, n, l, a, r;
    i = new ie({
        props: {
            to: s[14],
            class: "inline truncate",
            $$slots: {
                default: [Vi]
            },
            $$scope: {
                ctx: s
            }
        }
    }), n = new ie({
        props: {
            to: s[14],
            class: "truncate inline",
            $$slots: {
                default: [Ci]
            },
            $$scope: {
                ctx: s
            }
        }
    });
    let o = !s[2] && Ye(s);
    return {
        c() {
            e = N("div"), y(i.$$.fragment), t = U(), y(n.$$.fragment), l = U(), o && o.c(), a = B(), this.h()
        },
        l(u) {
            e = b(u, "DIV", {
                class: !0
            });
            var d = $(e);
            T(i.$$.fragment, d), t = P(d), T(n.$$.fragment, d), d.forEach(c), l = P(u), o && o.l(u), a = B(), this.h()
        },
        h() {
            E(e, "class", "teams stacked svelte-9txh06")
        },
        m(u, d) {
            h(u, e, d), D(i, e, null), C(e, t), D(n, e, null), h(u, l, d), o && o.m(u, d), h(u, a, d), r = !0
        },
        p(u, d) {
            const f = {};
            d & 528641 && (f.$$scope = {
                dirty: d,
                ctx: u
            }), i.$set(f);
            const m = {};
            d & 528513 && (m.$$scope = {
                dirty: d,
                ctx: u
            }), n.$set(m), u[2] ? o && (z(), v(o, 1, 1, () => {
                o = null
            }), W()) : o ? (o.p(u, d), d & 4 && k(o, 1)) : (o = Ye(u), o.c(), k(o, 1), o.m(a.parentNode, a))
        },
        i(u) {
            r || (k(i.$$.fragment, u), k(n.$$.fragment, u), k(o), r = !0)
        },
        o(u) {
            v(i.$$.fragment, u), v(n.$$.fragment, u), v(o), r = !1
        },
        d(u) {
            u && (c(e), c(l), c(a)), M(i), M(n), o && o.d(u)
        }
    }
}

function Ii(s) {
    let e, i, t, n, l, a;
    return i = new ie({
        props: {
            variant: "link",
            to: s[14],
            class: "inline truncate",
            $$slots: {
                default: [Oi]
            },
            $$scope: {
                ctx: s
            }
        }
    }), n = new ie({
        props: {
            variant: "link",
            to: s[14],
            class: "inline truncate",
            $$slots: {
                default: [Bi]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            e = N("span"), y(i.$$.fragment), t = H(`
        -
        `), y(n.$$.fragment), this.h()
        },
        l(r) {
            e = b(r, "SPAN", {
                class: !0,
                style: !0
            });
            var o = $(e);
            T(i.$$.fragment, o), t = G(o, `
        -
        `), T(n.$$.fragment, o), o.forEach(c), this.h()
        },
        h() {
            E(e, "class", "fixture svelte-9txh06"), E(e, "style", l = s[5] ? "display: inline;" : "")
        },
        m(r, o) {
            h(r, e, o), D(i, e, null), C(e, t), D(n, e, null), a = !0
        },
        p(r, o) {
            const u = {};
            o & 528641 && (u.$$scope = {
                dirty: o,
                ctx: r
            }), i.$set(u);
            const d = {};
            o & 528513 && (d.$$scope = {
                dirty: o,
                ctx: r
            }), n.$set(d), (!a || o & 32 && l !== (l = r[5] ? "display: inline;" : "")) && E(e, "style", l)
        },
        i(r) {
            a || (k(i.$$.fragment, r), k(n.$$.fragment, r), a = !0)
        },
        o(r) {
            v(i.$$.fragment, r), v(n.$$.fragment, r), a = !1
        },
        d(r) {
            r && c(e), M(i), M(n)
        }
    }
}

function Qe(s) {
    let e, i, t;
    return i = new ve({
        props: {
            icon: s[0].tournament.category.sport.slug,
            style: "fill: var(--yellow-500);"
        }
    }), {
        c() {
            e = N("span"), y(i.$$.fragment), this.h()
        },
        l(n) {
            e = b(n, "SPAN", {
                class: !0
            });
            var l = $(e);
            T(i.$$.fragment, l), l.forEach(c), this.h()
        },
        h() {
            E(e, "class", "ml-2 inline-flex translate-y-[2px]")
        },
        m(n, l) {
            h(n, e, l), D(i, e, null), t = !0
        },
        p(n, l) {
            const a = {};
            l & 1 && (a.icon = n[0].tournament.category.sport.slug), i.$set(a)
        },
        i(n) {
            t || (k(i.$$.fragment, n), t = !0)
        },
        o(n) {
            v(i.$$.fragment, n), t = !1
        },
        d(n) {
            n && c(e), M(i)
        }
    }
}

function Vi(s) {
    var o;
    let e, i = ((o = s[8]) == null ? void 0 : o.name) + "",
        t, n, l, a, r = s[12] === "home" && Qe(s);
    return {
        c() {
            e = N("span"), t = H(i), n = U(), r && r.c(), l = B()
        },
        l(u) {
            e = b(u, "SPAN", {});
            var d = $(e);
            t = G(d, i), d.forEach(c), n = P(u), r && r.l(u), l = B()
        },
        m(u, d) {
            h(u, e, d), C(e, t), h(u, n, d), r && r.m(u, d), h(u, l, d), a = !0
        },
        p(u, d) {
            var f;
            (!a || d & 256) && i !== (i = ((f = u[8]) == null ? void 0 : f.name) + "") && Z(t, i), u[12] === "home" ? r ? (r.p(u, d), d & 4096 && k(r, 1)) : (r = Qe(u), r.c(), k(r, 1), r.m(l.parentNode, l)) : r && (z(), v(r, 1, 1, () => {
                r = null
            }), W())
        },
        i(u) {
            a || (k(r), a = !0)
        },
        o(u) {
            v(r), a = !1
        },
        d(u) {
            u && (c(e), c(n), c(l)), r && r.d(u)
        }
    }
}

function Xe(s) {
    let e, i, t;
    return i = new ve({
        props: {
            icon: s[0].tournament.category.sport.slug,
            style: "fill: var(--yellow-500);"
        }
    }), {
        c() {
            e = N("span"), y(i.$$.fragment), this.h()
        },
        l(n) {
            e = b(n, "SPAN", {
                class: !0
            });
            var l = $(e);
            T(i.$$.fragment, l), l.forEach(c), this.h()
        },
        h() {
            E(e, "class", "ml-2 inline-flex translate-y-[2px]")
        },
        m(n, l) {
            h(n, e, l), D(i, e, null), t = !0
        },
        p(n, l) {
            const a = {};
            l & 1 && (a.icon = n[0].tournament.category.sport.slug), i.$set(a)
        },
        i(n) {
            t || (k(i.$$.fragment, n), t = !0)
        },
        o(n) {
            v(i.$$.fragment, n), t = !1
        },
        d(n) {
            n && c(e), M(i)
        }
    }
}

function Ci(s) {
    var o;
    let e, i = ((o = s[7]) == null ? void 0 : o.name) + "",
        t, n, l, a, r = s[12] === "away" && Xe(s);
    return {
        c() {
            e = N("span"), t = H(i), n = U(), r && r.c(), l = B()
        },
        l(u) {
            e = b(u, "SPAN", {});
            var d = $(e);
            t = G(d, i), d.forEach(c), n = P(u), r && r.l(u), l = B()
        },
        m(u, d) {
            h(u, e, d), C(e, t), h(u, n, d), r && r.m(u, d), h(u, l, d), a = !0
        },
        p(u, d) {
            var f;
            (!a || d & 128) && i !== (i = ((f = u[7]) == null ? void 0 : f.name) + "") && Z(t, i), u[12] === "away" ? r ? (r.p(u, d), d & 4096 && k(r, 1)) : (r = Xe(u), r.c(), k(r, 1), r.m(l.parentNode, l)) : r && (z(), v(r, 1, 1, () => {
                r = null
            }), W())
        },
        i(u) {
            a || (k(r), a = !0)
        },
        o(u) {
            v(r), a = !1
        },
        d(u) {
            u && (c(e), c(n), c(l)), r && r.d(u)
        }
    }
}

function Ye(s) {
    let e, i, t, n, l;
    return i = new Ti({
        props: {
            fixture: s[0],
            stacked: s[2]
        }
    }), n = new It({
        props: {
            fixture: s[0],
            stacked: !0
        }
    }), {
        c() {
            e = N("div"), y(i.$$.fragment), t = U(), y(n.$$.fragment), this.h()
        },
        l(a) {
            e = b(a, "DIV", {
                class: !0
            });
            var r = $(e);
            T(i.$$.fragment, r), t = P(r), T(n.$$.fragment, r), r.forEach(c), this.h()
        },
        h() {
            E(e, "class", "fixture-score svelte-9txh06")
        },
        m(a, r) {
            h(a, e, r), D(i, e, null), C(e, t), D(n, e, null), l = !0
        },
        p(a, r) {
            const o = {};
            r & 1 && (o.fixture = a[0]), r & 4 && (o.stacked = a[2]), i.$set(o);
            const u = {};
            r & 1 && (u.fixture = a[0]), n.$set(u)
        },
        i(a) {
            l || (k(i.$$.fragment, a), k(n.$$.fragment, a), l = !0)
        },
        o(a) {
            v(i.$$.fragment, a), v(n.$$.fragment, a), l = !1
        },
        d(a) {
            a && c(e), M(i), M(n)
        }
    }
}

function xe(s) {
    let e, i, t;
    return i = new ve({
        props: {
            icon: s[0].tournament.category.sport.slug,
            style: "fill: var(--yellow-500);"
        }
    }), {
        c() {
            e = N("span"), y(i.$$.fragment), this.h()
        },
        l(n) {
            e = b(n, "SPAN", {
                class: !0
            });
            var l = $(e);
            T(i.$$.fragment, l), l.forEach(c), this.h()
        },
        h() {
            E(e, "class", "mr-1 inline-flex translate-y-[2px]")
        },
        m(n, l) {
            h(n, e, l), D(i, e, null), t = !0
        },
        p(n, l) {
            const a = {};
            l & 1 && (a.icon = n[0].tournament.category.sport.slug), i.$set(a)
        },
        i(n) {
            t || (k(i.$$.fragment, n), t = !0)
        },
        o(n) {
            v(i.$$.fragment, n), t = !1
        },
        d(n) {
            n && c(e), M(i)
        }
    }
}

function Oi(s) {
    var a;
    let e, i = ((a = s[8]) == null ? void 0 : a.name) + "",
        t, n, l = s[12] === "home" && xe(s);
    return {
        c() {
            l && l.c(), e = U(), t = H(i)
        },
        l(r) {
            l && l.l(r), e = P(r), t = G(r, i)
        },
        m(r, o) {
            l && l.m(r, o), h(r, e, o), h(r, t, o), n = !0
        },
        p(r, o) {
            var u;
            r[12] === "home" ? l ? (l.p(r, o), o & 4096 && k(l, 1)) : (l = xe(r), l.c(), k(l, 1), l.m(e.parentNode, e)) : l && (z(), v(l, 1, 1, () => {
                l = null
            }), W()), (!n || o & 256) && i !== (i = ((u = r[8]) == null ? void 0 : u.name) + "") && Z(t, i)
        },
        i(r) {
            n || (k(l), n = !0)
        },
        o(r) {
            v(l), n = !1
        },
        d(r) {
            r && (c(e), c(t)), l && l.d(r)
        }
    }
}

function et(s) {
    let e, i, t;
    return i = new ve({
        props: {
            icon: s[0].tournament.category.sport.slug,
            style: "fill: var(--yellow-500);"
        }
    }), {
        c() {
            e = N("span"), y(i.$$.fragment), this.h()
        },
        l(n) {
            e = b(n, "SPAN", {
                class: !0
            });
            var l = $(e);
            T(i.$$.fragment, l), l.forEach(c), this.h()
        },
        h() {
            E(e, "class", "ml-1 inline-flex translate-y-[2px]")
        },
        m(n, l) {
            h(n, e, l), D(i, e, null), t = !0
        },
        p(n, l) {
            const a = {};
            l & 1 && (a.icon = n[0].tournament.category.sport.slug), i.$set(a)
        },
        i(n) {
            t || (k(i.$$.fragment, n), t = !0)
        },
        o(n) {
            v(i.$$.fragment, n), t = !1
        },
        d(n) {
            n && c(e), M(i)
        }
    }
}

function Bi(s) {
    var r;
    let e = ((r = s[7]) == null ? void 0 : r.name) + "",
        i, t, n, l, a = s[12] === "away" && et(s);
    return {
        c() {
            i = H(e), t = U(), a && a.c(), n = B()
        },
        l(o) {
            i = G(o, e), t = P(o), a && a.l(o), n = B()
        },
        m(o, u) {
            h(o, i, u), h(o, t, u), a && a.m(o, u), h(o, n, u), l = !0
        },
        p(o, u) {
            var d;
            (!l || u & 128) && e !== (e = ((d = o[7]) == null ? void 0 : d.name) + "") && Z(i, e), o[12] === "away" ? a ? (a.p(o, u), u & 4096 && k(a, 1)) : (a = et(o), a.c(), k(a, 1), a.m(n.parentNode, n)) : a && (z(), v(a, 1, 1, () => {
                a = null
            }), W())
        },
        i(o) {
            l || (k(a), l = !0)
        },
        o(o) {
            v(a), l = !1
        },
        d(o) {
            o && (c(i), c(t), c(n)), a && a.d(o)
        }
    }
}

function tt(s) {
    let e, i, t;
    return i = new Ct({
        props: {
            list: s[13],
            mobileView: s[2]
        }
    }), {
        c() {
            e = N("div"), y(i.$$.fragment), this.h()
        },
        l(n) {
            e = b(n, "DIV", {
                class: !0
            });
            var l = $(e);
            T(i.$$.fragment, l), l.forEach(c), this.h()
        },
        h() {
            E(e, "class", "breadcrumb svelte-9txh06")
        },
        m(n, l) {
            h(n, e, l), D(i, e, null), t = !0
        },
        p(n, l) {
            const a = {};
            l & 4 && (a.mobileView = n[2]), i.$set(a)
        },
        i(n) {
            t || (k(i.$$.fragment, n), t = !0)
        },
        o(n) {
            v(i.$$.fragment, n), t = !1
        },
        d(n) {
            n && c(e), M(i)
        }
    }
}

function it(s) {
    let e, i, t, n, l = s[2] && nt(s);
    return t = new ie({
        props: {
            variant: "subtle-link",
            to: s[14],
            $$slots: {
                default: [Ai]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            e = N("div"), l && l.c(), i = U(), y(t.$$.fragment), this.h()
        },
        l(a) {
            e = b(a, "DIV", {
                class: !0
            });
            var r = $(e);
            l && l.l(r), i = P(r), T(t.$$.fragment, r), r.forEach(c), this.h()
        },
        h() {
            E(e, "class", "market-count svelte-9txh06"), A(e, "stacked", s[2])
        },
        m(a, r) {
            h(a, e, r), l && l.m(e, null), C(e, i), D(t, e, null), n = !0
        },
        p(a, r) {
            a[2] ? l ? (l.p(a, r), r & 4 && k(l, 1)) : (l = nt(a), l.c(), k(l, 1), l.m(e, i)) : l && (z(), v(l, 1, 1, () => {
                l = null
            }), W());
            const o = {};
            r & 524289 && (o.$$scope = {
                dirty: r,
                ctx: a
            }), t.$set(o), (!n || r & 4) && A(e, "stacked", a[2])
        },
        i(a) {
            n || (k(l), k(t.$$.fragment, a), n = !0)
        },
        o(a) {
            v(l), v(t.$$.fragment, a), n = !1
        },
        d(a) {
            a && c(e), l && l.d(), M(t)
        }
    }
}

function nt(s) {
    let e, i, t;
    return i = new It({
        props: {
            fixture: s[0],
            stacked: !1
        }
    }), {
        c() {
            e = N("div"), y(i.$$.fragment), this.h()
        },
        l(n) {
            e = b(n, "DIV", {
                class: !0
            });
            var l = $(e);
            T(i.$$.fragment, l), l.forEach(c), this.h()
        },
        h() {
            E(e, "class", "widget-buttons-wrapper svelte-9txh06")
        },
        m(n, l) {
            h(n, e, l), D(i, e, null), t = !0
        },
        p(n, l) {
            const a = {};
            l & 1 && (a.fixture = n[0]), i.$set(a)
        },
        i(n) {
            t || (k(i.$$.fragment, n), t = !0)
        },
        o(n) {
            v(i.$$.fragment, n), t = !1
        },
        d(n) {
            n && c(e), M(i)
        }
    }
}

function Ai(s) {
    let e, i = s[0].marketCount + "",
        t;
    return {
        c() {
            e = H("+"), t = H(i)
        },
        l(n) {
            e = G(n, "+"), t = G(n, i)
        },
        m(n, l) {
            h(n, e, l), h(n, t, l)
        },
        p(n, l) {
            l & 1 && i !== (i = n[0].marketCount + "") && Z(t, i)
        },
        d(n) {
            n && (c(e), c(t))
        }
    }
}

function Li(s) {
    let e, i, t, n;
    const l = [Mi, Di],
        a = [];

    function r(o, u) {
        return o[4] || !o[0] ? 0 : 1
    }
    return e = r(s), i = a[e] = l[e](s), {
        c() {
            i.c(), t = B()
        },
        l(o) {
            i.l(o), t = B()
        },
        m(o, u) {
            a[e].m(o, u), h(o, t, u), n = !0
        },
        p(o, [u]) {
            let d = e;
            e = r(o), e === d ? a[e].p(o, u) : (z(), v(a[d], 1, 1, () => {
                a[d] = null
            }), W(), i = a[e], i ? i.p(o, u) : (i = a[e] = l[e](o), i.c()), k(i, 1), i.m(t.parentNode, t))
        },
        i(o) {
            n || (k(i), n = !0)
        },
        o(o) {
            v(i), n = !1
        },
        d(o) {
            o && c(t), a[e].d(o)
        }
    }
}

function Ui(s, e, i) {
    let t, n, l, a, r, o, u, d, {
            $$slots: f = {},
            $$scope: m
        } = e,
        {
            fixture: _
        } = e,
        {
            showFullDate: g
        } = e,
        {
            stacked: p = !1
        } = e,
        {
            isMulti: w
        } = e,
        {
            loading: F = !1
        } = e,
        {
            displayBreadcrumb: I = !1
        } = e,
        {
            isSearchFixture: S = !1
        } = e,
        {
            variant: V
        } = e,
        L = $t(_.tournament),
        J = Ne(_);
    return s.$$set = j => {
        "fixture" in j && i(0, _ = j.fixture), "showFullDate" in j && i(1, g = j.showFullDate), "stacked" in j && i(2, p = j.stacked), "isMulti" in j && i(3, w = j.isMulti), "loading" in j && i(4, F = j.loading), "displayBreadcrumb" in j && i(15, I = j.displayBreadcrumb), "isSearchFixture" in j && i(5, S = j.isSearchFixture), "variant" in j && i(6, V = j.variant), "$$scope" in j && i(19, m = j.$$scope)
    }, s.$$.update = () => {
        var j, K, O, q;
        s.$$.dirty & 68 && i(16, t = p ? "transparent" : V), s.$$.dirty & 1 && i(12, n = ((j = _.eventStatus) == null ? void 0 : j.__typename) === "SportFixtureEventStatusData" && ((K = _ == null ? void 0 : _.eventStatus) == null ? void 0 : K.currentTeamServing)), s.$$.dirty & 8 && i(17, l = w ? 3 : 1), s.$$.dirty & 163876 && i(11, a = Mt({
            stacked: p,
            marketsLength: l,
            displayBreadcrumb: I,
            isSearchFixture: S
        })), s.$$.dirty & 131076 && i(10, r = Et(p, l)), s.$$.dirty & 65536 && i(9, o = t === "light"), s.$$.dirty & 1 && i(8, u = ((O = _ == null ? void 0 : _.data) == null ? void 0 : O.__typename) === "SportFixtureDataMatch" ? _.data.competitors[0] : null), s.$$.dirty & 1 && i(7, d = ((q = _ == null ? void 0 : _.data) == null ? void 0 : q.__typename) === "SportFixtureDataMatch" ? _.data.competitors[1] : null)
    }, [_, g, p, w, F, S, V, d, u, o, r, a, n, L, J, I, t, l, f, m]
}
class Pi extends x {
    constructor(e) {
        super(), ee(this, e, Ui, Li, Y, {
            fixture: 0,
            showFullDate: 1,
            stacked: 2,
            isMulti: 3,
            loading: 4,
            displayBreadcrumb: 15,
            isSearchFixture: 5,
            variant: 6
        })
    }
}
const qi = {
    kind: "Document",
    definitions: [{
        kind: "OperationDefinition",
        operation: "subscription",
        name: {
            kind: "Name",
            value: "SportMarketSubscription"
        },
        variableDefinitions: [{
            kind: "VariableDefinition",
            variable: {
                kind: "Variable",
                name: {
                    kind: "Name",
                    value: "marketId"
                }
            },
            type: {
                kind: "NonNullType",
                type: {
                    kind: "NamedType",
                    name: {
                        kind: "Name",
                        value: "String"
                    }
                }
            }
        }, {
            kind: "VariableDefinition",
            variable: {
                kind: "Variable",
                name: {
                    kind: "Name",
                    value: "provider"
                }
            },
            type: {
                kind: "NonNullType",
                type: {
                    kind: "NamedType",
                    name: {
                        kind: "Name",
                        value: "SportsbookOddsProviderEnum"
                    }
                }
            }
        }],
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "sportMarket"
                },
                arguments: [{
                    kind: "Argument",
                    name: {
                        kind: "Name",
                        value: "marketId"
                    },
                    value: {
                        kind: "Variable",
                        name: {
                            kind: "Name",
                            value: "marketId"
                        }
                    }
                }, {
                    kind: "Argument",
                    name: {
                        kind: "Name",
                        value: "provider"
                    },
                    value: {
                        kind: "Variable",
                        name: {
                            kind: "Name",
                            value: "provider"
                        }
                    }
                }],
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "FragmentSpread",
                        name: {
                            kind: "Name",
                            value: "SportMarket"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "outcomes"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "FragmentSpread",
                                name: {
                                    kind: "Name",
                                    value: "SportMarketOutcome"
                                }
                            }]
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "fixture"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "id"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "status"
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "SportMarket"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportMarket"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "name"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "status"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "extId"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "specifiers"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "customBetAvailable"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "provider"
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "SportMarketOutcome"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportMarketOutcome"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "__typename"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "active"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "odds"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "name"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "customBetAvailable"
                }
            }]
        }
    }]
};
let ge = 0;
const lt = new Map,
    ae = new Map,
    _e = new Map,
    at = s => {
        s.forEach(e => {
            var i;
            ae.get(e) === 1 && (ae.delete(e), (i = _e.get(e)) == null || i.subscription.unsubscribe(), _e.delete(e)), ae.set(e, Number(ae.get(e)) - 1)
        })
    },
    ji = s => {
        const e = typeof s == "string" ? s : s.id;
        if (!ae.get(e)) {
            const i = Zt(typeof s == "string" ? void 0 : {
                    sportMarket: s,
                    __typename: "Subscription"
                }),
                t = Dt(),
                n = yt(t.subscription(qi, {
                    marketId: e,
                    provider: typeof s == "string" ? Se.betradar : s.provider ? ? Se.betradar
                }), Tt(l => {
                    var r;
                    ((r = l == null ? void 0 : l.data) == null ? void 0 : r.sportMarket) && i.set(l.data)
                }));
            _e.set(e, {
                store: i,
                subscription: n
            })
        }
        ae.set(e, (ae.get(e) || 0) + 1)
    },
    zi = () => {
        ge++;
        let s = [];
        return bt(() => {
            lt.delete(ge), at(s)
        }), e => {
            var t;
            e || at(s);
            const i = typeof e == "string" ? e : e.id;
            return s = [i], ji(e), lt.set(ge, s), (t = _e.get(i)) == null ? void 0 : t.store
        }
    };

function rt(s, e, i) {
    const t = s.slice();
    return t[14] = e[i], t
}

function Wi(s) {
    let e = s[4].name + "",
        i;
    return {
        c() {
            i = H(e)
        },
        l(t) {
            i = G(t, e)
        },
        m(t, n) {
            h(t, i, n)
        },
        p(t, n) {
            n & 16 && e !== (e = t[4].name + "") && Z(i, e)
        },
        d(t) {
            t && c(i)
        }
    }
}

function Ri(s) {
    let e, i;
    return e = new le({
        props: {
            size: "sm",
            align: "center",
            $$slots: {
                default: [Wi]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            y(e.$$.fragment)
        },
        l(t) {
            T(e.$$.fragment, t)
        },
        m(t, n) {
            D(e, t, n), i = !0
        },
        p(t, n) {
            const l = {};
            n & 131088 && (l.$$scope = {
                dirty: n,
                ctx: t
            }), e.$set(l)
        },
        i(t) {
            i || (k(e.$$.fragment, t), i = !0)
        },
        o(t) {
            v(e.$$.fragment, t), i = !1
        },
        d(t) {
            M(e, t)
        }
    }
}

function Ki(s) {
    var l, a;
    let e, i, t, n;
    return e = new we({
        props: {
            name: (l = s[7]) == null ? void 0 : l.name,
            outcome: "suspended"
        }
    }), t = new we({
        props: {
            name: (a = s[6]) == null ? void 0 : a.name,
            outcome: "suspended"
        }
    }), {
        c() {
            y(e.$$.fragment), i = U(), y(t.$$.fragment)
        },
        l(r) {
            T(e.$$.fragment, r), i = P(r), T(t.$$.fragment, r)
        },
        m(r, o) {
            D(e, r, o), h(r, i, o), D(t, r, o), n = !0
        },
        p(r, o) {
            var f, m;
            const u = {};
            o & 128 && (u.name = (f = r[7]) == null ? void 0 : f.name), e.$set(u);
            const d = {};
            o & 64 && (d.name = (m = r[6]) == null ? void 0 : m.name), t.$set(d)
        },
        i(r) {
            n || (k(e.$$.fragment, r), k(t.$$.fragment, r), n = !0)
        },
        o(r) {
            v(e.$$.fragment, r), v(t.$$.fragment, r), n = !1
        },
        d(r) {
            r && c(i), M(e, r), M(t, r)
        }
    }
}

function Hi(s) {
    let e = [],
        i = new Map,
        t, n, l = Q(s[5]);
    const a = r => r[14].id;
    for (let r = 0; r < l.length; r += 1) {
        let o = rt(s, l, r),
            u = a(o);
        i.set(u, e[r] = st(u, o))
    }
    return {
        c() {
            for (let r = 0; r < e.length; r += 1) e[r].c();
            t = B()
        },
        l(r) {
            for (let o = 0; o < e.length; o += 1) e[o].l(r);
            t = B()
        },
        m(r, o) {
            for (let u = 0; u < e.length; u += 1) e[u] && e[u].m(r, o);
            h(r, t, o), n = !0
        },
        p(r, o) {
            o & 55 && (l = Q(r[5]), z(), e = se(e, o, a, 1, r, l, i, t.parentNode, oe, st, t, rt), W())
        },
        i(r) {
            if (!n) {
                for (let o = 0; o < l.length; o += 1) k(e[o]);
                n = !0
            }
        },
        o(r) {
            for (let o = 0; o < e.length; o += 1) v(e[o]);
            n = !1
        },
        d(r) {
            r && c(t);
            for (let o = 0; o < e.length; o += 1) e[o].d(r)
        }
    }
}

function st(s, e) {
    var l;
    let i, t, n;
    return t = new Ht({
        props: {
            isMulti: e[2],
            horizontal: e[2] && !e[1],
            name: ye({
                isMulti: e[2],
                name: e[14].name,
                competitors: ((l = e[0].data) == null ? void 0 : l.__typename) === "SportFixtureDataMatch" ? e[0].data.competitors : [],
                stacked: e[1]
            }),
            bet: {
                __typename: "SportBetOutcome",
                outcome: e[14],
                fixture: e[0],
                market: e[4]
            }
        }
    }), {
        key: s,
        first: null,
        c() {
            i = B(), y(t.$$.fragment), this.h()
        },
        l(a) {
            i = B(), T(t.$$.fragment, a), this.h()
        },
        h() {
            this.first = i
        },
        m(a, r) {
            h(a, i, r), D(t, a, r), n = !0
        },
        p(a, r) {
            var u;
            e = a;
            const o = {};
            r & 4 && (o.isMulti = e[2]), r & 6 && (o.horizontal = e[2] && !e[1]), r & 39 && (o.name = ye({
                isMulti: e[2],
                name: e[14].name,
                competitors: ((u = e[0].data) == null ? void 0 : u.__typename) === "SportFixtureDataMatch" ? e[0].data.competitors : [],
                stacked: e[1]
            })), r & 49 && (o.bet = {
                __typename: "SportBetOutcome",
                outcome: e[14],
                fixture: e[0],
                market: e[4]
            }), t.$set(o)
        },
        i(a) {
            n || (k(t.$$.fragment, a), n = !0)
        },
        o(a) {
            v(t.$$.fragment, a), n = !1
        },
        d(a) {
            a && c(i), M(t, a)
        }
    }
}

function Gi(s) {
    let e, i, t, n, l, a, r, o;
    i = new he({
        props: {
            maxWidth: "100%",
            $$slots: {
                default: [Ri]
            },
            $$scope: {
                ctx: s
            }
        }
    });
    const u = [Hi, Ki],
        d = [];

    function f(m, _) {
        return m[5].length ? 0 : 1
    }
    return a = f(s), r = d[a] = u[a](s), {
        c() {
            e = N("div"), y(i.$$.fragment), n = U(), l = N("div"), r.c(), this.h()
        },
        l(m) {
            e = b(m, "DIV", {
                class: !0,
                style: !0
            });
            var _ = $(e);
            T(i.$$.fragment, _), _.forEach(c), n = P(m), l = b(m, "DIV", {
                class: !0,
                style: !0
            });
            var g = $(l);
            r.l(g), g.forEach(c), this.h()
        },
        h() {
            E(e, "class", "market-name svelte-19bjww6"), E(e, "style", t = "--area: marketName" + (s[3] || 0) + "; " + (s[1] ? "margin: var(--space-1) 0;" : "")), E(l, "class", "outcomes svelte-19bjww6"), R(l, "--area", "outcomes" + s[3]), A(l, "stacked", s[1]), A(l, "isMulti", s[2] && !s[8])
        },
        m(m, _) {
            h(m, e, _), D(i, e, null), h(m, n, _), h(m, l, _), d[a].m(l, null), o = !0
        },
        p(m, [_]) {
            const g = {};
            _ & 131088 && (g.$$scope = {
                dirty: _,
                ctx: m
            }), i.$set(g), (!o || _ & 10 && t !== (t = "--area: marketName" + (m[3] || 0) + "; " + (m[1] ? "margin: var(--space-1) 0;" : ""))) && E(e, "style", t);
            let p = a;
            a = f(m), a === p ? d[a].p(m, _) : (z(), v(d[p], 1, 1, () => {
                d[p] = null
            }), W(), r = d[a], r ? r.p(m, _) : (r = d[a] = u[a](m), r.c()), k(r, 1), r.m(l, null)), (!o || _ & 8) && R(l, "--area", "outcomes" + m[3]), (!o || _ & 2) && A(l, "stacked", m[1]), (!o || _ & 260) && A(l, "isMulti", m[2] && !m[8])
        },
        i(m) {
            o || (k(i.$$.fragment, m), k(r), o = !0)
        },
        o(m) {
            v(i.$$.fragment, m), v(r), o = !1
        },
        d(m) {
            m && (c(e), c(n), c(l)), M(i), d[a].d()
        }
    }
}

function Zi(s, e, i) {
    let t, n, l, a;
    re(s, Gt, F => i(8, a = F));
    let {
        fixture: r
    } = e, {
        market: o
    } = e, {
        stacked: u = !1
    } = e, {
        isMulti: d
    } = e, {
        index: f
    } = e, _ = zi()({ ...o,
        fixture: r
    });
    re(s, _, F => i(11, l = F));
    let g = (l == null ? void 0 : l.sportMarket) || o,
        p = (g == null ? void 0 : g.outcomes) || [],
        w = _ == null ? void 0 : _.subscribe(F => {
            F != null && F.sportMarket && i(4, g = F == null ? void 0 : F.sportMarket), i(5, p = g == null ? void 0 : g.outcomes)
        });
    return bt(() => {
        w == null || w()
    }), s.$$set = F => {
        "fixture" in F && i(0, r = F.fixture), "market" in F && i(10, o = F.market), "stacked" in F && i(1, u = F.stacked), "isMulti" in F && i(2, d = F.isMulti), "index" in F && i(3, f = F.index)
    }, s.$$.update = () => {
        var F, I, S, V;
        s.$$.dirty & 1 && i(7, t = ((F = r.data) == null ? void 0 : F.__typename) === "SportFixtureDataMatch" ? (I = r.data.teams) == null ? void 0 : I.find(L => L.qualifier === "home") : void 0), s.$$.dirty & 1 && i(6, n = ((S = r.data) == null ? void 0 : S.__typename) === "SportFixtureDataMatch" ? (V = r.data.teams) == null ? void 0 : V.find(L => L.qualifier === "away") : void 0)
    }, [r, u, d, f, g, p, n, t, a, _, o]
}
class Ji extends x {
    constructor(e) {
        super(), ee(this, e, Zi, Gi, Y, {
            fixture: 0,
            market: 10,
            stacked: 1,
            isMulti: 2,
            index: 3
        })
    }
}

function Qi(s) {
    let e, i, t, n, l, a, r;
    i = new he({
        props: {
            maxWidth: "100%",
            $$slots: {
                default: [xi]
            },
            $$scope: {
                ctx: s
            }
        }
    });
    const o = [tn, en],
        u = [];

    function d(f, m) {
        return f[3] && f[4] && !f[5] ? 0 : 1
    }
    return l = d(s), a = u[l] = o[l](s), {
        c() {
            e = N("div"), y(i.$$.fragment), t = U(), n = N("div"), a.c(), this.h()
        },
        l(f) {
            e = b(f, "DIV", {
                class: !0,
                style: !0
            });
            var m = $(e);
            T(i.$$.fragment, m), m.forEach(c), t = P(f), n = b(f, "DIV", {
                class: !0,
                style: !0
            });
            var _ = $(n);
            a.l(_), _.forEach(c), this.h()
        },
        h() {
            E(e, "class", "market-name svelte-1jne6zq"), R(e, "--area", "marketName" + s[6]), E(n, "class", "outcomes svelte-1jne6zq"), R(n, "--area", "outcomes" + s[6]), A(n, "isMulti", s[5])
        },
        m(f, m) {
            h(f, e, m), D(i, e, null), h(f, t, m), h(f, n, m), u[l].m(n, null), r = !0
        },
        p(f, m) {
            const _ = {};
            m & 896 && (_.$$scope = {
                dirty: m,
                ctx: f
            }), i.$set(_), (!r || m & 64) && R(e, "--area", "marketName" + f[6]);
            let g = l;
            l = d(f), l === g ? u[l].p(f, m) : (z(), v(u[g], 1, 1, () => {
                u[g] = null
            }), W(), a = u[l], a ? a.p(f, m) : (a = u[l] = o[l](f), a.c()), k(a, 1), a.m(n, null)), (!r || m & 64) && R(n, "--area", "outcomes" + f[6]), (!r || m & 32) && A(n, "isMulti", f[5])
        },
        i(f) {
            r || (k(i.$$.fragment, f), k(a), r = !0)
        },
        o(f) {
            v(i.$$.fragment, f), v(a), r = !1
        },
        d(f) {
            f && (c(e), c(t), c(n)), M(i), u[l].d()
        }
    }
}

function Xi(s) {
    let e, i, t;
    return i = new he({
        props: {
            maxWidth: "12ch",
            $$slots: {
                default: [sn]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            e = N("div"), y(i.$$.fragment), this.h()
        },
        l(n) {
            e = b(n, "DIV", {
                class: !0
            });
            var l = $(e);
            T(i.$$.fragment, l), l.forEach(c), this.h()
        },
        h() {
            E(e, "class", "outcome see-all-markets svelte-1jne6zq"), A(e, "isMulti", s[5])
        },
        m(n, l) {
            h(n, e, l), D(i, e, null), t = !0
        },
        p(n, l) {
            const a = {};
            l & 770 && (a.$$scope = {
                dirty: l,
                ctx: n
            }), i.$set(a), (!t || l & 32) && A(e, "isMulti", n[5])
        },
        i(n) {
            t || (k(i.$$.fragment, n), t = !0)
        },
        o(n) {
            v(i.$$.fragment, n), t = !1
        },
        d(n) {
            n && c(e), M(i)
        }
    }
}

function Yi(s) {
    let e = (s[7] ? s[7] : s[8]._(ne.winner)) + "",
        i;
    return {
        c() {
            i = H(e)
        },
        l(t) {
            i = G(t, e)
        },
        m(t, n) {
            h(t, i, n)
        },
        p(t, n) {
            n & 384 && e !== (e = (t[7] ? t[7] : t[8]._(ne.winner)) + "") && Z(i, e)
        },
        d(t) {
            t && c(i)
        }
    }
}

function xi(s) {
    let e, i;
    return e = new le({
        props: {
            align: "center",
            size: "sm",
            $$slots: {
                default: [Yi]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            y(e.$$.fragment)
        },
        l(t) {
            T(e.$$.fragment, t)
        },
        m(t, n) {
            D(e, t, n), i = !0
        },
        p(t, n) {
            const l = {};
            n & 896 && (l.$$scope = {
                dirty: n,
                ctx: t
            }), e.$set(l)
        },
        i(t) {
            i || (k(e.$$.fragment, t), i = !0)
        },
        o(t) {
            v(e.$$.fragment, t), i = !1
        },
        d(t) {
            M(e, t)
        }
    }
}

function en(s) {
    let e, i, t, n, l;
    return n = new Jt({}), {
        c() {
            e = N("button"), i = N("div"), t = N("div"), y(n.$$.fragment), this.h()
        },
        l(a) {
            e = b(a, "BUTTON", {
                class: !0
            });
            var r = $(e);
            i = b(r, "DIV", {
                class: !0,
                style: !0
            });
            var o = $(i);
            t = b(o, "DIV", {
                class: !0
            });
            var u = $(t);
            T(n.$$.fragment, u), u.forEach(c), o.forEach(c), r.forEach(c), this.h()
        },
        h() {
            E(t, "class", "lock-content svelte-1jne6zq"), E(i, "class", "outcome-content outcome-content-loocked svelte-1jne6zq"), R(i, "padding", "var(--space-4) 0"), e.disabled = !0, E(e, "class", "outcome outcome-locked svelte-1jne6zq"), A(e, "stacked", s[2]), A(e, "inactive", !0)
        },
        m(a, r) {
            h(a, e, r), C(e, i), C(i, t), D(n, t, null), l = !0
        },
        p(a, r) {
            (!l || r & 4) && A(e, "stacked", a[2])
        },
        i(a) {
            l || (k(n.$$.fragment, a), l = !0)
        },
        o(a) {
            v(n.$$.fragment, a), l = !1
        },
        d(a) {
            a && c(e), M(n)
        }
    }
}

function tn(s) {
    let e, i;
    return e = new he({
        props: {
            maxWidth: "100%",
            $$slots: {
                default: [an]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            y(e.$$.fragment)
        },
        l(t) {
            T(e.$$.fragment, t)
        },
        m(t, n) {
            D(e, t, n), i = !0
        },
        p(t, n) {
            const l = {};
            n & 796 && (l.$$scope = {
                dirty: n,
                ctx: t
            }), e.$set(l)
        },
        i(t) {
            i || (k(e.$$.fragment, t), i = !0)
        },
        o(t) {
            v(e.$$.fragment, t), i = !1
        },
        d(t) {
            M(e, t)
        }
    }
}

function nn(s) {
    let e, i;
    return {
        c() {
            e = N("span"), i = H(s[3]), this.h()
        },
        l(t) {
            e = b(t, "SPAN", {
                class: !0
            });
            var n = $(e);
            i = G(n, s[3]), n.forEach(c), this.h()
        },
        h() {
            E(e, "class", "name svelte-1jne6zq"), A(e, "suspended-name", !0)
        },
        m(t, n) {
            h(t, e, n), C(e, i)
        },
        p(t, n) {
            n & 8 && Z(i, t[3])
        },
        d(t) {
            t && c(e)
        }
    }
}

function ln(s) {
    let e, i;
    return {
        c() {
            e = N("span"), i = H(s[4]), this.h()
        },
        l(t) {
            e = b(t, "SPAN", {
                class: !0
            });
            var n = $(e);
            i = G(n, s[4]), n.forEach(c), this.h()
        },
        h() {
            E(e, "class", "name svelte-1jne6zq"), A(e, "suspended-name", !0)
        },
        m(t, n) {
            h(t, e, n), C(e, i)
        },
        p(t, n) {
            n & 16 && Z(i, t[4])
        },
        d(t) {
            t && c(e)
        }
    }
}

function an(s) {
    let e, i, t, n, l, a, r = s[8]._(ne.suspended) + "",
        o, u, d, f, m, _, g, p, w = s[8]._(ne.suspended) + "",
        F, I;
    return t = new De({
        props: {
            $$slots: {
                default: [nn]
            },
            $$scope: {
                ctx: s
            }
        }
    }), m = new De({
        props: {
            $$slots: {
                default: [ln]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            e = N("button"), i = N("div"), y(t.$$.fragment), n = U(), l = N("div"), a = N("span"), o = H(r), u = U(), d = N("button"), f = N("div"), y(m.$$.fragment), _ = U(), g = N("div"), p = N("span"), F = H(w), this.h()
        },
        l(S) {
            e = b(S, "BUTTON", {
                class: !0
            });
            var V = $(e);
            i = b(V, "DIV", {
                class: !0
            });
            var L = $(i);
            T(t.$$.fragment, L), n = P(L), l = b(L, "DIV", {
                class: !0
            });
            var J = $(l);
            a = b(J, "SPAN", {
                class: !0
            });
            var j = $(a);
            o = G(j, r), j.forEach(c), J.forEach(c), L.forEach(c), V.forEach(c), u = P(S), d = b(S, "BUTTON", {
                class: !0
            });
            var K = $(d);
            f = b(K, "DIV", {
                class: !0
            });
            var O = $(f);
            T(m.$$.fragment, O), _ = P(O), g = b(O, "DIV", {
                class: !0
            });
            var q = $(g);
            p = b(q, "SPAN", {
                class: !0
            });
            var te = $(p);
            F = G(te, w), te.forEach(c), q.forEach(c), O.forEach(c), K.forEach(c), this.h()
        },
        h() {
            E(a, "class", "suspended-odds svelte-1jne6zq"), E(l, "class", "odds svelte-1jne6zq"), E(i, "class", "outcome-content svelte-1jne6zq"), e.disabled = !0, E(e, "class", "outcome svelte-1jne6zq"), A(e, "stacked", s[2]), A(e, "inactive", !0), E(p, "class", "suspended-odds svelte-1jne6zq"), E(g, "class", "odds svelte-1jne6zq"), E(f, "class", "outcome-content svelte-1jne6zq"), d.disabled = !0, E(d, "class", "outcome svelte-1jne6zq"), A(d, "stacked", s[2]), A(d, "inactive", !0)
        },
        m(S, V) {
            h(S, e, V), C(e, i), D(t, i, null), C(i, n), C(i, l), C(l, a), C(a, o), h(S, u, V), h(S, d, V), C(d, f), D(m, f, null), C(f, _), C(f, g), C(g, p), C(p, F), I = !0
        },
        p(S, V) {
            const L = {};
            V & 520 && (L.$$scope = {
                dirty: V,
                ctx: S
            }), t.$set(L), (!I || V & 256) && r !== (r = S[8]._(ne.suspended) + "") && Z(o, r), (!I || V & 4) && A(e, "stacked", S[2]);
            const J = {};
            V & 528 && (J.$$scope = {
                dirty: V,
                ctx: S
            }), m.$set(J), (!I || V & 256) && w !== (w = S[8]._(ne.suspended) + "") && Z(F, w), (!I || V & 4) && A(d, "stacked", S[2])
        },
        i(S) {
            I || (k(t.$$.fragment, S), k(m.$$.fragment, S), I = !0)
        },
        o(S) {
            v(t.$$.fragment, S), v(m.$$.fragment, S), I = !1
        },
        d(S) {
            S && (c(e), c(u), c(d)), M(t), M(m)
        }
    }
}

function rn(s) {
    let e = s[8]._(ne.seeAll) + "",
        i;
    return {
        c() {
            i = H(e)
        },
        l(t) {
            i = G(t, e)
        },
        m(t, n) {
            h(t, i, n)
        },
        p(t, n) {
            n & 256 && e !== (e = t[8]._(ne.seeAll) + "") && Z(i, e)
        },
        d(t) {
            t && c(i)
        }
    }
}

function sn(s) {
    let e, i;
    return e = new ie({
        props: {
            size: "sm",
            variant: "minimal",
            class: "outcome-content w-full h-full",
            to: s[1],
            $$slots: {
                default: [rn]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            y(e.$$.fragment)
        },
        l(t) {
            T(e.$$.fragment, t)
        },
        m(t, n) {
            D(e, t, n), i = !0
        },
        p(t, n) {
            const l = {};
            n & 2 && (l.to = t[1]), n & 768 && (l.$$scope = {
                dirty: n,
                ctx: t
            }), e.$set(l)
        },
        i(t) {
            i || (k(e.$$.fragment, t), i = !0)
        },
        o(t) {
            v(e.$$.fragment, t), i = !1
        },
        d(t) {
            M(e, t)
        }
    }
}

function on(s) {
    let e, i, t, n;
    const l = [Xi, Qi],
        a = [];

    function r(o, u) {
        return o[0] ? 0 : 1
    }
    return e = r(s), i = a[e] = l[e](s), {
        c() {
            i.c(), t = B()
        },
        l(o) {
            i.l(o), t = B()
        },
        m(o, u) {
            a[e].m(o, u), h(o, t, u), n = !0
        },
        p(o, [u]) {
            let d = e;
            e = r(o), e === d ? a[e].p(o, u) : (z(), v(a[d], 1, 1, () => {
                a[d] = null
            }), W(), i = a[e], i ? i.p(o, u) : (i = a[e] = l[e](o), i.c()), k(i, 1), i.m(t.parentNode, t))
        },
        i(o) {
            n || (k(i), n = !0)
        },
        o(o) {
            v(i), n = !1
        },
        d(o) {
            o && c(t), a[e].d(o)
        }
    }
}

function un(s, e, i) {
    let t;
    re(s, wt, m => i(8, t = m));
    let {
        seeAllMarkets: n = !1
    } = e, {
        fixtureUrl: l
    } = e, {
        stacked: a = !1
    } = e, {
        homeName: r = ""
    } = e, {
        awayName: o = ""
    } = e, {
        isMulti: u = !1
    } = e, {
        index: d = 0
    } = e, {
        name: f = void 0
    } = e;
    return s.$$set = m => {
        "seeAllMarkets" in m && i(0, n = m.seeAllMarkets), "fixtureUrl" in m && i(1, l = m.fixtureUrl), "stacked" in m && i(2, a = m.stacked), "homeName" in m && i(3, r = m.homeName), "awayName" in m && i(4, o = m.awayName), "isMulti" in m && i(5, u = m.isMulti), "index" in m && i(6, d = m.index), "name" in m && i(7, f = m.name)
    }, [n, l, a, r, o, u, d, f, t]
}
class be extends x {
    constructor(e) {
        super(), ee(this, e, un, on, Y, {
            seeAllMarkets: 0,
            fixtureUrl: 1,
            stacked: 2,
            homeName: 3,
            awayName: 4,
            isMulti: 5,
            index: 6,
            name: 7
        })
    }
}

function ot(s, e, i) {
    const t = s.slice();
    return t[18] = e[i], t[17] = i, t
}

function ut(s, e, i) {
    const t = s.slice();
    return t[15] = e[i], t[17] = i, t
}

function dn(s) {
    let e, i;
    return e = new be({
        props: {
            fixtureUrl: s[12],
            stacked: s[2],
            homeName: s[10],
            awayName: s[9],
            isMulti: s[6]
        }
    }), {
        c() {
            y(e.$$.fragment)
        },
        l(t) {
            T(e.$$.fragment, t)
        },
        m(t, n) {
            D(e, t, n), i = !0
        },
        p(t, n) {
            const l = {};
            n & 4 && (l.stacked = t[2]), n & 1024 && (l.homeName = t[10]), n & 512 && (l.awayName = t[9]), n & 64 && (l.isMulti = t[6]), e.$set(l)
        },
        i(t) {
            i || (k(e.$$.fragment, t), i = !0)
        },
        o(t) {
            v(e.$$.fragment, t), i = !1
        },
        d(t) {
            M(e, t)
        }
    }
}

function mn(s) {
    let e, i, t = Q(s[7]),
        n = [];
    for (let a = 0; a < t.length; a += 1) n[a] = dt(ot(s, t, a));
    const l = a => v(n[a], 1, 1, () => {
        n[a] = null
    });
    return {
        c() {
            for (let a = 0; a < n.length; a += 1) n[a].c();
            e = B()
        },
        l(a) {
            for (let r = 0; r < n.length; r += 1) n[r].l(a);
            e = B()
        },
        m(a, r) {
            for (let o = 0; o < n.length; o += 1) n[o] && n[o].m(a, r);
            h(a, e, r), i = !0
        },
        p(a, r) {
            if (r & 5828) {
                t = Q(a[7]);
                let o;
                for (o = 0; o < t.length; o += 1) {
                    const u = ot(a, t, o);
                    n[o] ? (n[o].p(u, r), k(n[o], 1)) : (n[o] = dt(u), n[o].c(), k(n[o], 1), n[o].m(e.parentNode, e))
                }
                for (z(), o = t.length; o < n.length; o += 1) l(o);
                W()
            }
        },
        i(a) {
            if (!i) {
                for (let r = 0; r < t.length; r += 1) k(n[r]);
                i = !0
            }
        },
        o(a) {
            n = n.filter(Boolean);
            for (let r = 0; r < n.length; r += 1) v(n[r]);
            i = !1
        },
        d(a) {
            a && c(e), At(n, a)
        }
    }
}

function fn(s) {
    let e = [],
        i = new Map,
        t, n, l = Q(s[8]);
    const a = r => r[15].extId;
    for (let r = 0; r < l.length; r += 1) {
        let o = ut(s, l, r),
            u = a(o);
        i.set(u, e[r] = ft(u, o))
    }
    return {
        c() {
            for (let r = 0; r < e.length; r += 1) e[r].c();
            t = B()
        },
        l(r) {
            for (let o = 0; o < e.length; o += 1) e[o].l(r);
            t = B()
        },
        m(r, o) {
            for (let u = 0; u < e.length; u += 1) e[u] && e[u].m(r, o);
            h(r, t, o), n = !0
        },
        p(r, o) {
            o & 5989 && (l = Q(r[8]), z(), e = se(e, o, a, 1, r, l, i, t.parentNode, oe, ft, t, ut), W())
        },
        i(r) {
            if (!n) {
                for (let o = 0; o < l.length; o += 1) k(e[o]);
                n = !0
            }
        },
        o(r) {
            for (let o = 0; o < e.length; o += 1) v(e[o]);
            n = !1
        },
        d(r) {
            r && c(t);
            for (let o = 0; o < e.length; o += 1) e[o].d(r)
        }
    }
}

function dt(s) {
    let e, i;
    return e = new be({
        props: {
            name: typeof s[18] == "object" ? s[18].name : void 0,
            stacked: s[2],
            homeName: s[10],
            fixtureUrl: s[12],
            awayName: s[9],
            isMulti: s[6],
            index: s[17]
        }
    }), {
        c() {
            y(e.$$.fragment)
        },
        l(t) {
            T(e.$$.fragment, t)
        },
        m(t, n) {
            D(e, t, n), i = !0
        },
        p(t, n) {
            const l = {};
            n & 128 && (l.name = typeof t[18] == "object" ? t[18].name : void 0), n & 4 && (l.stacked = t[2]), n & 1024 && (l.homeName = t[10]), n & 512 && (l.awayName = t[9]), n & 64 && (l.isMulti = t[6]), e.$set(l)
        },
        i(t) {
            i || (k(e.$$.fragment, t), i = !0)
        },
        o(t) {
            v(e.$$.fragment, t), i = !1
        },
        d(t) {
            M(e, t)
        }
    }
}

function cn(s) {
    let e, i;
    return e = new be({
        props: {
            name: s[15].name,
            fixtureUrl: s[12],
            stacked: s[2],
            homeName: s[10],
            awayName: s[9],
            isMulti: s[6],
            index: s[17]
        }
    }), {
        c() {
            y(e.$$.fragment)
        },
        l(t) {
            T(e.$$.fragment, t)
        },
        m(t, n) {
            D(e, t, n), i = !0
        },
        p(t, n) {
            const l = {};
            n & 256 && (l.name = t[15].name), n & 4 && (l.stacked = t[2]), n & 1024 && (l.homeName = t[10]), n & 512 && (l.awayName = t[9]), n & 64 && (l.isMulti = t[6]), n & 256 && (l.index = t[17]), e.$set(l)
        },
        i(t) {
            i || (k(e.$$.fragment, t), i = !0)
        },
        o(t) {
            v(e.$$.fragment, t), i = !1
        },
        d(t) {
            M(e, t)
        }
    }
}

function kn(s) {
    let e = s[15].markets[0].specifiers,
        i, t, n = mt(s);
    return {
        c() {
            n.c(), i = B()
        },
        l(l) {
            n.l(l), i = B()
        },
        m(l, a) {
            n.m(l, a), h(l, i, a), t = !0
        },
        p(l, a) {
            a & 256 && Y(e, e = l[15].markets[0].specifiers) ? (z(), v(n, 1, 1, ce), W(), n = mt(l), n.c(), k(n, 1), n.m(i.parentNode, i)) : n.p(l, a)
        },
        i(l) {
            t || (k(n), t = !0)
        },
        o(l) {
            v(n), t = !1
        },
        d(l) {
            l && c(i), n.d(l)
        }
    }
}

function mt(s) {
    let e, i;
    return e = new Ji({
        props: {
            fixture: s[0],
            market: s[15].markets[0],
            isMulti: s[6],
            index: s[17],
            stacked: !1
        }
    }), {
        c() {
            y(e.$$.fragment)
        },
        l(t) {
            T(e.$$.fragment, t)
        },
        m(t, n) {
            D(e, t, n), i = !0
        },
        p(t, n) {
            const l = {};
            n & 1 && (l.fixture = t[0]), n & 256 && (l.market = t[15].markets[0]), n & 64 && (l.isMulti = t[6]), n & 256 && (l.index = t[17]), e.$set(l)
        },
        i(t) {
            i || (k(e.$$.fragment, t), i = !0)
        },
        o(t) {
            v(e.$$.fragment, t), i = !1
        },
        d(t) {
            M(e, t)
        }
    }
}

function ft(s, e) {
    let i, t, n, l, a;
    const r = [kn, cn],
        o = [];

    function u(d, f) {
        var m;
        return (m = d[15]) != null && m.markets[0] && !d[5] ? 0 : d[5] ? -1 : 1
    }
    return ~(t = u(e)) && (n = o[t] = r[t](e)), {
        key: s,
        first: null,
        c() {
            i = B(), n && n.c(), l = B(), this.h()
        },
        l(d) {
            i = B(), n && n.l(d), l = B(), this.h()
        },
        h() {
            this.first = i
        },
        m(d, f) {
            h(d, i, f), ~t && o[t].m(d, f), h(d, l, f), a = !0
        },
        p(d, f) {
            e = d;
            let m = t;
            t = u(e), t === m ? ~t && o[t].p(e, f) : (n && (z(), v(o[m], 1, 1, () => {
                o[m] = null
            }), W()), ~t ? (n = o[t], n ? n.p(e, f) : (n = o[t] = r[t](e), n.c()), k(n, 1), n.m(l.parentNode, l)) : n = null)
        },
        i(d) {
            a || (k(n), a = !0)
        },
        o(d) {
            v(n), a = !1
        },
        d(d) {
            d && (c(i), c(l)), ~t && o[t].d(d)
        }
    }
}

function _n(s) {
    let e, i, t, n, l;
    const a = [fn, mn, dn],
        r = [];

    function o(u, d) {
        return d & 33 && (e = null), u[11] && u[0].provider && u[0].status ? 0 : (e == null && (e = !!((!u[0].id || u[0].marketCount && Number(u[0].marketCount) === 0) && !u[5])), e ? 1 : u[5] ? -1 : 2)
    }
    return ~(i = o(s, -1)) && (t = r[i] = a[i](s)), {
        c() {
            t && t.c(), n = B()
        },
        l(u) {
            t && t.l(u), n = B()
        },
        m(u, d) {
            ~i && r[i].m(u, d), h(u, n, d), l = !0
        },
        p(u, d) {
            let f = i;
            i = o(u, d), i === f ? ~i && r[i].p(u, d) : (t && (z(), v(r[f], 1, 1, () => {
                r[f] = null
            }), W()), ~i ? (t = r[i], t ? t.p(u, d) : (t = r[i] = a[i](u), t.c()), k(t, 1), t.m(n.parentNode, n)) : t = null)
        },
        i(u) {
            l || (k(t), l = !0)
        },
        o(u) {
            v(t), l = !1
        },
        d(u) {
            u && c(n), ~i && r[i].d(u)
        }
    }
}

function vn(s) {
    let e, i;
    return e = new Pi({
        props: {
            fixture: s[0],
            isMulti: s[6],
            variant: s[3],
            stacked: s[2],
            showFullDate: s[1],
            displayBreadcrumb: s[4],
            isSearchFixture: s[5],
            $$slots: {
                default: [_n]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            y(e.$$.fragment)
        },
        l(t) {
            T(e.$$.fragment, t)
        },
        m(t, n) {
            D(e, t, n), i = !0
        },
        p(t, [n]) {
            const l = {};
            n & 1 && (l.fixture = t[0]), n & 64 && (l.isMulti = t[6]), n & 8 && (l.variant = t[3]), n & 4 && (l.stacked = t[2]), n & 2 && (l.showFullDate = t[1]), n & 16 && (l.displayBreadcrumb = t[4]), n & 32 && (l.isSearchFixture = t[5]), n & 1052645 && (l.$$scope = {
                dirty: n,
                ctx: t
            }), e.$set(l)
        },
        i(t) {
            i || (k(e.$$.fragment, t), i = !0)
        },
        o(t) {
            v(e.$$.fragment, t), i = !1
        },
        d(t) {
            M(e, t)
        }
    }
}

function hn(s, e, i) {
    let t, n, l, a, r, {
            fixture: o
        } = e,
        {
            templates: u
        } = e,
        {
            sortedTemplates: d
        } = e,
        {
            showFullDate: f = !0
        } = e,
        {
            stacked: m = !1
        } = e,
        {
            variant: _ = "light"
        } = e,
        {
            displayBreadcrumb: g = !1
        } = e,
        {
            isSearchFixture: p = !1
        } = e,
        {
            isMulti: w = !1
        } = e,
        F = Ne({
            data: o.data,
            tournament: o.tournament,
            slug: o.slug
        });
    return s.$$set = I => {
        "fixture" in I && i(0, o = I.fixture), "templates" in I && i(13, u = I.templates), "sortedTemplates" in I && i(14, d = I.sortedTemplates), "showFullDate" in I && i(1, f = I.showFullDate), "stacked" in I && i(2, m = I.stacked), "variant" in I && i(3, _ = I.variant), "displayBreadcrumb" in I && i(4, g = I.displayBreadcrumb), "isSearchFixture" in I && i(5, p = I.isSearchFixture), "isMulti" in I && i(6, w = I.isMulti)
    }, s.$$.update = () => {
        var I, S, V, L, J, j;
        s.$$.dirty & 8192 && i(11, t = u.length !== 0), s.$$.dirty & 1 && i(10, n = ((I = o.data) == null ? void 0 : I.__typename) !== "SportFixtureDataOutright" ? (V = (S = o.data) == null ? void 0 : S.competitors[0]) == null ? void 0 : V.name : void 0), s.$$.dirty & 1 && i(9, l = ((L = o.data) == null ? void 0 : L.__typename) !== "SportFixtureDataOutright" ? (j = (J = o.data) == null ? void 0 : J.competitors[1]) == null ? void 0 : j.name : void 0), s.$$.dirty & 24576 && i(8, a = d.map(K => {
            var O;
            return { ...K,
                markets: ((O = u == null ? void 0 : u.find(q => q.extId === K.extId)) == null ? void 0 : O.markets) ? ? []
            }
        }) || []), s.$$.dirty & 16448 && i(7, r = w ? d.length === 0 ? [0, 1, 2] : d : [0])
    }, [o, f, m, _, g, p, w, r, a, l, n, t, F, u, d]
}
class pn extends x {
    constructor(e) {
        super(), ee(this, e, hn, vn, Y, {
            fixture: 0,
            templates: 13,
            sortedTemplates: 14,
            showFullDate: 1,
            stacked: 2,
            variant: 3,
            displayBreadcrumb: 4,
            isSearchFixture: 5,
            isMulti: 6
        })
    }
}
const gn = {
    kind: "Document",
    definitions: [{
        kind: "OperationDefinition",
        operation: "subscription",
        name: {
            kind: "Name",
            value: "SportFixtureDataMatch_SportFixture"
        },
        variableDefinitions: [{
            kind: "VariableDefinition",
            variable: {
                kind: "Variable",
                name: {
                    kind: "Name",
                    value: "fixtureId"
                }
            },
            type: {
                kind: "NonNullType",
                type: {
                    kind: "NamedType",
                    name: {
                        kind: "Name",
                        value: "String"
                    }
                }
            }
        }, {
            kind: "VariableDefinition",
            variable: {
                kind: "Variable",
                name: {
                    kind: "Name",
                    value: "provider"
                }
            },
            type: {
                kind: "NonNullType",
                type: {
                    kind: "NamedType",
                    name: {
                        kind: "Name",
                        value: "SportsbookOddsProviderEnum"
                    }
                }
            }
        }],
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "sportFixture"
                },
                arguments: [{
                    kind: "Argument",
                    name: {
                        kind: "Name",
                        value: "fixtureId"
                    },
                    value: {
                        kind: "Variable",
                        name: {
                            kind: "Name",
                            value: "fixtureId"
                        }
                    }
                }, {
                    kind: "Argument",
                    name: {
                        kind: "Name",
                        value: "provider"
                    },
                    value: {
                        kind: "Variable",
                        name: {
                            kind: "Name",
                            value: "provider"
                        }
                    }
                }],
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "FragmentSpread",
                        name: {
                            kind: "Name",
                            value: "Preview_SportFixture"
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "FixtureMatchScore_SportFixture"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixture"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "status"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "tournament"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "category"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "sport"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "slug"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "eventStatus"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureEventStatusData"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "homeScore"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "awayScore"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "periodScores"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "homeScore"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "awayScore"
                                        }
                                    }]
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "EsportFixtureEventStatus"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "homeScore"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "awayScore"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "periodScores"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "homeScore"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "awayScore"
                                        }
                                    }]
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "scoreboard"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "homeKills"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "homeWonRounds"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "awayKills"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "awayWonRounds"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "FixtureOptionsOddin_SportFixture"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixture"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "extId"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "provider"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "status"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "widgetUrl"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "liveWidgetUrl"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "imgArenaStream"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "exists"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "geniussportsStream"
                },
                arguments: [{
                    kind: "Argument",
                    name: {
                        kind: "Name",
                        value: "deliveryType"
                    },
                    value: {
                        kind: "EnumValue",
                        value: "hls"
                    }
                }],
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "exists"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "betradarStream"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "exists"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "tournament"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "slug"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "frontRowSeatEvent"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "identifier"
                                }
                            }]
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "category"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "slug"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "sport"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "slug"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "data"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureDataMatch"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "competitors"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "abbreviation"
                                        }
                                    }]
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "tvChannels"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "streamUrl"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "language"
                                        }
                                    }]
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "startTime"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureDataOutright"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "name"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "startTime"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportCricketScore"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "competitors"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "abbreviation"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "FixtureOptionsBetRadar_SportFixture"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixture"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "extId"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "provider"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "status"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "widgetUrl"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "liveWidgetUrl"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "imgArenaStream"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "exists"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "geniussportsStream"
                },
                arguments: [{
                    kind: "Argument",
                    name: {
                        kind: "Name",
                        value: "deliveryType"
                    },
                    value: {
                        kind: "EnumValue",
                        value: "hls"
                    }
                }],
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "exists"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "betradarStream"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "exists"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "frontRowSeatFight"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "fightId"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "tournament"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "slug"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "frontRowSeatEvent"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "identifier"
                                }
                            }]
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "category"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "slug"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "sport"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "slug"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "data"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureDataMatch"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "competitors"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "abbreviation"
                                        }
                                    }]
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "tvChannels"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "streamUrl"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "language"
                                        }
                                    }]
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "startTime"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureDataOutright"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "name"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "startTime"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportCricketScore"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "competitors"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "abbreviation"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "FixtureOptions_SportFixture"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixture"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "FixtureOptionsOddin_SportFixture"
                }
            }, {
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "FixtureOptionsBetRadar_SportFixture"
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "FixtureScore_SportFixture"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixture"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "provider"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "eventStatus"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureEventStatusData"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "homeScore"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "awayScore"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "periodScores"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "homeScore"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "awayScore"
                                        }
                                    }]
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "EsportFixtureEventStatus"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "homeScore"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "awayScore"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "periodScores"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "homeScore"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "awayScore"
                                        }
                                    }]
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "scoreboard"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "homeKills"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "homeWonRounds"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "awayKills"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "awayWonRounds"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "tournament"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "category"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "sport"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "slug"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "Live_SportFixture"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixture"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "FixtureScore_SportFixture"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "provider"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "eventStatus"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureEventStatusData"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "matchStatus"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "periodScores"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "matchStatus"
                                        }
                                    }]
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "clock"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "matchTime"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "remainingTime"
                                        }
                                    }]
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "EsportFixtureEventStatus"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "matchStatus"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "periodScores"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "matchStatus"
                                        }
                                    }]
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "scoreboard"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "gameTime"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "remainingGameTime"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "tournament"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "category"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "sport"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "slug"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "Active_SportFixture"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixture"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "data"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureDataOutright"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "endTime"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureDataMatch"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "startTime"
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "FixtureStatus_SportFixture"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixture"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "status"
                }
            }, {
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "FixtureOptions_SportFixture"
                }
            }, {
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "Live_SportFixture"
                }
            }, {
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "Active_SportFixture"
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "Frame_SportFixture"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixture"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "FixtureMatchScore_SportFixture"
                }
            }, {
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "FixtureOptionsOddin_SportFixture"
                }
            }, {
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "FixtureOptionsBetRadar_SportFixture"
                }
            }, {
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "FixtureStatus_SportFixture"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "name"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "slug"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "eventStatus"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureEventStatusData"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "currentTeamServing"
                                }
                            }]
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "marketCount"
                },
                arguments: [{
                    kind: "Argument",
                    name: {
                        kind: "Name",
                        value: "status"
                    },
                    value: {
                        kind: "ListValue",
                        values: [{
                            kind: "EnumValue",
                            value: "active"
                        }, {
                            kind: "EnumValue",
                            value: "suspended"
                        }]
                    }
                }]
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "data"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureDataMatch"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "competitors"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "tournament"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "id"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "name"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "slug"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "category"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "id"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "name"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "slug"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "sport"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "id"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "slug"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "SportBetOutcome_SportFixture"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixture"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "status"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "provider"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "data"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportCricketScore"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "competitors"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }]
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureDataMatch"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "competitors"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "abbreviation"
                                        }
                                    }]
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "startTime"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureDataOutright"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "name"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "startTime"
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "Market_SportFixture"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixture"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "SportBetOutcome_SportFixture"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "status"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "data"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureDataMatch"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "teams"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "qualifier"
                                        }
                                    }]
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "competitors"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "abbreviation"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "Preview_SportFixture"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixture"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "Frame_SportFixture"
                }
            }, {
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "Market_SportFixture"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "provider"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "status"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "slug"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "marketCount"
                },
                arguments: [{
                    kind: "Argument",
                    name: {
                        kind: "Name",
                        value: "status"
                    },
                    value: {
                        kind: "ListValue",
                        values: [{
                            kind: "EnumValue",
                            value: "active"
                        }, {
                            kind: "EnumValue",
                            value: "suspended"
                        }]
                    }
                }]
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "tournament"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "slug"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "category"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "slug"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "sport"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "slug"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "data"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportCricketScore"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "competitors"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }]
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureDataMatch"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "competitors"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }]
};

function Sn(s) {
    let e, i;
    return e = new pn({
        props: {
            fixture: s[0],
            sortedTemplates: s[7],
            stacked: s[8],
            templates: s[5],
            variant: s[1],
            showFullDate: s[2],
            displayBreadcrumb: s[3],
            isSearchFixture: s[4],
            isMulti: s[6]
        }
    }), {
        c() {
            y(e.$$.fragment)
        },
        l(t) {
            T(e.$$.fragment, t)
        },
        m(t, n) {
            D(e, t, n), i = !0
        },
        p(t, [n]) {
            const l = {};
            n & 1 && (l.fixture = t[0]), n & 128 && (l.sortedTemplates = t[7]), n & 256 && (l.stacked = t[8]), n & 32 && (l.templates = t[5]), n & 2 && (l.variant = t[1]), n & 4 && (l.showFullDate = t[2]), n & 8 && (l.displayBreadcrumb = t[3]), n & 16 && (l.isSearchFixture = t[4]), n & 64 && (l.isMulti = t[6]), e.$set(l)
        },
        i(t) {
            i || (k(e.$$.fragment, t), i = !0)
        },
        o(t) {
            v(e.$$.fragment, t), i = !1
        },
        d(t) {
            M(e, t)
        }
    }
}

function Fn(s, e, i) {
    let t, n, l, a, r, o, {
            fixture: u
        } = e,
        {
            sortedTemplates: d
        } = e,
        {
            variant: f = "light"
        } = e,
        {
            showFullDate: m = !1
        } = e,
        {
            displayBreadcrumb: _ = !1
        } = e,
        {
            isSearchFixture: g = !1
        } = e,
        {
            group: p
        } = e,
        w = Fe();
    return re(s, w, F => i(8, o = F)), Lt(() => {
        const F = Dt();
        let I = yt(F.subscription(gn, {
            fixtureId: u == null ? void 0 : u.id,
            provider: (u == null ? void 0 : u.provider) ? ? Se.betradar
        }), Tt(({
            data: S
        }) => {
            let V = S == null ? void 0 : S.sportFixture;
            V && i(0, u = { ...u,
                ...V
            })
        }));
        return () => {
            I.unsubscribe()
        }
    }), s.$$set = F => {
        "fixture" in F && i(0, u = F.fixture), "sortedTemplates" in F && i(10, d = F.sortedTemplates), "variant" in F && i(1, f = F.variant), "showFullDate" in F && i(2, m = F.showFullDate), "displayBreadcrumb" in F && i(3, _ = F.displayBreadcrumb), "isSearchFixture" in F && i(4, g = F.isSearchFixture), "group" in F && i(11, p = F.group)
    }, s.$$.update = () => {
        s.$$.dirty & 1 && i(13, t = u != null && u.groups[0] ? u.groups[0].templates.map(F => {
            var V;
            const S = (((V = F.markets) == null ? void 0 : V.filter(L => L && qt.includes(L.status))) || []).sort((L, J) => Math.abs(Number(Te(L.specifiers))) - Math.abs(Number(Te(J.specifiers))));
            return { ...F,
                markets: S
            }
        }) : []), s.$$.dirty & 10240 && i(12, n = p === $e ? (t == null ? void 0 : t.filter(F => F.markets.length > 0)) || [] : t), s.$$.dirty & 2048 && i(6, l = p ? jt.includes(p) : !1), s.$$.dirty & 6208 && i(5, a = n.slice(0, !l || p === $e ? 1 : 3)), s.$$.dirty & 1120 && i(7, r = l ? d.slice(0, 3) : a)
    }, [u, f, m, _, g, a, l, r, o, w, d, p, n, t]
}
class Bt extends x {
    constructor(e) {
        super(), ee(this, e, Fn, Sn, Y, {
            fixture: 0,
            sortedTemplates: 10,
            variant: 1,
            showFullDate: 2,
            displayBreadcrumb: 3,
            isSearchFixture: 4,
            group: 11
        })
    }
}

function ct(s) {
    let e, i;
    return e = new Qt({
        props: {
            value: s[0]
        }
    }), {
        c() {
            y(e.$$.fragment)
        },
        l(t) {
            T(e.$$.fragment, t)
        },
        m(t, n) {
            D(e, t, n), i = !0
        },
        p(t, n) {
            const l = {};
            n & 1 && (l.value = t[0]), e.$set(l)
        },
        i(t) {
            i || (k(e.$$.fragment, t), i = !0)
        },
        o(t) {
            v(e.$$.fragment, t), i = !1
        },
        d(t) {
            M(e, t)
        }
    }
}

function Nn(s) {
    let e, i, t = s[0] && ct(s);
    return {
        c() {
            e = N("div"), t && t.c(), this.h()
        },
        l(n) {
            e = b(n, "DIV", {
                class: !0
            });
            var l = $(e);
            t && t.l(l), l.forEach(c), this.h()
        },
        h() {
            E(e, "class", "group-time svelte-5qjj7e")
        },
        m(n, l) {
            h(n, e, l), t && t.m(e, null), i = !0
        },
        p(n, [l]) {
            n[0] ? t ? (t.p(n, l), l & 1 && k(t, 1)) : (t = ct(n), t.c(), k(t, 1), t.m(e, null)) : t && (z(), v(t, 1, 1, () => {
                t = null
            }), W())
        },
        i(n) {
            i || (k(t), i = !0)
        },
        o(n) {
            v(t), i = !1
        },
        d(n) {
            n && c(e), t && t.d()
        }
    }
}

function bn(s, e, i) {
    let {
        startTime: t
    } = e;
    return s.$$set = n => {
        "startTime" in n && i(0, t = n.startTime)
    }, [t]
}
class $n extends x {
    constructor(e) {
        super(), ee(this, e, bn, Nn, Y, {
            startTime: 0
        })
    }
}

function kt(s, e, i) {
    const t = s.slice();
    return t[9] = e[i].fixture, t[12] = e[i].__element, t[11] = i, t
}
const wn = s => ({}),
    _t = s => ({}),
    yn = s => ({}),
    vt = s => ({}),
    Tn = s => ({}),
    ht = s => ({});

function pt(s, e, i) {
    const t = s.slice();
    return t[9] = e[i], t[11] = i, t
}
const Dn = s => ({}),
    gt = s => ({}),
    Mn = s => ({}),
    St = s => ({});

function En(s) {
    let e = [],
        i = new Map,
        t, n, l = Q(s[6]);
    const a = r => r[9].id + r[12];
    for (let r = 0; r < l.length; r += 1) {
        let o = kt(s, l, r),
            u = a(o);
        i.set(u, e[r] = Ft(u, o))
    }
    return {
        c() {
            for (let r = 0; r < e.length; r += 1) e[r].c();
            t = B()
        },
        l(r) {
            for (let o = 0; o < e.length; o += 1) e[o].l(r);
            t = B()
        },
        m(r, o) {
            for (let u = 0; u < e.length; u += 1) e[u] && e[u].m(r, o);
            h(r, t, o), n = !0
        },
        p(r, o) {
            o & 250 && (l = Q(r[6]), z(), e = se(e, o, a, 1, r, l, i, t.parentNode, oe, Ft, t, kt), W())
        },
        i(r) {
            if (!n) {
                for (let o = 0; o < l.length; o += 1) k(e[o]);
                n = !0
            }
        },
        o(r) {
            for (let o = 0; o < e.length; o += 1) v(e[o]);
            n = !1
        },
        d(r) {
            r && c(t);
            for (let o = 0; o < e.length; o += 1) e[o].d(r)
        }
    }
}

function In(s) {
    let e = [],
        i = new Map,
        t, n, l = Q(s[0]);
    const a = r => r[9].id;
    for (let r = 0; r < l.length; r += 1) {
        let o = pt(s, l, r),
            u = a(o);
        i.set(u, e[r] = Nt(u, o))
    }
    return {
        c() {
            for (let r = 0; r < e.length; r += 1) e[r].c();
            t = B()
        },
        l(r) {
            for (let o = 0; o < e.length; o += 1) e[o].l(r);
            t = B()
        },
        m(r, o) {
            for (let u = 0; u < e.length; u += 1) e[u] && e[u].m(r, o);
            h(r, t, o), n = !0
        },
        p(r, o) {
            o & 187 && (l = Q(r[0]), z(), e = se(e, o, a, 1, r, l, i, t.parentNode, oe, Nt, t, pt), W())
        },
        i(r) {
            if (!n) {
                for (let o = 0; o < l.length; o += 1) k(e[o]);
                n = !0
            }
        },
        o(r) {
            for (let o = 0; o < e.length; o += 1) v(e[o]);
            n = !1
        },
        d(r) {
            r && c(t);
            for (let o = 0; o < e.length; o += 1) e[o].d(r)
        }
    }
}

function Vn(s) {
    let e, i = s[9].id + "",
        t;
    return {
        c() {
            e = N("span"), t = H(i)
        },
        l(n) {
            e = b(n, "SPAN", {});
            var l = $(e);
            t = G(l, i), l.forEach(c)
        },
        m(n, l) {
            h(n, e, l), C(e, t)
        },
        p(n, l) {
            l & 64 && i !== (i = n[9].id + "") && Z(t, i)
        },
        i: ce,
        o: ce,
        d(n) {
            n && c(e)
        }
    }
}

function Cn(s) {
    let e, i, t;
    e = new Ot({
        props: {
            fixture: s[9]
        }
    });
    const n = s[8].divider,
        l = ue(n, s, s[7], _t);
    return {
        c() {
            y(e.$$.fragment), i = U(), l && l.c()
        },
        l(a) {
            T(e.$$.fragment, a), i = P(a), l && l.l(a)
        },
        m(a, r) {
            D(e, a, r), h(a, i, r), l && l.m(a, r), t = !0
        },
        p(a, r) {
            const o = {};
            r & 64 && (o.fixture = a[9]), e.$set(o), l && l.p && (!t || r & 128) && de(l, n, a, a[7], t ? fe(n, a[7], r, wn) : me(a[7]), _t)
        },
        i(a) {
            t || (k(e.$$.fragment, a), k(l, a), t = !0)
        },
        o(a) {
            v(e.$$.fragment, a), v(l, a), t = !1
        },
        d(a) {
            a && c(i), M(e, a), l && l.d(a)
        }
    }
}

function On(s) {
    let e, i, t;
    e = new Bt({
        props: {
            variant: s[11] === 0 ? "transparent" : "light",
            fixture: s[9],
            group: s[5],
            sortedTemplates: s[1],
            displayBreadcrumb: s[3],
            isSearchFixture: s[4]
        }
    });
    const n = s[8].divider,
        l = ue(n, s, s[7], vt);
    return {
        c() {
            y(e.$$.fragment), i = U(), l && l.c()
        },
        l(a) {
            T(e.$$.fragment, a), i = P(a), l && l.l(a)
        },
        m(a, r) {
            D(e, a, r), h(a, i, r), l && l.m(a, r), t = !0
        },
        p(a, r) {
            const o = {};
            r & 64 && (o.variant = a[11] === 0 ? "transparent" : "light"), r & 64 && (o.fixture = a[9]), r & 32 && (o.group = a[5]), r & 2 && (o.sortedTemplates = a[1]), r & 8 && (o.displayBreadcrumb = a[3]), r & 16 && (o.isSearchFixture = a[4]), e.$set(o), l && l.p && (!t || r & 128) && de(l, n, a, a[7], t ? fe(n, a[7], r, yn) : me(a[7]), vt)
        },
        i(a) {
            t || (k(e.$$.fragment, a), k(l, a), t = !0)
        },
        o(a) {
            v(e.$$.fragment, a), v(l, a), t = !1
        },
        d(a) {
            a && c(i), M(e, a), l && l.d(a)
        }
    }
}

function Bn(s) {
    let e, i, t;
    e = new $n({
        props: {
            startTime: s[9].data.startTime
        }
    });
    const n = s[8].divider,
        l = ue(n, s, s[7], ht);
    return {
        c() {
            y(e.$$.fragment), i = U(), l && l.c()
        },
        l(a) {
            T(e.$$.fragment, a), i = P(a), l && l.l(a)
        },
        m(a, r) {
            D(e, a, r), h(a, i, r), l && l.m(a, r), t = !0
        },
        p(a, r) {
            const o = {};
            r & 64 && (o.startTime = a[9].data.startTime), e.$set(o), l && l.p && (!t || r & 128) && de(l, n, a, a[7], t ? fe(n, a[7], r, Tn) : me(a[7]), ht)
        },
        i(a) {
            t || (k(e.$$.fragment, a), k(l, a), t = !0)
        },
        o(a) {
            v(e.$$.fragment, a), v(l, a), t = !1
        },
        d(a) {
            a && c(i), M(e, a), l && l.d(a)
        }
    }
}

function Ft(s, e) {
    let i, t, n, l, a;
    const r = [Bn, On, Cn, Vn],
        o = [];

    function u(d, f) {
        var m, _, g, p;
        return d[12] === "GroupTime" && (((m = d[9].data) == null ? void 0 : m.__typename) === "SportFixtureDataMatch" || ((_ = d[9].data) == null ? void 0 : _.__typename) === "SportFixtureDataOutright") ? 0 : ((g = d[9].data) == null ? void 0 : g.__typename) === "SportFixtureDataMatch" ? 1 : ((p = d[9].data) == null ? void 0 : p.__typename) === "SportFixtureDataOutright" ? 2 : 3
    }
    return t = u(e), n = o[t] = r[t](e), {
        key: s,
        first: null,
        c() {
            i = B(), n.c(), l = B(), this.h()
        },
        l(d) {
            i = B(), n.l(d), l = B(), this.h()
        },
        h() {
            this.first = i
        },
        m(d, f) {
            h(d, i, f), o[t].m(d, f), h(d, l, f), a = !0
        },
        p(d, f) {
            e = d;
            let m = t;
            t = u(e), t === m ? o[t].p(e, f) : (z(), v(o[m], 1, 1, () => {
                o[m] = null
            }), W(), n = o[t], n ? n.p(e, f) : (n = o[t] = r[t](e), n.c()), k(n, 1), n.m(l.parentNode, l))
        },
        i(d) {
            a || (k(n), a = !0)
        },
        o(d) {
            v(n), a = !1
        },
        d(d) {
            d && (c(i), c(l)), o[t].d(d)
        }
    }
}

function An(s) {
    let e, i, t;
    e = new Ot({
        props: {
            fixture: s[9]
        }
    });
    const n = s[8].divider,
        l = ue(n, s, s[7], gt);
    return {
        c() {
            y(e.$$.fragment), i = U(), l && l.c()
        },
        l(a) {
            T(e.$$.fragment, a), i = P(a), l && l.l(a)
        },
        m(a, r) {
            D(e, a, r), h(a, i, r), l && l.m(a, r), t = !0
        },
        p(a, r) {
            const o = {};
            r & 1 && (o.fixture = a[9]), e.$set(o), l && l.p && (!t || r & 128) && de(l, n, a, a[7], t ? fe(n, a[7], r, Dn) : me(a[7]), gt)
        },
        i(a) {
            t || (k(e.$$.fragment, a), k(l, a), t = !0)
        },
        o(a) {
            v(e.$$.fragment, a), v(l, a), t = !1
        },
        d(a) {
            a && c(i), M(e, a), l && l.d(a)
        }
    }
}

function Ln(s) {
    let e, i, t;
    e = new Bt({
        props: {
            showFullDate: !0,
            variant: s[11] === 0 ? "transparent" : "light",
            sortedTemplates: s[1],
            fixture: s[9],
            group: s[5],
            displayBreadcrumb: s[3],
            isSearchFixture: s[4]
        }
    });
    const n = s[8].divider,
        l = ue(n, s, s[7], St);
    return {
        c() {
            y(e.$$.fragment), i = U(), l && l.c()
        },
        l(a) {
            T(e.$$.fragment, a), i = P(a), l && l.l(a)
        },
        m(a, r) {
            D(e, a, r), h(a, i, r), l && l.m(a, r), t = !0
        },
        p(a, r) {
            const o = {};
            r & 1 && (o.variant = a[11] === 0 ? "transparent" : "light"), r & 2 && (o.sortedTemplates = a[1]), r & 1 && (o.fixture = a[9]), r & 32 && (o.group = a[5]), r & 8 && (o.displayBreadcrumb = a[3]), r & 16 && (o.isSearchFixture = a[4]), e.$set(o), l && l.p && (!t || r & 128) && de(l, n, a, a[7], t ? fe(n, a[7], r, Mn) : me(a[7]), St)
        },
        i(a) {
            t || (k(e.$$.fragment, a), k(l, a), t = !0)
        },
        o(a) {
            v(e.$$.fragment, a), v(l, a), t = !1
        },
        d(a) {
            a && c(i), M(e, a), l && l.d(a)
        }
    }
}

function Nt(s, e) {
    let i, t, n, l, a;
    const r = [Ln, An],
        o = [];

    function u(d, f) {
        var m, _;
        return ((m = d[9].data) == null ? void 0 : m.__typename) === "SportFixtureDataMatch" ? 0 : ((_ = d[9].data) == null ? void 0 : _.__typename) === "SportFixtureDataOutright" ? 1 : -1
    }
    return ~(t = u(e)) && (n = o[t] = r[t](e)), {
        key: s,
        first: null,
        c() {
            i = B(), n && n.c(), l = B(), this.h()
        },
        l(d) {
            i = B(), n && n.l(d), l = B(), this.h()
        },
        h() {
            this.first = i
        },
        m(d, f) {
            h(d, i, f), ~t && o[t].m(d, f), h(d, l, f), a = !0
        },
        p(d, f) {
            e = d;
            let m = t;
            t = u(e), t === m ? ~t && o[t].p(e, f) : (n && (z(), v(o[m], 1, 1, () => {
                o[m] = null
            }), W()), ~t ? (n = o[t], n ? n.p(e, f) : (n = o[t] = r[t](e), n.c()), k(n, 1), n.m(l.parentNode, l)) : n = null)
        },
        i(d) {
            a || (k(n), a = !0)
        },
        o(d) {
            v(n), a = !1
        },
        d(d) {
            d && (c(i), c(l)), ~t && o[t].d(d)
        }
    }
}

function Un(s) {
    let e, i, t, n;
    const l = [In, En],
        a = [];

    function r(o, u) {
        return o[2] === !1 ? 0 : 1
    }
    return i = r(s), t = a[i] = l[i](s), {
        c() {
            e = N("div"), t.c(), this.h()
        },
        l(o) {
            e = b(o, "DIV", {
                class: !0
            });
            var u = $(e);
            t.l(u), u.forEach(c), this.h()
        },
        h() {
            E(e, "class", "fixture-wrapper")
        },
        m(o, u) {
            h(o, e, u), a[i].m(e, null), n = !0
        },
        p(o, [u]) {
            let d = i;
            i = r(o), i === d ? a[i].p(o, u) : (z(), v(a[d], 1, 1, () => {
                a[d] = null
            }), W(), t = a[i], t ? t.p(o, u) : (t = a[i] = l[i](o), t.c()), k(t, 1), t.m(e, null))
        },
        i(o) {
            n || (k(t), n = !0)
        },
        o(o) {
            v(t), n = !1
        },
        d(o) {
            o && c(e), a[i].d()
        }
    }
}

function Pn(s, e, i) {
    let t, {
            $$slots: n = {},
            $$scope: l
        } = e,
        {
            fixtureList: a = []
        } = e,
        {
            sortedTemplates: r = []
        } = e,
        {
            addTimeElements: o = !1
        } = e,
        {
            displayBreadcrumb: u = !1
        } = e,
        {
            isSearchFixture: d = !1
        } = e,
        {
            group: f
        } = e;
    return s.$$set = m => {
        "fixtureList" in m && i(0, a = m.fixtureList), "sortedTemplates" in m && i(1, r = m.sortedTemplates), "addTimeElements" in m && i(2, o = m.addTimeElements), "displayBreadcrumb" in m && i(3, u = m.displayBreadcrumb), "isSearchFixture" in m && i(4, d = m.isSearchFixture), "group" in m && i(5, f = m.group), "$$scope" in m && i(7, l = m.$$scope)
    }, s.$$.update = () => {
        s.$$.dirty & 5 && i(6, t = o ? Wt(a) : [])
    }, [a, r, o, u, d, f, t, l, n]
}
class ol extends x {
    constructor(e) {
        super(), ee(this, e, Pn, Un, Y, {
            fixtureList: 0,
            sortedTemplates: 1,
            addTimeElements: 2,
            displayBreadcrumb: 3,
            isSearchFixture: 4,
            group: 5
        })
    }
}
export {
    ol as F, vi as L, Ji as M, Ct as a, zi as t
};