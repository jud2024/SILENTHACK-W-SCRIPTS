import {
    x as a,
    v as e
} from "./scheduler.DXu26z7T.js";
import {
    w as r
} from "./index.C2-CG2CN.js";
const s = "@@layout",
    i = () => {
        const t = r(1200);
        return e(s, t), t
    },
    m = () => a(s),
    p = ({
        viewportSize: t,
        maxWidth: o = 768
    }) => t < o,
    u = ({
        viewportSize: t,
        minWidth: o = 1024
    }) => t >= o;
export {
    u as a, i as c, m as g, p as i
};