import {
    s as M,
    a as g,
    e as z,
    d as A,
    f as B,
    i as p,
    F as G,
    j as h,
    W as S,
    u as $,
    g as b,
    b as v,
    r as K,
    c as d,
    X as Q,
    w as R,
    J as U,
    O as Y,
    m as D,
    P as Z,
    N
} from "./scheduler.DXu26z7T.js";
import {
    S as j,
    i as y,
    t as u,
    b as c,
    c as C,
    a as F,
    m as J,
    d as L,
    g as x,
    e as ee
} from "./index.Dz_MmNB3.js";
import {
    c as te
} from "./shared.G3i0PjK-.js";
import {
    g as oe
} from "./context.C4qMQqMz.js";
import {
    T as se
} from "./index.CYsK4uyl.js";
const ne = t => ({
        hovering: t & 14,
        node: t & 1
    }),
    E = t => ({
        hovering: t[1] ? !1 : t[2] && t[3],
        node: t[0]
    });

function le(t) {
    let o, r, e, n;
    const a = t[11].default,
        l = g(a, t, t[10], E);
    return {
        c() {
            o = z("div"), l && l.c(), this.h()
        },
        l(s) {
            o = A(s, "DIV", {
                class: !0
            });
            var i = B(o);
            l && l.l(i), i.forEach(p), this.h()
        },
        h() {
            G(o, "class", "hoverable svelte-bbyuql")
        },
        m(s, i) {
            h(s, o, i), l && l.m(o, null), t[12](o), r = !0, e || (n = [S(o, "pointerenter", t[7]), S(o, "pointerleave", t[8])], e = !0)
        },
        p(s, [i]) {
            l && l.p && (!r || i & 1039) && $(l, a, s, s[10], r ? v(a, s[10], i, ne) : b(s[10]), E)
        },
        i(s) {
            r || (u(l, s), r = !0)
        },
        o(s) {
            c(l, s), r = !1
        },
        d(s) {
            s && p(o), l && l.d(s), t[12](null), e = !1, K(n)
        }
    }
}

function re(t, o, r) {
    let e, n, a, l, {
        $$slots: s = {},
        $$scope: i
    } = o;
    const T = oe();
    d(t, T, f => r(9, n = f));
    const w = Q();
    let _, P;
    const m = te(),
        {
            hovering: k,
            sharedHovering: H
        } = m;
    d(t, k, f => r(2, a = f)), d(t, H, f => r(3, l = f)), R(() => {
        clearTimeout(P)
    });
    const V = f => {
            f.pointerType !== "touch" && (m.enter(), w("mouseenter"))
        },
        W = f => {
            f.pointerType !== "touch" && (m.leave(), w("mouseleave"))
        };

    function X(f) {
        U[f ? "unshift" : "push"](() => {
            _ = f, r(0, _)
        })
    }
    return t.$$set = f => {
        "$$scope" in f && r(10, i = f.$$scope)
    }, t.$$.update = () => {
        t.$$.dirty & 512 && r(1, e = n ? n.isOpen : !1)
    }, [_, e, a, l, T, k, H, V, W, n, i, s, X]
}
class ae extends j {
    constructor(o) {
        super(), y(this, o, re, le, M, {})
    }
}
const ie = t => ({}),
    O = t => ({}),
    fe = t => ({
        showTooltip: t & 16
    }),
    q = t => ({
        showTooltip: t[4]
    });

function I(t) {
    let o, r;
    return o = new se({
        props: {
            parentNode: t[5],
            $$slots: {
                default: [ue]
            },
            $$scope: {
                ctx: t
            }
        }
    }), {
        c() {
            C(o.$$.fragment)
        },
        l(e) {
            F(o.$$.fragment, e)
        },
        m(e, n) {
            J(o, e, n), r = !0
        },
        p(e, n) {
            const a = {};
            n & 32 && (a.parentNode = e[5]), n & 8 && (a.$$scope = {
                dirty: n,
                ctx: e
            }), o.$set(a)
        },
        i(e) {
            r || (u(o.$$.fragment, e), r = !0)
        },
        o(e) {
            c(o.$$.fragment, e), r = !1
        },
        d(e) {
            L(o, e)
        }
    }
}

function ue(t) {
    let o;
    const r = t[0].tooltip,
        e = g(r, t, t[3], O);
    return {
        c() {
            e && e.c()
        },
        l(n) {
            e && e.l(n)
        },
        m(n, a) {
            e && e.m(n, a), o = !0
        },
        p(n, a) {
            e && e.p && (!o || a & 8) && $(e, r, n, n[3], o ? v(r, n[3], a, ie) : b(n[3]), O)
        },
        i(n) {
            o || (u(e, n), o = !0)
        },
        o(n) {
            c(e, n), o = !1
        },
        d(n) {
            e && e.d(n)
        }
    }
}

function ce(t) {
    let o, r, e;
    const n = t[0].default,
        a = g(n, t, t[3], q);
    let l = t[4] && I(t);
    return {
        c() {
            a && a.c(), o = Y(), l && l.c(), r = D()
        },
        l(s) {
            a && a.l(s), o = Z(s), l && l.l(s), r = D()
        },
        m(s, i) {
            a && a.m(s, i), h(s, o, i), l && l.m(s, i), h(s, r, i), e = !0
        },
        p(s, i) {
            a && a.p && (!e || i & 24) && $(a, n, s, s[3], e ? v(n, s[3], i, fe) : b(s[3]), q), s[4] ? l ? (l.p(s, i), i & 16 && u(l, 1)) : (l = I(s), l.c(), u(l, 1), l.m(r.parentNode, r)) : l && (x(), c(l, 1, 1, () => {
                l = null
            }), ee())
        },
        i(s) {
            e || (u(a, s), u(l), e = !0)
        },
        o(s) {
            c(a, s), c(l), e = !1
        },
        d(s) {
            s && (p(o), p(r)), a && a.d(s), l && l.d(s)
        }
    }
}

function pe(t) {
    let o, r;
    return o = new ae({
        props: {
            $$slots: {
                default: [ce, ({
                    hovering: e,
                    node: n
                }) => ({
                    4: e,
                    5: n
                }), ({
                    hovering: e,
                    node: n
                }) => (e ? 16 : 0) | (n ? 32 : 0)]
            },
            $$scope: {
                ctx: t
            }
        }
    }), o.$on("mouseenter", t[1]), o.$on("mouseleave", t[2]), {
        c() {
            C(o.$$.fragment)
        },
        l(e) {
            F(o.$$.fragment, e)
        },
        m(e, n) {
            J(o, e, n), r = !0
        },
        p(e, [n]) {
            const a = {};
            n & 56 && (a.$$scope = {
                dirty: n,
                ctx: e
            }), o.$set(a)
        },
        i(e) {
            r || (u(o.$$.fragment, e), r = !0)
        },
        o(e) {
            c(o.$$.fragment, e), r = !1
        },
        d(e) {
            L(o, e)
        }
    }
}

function _e(t, o, r) {
    let {
        $$slots: e = {},
        $$scope: n
    } = o;

    function a(s) {
        N.call(this, t, s)
    }

    function l(s) {
        N.call(this, t, s)
    }
    return t.$$set = s => {
        "$$scope" in s && r(3, n = s.$$scope)
    }, [e, a, l, n]
}
class be extends j {
    constructor(o) {
        super(), y(this, o, _e, pe, M, {})
    }
}
export {
    be as H
};