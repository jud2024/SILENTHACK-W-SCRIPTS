import {
    aI as S,
    bM as D,
    bq as w,
    bN as I,
    bO as M,
    bP as T,
    bd as b,
    bQ as $,
    bR as q,
    bS as A,
    bT as G,
    bU as O,
    bV as U,
    b as N,
    e as Q,
    bW as j,
    aG as B,
    a$ as H,
    w as K,
    f as h,
    ae as V,
    Y as W,
    R as z,
    bX as X
} from "../chunks/index.B4-7gKq3.js";
import {
    G as Y,
    s as x,
    a as J,
    O as Z,
    P as ee,
    j as te,
    u as ne,
    g as se,
    b as ae,
    i as oe
} from "../chunks/scheduler.DXu26z7T.js";
import {
    o as re
} from "../chunks/urql-svelte.Jmuk7rkA.js";
import {
    l as ie
} from "../chunks/helpers.TV7w6l2o.js";
import {
    l as le
} from "../chunks/auth.BoP-Nqg0.js";
import {
    U as ce
} from "../chunks/UserPreferenceMeta.generated.BbBaS4J9.js";
import {
    p as g
} from "../chunks/index.B81orGJm.js";
import {
    e as ue
} from "../chunks/index.g5YcAAdQ.js";
import {
    w as k
} from "../chunks/index.C2-CG2CN.js";
import {
    C as me
} from "../chunks/CurrentAnnouncements.generated.Cniolakq.js";
import {
    G as pe
} from "../chunks/GetFeatureFlags.generated.CL24m5OL.js";
import {
    f as de,
    s as fe,
    a as he,
    r as Se,
    c as ge,
    p as be,
    l as ye
} from "../chunks/_api.D0-JRCgy.js";
import {
    g as ke
} from "../chunks/roles.CMi1bAOW.js";
import {
    b as _e
} from "../chunks/stores.C1s9-Gyh.js";
import {
    S as E,
    i as F,
    c as ve,
    a as xe,
    m as Ee,
    t as _,
    b as v,
    d as Fe
} from "../chunks/index.Dz_MmNB3.js";

function Re({
    client: r
}) {
    return async function(a, o, n) {
        try {
            const t = re(a, o, n),
                e = await r.query(t.query, t.variables, t.context).toPromise();
            return Object.assign(Y(t), { ...e,
                context: { ...t.context,
                    requestPolicy: "cache-only"
                }
            }), t
        } catch (t) {
            return S.next({
                type: "errorExchange",
                error: (t == null ? void 0 : t.message) || "Mutation error"
            }), t
        }
    }
}
const Ce = ({
        forward: r
    }) => s => b(r(s), G(({
        error: a
    }) => {
        const o = a == null ? void 0 : a.graphQLErrors,
            n = a == null ? void 0 : a.networkError;
        o ? o.forEach(({
            originalError: t
        }) => {
            S.next({
                type: (t == null ? void 0 : t.errorType) || "errorExchange",
                error: t
            })
        }) : n && S.next({
            type: "errorExchange",
            error: n
        })
    })),
    Pe = r => ({
        forward: s
    }) => a => b(a, O(o => {
        const n = r(o.context.fetchOptions);
        return b(typeof n.then == "function" ? U(n) : N(n), Q(t => ({ ...o,
            context: { ...o.context,
                fetchOptions: t
            }
        })))
    }), s),
    Le = {},
    De = (r, s) => {
        const a = () => H(),
            o = () => K(),
            n = Pe(async u => {
                const c = a(),
                    m = { ...u,
                        headers: { ...c ? {
                                "x-access-token": c
                            } : {},
                            "x-language": o(),
                            ...Le
                        }
                    };
                return Promise.resolve(m)
            }),
            e = [$({
                forwardSubscription(u) {
                    return {
                        subscribe: c => ({
                            unsubscribe: j.subscribe({ ...u,
                                query: typeof u.query == "string" ? u.query : B(u.query)
                            }, {
                                error: m => {
                                    c.error(m), S.next({
                                        type: "errorExchange",
                                        error: m
                                    })
                                },
                                ...c
                            })
                        })
                    }
                }
            })],
            l = q({
                resolvers: {
                    Subscription: {
                        sportMarket: (u, c) => ({
                            __typename: "SportMarket",
                            marketId: c.marketId
                        })
                    },
                    Query: {
                        sportMarket: (u, c) => ({
                            __typename: "SportMarket",
                            id: c.marketId
                        })
                    }
                },
                keys: {
                    UserFlag: () => null,
                    Balance: () => null,
                    UserBalance: () => null,
                    UserRole: () => null,
                    GameKuratorGame: () => null,
                    SportGroup: () => null,
                    SportGroupTemplate: () => null,
                    SportFixtureDataOutright: () => null,
                    SportFixtureDataMatch: () => null,
                    SportFixtureEventStatusStatisticHomeAway: () => null,
                    SportFixtureEventStatusPeriodScore: () => null,
                    FixtureSportEventStatusStatistic: () => null,
                    SportFixtureEventStatusClock: () => null,
                    SportFixtureEventStatus: () => null,
                    SportFixtureCompetitor: () => null,
                    ChatMessageDataText: () => null,
                    ChatMessageDataRain: () => null,
                    ChatMessageDataTip: () => null,
                    RacePosition: () => null,
                    ChatMessageDataRace: () => null,
                    ChatMessageDataBot: () => null,
                    ChatRainUser: () => null,
                    ChatRain: () => null,
                    GameKuratorFilter: () => null,
                    CommunityUser: () => null,
                    Info: () => null,
                    InfoCurrency: () => null,
                    InfoSetting: () => null,
                    InfoRole: () => null
                },
                schema: A
            });
        return D({
            url: w,
            fetch: s,
            requestPolicy: "network-only",
            exchanges: [I, M, l, ...e, n, Ce, T]
        })
    },
    we = r => h({
        doc: ce,
        load: r,
        variables: {}
    }),
    Ie = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "query",
            name: {
                kind: "Name",
                value: "InfoRoles"
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "info"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "roles"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "include"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "exclude"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "modify"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }]
    },
    Me = !1,
    Te = async r => {
        var s, a, o;
        try {
            const n = ((s = r.data) == null ? void 0 : s.session) ? ? {},
                t = await r.parent(),
                e = { ...r,
                    data: { ...r.data,
                        ...t
                    }
                },
                l = De(n, e.fetch),
                y = n.isAuthenticated ? we(e).then(i => k(i)) : Promise.resolve(k(void 0)),
                u = Promise.all([de(e, {
                    type: V.live
                }), g ? fe(e) : Promise.resolve(void 0), g ? he(e) : Promise.resolve(void 0), g ? Se(e) : Promise.resolve(void 0), ge(e, {
                    type: W.sidebar,
                    isActivePlayersFeatureFlagOn: !1
                }), be(e, {
                    isAuthenticated: n.isAuthenticated
                }), ye(e)]).then(i => ({
                    fixtureCount: i[0],
                    sportSidebar: i[1],
                    topSportSidebar: i[2],
                    racingSidebar: i[3],
                    casinoLinks: i[4],
                    promotion: i[5],
                    sponsorshipMenuItems: i[6]
                })),
                [c, p, m, d, f, R, C, P, L] = await Promise.all([y, ie(e), z.fetch(e), le({ ...e,
                    isAuthenticated: n.isAuthenticated
                }), h({
                    load: e,
                    doc: Ie,
                    variables: {}
                }), u, h({
                    doc: me,
                    load: e,
                    variables: {}
                }).then(i => (i == null ? void 0 : i.currentAnnouncements) || []), h({
                    doc: pe,
                    load: e,
                    variables: {
                        limit: 50,
                        offset: 0
                    }
                }).then(i => (i == null ? void 0 : i.featureFlagList) || []), _e({ ...e,
                    isAuthenticated: n.isAuthenticated
                })]);
            return {
                session: n,
                featureFlagResponse: P,
                userTransactionEligibilityResponse: L,
                restrictedRegionData: p,
                conversionsRates: m,
                leftSidebar: R,
                authResponse: { ...d,
                    includedRoles: ke({
                        infoRoles: ((a = f == null ? void 0 : f.info) == null ? void 0 : a.roles) || [],
                        userRoles: ((o = d == null ? void 0 : d.user) == null ? void 0 : o.roles) || []
                    }).include
                },
                userPreferences: c,
                infoRoles: f,
                announcementsResponse: C,
                client: l,
                query: Re({
                    client: l
                })
            }
        } catch (n) {
            console.error("svelte handle error", n), ue(404, "Failed to load")
        }
    },
    Ze = Object.freeze(Object.defineProperty({
        __proto__: null,
        load: Te,
        prerender: Me
    }, Symbol.toStringTag, {
        value: "Module"
    }));
class $e extends E {
    constructor(s) {
        super(), F(this, s, null, null, x, {})
    }
}

function qe(r) {
    let s, a, o;
    s = new $e({});
    const n = r[2].default,
        t = J(n, r, r[1], null);
    return {
        c() {
            ve(s.$$.fragment), a = Z(), t && t.c()
        },
        l(e) {
            xe(s.$$.fragment, e), a = ee(e), t && t.l(e)
        },
        m(e, l) {
            Ee(s, e, l), te(e, a, l), t && t.m(e, l), o = !0
        },
        p(e, [l]) {
            t && t.p && (!o || l & 2) && ne(t, n, e, e[1], o ? ae(n, e[1], l, null) : se(e[1]), null)
        },
        i(e) {
            o || (_(s.$$.fragment, e), _(t, e), o = !0)
        },
        o(e) {
            v(s.$$.fragment, e), v(t, e), o = !1
        },
        d(e) {
            e && oe(a), Fe(s, e), t && t.d(e)
        }
    }
}

function Ae(r, s, a) {
    let {
        $$slots: o = {},
        $$scope: n
    } = s, {
        data: t
    } = s;
    return X({
        locale: t.session.locale,
        catalog: t.session.catalog
    }), r.$$set = e => {
        "data" in e && a(0, t = e.data), "$$scope" in e && a(1, n = e.$$scope)
    }, [t, n, o]
}
class et extends E {
    constructor(s) {
        super(), F(this, s, Ae, qe, x, {
            data: 0
        })
    }
}
export {
    et as component, Ze as universal
};