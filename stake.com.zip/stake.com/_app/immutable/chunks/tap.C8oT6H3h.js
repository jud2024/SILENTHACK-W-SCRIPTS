import {
    o as r,
    i as d,
    a as f,
    c as s
} from "./dateTimestampProvider.DBRuHdww.js";

function _(o, u, v) {
    var a = f(o) || u || v ? {
        next: o,
        error: u,
        complete: v
    } : o;
    return a ? r(function(e, n) {
        var t;
        (t = a.subscribe) === null || t === void 0 || t.call(a);
        var c = !0;
        e.subscribe(s(n, function(i) {
            var l;
            (l = a.next) === null || l === void 0 || l.call(a, i), n.next(i)
        }, function() {
            var i;
            c = !1, (i = a.complete) === null || i === void 0 || i.call(a), n.complete()
        }, function(i) {
            var l;
            c = !1, (l = a.error) === null || l === void 0 || l.call(a, i), n.error(i)
        }, function() {
            var i, l;
            c && ((i = a.unsubscribe) === null || i === void 0 || i.call(a)), (l = a.finalize) === null || l === void 0 || l.call(a)
        }))
    }) : d
}
export {
    _ as t
};