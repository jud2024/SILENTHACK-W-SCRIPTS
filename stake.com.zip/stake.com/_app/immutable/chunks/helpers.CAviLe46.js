import {
    a as o
} from "./index.1CTKaDY2.js";
import {
    l as d
} from "./index.CY6-K88d.js";
import {
    a0 as l
} from "./index.B4-7gKq3.js";
import {
    G as r
} from "./scheduler.DXu26z7T.js";
import {
    w as i
} from "./index.C2-CG2CN.js";
const s = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "query",
            name: {
                kind: "Name",
                value: "GetFailedTransactionsCount"
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "failedDepositCount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "failedWithdrawalCount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "pendingWithdrawalCount"
                    }
                }]
            }
        }]
    },
    c = i(0),
    f = i(0),
    m = i(0),
    C = () => {
        r(d) === "fullsize" && o.set("minimized")
    };
async function b() {
    var e, t, n;
    try {
        const a = await l({
            load: {
                fetch
            },
            doc: s,
            variables: {}
        });
        if (a) c.set(((e = a == null ? void 0 : a.data) == null ? void 0 : e.failedDepositCount) || 0), f.set(((t = a == null ? void 0 : a.data) == null ? void 0 : t.failedWithdrawalCount) || 0), m.set(((n = a == null ? void 0 : a.data) == null ? void 0 : n.pendingWithdrawalCount) || 0);
        else throw "Unable to update failed transactions"
    } catch (a) {
        console.error(a)
    } finally {}
}
export {
    C as c, b as o
};