import {
    s as Y,
    K as g,
    L as D,
    c as m,
    M as v,
    T as j,
    a as L,
    u as P,
    g as V,
    b as Z
} from "./scheduler.DXu26z7T.js";
import {
    S as x,
    i as w,
    c as z,
    a as B,
    m as G,
    t as f,
    b as _,
    d as H
} from "./index.Dz_MmNB3.js";
import {
    g as $,
    a as ee
} from "./spread.CgU5AtxT.js";
import {
    A as ne
} from "./index.BYgQ-xSW.js";
import {
    g as te
} from "./index.BFHGe0pG.js";
import {
    i as oe
} from "./index.B4-7gKq3.js";
import {
    C as re
} from "./index.Na6KaqFL.js";
const se = o => ({}),
    p = o => ({}),
    ae = o => ({}),
    K = o => ({});

function ue(o) {
    let e;
    const a = o[20].label,
        n = L(a, o, o[24], p);
    return {
        c() {
            n && n.c()
        },
        l(r) {
            n && n.l(r)
        },
        m(r, t) {
            n && n.m(r, t), e = !0
        },
        p(r, t) {
            n && n.p && (!e || t & 16777216) && P(n, a, r, r[24], e ? Z(a, r[24], t, se) : V(r[24]), p)
        },
        i(r) {
            e || (f(n, r), e = !0)
        },
        o(r) {
            _(n, r), e = !1
        },
        d(r) {
            n && n.d(r)
        }
    }
}

function ie(o) {
    let e;
    const a = o[20].buttons,
        n = L(a, o, o[24], K);
    return {
        c() {
            n && n.c()
        },
        l(r) {
            n && n.l(r)
        },
        m(r, t) {
            n && n.m(r, t), e = !0
        },
        p(r, t) {
            n && n.p && (!e || t & 16777216) && P(n, a, r, r[24], e ? Z(a, r[24], t, ae) : V(r[24]), K)
        },
        i(r) {
            e || (f(n, r), e = !0)
        },
        o(r) {
            _(n, r), e = !1
        },
        d(r) {
            n && n.d(r)
        }
    }
}

function le(o) {
    let e, a;
    return e = new re({
        props: {
            currency: o[5]
        }
    }), {
        c() {
            z(e.$$.fragment)
        },
        l(n) {
            B(e.$$.fragment, n)
        },
        m(n, r) {
            G(e, n, r), a = !0
        },
        p(n, r) {
            const t = {};
            r & 32 && (t.currency = n[5]), e.$set(t)
        },
        i(n) {
            a || (f(e.$$.fragment, n), a = !0)
        },
        o(n) {
            _(e.$$.fragment, n), a = !1
        },
        d(n) {
            H(e, n)
        }
    }
}

function me(o) {
    let e, a;
    const n = [{
        roundingType: o[6]
    }, {
        amount: o[18]
    }, {
        tooltipError: !1
    }, {
        required: o[1]
    }, {
        errorMessage: o[8] && o[9]._(o[8])
    }, {
        "data-testid": "send-rain-amount"
    }, {
        maxEnabled: o[4]
    }, {
        currency: o[5]
    }, {
        max: o[3]
    }, {
        disabled: o[11] || o[2] || o[12]
    }, {
        name: o[0]
    }, {
        conversionMaxWidth: o[7]
    }, o[19]];
    let r = {
        $$slots: {
            iconAfter: [le],
            buttons: [ie],
            label: [ue]
        },
        $$scope: {
            ctx: o
        }
    };
    for (let t = 0; t < n.length; t += 1) r = g(r, n[t]);
    return e = new ne({
        props: r
    }), e.$on("blur", o[21]), e.$on("focus", o[22]), e.$on("max", o[23]), {
        c() {
            z(e.$$.fragment)
        },
        l(t) {
            B(e.$$.fragment, t)
        },
        m(t, u) {
            G(e, t, u), a = !0
        },
        p(t, [u]) {
            const i = u & 793599 ? $(n, [u & 64 && {
                roundingType: t[6]
            }, u & 262144 && {
                amount: t[18]
            }, n[2], u & 2 && {
                required: t[1]
            }, u & 768 && {
                errorMessage: t[8] && t[9]._(t[8])
            }, n[5], u & 16 && {
                maxEnabled: t[4]
            }, u & 32 && {
                currency: t[5]
            }, u & 8 && {
                max: t[3]
            }, u & 6148 && {
                disabled: t[11] || t[2] || t[12]
            }, u & 1 && {
                name: t[0]
            }, u & 128 && {
                conversionMaxWidth: t[7]
            }, u & 524288 && ee(t[19])]) : {};
            u & 16777248 && (i.$$scope = {
                dirty: u,
                ctx: t
            }), e.$set(i)
        },
        i(t) {
            a || (f(e.$$.fragment, t), a = !0)
        },
        o(t) {
            _(e.$$.fragment, t), a = !1
        },
        d(t) {
            H(e, t)
        }
    }
}

function ce(o, e, a) {
    const n = ["name", "required", "disabled", "max", "maxEnabled", "currency", "roundingType", "conversionMaxWidth"];
    let r = D(e, n),
        t, u, i, h, M;
    m(o, oe, s => a(9, u = s));
    let {
        $$slots: J = {},
        $$scope: y
    } = e, {
        name: d
    } = e, {
        required: T = !1
    } = e, {
        disabled: q = !1
    } = e, {
        max: b = 1 / 0
    } = e, {
        maxEnabled: E = !1
    } = e, {
        currency: W
    } = e, {
        roundingType: A = "round"
    } = e, {
        conversionMaxWidth: S = void 0
    } = e;
    const C = te(),
        {
            isSubmitting: F,
            disabled: I
        } = C;
    m(o, F, s => a(11, h = s)), m(o, I, s => a(12, M = s));
    let N = C.fields[d];
    const {
        error: k,
        value: l,
        focus: c
    } = N;
    m(o, k, s => a(8, t = s)), m(o, c, s => a(10, i = s));
    const O = s => s === "" ? (l.set("0"), "0") : (l.set(s), s),
        Q = { ...l,
            set: s => {
                O(s)
            }
        },
        R = () => {
            j(c, i = !1, i)
        },
        U = () => {
            j(c, i = !0, i)
        },
        X = () => l.set(String(b));
    return o.$$set = s => {
        e = g(g({}, e), v(s)), a(19, r = D(e, n)), "name" in s && a(0, d = s.name), "required" in s && a(1, T = s.required), "disabled" in s && a(2, q = s.disabled), "max" in s && a(3, b = s.max), "maxEnabled" in s && a(4, E = s.maxEnabled), "currency" in s && a(5, W = s.currency), "roundingType" in s && a(6, A = s.roundingType), "conversionMaxWidth" in s && a(7, S = s.conversionMaxWidth), "$$scope" in s && a(24, y = s.$$scope)
    }, [d, T, q, b, E, W, A, S, t, u, i, h, M, F, I, k, l, c, Q, r, J, R, U, X, y]
}
class ye extends x {
    constructor(e) {
        super(), w(this, e, ce, me, Y, {
            name: 0,
            required: 1,
            disabled: 2,
            max: 3,
            maxEnabled: 4,
            currency: 5,
            roundingType: 6,
            conversionMaxWidth: 7
        })
    }
}
export {
    ye as A
};