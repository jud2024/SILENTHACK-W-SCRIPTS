import {
    s as u,
    C as f,
    H as h,
    D as v,
    f as m,
    E as V,
    i as c,
    F as r,
    j as _,
    n as o
} from "./scheduler.DXu26z7T.js";
import {
    S as d,
    i as g
} from "./index.Dz_MmNB3.js";

function Z(n) {
    let e, s, a = ` <title>${n[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M33.013 19.707 64 0v12.64L30.987 33.627 18.133 18.853 0 30.693V17.947L20.107 4.853l12.906 14.854ZM16 64H5.333V35.173L16 28.213V64Zm13.707-21.653-3.04-3.52V64h10.666V37.493l-2.773 1.76-4.853 3.094ZM58.667 64H48V30.72l10.667-6.8V64Z"></path>`,
        i;
    return {
        c() {
            e = f("svg"), s = new h(!0), this.h()
        },
        l(t) {
            e = v(t, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var l = m(e);
            s = V(l, !0), l.forEach(c), this.h()
        },
        h() {
            s.a = null, r(e, "fill", "currentColor"), r(e, "viewBox", "0 0 64 64"), r(e, "class", i = "svg-icon " + n[2]), r(e, "style", n[0])
        },
        m(t, l) {
            _(t, e, l), s.m(a, e)
        },
        p(t, [l]) {
            l & 2 && a !== (a = ` <title>${t[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M33.013 19.707 64 0v12.64L30.987 33.627 18.133 18.853 0 30.693V17.947L20.107 4.853l12.906 14.854ZM16 64H5.333V35.173L16 28.213V64Zm13.707-21.653-3.04-3.52V64h10.666V37.493l-2.773 1.76-4.853 3.094ZM58.667 64H48V30.72l10.667-6.8V64Z"></path>`) && s.p(a), l & 4 && i !== (i = "svg-icon " + t[2]) && r(e, "class", i), l & 1 && r(e, "style", t[0])
        },
        i: o,
        o,
        d(t) {
            t && c(e)
        }
    }
}

function y(n, e, s) {
    let {
        style: a = ""
    } = e, {
        alt: i = ""
    } = e, {
        class: t = ""
    } = e;
    return n.$$set = l => {
        "style" in l && s(0, a = l.style), "alt" in l && s(1, i = l.alt), "class" in l && s(2, t = l.class)
    }, [a, i, t]
}
class M extends d {
    constructor(e) {
        super(), g(this, e, y, Z, u, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    M as G
};