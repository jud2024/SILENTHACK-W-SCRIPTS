/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
var v = function() {
    return v = Object.assign || function(t) {
        for (var e, n = 1, a = arguments.length; n < a; n++) {
            e = arguments[n];
            for (var u in e) Object.prototype.hasOwnProperty.call(e, u) && (t[u] = e[u])
        }
        return t
    }, v.apply(this, arguments)
};

function z(r, t) {
    var e = {};
    for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && t.indexOf(n) < 0 && (e[n] = r[n]);
    if (r != null && typeof Object.getOwnPropertySymbols == "function")
        for (var a = 0, n = Object.getOwnPropertySymbols(r); a < n.length; a++) t.indexOf(n[a]) < 0 && Object.prototype.propertyIsEnumerable.call(r, n[a]) && (e[n[a]] = r[n[a]]);
    return e
}

function d(r) {
    var t = typeof Symbol == "function" && Symbol.iterator,
        e = t && r[t],
        n = 0;
    if (e) return e.call(r);
    if (r && typeof r.length == "number") return {
        next: function() {
            return r && n >= r.length && (r = void 0), {
                value: r && r[n++],
                done: !r
            }
        }
    };
    throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
}

function j(r, t) {
    var e = typeof Symbol == "function" && r[Symbol.iterator];
    if (!e) return r;
    var n = e.call(r),
        a, u = [],
        f;
    try {
        for (;
            (t === void 0 || t-- > 0) && !(a = n.next()).done;) u.push(a.value)
    } catch (o) {
        f = {
            error: o
        }
    } finally {
        try {
            a && !a.done && (e = n.return) && e.call(n)
        } finally {
            if (f) throw f.error
        }
    }
    return u
}

function G() {
    for (var r = [], t = 0; t < arguments.length; t++) r = r.concat(j(arguments[t]));
    return r
}
var P = ".",
    B = {},
    m = "xstate.guard",
    $ = "";

function b(r) {
    return Object.keys(r)
}

function F(r, t, e) {
    e === void 0 && (e = P);
    var n = O(r, e),
        a = O(t, e);
    return l(a) ? l(n) ? a === n : !1 : l(n) ? n in a : b(n).every(function(u) {
        return u in a ? F(n[u], a[u]) : !1
    })
}

function q(r) {
    try {
        return l(r) || typeof r == "number" ? "" + r : r.type
    } catch {
        throw new Error("Events must be strings or objects with a string event.type property.")
    }
}

function I(r, t) {
    try {
        return w(r) ? r : r.toString().split(t)
    } catch {
        throw new Error("'" + r + "' is not a valid state path.")
    }
}

function D(r) {
    return typeof r == "object" && "value" in r && "context" in r && "event" in r && "_event" in r
}

function O(r, t) {
    if (D(r)) return r.value;
    if (w(r)) return E(r);
    if (typeof r != "string") return r;
    var e = I(r, t);
    return E(e)
}

function E(r) {
    if (r.length === 1) return r[0];
    for (var t = {}, e = t, n = 0; n < r.length - 1; n++) n === r.length - 2 ? e[r[n]] = r[n + 1] : (e[r[n]] = {}, e = e[r[n]]);
    return t
}

function M(r, t) {
    for (var e = {}, n = b(r), a = 0; a < n.length; a++) {
        var u = n[a];
        e[u] = t(r[u], u, r, a)
    }
    return e
}

function J(r, t, e) {
    var n, a, u = {};
    try {
        for (var f = d(b(r)), o = f.next(); !o.done; o = f.next()) {
            var i = o.value,
                c = r[i];
            e(c) && (u[i] = t(c, i, r))
        }
    } catch (y) {
        n = {
            error: y
        }
    } finally {
        try {
            o && !o.done && (a = f.return) && a.call(f)
        } finally {
            if (n) throw n.error
        }
    }
    return u
}
var X = function(r) {
    return function(t) {
        var e, n, a = t;
        try {
            for (var u = d(r), f = u.next(); !f.done; f = u.next()) {
                var o = f.value;
                a = a[o]
            }
        } catch (i) {
            e = {
                error: i
            }
        } finally {
            try {
                f && !f.done && (n = u.return) && n.call(u)
            } finally {
                if (e) throw e.error
            }
        }
        return a
    }
};

function N(r, t) {
    return function(e) {
        var n, a, u = e;
        try {
            for (var f = d(r), o = f.next(); !o.done; o = f.next()) {
                var i = o.value;
                u = u[t][i]
            }
        } catch (c) {
            n = {
                error: c
            }
        } finally {
            try {
                o && !o.done && (a = f.return) && a.call(f)
            } finally {
                if (n) throw n.error
            }
        }
        return u
    }
}

function Y(r) {
    if (!r) return [
        []
    ];
    if (l(r)) return [
        [r]
    ];
    var t = K(b(r).map(function(e) {
        var n = r[e];
        return typeof n != "string" && (!n || !Object.keys(n).length) ? [
            [e]
        ] : Y(r[e]).map(function(a) {
            return [e].concat(a)
        })
    }));
    return t
}

function K(r) {
    var t;
    return (t = []).concat.apply(t, G(r))
}

function T(r) {
    return w(r) ? r : [r]
}

function L(r) {
    return r === void 0 ? [] : T(r)
}

function Q(r, t, e) {
    var n, a;
    if (s(r)) return r(t, e.data);
    var u = {};
    try {
        for (var f = d(Object.keys(r)), o = f.next(); !o.done; o = f.next()) {
            var i = o.value,
                c = r[i];
            s(c) ? u[i] = c(t, e.data) : u[i] = c
        }
    } catch (y) {
        n = {
            error: y
        }
    } finally {
        try {
            o && !o.done && (a = f.return) && a.call(f)
        } finally {
            if (n) throw n.error
        }
    }
    return u
}

function W(r) {
    return /^(done|error)\./.test(r)
}

function Z(r) {
    return !!(r instanceof Promise || r !== null && (s(r) || typeof r == "object") && s(r.then))
}

function H(r, t) {
    var e, n, a = j([
            [],
            []
        ], 2),
        u = a[0],
        f = a[1];
    try {
        for (var o = d(r), i = o.next(); !i.done; i = o.next()) {
            var c = i.value;
            t(c) ? u.push(c) : f.push(c)
        }
    } catch (y) {
        e = {
            error: y
        }
    } finally {
        try {
            i && !i.done && (n = o.return) && n.call(o)
        } finally {
            if (e) throw e.error
        }
    }
    return [u, f]
}

function A(r, t) {
    return M(r.states, function(e, n) {
        if (e) {
            var a = (l(t) ? void 0 : t[n]) || (e ? e.current : void 0);
            if (a) return {
                current: a,
                states: A(e, a)
            }
        }
    })
}

function V(r, t) {
    return {
        current: t,
        states: A(r, t)
    }
}

function k(r, t, e, n) {
    var a = r && e.reduce(function(u, f) {
        var o, i, c = f.assignment,
            y = {
                state: n,
                action: f,
                _event: t
            },
            g = {};
        if (s(c)) g = c(u, t.data, y);
        else try {
            for (var p = d(b(c)), h = p.next(); !h.done; h = p.next()) {
                var x = h.value,
                    S = c[x];
                g[x] = s(S) ? S(u, t.data, y) : S
            }
        } catch (C) {
            o = {
                error: C
            }
        } finally {
            try {
                h && !h.done && (i = p.return) && i.call(p)
            } finally {
                if (o) throw o.error
            }
        }
        return Object.assign({}, u, g)
    }, r);
    return a
}

function w(r) {
    return Array.isArray(r)
}

function s(r) {
    return typeof r == "function"
}

function l(r) {
    return typeof r == "string"
}

function _(r, t) {
    if (r) return l(r) ? {
        type: m,
        name: r,
        predicate: t ? t[r] : void 0
    } : s(r) ? {
        type: m,
        name: r.name,
        predicate: r
    } : r
}

function rr(r) {
    try {
        return "subscribe" in r && s(r.subscribe)
    } catch {
        return !1
    }
}
var nr = function() {
    return typeof Symbol == "function" && Symbol.observable || "@@observable"
}();

function R(r) {
    try {
        return "__xstatenode" in r
    } catch {
        return !1
    }
}

function tr(r) {
    return !!r && typeof r.send == "function"
}

function U(r, t) {
    return l(r) || typeof r == "number" ? v({
        type: r
    }, t) : r
}

function er(r, t) {
    if (!l(r) && "$$type" in r && r.$$type === "scxml") return r;
    var e = U(r);
    return v({
        name: e.type,
        data: e,
        $$type: "scxml",
        type: "external"
    }, t)
}

function ar(r, t) {
    var e = T(t).map(function(n) {
        return typeof n > "u" || typeof n == "string" || R(n) ? {
            target: n,
            event: r
        } : v(v({}, n), {
            event: r
        })
    });
    return e
}

function ur(r) {
    if (!(r === void 0 || r === $)) return L(r)
}

function fr(r, t, e, n, a) {
    var u = r.options.guards,
        f = {
            state: a,
            cond: t,
            _event: n
        };
    if (t.type === m) return t.predicate(e, n.data, f);
    var o = u[t.type];
    if (!o) throw new Error("Guard '" + t.type + "' is not implemented on machine '" + r.id + "'.");
    return o(e, n.data, f)
}

function or(r) {
    return typeof r == "string" ? {
        type: r
    } : r
}

function ir(r, t, e) {
    if (typeof r == "object") return r;
    var n = function() {};
    return {
        next: r,
        error: t || n,
        complete: e || n
    }
}
export {
    I as A, M as B, J as C, Y as D, B as E, N as F, ur as G, ar as H, Z as I, rr as J, nr as K, tr as L, ir as M, P as S, v as _, er as a, l as b, j as c, L as d, _ as e, K as f, q as g, fr as h, s as i, w as j, b as k, d as l, F as m, G as n, z as o, H as p, or as q, Q as r, R as s, U as t, k as u, O as v, X as w, E as x, W as y, V as z
};