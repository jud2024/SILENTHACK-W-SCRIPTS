import {
    _ as i
} from "./index.B4-7gKq3.js";
import {
    s as t
} from "./interpreter.CJhK2JTN.js";

function E(e) {
    const a = {
        initial: "idle",
        states: {
            idle: {
                on: {
                    FETCH_STATE: "fetching",
                    SKIP_REQUEST_STATE: "#betTab"
                }
            },
            fetching: {
                id: "getState.fetching",
                invoke: {
                    id: "requestState",
                    src: "requestState",
                    onDone: {
                        actions: t((T, n) => ({
                            type: "HAS_STATE",
                            bet: n.data
                        }))
                    },
                    onError: {
                        actions: t("TO_BET")
                    }
                },
                on: {
                    HAS_STATE: {
                        target: "#betTab.play"
                    },
                    TO_BET: {
                        target: "#betTab"
                    },
                    TO_AUTOBET: {
                        target: "#autobetTab"
                    }
                }
            }
        }
    };
    return i.merge(a, e)
}

function d(e) {
    const a = {
        initial: "idle",
        id: "betTab",
        states: {
            idle: {
                id: "betTab.idle",
                on: {
                    BET: {
                        target: "fetching"
                    },
                    TO_AUTOBET: {
                        target: "#autobetTab"
                    },
                    TO_ADVANCED: {
                        target: "#advancedTab"
                    },
                    REFETCH_STATE: {
                        target: "#getState.fetching"
                    }
                }
            },
            fetching: {
                invoke: {
                    id: "mutationBet",
                    src: "mutationBet",
                    onDone: {
                        actions: t((T, n) => ({
                            type: "SUCCESS",
                            bet: n.data
                        }))
                    },
                    onError: {
                        actions: t("ERROR")
                    }
                },
                on: {
                    SUCCESS: {
                        target: "play",
                        actions: ["addBetToContext"]
                    },
                    ERROR: {
                        target: "idle"
                    }
                }
            }
        }
    };
    return i.merge(a, e)
}
export {
    d as a, E as e
};