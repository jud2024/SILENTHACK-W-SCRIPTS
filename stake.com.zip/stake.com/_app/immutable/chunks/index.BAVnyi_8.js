import {
    G as P,
    s as G,
    e as N,
    O as H,
    d as V,
    f as O,
    P as L,
    i as d,
    F as E,
    j as w,
    k as A,
    c as h,
    m as C,
    J as U,
    n as p,
    t as q,
    h as z,
    l as J
} from "./scheduler.DXu26z7T.js";
import {
    S as K,
    i as Q,
    c as k,
    a as y,
    m as W,
    t as f,
    g as D,
    b as m,
    e as F,
    d as v
} from "./index.Dz_MmNB3.js";
import "./index.ByMdEFI5.js";
import {
    h as X,
    H as b,
    G as I,
    i as Y,
    F as M
} from "./index.B4-7gKq3.js";
import {
    C as Z
} from "./index.COpyS6pA.js";
import "./index.B3dW9TVs.js";
import {
    i as x
} from "./index.BxooaYHE.js";
import {
    S as $
} from "./constants.CW0Xv01T.js";
import {
    s as ee
} from "./stores.C2Y_-UWr.js";
import {
    m as te
} from "./utils.92_vUFxq.js";
import {
    V as ae
} from "./index.ej-0ZG0S.js";
import {
    B as ne
} from "./button.BwmFDw8u.js";
import {
    W as re
} from "./Wallet.B4hgSvlS.js";
const B = {
        wallet: X._("Wallet")
    },
    se = () => {
        P(ee), te.wallet.open({
            tab: "overview",
            currency: P(b),
            ...ae === "sweeps"
        })
    };

function S(s) {
    let e, t;
    return e = new ne({
        props: {
            style: "border-radius: 0 var(--radius-base) var(--radius-base) 0",
            variant: "action",
            size: "sm",
            "data-testid": "wallet",
            "data-test": "wallet",
            "data-analytics": "global-navbar-wallet-button",
            "data-content": $,
            $$slots: {
                default: [ie]
            },
            $$scope: {
                ctx: s
            }
        }
    }), e.$on("click", se), {
        c() {
            k(e.$$.fragment)
        },
        l(a) {
            y(e.$$.fragment, a)
        },
        m(a, l) {
            W(e, a, l), t = !0
        },
        p(a, l) {
            const n = {};
            l & 4609 && (n.$$scope = {
                dirty: l,
                ctx: a
            }), e.$set(n)
        },
        i(a) {
            t || (f(e.$$.fragment, a), t = !0)
        },
        o(a) {
            m(e.$$.fragment, a), t = !1
        },
        d(a) {
            v(e, a)
        }
    }
}

function le(s) {
    let e, t;
    return e = new re({}), {
        c() {
            k(e.$$.fragment)
        },
        l(a) {
            y(e.$$.fragment, a)
        },
        m(a, l) {
            W(e, a, l), t = !0
        },
        p,
        i(a) {
            t || (f(e.$$.fragment, a), t = !0)
        },
        o(a) {
            m(e.$$.fragment, a), t = !1
        },
        d(a) {
            v(e, a)
        }
    }
}

function oe(s) {
    let e, t = s[9]._(B.wallet) + "",
        a;
    return {
        c() {
            e = N("span"), a = q(t)
        },
        l(l) {
            e = V(l, "SPAN", {});
            var n = O(e);
            a = z(n, t), n.forEach(d)
        },
        m(l, n) {
            w(l, e, n), A(e, a)
        },
        p(l, n) {
            n & 512 && t !== (t = l[9]._(B.wallet) + "") && J(a, t)
        },
        i: p,
        o: p,
        d(l) {
            l && d(e)
        }
    }
}

function ie(s) {
    let e, t, a, l;
    const n = [oe, le],
        r = [];

    function c(o, u) {
        return o[0] ? 0 : 1
    }
    return e = c(s), t = r[e] = n[e](s), {
        c() {
            t.c(), a = C()
        },
        l(o) {
            t.l(o), a = C()
        },
        m(o, u) {
            r[e].m(o, u), w(o, a, u), l = !0
        },
        p(o, u) {
            let _ = e;
            e = c(o), e === _ ? r[e].p(o, u) : (D(), m(r[_], 1, 1, () => {
                r[_] = null
            }), F(), t = r[e], t ? t.p(o, u) : (t = r[e] = n[e](o), t.c()), f(t, 1), t.m(a.parentNode, a))
        },
        i(o) {
            l || (f(t), l = !0)
        },
        o(o) {
            m(t), l = !1
        },
        d(o) {
            o && d(a), r[e].d(o)
        }
    }
}

function ce(s) {
    let e, t, a, l;
    t = new Z({
        props: {
            parentNode: s[5],
            header: s[2],
            currencies: s[3],
            truncateMaxWidth: s[4],
            currency: s[6],
            view: s[7] ? "inPlay" : "default"
        }
    }), t.$on("changeCurrency", s[10]);
    let n = (s[1] || s[0]) && S(s);
    return {
        c() {
            e = N("div"), k(t.$$.fragment), a = H(), n && n.c(), this.h()
        },
        l(r) {
            e = V(r, "DIV", {
                class: !0,
                "data-test": !0
            });
            var c = O(e);
            y(t.$$.fragment, c), a = L(c), n && n.l(c), c.forEach(d), this.h()
        },
        h() {
            E(e, "class", "balance-toggle svelte-51jofe"), E(e, "data-test", "balance-toggle")
        },
        m(r, c) {
            w(r, e, c), W(t, e, null), A(e, a), n && n.m(e, null), s[11](e), l = !0
        },
        p(r, [c]) {
            const o = {};
            c & 32 && (o.parentNode = r[5]), c & 4 && (o.header = r[2]), c & 8 && (o.currencies = r[3]), c & 16 && (o.truncateMaxWidth = r[4]), c & 64 && (o.currency = r[6]), c & 128 && (o.view = r[7] ? "inPlay" : "default"), t.$set(o), r[1] || r[0] ? n ? (n.p(r, c), c & 3 && f(n, 1)) : (n = S(r), n.c(), f(n, 1), n.m(e, null)) : n && (D(), m(n, 1, 1, () => {
                n = null
            }), F())
        },
        i(r) {
            l || (f(t.$$.fragment, r), f(n), l = !0)
        },
        o(r) {
            m(t.$$.fragment, r), m(n), l = !1
        },
        d(r) {
            r && d(e), v(t), n && n.d(), s[11](null)
        }
    }
}

function ue(s, e, t) {
    let a, l, n, r;
    h(s, b, i => t(6, a = i)), h(s, x, i => t(7, l = i)), h(s, I, i => t(8, n = i)), h(s, Y, i => t(9, r = i));
    let {
        showText: c = !0
    } = e, {
        showWallet: o = !0
    } = e, {
        header: u = !0
    } = e, {
        currencies: _ = void 0
    } = e, {
        truncateMaxWidth: T = "12ch"
    } = e, g;
    const R = ({
        detail: i
    }) => {
        b.set(i), i in M && n !== "crypto" && I.set(M[i])
    };

    function j(i) {
        U[i ? "unshift" : "push"](() => {
            g = i, t(5, g)
        })
    }
    return s.$$set = i => {
        "showText" in i && t(0, c = i.showText), "showWallet" in i && t(1, o = i.showWallet), "header" in i && t(2, u = i.header), "currencies" in i && t(3, _ = i.currencies), "truncateMaxWidth" in i && t(4, T = i.truncateMaxWidth)
    }, [c, o, u, _, T, g, a, l, n, r, R, j]
}
class Te extends K {
    constructor(e) {
        super(), Q(this, e, ue, ce, G, {
            showText: 0,
            showWallet: 1,
            header: 2,
            currencies: 3,
            truncateMaxWidth: 4
        })
    }
}
export {
    Te as B, se as o
};