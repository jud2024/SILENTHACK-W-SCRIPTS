import {
    _ as o
} from "./preload-helper.BqjOJQfC.js";
import {
    _ as w
} from "./dynamic-import-helper.BheWnx7M.js";
import {
    j as h
} from "./jsonScript.84xs9Vds.js";
import {
    D as $
} from "./index.B81orGJm.js";
import {
    g as S,
    a as f
} from "./pageSeo.DmcsyA6w.js";
import {
    ag as N,
    D as B
} from "./index.B4-7gKq3.js";
class k extends Error {
    constructor(r, p) {
        super(r), this.name = "DevalueError", this.path = p.join("")
    }
}

function A(s) {
    return Object(s) !== s
}
const z = Object.getOwnPropertyNames(Object.prototype).sort().join("\0");

function C(s) {
    const r = Object.getPrototypeOf(s);
    return r === Object.prototype || r === null || Object.getOwnPropertyNames(r).sort().join("\0") === z
}

function M(s) {
    return Object.prototype.toString.call(s).slice(8, -1)
}

function J(s) {
    switch (s) {
        case '"':
            return '\\"';
        case "<":
            return "\\u003C";
        case "\\":
            return "\\\\";
        case `
`:
            return "\\n";
        case "\r":
            return "\\r";
        case "	":
            return "\\t";
        case "\b":
            return "\\b";
        case "\f":
            return "\\f";
        case "\u2028":
            return "\\u2028";
        case "\u2029":
            return "\\u2029";
        default:
            return s < " " ? `\\u${s.charCodeAt(0).toString(16).padStart(4,"0")}` : ""
    }
}

function l(s) {
    let r = "",
        p = 0;
    const _ = s.length;
    for (let i = 0; i < _; i += 1) {
        const a = s[i],
            m = J(a);
        m && (r += s.slice(p, i) + m, p = i + 1)
    }
    return `"${p===0?s:r+s.slice(p)}"`
}
const j = -1,
    L = -2,
    T = -3,
    R = -4,
    V = -5,
    O = -6;

function F(s, r) {
    return q(JSON.parse(s))
}

function q(s, r) {
    if (typeof s == "number") return i(s, !0);
    if (!Array.isArray(s) || s.length === 0) throw new Error("Invalid input");
    const p = s,
        _ = Array(p.length);

    function i(a, m = !1) {
        if (a === j) return;
        if (a === T) return NaN;
        if (a === R) return 1 / 0;
        if (a === V) return -1 / 0;
        if (a === O) return -0;
        if (m) throw new Error("Invalid input");
        if (a in _) return _[a];
        const e = p[a];
        if (!e || typeof e != "object") _[a] = e;
        else if (Array.isArray(e))
            if (typeof e[0] == "string") {
                const d = e[0];
                switch (d) {
                    case "Date":
                        _[a] = new Date(e[1]);
                        break;
                    case "Set":
                        const t = new Set;
                        _[a] = t;
                        for (let u = 1; u < e.length; u += 1) t.add(i(e[u]));
                        break;
                    case "Map":
                        const E = new Map;
                        _[a] = E;
                        for (let u = 1; u < e.length; u += 2) E.set(i(e[u]), i(e[u + 1]));
                        break;
                    case "RegExp":
                        _[a] = new RegExp(e[1], e[2]);
                        break;
                    case "Object":
                        _[a] = Object(e[1]);
                        break;
                    case "BigInt":
                        _[a] = BigInt(e[1]);
                        break;
                    case "null":
                        const n = Object.create(null);
                        _[a] = n;
                        for (let u = 1; u < e.length; u += 2) n[e[u]] = i(e[u + 1]);
                        break;
                    default:
                        throw new Error(`Unknown type ${d}`)
                }
            } else {
                const d = new Array(e.length);
                _[a] = d;
                for (let t = 0; t < e.length; t += 1) {
                    const E = e[t];
                    E !== L && (d[t] = i(E))
                }
            }
        else {
            const d = {};
            _[a] = d;
            for (const t in e) {
                const E = e[t];
                d[t] = i(E)
            }
        }
        return _[a]
    }
    return i(0)
}

function G(s, r) {
    const p = [],
        _ = new Map,
        i = [];
    for (const t in r) i.push({
        key: t,
        fn: r[t]
    });
    const a = [];
    let m = 0;

    function e(t) {
        if (typeof t == "function") throw new k("Cannot stringify a function", a);
        if (_.has(t)) return _.get(t);
        if (t === void 0) return j;
        if (Number.isNaN(t)) return T;
        if (t === 1 / 0) return R;
        if (t === -1 / 0) return V;
        if (t === 0 && 1 / t < 0) return O;
        const E = m++;
        _.set(t, E);
        for (const {
                key: u,
                fn: I
            } of i) {
            const b = I(t);
            if (b) return p[E] = `["${u}",${e(b)}]`, E
        }
        let n = "";
        if (A(t)) n = v(t);
        else switch (M(t)) {
            case "Number":
            case "String":
            case "Boolean":
                n = `["Object",${v(t)}]`;
                break;
            case "BigInt":
                n = `["BigInt",${t}]`;
                break;
            case "Date":
                n = `["Date","${!isNaN(t.getDate())?t.toISOString():""}"]`;
                break;
            case "RegExp":
                const {
                    source: b,
                    flags: g
                } = t;
                n = g ? `["RegExp",${l(b)},"${g}"]` : `["RegExp",${l(b)}]`;
                break;
            case "Array":
                n = "[";
                for (let c = 0; c < t.length; c += 1) c > 0 && (n += ","), c in t ? (a.push(`[${c}]`), n += e(t[c]), a.pop()) : n += L;
                n += "]";
                break;
            case "Set":
                n = '["Set"';
                for (const c of t) n += `,${e(c)}`;
                n += "]";
                break;
            case "Map":
                n = '["Map"';
                for (const [c, y] of t) a.push(`.get(${A(c)?v(c):"..."})`), n += `,${e(c)},${e(y)}`, a.pop();
                n += "]";
                break;
            default:
                if (!C(t)) throw new k("Cannot stringify arbitrary non-POJOs", a);
                if (Object.getOwnPropertySymbols(t).length > 0) throw new k("Cannot stringify POJOs with symbolic keys", a);
                if (Object.getPrototypeOf(t) === null) {
                    n = '["null"';
                    for (const c in t) a.push(`.${c}`), n += `,${l(c)},${e(t[c])}`, a.pop();
                    n += "]"
                } else {
                    n = "{";
                    let c = !1;
                    for (const y in t) c && (n += ","), c = !0, a.push(`.${y}`), n += `${l(y)}:${e(t[y])}`, a.pop();
                    n += "}"
                }
        }
        return p[E] = n, E
    }
    const d = e(s);
    return d < 0 ? `${d}` : `[${p.join(",")}]`
}

function v(s) {
    const r = typeof s;
    return r === "string" ? l(s) : s instanceof String ? l(s.toString()) : s === void 0 ? j.toString() : s === 0 && 1 / s < 0 ? O.toString() : r === "bigint" ? `["BigInt","${s}"]` : String(s)
}
const H = ["/root-home-page", "/casino/games/baccarat", "/casino/games/blackjack", "/casino/games/mines", "/casino/games/crash", "/casino/games/dice", "/casino/games/roulette", "/casino/games/diamonds", "/casino/games/hilo", "/casino/games/plinko", "/casino/games/evolution-monopoly-live", "/casino/games/pragmatic-play-sweet-bonanza", "/casino/games/pragmatic-play-gates-of-olympus", "/casino/games/relax-money-train3", "/casino/group/slots", "/casino/group/roulette", "/casino/group/blackjack", "/casino/group/baccarat", "/casino/group/live-casino", "/casino/group/stake-originals", "/casino/group/game-shows", "/casino/group/table-games", "/sports/home", "/sports/live", "/sports/soccer", "/sports/basketball", "/sports/basketball/usa/nba", "/sports/cricket", "/sports/tennis", "/sports/ice-hockey", "/sports/ice-hockey/usa/nhl", "/sports/mma", "/sports/mma/ufc", "/sports/american-football", "/sports/american-football/usa/nfl", "/sports/home/live", "/sports/league-of-legends", "/sports/boxing", "/sports/golf", "/sports/dota-2", "/sports/baseball", "/sports/electronic-leagues", "/sports/counter-strike", "/sports/darts", "/sports/volleyball", "/sports/snooker", "/sports/politics-entertainment", "/sports/aussie-rules", "/sports/table-tennis", "/sports/rugby", "/sports/handball", "/sports/fifa", "/sports/badminton", "/sports/call-of-duty", "/sports/floorball", "/sports/basketball-3x3", "/sports/gaelic-football", "/sports/biathlon", "/sports/arena-of-valor", "/sports/kabaddi", "/sports/field-hockey", "/sports/motorcycle-racing", "/sports/bowls", "/sports/squash", "/sports/bandy", "/sports/waterpolo", "/sports/rocket-league", "/sports/gaelic-hurling", "/sports/judo", "/sports/cross-country", "/sports/futsal", "/sports/cycling", "/sports/beach-soccer", "/sports/curling", "/sports/stock-car-racing", "/casino/games/limbo", "/casino/games/dragon-tower", "/casino/games/keno", "/casino/games/wheel", "/casino/games/tome-of-life", "/casino/games/slide", "/casino/games/slots", "/casino/games/slots-samurai", "/casino/games/video-poker"],
    U = async s => {
        const r = s.replace(/\//g, "-");
        try {
            return await w(Object.assign({
                "../sanity/backup-data/seo/-casino-games-baccarat/production.json": () => o(() =>
                    import ("./production.BhslyT_9.js"), []),
                "../sanity/backup-data/seo/-casino-games-baccarat/sweeps.json": () => o(() =>
                    import ("./sweeps.Ca7VN5a1.js"), []),
                "../sanity/backup-data/seo/-casino-games-blackjack/production.json": () => o(() =>
                    import ("./production.B2rDUj80.js"), []),
                "../sanity/backup-data/seo/-casino-games-blackjack/sweeps.json": () => o(() =>
                    import ("./sweeps.DC8EDxLh.js"), []),
                "../sanity/backup-data/seo/-casino-games-crash/production.json": () => o(() =>
                    import ("./production.ClP-xarX.js"), []),
                "../sanity/backup-data/seo/-casino-games-crash/sweeps.json": () => o(() =>
                    import ("./sweeps.da_JFxrH.js"), []),
                "../sanity/backup-data/seo/-casino-games-diamonds/production.json": () => o(() =>
                    import ("./production.B1128s68.js"), []),
                "../sanity/backup-data/seo/-casino-games-diamonds/sweeps.json": () => o(() =>
                    import ("./sweeps.CDWO_i18.js"), []),
                "../sanity/backup-data/seo/-casino-games-dice/production.json": () => o(() =>
                    import ("./production.Do2qWap5.js"), []),
                "../sanity/backup-data/seo/-casino-games-dice/sweeps.json": () => o(() =>
                    import ("./sweeps.DVvzfbKe.js"), []),
                "../sanity/backup-data/seo/-casino-games-dragon-tower/production.json": () => o(() =>
                    import ("./production.DK_mr83-.js"), []),
                "../sanity/backup-data/seo/-casino-games-dragon-tower/sweeps.json": () => o(() =>
                    import ("./sweeps.FmUpZXOx.js"), []),
                "../sanity/backup-data/seo/-casino-games-evolution-monopoly-live/production.json": () => o(() =>
                    import ("./production.D10rGTea.js"), []),
                "../sanity/backup-data/seo/-casino-games-evolution-monopoly-live/sweeps.json": () => o(() =>
                    import ("./sweeps.UKWbAbyX.js"), []),
                "../sanity/backup-data/seo/-casino-games-hilo/production.json": () => o(() =>
                    import ("./production.Cabyp57L.js"), []),
                "../sanity/backup-data/seo/-casino-games-hilo/sweeps.json": () => o(() =>
                    import ("./sweeps.nJP0vMiu.js"), []),
                "../sanity/backup-data/seo/-casino-games-keno/production.json": () => o(() =>
                    import ("./production.lLLfzcVf.js"), []),
                "../sanity/backup-data/seo/-casino-games-keno/sweeps.json": () => o(() =>
                    import ("./sweeps.BgmDK-Sa.js"), []),
                "../sanity/backup-data/seo/-casino-games-limbo/production.json": () => o(() =>
                    import ("./production.Bq9wA1rh.js"), []),
                "../sanity/backup-data/seo/-casino-games-limbo/sweeps.json": () => o(() =>
                    import ("./sweeps.pebe3n0f.js"), []),
                "../sanity/backup-data/seo/-casino-games-mines/production.json": () => o(() =>
                    import ("./production.CIvDis9C.js"), []),
                "../sanity/backup-data/seo/-casino-games-mines/sweeps.json": () => o(() =>
                    import ("./sweeps.BDFXmsaG.js"), []),
                "../sanity/backup-data/seo/-casino-games-plinko/production.json": () => o(() =>
                    import ("./production.DlR89YOZ.js"), []),
                "../sanity/backup-data/seo/-casino-games-plinko/sweeps.json": () => o(() =>
                    import ("./sweeps.BMrYdxkj.js"), []),
                "../sanity/backup-data/seo/-casino-games-pragmatic-play-gates-of-olympus/production.json": () => o(() =>
                    import ("./production.CRXOQqDo.js"), []),
                "../sanity/backup-data/seo/-casino-games-pragmatic-play-gates-of-olympus/sweeps.json": () => o(() =>
                    import ("./sweeps.CZiWtdKh.js"), []),
                "../sanity/backup-data/seo/-casino-games-pragmatic-play-sweet-bonanza/production.json": () => o(() =>
                    import ("./production.CRpE2nnF.js"), []),
                "../sanity/backup-data/seo/-casino-games-pragmatic-play-sweet-bonanza/sweeps.json": () => o(() =>
                    import ("./sweeps.BkZWcnzz.js"), []),
                "../sanity/backup-data/seo/-casino-games-relax-money-train3/production.json": () => o(() =>
                    import ("./production.DhwQL_rB.js"), []),
                "../sanity/backup-data/seo/-casino-games-relax-money-train3/sweeps.json": () => o(() =>
                    import ("./sweeps.DpOv0Kpg.js"), []),
                "../sanity/backup-data/seo/-casino-games-roulette/production.json": () => o(() =>
                    import ("./production.DQrmR4Q-.js"), []),
                "../sanity/backup-data/seo/-casino-games-roulette/sweeps.json": () => o(() =>
                    import ("./sweeps.BFKiZjBR.js"), []),
                "../sanity/backup-data/seo/-casino-games-slide/production.json": () => o(() =>
                    import ("./production.Dtqq0w4j.js"), []),
                "../sanity/backup-data/seo/-casino-games-slide/sweeps.json": () => o(() =>
                    import ("./sweeps.WugRqPUR.js"), []),
                "../sanity/backup-data/seo/-casino-games-slots-samurai/production.json": () => o(() =>
                    import ("./production.7YbfKr3h.js"), []),
                "../sanity/backup-data/seo/-casino-games-slots-samurai/sweeps.json": () => o(() =>
                    import ("./sweeps.Dq9dZPkl.js"), []),
                "../sanity/backup-data/seo/-casino-games-slots/production.json": () => o(() =>
                    import ("./production.BYr7vcHY.js"), []),
                "../sanity/backup-data/seo/-casino-games-slots/sweeps.json": () => o(() =>
                    import ("./sweeps.CP8R515_.js"), []),
                "../sanity/backup-data/seo/-casino-games-tome-of-life/production.json": () => o(() =>
                    import ("./production.C1n9Lo1l.js"), []),
                "../sanity/backup-data/seo/-casino-games-tome-of-life/sweeps.json": () => o(() =>
                    import ("./sweeps.HcTD6LpJ.js"), []),
                "../sanity/backup-data/seo/-casino-games-video-poker/production.json": () => o(() =>
                    import ("./production.BGEZMkg7.js"), []),
                "../sanity/backup-data/seo/-casino-games-video-poker/sweeps.json": () => o(() =>
                    import ("./sweeps.D7PMA7kr.js"), []),
                "../sanity/backup-data/seo/-casino-games-wheel/production.json": () => o(() =>
                    import ("./production.BTDpP9V5.js"), []),
                "../sanity/backup-data/seo/-casino-games-wheel/sweeps.json": () => o(() =>
                    import ("./sweeps.CE3k8xTc.js"), []),
                "../sanity/backup-data/seo/-casino-group-baccarat/production.json": () => o(() =>
                    import ("./production.j1dnGWBu.js"), []),
                "../sanity/backup-data/seo/-casino-group-baccarat/sweeps.json": () => o(() =>
                    import ("./sweeps.BKG43L1W.js"), []),
                "../sanity/backup-data/seo/-casino-group-blackjack/production.json": () => o(() =>
                    import ("./production.BlaPKo3u.js"), []),
                "../sanity/backup-data/seo/-casino-group-blackjack/sweeps.json": () => o(() =>
                    import ("./sweeps.vA8jNX2T.js"), []),
                "../sanity/backup-data/seo/-casino-group-game-shows/production.json": () => o(() =>
                    import ("./production.9X4lcWJ6.js"), []),
                "../sanity/backup-data/seo/-casino-group-game-shows/sweeps.json": () => o(() =>
                    import ("./sweeps.B5rm73ZZ.js"), []),
                "../sanity/backup-data/seo/-casino-group-live-casino/production.json": () => o(() =>
                    import ("./production.Ceip9fi2.js"), []),
                "../sanity/backup-data/seo/-casino-group-live-casino/sweeps.json": () => o(() =>
                    import ("./sweeps.B4ruqmbg.js"), []),
                "../sanity/backup-data/seo/-casino-group-roulette/production.json": () => o(() =>
                    import ("./production.0GBy_4kw.js"), []),
                "../sanity/backup-data/seo/-casino-group-roulette/sweeps.json": () => o(() =>
                    import ("./sweeps.Cyaukp9f.js"), []),
                "../sanity/backup-data/seo/-casino-group-slots/production.json": () => o(() =>
                    import ("./production.D1GNzwk4.js"), []),
                "../sanity/backup-data/seo/-casino-group-slots/sweeps.json": () => o(() =>
                    import ("./sweeps.BW01qMvG.js"), []),
                "../sanity/backup-data/seo/-casino-group-stake-originals/production.json": () => o(() =>
                    import ("./production.CydLRKvG.js"), []),
                "../sanity/backup-data/seo/-casino-group-stake-originals/sweeps.json": () => o(() =>
                    import ("./sweeps.DCmHTPsN.js"), []),
                "../sanity/backup-data/seo/-casino-group-table-games/production.json": () => o(() =>
                    import ("./production.DYGp7Bsn.js"), []),
                "../sanity/backup-data/seo/-casino-group-table-games/sweeps.json": () => o(() =>
                    import ("./sweeps.D222ZBs2.js"), []),
                "../sanity/backup-data/seo/-root-home-page/production.json": () => o(() =>
                    import ("./production.DnUhTBNQ.js"), []),
                "../sanity/backup-data/seo/-root-home-page/sweeps.json": () => o(() =>
                    import ("./sweeps.CDsnFwKC.js"), []),
                "../sanity/backup-data/seo/-sports-american-football-usa-nfl/production.json": () => o(() =>
                    import ("./production.DkelMH9H.js"), []),
                "../sanity/backup-data/seo/-sports-american-football-usa-nfl/sweeps.json": () => o(() =>
                    import ("./sweeps.DsXMm515.js"), []),
                "../sanity/backup-data/seo/-sports-american-football/production.json": () => o(() =>
                    import ("./production.Dzpib9pX.js"), []),
                "../sanity/backup-data/seo/-sports-american-football/sweeps.json": () => o(() =>
                    import ("./sweeps.CJCO5ebP.js"), []),
                "../sanity/backup-data/seo/-sports-arena-of-valor/production.json": () => o(() =>
                    import ("./production.jFBkpMww.js"), []),
                "../sanity/backup-data/seo/-sports-arena-of-valor/sweeps.json": () => o(() =>
                    import ("./sweeps.7MY-C4AS.js"), []),
                "../sanity/backup-data/seo/-sports-aussie-rules/production.json": () => o(() =>
                    import ("./production.Ch7SJhqw.js"), []),
                "../sanity/backup-data/seo/-sports-aussie-rules/sweeps.json": () => o(() =>
                    import ("./sweeps.BAP64dab.js"), []),
                "../sanity/backup-data/seo/-sports-badminton/production.json": () => o(() =>
                    import ("./production.DLGgUrWY.js"), []),
                "../sanity/backup-data/seo/-sports-badminton/sweeps.json": () => o(() =>
                    import ("./sweeps.C1dGuWmB.js"), []),
                "../sanity/backup-data/seo/-sports-bandy/production.json": () => o(() =>
                    import ("./production.C3wHpw5V.js"), []),
                "../sanity/backup-data/seo/-sports-bandy/sweeps.json": () => o(() =>
                    import ("./sweeps.DPS8sOJp.js"), []),
                "../sanity/backup-data/seo/-sports-baseball/production.json": () => o(() =>
                    import ("./production.DYZvBQpV.js"), []),
                "../sanity/backup-data/seo/-sports-baseball/sweeps.json": () => o(() =>
                    import ("./sweeps.BnyYnI2l.js"), []),
                "../sanity/backup-data/seo/-sports-basketball-3x3/production.json": () => o(() =>
                    import ("./production.CZrJcbx5.js"), []),
                "../sanity/backup-data/seo/-sports-basketball-3x3/sweeps.json": () => o(() =>
                    import ("./sweeps.D9KTSNef.js"), []),
                "../sanity/backup-data/seo/-sports-basketball-usa-nba/production.json": () => o(() =>
                    import ("./production.DDhTaAUr.js"), []),
                "../sanity/backup-data/seo/-sports-basketball-usa-nba/sweeps.json": () => o(() =>
                    import ("./sweeps.CCTkCNje.js"), []),
                "../sanity/backup-data/seo/-sports-basketball/production.json": () => o(() =>
                    import ("./production.DKvR0HLK.js"), []),
                "../sanity/backup-data/seo/-sports-basketball/sweeps.json": () => o(() =>
                    import ("./sweeps.WcVGkmbO.js"), []),
                "../sanity/backup-data/seo/-sports-beach-soccer/production.json": () => o(() =>
                    import ("./production.CaUA8DCn.js"), []),
                "../sanity/backup-data/seo/-sports-beach-soccer/sweeps.json": () => o(() =>
                    import ("./sweeps.C-PM5fVk.js"), []),
                "../sanity/backup-data/seo/-sports-biathlon/production.json": () => o(() =>
                    import ("./production.qK_CxFj4.js"), []),
                "../sanity/backup-data/seo/-sports-biathlon/sweeps.json": () => o(() =>
                    import ("./sweeps.DjDCjqbp.js"), []),
                "../sanity/backup-data/seo/-sports-bowls/production.json": () => o(() =>
                    import ("./production.44ALR3VT.js"), []),
                "../sanity/backup-data/seo/-sports-bowls/sweeps.json": () => o(() =>
                    import ("./sweeps.BAnlKdqF.js"), []),
                "../sanity/backup-data/seo/-sports-boxing/production.json": () => o(() =>
                    import ("./production.CM1pA3E5.js"), []),
                "../sanity/backup-data/seo/-sports-boxing/sweeps.json": () => o(() =>
                    import ("./sweeps.B4mu5UYt.js"), []),
                "../sanity/backup-data/seo/-sports-call-of-duty/production.json": () => o(() =>
                    import ("./production.CUbaDBrg.js"), []),
                "../sanity/backup-data/seo/-sports-call-of-duty/sweeps.json": () => o(() =>
                    import ("./sweeps.SYvAuN4b.js"), []),
                "../sanity/backup-data/seo/-sports-counter-strike/production.json": () => o(() =>
                    import ("./production.CnqzzUxr.js"), []),
                "../sanity/backup-data/seo/-sports-counter-strike/sweeps.json": () => o(() =>
                    import ("./sweeps.CAy-C4Nx.js"), []),
                "../sanity/backup-data/seo/-sports-cricket/production.json": () => o(() =>
                    import ("./production.CMtk0ycM.js"), []),
                "../sanity/backup-data/seo/-sports-cricket/sweeps.json": () => o(() =>
                    import ("./sweeps.C9SXkr6E.js"), []),
                "../sanity/backup-data/seo/-sports-cross-country/production.json": () => o(() =>
                    import ("./production.Cc2m-wyo.js"), []),
                "../sanity/backup-data/seo/-sports-cross-country/sweeps.json": () => o(() =>
                    import ("./sweeps.C2ACxuCs.js"), []),
                "../sanity/backup-data/seo/-sports-curling/production.json": () => o(() =>
                    import ("./production.BFd8IAVn.js"), []),
                "../sanity/backup-data/seo/-sports-curling/sweeps.json": () => o(() =>
                    import ("./sweeps.C_XcJQcF.js"), []),
                "../sanity/backup-data/seo/-sports-cycling/production.json": () => o(() =>
                    import ("./production.VLU7aWcI.js"), []),
                "../sanity/backup-data/seo/-sports-cycling/sweeps.json": () => o(() =>
                    import ("./sweeps.CVBKPuVZ.js"), []),
                "../sanity/backup-data/seo/-sports-darts/production.json": () => o(() =>
                    import ("./production.ItRkK23X.js"), []),
                "../sanity/backup-data/seo/-sports-darts/sweeps.json": () => o(() =>
                    import ("./sweeps.CmIBcS__.js"), []),
                "../sanity/backup-data/seo/-sports-dota-2/production.json": () => o(() =>
                    import ("./production.DcUl8Aek.js"), []),
                "../sanity/backup-data/seo/-sports-electronic-leagues/production.json": () => o(() =>
                    import ("./production.-U8aaqKz.js"), []),
                "../sanity/backup-data/seo/-sports-field-hockey/production.json": () => o(() =>
                    import ("./production.BeQi1VF3.js"), []),
                "../sanity/backup-data/seo/-sports-field-hockey/sweeps.json": () => o(() =>
                    import ("./sweeps.ChKH2sdk.js"), []),
                "../sanity/backup-data/seo/-sports-fifa/production.json": () => o(() =>
                    import ("./production.BZUmaAlb.js"), []),
                "../sanity/backup-data/seo/-sports-fifa/sweeps.json": () => o(() =>
                    import ("./sweeps.B3IO1udb.js"), []),
                "../sanity/backup-data/seo/-sports-floorball/production.json": () => o(() =>
                    import ("./production.CMi6ILta.js"), []),
                "../sanity/backup-data/seo/-sports-floorball/sweeps.json": () => o(() =>
                    import ("./sweeps.Dx0WKMCm.js"), []),
                "../sanity/backup-data/seo/-sports-futsal/production.json": () => o(() =>
                    import ("./production.CGrgzWgM.js"), []),
                "../sanity/backup-data/seo/-sports-futsal/sweeps.json": () => o(() =>
                    import ("./sweeps.CryDsUpo.js"), []),
                "../sanity/backup-data/seo/-sports-gaelic-football/production.json": () => o(() =>
                    import ("./production.DEOhGUt1.js"), []),
                "../sanity/backup-data/seo/-sports-gaelic-football/sweeps.json": () => o(() =>
                    import ("./sweeps.lEzcrH1K.js"), []),
                "../sanity/backup-data/seo/-sports-gaelic-hurling/production.json": () => o(() =>
                    import ("./production.9kDA6jQV.js"), []),
                "../sanity/backup-data/seo/-sports-gaelic-hurling/sweeps.json": () => o(() =>
                    import ("./sweeps.pP1di_1b.js"), []),
                "../sanity/backup-data/seo/-sports-golf/production.json": () => o(() =>
                    import ("./production.CZkdHAn6.js"), []),
                "../sanity/backup-data/seo/-sports-golf/sweeps.json": () => o(() =>
                    import ("./sweeps.P4KqfZVW.js"), []),
                "../sanity/backup-data/seo/-sports-handball/production.json": () => o(() =>
                    import ("./production.BiFoCnTY.js"), []),
                "../sanity/backup-data/seo/-sports-handball/sweeps.json": () => o(() =>
                    import ("./sweeps.CTvbbmWx.js"), []),
                "../sanity/backup-data/seo/-sports-home-live/production.json": () => o(() =>
                    import ("./production.DUjOYmU7.js"), []),
                "../sanity/backup-data/seo/-sports-home-live/sweeps.json": () => o(() =>
                    import ("./sweeps.7PedaQ8I.js"), []),
                "../sanity/backup-data/seo/-sports-home/production.json": () => o(() =>
                    import ("./production.CctjFl9S.js"), []),
                "../sanity/backup-data/seo/-sports-home/sweeps.json": () => o(() =>
                    import ("./sweeps.Cw2fwhE_.js"), []),
                "../sanity/backup-data/seo/-sports-ice-hockey-usa-nhl/production.json": () => o(() =>
                    import ("./production.iLkmVbzf.js"), []),
                "../sanity/backup-data/seo/-sports-ice-hockey-usa-nhl/sweeps.json": () => o(() =>
                    import ("./sweeps.B5RKtdhd.js"), []),
                "../sanity/backup-data/seo/-sports-ice-hockey/production.json": () => o(() =>
                    import ("./production.Dz-RVHsH.js"), []),
                "../sanity/backup-data/seo/-sports-ice-hockey/sweeps.json": () => o(() =>
                    import ("./sweeps.CqO6XUph.js"), []),
                "../sanity/backup-data/seo/-sports-judo/production.json": () => o(() =>
                    import ("./production.DK4lrhgm.js"), []),
                "../sanity/backup-data/seo/-sports-judo/sweeps.json": () => o(() =>
                    import ("./sweeps.BZy56qyH.js"), []),
                "../sanity/backup-data/seo/-sports-kabaddi/production.json": () => o(() =>
                    import ("./production.CY7ks_1O.js"), []),
                "../sanity/backup-data/seo/-sports-league-of-legends/production.json": () => o(() =>
                    import ("./production.CeyrpZA6.js"), []),
                "../sanity/backup-data/seo/-sports-league-of-legends/sweeps.json": () => o(() =>
                    import ("./sweeps.DC_lLRIc.js"), []),
                "../sanity/backup-data/seo/-sports-live/production.json": () => o(() =>
                    import ("./production.BfKMF_mE.js"), []),
                "../sanity/backup-data/seo/-sports-live/sweeps.json": () => o(() =>
                    import ("./sweeps.BQnjZA4p.js"), []),
                "../sanity/backup-data/seo/-sports-mma-ufc/production.json": () => o(() =>
                    import ("./production.CVbL6f47.js"), []),
                "../sanity/backup-data/seo/-sports-mma-ufc/sweeps.json": () => o(() =>
                    import ("./sweeps.DSw1-SXJ.js"), []),
                "../sanity/backup-data/seo/-sports-mma/production.json": () => o(() =>
                    import ("./production.BbM42Aic.js"), []),
                "../sanity/backup-data/seo/-sports-mma/sweeps.json": () => o(() =>
                    import ("./sweeps.BkPw0ZR0.js"), []),
                "../sanity/backup-data/seo/-sports-motorcycle-racing/production.json": () => o(() =>
                    import ("./production.CrWe4njG.js"), []),
                "../sanity/backup-data/seo/-sports-motorcycle-racing/sweeps.json": () => o(() =>
                    import ("./sweeps.CyrsodVs.js"), []),
                "../sanity/backup-data/seo/-sports-politics-entertainment/production.json": () => o(() =>
                    import ("./production.CZiNYEOO.js"), []),
                "../sanity/backup-data/seo/-sports-rocket-league/production.json": () => o(() =>
                    import ("./production.BytYBdWe.js"), []),
                "../sanity/backup-data/seo/-sports-rocket-league/sweeps.json": () => o(() =>
                    import ("./sweeps.nNK5bz4a.js"), []),
                "../sanity/backup-data/seo/-sports-rugby/production.json": () => o(() =>
                    import ("./production.B-3zyNye.js"), []),
                "../sanity/backup-data/seo/-sports-rugby/sweeps.json": () => o(() =>
                    import ("./sweeps.5j7Qvf3q.js"), []),
                "../sanity/backup-data/seo/-sports-snooker/production.json": () => o(() =>
                    import ("./production.CS10gp8y.js"), []),
                "../sanity/backup-data/seo/-sports-soccer/production.json": () => o(() =>
                    import ("./production.CatMn70-.js"), []),
                "../sanity/backup-data/seo/-sports-soccer/sweeps.json": () => o(() =>
                    import ("./sweeps.DalTjcXX.js"), []),
                "../sanity/backup-data/seo/-sports-squash/production.json": () => o(() =>
                    import ("./production.NOAeysyy.js"), []),
                "../sanity/backup-data/seo/-sports-squash/sweeps.json": () => o(() =>
                    import ("./sweeps.C1TqG_xK.js"), []),
                "../sanity/backup-data/seo/-sports-stock-car-racing/production.json": () => o(() =>
                    import ("./production.Cq2i4rle.js"), []),
                "../sanity/backup-data/seo/-sports-stock-car-racing/sweeps.json": () => o(() =>
                    import ("./sweeps.DXzWMe7Z.js"), []),
                "../sanity/backup-data/seo/-sports-table-tennis/production.json": () => o(() =>
                    import ("./production.CRXLfQmI.js"), []),
                "../sanity/backup-data/seo/-sports-table-tennis/sweeps.json": () => o(() =>
                    import ("./sweeps.8HpcyxPK.js"), []),
                "../sanity/backup-data/seo/-sports-tennis/production.json": () => o(() =>
                    import ("./production.DJqJdcMy.js"), []),
                "../sanity/backup-data/seo/-sports-tennis/sweeps.json": () => o(() =>
                    import ("./sweeps.BCFtZfEl.js"), []),
                "../sanity/backup-data/seo/-sports-volleyball/production.json": () => o(() =>
                    import ("./production.Dza_8ppW.js"), []),
                "../sanity/backup-data/seo/-sports-volleyball/sweeps.json": () => o(() =>
                    import ("./sweeps.BCYA1tOh.js"), []),
                "../sanity/backup-data/seo/-sports-waterpolo/production.json": () => o(() =>
                    import ("./production.D5lhvV61.js"), []),
                "../sanity/backup-data/seo/-sports-waterpolo/sweeps.json": () => o(() =>
                    import ("./sweeps.BscvgWsB.js"), [])
            }), `../sanity/backup-data/seo/${r}/${$}.json`, 6)
        } catch (p) {
            return console.error(p), null
        }
    };

function P(s) {
    var p, _, i, a;
    const r = { ...s,
        sanitizedJsonLd: "",
        openGraph: {
            title: s == null ? void 0 : s.title,
            description: s == null ? void 0 : s.description,
            images: (_ = (p = s == null ? void 0 : s.thumbnail) == null ? void 0 : p.asset) != null && _.url ? [{
                url: `${(a=(i=s==null?void 0:s.thumbnail)==null?void 0:i.asset)==null?void 0:a.url}`,
                alt: `${(s==null?void 0:s.thumbnailAlt)||(s==null?void 0:s.title)} thumbnail`
            }] : []
        }
    };
    if (r != null && r.jsonLd) {
        let m;
        try {
            m = G(r.jsonLd), r.sanitizedJsonLd = h(F(m))
        } catch (e) {
            console.error(e)
        }
    }
    return r
}
const D = () => !!B("session"),
    Y = (s, r) => D() ? S(s, r) : f(s, r),
    x = (s, r) => D() ? x(s, r) : f(s, r);
async function so(s, r, p, _ = Y) {
    try {
        const {
            lang: i
        } = s.params;
        let a = r;
        i && r.startsWith(`/${i}/`) && (a = N(r, i));
        const m = await _(s, {
            slug: a
        });
        if (!m) {
            if (i == "en" && H.includes(a)) {
                const d = await U(a);
                return P(d)
            }
            return p
        }
        return P(m)
    } catch (i) {
        return console.error("seo fetch failed", i), p
    }
}
export {
    Y as a, so as f, x as g
};