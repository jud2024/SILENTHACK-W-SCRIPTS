import {
    G as _,
    s as H,
    e as M,
    d as U,
    f as L,
    i as S,
    F as D,
    j as I,
    c as x,
    o as F,
    t as q,
    h as X,
    k as z,
    l as J,
    n as K,
    p as Q
} from "./scheduler.DXu26z7T.js";
import {
    s as p
} from "./index.A2FRVEtT.js";
import {
    b as h,
    r as j
} from "./index.lhCIiKC2.js";
import {
    h as l,
    aV as g,
    aW as d,
    aX as Y,
    i as Z
} from "./index.B4-7gKq3.js";
import {
    S as $,
    i as ee,
    c as w,
    a as B,
    m as k,
    t as A,
    b as O,
    d as R
} from "./index.Dz_MmNB3.js";
import "./index.ByMdEFI5.js";
import {
    d as te
} from "./index.C2-CG2CN.js";
import "./index.B3dW9TVs.js";
import {
    r as v
} from "./constants.DX75DoF3.js";
import {
    H as ae
} from "./index.u8ZD9oiA.js";
import {
    i as W
} from "./index.c5a505nz.js";
import {
    B as se
} from "./button.BwmFDw8u.js";
import {
    L as ne
} from "./Live.DUBCovZv.js";
const o = {
        cancelled: l._("Cancelled"),
        active: l._("Active"),
        cashout: l._("Cashed Out"),
        pending: l._("Pending"),
        rejected: l._("Rejected"),
        tie: l._("Void"),
        loss: l._("Loss"),
        win: l._("Win"),
        halfLoss: l._("Half Loss"),
        halfWin: l._("Half Win"),
        partiallyRefunded: l._("Partially Refunded"),
        settled: l._("Settled"),
        adjusted: l._("Adjusted")
    },
    P = s => {
        if (s === "jpWin" || s === "win") return "win";
        if (s === "jpPlace" || s === "place") return "place"
    },
    C = (s, t, e) => s.id + "-" + t.id + "-" + e,
    ie = ({
        event: s,
        runner: t,
        outcome: e,
        betType: a,
        spOutcome: n,
        eachWayOdds: i
    }) => ({
        type: "racingBet",
        id: e.id,
        data: {
            eachWaySelected: a === d.each_way,
            ...n && {
                spMarket: P(e.market.name)
            },
            odds: e.odds,
            event: s,
            runner: t,
            outcome: e,
            betType: a === "each_way" ? d.each_way : P(e.market.name) === "win" ? d.win : d.place
        },
        state: {
            acceptedOdds: i !== void 0 ? i : e.odds
        }
    }),
    re = (s, t, e) => {
        const a = C(s, t, e);
        return {
            type: "racingBet",
            id: a,
            data: {
                eachWaySelected: !1,
                spMarket: e,
                odds: 1,
                event: s,
                runner: t,
                betType: e === "win" ? d.win : d.place,
                outcome: {
                    __typename: "RacingOutcome",
                    id: a,
                    active: !0,
                    odds: 1,
                    market: {
                        __typename: "RacingMarket",
                        name: e,
                        status: Y.active
                    }
                }
            },
            state: {
                acceptedOdds: 1
            }
        }
    },
    Be = {
        getSettledBetStatus: s => s.adjustments.length > 0 ? {
            message: o.adjusted,
            variant: "light"
        } : s.resultType === g.WON ? {
            message: o.win,
            variant: "success"
        } : s.resultType === g.LOST ? {
            message: o.loss,
            variant: "light"
        } : s.resultType === g.CANCELLED ? {
            message: o.cancelled,
            variant: "default"
        } : s.resultType === g.PARTIAL_REFUNDED ? {
            message: o.partiallyRefunded,
            variant: "light"
        } : {
            message: o.tie,
            variant: "light"
        },
        handleOutcomeSelection: (s, t, e, a) => {
            const n = ie({
                event: s,
                runner: t,
                outcome: e,
                spOutcome: a
            });
            (e == null ? void 0 : e.id) in _(h) && !_(h)[e == null ? void 0 : e.id].state.response ? p.send({
                type: "REMOVE_BET",
                bet: n
            }) : p.send({
                type: "ADD_BET",
                bet: n
            })
        },
        handleSPSelection: (s, t, e) => {
            const a = re(s, t, e),
                n = C(s, t, e);
            n in _(h) && !_(h)[n].state.response ? p.send({
                type: "REMOVE_BET",
                bet: a
            }) : p.send({
                type: "ADD_BET",
                bet: a
            })
        },
        mapOutcomeTypeToTranslation: (s, t = void 0, e) => ({
            win: t ? "spWin" : "fixedWin",
            place: t ? "spPlace" : "fixedPlace",
            ...e && t && {
                win: "jpSpWin",
                place: "jpSpPlace"
            },
            each_way: t ? "spWinOrPlace" : "winOrPlace",
            big_six: "bigSix",
            first_four: "firstFour",
            place_n: "placeN",
            same_race_multi: "sameRaceMulti"
        })[s] || s
    };

function le(s) {
    let t, e;
    return t = new ne({}), {
        c() {
            w(t.$$.fragment)
        },
        l(a) {
            B(t.$$.fragment, a)
        },
        m(a, n) {
            k(t, a, n), e = !0
        },
        i(a) {
            e || (A(t.$$.fragment, a), e = !0)
        },
        o(a) {
            O(t.$$.fragment, a), e = !1
        },
        d(a) {
            R(t, a)
        }
    }
}

function ce(s) {
    let t, e;
    return t = new se({
        props: {
            variant: "subtle-link",
            "data-analytics": "sports-stream-button",
            disabled: s[8] || !s[5],
            $$slots: {
                default: [le]
            },
            $$scope: {
                ctx: s
            }
        }
    }), t.$on("click", s[10]), {
        c() {
            w(t.$$.fragment)
        },
        l(a) {
            B(t.$$.fragment, a)
        },
        m(a, n) {
            k(t, a, n), e = !0
        },
        p(a, n) {
            const i = {};
            n & 288 && (i.disabled = a[8] || !a[5]), n & 2048 && (i.$$scope = {
                dirty: n,
                ctx: a
            }), t.$set(i)
        },
        i(a) {
            e || (A(t.$$.fragment, a), e = !0)
        },
        o(a) {
            O(t.$$.fragment, a), e = !1
        },
        d(a) {
            R(t, a)
        }
    }
}

function oe(s) {
    let t, e = s[7]._(s[5] ? v.liveStream : v.availableSoon) + "",
        a;
    return {
        c() {
            t = M("span"), a = q(e), this.h()
        },
        l(n) {
            t = U(n, "SPAN", {
                slot: !0
            });
            var i = L(t);
            a = X(i, e), i.forEach(S), this.h()
        },
        h() {
            D(t, "slot", "tooltip")
        },
        m(n, i) {
            I(n, t, i), z(t, a)
        },
        p(n, i) {
            i & 160 && e !== (e = n[7]._(n[5] ? v.liveStream : v.availableSoon) + "") && J(a, e)
        },
        d(n) {
            n && S(t)
        }
    }
}

function de(s) {
    let t, e, a;
    return e = new ae({
        props: {
            $$slots: {
                tooltip: [oe],
                default: [ce]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            t = M("div"), w(e.$$.fragment), this.h()
        },
        l(n) {
            t = U(n, "DIV", {
                class: !0
            });
            var i = L(t);
            B(e.$$.fragment, i), i.forEach(S), this.h()
        },
        h() {
            D(t, "class", "inline-flex")
        },
        m(n, i) {
            I(n, t, i), k(e, t, null), a = !0
        },
        p(n, [i]) {
            const c = {};
            i & 2495 && (c.$$scope = {
                dirty: i,
                ctx: n
            }), e.$set(c)
        },
        i(n) {
            a || (A(e.$$.fragment, n), a = !0)
        },
        o(n) {
            O(e.$$.fragment, n), a = !1
        },
        d(n) {
            n && S(t), R(e)
        }
    }
}

function me(s, t, e) {
    let a, n, i, c = K,
        G = () => (c(), c = Q(a, r => e(8, i = r)), a);
    x(s, Z, r => e(7, n = r)), s.$$.on_destroy.push(() => c());
    let {
        id: y
    } = t, {
        title: b
    } = t, {
        streamUrl: m
    } = t, {
        streamGeoBlocked: E
    } = t, {
        streamEventStart: u
    } = t, {
        linkUrl: T = ""
    } = t, f = W(u);
    F(() => {
        if (f) return;
        const r = setInterval(() => {
            W(u) && (e(5, f = !0), clearInterval(r))
        }, 1e4);
        return () => {
            r && clearInterval(r)
        }
    });
    const N = () => {
        j.add({
            id: y,
            name: b,
            streamUrl: m,
            streamGeoBlocked: E,
            streamAvailable: f,
            linkUrl: T
        })
    };
    return s.$$set = r => {
        "id" in r && e(0, y = r.id), "title" in r && e(1, b = r.title), "streamUrl" in r && e(2, m = r.streamUrl), "streamGeoBlocked" in r && e(3, E = r.streamGeoBlocked), "streamEventStart" in r && e(9, u = r.streamEventStart), "linkUrl" in r && e(4, T = r.linkUrl)
    }, s.$$.update = () => {
        s.$$.dirty & 4 && G(e(6, a = te(j, r => r.some(V => V.streamUrl === m))))
    }, [y, b, m, E, T, f, a, n, i, u, N]
}
class ke extends $ {
    constructor(t) {
        super(), ee(this, t, me, de, H, {
            id: 0,
            title: 1,
            streamUrl: 2,
            streamGeoBlocked: 3,
            streamEventStart: 9,
            linkUrl: 4
        })
    }
}
export {
    ke as B, re as a, P as c, o as m, ie as o, Be as r, C as s
};