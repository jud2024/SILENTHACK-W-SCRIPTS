import {
    s as B,
    e as k,
    O as E,
    d as q,
    f as L,
    P as M,
    i as m,
    j as g,
    k as C,
    L as V,
    X as G,
    K as I,
    M as J,
    Q as y,
    V as P,
    F as T,
    W as R,
    t as K,
    h as O,
    l as Y,
    a as Z,
    m as W,
    u as w,
    g as $,
    b as x
} from "./scheduler.DXu26z7T.js";
import {
    S as ee,
    i as te,
    c as N,
    a as S,
    m as A,
    t as _,
    g as Q,
    b as v,
    e as U,
    d as D
} from "./index.Dz_MmNB3.js";
import {
    g as ae
} from "./spread.CgU5AtxT.js";
import "./index.ByMdEFI5.js";
import {
    L as le,
    a as se
} from "./index.BL_Dq_5k.js";
import {
    T as ie
} from "./index.D7nbRHfU.js";
import {
    E as re
} from "./Error.DAkWdr3O.js";
const ne = n => ({}),
    j = n => ({});

function F(n) {
    let e, l;
    return e = new ie({
        props: {
            lineHeight: "none",
            variant: "negative",
            id: "rego-terms",
            $$slots: {
                default: [fe]
            },
            $$scope: {
                ctx: n
            }
        }
    }), {
        c() {
            N(e.$$.fragment)
        },
        l(i) {
            S(e.$$.fragment, i)
        },
        m(i, o) {
            A(e, i, o), l = !0
        },
        i(i) {
            l || (_(e.$$.fragment, i), l = !0)
        },
        o(i) {
            v(e.$$.fragment, i), l = !1
        },
        d(i) {
            D(e, i)
        }
    }
}

function fe(n) {
    let e;
    return {
        c() {
            e = K("*")
        },
        l(l) {
            e = O(l, "*")
        },
        m(l, i) {
            g(l, e, i)
        },
        d(l) {
            l && m(e)
        }
    }
}

function oe(n) {
    let e, l, i;
    const o = n[10].label,
        s = Z(o, n, n[12], j);
    let a = n[6] && F(n);
    return {
        c() {
            s && s.c(), e = E(), a && a.c(), l = W()
        },
        l(t) {
            s && s.l(t), e = M(t), a && a.l(t), l = W()
        },
        m(t, f) {
            s && s.m(t, f), g(t, e, f), a && a.m(t, f), g(t, l, f), i = !0
        },
        p(t, f) {
            s && s.p && (!i || f & 4096) && w(s, o, t, t[12], i ? x(o, t[12], f, ne) : $(t[12]), j), t[6] ? a ? f & 64 && _(a, 1) : (a = F(t), a.c(), _(a, 1), a.m(l.parentNode, l)) : a && (Q(), v(a, 1, 1, () => {
                a = null
            }), U())
        },
        i(t) {
            i || (_(s, t), _(a), i = !0)
        },
        o(t) {
            v(s, t), v(a), i = !1
        },
        d(t) {
            t && (m(e), m(l)), s && s.d(t), a && a.d(t)
        }
    }
}

function ue(n) {
    let e, l, i, o, s, a, t, f, b, h = [{
            type: n[0]
        }, {
            value: n[3]
        }, {
            disabled: n[2]
        }, {
            checked: n[1]
        }, n[9]],
        d = {};
    for (let r = 0; r < h.length; r += 1) d = I(d, h[r]);
    return a = new se({
        props: {
            style: "padding-top: " + n[8] + "; margin-left: var(--space-2);  ",
            fullWidth: !0,
            $$slots: {
                default: [oe]
            },
            $$scope: {
                ctx: n
            }
        }
    }), {
        c() {
            e = k("input"), l = E(), i = k("span"), s = E(), N(a.$$.fragment), this.h()
        },
        l(r) {
            e = q(r, "INPUT", {
                type: !0
            }), l = M(r), i = q(r, "SPAN", {
                class: !0
            }), L(i).forEach(m), s = M(r), S(a.$$.fragment, r), this.h()
        },
        h() {
            y(e, d), P(e, "svelte-1g0eabw", !0), T(i, "class", o = "indicator variant-" + n[5] + " svelte-1g0eabw"), P(i, "invalid", !n[1] && n[4])
        },
        m(r, c) {
            g(r, e, c), "value" in d && (e.value = d.value), e.autofocus && e.focus(), g(r, l, c), g(r, i, c), g(r, s, c), A(a, r, c), t = !0, f || (b = R(e, "change", n[11]), f = !0)
        },
        p(r, c) {
            y(e, d = ae(h, [(!t || c & 1) && {
                type: r[0]
            }, (!t || c & 8 && e.value !== r[3]) && {
                value: r[3]
            }, (!t || c & 4) && {
                disabled: r[2]
            }, (!t || c & 2) && {
                checked: r[1]
            }, c & 512 && r[9]])), "value" in d && (e.value = d.value), P(e, "svelte-1g0eabw", !0), (!t || c & 32 && o !== (o = "indicator variant-" + r[5] + " svelte-1g0eabw")) && T(i, "class", o), (!t || c & 50) && P(i, "invalid", !r[1] && r[4]);
            const p = {};
            c & 4160 && (p.$$scope = {
                dirty: c,
                ctx: r
            }), a.$set(p)
        },
        i(r) {
            t || (_(a.$$.fragment, r), t = !0)
        },
        o(r) {
            v(a.$$.fragment, r), t = !1
        },
        d(r) {
            r && (m(e), m(l), m(i), m(s)), D(a, r), f = !1, b()
        }
    }
}

function H(n) {
    let e, l, i, o, s, a;
    return l = new re({}), {
        c() {
            e = k("div"), N(l.$$.fragment), i = E(), o = k("span"), s = K(n[4]), this.h()
        },
        l(t) {
            e = q(t, "DIV", {
                class: !0
            });
            var f = L(e);
            S(l.$$.fragment, f), i = M(f), o = q(f, "SPAN", {});
            var b = L(o);
            s = O(b, n[4]), b.forEach(m), f.forEach(m), this.h()
        },
        h() {
            T(e, "class", "input-error svelte-1g0eabw")
        },
        m(t, f) {
            g(t, e, f), A(l, e, null), C(e, i), C(e, o), C(o, s), a = !0
        },
        p(t, f) {
            (!a || f & 16) && Y(s, t[4])
        },
        i(t) {
            a || (_(l.$$.fragment, t), a = !0)
        },
        o(t) {
            v(l.$$.fragment, t), a = !1
        },
        d(t) {
            t && m(e), D(l)
        }
    }
}

function ce(n) {
    let e, l, i, o;
    l = new le({
        props: {
            "data-test": n[9]["data-test"],
            stacked: !1,
            style: "flex-direction: row; cursor: pointer;",
            $$slots: {
                default: [ue]
            },
            $$scope: {
                ctx: n
            }
        }
    });
    let s = !n[1] && n[4] && H(n);
    return {
        c() {
            e = k("div"), N(l.$$.fragment), i = E(), s && s.c()
        },
        l(a) {
            e = q(a, "DIV", {});
            var t = L(e);
            S(l.$$.fragment, t), i = M(t), s && s.l(t), t.forEach(m)
        },
        m(a, t) {
            g(a, e, t), A(l, e, null), C(e, i), s && s.m(e, null), o = !0
        },
        p(a, [t]) {
            const f = {};
            t & 512 && (f["data-test"] = a[9]["data-test"]), t & 4735 && (f.$$scope = {
                dirty: t,
                ctx: a
            }), l.$set(f), !a[1] && a[4] ? s ? (s.p(a, t), t & 18 && _(s, 1)) : (s = H(a), s.c(), _(s, 1), s.m(e, null)) : s && (Q(), v(s, 1, 1, () => {
                s = null
            }), U())
        },
        i(a) {
            o || (_(l.$$.fragment, a), _(s), o = !0)
        },
        o(a) {
            v(l.$$.fragment, a), v(s), o = !1
        },
        d(a) {
            a && m(e), D(l), s && s.d()
        }
    }
}

function me(n, e, l) {
    const i = ["type", "checked", "disabled", "value", "errorMessage", "variant", "required"];
    let o = V(e, i),
        {
            $$slots: s = {},
            $$scope: a
        } = e,
        {
            type: t = "checkbox"
        } = e,
        {
            checked: f
        } = e,
        {
            disabled: b = !1
        } = e,
        {
            value: h = void 0
        } = e,
        {
            errorMessage: d = void 0
        } = e,
        {
            variant: r = "default"
        } = e,
        {
            required: c = !1
        } = e;
    const p = G(),
        X = t === "radio" ? "4px" : "6px",
        z = u => p("change", u);
    return n.$$set = u => {
        e = I(I({}, e), J(u)), l(9, o = V(e, i)), "type" in u && l(0, t = u.type), "checked" in u && l(1, f = u.checked), "disabled" in u && l(2, b = u.disabled), "value" in u && l(3, h = u.value), "errorMessage" in u && l(4, d = u.errorMessage), "variant" in u && l(5, r = u.variant), "required" in u && l(6, c = u.required), "$$scope" in u && l(12, a = u.$$scope)
    }, [t, f, b, h, d, r, c, p, X, o, s, z, a]
}
class ke extends ee {
    constructor(e) {
        super(), te(this, e, me, ce, B, {
            type: 0,
            checked: 1,
            disabled: 2,
            value: 3,
            errorMessage: 4,
            variant: 5,
            required: 6
        })
    }
}
export {
    ke as C
};