import {
    v as o
} from "./index.B4-7gKq3.js";
import {
    x as r,
    v as i
} from "./scheduler.DXu26z7T.js";
const s = "__stores__userNotificationsEmitter",
    a = () => {
        const t = {
            emitter: o()
        };
        return i(s, t), t
    },
    m = () => r(s);
export {
    a as c, m as g
};