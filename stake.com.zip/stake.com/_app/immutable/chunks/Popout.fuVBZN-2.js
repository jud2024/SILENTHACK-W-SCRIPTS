import {
    s as o,
    C as c,
    H as u,
    D as f,
    f as m,
    E as _,
    i as r,
    F as h,
    j as d,
    n as v
} from "./scheduler.DXu26z7T.js";
import {
    S as g,
    i as H
} from "./index.Dz_MmNB3.js";

function V(n) {
    let e, s, a = ` <title>${n[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M10.823 53.176h42.353V39.941h7.059v20.294H3.765V3.765h20.293v7.058H10.823v42.353Zm28.236-42.353V3.765h21.176V24.94h-7.059v-9.123L27.88 41.115l-4.994-4.995 25.297-25.296H39.06Z"></path>`,
        i;
    return {
        c() {
            e = c("svg"), s = new u(!0), this.h()
        },
        l(l) {
            e = f(l, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var t = m(e);
            s = _(t, !0), t.forEach(r), this.h()
        },
        h() {
            s.a = null, h(e, "fill", "currentColor"), h(e, "viewBox", "0 0 64 64"), h(e, "class", i = "svg-icon " + n[2]), h(e, "style", n[0])
        },
        m(l, t) {
            d(l, e, t), s.m(a, e)
        },
        p(l, [t]) {
            t & 2 && a !== (a = ` <title>${l[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M10.823 53.176h42.353V39.941h7.059v20.294H3.765V3.765h20.293v7.058H10.823v42.353Zm28.236-42.353V3.765h21.176V24.94h-7.059v-9.123L27.88 41.115l-4.994-4.995 25.297-25.296H39.06Z"></path>`) && s.p(a), t & 4 && i !== (i = "svg-icon " + l[2]) && h(e, "class", i), t & 1 && h(e, "style", l[0])
        },
        i: v,
        o: v,
        d(l) {
            l && r(e)
        }
    }
}

function y(n, e, s) {
    let {
        style: a = ""
    } = e, {
        alt: i = ""
    } = e, {
        class: l = ""
    } = e;
    return n.$$set = t => {
        "style" in t && s(0, a = t.style), "alt" in t && s(1, i = t.alt), "class" in t && s(2, l = t.class)
    }, [a, i, l]
}
class C extends g {
    constructor(e) {
        super(), H(this, e, y, V, o, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    C as P
};