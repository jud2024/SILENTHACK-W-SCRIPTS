import {
    s as A,
    c as y,
    m as g,
    j as b,
    i as p,
    a1 as D,
    t as $,
    h as I,
    l as U,
    n as d,
    e as R,
    d as j,
    f as q,
    k as x
} from "./scheduler.DXu26z7T.js";
import {
    S as H,
    i as O,
    c as C,
    a as B,
    m as S,
    t as f,
    b as _,
    d as v,
    g as E,
    e as F
} from "./index.Dz_MmNB3.js";
import {
    e as M
} from "./each.DvgCmocI.js";
import {
    T as P
} from "./index.D7nbRHfU.js";
import {
    F as Y
} from "./index.BzMmusTo.js";
import {
    C as z
} from "./index.CAbJJJ2j.js";
import {
    h as V,
    R as G,
    H as J,
    i as K
} from "./index.B4-7gKq3.js";
import {
    V as L
} from "./index.B81orGJm.js";
const w = {
        description: {
            id: "First to hit {multiplier} with min {minBet} {bet}"
        },
        bet: V._("bet")
    },
    Q = { ...w,
        bet: V._("play")
    },
    W = {
        stake: w,
        sweeps: Q
    },
    k = W[L] || w;

function N(o, e, r) {
    const t = o.slice();
    return t[9] = e[r], t
}

function X(o) {
    let e = o[2]._(k.bet) + "",
        r;
    return {
        c() {
            r = $(e)
        },
        l(t) {
            r = I(t, e)
        },
        m(t, n) {
            b(t, r, n)
        },
        p(t, n) {
            n & 4 && e !== (e = t[2]._(k.bet) + "") && U(r, e)
        },
        i: d,
        o: d,
        d(t) {
            t && p(r)
        }
    }
}

function Z(o) {
    let e, r;
    return e = new z({
        props: {
            currency: o[1],
            value: o[3]
        }
    }), {
        c() {
            C(e.$$.fragment)
        },
        l(t) {
            B(e.$$.fragment, t)
        },
        m(t, n) {
            S(e, t, n), r = !0
        },
        p(t, n) {
            const c = {};
            n & 2 && (c.currency = t[1]), n & 8 && (c.value = t[3]), e.$set(c)
        },
        i(t) {
            r || (f(e.$$.fragment, t), r = !0)
        },
        o(t) {
            _(e.$$.fragment, t), r = !1
        },
        d(t) {
            v(e, t)
        }
    }
}

function ee(o) {
    let e, r;
    return e = new Y({
        props: {
            value: o[0]
        }
    }), {
        c() {
            C(e.$$.fragment)
        },
        l(t) {
            B(e.$$.fragment, t)
        },
        m(t, n) {
            S(e, t, n), r = !0
        },
        p(t, n) {
            const c = {};
            n & 1 && (c.value = t[0]), e.$set(c)
        },
        i(t) {
            r || (f(e.$$.fragment, t), r = !0)
        },
        o(t) {
            _(e.$$.fragment, t), r = !1
        },
        d(t) {
            v(e, t)
        }
    }
}

function te(o) {
    let e, r = o[9] + "",
        t;
    return {
        c() {
            e = R("span"), t = $(r)
        },
        l(n) {
            e = j(n, "SPAN", {});
            var c = q(e);
            t = I(c, r), c.forEach(p)
        },
        m(n, c) {
            b(n, e, c), x(e, t)
        },
        p(n, c) {
            c & 16 && r !== (r = n[9] + "") && U(t, r)
        },
        i: d,
        o: d,
        d(n) {
            n && p(e)
        }
    }
}

function T(o) {
    let e, r, t, n;
    const c = [te, ee, Z, X],
        l = [];

    function s(i, u) {
        return typeof i[9] == "string" ? 0 : i[9][0] === "multiplier" ? 1 : i[9][0] === "minBet" ? 2 : i[9][0] === "bet" ? 3 : -1
    }
    return ~(e = s(o)) && (r = l[e] = c[e](o)), {
        c() {
            r && r.c(), t = g()
        },
        l(i) {
            r && r.l(i), t = g()
        },
        m(i, u) {
            ~e && l[e].m(i, u), b(i, t, u), n = !0
        },
        p(i, u) {
            let m = e;
            e = s(i), e === m ? ~e && l[e].p(i, u) : (r && (E(), _(l[m], 1, 1, () => {
                l[m] = null
            }), F()), ~e ? (r = l[e], r ? r.p(i, u) : (r = l[e] = c[e](i), r.c()), f(r, 1), r.m(t.parentNode, t)) : r = null)
        },
        i(i) {
            n || (f(r), n = !0)
        },
        o(i) {
            _(r), n = !1
        },
        d(i) {
            i && p(t), ~e && l[e].d(i)
        }
    }
}

function re(o) {
    let e, r, t = M(o[4]),
        n = [];
    for (let l = 0; l < t.length; l += 1) n[l] = T(N(o, t, l));
    const c = l => _(n[l], 1, 1, () => {
        n[l] = null
    });
    return {
        c() {
            for (let l = 0; l < n.length; l += 1) n[l].c();
            e = g()
        },
        l(l) {
            for (let s = 0; s < n.length; s += 1) n[s].l(l);
            e = g()
        },
        m(l, s) {
            for (let i = 0; i < n.length; i += 1) n[i] && n[i].m(l, s);
            b(l, e, s), r = !0
        },
        p(l, s) {
            if (s & 31) {
                t = M(l[4]);
                let i;
                for (i = 0; i < t.length; i += 1) {
                    const u = N(l, t, i);
                    n[i] ? (n[i].p(u, s), f(n[i], 1)) : (n[i] = T(u), n[i].c(), f(n[i], 1), n[i].m(e.parentNode, e))
                }
                for (E(), i = t.length; i < n.length; i += 1) c(i);
                F()
            }
        },
        i(l) {
            if (!r) {
                for (let s = 0; s < t.length; s += 1) f(n[s]);
                r = !0
            }
        },
        o(l) {
            n = n.filter(Boolean);
            for (let s = 0; s < n.length; s += 1) _(n[s]);
            r = !1
        },
        d(l) {
            l && p(e), D(n, l)
        }
    }
}

function ne(o) {
    let e, r;
    return e = new P({
        props: {
            inline: !0,
            iconSpace: !1,
            variant: "subtle",
            $$slots: {
                default: [re]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            C(e.$$.fragment)
        },
        l(t) {
            B(e.$$.fragment, t)
        },
        m(t, n) {
            S(e, t, n), r = !0
        },
        p(t, [n]) {
            const c = {};
            n & 4127 && (c.$$scope = {
                dirty: n,
                ctx: t
            }), e.$set(c)
        },
        i(t) {
            r || (f(e.$$.fragment, t), r = !0)
        },
        o(t) {
            _(e.$$.fragment, t), r = !1
        },
        d(t) {
            v(e, t)
        }
    }
}

function ie(o, e, r) {
    let t, n, c, l, s, i;
    y(o, G, a => r(7, l = a)), y(o, J, a => r(8, s = a)), y(o, K, a => r(2, i = a));
    let {
        targetMultiplier: u
    } = e, {
        minBetUsd: m
    } = e, {
        betCurrency: h
    } = e;
    return o.$$set = a => {
        "targetMultiplier" in a && r(0, u = a.targetMultiplier), "minBetUsd" in a && r(5, m = a.minBetUsd), "betCurrency" in a && r(6, h = a.betCurrency)
    }, o.$$.update = () => {
        var a;
        o.$$.dirty & 4 && r(4, t = i.message(k.description.id)), o.$$.dirty & 320 && r(1, n = h || s), o.$$.dirty & 226 && r(3, c = m / ((a = l.rates) == null ? void 0 : a[n].usd))
    }, [u, n, i, c, t, m, h, l, s]
}
class _e extends H {
    constructor(e) {
        super(), O(this, e, ie, ne, A, {
            targetMultiplier: 0,
            minBetUsd: 5,
            betCurrency: 6
        })
    }
}
export {
    _e as C
};