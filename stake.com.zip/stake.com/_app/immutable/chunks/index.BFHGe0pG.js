import {
    w as A,
    x as D,
    o as j,
    v as P,
    G as O,
    s as Y,
    a as x,
    K as w,
    e as K,
    d as W,
    f as X,
    i as N,
    Q as q,
    V as C,
    j as G,
    W as Q,
    ac as z,
    u as H,
    g as J,
    b as U,
    L as B,
    X as Z,
    c as p,
    M as $
} from "./scheduler.DXu26z7T.js";
import {
    S as ee,
    i as te,
    t as se,
    b as ae
} from "./index.Dz_MmNB3.js";
import {
    g as ie
} from "./spread.CgU5AtxT.js";
import {
    h as b,
    _ as v
} from "./index.B4-7gKq3.js";
import {
    d as L,
    w as V
} from "./index.C2-CG2CN.js";
import {
    l as ne
} from "./object.KBCZ3_4R.js";
import {
    V as le
} from "./index.B81orGJm.js";

function oe(e) {
    Object.keys(e).forEach(t => {
        Object.keys(e[t]).forEach(l => {
            ne[t][l] = e[t][l]
        })
    })
}
const re = "storybookImmediatelyInvalidate",
    F = {
        max: b._("Max"),
        required: b._("This field is required"),
        currency: b._("Currency"),
        default: b._("This field is not valid"),
        numberTooSmall: e => ({
            id: "The minimum value is {min}",
            values: e
        }),
        numberTooBig: e => ({
            id: "The maximum value is {max}",
            values: e
        }),
        stringTooShort: e => ({
            id: "Minimum character length is {min}",
            values: e
        }),
        stringTooLong: e => ({
            id: "Maximum character length is {max}",
            values: e
        }),
        emailInvalid: b._("This contains invalid email characters"),
        withdrawTo: b._("Withdraw to"),
        countryCode: b._("Country code"),
        phoneNumber: b._("Phone number")
    },
    ue = { ...F,
        withdrawTo: b._("Redeem to")
    },
    ce = {
        stake: F,
        sweeps: ue
    },
    M = ce[le] || F,
    me = {
        min: ({
            min: e
        }) => ({
            key: "stringTooShort",
            values: {
                min: e
            }
        }),
        max: ({
            max: e
        }) => ({
            key: "stringTooLong",
            values: {
                max: e
            }
        }),
        email: M.emailInvalid
    },
    de = {
        min: ({
            min: e
        }) => ({
            key: "numberTooSmall",
            values: {
                min: e
            }
        }),
        max: ({
            max: e
        }) => ({
            key: "numberTooBig",
            values: {
                max: e
            }
        })
    },
    fe = {
        default: ({
            label: e
        }) => ({
            key: "default",
            values: {
                label: e
            }
        }),
        required: ({
            label: e
        }) => ({
            key: "required",
            values: {
                label: e
            }
        })
    },
    he = () => {
        oe({
            mixed: fe,
            string: me,
            number: de
        })
    },
    R = "@@form";

function ge(e) {
    P(R, e)
}

function ve() {
    return D(R)
}

function be({
    value: e,
    fieldKey: t,
    schema: l,
    getStores: g,
    transformValuesBeforeValidation: d
}) {
    const f = V(!1),
        n = V(e),
        c = V(!1),
        r = V(null),
        a = V(!1),
        o = V(!1);
    let y = e,
        h = e;
    const _ = async () => {
            var m, u;
            const i = g();
            if (i) {
                const I = v.mapValues(i, k => k.getValue());
                a.set(!0);
                try {
                    return await l.validateAt(t, d(I)), r.set(null), a.set(!1), null
                } catch (k) {
                    const S = k,
                        E = (M == null ? void 0 : M[(m = S.message) == null ? void 0 : m.key]) || S.message;
                    return (u = S == null ? void 0 : S.message) != null && u.values && typeof E == "function" ? r.set(E(S.message.values)) : r.set(E), a.set(!1), S.message
                }
            }
        },
        T = n.subscribe(i => {
            const m = O(c),
                u = O(o);
            y = i, m || c.set(i !== h), u && _()
        }),
        s = f.subscribe(i => {
            const m = O(c);
            !i && m && (o.set(!0), _())
        });
    return {
        touched: c,
        validating: a,
        value: n,
        error: r,
        focus: f,
        validateOnChange: o,
        validate: () => _(),
        unsubscribe: () => {
            T(), s()
        },
        reset: i => {
            n.set(i || h)
        },
        getValue: () => y,
        setInitialValue: i => {
            h = i
        }
    }
}

function _e(e) {
    return e
}

function Ee(e) {
    let t;
    he();
    const l = (e == null ? void 0 : e.transformValuesBeforeValidation) || _e,
        g = () => t;
    t = v.mapValues(e.initialValues, (s, i) => be({
        value: s,
        fieldKey: i,
        schema: e.validationSchema,
        getStores: g,
        transformValuesBeforeValidation: l
    })), A(() => {
        v.map(t, s => s.unsubscribe())
    });
    const d = V(!1),
        f = async () => {
            var m;
            d.set(!0);
            const s = await n(),
                i = s.every(u => u === null);
            if (window != null && window.formDebug && console.log(s), i) {
                const u = v.mapValues(t, I => O(I.value));
                try {
                    await e.onSubmit(u, T)
                } catch (I) {
                    console.error("handleSubmit", {
                        e: I
                    })
                }
            } else if (e.scrollToErrorOnSubmit) {
                const u = (m = document.getElementsByClassName("input-error")) == null ? void 0 : m[0];
                u && u.scrollIntoView({
                    behavior: "smooth",
                    block: "center"
                })
            }
            d.set(!1)
        },
        n = async () => await Promise.all(v.values(v.mapValues(t, i => i.validate()))),
        c = v.map(t, s => s.error),
        r = V(!1),
        a = v.map(t, s => s.validating),
        o = v.map(t, s => s.touched),
        y = L(c, s => !s.some(i => i !== null)),
        h = L(a, s => s.includes(!0)),
        _ = L(o, s => s.includes(!0)),
        T = {
            fields: t,
            isValid: y,
            validating: h,
            touched: _,
            isSubmitting: d,
            disabled: r,
            handleSubmit: f,
            validate: n,
            reset: s => {
                v.forEach(t, (i, m) => {
                    const u = s && m in s ? s[m] : e.initialValues[m];
                    i.validateOnChange.set(!1), i.setInitialValue(u), i.value.set(u), i.touched.set(!1)
                })
            }
        };
    return ge(T), D(re) && j(() => {
        n()
    }), T
}

function Ve(e) {
    let t, l, g, d;
    const f = e[9].default,
        n = x(f, e, e[8], null);
    let c = [{
            style: e[0]
        }, {
            "data-test-form-valid": e[2]
        }, e[6]],
        r = {};
    for (let a = 0; a < c.length; a += 1) r = w(r, c[a]);
    return {
        c() {
            t = K("form"), n && n.c(), this.h()
        },
        l(a) {
            t = W(a, "FORM", {
                style: !0,
                "data-test-form-valid": !0
            });
            var o = X(t);
            n && n.l(o), o.forEach(N), this.h()
        },
        h() {
            q(t, r), C(t, "is-inline", e[1]), C(t, "svelte-188ba96", !0)
        },
        m(a, o) {
            G(a, t, o), n && n.m(t, null), l = !0, g || (d = Q(t, "submit", z(e[10])), g = !0)
        },
        p(a, [o]) {
            n && n.p && (!l || o & 256) && H(n, f, a, a[8], l ? U(f, a[8], o, null) : J(a[8]), null), q(t, r = ie(c, [(!l || o & 1) && {
                style: a[0]
            }, (!l || o & 4) && {
                "data-test-form-valid": a[2]
            }, o & 64 && a[6]])), C(t, "is-inline", a[1]), C(t, "svelte-188ba96", !0)
        },
        i(a) {
            l || (se(n, a), l = !0)
        },
        o(a) {
            ae(n, a), l = !1
        },
        d(a) {
            a && N(t), n && n.d(a), g = !1, d()
        }
    }
}

function ye(e, t, l) {
    const g = ["style", "inline", "disabled"];
    let d = B(t, g),
        f, {
            $$slots: n = {},
            $$scope: c
        } = t,
        {
            style: r = void 0
        } = t,
        {
            inline: a = !1
        } = t,
        {
            disabled: o = !1
        } = t;
    const y = Z(),
        h = ve(),
        {
            isValid: _
        } = h;
    p(e, _, s => l(2, f = s));
    const T = s => {
        y("submit", s), h && h.handleSubmit()
    };
    return e.$$set = s => {
        t = w(w({}, t), $(s)), l(6, d = B(t, g)), "style" in s && l(0, r = s.style), "inline" in s && l(1, a = s.inline), "disabled" in s && l(7, o = s.disabled), "$$scope" in s && l(8, c = s.$$scope)
    }, e.$$.update = () => {
        e.$$.dirty & 128 && h.disabled.set(!!o)
    }, [r, a, f, y, h, _, d, o, c, n, T]
}
class Le extends ee {
    constructor(t) {
        super(), te(this, t, ye, Ve, Y, {
            style: 0,
            inline: 1,
            disabled: 7
        })
    }
}
export {
    Le as F, Ee as c, ve as g, M as m, de as n
};