const e = l => l <= 500 ? {
    slidesToShow: 3,
    initialSlide: 0,
    buttonSlidesToScroll: 3,
    slidesToHaveOpacity: 2,
    centerMode: !1,
    slidesToScroll: 3,
    gap: 5,
    draggable: !0
} : l <= 700 ? {
    slidesToShow: 4,
    initialSlide: 0,
    buttonSlidesToScroll: 4,
    slidesToHaveOpacity: 2,
    centerMode: !1,
    slidesToScroll: 4,
    gap: 5,
    draggable: !0
} : l <= 850 ? {
    slidesToShow: 4.5,
    initialSlide: 2,
    buttonSlidesToScroll: 3,
    slidesToHaveOpacity: 2,
    slidesToScroll: 4,
    gap: 15,
    draggable: !0
} : l <= 1e3 ? {
    slidesToShow: 5.5,
    initialSlide: 2,
    buttonSlidesToScroll: 3,
    slidesToHaveOpacity: 2,
    slidesToScroll: 5,
    gap: 15,
    draggable: !0
} : l <= 1150 ? {
    slidesToShow: 6.5,
    initialSlide: 3,
    buttonSlidesToScroll: 6,
    slidesToHaveOpacity: 3,
    slidesToScroll: 6,
    gap: 15,
    draggable: !1
} : {
    slidesToShow: 7.5,
    initialSlide: 3,
    buttonSlidesToScroll: 7,
    slidesToHaveOpacity: 3,
    slidesToScroll: 7,
    gap: 10,
    draggable: !1
};
export {
    e as g
};