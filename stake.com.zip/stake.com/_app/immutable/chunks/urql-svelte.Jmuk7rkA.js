import {
    w as m
} from "./index.C2-CG2CN.js";
import {
    v as p,
    w as h,
    x as d
} from "./scheduler.DXu26z7T.js";
import {
    c as v,
    s as x,
    N as $,
    a as k,
    K as O,
    m as j,
    b,
    d as w,
    e as C,
    t as P,
    g as _
} from "./index.B4-7gKq3.js";

function l() {
    return (l = Object.assign || function(n) {
        for (var s = 1; s < arguments.length; s++) {
            var a = arguments[s];
            for (var e in a) Object.prototype.hasOwnProperty.call(a, e) && (n[e] = a[e])
        }
        return n
    }).apply(this, arguments)
}

function S(n, s, a) {
    var e = {
            query: n,
            variables: s || null,
            context: a
        },
        t = {
            stale: !1,
            fetching: !1,
            data: void 0,
            error: void 0,
            extensions: void 0
        },
        i = m(t),
        f = !1;
    return t.set = function(r) {
        if (!(!r || r === t)) {
            f = !0;
            var c = !1;
            if ("query" in r || "variables" in r) {
                var g = v(e.query, e.variables),
                    q = v(r.query || e.query, r.variables || e.variables);
                g.key !== q.key && (c = !0, e.query = r.query || e.query, e.variables = r.variables || e.variables || null)
            }
            "context" in r && x(e.context) !== x(r.context) && (c = !0, e.context = r.context);
            for (var o in r) o === "query" || o === "variables" || o === "context" || (o === "fetching" ? t[o] = !!r[o] : o in t && (t[o] = r[o]), c = !0);
            t.stale = !!r.stale, f = !1, c && i.set(t)
        }
    }, t.update = function(r) {
        t.set(r(t))
    }, t.subscribe = function(r, c) {
        return i.subscribe(r, c)
    }, t.reexecute = function(u) {
        e.context = l({}, u || e.context), i.set(t)
    }, Object.keys(e).forEach(function(u) {
        Object.defineProperty(t, u, {
            configurable: !1,
            get: function() {
                return e[u]
            },
            set: function(c) {
                e[u] = c, f || i.set(t)
            }
        })
    }), t
}

function y() {
    return d("$$_urql")
}

function N(n) {
    p("$$_urql", n)
}
var V = {
    fetching: !1,
    stale: !1,
    error: void 0,
    data: void 0,
    extensions: void 0
};

function D(n) {
    return j(function(s) {
        var a, e = {};
        return n.subscribe(function(t) {
            var i = v(t.query, t.variables);
            ((i.context = t.context) !== e || i.key !== a) && (a = i.key, e = t.context, s.next(i))
        })
    })
}

function Q(n) {
    var s = y(),
        a = $(function(e) {
            n.set(e)
        })(k(function(e, t) {
            return l({}, e, t)
        }, V)(O(function(e) {
            return e.context && e.context.pause ? b({
                fetching: !1,
                stale: !1
            }) : w([b({
                fetching: !0,
                stale: !1
            }), C(function(t) {
                return l({}, {
                    fetching: !1
                }, t, {
                    stale: !!t.stale
                })
            })(s.executeQuery(e, e.context)), b({
                fetching: !1,
                stale: !1
            })])
        })(D(n))));
    return h(a.unsubscribe), n
}

function R(n) {
    var s = y(),
        a = typeof n.subscribe != "function" ? S(n.query, n.variables) : n;
    return function(e, t) {
        var i = {
            fetching: !0,
            variables: e || a.variables,
            context: t || a.context
        };
        return a.set(i), P(_(1)(s.executeMutation(v(a.query, a.variables || {}), a.context))).then(function(f) {
            var u = l({}, {
                fetching: !1
            }, f);
            return a.set(u), a
        })
    }
}
export {
    R as m, S as o, Q as q, N as s
};