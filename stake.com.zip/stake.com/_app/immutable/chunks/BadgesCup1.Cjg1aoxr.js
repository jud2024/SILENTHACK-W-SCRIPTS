import {
    s as f,
    C as m,
    H as r,
    D as o,
    f as u,
    E as g,
    i as v,
    F as n,
    j as _,
    n as h
} from "./scheduler.DXu26z7T.js";
import {
    S as C,
    i as V
} from "./index.Dz_MmNB3.js";

function d(c) {
    let t, e, a = ` <title>${c[1]||""}</title> <path d="M96 25.48C96 15.2 89.88 6.32 81.08 2.32V0H14.92v2.32C6.12 6.32 0 15.2 0 25.48s6.12 19.16 14.92 23.16v5.92c0 8.2 9.6 13.28 21.48 15.24v9.64c-9.96 1.28-16.88 4.12-16.88 7.44v9.08h57.04v-9.08c0-3.32-6.96-6.2-16.88-7.44V69.8c11.88-1.96 21.48-7.04 21.48-15.24v-5.92c8.8-4 14.92-12.88 14.92-23.16H96Zm-88 0c0-5.64 2.72-10.64 6.92-13.84v27.64C10.76 36.08 8 31.12 8 25.44v.04Zm73.08 13.84V11.64C85.24 14.84 88 19.8 88 25.48s-2.72 10.64-6.92 13.84Z" fill="#F0B90B"></path><path d="M42.998 55.6V27.12l-7.84 7.76-7.92-8.28 17.72-17.32h12.08V55.6h-14.04Z" fill="#554204"></path>`,
        i;
    return {
        c() {
            t = m("svg"), e = new r(!0), this.h()
        },
        l(s) {
            t = o(s, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var l = u(t);
            e = g(l, !0), l.forEach(v), this.h()
        },
        h() {
            e.a = null, n(t, "fill", "none"), n(t, "viewBox", "0 0 97 96"), n(t, "class", i = "svg-icon " + c[2]), n(t, "style", c[0])
        },
        m(s, l) {
            _(s, t, l), e.m(a, t)
        },
        p(s, [l]) {
            l & 2 && a !== (a = ` <title>${s[1]||""}</title> <path d="M96 25.48C96 15.2 89.88 6.32 81.08 2.32V0H14.92v2.32C6.12 6.32 0 15.2 0 25.48s6.12 19.16 14.92 23.16v5.92c0 8.2 9.6 13.28 21.48 15.24v9.64c-9.96 1.28-16.88 4.12-16.88 7.44v9.08h57.04v-9.08c0-3.32-6.96-6.2-16.88-7.44V69.8c11.88-1.96 21.48-7.04 21.48-15.24v-5.92c8.8-4 14.92-12.88 14.92-23.16H96Zm-88 0c0-5.64 2.72-10.64 6.92-13.84v27.64C10.76 36.08 8 31.12 8 25.44v.04Zm73.08 13.84V11.64C85.24 14.84 88 19.8 88 25.48s-2.72 10.64-6.92 13.84Z" fill="#F0B90B"></path><path d="M42.998 55.6V27.12l-7.84 7.76-7.92-8.28 17.72-17.32h12.08V55.6h-14.04Z" fill="#554204"></path>`) && e.p(a), l & 4 && i !== (i = "svg-icon " + s[2]) && n(t, "class", i), l & 1 && n(t, "style", s[0])
        },
        i: h,
        o: h,
        d(s) {
            s && v(t)
        }
    }
}

function B(c, t, e) {
    let {
        style: a = ""
    } = t, {
        alt: i = ""
    } = t, {
        class: s = ""
    } = t;
    return c.$$set = l => {
        "style" in l && e(0, a = l.style), "alt" in l && e(1, i = l.alt), "class" in l && e(2, s = l.class)
    }, [a, i, s]
}
class H extends C {
    constructor(t) {
        super(), V(this, t, B, d, f, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    H as B
};