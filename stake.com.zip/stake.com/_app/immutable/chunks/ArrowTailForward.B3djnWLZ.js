import {
    s as h,
    C as f,
    H as u,
    D as m,
    f as v,
    E as _,
    i as c,
    F as r,
    j as g,
    n as o
} from "./scheduler.DXu26z7T.js";
import {
    S as y,
    i as d
} from "./index.Dz_MmNB3.js";

function w(n) {
    let t, s, a = ` <title>${n[1]||""}</title> <path d="M8 37.486h30.909L28.665 47.73l6.313 6.314L56 33.022 34.978 12l-6.313 6.314 10.244 10.244H8v8.933-.005Z"></path>`,
        i;
    return {
        c() {
            t = f("svg"), s = new u(!0), this.h()
        },
        l(l) {
            t = m(l, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var e = v(t);
            s = _(e, !0), e.forEach(c), this.h()
        },
        h() {
            s.a = null, r(t, "fill", "currentColor"), r(t, "viewBox", "0 0 64 64"), r(t, "class", i = "svg-icon " + n[2]), r(t, "style", n[0])
        },
        m(l, e) {
            g(l, t, e), s.m(a, t)
        },
        p(l, [e]) {
            e & 2 && a !== (a = ` <title>${l[1]||""}</title> <path d="M8 37.486h30.909L28.665 47.73l6.313 6.314L56 33.022 34.978 12l-6.313 6.314 10.244 10.244H8v8.933-.005Z"></path>`) && s.p(a), e & 4 && i !== (i = "svg-icon " + l[2]) && r(t, "class", i), e & 1 && r(t, "style", l[0])
        },
        i: o,
        o,
        d(l) {
            l && c(t)
        }
    }
}

function H(n, t, s) {
    let {
        style: a = ""
    } = t, {
        alt: i = ""
    } = t, {
        class: l = ""
    } = t;
    return n.$$set = e => {
        "style" in e && s(0, a = e.style), "alt" in e && s(1, i = e.alt), "class" in e && s(2, l = e.class)
    }, [a, i, l]
}
class A extends y {
    constructor(t) {
        super(), d(this, t, H, w, h, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    A
};