import {
    s as r,
    C as m,
    H as o,
    D as f,
    f as u,
    E as _,
    i as v,
    F as n,
    j as g,
    n as c
} from "./scheduler.DXu26z7T.js";
import {
    S as y,
    i as Z
} from "./index.Dz_MmNB3.js";

function d(h) {
    let t, s, a = ` <title>${h[1]||""}</title> <path d="M.001 3.549v7.12h7.12v49.786h6.214c.778-3.122 3.556-5.398 6.866-5.398a7.07 7.07 0 0 1 6.856 5.348l.01.048h9.974c.778-3.122 3.556-5.398 6.866-5.398a7.07 7.07 0 0 1 6.856 5.348l.01.048h6.16V10.665h7.066v-7.12L.001 3.549Zm35.546 37.334h-17.76v-5.334h17.76v5.334Zm10.668-14.214H17.789v-5.334h28.426v5.334Z"></path>`,
        i;
    return {
        c() {
            t = m("svg"), s = new o(!0), this.h()
        },
        l(l) {
            t = f(l, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var e = u(t);
            s = _(e, !0), e.forEach(v), this.h()
        },
        h() {
            s.a = null, n(t, "fill", "currentColor"), n(t, "viewBox", "0 0 64 64"), n(t, "class", i = "svg-icon " + h[2]), n(t, "style", h[0])
        },
        m(l, e) {
            g(l, t, e), s.m(a, t)
        },
        p(l, [e]) {
            e & 2 && a !== (a = ` <title>${l[1]||""}</title> <path d="M.001 3.549v7.12h7.12v49.786h6.214c.778-3.122 3.556-5.398 6.866-5.398a7.07 7.07 0 0 1 6.856 5.348l.01.048h9.974c.778-3.122 3.556-5.398 6.866-5.398a7.07 7.07 0 0 1 6.856 5.348l.01.048h6.16V10.665h7.066v-7.12L.001 3.549Zm35.546 37.334h-17.76v-5.334h17.76v5.334Zm10.668-14.214H17.789v-5.334h28.426v5.334Z"></path>`) && s.p(a), e & 4 && i !== (i = "svg-icon " + l[2]) && n(t, "class", i), e & 1 && n(t, "style", l[0])
        },
        i: c,
        o: c,
        d(l) {
            l && v(t)
        }
    }
}

function H(h, t, s) {
    let {
        style: a = ""
    } = t, {
        alt: i = ""
    } = t, {
        class: l = ""
    } = t;
    return h.$$set = e => {
        "style" in e && s(0, a = e.style), "alt" in e && s(1, i = e.alt), "class" in e && s(2, l = e.class)
    }, [a, i, l]
}
class C extends y {
    constructor(t) {
        super(), Z(this, t, H, d, r, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    C as B
};