import {
    _ as o
} from "./index.B4-7gKq3.js";
const f = (e, n) => {
        const t = e - n;
        return Math.abs(t / e * 100)
    },
    c = ({
        blockResults: e,
        balance: n,
        amount: t,
        gamesLeft: a,
        potentialStopLoss: r
    }) => {
        if (e != null && e.stop) return e.message;
        if (a === 1) return "limitReached";
        if (t > n) return "insufficientBalance";
        if (r) return "potentialStopLossReached"
    },
    d = ({
        blocks: e,
        id: n,
        value: t,
        blockDefault: a,
        target: r
    }) => e.some(i => i.id === n) ? e.map(i => {
        const s = i;
        return i.id === n && (s[r].value = t), s
    }) : [...e, { ...a,
        [r]: { ...a[r],
            value: t
        }
    }],
    p = ({
        blocks: e,
        block: n
    }) => e.every(t => t.id !== n.id) ? [...e, n] : e,
    h = e => {
        const n = o.values(e);
        return o.sum(n)
    };
export {
    c as a, p as b, h as c, d, f as g
};