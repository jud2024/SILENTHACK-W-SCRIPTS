import {
    s as f,
    K as l,
    L as d,
    M as u
} from "./scheduler.DXu26z7T.js";
import {
    S as c,
    i as _,
    c as g,
    a as p,
    m as v,
    t as h,
    b as y,
    d as O
} from "./index.Dz_MmNB3.js";
import {
    g as C,
    a as b
} from "./spread.CgU5AtxT.js";
import "./index.ByMdEFI5.js";
import {
    C as A
} from "./ChevronDown.D-lyczpB.js";

function S(t) {
    let n, a;
    const o = [t[3], {
        style: "transform: rotate(" + (t[2] ? t[1] === "standard" || t[1] === "menu-item" ? "0" : "180" : t[1] === "standard" ? "90" : t[1] === "menu-item" ? "270" : "0") + `deg);
   ` + t[0]
    }];
    let i = {};
    for (let e = 0; e < o.length; e += 1) i = l(i, o[e]);
    return n = new A({
        props: i
    }), {
        c() {
            g(n.$$.fragment)
        },
        l(e) {
            p(n.$$.fragment, e)
        },
        m(e, s) {
            v(n, e, s), a = !0
        },
        p(e, [s]) {
            const m = s & 15 ? C(o, [s & 8 && b(e[3]), s & 7 && {
                style: "transform: rotate(" + (e[2] ? e[1] === "standard" || e[1] === "menu-item" ? "0" : "180" : e[1] === "standard" ? "90" : e[1] === "menu-item" ? "270" : "0") + `deg);
   ` + e[0]
            }]) : {};
            n.$set(m)
        },
        i(e) {
            a || (h(n.$$.fragment, e), a = !0)
        },
        o(e) {
            y(n.$$.fragment, e), a = !1
        },
        d(e) {
            O(n, e)
        }
    }
}

function j(t, n, a) {
    const o = ["style", "variant", "isOpen"];
    let i = d(n, o),
        {
            style: e = ""
        } = n,
        {
            variant: s = "standard"
        } = n,
        {
            isOpen: m
        } = n;
    return t.$$set = r => {
        n = l(l({}, n), u(r)), a(3, i = d(n, o)), "style" in r && a(0, e = r.style), "variant" in r && a(1, s = r.variant), "isOpen" in r && a(2, m = r.isOpen)
    }, [e, s, m, i]
}
class M extends c {
    constructor(n) {
        super(), _(this, n, j, S, f, {
            style: 0,
            variant: 1,
            isOpen: 2
        })
    }
}
export {
    M as A
};