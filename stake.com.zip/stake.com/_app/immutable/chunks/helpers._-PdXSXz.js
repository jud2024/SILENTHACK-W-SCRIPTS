import {
    h as y,
    am as m,
    ap as c
} from "./index.B4-7gKq3.js";
import {
    m as u,
    c as O
} from "./utils.92_vUFxq.js";
import {
    c as d
} from "./index.-nwNZ3NJ.js";
import {
    n as h
} from "./index.DGKYLdH2.js";
import "./index.ByMdEFI5.js";
import {
    E as l
} from "./Error.DAkWdr3O.js";
const _ = s => ({
        title: y._("OAuth User Already Registered"),
        body: {
            id: "This email is already registered under the username {username}",
            values: s
        },
        icon: l
    }),
    f = 600,
    g = 600,
    E = ({
        windowName: s = "Connect With OAuth",
        url: t
    }) => {
        const n = screen.width / 2 - g / 2,
            o = screen.height / 2 - f / 2,
            r = `location=0, status=0, width=${g}, height=${f}, top=${o}, left=${n}`;
        return window.open(t, s, r)
    },
    I = async s => {
        const {
            data: t,
            error: n,
            eventDispatcher: o,
            handlers: r
        } = s;
        if (n)
            if (Array.isArray(n)) {
                const a = n[0];
                a != null && a.message && h.open(d({
                    message: a.message
                }))
            } else h.open(d({
                message: n.message
            }));
        const p = t && "oauth" in t ? t.oauth : t == null ? void 0 : t.oneTap;
        let i;
        if (p) {
            const {
                result: e
            } = p;
            return (e == null ? void 0 : e.__typename) === "OauthTfa" && (i = "OauthTfa", m("loginToken", e.loginToken), u.auth.open({
                tab: "login"
            }), o && o("oauth", {
                type: "OauthTfa",
                loginToken: e.loginToken
            })), (e == null ? void 0 : e.__typename) === "UserAuthenticatedSession" && (i = "UserAuthenticatedSession", c.next({
                type: "authenticate",
                subtype: "login",
                userAuthenticatedSession: e
            }), c.next({
                type: "firstUserResponse",
                user: e.session.user
            }), o && o("oauth", {
                type: "UserAuthenticatedSession"
            }), O()), (e == null ? void 0 : e.__typename) === "OauthRegister" && (i = "OauthRegister", m.set("identityId", e.identityId), u.registerOauth.open({
                email: e != null && e.requestEmail ? "requested" : "omit"
            }), o && o("oauth", {
                type: "OauthRegister",
                identityId: e.identityId
            })), (e == null ? void 0 : e.__typename) === "OauthUserExists" && h.open(_({
                username: e.user.name
            })), (e == null ? void 0 : e.__typename) === "OauthRequest" && r.OauthRequest(e), i
        }
    };
export {
    E as a, I as o
};