import {
    am as d,
    A as l,
    an as n
} from "./index.B4-7gKq3.js";
const m = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "mutation",
            name: {
                kind: "Name",
                value: "TrackCampaignHit"
            },
            variableDefinitions: [{
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "code"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "String"
                        }
                    }
                }
            }],
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "trackCampaignHit"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "code"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "code"
                            }
                        }
                    }]
                }]
            }
        }]
    },
    i = d.namespace("affiliate"),
    g = async (e, a) => {
        const t = l(),
            o = i.has("code") ? Date.now() > i.get("code").expiry : !1,
            c = !(k() === e) && !o,
            s = Date.now() + n * 15;
        i.set("code", {
            code: e,
            expiry: s
        }), r(a), c && await t.mutation(m, {
            code: e
        }).toPromise()
    },
    r = async e => {
        if (!e) {
            i.set("clickId", {
                clickId: void 0
            });
            return
        }
        const a = Date.now() + n * 15;
        i.set("clickId", {
            clickId: e,
            expiry: a
        })
    },
    k = () => {
        var e;
        return i.has("code") ? (e = i.get("code")) == null ? void 0 : e.code : void 0
    },
    u = () => {
        var e;
        return i.has("clickId") ? (e = i.get("clickId")) == null ? void 0 : e.clickId : void 0
    };
export {
    u as a, k as g, g as r
};