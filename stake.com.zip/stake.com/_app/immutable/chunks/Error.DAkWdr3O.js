import {
    s as o,
    C as m,
    H as f,
    D as u,
    f as v,
    E as _,
    i as c,
    F as r,
    j as g,
    n as h
} from "./scheduler.DXu26z7T.js";
import {
    S as y,
    i as H
} from "./index.Dz_MmNB3.js";

function Z(n) {
    let t, a, l = ` <title>${n[1]||""}</title> <path d="M32 64c17.672 0 32-14.328 32-32S49.672 0 32 0 0 14.328 0 32s14.328 32 32 32Zm-5.333-51.68h10.666v20.987H26.667V12.32ZM32 39.44a6.134 6.134 0 1 1-6.133 6.133v-.026a6.106 6.106 0 0 1 6.106-6.107h.03H32Z"></path>`,
        i;
    return {
        c() {
            t = m("svg"), a = new f(!0), this.h()
        },
        l(e) {
            t = u(e, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var s = v(t);
            a = _(s, !0), s.forEach(c), this.h()
        },
        h() {
            a.a = null, r(t, "fill", "currentColor"), r(t, "viewBox", "0 0 64 64"), r(t, "class", i = "svg-icon " + n[2]), r(t, "style", n[0])
        },
        m(e, s) {
            g(e, t, s), a.m(l, t)
        },
        p(e, [s]) {
            s & 2 && l !== (l = ` <title>${e[1]||""}</title> <path d="M32 64c17.672 0 32-14.328 32-32S49.672 0 32 0 0 14.328 0 32s14.328 32 32 32Zm-5.333-51.68h10.666v20.987H26.667V12.32ZM32 39.44a6.134 6.134 0 1 1-6.133 6.133v-.026a6.106 6.106 0 0 1 6.106-6.107h.03H32Z"></path>`) && a.p(l), s & 4 && i !== (i = "svg-icon " + e[2]) && r(t, "class", i), s & 1 && r(t, "style", e[0])
        },
        i: h,
        o: h,
        d(e) {
            e && c(t)
        }
    }
}

function d(n, t, a) {
    let {
        style: l = ""
    } = t, {
        alt: i = ""
    } = t, {
        class: e = ""
    } = t;
    return n.$$set = s => {
        "style" in s && a(0, l = s.style), "alt" in s && a(1, i = s.alt), "class" in s && a(2, e = s.class)
    }, [l, i, e]
}
class M extends y {
    constructor(t) {
        super(), H(this, t, d, Z, o, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    M as E
};