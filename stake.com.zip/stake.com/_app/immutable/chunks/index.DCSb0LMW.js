import {
    s as w,
    a as h,
    e as v,
    O as D,
    d as g,
    f as y,
    i as m,
    P as L,
    F as z,
    I as S,
    j as V,
    k as $,
    u as b,
    g as E,
    b as k
} from "./scheduler.DXu26z7T.js";
import {
    S as j,
    i as q,
    t as u,
    b as p,
    c as C,
    a as F,
    m as O,
    d as P
} from "./index.Dz_MmNB3.js";
import {
    E as A
} from "./index.CJLuklPK.js";
const B = o => ({}),
    I = o => ({});

function G(o) {
    let e, s;
    return e = new A({}), {
        c() {
            C(e.$$.fragment)
        },
        l(n) {
            F(e.$$.fragment, n)
        },
        m(n, a) {
            O(e, n, a), s = !0
        },
        i(n) {
            s || (u(e.$$.fragment, n), s = !0)
        },
        o(n) {
            p(e.$$.fragment, n), s = !1
        },
        d(n) {
            P(e, n)
        }
    }
}

function H(o) {
    let e, s, n, a;
    const c = o[2].icon,
        f = h(c, o, o[1], I),
        r = f || G(),
        _ = o[2].default,
        i = h(_, o, o[1], null);
    return {
        c() {
            e = v("div"), s = v("div"), r && r.c(), n = D(), i && i.c(), this.h()
        },
        l(t) {
            e = g(t, "DIV", {
                class: !0
            });
            var l = y(e);
            s = g(l, "DIV", {
                class: !0,
                style: !0
            });
            var d = y(s);
            r && r.l(d), d.forEach(m), n = L(l), i && i.l(l), l.forEach(m), this.h()
        },
        h() {
            z(s, "class", "sports-icon-wrapper svelte-1au42ay"), S(s, "font-size", "var(--text-size-" + o[0] + ")"), z(e, "class", "sports-empty-list svelte-1au42ay")
        },
        m(t, l) {
            V(t, e, l), $(e, s), r && r.m(s, null), $(e, n), i && i.m(e, null), a = !0
        },
        p(t, [l]) {
            f && f.p && (!a || l & 2) && b(f, c, t, t[1], a ? k(c, t[1], l, B) : E(t[1]), I), (!a || l & 1) && S(s, "font-size", "var(--text-size-" + t[0] + ")"), i && i.p && (!a || l & 2) && b(i, _, t, t[1], a ? k(_, t[1], l, null) : E(t[1]), null)
        },
        i(t) {
            a || (u(r, t), u(i, t), a = !0)
        },
        o(t) {
            p(r, t), p(i, t), a = !1
        },
        d(t) {
            t && m(e), r && r.d(t), i && i.d(t)
        }
    }
}

function J(o, e, s) {
    let {
        $$slots: n = {},
        $$scope: a
    } = e, {
        fontSize: c = "8xl"
    } = e;
    return o.$$set = f => {
        "fontSize" in f && s(0, c = f.fontSize), "$$scope" in f && s(1, a = f.$$scope)
    }, [c, a, n]
}
class Q extends j {
    constructor(e) {
        super(), q(this, e, J, H, w, {
            fontSize: 0
        })
    }
}
export {
    Q as S
};