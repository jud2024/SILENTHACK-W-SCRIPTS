import {
    s as u,
    C as f,
    H as v,
    D as h,
    f as m,
    E as _,
    i as c,
    F as r,
    j as d,
    n as o
} from "./scheduler.DXu26z7T.js";
import {
    S as g,
    i as y
} from "./index.Dz_MmNB3.js";

function A(n) {
    let e, a, s = ` <title>${n[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M48.322 30.536A19.63 19.63 0 0 0 51.63 19.63 19.619 19.619 0 0 0 32 0a19.63 19.63 0 1 0 16.322 30.536ZM42.197 43.97a26.63 26.63 0 0 0 8.643-5.78A19.84 19.84 0 0 1 64 56.86V64H0v-7.14a19.84 19.84 0 0 1 13.16-18.67 26.63 26.63 0 0 0 29.037 5.78Z"></path>`,
        i;
    return {
        c() {
            e = f("svg"), a = new v(!0), this.h()
        },
        l(l) {
            e = h(l, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var t = m(e);
            a = _(t, !0), t.forEach(c), this.h()
        },
        h() {
            a.a = null, r(e, "fill", "currentColor"), r(e, "viewBox", "0 0 64 64"), r(e, "class", i = "svg-icon " + n[2]), r(e, "style", n[0])
        },
        m(l, t) {
            d(l, e, t), a.m(s, e)
        },
        p(l, [t]) {
            t & 2 && s !== (s = ` <title>${l[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M48.322 30.536A19.63 19.63 0 0 0 51.63 19.63 19.619 19.619 0 0 0 32 0a19.63 19.63 0 1 0 16.322 30.536ZM42.197 43.97a26.63 26.63 0 0 0 8.643-5.78A19.84 19.84 0 0 1 64 56.86V64H0v-7.14a19.84 19.84 0 0 1 13.16-18.67 26.63 26.63 0 0 0 29.037 5.78Z"></path>`) && a.p(s), t & 4 && i !== (i = "svg-icon " + l[2]) && r(e, "class", i), t & 1 && r(e, "style", l[0])
        },
        i: o,
        o,
        d(l) {
            l && c(e)
        }
    }
}

function H(n, e, a) {
    let {
        style: s = ""
    } = e, {
        alt: i = ""
    } = e, {
        class: l = ""
    } = e;
    return n.$$set = t => {
        "style" in t && a(0, s = t.style), "alt" in t && a(1, i = t.alt), "class" in t && a(2, l = t.class)
    }, [s, i, l]
}
class Z extends g {
    constructor(e) {
        super(), y(this, e, H, A, u, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    Z as A
};