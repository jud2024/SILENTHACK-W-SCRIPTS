import {
    s as S,
    a as V,
    K as g,
    O as q,
    e as E,
    P as y,
    d as I,
    f as N,
    i as _,
    Q as v,
    j as h,
    u as F,
    g as K,
    b as M,
    L as p,
    M as Q,
    R as b,
    F as R
} from "./scheduler.DXu26z7T.js";
import {
    S as z,
    i as A,
    t as m,
    g as O,
    b as d,
    e as P,
    c as D,
    a as B,
    m as k,
    d as C
} from "./index.Dz_MmNB3.js";
import {
    g as G
} from "./spread.CgU5AtxT.js";
import {
    c as L
} from "./index.BljstGtu.js";
import {
    D as H
} from "./DotsLoader.BJx50Plt.js";
import "./index.ByMdEFI5.js";
import "./index.B4-7gKq3.js";
import "./entry.GPJbNZcP.js"; /* empty css                                            */
function j(o) {
    let s, t, f;
    var n = o[1];

    function a(i, l) {
        return {}
    }
    return n && (t = b(n, a())), {
        c() {
            s = E("div"), t && D(t.$$.fragment), this.h()
        },
        l(i) {
            s = I(i, "DIV", {
                class: !0
            });
            var l = N(s);
            t && B(t.$$.fragment, l), l.forEach(_), this.h()
        },
        h() {
            R(s, "class", "inline-flex justify-center items-center absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2")
        },
        m(i, l) {
            h(i, s, l), t && k(t, s, null), f = !0
        },
        p(i, l) {
            if (l & 2 && n !== (n = i[1])) {
                if (t) {
                    O();
                    const c = t;
                    d(c.$$.fragment, 1, 0, () => {
                        C(c, 1)
                    }), P()
                }
                n ? (t = b(n, a()), D(t.$$.fragment), m(t.$$.fragment, 1), k(t, s, null)) : t = null
            }
        },
        i(i) {
            f || (t && m(t.$$.fragment, i), f = !0)
        },
        o(i) {
            t && d(t.$$.fragment, i), f = !1
        },
        d(i) {
            i && _(s), t && C(t)
        }
    }
}

function J(o) {
    let s, t, f, n, a = o[2] && j(o);
    const i = o[5].default,
        l = V(i, o, o[4], null);
    let c = [{
            "data-loader-content": ""
        }, {
            class: f = L("contents", o[2] && "invisible", o[0])
        }, o[3]],
        u = {};
    for (let e = 0; e < c.length; e += 1) u = g(u, c[e]);
    return {
        c() {
            a && a.c(), s = q(), t = E("div"), l && l.c(), this.h()
        },
        l(e) {
            a && a.l(e), s = y(e), t = I(e, "DIV", {
                "data-loader-content": !0,
                class: !0
            });
            var r = N(t);
            l && l.l(r), r.forEach(_), this.h()
        },
        h() {
            v(t, u)
        },
        m(e, r) {
            a && a.m(e, r), h(e, s, r), h(e, t, r), l && l.m(t, null), n = !0
        },
        p(e, [r]) {
            e[2] ? a ? (a.p(e, r), r & 4 && m(a, 1)) : (a = j(e), a.c(), m(a, 1), a.m(s.parentNode, s)) : a && (O(), d(a, 1, 1, () => {
                a = null
            }), P()), l && l.p && (!n || r & 16) && F(l, i, e, e[4], n ? M(i, e[4], r, null) : K(e[4]), null), v(t, u = G(c, [{
                "data-loader-content": ""
            }, (!n || r & 5 && f !== (f = L("contents", e[2] && "invisible", e[0]))) && {
                class: f
            }, r & 8 && e[3]]))
        },
        i(e) {
            n || (m(a), m(l, e), n = !0)
        },
        o(e) {
            d(a), d(l, e), n = !1
        },
        d(e) {
            e && (_(s), _(t)), a && a.d(e), l && l.d(e)
        }
    }
}

function T(o, s, t) {
    const f = ["class", "loader", "loading"];
    let n = p(s, f),
        {
            $$slots: a = {},
            $$scope: i
        } = s,
        {
            class: l = void 0
        } = s,
        {
            loader: c = H
        } = s,
        {
            loading: u = !1
        } = s;
    return o.$$set = e => {
        s = g(g({}, s), Q(e)), t(3, n = p(s, f)), "class" in e && t(0, l = e.class), "loader" in e && t(1, c = e.loader), "loading" in e && t(2, u = e.loading), "$$scope" in e && t(4, i = e.$$scope)
    }, [l, c, u, n, i, a]
}
class te extends z {
    constructor(s) {
        super(), A(this, s, T, J, S, {
            class: 0,
            loader: 1,
            loading: 2
        })
    }
}
export {
    te as C
};