import {
    _ as g,
    i as H,
    an as V
} from "./index.B4-7gKq3.js";
import {
    s as B,
    e as h,
    O as F,
    d as $,
    f as k,
    P as G,
    i as p,
    F as _,
    V as b,
    j as A,
    k as x,
    c as U,
    t as y,
    h as D,
    l as z
} from "./scheduler.DXu26z7T.js";
import {
    S as W,
    i as j,
    c as S,
    a as N,
    m as T,
    t as C,
    b as v,
    d as O
} from "./index.Dz_MmNB3.js";
import {
    T as E
} from "./index.CTIl3dBv.js";
import {
    T as R
} from "./index.rqxo2ccV.js";
import {
    m as M
} from "./SportBetOutcome.GMTGMAV5.js";
import {
    g as P
} from "./fixture.DfNw968C.js";
import {
    _ as q
} from "./_curry2.S8Bff5Bl.js";
const d = 6,
    I = 3,
    f = (a, e, r) => g.range(0, e).reduce((t, m, s) => {
        const u = typeof a == "function" ? a(s) : a;
        return r ? `
        ${t}
        ${u}
    ` : `${t} ${u}`
    }, ""),
    _e = ({
        stacked: a,
        marketsLength: e,
        displayBreadcrumb: r,
        isSearchFixture: t
    }) => {
        if (a) return t ? `
      'team team team team team team team team team team team team'
      'misc misc misc misc misc misc misc misc misc misc misc misc'
      'breadcrumb breadcrumb breadcrumb breadcrumb breadcrumb breadcrumb breadcrumb breadcrumb breadcrumb breadcrumb breadcrumb breadcrumb'
    ` : r ? `
      'misc misc marketCount marketCount marketCount marketCount'
      'fixture fixture fixture fixture fixture fixture'
      'breadcrumb breadcrumb breadcrumb breadcrumb breadcrumb breadcrumb'
      ${f(u=>`
              '${f(`marketName${u}`,d,!1)}'
              '${f(`outcomes${u}`,d,!1)}'
              '${f(`outcomes${u}`,d,!1)}'
            `,e,!0)}
    ` : `
      'misc misc marketCount marketCount marketCount marketCount'
      'fixture fixture fixture fixture fixture fixture'
      ${f(u=>`
              '${f(`marketName${u}`,d,!1)}'
              '${f(`outcomes${u}`,d,!1)}'
              '${f(`outcomes${u}`,d,!1)}'
            `,e,!0)}
    `;
        if (e === 1) return t ? `
      'fixture fixture fixture fixture fixture fixture fixture fixture fixture fixture fixture fixture'
      'misc misc misc misc misc misc misc misc misc misc misc misc'
      'breadcrumb breadcrumb breadcrumb breadcrumb breadcrumb breadcrumb breadcrumb breadcrumb breadcrumb breadcrumb breadcrumb breadcrumb'
    ` : r ? `
      'misc misc line line line line marketName0 marketName0 marketName0 marketName0 line2 line2'
      'teams teams teams fixtureScore fixtureScore outcomes0 outcomes0 outcomes0 outcomes0 outcomes0 outcomes0 marketCount'
      'teams teams teams fixtureScore fixtureScore outcomes0 outcomes0 outcomes0 outcomes0 outcomes0 outcomes0 marketCount'
      'breadcrumb breadcrumb breadcrumb fixtureScore fixtureScore outcomes0 outcomes0 outcomes0 outcomes0 outcomes0 outcomes0 marketCount'
    ` : `
    'misc misc line line line line marketName0 marketName0 marketName0 marketName0 line2 line2'
    'teams teams teams fixtureScore fixtureScore outcomes0 outcomes0 outcomes0 outcomes0 outcomes0 outcomes0 marketCount'
    'teams teams teams fixtureScore fixtureScore outcomes0 outcomes0 outcomes0 outcomes0 outcomes0 outcomes0 marketCount'
  `;
        if (t) return `
    'fixture fixture fixture fixture fixture fixture fixture fixture fixture fixture fixture fixture'
    'misc misc misc misc misc misc misc misc misc misc misc misc'
    'breadcrumb breadcrumb breadcrumb breadcrumb breadcrumb breadcrumb breadcrumb breadcrumb breadcrumb breadcrumb breadcrumb breadcrumb'
  `;
        const m = f(u => `marketName${u} marketName${u} marketName${u}`, e, !1),
            s = f(u => f(`outcomes${u}`, I, !1), e, !1);
        return `
    'misc misc line line line line line ${m} line2'
    'teams teams teams teams fixtureScore fixtureScore fixtureScore ${s} marketCount'
    'teams teams teams teams fixtureScore fixtureScore fixtureScore ${s} marketCount'
    'breadcrumb breadcrumb breadcrumb breadcrumb breadcrumb breadcrumb breadcrumb ${s} marketCount'
  `
    },
    pe = (a, e) => a ? d : Math.max(12, 8 + e * I),
    K = a => {
        const e = a.match(/[+-]?\d+(\.\d+)?/g);
        return e ? e[e.length - 1] : ""
    },
    Y = (a, e) => {
        if (e.length === 0) return a;
        const [r, t] = e;
        if (a === r.name) return r.abbreviation;
        if (a === t.name) return t.abbreviation;
        const m = new RegExp(`${r.name}|${t.name}`, "g"),
            s = a.replace(m, ""),
            u = K(s);
        return u ? `${s[0]} ${u}` : s
    },
    J = (a, e) => {
        if (e.length === 0) return a;
        const [r, t] = e;
        let m = a;
        if (m.includes(r.name)) {
            if (m === r.name) return m;
            m = g.replace(m, new RegExp(r.name, "gi"), (r == null ? void 0 : r.abbreviation) ? ? "")
        }
        if (m.includes(t.name)) {
            if (m === t.name) return m;
            m = g.replace(m, new RegExp(t.name, "gi"), (t == null ? void 0 : t.abbreviation) ? ? "")
        }
        return m
    },
    ge = ({
        isMulti: a,
        stacked: e,
        name: r,
        competitors: t
    }) => a && !e ? Y(r, t) : J(r, t);

function L(a) {
    let e, r;
    return {
        c() {
            e = h("span"), r = y(a[6]), this.h()
        },
        l(t) {
            e = $(t, "SPAN", {
                class: !0
            });
            var m = k(e);
            r = D(m, a[6]), m.forEach(p), this.h()
        },
        h() {
            _(e, "class", "name suspended-name svelte-1yo4ude"), b(e, "suspended-name", !0)
        },
        m(t, m) {
            A(t, e, m), x(e, r)
        },
        p(t, m) {
            m & 64 && z(r, t[6])
        },
        d(t) {
            t && p(e)
        }
    }
}

function Q(a) {
    let e, r;
    return e = new R({
        props: {
            $$slots: {
                default: [L]
            },
            $$scope: {
                ctx: a
            }
        }
    }), {
        c() {
            S(e.$$.fragment)
        },
        l(t) {
            N(e.$$.fragment, t)
        },
        m(t, m) {
            T(e, t, m), r = !0
        },
        p(t, m) {
            const s = {};
            m & 320 && (s.$$scope = {
                dirty: m,
                ctx: t
            }), e.$set(s)
        },
        i(t) {
            r || (C(e.$$.fragment, t), r = !0)
        },
        o(t) {
            v(e.$$.fragment, t), r = !1
        },
        d(t) {
            O(e, t)
        }
    }
}

function X(a) {
    let e, r = a[5]._(M.suspended) + "",
        t;
    return {
        c() {
            e = h("span"), t = y(r), this.h()
        },
        l(m) {
            e = $(m, "SPAN", {
                class: !0
            });
            var s = k(e);
            t = D(s, r), s.forEach(p), this.h()
        },
        h() {
            _(e, "class", "suspended-odds")
        },
        m(m, s) {
            A(m, e, s), x(e, t)
        },
        p(m, s) {
            s & 32 && r !== (r = m[5]._(M.suspended) + "") && z(t, r)
        },
        d(m) {
            m && p(e)
        }
    }
}

function Z(a) {
    let e, r;
    return e = new R({
        props: {
            $$slots: {
                default: [X]
            },
            $$scope: {
                ctx: a
            }
        }
    }), {
        c() {
            S(e.$$.fragment)
        },
        l(t) {
            N(e.$$.fragment, t)
        },
        m(t, m) {
            T(e, t, m), r = !0
        },
        p(t, m) {
            const s = {};
            m & 288 && (s.$$scope = {
                dirty: m,
                ctx: t
            }), e.$set(s)
        },
        i(t) {
            r || (C(e.$$.fragment, t), r = !0)
        },
        o(t) {
            v(e.$$.fragment, t), r = !1
        },
        d(t) {
            O(e, t)
        }
    }
}

function ee(a) {
    let e, r, t, m, s, u, n;
    return t = new E({
        props: {
            maxWidth: "100%",
            $$slots: {
                default: [Q]
            },
            $$scope: {
                ctx: a
            }
        }
    }), s = new E({
        props: {
            maxWidth: "100%",
            $$slots: {
                default: [Z]
            },
            $$scope: {
                ctx: a
            }
        }
    }), {
        c() {
            e = h("button"), r = h("div"), S(t.$$.fragment), m = F(), S(s.$$.fragment), this.h()
        },
        l(c) {
            e = $(c, "BUTTON", {
                "aria-label": !0,
                "data-test": !0,
                class: !0
            });
            var i = k(e);
            r = $(i, "DIV", {
                class: !0
            });
            var l = k(r);
            N(t.$$.fragment, l), m = G(l), N(s.$$.fragment, l), l.forEach(p), i.forEach(p), this.h()
        },
        h() {
            var c;
            _(r, "class", "outcome-content svelte-1yo4ude"), b(r, "horizontal", a[1]), b(r, "center", a[3] || a[4]), _(e, "aria-label", u = a[0] === "suspended" ? a[0] : (c = a[0]) == null ? void 0 : c.name), _(e, "data-test", "fixture-outcome active:scale-[0.98]"), _(e, "class", "outcome svelte-1yo4ude"), e.disabled = !0, b(e, "isMulti", a[2])
        },
        m(c, i) {
            A(c, e, i), x(e, r), T(t, r, null), x(r, m), T(s, r, null), n = !0
        },
        p(c, [i]) {
            var w;
            const l = {};
            i & 320 && (l.$$scope = {
                dirty: i,
                ctx: c
            }), t.$set(l);
            const o = {};
            i & 288 && (o.$$scope = {
                dirty: i,
                ctx: c
            }), s.$set(o), (!n || i & 2) && b(r, "horizontal", c[1]), (!n || i & 24) && b(r, "center", c[3] || c[4]), (!n || i & 1 && u !== (u = c[0] === "suspended" ? c[0] : (w = c[0]) == null ? void 0 : w.name)) && _(e, "aria-label", u), (!n || i & 4) && b(e, "isMulti", c[2])
        },
        i(c) {
            n || (C(t.$$.fragment, c), C(s.$$.fragment, c), n = !0)
        },
        o(c) {
            v(t.$$.fragment, c), v(s.$$.fragment, c), n = !1
        },
        d(c) {
            c && p(e), O(t), O(s)
        }
    }
}

function te(a, e, r) {
    let t, m;
    U(a, H, o => r(5, m = o));
    let {
        outcome: s
    } = e, {
        horizontal: u = !1
    } = e, {
        name: n
    } = e, {
        isMulti: c = !1
    } = e, {
        hideOdds: i = !1
    } = e, {
        customPlayerProps: l = !1
    } = e;
    return a.$$set = o => {
        "outcome" in o && r(0, s = o.outcome), "horizontal" in o && r(1, u = o.horizontal), "name" in o && r(7, n = o.name), "isMulti" in o && r(2, c = o.isMulti), "hideOdds" in o && r(3, i = o.hideOdds), "customPlayerProps" in o && r(4, l = o.customPlayerProps)
    }, a.$$.update = () => {
        a.$$.dirty & 161 && r(6, t = n && n in M ? m._(M[n]) : n ? ? (typeof s == "object" ? s.name : ""))
    }, [s, u, c, i, l, m, t, n]
}
class he extends W {
    constructor(e) {
        super(), j(this, e, te, ee, B, {
            outcome: 0,
            horizontal: 1,
            name: 7,
            isMulti: 2,
            hideOdds: 3,
            customPlayerProps: 4
        })
    }
}
var re = q(function(a, e) {
    for (var r = [], t = 0, m = e.length; t < m;) {
        for (var s = t + 1; s < m && a(e[s - 1], e[s]);) s += 1;
        r.push(e.slice(t, s)), t = s
    }
    return r
});
const ae = (a, e) => {
    if (a && e) return Math.floor((new Date(e).setHours(0, 0, 0, 0) - new Date(a).setHours(0, 0, 0, 0)) / V)
};

function me(a) {
    return re((e, r) => {
        const {
            startTime: t
        } = P(e.data), {
            startTime: m
        } = P(r.data);
        return ae(t, m) === 0
    }, a)
}
const $e = a => {
        const e = g.sortBy(a, t => {
            const {
                startTime: m
            } = P(t.data);
            return m ? new Date(m).getTime() : 0
        });
        return me(e).reduce((t, m) => [...t, {
            fixture: m[0],
            __element: "GroupTime"
        }, ...m.map(s => ({
            fixture: s,
            __element: "Fixture"
        }))], [])
    },
    se = ["14", "player", "2", "23", "28", "3", "36", "40", "71", "77", "27", "34", "69", "45", "99", "37", "31"];

function ue(a) {
    if (se.includes(a.extId)) return a;
    const e = g.groupBy(a.markets, t => t.name);
    return g.values(e).map(t => ({ ...a,
        markets: t
    }))
}

function ke(a) {
    const e = a.map(r => ue(r));
    return g.flatten(e)
}
export {
    he as P, pe as a, ge as b, K as c, $e as d, _e as g, ke as s
};