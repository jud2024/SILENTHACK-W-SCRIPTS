import {
    h as e
} from "./index.B4-7gKq3.js";
const t = {
    stop: e._("Stop"),
    skipToContent: e._("Skip to content"),
    recentGames: e._("Continue playing"),
    trendingGames: e._("Trending Games"),
    trendingSports: e._("Trending Sports"),
    consoleWarning: o => ({
        id: "This is a browser feature intended for developers. If someone told you to copy and paste something here to enable a {site} feature or 'hack' someone's account, it is a scam and will give them access to your {site} account.",
        values: {
            site: o
        }
    })
};
export {
    t as m
};