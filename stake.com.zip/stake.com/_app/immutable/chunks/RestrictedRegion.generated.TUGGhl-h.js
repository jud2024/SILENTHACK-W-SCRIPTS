const e = {
    kind: "Document",
    definitions: [{
        kind: "OperationDefinition",
        operation: "query",
        name: {
            kind: "Name",
            value: "RestrictedRegion"
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "country"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "state"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "isBlocked"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "isDiscontinuedBlocked"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "isSoftBlocked"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "info"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "bannedUSStates"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "name"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "value"
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }]
};
export {
    e as R
};