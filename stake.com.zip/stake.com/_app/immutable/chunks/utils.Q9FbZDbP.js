import {
    M as i,
    F as t
} from "./index.B4-7gKq3.js";

function C(n) {
    const e = [...n].sort((r, o) => i({
            currency: r
        }, {
            currency: o
        })),
        s = e.filter(r => r in t),
        c = e.filter(r => !(r in t));
    return [...s, ...c]
}
export {
    C as s
};