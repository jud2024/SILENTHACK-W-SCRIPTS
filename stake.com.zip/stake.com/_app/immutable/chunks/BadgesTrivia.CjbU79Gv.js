import {
    s as r,
    C as o,
    H as m,
    D as u,
    f as g,
    E as v,
    i as f,
    F as h,
    j as _,
    n as c
} from "./scheduler.DXu26z7T.js";
import {
    S as d,
    i as y
} from "./index.Dz_MmNB3.js";

function F(n) {
    let l, e, s = ` <title>${n[1]||""}</title> <path d="M24.766 15.437a40.004 40.004 0 0 1 62.808 26.735l-25.33 3.733a14.403 14.403 0 0 0-22.61-9.625L24.766 15.437Z" fill="#FF5674"></path><path d="M29.5 83.472a40.004 40.004 0 0 1-4.63-68.104l14.806 20.887a14.401 14.401 0 0 0 1.667 24.518l-11.842 22.7Z" fill="#FE9D00"></path><path d="M87.522 41.842a40.003 40.003 0 0 1-58.696 41.275l12.268-22.472a14.402 14.402 0 0 0 21.13-14.86l25.298-3.943Z" fill="#00B801"></path>`,
        i;
    return {
        c() {
            l = o("svg"), e = new m(!0), this.h()
        },
        l(t) {
            l = u(t, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var a = g(l);
            e = v(a, !0), a.forEach(f), this.h()
        },
        h() {
            e.a = null, h(l, "fill", "none"), h(l, "viewBox", "0 0 96 96"), h(l, "class", i = "svg-icon " + n[2]), h(l, "style", n[0])
        },
        m(t, a) {
            _(t, l, a), e.m(s, l)
        },
        p(t, [a]) {
            a & 2 && s !== (s = ` <title>${t[1]||""}</title> <path d="M24.766 15.437a40.004 40.004 0 0 1 62.808 26.735l-25.33 3.733a14.403 14.403 0 0 0-22.61-9.625L24.766 15.437Z" fill="#FF5674"></path><path d="M29.5 83.472a40.004 40.004 0 0 1-4.63-68.104l14.806 20.887a14.401 14.401 0 0 0 1.667 24.518l-11.842 22.7Z" fill="#FE9D00"></path><path d="M87.522 41.842a40.003 40.003 0 0 1-58.696 41.275l12.268-22.472a14.402 14.402 0 0 0 21.13-14.86l25.298-3.943Z" fill="#00B801"></path>`) && e.p(s), a & 4 && i !== (i = "svg-icon " + t[2]) && h(l, "class", i), a & 1 && h(l, "style", t[0])
        },
        i: c,
        o: c,
        d(t) {
            t && f(l)
        }
    }
}

function p(n, l, e) {
    let {
        style: s = ""
    } = l, {
        alt: i = ""
    } = l, {
        class: t = ""
    } = l;
    return n.$$set = a => {
        "style" in a && e(0, s = a.style), "alt" in a && e(1, i = a.alt), "class" in a && e(2, t = a.class)
    }, [s, i, t]
}
class Z extends d {
    constructor(l) {
        super(), y(this, l, p, F, r, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    Z as B
};