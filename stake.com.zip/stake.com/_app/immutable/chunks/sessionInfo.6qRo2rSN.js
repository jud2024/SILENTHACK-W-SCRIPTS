import {
    B as e
} from "./index.B4-7gKq3.js";
const a = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "mutation",
            name: {
                kind: "Name",
                value: "TerminateSession"
            },
            variableDefinitions: [{
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "sessionId"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "String"
                        }
                    }
                }
            }],
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "terminateSession"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "sessionId"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "sessionId"
                            }
                        }
                    }],
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "active"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }]
                    }
                }]
            }
        }]
    },
    i = "session_info",
    o = e(i, void 0);
export {
    a as T, o as s
};