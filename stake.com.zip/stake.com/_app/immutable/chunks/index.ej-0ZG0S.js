const s = "stake",
    a = "stake";
export {
    s as V, a
};