import {
    p as r,
    n as t
} from "./index.B4-7gKq3.js";
import {
    d as e
} from "./index.C2-CG2CN.js";
const s = e([r, t], ([o, a]) => a != null && a.to ? { ...o,
    ...a.to
} : o);
export {
    s as m
};