import {
    w as o
} from "./index.C2-CG2CN.js";
const e = o({
    activeDepositBonus: void 0
});
export {
    e as b
};