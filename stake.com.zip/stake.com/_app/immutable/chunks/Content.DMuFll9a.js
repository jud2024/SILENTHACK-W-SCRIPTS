import {
    s as f,
    a as c,
    e as u,
    d as _,
    f as p,
    i as o,
    F as m,
    V as r,
    j as d,
    u as g,
    g as h,
    b as S
} from "./scheduler.DXu26z7T.js";
import {
    S as v,
    i as b,
    t as C,
    b as V
} from "./index.Dz_MmNB3.js";

function j(i) {
    let e, n;
    const l = i[2].default,
        s = c(l, i, i[1], null);
    return {
        c() {
            e = u("div"), s && s.c(), this.h()
        },
        l(t) {
            e = _(t, "DIV", {
                class: !0
            });
            var a = p(e);
            s && s.l(a), a.forEach(o), this.h()
        },
        h() {
            m(e, "class", "content svelte-ortsob"), r(e, "top-spacing", i[0])
        },
        m(t, a) {
            d(t, e, a), s && s.m(e, null), n = !0
        },
        p(t, [a]) {
            s && s.p && (!n || a & 2) && g(s, l, t, t[1], n ? S(l, t[1], a, null) : h(t[1]), null), (!n || a & 1) && r(e, "top-spacing", t[0])
        },
        i(t) {
            n || (C(s, t), n = !0)
        },
        o(t) {
            V(s, t), n = !1
        },
        d(t) {
            t && o(e), s && s.d(t)
        }
    }
}

function q(i, e, n) {
    let {
        $$slots: l = {},
        $$scope: s
    } = e, {
        topSpacing: t = !1
    } = e;
    return i.$$set = a => {
        "topSpacing" in a && n(0, t = a.topSpacing), "$$scope" in a && n(1, s = a.$$scope)
    }, [t, s, l]
}
class F extends v {
    constructor(e) {
        super(), b(this, e, q, j, f, {
            topSpacing: 0
        })
    }
}
export {
    F as C
};