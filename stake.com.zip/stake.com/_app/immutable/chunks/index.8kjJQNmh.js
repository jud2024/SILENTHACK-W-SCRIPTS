import {
    h as o
} from "./index.B4-7gKq3.js";
import "./index.ByMdEFI5.js";
import {
    m as t
} from "./utils.92_vUFxq.js";
import {
    W as i
} from "./Wallet.B4hgSvlS.js";
const e = () => ({
    title: o._("Reload Activated"),
    icon: i,
    sound: "money",
    click: () => t.vip.to({
        tab: "reload"
    })
});
export {
    e as c
};