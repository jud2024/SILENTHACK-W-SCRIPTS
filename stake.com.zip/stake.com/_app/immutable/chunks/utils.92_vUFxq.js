const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["_app/immutable/chunks/index.DeKgMl2t.js", "_app/immutable/chunks/scheduler.DXu26z7T.js", "_app/immutable/chunks/index.Dz_MmNB3.js", "_app/immutable/chunks/DepositBonus.BcTJwfHW.js", "_app/immutable/chunks/contentOrLoader.Ol9dNjON.js", "_app/immutable/chunks/spread.CgU5AtxT.js", "_app/immutable/chunks/index.BljstGtu.js", "_app/immutable/chunks/bundle-mjs.BQkiJtvj.js", "_app/immutable/chunks/DotsLoader.BJx50Plt.js", "_app/immutable/assets/index.CokKH7f8.css", "_app/immutable/chunks/index.ByMdEFI5.js", "_app/immutable/chunks/index.B4-7gKq3.js", "_app/immutable/chunks/index.B81orGJm.js", "_app/immutable/chunks/entry.GPJbNZcP.js", "_app/immutable/chunks/index.C2-CG2CN.js", "_app/immutable/chunks/control.CYgJF_JY.js", "_app/immutable/chunks/index.B3dW9TVs.js", "_app/immutable/chunks/index.C0ktTqgN.js", "_app/immutable/assets/index.DMDg88t4.css", "_app/immutable/chunks/index.CAbJJJ2j.js", "_app/immutable/chunks/index.Na6KaqFL.js", "_app/immutable/chunks/shared.G3i0PjK-.js", "_app/immutable/chunks/index.D7nbRHfU.js", "_app/immutable/assets/index.BdirPLLy.css", "_app/immutable/chunks/index.CYsK4uyl.js", "_app/immutable/chunks/resizeObserver.A9wvMie0.js", "_app/immutable/chunks/index.D1aiuvC7.js", "_app/immutable/chunks/variables.CIGccMR5.js", "_app/immutable/chunks/popper.Dvb6l-Oe.js", "_app/immutable/assets/index.DNFzbYhI.css", "_app/immutable/chunks/fiatNumberFormat.CcHMsn0U.js", "_app/immutable/assets/index.Bnc4pGth.css", "_app/immutable/chunks/index.DChG_RHX.js", "_app/immutable/assets/index.Cd8tiyDO.css", "_app/immutable/chunks/index.npO8CbVj.js", "_app/immutable/chunks/index.CY6-K88d.js", "_app/immutable/chunks/index.1CTKaDY2.js", "_app/immutable/chunks/sessionInfo.6qRo2rSN.js", "_app/immutable/chunks/Error.DAkWdr3O.js", "_app/immutable/chunks/Info.D3JB_c9O.js", "_app/immutable/assets/index.felXNNtU.css", "_app/immutable/chunks/index.-nwNZ3NJ.js", "_app/immutable/chunks/index.DGKYLdH2.js", "_app/immutable/chunks/index.Cpg-fJ3N.js", "_app/immutable/chunks/index.DFo17Q3m.js", "_app/immutable/chunks/Check.DB8bZaWQ.js", "_app/immutable/chunks/index.BVzdEbT-.js", "_app/immutable/chunks/helpers.CobRd3cj.js", "_app/immutable/chunks/index.lhCIiKC2.js", "_app/immutable/chunks/index.BxooaYHE.js", "_app/immutable/chunks/index.CgjaLSob.js", "_app/immutable/chunks/howler.D2eOmZSY.js", "_app/immutable/chunks/constants.DX75DoF3.js", "_app/immutable/chunks/makeFetchStore.Bw6N3EDt.js", "_app/immutable/chunks/utils.Csgj0yys.js", "_app/immutable/chunks/messages.BhHwkfmF.js", "_app/immutable/chunks/urql-svelte.Jmuk7rkA.js", "_app/immutable/chunks/each.DvgCmocI.js", "_app/immutable/chunks/externalLink.D-xTc-p4.js", "_app/immutable/chunks/index.DJurAkTj.js", "_app/immutable/chunks/ctx.CWJzPttI.js", "_app/immutable/chunks/button.BwmFDw8u.js", "_app/immutable/assets/DepositBonus.DJWZvnWj.css", "_app/immutable/chunks/Content.DMuFll9a.js", "_app/immutable/assets/Content.gLfgoKvq.css", "_app/immutable/chunks/index.IduFdWsZ.js", "_app/immutable/chunks/index.vP7oUaYA.js", "_app/immutable/chunks/await_block.D0Ps1QAT.js", "_app/immutable/chunks/object.KBCZ3_4R.js", "_app/immutable/chunks/index.BFHGe0pG.js", "_app/immutable/assets/index.CbvdedHS.css", "_app/immutable/chunks/utils.BavHI5oJ.js", "_app/immutable/chunks/DateInputField.CCKGKrw8.js", "_app/immutable/chunks/index.Dx3GbCCc.js", "_app/immutable/chunks/index.BL_Dq_5k.js", "_app/immutable/assets/index.xmF2RXh7.css", "_app/immutable/chunks/index.CUJEOnPE.js", "_app/immutable/assets/index.BSQFDegy.css", "_app/immutable/chunks/context.Bn3Uf8lc.js", "_app/immutable/chunks/ViewOn.CwMunkhd.js", "_app/immutable/assets/index.C6MhagHP.css", "_app/immutable/chunks/index.BvEEXkHb.js", "_app/immutable/chunks/ChevronDown.D-lyczpB.js", "_app/immutable/assets/index.bkZiabwo.css", "_app/immutable/assets/DateInputField.BJgNS0ol.css", "_app/immutable/chunks/InputField.BIUMvU2x.js", "_app/immutable/chunks/utils.CiRndAdN.js", "_app/immutable/chunks/messages.Cz2watLL.js", "_app/immutable/chunks/PhoneNumberField.1hbtzD2u.js", "_app/immutable/chunks/SelectField.DjM_dQdl.js", "_app/immutable/chunks/index.BCCu0f9D.js", "_app/immutable/chunks/Submit.Bay6TRFQ.js", "_app/immutable/chunks/iovation.ERRqkybm.js", "_app/immutable/chunks/RegisterOauth.Bnq8aeRu.js", "_app/immutable/chunks/constants.CW0Xv01T.js", "_app/immutable/chunks/RegisterOauth.svelte_svelte_type_style_lang.Vbt2Jyfe.js", "_app/immutable/assets/RegisterOauth.0Eaenvun.css", "_app/immutable/chunks/index.ziKoCW02.js", "_app/immutable/chunks/Rewards.B7X_Gvty.js", "_app/immutable/chunks/TableGames.DYIiz1a8.js", "_app/immutable/chunks/Trophy4.CNL_sHmf.js", "_app/immutable/chunks/LiveDealers.BoasVGZc.js", "_app/immutable/chunks/SocialTwitchColor.B_tbjTVe.js", "_app/immutable/chunks/Fire.BfGK7z2X.js", "_app/immutable/chunks/helpers._-PdXSXz.js", "_app/immutable/chunks/messages.vRN_aVPy.js", "_app/immutable/chunks/index.0hsNzg8n.js", "_app/immutable/chunks/index.A33jTkiJ.js", "_app/immutable/chunks/ArrowTailBackward.Dg3YmG2n.js", "_app/immutable/assets/index.qnL1AeOy.css", "_app/immutable/chunks/index.Nhx66bSE.js", "_app/immutable/chunks/GetFeatureFlags.generated.CL24m5OL.js", "_app/immutable/chunks/index.DvfdZexJ.js", "_app/immutable/chunks/RestrictedRegion.generated.TUGGhl-h.js", "_app/immutable/chunks/index.CVJ30NdW.js", "_app/immutable/chunks/index.Cakithnr.js", "_app/immutable/assets/index.BFVN46Uo.css", "_app/immutable/assets/index.CltSCZKY.css", "_app/immutable/chunks/AcceptTermsOfService.generated.40ufXiYj.js", "_app/immutable/chunks/TermsOfService.generated.BtlDA91J.js", "_app/immutable/chunks/CheckboxField.CJZ8sNwQ.js", "_app/immutable/chunks/Terms.BWP7BXLj.js", "_app/immutable/chunks/index.QCc5oEI0.js", "_app/immutable/chunks/Popout.fuVBZN-2.js", "_app/immutable/chunks/index.oTMdB5Eh.js", "_app/immutable/assets/index.BUKkGvzh.css", "_app/immutable/chunks/context.UnLgwODO.js", "_app/immutable/chunks/index.BRT09uIB.js", "_app/immutable/chunks/context.BYnTbg5S.js", "_app/immutable/chunks/fixture.DfNw968C.js", "_app/immutable/chunks/ArrowTailForward.B3djnWLZ.js", "_app/immutable/chunks/index.Cn-rinD1.js", "_app/immutable/chunks/FavouriteFilled.DMUm0W9G.js", "_app/immutable/chunks/SportsBasketball.D8a7WuBk.js", "_app/immutable/chunks/SportsHorseRacing.B5gmVLgd.js", "_app/immutable/chunks/SportsArchery.xCgY6FbW.js", "_app/immutable/chunks/group.DFY3aPRQ.js", "_app/immutable/chunks/index.CTIl3dBv.js", "_app/immutable/chunks/index.rqxo2ccV.js", "_app/immutable/assets/index.BxdntPdZ.css", "_app/immutable/chunks/SportBetOutcome.GMTGMAV5.js", "_app/immutable/chunks/index.A2FRVEtT.js", "_app/immutable/chunks/Wallet.B4hgSvlS.js", "_app/immutable/chunks/interpreter.CJhK2JTN.js", "_app/immutable/assets/index.C3SClUl_.css", "_app/immutable/chunks/clickTransform.BPJZMoSk.js", "_app/immutable/assets/SportBetOutcome.DKoZWfkK.css", "_app/immutable/chunks/_curry2.S8Bff5Bl.js", "_app/immutable/assets/group.b8aJ225x.css", "_app/immutable/chunks/index.BBjbzRMH.js", "_app/immutable/chunks/index.DUHuGv4r.js", "_app/immutable/chunks/index.Drh4nwD9.js", "_app/immutable/chunks/index.DCTjP2Ha.js", "_app/immutable/chunks/index.DlOe5U6J.js", "_app/immutable/assets/index.D_dkgKnC.css", "_app/immutable/chunks/utils.PGvbthip.js", "_app/immutable/assets/utils.BiQ70sTp.css", "_app/immutable/chunks/index.CUgLGuIE.js", "_app/immutable/chunks/index.u8ZD9oiA.js", "_app/immutable/chunks/context.C4qMQqMz.js", "_app/immutable/assets/index.DDdK-dz-.css", "_app/immutable/chunks/Graph.5H4YYOLp.js", "_app/immutable/chunks/Live.DUBCovZv.js", "_app/immutable/assets/index.DnWe99vP.css", "_app/immutable/chunks/index.B1KDSkU5.js", "_app/immutable/assets/index.Dvb3PVlj.css", "_app/immutable/chunks/Lock.CRzw2MJX.js", "_app/immutable/assets/index.By8U_mqu.css", "_app/immutable/chunks/index.BdzuYyUh.js", "_app/immutable/assets/index.8H5V7w30.css", "_app/immutable/chunks/index.B4mPmVgF.js", "_app/immutable/chunks/index.DmsScLg1.js", "_app/immutable/chunks/index.Cp95w4vW.js", "_app/immutable/assets/index.P42si0Xl.css", "_app/immutable/chunks/AccordionHeader.MRxqKRwW.js", "_app/immutable/assets/AccordionHeader.CnNLgGdH.css", "_app/immutable/chunks/index.DCSb0LMW.js", "_app/immutable/chunks/index.CJLuklPK.js", "_app/immutable/chunks/index.Bhhzp5qA.js", "_app/immutable/assets/index.DmlheggN.css", "_app/immutable/assets/index.DxKxNrPr.css", "_app/immutable/assets/index.CmrxalE1.css", "_app/immutable/assets/index.DPVDkUhm.css", "_app/immutable/chunks/blockTouchBodyScroll.cXxkc2Ey.js", "_app/immutable/assets/Terms.BtijQPZV.css", "_app/immutable/assets/AcceptTermsOfService.DIEi3E4l.css", "_app/immutable/chunks/affiliate.DYm3buUc.js", "_app/immutable/chunks/index.esm.Dhw5Qc84.js", "_app/immutable/chunks/index.Bz47LUZP.js", "_app/immutable/chunks/messages.TqC-bv_J.js", "_app/immutable/chunks/index.B43rDWIe.js", "_app/immutable/chunks/tslib.es6.CYhxggkG.js", "_app/immutable/chunks/dateTimestampProvider.DBRuHdww.js", "_app/immutable/chunks/innerFrom.BRHulYBS.js", "_app/immutable/chunks/interval.BgEOk4xr.js", "_app/immutable/chunks/async.DWikFYac.js", "_app/immutable/chunks/switchMap.DLhHjf4W.js", "_app/immutable/chunks/tap.C8oT6H3h.js", "_app/immutable/chunks/index.Ci34scWy.js", "_app/immutable/chunks/roles.CMi1bAOW.js", "_app/immutable/chunks/index.CgcfDf3j.js", "_app/immutable/chunks/helpers.CAviLe46.js", "_app/immutable/chunks/Lazy.5c2fu-AO.js", "_app/immutable/assets/index.BBKk0HAP.css", "_app/immutable/assets/index.BsfGSK_s.css", "_app/immutable/chunks/index.BRTKpJCf.js", "_app/immutable/chunks/index.SN9TA6nA.js", "_app/immutable/chunks/index.CIhg29qo.js", "_app/immutable/chunks/query-string.27nWWSq4.js", "_app/immutable/chunks/UserFromName.BJUA46NY.js", "_app/immutable/chunks/index.B1J2NdFH.js", "_app/immutable/chunks/index.DTS6WF86.js", "_app/immutable/chunks/VIPSilver.CnTTpkRN.js", "_app/immutable/chunks/vip.rsPZMLqI.js", "_app/immutable/assets/index.FcFDsYzm.css", "_app/immutable/chunks/GhostModeOn.cYfUwU7X.js", "_app/immutable/assets/index.u00usa4u.css", "_app/immutable/chunks/index.C-w7NpLP.js", "_app/immutable/chunks/index.CP_OaIgJ.js", "_app/immutable/assets/index.B3vG_aBm.css", "_app/immutable/assets/index.B2eXO9HW.css", "_app/immutable/chunks/index.CIBDG73T.js", "_app/immutable/chunks/index.Cq_eNUyU.js", "_app/immutable/chunks/index.BzMmusTo.js", "_app/immutable/chunks/index.CsashSqM.js", "_app/immutable/assets/index.CC2klXHg.css", "_app/immutable/chunks/index.CuBfB3P7.js", "_app/immutable/chunks/Cross.DFKMr_Np.js", "_app/immutable/chunks/Button.MJX-BToZ.js", "_app/immutable/chunks/index.c5a505nz.js", "_app/immutable/chunks/messages.CGOEYt_d.js", "_app/immutable/chunks/globals.D0QH3NT1.js", "_app/immutable/assets/messages.CfrqXHds.css", "_app/immutable/chunks/ChevronUp.BAkg4bKv.js", "_app/immutable/assets/index.CQBIOVj_.css", "_app/immutable/chunks/constants.JccqSNFq.js", "_app/immutable/chunks/index.CXFXB5GE.js", "_app/immutable/chunks/generatePath.DsXei5FM.js", "_app/immutable/chunks/paths.RTtAVJV7.js", "_app/immutable/chunks/preload-helper.BqjOJQfC.js", "_app/immutable/chunks/calculateSwishCustomBet.generated.BAiz6z8n.js", "_app/immutable/chunks/CustomBetOdds.generated.CNVEKRhY.js", "_app/immutable/assets/index.CNBwtUN2.css", "_app/immutable/chunks/index.Dc4VZCtB.js", "_app/immutable/chunks/index.B_DYqMGF.js", "_app/immutable/chunks/index.CUGjhjk5.js", "_app/immutable/chunks/index.B4v2Pvbr.js", "_app/immutable/chunks/Account.Dy1oZprP.js", "_app/immutable/chunks/AddIgnoredUser.generated.C970r58h.js", "_app/immutable/chunks/Unfriend.Ce_l8c8_.js", "_app/immutable/chunks/DeleteIgnoredUser.generated.C_zmziUg.js", "_app/immutable/chunks/stores.C1s9-Gyh.js", "_app/immutable/chunks/helpers.mdRln9WE.js", "_app/immutable/chunks/Settings.B9OSzQXJ.js", "_app/immutable/chunks/index.DemeWyRw.js", "_app/immutable/assets/index.CcO8OMuM.css", "_app/immutable/chunks/index.CNv9FBOb.js", "_app/immutable/assets/index.B2-kADF2.css", "_app/immutable/chunks/index.DUGLC8Kl.js", "_app/immutable/chunks/CrashGame.BFlyVme_.js", "_app/immutable/chunks/index.BavbWpNs.js", "_app/immutable/assets/index.BeAU0Ht7.css", "_app/immutable/chunks/index.Db24s5zc.js", "_app/immutable/chunks/setup.D-_1lgCN.js", "_app/immutable/chunks/helpers.BdroHKF4.js", "_app/immutable/chunks/store.DsAt9qNE.js", "_app/immutable/assets/index.i96WhWp3.css", "_app/immutable/chunks/general.CID39R0-.js", "_app/immutable/chunks/messages.DGEB5TOw.js", "_app/immutable/assets/CrashGame.CHvd5TYi.css", "_app/immutable/chunks/index.CEdYI-Gt.js", "_app/immutable/chunks/index.browser.BEMxqJOT.js", "_app/immutable/chunks/CreateCampaign.generated.DriYNyG-.js", "_app/immutable/chunks/index.B1yZYdj5.js", "_app/immutable/chunks/index.CyZ8P5ib.js", "_app/immutable/chunks/index.BAVnyi_8.js", "_app/immutable/chunks/index.COpyS6pA.js", "_app/immutable/chunks/DropdownContent.DaecMGoH.js", "_app/immutable/assets/DropdownContent.DlkHq7L1.css", "_app/immutable/chunks/DropdownArrow.C_ADoLvp.js", "_app/immutable/chunks/index.DO-ZTgvx.js", "_app/immutable/chunks/clickOutside.B3QPj_Ml.js", "_app/immutable/chunks/Search.Dsf-x3-k.js", "_app/immutable/chunks/utils.Q9FbZDbP.js", "_app/immutable/assets/index.B4ZLc7qG.css", "_app/immutable/chunks/stores.C2Y_-UWr.js", "_app/immutable/chunks/index.ej-0ZG0S.js", "_app/immutable/assets/index.CIIXXJyc.css", "_app/immutable/chunks/KuratorGameQuery.generated.D_RF3oUR.js", "_app/immutable/chunks/Slide.B1qMR9s0.js", "_app/immutable/chunks/index.D-7TT9-T.js", "_app/immutable/chunks/index.Bk7dAAE4.js", "_app/immutable/chunks/MiscStop.pqiEj6eq.js", "_app/immutable/chunks/List.DAtnvj0J.js", "_app/immutable/chunks/StakeOriginalsStakeWheel.D9kbMuGs.js", "_app/immutable/chunks/StakeOriginalsStakeRoulette.C5Lbr9N-.js", "_app/immutable/chunks/BadgesUnignore.DF3Iqmag.js", "_app/immutable/chunks/Casino.DVF879Gw.js", "_app/immutable/chunks/BetInstant.BTtScKo0.js", "_app/immutable/chunks/Affiliate.6_vwcHfp.js", "_app/immutable/chunks/SortAZ._Orhvldh.js", "_app/immutable/assets/index.8oPxuECQ.css", "_app/immutable/assets/Slide.CUfVCFME.css", "_app/immutable/chunks/index.BmTk3-ns.js", "_app/immutable/chunks/AmountField.ClCNMmNI.js", "_app/immutable/chunks/index.BYgQ-xSW.js", "_app/immutable/chunks/index.DYe64iMk.js", "_app/immutable/assets/index.C053kIrr.css", "_app/immutable/chunks/ToggleField.CZayLnpR.js", "_app/immutable/chunks/index.fjw4cqxA.js", "_app/immutable/assets/index.CNeaGQKb.css", "_app/immutable/assets/index.BKIf2qFB.css", "_app/immutable/chunks/index.CGBQVeop.js", "_app/immutable/chunks/index.D_fkjfAC.js", "_app/immutable/chunks/index.DUX-fr8O.js", "_app/immutable/chunks/index.8k1x2jes.js", "_app/immutable/chunks/index.CGpM-67n.js", "_app/immutable/chunks/index.Q_SYydu9.js", "_app/immutable/assets/index.BUDdEBPA.css", "_app/immutable/assets/index.1ijUQvUW.css", "_app/immutable/chunks/index.DkKgEBic.js", "_app/immutable/chunks/index.BiZyFJca.js", "_app/immutable/chunks/season.CGUP7z2p.js", "_app/immutable/chunks/lottie.4uHITndB.js", "_app/immutable/assets/index.Bt8iowVM.css", "_app/immutable/assets/index.DannAXTk.css", "_app/immutable/chunks/index.DHf88Hxl.js", "_app/immutable/chunks/index.BQxoob6z.js", "_app/immutable/chunks/Verify.mXga7moO.js", "_app/immutable/chunks/store.CqCe6hSO.js", "_app/immutable/chunks/index.DdwTsCWL.js", "_app/immutable/assets/index.Dk4tXzwE.css", "_app/immutable/assets/store.DZI5CbP7.css", "_app/immutable/assets/SlideGame.C-xCGfwZ.css", "_app/immutable/assets/index.pIg_YGgN.css", "_app/immutable/chunks/index.CV26phUF.js", "_app/immutable/assets/index.BtDQCGNj.css", "_app/immutable/chunks/index.Ceod1k5r.js", "_app/immutable/chunks/FitToPlay.generated.CZctvVZt.js", "_app/immutable/assets/index.D4mV8pyK.css", "_app/immutable/chunks/index.p4ZshX_y.js", "_app/immutable/chunks/Mail.DzYKlkWd.js", "_app/immutable/chunks/Fields.DeIiA4kH.js", "_app/immutable/chunks/Currency.B6CmCNP_.js", "_app/immutable/chunks/Address.CJ9T97ZR.js", "_app/immutable/assets/Address.aCJnikvW.css", "_app/immutable/chunks/TfaInput.CLlV1LvW.js", "_app/immutable/chunks/OAuthField.CGGSAQDW.js", "_app/immutable/assets/OAuthField.B97_15Jc.css", "_app/immutable/chunks/index.BuovPrVs.js", "_app/immutable/chunks/CreateWithdrawalMeta.generated.BLp-nWo9.js", "_app/immutable/chunks/convert.C4uH62iM.js", "_app/immutable/chunks/index.D1K2D9io.js", "_app/immutable/assets/CreateWithdrawalMeta.DdqURt92.css", "_app/immutable/chunks/ts.BdhwrO2u.js", "_app/immutable/chunks/index.DDPEq5DF.js", "_app/immutable/chunks/index.YtbdMakR.js", "_app/immutable/chunks/index.CWX62gtT.js", "_app/immutable/chunks/index.JPBYpHIs.js", "_app/immutable/assets/index.Aw-sVBnN.css", "_app/immutable/assets/index.CVShe-_l.css", "_app/immutable/chunks/index.DAhPhafI.js", "_app/immutable/assets/index.BCLXCqFk.css", "_app/immutable/chunks/index.CW_nQpKd.js", "_app/immutable/chunks/preloaders.DLmr5t44.js", "_app/immutable/assets/index.2XCtgqeS.css", "_app/immutable/chunks/index.DMk9hCYD.js", "_app/immutable/chunks/index.BJhjh7Yl.js", "_app/immutable/chunks/index.D4kqVxDU.js", "_app/immutable/chunks/geoComply.DqNNM3gB.js", "_app/immutable/chunks/index.DHLw19_S.js", "_app/immutable/chunks/index.BhEJfhLu.js", "_app/immutable/chunks/RemoveCampaignPostback.generated.D3QVsXZK.js", "_app/immutable/chunks/_page.DUb32PoL.js", "_app/immutable/chunks/CampaignList.generated.ZIso49fL.js", "_app/immutable/chunks/UserPermissionFlagByName.generated.ei382Ygr.js", "_app/immutable/chunks/pageSeo.DmcsyA6w.js", "_app/immutable/chunks/get.YfNxXJCS.js", "_app/immutable/chunks/sanity.Cu4Or4Eg.js", "_app/immutable/chunks/dynamic-import-helper.BheWnx7M.js", "_app/immutable/chunks/jsonScript.84xs9Vds.js", "_app/immutable/chunks/index.Cwc3Y_H_.js", "_app/immutable/chunks/MicrophoneOff.BHVz4t8f.js", "_app/immutable/chunks/index.BHHo1fl5.js", "_app/immutable/chunks/Pagination.CKRSZVAD.js", "_app/immutable/chunks/createPagination.nV30wPMr.js", "_app/immutable/assets/index.Cxe45h4T.css", "_app/immutable/chunks/index.C2OU6InA.js", "_app/immutable/chunks/index.D_XRps8j.js", "_app/immutable/assets/index.DruRtu34.css", "_app/immutable/chunks/index.sRX0vm9v.js", "_app/immutable/chunks/BonusEligibleCurrencies.generated.PjBXPy8z.js", "_app/immutable/chunks/index.8kjJQNmh.js", "_app/immutable/chunks/index.vF9FMtJj.js", "_app/immutable/chunks/loadHeroes.DzVzpj5D.js", "_app/immutable/chunks/progress-bar.COlnlh7F.js", "_app/immutable/chunks/progress-bar-indicator.-mV0LZZH.js", "_app/immutable/chunks/updater.ijzXWSE7.js", "_app/immutable/chunks/_api.D0-JRCgy.js", "_app/immutable/chunks/KuratorCollection.generated.C8c5aVgv.js", "_app/immutable/chunks/index.BhRPG--d.js", "_app/immutable/chunks/index.svelte_svelte_type_style_lang.D-BbJzH-.js", "_app/immutable/assets/index.B38WCeFZ.css", "_app/immutable/chunks/BadgesCup1.Cjg1aoxr.js", "_app/immutable/assets/index.-lGgxXJ1.css", "_app/immutable/chunks/index.CeCwkAr8.js", "_app/immutable/chunks/index.BuuWwOkh.js", "_app/immutable/assets/index.DWlh2vYU.css", "_app/immutable/chunks/BreezeOnRampList.generated.Dz5CqcmZ.js", "_app/immutable/chunks/index.BFJERMMW.js", "_app/immutable/chunks/TicketList.generated.ClC7lMqC.js", "_app/immutable/assets/index.g_pox5WJ.css", "_app/immutable/chunks/index.CxNJ9xF7.js", "_app/immutable/chunks/index.CsUYJIUe.js", "_app/immutable/chunks/index.CPyMgfLh.js", "_app/immutable/chunks/rum.C965eY3q.js", "_app/immutable/chunks/index.CRJgPIwB.js", "_app/immutable/chunks/index.BSvWMtTo.js", "_app/immutable/chunks/index.BnVFwGh_.js", "_app/immutable/chunks/index.DiWJbxMk.js", "_app/immutable/chunks/index.vMY77hpA.js", "_app/immutable/chunks/index.QsGNEQwR.js", "_app/immutable/chunks/StakeShop.svelte_svelte_type_style_lang.D6uL7lxM.js", "_app/immutable/chunks/Support.CEAFJiR2.js", "_app/immutable/chunks/Twitter.Biv2Dbuo.js", "_app/immutable/chunks/Chat.DCseWHnE.js", "_app/immutable/assets/StakeShop.wnpuN71x.css", "_app/immutable/chunks/CallToAction.BPF943G3.js", "_app/immutable/chunks/index.BFidmMbA.js", "_app/immutable/chunks/index.DTzw0OqV.js", "_app/immutable/chunks/index.BmrkGTvt.js", "_app/immutable/chunks/us-redirect.CfF30ev5.js", "_app/immutable/chunks/index.BxCwdXZg.js", "_app/immutable/chunks/index.CkesYgi5.js", "_app/immutable/chunks/index.C1zskijt.js", "_app/immutable/chunks/us-restricted.p2Gk5faO.js", "_app/immutable/chunks/index.Dg-QYPcw.js", "_app/immutable/chunks/index.DBva-sFz.js", "_app/immutable/chunks/StakeShop.TavX2Bwa.js", "_app/immutable/chunks/index.D8ZQohQD.js", "_app/immutable/chunks/index.ChuNlIgD.js", "_app/immutable/chunks/index.Ckrm8qkl.js", "_app/immutable/assets/index.BQ4sBIy5.css", "_app/immutable/chunks/index.HIeGUq4t.js", "_app/immutable/chunks/index.D552V4c0.js", "_app/immutable/chunks/index.BwLxXbkX.js", "_app/immutable/chunks/index.BNKhA_XP.js", "_app/immutable/chunks/SlideGame.DGpe5Ihg.js", "_app/immutable/chunks/Result.BCXbJMdZ.js", "_app/immutable/chunks/SpriteSheetCanvas.C41cKpbi.js", "_app/immutable/assets/SpriteSheetCanvas.dYJ-uoBw.css", "_app/immutable/assets/Result.DtuSVOdc.css", "_app/immutable/chunks/messages.BgutK_mE.js", "_app/immutable/chunks/index.B4qbwh5l.js", "_app/immutable/chunks/index.C7klA33a.js", "_app/immutable/chunks/index.Bc8CKQff.js", "_app/immutable/chunks/index.DdrXw2Cq.js", "_app/immutable/chunks/ArrowLineUp.9aAvulx3.js", "_app/immutable/chunks/index.CCRYnEcD.js", "_app/immutable/chunks/HoverTooltip.Db11suIN.js", "_app/immutable/assets/HoverTooltip._uE6kbgV.css", "_app/immutable/chunks/percent.BPWhwbv_.js", "_app/immutable/chunks/messages.D4XShKsY.js", "_app/immutable/assets/messages.rneuwz2t.css", "_app/immutable/chunks/index.l0BdouX0.js", "_app/immutable/chunks/Races.CQldkNqK.js", "_app/immutable/assets/index.DNESmN0r.css", "_app/immutable/chunks/index.eKtawbnV.js", "_app/immutable/chunks/index.B7eCZL6K.js", "_app/immutable/assets/index.BOV_ILbp.css", "_app/immutable/assets/index.BgILgkJs.css", "_app/immutable/chunks/index.B1bBPO6o.js", "_app/immutable/assets/index.BgA0S2U5.css", "_app/immutable/chunks/index.CRzUBLDh.js", "_app/immutable/chunks/index.CoDDQPu5.js", "_app/immutable/chunks/index.D5s1qZR9.js", "_app/immutable/chunks/LayoutSpacing.BhsDyAer.js", "_app/immutable/assets/LayoutSpacing.DqlW0gM4.css", "_app/immutable/chunks/index.DOdJmeib.js", "_app/immutable/assets/index.IKLJS44X.css", "_app/immutable/assets/index.J1DcJVE5.css", "_app/immutable/chunks/index.DaopSbLI.js", "_app/immutable/chunks/utils.D_b734Ye.js", "_app/immutable/chunks/debounceTime.Bb8mI86N.js", "_app/immutable/chunks/index.BoAfEC0D.js", "_app/immutable/chunks/CurrentAnnouncements.generated.Cniolakq.js", "_app/immutable/chunks/ChevronLeft.BpZjIwcI.js", "_app/immutable/chunks/index.D4V_lJ4K.js", "_app/immutable/assets/index.CxhzasRP.css", "_app/immutable/chunks/index.BijwZwmH.js", "_app/immutable/assets/index.6jM-ELh1.css", "_app/immutable/chunks/Rotate.BY58fxIA.js", "_app/immutable/chunks/scrollTopContainer.DLbcGdPu.js", "_app/immutable/assets/utils.CPAluDeI.css", "_app/immutable/chunks/index.Ddq9_51p.js", "_app/immutable/chunks/UserEmail.generated.y_2XuSYr.js", "_app/immutable/assets/index.DtCyYEMx.css", "_app/immutable/assets/index.B7c7JYWY.css", "_app/immutable/chunks/index.BHp-3GN3.js", "_app/immutable/chunks/index.CEKDzRsq.js", "_app/immutable/assets/index.Bh_M27jZ.css", "_app/immutable/chunks/index.D8Vi5kFO.js", "_app/immutable/chunks/index.BzgyI3Xq.js", "_app/immutable/assets/index.yubQUU96.css", "_app/immutable/assets/index.DfcpgpdP.css", "_app/immutable/chunks/index.zN-vqw_u.js", "_app/immutable/chunks/Betslip.C7x1Ve5J.js", "_app/immutable/assets/index.B1oYvxF1.css", "_app/immutable/chunks/index.DKJT1W9s.js"]))) => i.map(i => d[i]);
import {
    h as r,
    _ as I,
    p as $,
    aS as w,
    ag as Y,
    a0 as ee,
    v as te
} from "./index.B4-7gKq3.js";
import {
    q as R
} from "./query-string.27nWWSq4.js";
import {
    _ as l
} from "./preload-helper.BqjOJQfC.js";
import "./index.ByMdEFI5.js";
import {
    s as d,
    C as v,
    H as f,
    D as h,
    f as g,
    E as y,
    i as u,
    F as c,
    j as p,
    n as _,
    G as oe
} from "./scheduler.DXu26z7T.js";
import {
    S as E,
    i as P
} from "./index.Dz_MmNB3.js";
import {
    g as B
} from "./entry.GPJbNZcP.js";
import {
    V as ne,
    d as G
} from "./index.B81orGJm.js";
import {
    L as S,
    F as ie
} from "./List.DAtnvj0J.js";
import {
    S as C
} from "./Settings.B9OSzQXJ.js";
import {
    R as se,
    T as q,
    S as ae,
    D as re,
    a as le
} from "./Trophy4.CNL_sHmf.js";
import {
    S as W
} from "./SportsArchery.xCgY6FbW.js";
import {
    E as ce
} from "./Error.DAkWdr3O.js";
import {
    d as ue,
    C as _e,
    f as me,
    N as de,
    H as ve,
    g as fe,
    h as he,
    P as ge,
    j as ye,
    l as pe,
    m as Ee,
    W as Pe,
    q as Se,
    n as Le,
    t as ke
} from "./constants.JccqSNFq.js";
import {
    I as j
} from "./Info.D3JB_c9O.js";
import {
    A as H
} from "./Account.Dy1oZprP.js";
import {
    p as Q
} from "./paths.RTtAVJV7.js";
import {
    S as Ie
} from "./SportsBasketball.D8a7WuBk.js";
import {
    G as Re
} from "./Graph.5H4YYOLp.js";

function Oe(o) {
    let e, i, s = ` <title>${o[1]||""}</title> <path d="M32 0C14.326 0 0 14.326 0 32s14.326 32 32 32 32-14.326 32-32S49.674 0 32 0Zm-3.386 48L15.468 34.826l6.586-6.614 6.24 6.24 16.134-17.626 6.906 6.294L28.614 48Z"></path>`,
        a;
    return {
        c() {
            e = v("svg"), i = new f(!0), this.h()
        },
        l(n) {
            e = h(n, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var t = g(e);
            i = y(t, !0), t.forEach(u), this.h()
        },
        h() {
            i.a = null, c(e, "fill", "currentColor"), c(e, "viewBox", "0 0 64 64"), c(e, "class", a = "svg-icon " + o[2]), c(e, "style", o[0])
        },
        m(n, t) {
            p(n, e, t), i.m(s, e)
        },
        p(n, [t]) {
            t & 2 && s !== (s = ` <title>${n[1]||""}</title> <path d="M32 0C14.326 0 0 14.326 0 32s14.326 32 32 32 32-14.326 32-32S49.674 0 32 0Zm-3.386 48L15.468 34.826l6.586-6.614 6.24 6.24 16.134-17.626 6.906 6.294L28.614 48Z"></path>`) && i.p(s), t & 4 && a !== (a = "svg-icon " + n[2]) && c(e, "class", a), t & 1 && c(e, "style", n[0])
        },
        i: _,
        o: _,
        d(n) {
            n && u(e)
        }
    }
}

function Ve(o, e, i) {
    let {
        style: s = ""
    } = e, {
        alt: a = ""
    } = e, {
        class: n = ""
    } = e;
    return o.$$set = t => {
        "style" in t && i(0, s = t.style), "alt" in t && i(1, a = t.alt), "class" in t && i(2, n = t.class)
    }, [s, a, n]
}
class D extends E {
    constructor(e) {
        super(), P(this, e, Ve, Oe, d, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}

function Ae(o) {
    let e, i, s = ` <title>${o[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="m57.742 15.508 5.547 5.548a2.4 2.4 0 0 1 .712 1.71 2.4 2.4 0 0 1-.712 1.708l-8.846 8.846L30.694 9.571 39.59.725A2.4 2.4 0 0 1 41.3.014a2.4 2.4 0 0 1 1.708.711l5.498 5.548a6.532 6.532 0 0 0 9.236 9.236ZM.738 39.529 27.395 12.87l23.747 23.747-26.657 26.657a2.4 2.4 0 0 1-1.71.712 2.4 2.4 0 0 1-1.709-.712l-5.547-5.547a6.532 6.532 0 0 0-9.236-9.236L.736 42.994a2.407 2.407 0 0 1 .002-3.466Z"></path>`,
        a;
    return {
        c() {
            e = v("svg"), i = new f(!0), this.h()
        },
        l(n) {
            e = h(n, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var t = g(e);
            i = y(t, !0), t.forEach(u), this.h()
        },
        h() {
            i.a = null, c(e, "fill", "currentColor"), c(e, "viewBox", "0 0 64 64"), c(e, "class", a = "svg-icon " + o[2]), c(e, "style", o[0])
        },
        m(n, t) {
            p(n, e, t), i.m(s, e)
        },
        p(n, [t]) {
            t & 2 && s !== (s = ` <title>${n[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="m57.742 15.508 5.547 5.548a2.4 2.4 0 0 1 .712 1.71 2.4 2.4 0 0 1-.712 1.708l-8.846 8.846L30.694 9.571 39.59.725A2.4 2.4 0 0 1 41.3.014a2.4 2.4 0 0 1 1.708.711l5.498 5.548a6.532 6.532 0 0 0 9.236 9.236ZM.738 39.529 27.395 12.87l23.747 23.747-26.657 26.657a2.4 2.4 0 0 1-1.71.712 2.4 2.4 0 0 1-1.709-.712l-5.547-5.547a6.532 6.532 0 0 0-9.236-9.236L.736 42.994a2.407 2.407 0 0 1 .002-3.466Z"></path>`) && i.p(s), t & 4 && a !== (a = "svg-icon " + n[2]) && c(e, "class", a), t & 1 && c(e, "style", n[0])
        },
        i: _,
        o: _,
        d(n) {
            n && u(e)
        }
    }
}

function Te(o, e, i) {
    let {
        style: s = ""
    } = e, {
        alt: a = ""
    } = e, {
        class: n = ""
    } = e;
    return o.$$set = t => {
        "style" in t && i(0, s = t.style), "alt" in t && i(1, a = t.alt), "class" in t && i(2, n = t.class)
    }, [s, a, n]
}
class we extends E {
    constructor(e) {
        super(), P(this, e, Te, Ae, d, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}

function De(o) {
    let e, i, s = ` <title>${o[1]||""}</title> <path d="M20 64c11.046 0 20-8.954 20-20 0-1.252-.116-2.476-.336-3.664L64 16V4c0-2.21-1.79-4-4-4h-4v4h-8v8h-8v8h-8l-5.19 5.19A19.954 19.954 0 0 0 20 24C8.954 24 0 32.954 0 44s8.954 20 20 20Zm-5.992-20.008a6 6 0 1 1 0 12 6 6 0 0 1 0-12Z"></path>`,
        a;
    return {
        c() {
            e = v("svg"), i = new f(!0), this.h()
        },
        l(n) {
            e = h(n, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var t = g(e);
            i = y(t, !0), t.forEach(u), this.h()
        },
        h() {
            i.a = null, c(e, "fill", "currentColor"), c(e, "viewBox", "0 0 64 64"), c(e, "class", a = "svg-icon " + o[2]), c(e, "style", o[0])
        },
        m(n, t) {
            p(n, e, t), i.m(s, e)
        },
        p(n, [t]) {
            t & 2 && s !== (s = ` <title>${n[1]||""}</title> <path d="M20 64c11.046 0 20-8.954 20-20 0-1.252-.116-2.476-.336-3.664L64 16V4c0-2.21-1.79-4-4-4h-4v4h-8v8h-8v8h-8l-5.19 5.19A19.954 19.954 0 0 0 20 24C8.954 24 0 32.954 0 44s8.954 20 20 20Zm-5.992-20.008a6 6 0 1 1 0 12 6 6 0 0 1 0-12Z"></path>`) && i.p(s), t & 4 && a !== (a = "svg-icon " + n[2]) && c(e, "class", a), t & 1 && c(e, "style", n[0])
        },
        i: _,
        o: _,
        d(n) {
            n && u(e)
        }
    }
}

function Ce(o, e, i) {
    let {
        style: s = ""
    } = e, {
        alt: a = ""
    } = e, {
        class: n = ""
    } = e;
    return o.$$set = t => {
        "style" in t && i(0, s = t.style), "alt" in t && i(1, a = t.alt), "class" in t && i(2, n = t.class)
    }, [s, a, n]
}
class z extends E {
    constructor(e) {
        super(), P(this, e, Ce, De, d, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}

function be(o) {
    let e, i, s = ` <title>${o[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M23.174 48.96h15.174v-6.506h8V56.96H23.174V64L0 56.96V7.04L23.174 0v7.04h23.174v14.506h-8V15.04H23.174v33.92Zm25.332-25.895L64 32l-15.494 8.934V36h-16.16v-8h16.16v-4.934Z"></path>`,
        a;
    return {
        c() {
            e = v("svg"), i = new f(!0), this.h()
        },
        l(n) {
            e = h(n, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var t = g(e);
            i = y(t, !0), t.forEach(u), this.h()
        },
        h() {
            i.a = null, c(e, "fill", "currentColor"), c(e, "viewBox", "0 0 64 64"), c(e, "class", a = "svg-icon " + o[2]), c(e, "style", o[0])
        },
        m(n, t) {
            p(n, e, t), i.m(s, e)
        },
        p(n, [t]) {
            t & 2 && s !== (s = ` <title>${n[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M23.174 48.96h15.174v-6.506h8V56.96H23.174V64L0 56.96V7.04L23.174 0v7.04h23.174v14.506h-8V15.04H23.174v33.92Zm25.332-25.895L64 32l-15.494 8.934V36h-16.16v-8h16.16v-4.934Z"></path>`) && i.p(s), t & 4 && a !== (a = "svg-icon " + n[2]) && c(e, "class", a), t & 1 && c(e, "style", n[0])
        },
        i: _,
        o: _,
        d(n) {
            n && u(e)
        }
    }
}

function Ze(o, e, i) {
    let {
        style: s = ""
    } = e, {
        alt: a = ""
    } = e, {
        class: n = ""
    } = e;
    return o.$$set = t => {
        "style" in t && i(0, s = t.style), "alt" in t && i(1, a = t.alt), "class" in t && i(2, n = t.class)
    }, [s, a, n]
}
class Me extends E {
    constructor(e) {
        super(), P(this, e, Ze, be, d, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}

function Ne(o) {
    let e, i, s = ` <title>${o[1]||""}</title> <path d="M56.213 38.053v10.374H7.787V38.053h6.906v-15.84c.038-8.3 5.912-15.216 13.728-16.86l.112-.02V3.467a3.466 3.466 0 0 1 6.932 0v1.866c7.954 1.668 13.84 8.624 13.84 16.956v15.844l6.908-.08ZM32 63.999c5.73 0 10.374-4.644 10.374-10.374H21.627c0 5.73 4.644 10.374 10.374 10.374H32Z"></path>`,
        a;
    return {
        c() {
            e = v("svg"), i = new f(!0), this.h()
        },
        l(n) {
            e = h(n, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var t = g(e);
            i = y(t, !0), t.forEach(u), this.h()
        },
        h() {
            i.a = null, c(e, "fill", "currentColor"), c(e, "viewBox", "0 0 64 64"), c(e, "class", a = "svg-icon " + o[2]), c(e, "style", o[0])
        },
        m(n, t) {
            p(n, e, t), i.m(s, e)
        },
        p(n, [t]) {
            t & 2 && s !== (s = ` <title>${n[1]||""}</title> <path d="M56.213 38.053v10.374H7.787V38.053h6.906v-15.84c.038-8.3 5.912-15.216 13.728-16.86l.112-.02V3.467a3.466 3.466 0 0 1 6.932 0v1.866c7.954 1.668 13.84 8.624 13.84 16.956v15.844l6.908-.08ZM32 63.999c5.73 0 10.374-4.644 10.374-10.374H21.627c0 5.73 4.644 10.374 10.374 10.374H32Z"></path>`) && i.p(s), t & 4 && a !== (a = "svg-icon " + n[2]) && c(e, "class", a), t & 1 && c(e, "style", n[0])
        },
        i: _,
        o: _,
        d(n) {
            n && u(e)
        }
    }
}

function Be(o, e, i) {
    let {
        style: s = ""
    } = e, {
        alt: a = ""
    } = e, {
        class: n = ""
    } = e;
    return o.$$set = t => {
        "style" in t && i(0, s = t.style), "alt" in t && i(1, a = t.alt), "class" in t && i(2, n = t.class)
    }, [s, a, n]
}
class K extends E {
    constructor(e) {
        super(), P(this, e, Be, Ne, d, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}

function He(o) {
    let e, i, s = ` <title>${o[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M28.982-.001h.252c19.18.022 34.726 15.568 34.748 34.75v.25h-4v-.252c-.018-16.974-13.774-30.73-30.75-30.748h-.25v-4Zm3.561 49.81 2.63-6.29-.002.002c1.94-2.14 16.53 11.33 14.59 13.48l-7.05 5.05.04-.026A11.386 11.386 0 0 1 36.321 64c-2.512 0-4.836-.81-6.69-2.16l-.356-.227C18.694 54.453 9.545 45.335 2.127 34.43a11.35 11.35 0 0 1-2.11-6.61c0-2.39.736-4.607 1.966-6.4l5.08-7.13c2.15-1.95 15.62 12.59 13.47 14.59l-6.29 2.63c3.97 7.9 10.18 13.91 18.3 18.3Zm-3.311-39.73h-.25v4h.25c11.412.012 20.658 9.258 20.67 20.668v.252h4v-.25c-.018-13.618-11.052-24.652-24.668-24.67h-.002Zm-.25 10.07h.252c8.056.011 14.586 6.541 14.598 14.6v.25h-4a2.627 2.627 0 0 0 0-.25v-.003c-.012-5.848-4.75-10.586-10.6-10.598h-.25v-4Zm10.85 14.85v.005-.006Z"></path>`,
        a;
    return {
        c() {
            e = v("svg"), i = new f(!0), this.h()
        },
        l(n) {
            e = h(n, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var t = g(e);
            i = y(t, !0), t.forEach(u), this.h()
        },
        h() {
            i.a = null, c(e, "fill", "currentColor"), c(e, "viewBox", "0 0 64 64"), c(e, "class", a = "svg-icon " + o[2]), c(e, "style", o[0])
        },
        m(n, t) {
            p(n, e, t), i.m(s, e)
        },
        p(n, [t]) {
            t & 2 && s !== (s = ` <title>${n[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M28.982-.001h.252c19.18.022 34.726 15.568 34.748 34.75v.25h-4v-.252c-.018-16.974-13.774-30.73-30.75-30.748h-.25v-4Zm3.561 49.81 2.63-6.29-.002.002c1.94-2.14 16.53 11.33 14.59 13.48l-7.05 5.05.04-.026A11.386 11.386 0 0 1 36.321 64c-2.512 0-4.836-.81-6.69-2.16l-.356-.227C18.694 54.453 9.545 45.335 2.127 34.43a11.35 11.35 0 0 1-2.11-6.61c0-2.39.736-4.607 1.966-6.4l5.08-7.13c2.15-1.95 15.62 12.59 13.47 14.59l-6.29 2.63c3.97 7.9 10.18 13.91 18.3 18.3Zm-3.311-39.73h-.25v4h.25c11.412.012 20.658 9.258 20.67 20.668v.252h4v-.25c-.018-13.618-11.052-24.652-24.668-24.67h-.002Zm-.25 10.07h.252c8.056.011 14.586 6.541 14.598 14.6v.25h-4a2.627 2.627 0 0 0 0-.25v-.003c-.012-5.848-4.75-10.586-10.6-10.598h-.25v-4Zm10.85 14.85v.005-.006Z"></path>`) && i.p(s), t & 4 && a !== (a = "svg-icon " + n[2]) && c(e, "class", a), t & 1 && c(e, "style", n[0])
        },
        i: _,
        o: _,
        d(n) {
            n && u(e)
        }
    }
}

function Ke(o, e, i) {
    let {
        style: s = ""
    } = e, {
        alt: a = ""
    } = e, {
        class: n = ""
    } = e;
    return o.$$set = t => {
        "style" in t && i(0, s = t.style), "alt" in t && i(1, a = t.alt), "class" in t && i(2, n = t.class)
    }, [s, a, n]
}
class Fe extends E {
    constructor(e) {
        super(), P(this, e, Ke, He, d, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}

function Ue(o) {
    let e, i, s = ` <title>${o[1]||""}</title> <path d="M54.042 29.572C49.932 18.108 41.222 7.812 32.002 0c-9.22 7.814-17.93 18.108-22.04 29.572-2.542 7.09-2.792 14.786.786 21.588C14.864 58.982 23.162 64 32 64s17.138-5.018 21.252-12.84c3.58-6.802 3.328-14.498.786-21.588h.004Zm-7.868 17.862C43.436 52.638 37.874 56 32.002 56c-3.446 0-6.782-1.158-9.506-3.166.828.108 1.664.166 2.508.166 7.34 0 14.292-4.2 17.712-10.702 2.804-5.33 2.562-10.866 1.492-15.272a42.916 42.916 0 0 1 2.302 5.246c1.412 3.942 2.502 9.772-.336 15.162Z"></path>`,
        a;
    return {
        c() {
            e = v("svg"), i = new f(!0), this.h()
        },
        l(n) {
            e = h(n, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var t = g(e);
            i = y(t, !0), t.forEach(u), this.h()
        },
        h() {
            i.a = null, c(e, "fill", "currentColor"), c(e, "viewBox", "0 0 64 64"), c(e, "class", a = "svg-icon " + o[2]), c(e, "style", o[0])
        },
        m(n, t) {
            p(n, e, t), i.m(s, e)
        },
        p(n, [t]) {
            t & 2 && s !== (s = ` <title>${n[1]||""}</title> <path d="M54.042 29.572C49.932 18.108 41.222 7.812 32.002 0c-9.22 7.814-17.93 18.108-22.04 29.572-2.542 7.09-2.792 14.786.786 21.588C14.864 58.982 23.162 64 32 64s17.138-5.018 21.252-12.84c3.58-6.802 3.328-14.498.786-21.588h.004Zm-7.868 17.862C43.436 52.638 37.874 56 32.002 56c-3.446 0-6.782-1.158-9.506-3.166.828.108 1.664.166 2.508.166 7.34 0 14.292-4.2 17.712-10.702 2.804-5.33 2.562-10.866 1.492-15.272a42.916 42.916 0 0 1 2.302 5.246c1.412 3.942 2.502 9.772-.336 15.162Z"></path>`) && i.p(s), t & 4 && a !== (a = "svg-icon " + n[2]) && c(e, "class", a), t & 1 && c(e, "style", n[0])
        },
        i: _,
        o: _,
        d(n) {
            n && u(e)
        }
    }
}

function Ye(o, e, i) {
    let {
        style: s = ""
    } = e, {
        alt: a = ""
    } = e, {
        class: n = ""
    } = e;
    return o.$$set = t => {
        "style" in t && i(0, s = t.style), "alt" in t && i(1, a = t.alt), "class" in t && i(2, n = t.class)
    }, [s, a, n]
}
class Ge extends E {
    constructor(e) {
        super(), P(this, e, Ye, Ue, d, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}

function qe(o) {
    let e, i, s = ` <title>${o[1]||""}</title> <path d="M84.487 60.808c0-10.46-2.837-22.46-9.891-29.107-2.271 8.839-6.324 8.839-6.324 8.839S66.243 0 43.947 0c0 0 0 34.702-12.162 34.702 0 0-.447-13.783-6.528-13.783-1.378 9.283-13.744 21.649-13.744 39.892.021 16.76 11.339 30.871 26.745 35.128l.255.061c-4.217-4.257-15.567-18.973 1.378-39.245 0 0 0 16.216 12.162 16.216a8.11 8.11 0 0 0 8.11-8.11s11.228 18.852-2.515 31.096c15.583-4.375 26.82-18.447 26.839-35.145v-.004Z"></path>`,
        a;
    return {
        c() {
            e = v("svg"), i = new f(!0), this.h()
        },
        l(n) {
            e = h(n, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var t = g(e);
            i = y(t, !0), t.forEach(u), this.h()
        },
        h() {
            i.a = null, c(e, "fill", "currentColor"), c(e, "viewBox", "0 0 96 96"), c(e, "class", a = "svg-icon " + o[2]), c(e, "style", o[0])
        },
        m(n, t) {
            p(n, e, t), i.m(s, e)
        },
        p(n, [t]) {
            t & 2 && s !== (s = ` <title>${n[1]||""}</title> <path d="M84.487 60.808c0-10.46-2.837-22.46-9.891-29.107-2.271 8.839-6.324 8.839-6.324 8.839S66.243 0 43.947 0c0 0 0 34.702-12.162 34.702 0 0-.447-13.783-6.528-13.783-1.378 9.283-13.744 21.649-13.744 39.892.021 16.76 11.339 30.871 26.745 35.128l.255.061c-4.217-4.257-15.567-18.973 1.378-39.245 0 0 0 16.216 12.162 16.216a8.11 8.11 0 0 0 8.11-8.11s11.228 18.852-2.515 31.096c15.583-4.375 26.82-18.447 26.839-35.145v-.004Z"></path>`) && i.p(s), t & 4 && a !== (a = "svg-icon " + n[2]) && c(e, "class", a), t & 1 && c(e, "style", n[0])
        },
        i: _,
        o: _,
        d(n) {
            n && u(e)
        }
    }
}

function We(o, e, i) {
    let {
        style: s = ""
    } = e, {
        alt: a = ""
    } = e, {
        class: n = ""
    } = e;
    return o.$$set = t => {
        "style" in t && i(0, s = t.style), "alt" in t && i(1, a = t.alt), "class" in t && i(2, n = t.class)
    }, [s, a, n]
}
class je extends E {
    constructor(e) {
        super(), P(this, e, We, qe, d, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}

function Qe(o) {
    let e, i, s = ` <title>${o[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M0 49.573V0h64v49.573H0ZM31.067 28.8h7.786v-8h-7.786a11.92 11.92 0 1 0 0 8ZM48 41.947h8v-12.08h-8v12.08Zm0-22.214h8V7.653h-8v12.08ZM23.893 24.8a4 4 0 1 1-8 0 4 4 0 0 1 8 0ZM5.333 64H18.72l4.56-7.76H5.333V64Zm53.334 0H45.28l-4.56-7.76h17.947V64Z"></path>`,
        a;
    return {
        c() {
            e = v("svg"), i = new f(!0), this.h()
        },
        l(n) {
            e = h(n, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var t = g(e);
            i = y(t, !0), t.forEach(u), this.h()
        },
        h() {
            i.a = null, c(e, "fill", "currentColor"), c(e, "viewBox", "0 0 64 64"), c(e, "class", a = "svg-icon " + o[2]), c(e, "style", o[0])
        },
        m(n, t) {
            p(n, e, t), i.m(s, e)
        },
        p(n, [t]) {
            t & 2 && s !== (s = ` <title>${n[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M0 49.573V0h64v49.573H0ZM31.067 28.8h7.786v-8h-7.786a11.92 11.92 0 1 0 0 8ZM48 41.947h8v-12.08h-8v12.08Zm0-22.214h8V7.653h-8v12.08ZM23.893 24.8a4 4 0 1 1-8 0 4 4 0 0 1 8 0ZM5.333 64H18.72l4.56-7.76H5.333V64Zm53.334 0H45.28l-4.56-7.76h17.947V64Z"></path>`) && i.p(s), t & 4 && a !== (a = "svg-icon " + n[2]) && c(e, "class", a), t & 1 && c(e, "style", n[0])
        },
        i: _,
        o: _,
        d(n) {
            n && u(e)
        }
    }
}

function ze(o, e, i) {
    let {
        style: s = ""
    } = e, {
        alt: a = ""
    } = e, {
        class: n = ""
    } = e;
    return o.$$set = t => {
        "style" in t && i(0, s = t.style), "alt" in t && i(1, a = t.alt), "class" in t && i(2, n = t.class)
    }, [s, a, n]
}
class xe extends E {
    constructor(e) {
        super(), P(this, e, ze, Qe, d, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}

function Je(o) {
    let e, i, s = ` <title>${o[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M31.2 9.013c.56.854 1.013 1.76 1.333 2.72l4.64 1.147v6.053l-4.613 1.174a12.429 12.429 0 0 1-2.4 4.106l1.333 4.587-5.253 3.013-3.307-3.44c-.773.16-1.573.24-2.373.24-.8 0-1.6-.08-2.373-.24l-3.334 3.44L9.627 28.8l1.306-4.587a12.3 12.3 0 0 1-2.346-4.106L3.92 18.933V12.88l4.667-1.147a9.913 9.913 0 0 1 1.333-2.72c.293-.48.64-.96 1.013-1.386L9.627 3.013 14.853 0l3.334 3.44c.773-.16 1.573-.24 2.373-.24.8 0 1.6.08 2.373.24L26.24 0l5.253 3.013L30.16 7.6a9.19 9.19 0 0 1 1.04 1.413ZM15.627 15.92a4.94 4.94 0 0 0 4.933 4.933 4.94 4.94 0 0 0 4.933-4.933 4.94 4.94 0 0 0-4.933-4.933 4.94 4.94 0 0 0-4.933 4.933Zm23.44 17.866V32.24c0-4.24 3.44-7.68 7.68-7.68H64V12.64c0-2-1.627-3.627-3.627-3.627H38.16c1.76.427 3.013 2.027 3.013 3.867v6.053c0 1.84-1.253 3.44-3.04 3.867l-2.773.72c-.24.48-.533.96-.827 1.413l.8 2.773c.507 1.76-.266 3.627-1.84 4.56L28.24 35.28c-.613.373-1.307.533-2 .533-1.04 0-2.107-.4-2.88-1.2l-1.947-2.026c-.586.026-1.146.026-1.733 0l-1.947 2.026a3.998 3.998 0 0 1-4.88.667l-5.226-3.014a3.986 3.986 0 0 1-1.84-4.56l.773-2.773C6.267 24.48 6 24 5.733 23.52L2.96 22.8A3.99 3.99 0 0 1 0 19.706v33.68c0 2 1.627 3.627 3.627 3.627h56.746c2 0 3.627-1.627 3.627-3.627v-11.92H46.747c-4.24 0-7.68-3.44-7.68-7.68Zm7.68-5.226a3.687 3.687 0 0 0-3.68 3.68v1.547a3.687 3.687 0 0 0 3.68 3.68H64V28.56H46.746Z"></path>`,
        a;
    return {
        c() {
            e = v("svg"), i = new f(!0), this.h()
        },
        l(n) {
            e = h(n, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var t = g(e);
            i = y(t, !0), t.forEach(u), this.h()
        },
        h() {
            i.a = null, c(e, "fill", "currentColor"), c(e, "viewBox", "0 0 64 64"), c(e, "class", a = "svg-icon " + o[2]), c(e, "style", o[0])
        },
        m(n, t) {
            p(n, e, t), i.m(s, e)
        },
        p(n, [t]) {
            t & 2 && s !== (s = ` <title>${n[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M31.2 9.013c.56.854 1.013 1.76 1.333 2.72l4.64 1.147v6.053l-4.613 1.174a12.429 12.429 0 0 1-2.4 4.106l1.333 4.587-5.253 3.013-3.307-3.44c-.773.16-1.573.24-2.373.24-.8 0-1.6-.08-2.373-.24l-3.334 3.44L9.627 28.8l1.306-4.587a12.3 12.3 0 0 1-2.346-4.106L3.92 18.933V12.88l4.667-1.147a9.913 9.913 0 0 1 1.333-2.72c.293-.48.64-.96 1.013-1.386L9.627 3.013 14.853 0l3.334 3.44c.773-.16 1.573-.24 2.373-.24.8 0 1.6.08 2.373.24L26.24 0l5.253 3.013L30.16 7.6a9.19 9.19 0 0 1 1.04 1.413ZM15.627 15.92a4.94 4.94 0 0 0 4.933 4.933 4.94 4.94 0 0 0 4.933-4.933 4.94 4.94 0 0 0-4.933-4.933 4.94 4.94 0 0 0-4.933 4.933Zm23.44 17.866V32.24c0-4.24 3.44-7.68 7.68-7.68H64V12.64c0-2-1.627-3.627-3.627-3.627H38.16c1.76.427 3.013 2.027 3.013 3.867v6.053c0 1.84-1.253 3.44-3.04 3.867l-2.773.72c-.24.48-.533.96-.827 1.413l.8 2.773c.507 1.76-.266 3.627-1.84 4.56L28.24 35.28c-.613.373-1.307.533-2 .533-1.04 0-2.107-.4-2.88-1.2l-1.947-2.026c-.586.026-1.146.026-1.733 0l-1.947 2.026a3.998 3.998 0 0 1-4.88.667l-5.226-3.014a3.986 3.986 0 0 1-1.84-4.56l.773-2.773C6.267 24.48 6 24 5.733 23.52L2.96 22.8A3.99 3.99 0 0 1 0 19.706v33.68c0 2 1.627 3.627 3.627 3.627h56.746c2 0 3.627-1.627 3.627-3.627v-11.92H46.747c-4.24 0-7.68-3.44-7.68-7.68Zm7.68-5.226a3.687 3.687 0 0 0-3.68 3.68v1.547a3.687 3.687 0 0 0 3.68 3.68H64V28.56H46.746Z"></path>`) && i.p(s), t & 4 && a !== (a = "svg-icon " + n[2]) && c(e, "class", a), t & 1 && c(e, "style", n[0])
        },
        i: _,
        o: _,
        d(n) {
            n && u(e)
        }
    }
}

function Xe(o, e, i) {
    let {
        style: s = ""
    } = e, {
        alt: a = ""
    } = e, {
        class: n = ""
    } = e;
    return o.$$set = t => {
        "style" in t && i(0, s = t.style), "alt" in t && i(1, a = t.alt), "class" in t && i(2, n = t.class)
    }, [s, a, n]
}
class $e extends E {
    constructor(e) {
        super(), P(this, e, Xe, Je, d, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}

function et(o) {
    let e, i, s = ` <title>${o[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M6.718 61.1H57.28c5.17 0 8.393-5.607 5.808-10.072l-25.28-43.68c-2.586-4.464-9.032-4.464-11.617 0L.91 51.029C-1.676 55.493 1.547 61.1 6.717 61.1ZM32 37.598a3.367 3.367 0 0 1-3.357-3.357v-6.715A3.367 3.367 0 0 1 32 24.169a3.367 3.367 0 0 1 3.357 3.357v6.715A3.367 3.367 0 0 1 32 37.598Zm-3.357 13.43h6.714v-6.715h-6.714v6.715Z"></path>`,
        a;
    return {
        c() {
            e = v("svg"), i = new f(!0), this.h()
        },
        l(n) {
            e = h(n, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var t = g(e);
            i = y(t, !0), t.forEach(u), this.h()
        },
        h() {
            i.a = null, c(e, "fill", "currentColor"), c(e, "viewBox", "0 0 64 64"), c(e, "class", a = "svg-icon " + o[2]), c(e, "style", o[0])
        },
        m(n, t) {
            p(n, e, t), i.m(s, e)
        },
        p(n, [t]) {
            t & 2 && s !== (s = ` <title>${n[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M6.718 61.1H57.28c5.17 0 8.393-5.607 5.808-10.072l-25.28-43.68c-2.586-4.464-9.032-4.464-11.617 0L.91 51.029C-1.676 55.493 1.547 61.1 6.717 61.1ZM32 37.598a3.367 3.367 0 0 1-3.357-3.357v-6.715A3.367 3.367 0 0 1 32 24.169a3.367 3.367 0 0 1 3.357 3.357v6.715A3.367 3.367 0 0 1 32 37.598Zm-3.357 13.43h6.714v-6.715h-6.714v6.715Z"></path>`) && i.p(s), t & 4 && a !== (a = "svg-icon " + n[2]) && c(e, "class", a), t & 1 && c(e, "style", n[0])
        },
        i: _,
        o: _,
        d(n) {
            n && u(e)
        }
    }
}

function tt(o, e, i) {
    let {
        style: s = ""
    } = e, {
        alt: a = ""
    } = e, {
        class: n = ""
    } = e;
    return o.$$set = t => {
        "style" in t && i(0, s = t.style), "alt" in t && i(1, a = t.alt), "class" in t && i(2, n = t.class)
    }, [s, a, n]
}
class ot extends E {
    constructor(e) {
        super(), P(this, e, tt, et, d, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
const nt = {
        component: () => l(() =>
            import ("./index.DeKgMl2t.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64])),
        title: r._("Exclusive Deposit Bonus Offer"),
        icon: K
    },
    L = "modal",
    m = o => !o.isAuthenticated,
    x = o => o.isAuthenticated;

function it(o) {
    return I.fromPairs(I.entries(o).map(([e, i]) => {
        const s = { ...i,
            open: a => {
                const n = R.generate({
                        search: { ...a,
                            [L]: e
                        }
                    }),
                    t = `${window.location.pathname}${n}`.replace("//", "/");
                B(t, { ...(i == null ? void 0 : i.opts) ? ? {},
                    noScroll : !0
                })
            },
            to: a => R.generate({
                pageQuery: oe($).url.searchParams,
                search: { ...a,
                    [L]: e
                }
            })
        };
        return [e, s]
    }))
}
const st = {
        component: () => l(() =>
            import ("./index.IduFdWsZ.js"), __vite__mapDeps([65, 1, 2, 11, 12, 13, 14, 15, 10, 39, 22, 5, 23, 16, 7, 66, 67, 68, 69, 70, 57, 71, 45, 72, 73, 38, 24, 25, 26, 27, 6, 28, 29, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 4, 8, 9, 61, 60, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 41, 42, 43, 104, 105, 106, 107, 108, 109, 32, 33, 110, 111, 112, 113, 114, 115, 116, 117, 34, 35, 36, 37, 30, 40, 118, 119, 56, 120, 121, 122, 58, 59, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 48, 49, 50, 51, 52, 53, 54, 141, 19, 20, 21, 31, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 63, 64, 204])),
        header: null,
        restricted: x,
        removeSearchParams: ["tab", "redirect"]
    },
    at = {
        component: () => l(() =>
            import ("./index.BRTKpJCf.js"), __vite__mapDeps([205, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64])),
        title: r._("Exclusive Deposit Bonus Offer"),
        icon: K,
        persistent: !0
    },
    J = {
        component: () => l(() =>
            import ("./index.SN9TA6nA.js").then(o => o.i), __vite__mapDeps([206, 1, 2, 11, 12, 13, 14, 15, 191, 207, 114, 115, 6, 7, 116, 117, 63, 64, 57, 10, 208, 32, 5, 33, 151, 152, 209, 16, 210, 158, 21, 159, 24, 25, 26, 27, 28, 29, 160, 211, 198, 36, 37, 30, 199, 212, 150, 61, 60, 47, 48, 49, 43, 35, 50, 51, 52, 53, 54, 55, 42, 213, 214, 138, 22, 23, 139, 215, 216, 164, 165, 56, 217, 218, 73, 38, 74, 75, 76, 77, 78, 79, 80, 219, 220, 221, 222, 19, 20, 31, 223, 59, 58, 224, 172, 82, 225, 226, 227, 142, 41, 141, 143, 144, 153, 154, 228, 229, 162, 131, 132, 133, 134, 135, 45, 129, 149, 155, 156, 157, 161, 163, 230, 231, 232, 190, 192, 193, 4, 8, 9, 233, 137, 234, 235, 236, 237, 238, 239, 123, 240, 241, 68, 69, 70, 91, 89, 81, 83, 85, 242])),
        title: r._("Bet"),
        icon: S,
        removeSearchParams: ["betId", "iid", "addToBetSlip"]
    },
    rt = {
        component: () => l(() =>
            import ("./index.SN9TA6nA.js").then(o => o.i), __vite__mapDeps([206, 1, 2, 11, 12, 13, 14, 15, 191, 207, 114, 115, 6, 7, 116, 117, 63, 64, 57, 10, 208, 32, 5, 33, 151, 152, 209, 16, 210, 158, 21, 159, 24, 25, 26, 27, 28, 29, 160, 211, 198, 36, 37, 30, 199, 212, 150, 61, 60, 47, 48, 49, 43, 35, 50, 51, 52, 53, 54, 55, 42, 213, 214, 138, 22, 23, 139, 215, 216, 164, 165, 56, 217, 218, 73, 38, 74, 75, 76, 77, 78, 79, 80, 219, 220, 221, 222, 19, 20, 31, 223, 59, 58, 224, 172, 82, 225, 226, 227, 142, 41, 141, 143, 144, 153, 154, 228, 229, 162, 131, 132, 133, 134, 135, 45, 129, 149, 155, 156, 157, 161, 163, 230, 231, 232, 190, 192, 193, 4, 8, 9, 233, 137, 234, 235, 236, 237, 238, 239, 123, 240, 241, 68, 69, 70, 91, 89, 81, 83, 85, 242])),
        title: r._("Game"),
        icon: S,
        removeSearchParams: ["betId", "iid"]
    },
    lt = {
        stake: J,
        sweeps: rt
    },
    ct = lt[ne] || J,
    ut = {
        component: () => l(() =>
            import ("./index.Dc4VZCtB.js"), __vite__mapDeps([243, 1, 2, 69, 5, 11, 12, 13, 14, 15, 68, 70, 22, 23, 89, 81, 57, 10, 74, 75, 78, 82, 38, 83, 91, 16, 7, 4, 6, 8, 9, 61, 60, 42, 43, 244, 63, 64])),
        title: r._("Break In Play")
    },
    _t = {
        component: () => l(() =>
            import ("./index.CUGjhjk5.js"), __vite__mapDeps([245, 1, 2, 63, 64, 11, 12, 13, 14, 15, 68, 89, 5, 81, 57, 10, 22, 23, 74, 75, 78, 82, 38, 83, 69, 70, 91, 16, 7, 4, 6, 8, 9, 61, 60, 246, 247, 248, 249, 250, 42, 43, 36, 27, 37, 30, 251, 252, 253])),
        title: r._("Chat Controls"),
        icon: C
    },
    mt = {
        component: () => l(() =>
            import ("./index.DemeWyRw.js"), __vite__mapDeps([254, 1, 2, 57, 11, 12, 13, 14, 15, 22, 5, 23, 63, 64, 58, 59, 6, 7, 60, 16, 10, 123, 255])),
        title: r._("Chat Rules"),
        icon: se
    },
    dt = {
        component: () => l(() =>
            import ("./index.CNv9FBOb.js"), __vite__mapDeps([256, 239, 1, 67, 2, 16, 7, 14, 32, 5, 33, 22, 23, 11, 12, 13, 15, 35, 27, 36, 37, 30, 61, 60, 6, 257])),
        restricted: m,
        header: null
    },
    vt = {
        component: () => l(() =>
            import ("./index.DUGLC8Kl.js"), __vite__mapDeps([258, 1, 2, 259, 57, 11, 12, 13, 14, 15, 114, 115, 6, 7, 116, 117, 260, 5, 261, 16, 262, 10, 237, 58, 59, 60, 238, 263, 39, 42, 43, 50, 51, 264, 54, 265, 218, 73, 22, 23, 38, 24, 25, 26, 27, 28, 29, 74, 75, 76, 77, 78, 79, 80, 61, 219, 32, 33, 19, 20, 21, 30, 31, 223, 221, 137, 210, 158, 159, 160, 211, 198, 36, 37, 199, 212, 150, 151, 152, 47, 48, 49, 35, 52, 53, 55, 213, 214, 138, 139, 215, 216, 217, 220, 222, 266, 56, 267, 112, 68, 268, 269])),
        title: r._("Crash Game"),
        icon: S,
        removeSearchParams: ["gameId"]
    };
async function ft() {
    return new Promise(o => {
        o()
    })
}
const ht = {
        component: () => l(() =>
            import ("./index.CEdYI-Gt.js"), __vite__mapDeps([270, 1, 2, 69, 5, 11, 12, 13, 14, 15, 68, 70, 91, 16, 7, 4, 6, 8, 9, 10, 61, 60, 42, 43, 271, 45, 272, 112, 236, 22, 23, 218, 73, 38, 24, 25, 26, 27, 28, 29, 74, 75, 76, 77, 78, 79, 80, 219, 85, 63, 64])),
        title: r._("Create Campaign"),
        icon: q,
        preload: ft
    },
    gt = {
        component: () => l(() =>
            import ("./index.B1yZYdj5.js"), __vite__mapDeps([273, 1, 2, 274, 69, 5, 11, 12, 13, 14, 15, 68, 70, 275, 10, 276, 277, 25, 28, 159, 16, 7, 61, 60, 6, 26, 278, 279, 172, 82, 22, 23, 49, 43, 280, 251, 57, 20, 164, 165, 35, 27, 36, 37, 30, 19, 21, 24, 29, 31, 281, 73, 38, 74, 75, 76, 77, 78, 79, 80, 282, 283, 284, 94, 285, 286, 142, 287, 91, 4, 8, 9, 202, 85, 288, 289, 290, 59, 291, 99, 292, 293, 100, 294, 295, 133, 101, 103, 296, 297, 298, 98, 299, 300, 301, 108, 130, 302, 303, 114, 115, 116, 117, 304, 305, 306, 307, 308, 309, 310, 42, 135, 227, 311, 83, 63, 64])),
        title: r._("Create Challenge"),
        icon: W
    };
r._("Create Challenge"), W;
const yt = {
        component: () => l(() =>
            import ("./index.CGBQVeop.js"), __vite__mapDeps([312, 1, 2, 63, 64, 22, 5, 23, 16, 7, 14, 17, 12, 18, 313, 11, 13, 15, 36, 27, 37, 30, 61, 60, 6])),
        title: r._("Early Access"),
        icon: ae,
        persistent: !0,
        gotoOptions: {
            replaceState: !0
        }
    },
    pt = {
        component: () => l(() =>
            import ("./index.DUX-fr8O.js"), __vite__mapDeps([314, 1, 2, 114, 115, 12, 6, 7, 116, 117, 251, 11, 13, 14, 15, 315, 16, 35, 27, 36, 37, 30, 178, 316, 10, 69, 5, 68, 70, 317, 34, 38, 39, 40, 22, 23, 188, 42, 43, 189, 41, 85, 73, 24, 25, 26, 28, 29, 74, 75, 76, 77, 78, 79, 80, 32, 33, 88, 89, 81, 57, 82, 83, 90, 91, 4, 8, 9, 61, 60, 308, 309, 310, 72, 84, 112, 318, 44, 45, 110, 111, 319])),
        restricted: m,
        header: () => l(() =>
            import ("./index.DkKgEBic.js"), __vite__mapDeps([320, 1, 2, 11, 12, 13, 14, 15, 321, 322, 5, 323, 94, 324, 16, 7, 61, 60, 6, 325])),
        fullScreenMobile: !0,
        size: "lg"
    },
    Et = {
        component: () => l(() =>
            import ("./index.DHf88Hxl.js"), __vite__mapDeps([326, 1, 2, 11, 12, 13, 14, 15, 63, 64, 58, 5, 59, 6, 7, 60, 16, 10, 22, 23, 123])),
        title: r._("Warning"),
        removeSearchParams: ["url"],
        icon: ce
    },
    Pt = {
        component: () => l(() =>
            import ("./index.BQxoob6z.js"), __vite__mapDeps([327, 1, 2, 57, 11, 12, 13, 14, 15, 260, 5, 261, 16, 7, 328, 73, 10, 22, 23, 38, 24, 25, 26, 27, 6, 28, 29, 74, 75, 76, 77, 78, 79, 80, 59, 60, 69, 68, 70, 85, 91, 4, 8, 9, 61, 43, 218, 219, 191, 207, 329, 239, 35, 36, 37, 30, 330, 331, 81, 82, 83, 233, 235, 332, 238, 333, 334])),
        title: r._("Fairness"),
        icon: ie,
        removeSearchParams: ["tab", ue, _e, me, de, ve, fe, he, ge, ye, pe, Ee, Pe, Se, Le, ke]
    },
    St = {
        component: () => l(() =>
            import ("./index.CV26phUF.js"), __vite__mapDeps([335, 1, 2, 16, 7, 14, 32, 5, 33, 22, 23, 11, 12, 13, 15, 61, 60, 6, 336])),
        restricted: m,
        header: null
    },
    Lt = {
        component: () => l(() =>
            import ("./index.Ceod1k5r.js"), __vite__mapDeps([337, 1, 2, 63, 64, 69, 5, 11, 12, 13, 14, 15, 68, 70, 91, 16, 7, 4, 6, 8, 9, 10, 61, 60, 338, 22, 23, 313, 36, 27, 37, 30, 339])),
        title: r._("Fit To Play"),
        icon: D,
        persistent: !0,
        restricted: m
    },
    kt = {
        component: () => l(() =>
            import ("./index.p4ZshX_y.js"), __vite__mapDeps([340, 1, 2, 32, 5, 33, 11, 12, 13, 14, 15, 10, 341, 188, 42, 43, 189, 41, 38, 69, 68, 70, 342, 57, 343, 276, 277, 25, 28, 159, 16, 7, 61, 60, 6, 26, 278, 279, 172, 82, 22, 23, 49, 280, 251, 20, 164, 165, 35, 27, 36, 37, 30, 19, 21, 24, 29, 31, 281, 73, 74, 75, 76, 77, 78, 79, 80, 282, 283, 284, 236, 344, 85, 345, 89, 81, 83, 346, 347, 200, 45, 104, 4, 8, 9, 105, 102, 348, 304, 305, 306, 307, 91, 187])),
        title: r._("Forgot Password"),
        icon: C
    },
    It = r._("Withdraw Only"),
    Rt = {
        component: () => l(() =>
            import ("./index.BuovPrVs.js"), __vite__mapDeps([349, 1, 2, 57, 350, 10, 11, 12, 13, 14, 15, 19, 5, 20, 21, 22, 23, 24, 25, 26, 27, 6, 7, 28, 29, 30, 31, 293, 68, 202, 351, 49, 43, 16, 277, 159, 61, 60, 278, 279, 172, 82, 236, 352, 341, 276, 280, 251, 164, 165, 35, 36, 37, 281, 73, 38, 74, 75, 76, 77, 78, 79, 80, 282, 283, 284, 69, 70, 4, 8, 9, 32, 33, 85, 91, 344, 345, 353, 42, 346, 313, 34, 39, 40, 198, 199, 63, 64, 354, 114, 115, 116, 117])),
        removeSearchParams: ["currency", "chain"],
        title: It,
        icon: ot,
        persistent: !0,
        restricted: m
    },
    Ot = {
        component: () => l(() =>
            import ("./index.DDPEq5DF.js"), __vite__mapDeps([355, 1, 2, 68, 11, 12, 13, 14, 15, 42, 43, 69, 5, 70, 22, 23, 91, 16, 7, 4, 6, 8, 9, 10, 61, 60, 89, 81, 57, 74, 75, 78, 82, 38, 83, 244, 63, 64])),
        title: r._("Self Exclusion")
    },
    Vt = {
        component: () => l(() =>
            import ("./index.YtbdMakR.js"), __vite__mapDeps([356, 1, 2, 63, 64, 357, 11, 12, 13, 14, 15, 22, 5, 23, 34, 10, 35, 27, 36, 37, 30, 38, 39, 40, 16, 7, 17, 18, 358, 61, 60, 6, 114, 115, 116, 117, 231, 57, 110, 111, 359, 313, 360])),
        title: r._("Verification"),
        icon: j,
        persistent: !0,
        restricted: m
    },
    At = {
        component: () => l(() =>
            import ("./index.DAhPhafI.js"), __vite__mapDeps([361, 1, 2, 16, 7, 14, 32, 5, 33, 22, 23, 251, 11, 12, 13, 15, 61, 60, 6, 362])),
        restricted: m,
        header: null
    },
    Tt = {
        component: () => l(() =>
            import ("./index.CW_nQpKd.js"), __vite__mapDeps([363, 1, 2, 63, 64, 57, 22, 5, 23, 11, 12, 13, 14, 15, 16, 7, 35, 27, 36, 37, 30, 364, 358, 61, 60, 6, 365])),
        header: null,
        removeSearchParams: ["promotion"],
        icon: je
    },
    wt = {
        component: () => l(() =>
            import ("./index.DMk9hCYD.js"), __vite__mapDeps([366, 1, 2, 367, 22, 5, 23, 12, 11, 13, 14, 15, 63, 64, 34, 10, 35, 27, 36, 37, 30, 38, 39, 40])),
        title: r._("Further Information Required"),
        icon: H
    },
    Dt = {
        component: () => l(() =>
            import ("./index.D4kqVxDU.js"), __vite__mapDeps([368, 1, 2, 313, 5, 11, 12, 13, 14, 15, 16, 7, 36, 27, 37, 30, 61, 60, 6, 32, 33, 22, 23, 63, 64, 17, 18, 369, 114, 115, 116, 117])),
        title: r._("Location Check"),
        icon: D,
        removeSearchParams: ["message"],
        persistent: !0
    },
    Ct = {
        component: () => l(() =>
            import ("./index.DHLw19_S.js"), __vite__mapDeps([370, 1, 2, 11, 12, 13, 14, 15, 313, 5, 16, 7, 36, 27, 37, 30, 61, 60, 6, 22, 23, 63, 64])),
        title: r._("Logout"),
        icon: Me
    },
    bt = {
        component: () => l(() =>
            import ("./index.BhEJfhLu.js"), __vite__mapDeps([371, 1, 2, 114, 115, 12, 6, 7, 116, 117, 57, 11, 13, 14, 15, 69, 5, 68, 70, 22, 23, 59, 60, 16, 4, 8, 9, 10, 17, 18, 85, 73, 38, 24, 25, 26, 27, 28, 29, 74, 75, 76, 77, 78, 79, 80, 89, 81, 82, 83, 91, 61, 372, 44, 45, 42, 43, 330, 331, 63, 64, 373, 374, 272, 375, 376, 222, 377, 378, 239, 379, 380, 271])),
        title: r._("Manage Postbacks"),
        icon: K
    },
    Zt = {
        component: () => l(() =>
            import ("./index.Cwc3Y_H_.js"), __vite__mapDeps([381, 1, 2, 231, 57, 5, 11, 12, 13, 14, 15, 210, 10, 158, 21, 159, 24, 25, 26, 27, 6, 7, 28, 29, 160, 211, 198, 36, 37, 30, 199, 212, 150, 151, 152, 16, 61, 60, 47, 48, 49, 43, 35, 50, 51, 52, 53, 54, 55, 42, 213, 214, 138, 22, 23, 139, 215, 216, 164, 165, 260, 261, 114, 115, 116, 117, 63, 64, 177, 178, 134, 179, 124, 125, 69, 68, 70, 342, 343, 276, 277, 278, 279, 172, 82, 280, 251, 20, 19, 31, 281, 73, 38, 74, 75, 76, 77, 78, 79, 80, 282, 283, 284, 236, 344, 85, 345, 89, 81, 83, 346, 347, 200, 45, 41, 104, 4, 8, 9, 105, 102, 348, 304, 305, 306, 307, 91, 382, 209, 56, 383, 384, 32, 33, 385, 249, 386])),
        title: r._("Moderation"),
        icon: C,
        removeSearchParams: ["name", "view"],
        restricted: m
    },
    Mt = {
        component: () => l(() =>
            import ("./index.C2OU6InA.js"), __vite__mapDeps([387, 1, 2, 10, 22, 5, 23, 59, 11, 12, 13, 14, 15, 6, 7, 60, 16, 58, 321, 322, 323, 94, 324, 114, 115, 116, 117, 63, 64, 388, 98, 100, 123, 389])),
        header: null
    },
    Nt = {
        title: r._("Redeem Promotion"),
        component: () => l(() =>
            import ("./index.sRX0vm9v.js"), __vite__mapDeps([390, 1, 2, 391, 11, 12, 13, 14, 15, 10, 57, 19, 5, 20, 21, 22, 23, 24, 25, 26, 27, 6, 7, 28, 29, 30, 31, 392, 142, 69, 68, 70, 91, 16, 4, 8, 9, 61, 60, 42, 43, 41, 38, 56, 114, 115, 116, 117, 343, 276, 277, 159, 278, 279, 172, 82, 49, 280, 251, 164, 165, 35, 36, 37, 281, 73, 74, 75, 76, 77, 78, 79, 80, 282, 283, 284, 236, 63, 64])),
        removeSearchParams: ["code"],
        icon: S,
        restricted: m
    },
    Bt = {
        component: () => l(() =>
            import ("./index.vF9FMtJj.js"), __vite__mapDeps([393, 1, 67, 2, 11, 12, 13, 14, 15, 198, 36, 27, 37, 30, 199, 394, 377, 63, 64, 114, 115, 6, 7, 116, 117, 22, 5, 23, 32, 33, 19, 20, 10, 21, 24, 25, 26, 28, 29, 31, 395, 16, 396, 397, 35, 398, 399, 238, 400, 57, 401, 402, 303, 403, 59, 60, 61, 177, 178, 134, 179, 404])),
        removeSearchParams: ["id", "type"],
        header: null
    },
    Ht = {
        component: () => l(() =>
            import ("./index.CeCwkAr8.js"), __vite__mapDeps([405, 1, 2, 11, 12, 13, 14, 15, 32, 5, 33, 63, 64, 16, 7, 22, 23, 114, 115, 6, 116, 117, 406, 10, 45, 407, 330, 57, 61, 60, 331, 408])),
        removeSearchParams: ["pageId", "clientReferenceId"]
    },
    Kt = {
        empty: r._("You don't have any tickets yet"),
        yourTickets: r._("Your tickets"),
        ticket: r._("TICKET")
    },
    Ft = {
        component: () => l(() =>
            import ("./index.BFJERMMW.js"), __vite__mapDeps([409, 1, 67, 2, 57, 114, 115, 12, 6, 7, 116, 117, 34, 10, 35, 27, 14, 36, 11, 13, 15, 37, 30, 38, 39, 40, 177, 178, 134, 179, 383, 384, 16, 32, 5, 33, 61, 60, 410, 22, 23, 385, 411])),
        restricted: m,
        icon: we,
        title: Kt.yourTickets
    },
    Ut = {
        component: () => l(() =>
            import ("./index.CxNJ9xF7.js"), __vite__mapDeps([412, 1, 2, 63, 64, 11, 12, 13, 14, 15, 114, 115, 6, 7, 116, 117, 236, 251, 198, 36, 27, 37, 30, 199, 41, 10, 38, 69, 5, 68, 70, 351, 49, 43, 42, 352, 341, 276, 277, 25, 28, 159, 16, 61, 60, 26, 278, 279, 172, 82, 22, 23, 280, 57, 20, 164, 165, 35, 19, 21, 24, 29, 31, 281, 73, 74, 75, 76, 77, 78, 79, 80, 282, 283, 284, 202, 246, 247, 248, 249, 250, 252, 91, 4, 8, 9, 85, 346, 304, 305, 306, 307, 347, 200, 45, 104, 105, 102, 348])),
        title: r._("Rain"),
        icon: Ge,
        removeSearchParams: ["currency"],
        restricted: m
    },
    Yt = {
        component: () => l(() =>
            import ("./index.CsUYJIUe.js"), __vite__mapDeps([413, 1, 2, 391, 11, 12, 13, 14, 15, 10, 57, 19, 5, 20, 21, 22, 23, 24, 25, 26, 27, 6, 7, 28, 29, 30, 31, 414, 38, 69, 68, 70, 91, 16, 4, 8, 9, 61, 60, 42, 43, 188, 189, 41, 114, 115, 116, 117, 343, 276, 277, 159, 278, 279, 172, 82, 49, 280, 251, 164, 165, 35, 36, 37, 281, 73, 74, 75, 76, 77, 78, 79, 80, 282, 283, 284, 236, 63, 64, 34, 39, 40, 198, 199, 415, 239])),
        title: r._("Redeem Bonus"),
        icon: S,
        removeSearchParams: ["code", "type"],
        restricted: m
    },
    Gt = {
        component: () => l(() =>
            import ("./index.CRJgPIwB.js"), __vite__mapDeps([416, 1, 2, 11, 12, 13, 14, 15, 32, 5, 33, 63, 64, 16, 7, 22, 23, 406, 10, 45, 407, 61, 60, 6])),
        removeSearchParams: ["pageId", "clientReferenceId"]
    },
    qt = {
        component: () => l(() =>
            import ("./index.BSvWMtTo.js"), __vite__mapDeps([417, 1, 2, 11, 12, 13, 14, 15, 63, 64, 69, 5, 68, 70, 91, 16, 7, 4, 6, 8, 9, 10, 61, 60, 186, 85, 73, 22, 23, 38, 24, 25, 26, 27, 28, 29, 74, 75, 76, 77, 78, 79, 80, 87, 112, 86, 107, 108, 109, 118, 32, 33, 119, 56, 120, 121, 114, 115, 116, 117, 34, 35, 36, 37, 30, 39, 40, 122, 57, 58, 59, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 48, 49, 43, 50, 51, 52, 53, 54, 141, 19, 20, 21, 31, 142, 42, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 82, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 41])),
        title: r._("Register OAuth"),
        icon: "",
        removeSearchParams: ["email"]
    },
    Wt = {
        component: () => l(() =>
            import ("./index.BnVFwGh_.js"), __vite__mapDeps([418, 1, 2, 63, 64, 114, 115, 12, 6, 7, 116, 117, 198, 36, 11, 13, 14, 15, 27, 37, 30, 199, 57, 188, 42, 43, 189, 41, 10, 38, 69, 5, 68, 70, 151, 152, 73, 22, 23, 24, 25, 26, 28, 29, 74, 75, 76, 77, 78, 79, 80, 59, 60, 16, 91, 4, 8, 9, 61, 238, 34, 35, 39, 40, 56])),
        title: r._("Post Card Code Generator"),
        icon: C
    },
    jt = {
        component: () => l(() =>
            import ("./index.DiWJbxMk.js"), __vite__mapDeps([419, 1, 2, 59, 5, 11, 12, 13, 14, 15, 6, 7, 60, 16, 63, 64, 114, 115, 116, 117, 22, 23, 68, 42, 43, 85, 73, 10, 38, 24, 25, 26, 27, 28, 29, 74, 75, 76, 77, 78, 79, 80, 69, 70, 91, 4, 8, 9, 61, 86, 87, 346, 71, 420, 34, 35, 36, 37, 30, 39, 40, 188, 189, 41])),
        title: r._("Reset Password"),
        icon: z,
        removeSearchParams: ["key"],
        restricted: x
    },
    Qt = {
        key: "GB",
        component: () => l(() =>
            import ("./index.QsGNEQwR.js"), __vite__mapDeps([421, 1, 2, 57, 11, 12, 13, 14, 15, 422, 22, 5, 23, 16, 7, 58, 59, 6, 60, 10, 61, 423, 424, 425, 426, 427, 236])).then(o => o.default),
        condition: ({
            data: {
                isBlocked: o,
                country: e
            }
        }) => o && e === w.GB,
        persistent: !0,
        legallyDark: !0
    },
    en = {
        header: ({
            site: o
        }) => ({
            id: "Sorry, {site} is not available in the United Kingdom.",
            values: {
                site: o
            }
        }),
        body: [({
            site: o
        }) => ({
            id: "Due to our gaming license, {site} is unable to accept players who are located within your country, however we do have a home for you over at Stake.uk.com!",
            values: {
                site: o
            }
        })],
        cta: r._("Take me to Stake.uk.com")
    },
    zt = {
        key: "ON",
        component: () => l(() =>
            import ("./index.BFidmMbA.js"), __vite__mapDeps([428, 1, 2, 57, 11, 12, 13, 14, 15, 422, 22, 5, 23, 16, 7, 58, 59, 6, 60, 10, 61, 423, 424, 425, 426, 427, 236])).then(o => o.default),
        condition: ({
            data: {
                isDiscontinuedBlocked: o,
                state: e
            }
        }) => o && e === "ON"
    },
    tn = {
        header: r._("Notice to Customers Located in Ontario"),
        body: [r._("Based on your IP address, it seems you are currently located within Ontario."), r._("Due to a change in local regulation, Stake.com is unable to accept bets, deposits or registrations from people who are located in Ontario. However, if you have funds or any unclaimed bonuses on your account you can continue to withdraw as usual."), r._("Stake will never hold, freeze or confiscate your funds or unclaimed bonuses."), r._("Going forward, Stake will be available for customers located in Ontario at Stake.ca - Our new fully licensed platform for Ontarian customers.")],
        cta: r._("Start Playing on Stake.ca")
    },
    xt = {
        key: "CO",
        component: () => l(() =>
            import ("./index.DTzw0OqV.js"), __vite__mapDeps([429, 1, 2, 57, 11, 12, 13, 14, 15, 422, 22, 5, 23, 16, 7, 58, 59, 6, 60, 10, 61, 423, 424, 425, 426, 427, 236])).then(o => o.default),
        condition: ({
            data: {
                isSoftBlocked: o,
                country: e
            }
        }) => o && e === w.CO
    },
    on = {
        header: r._("Notice to Customers Located in Colombia"),
        body: [r._("Based on your IP address, it seems you are currently located within Colombia."), r._("If you have an existing account, please login to withdraw your funds before moving over to your new home."), r._("Stake will never hold, freeze or confiscate your funds or unclaimed bonuses."), r._("Going forward, Stake will be available for customers located in Colombia at Stake.com.co - Our new fully licensed platform for Colombian customers.")],
        cta: r._("Start Playing on Stake.com.co")
    },
    Jt = {
        key: "US",
        component: () => l(() =>
            import ("./index.BmrkGTvt.js"), __vite__mapDeps([430, 1, 2, 57, 11, 12, 13, 14, 15, 431, 422, 22, 5, 23, 16, 7, 58, 59, 6, 60, 10, 61, 423, 424, 425, 426, 427, 236])).then(o => o.default),
        condition: ({
            data: {
                isBlocked: o,
                country: e
            }
        }) => o && e === w.US,
        persistent: !0
    },
    nn = {
        header: ({
            site: o
        }) => ({
            id: "Sorry, {site} is not available in your region, but Stake.us is!",
            values: {
                site: o
            }
        }),
        body: [r._("Due to our gaming license, we cannot accept customers from the United States. However you are welcome to signup for our social casino Stake.us")],
        cta: r._("Start Playing on Stake.us")
    },
    Xt = {
        key: "PE",
        component: () => l(() =>
            import ("./index.BxCwdXZg.js"), __vite__mapDeps([432, 1, 2, 57, 11, 12, 13, 14, 15, 422, 22, 5, 23, 16, 7, 58, 59, 6, 60, 10, 61, 423, 424, 425, 426, 427, 236])).then(o => o.default),
        condition: ({
            data: {
                isDiscontinuedBlocked: o,
                country: e
            }
        }) => o && e === w.PE
    },
    sn = {
        header: r._("Notice to Customers Located in Peru"),
        body: [r._("Your current IP address suggests you're located in Peru."), r._("You can only use Stake.pe to continue gambling with us."), r._("If you have unclaimed funds on Stake.com, email us at support@stake.com"), r._("Stake will never hold, freeze or confiscate your funds or unclaimed bonuses.")],
        cta: r._("Start Playing on Stake.pe")
    },
    $t = {
        key: "default",
        component: () => l(() =>
            import ("./index.CkesYgi5.js"), __vite__mapDeps([433, 1, 2, 57, 431, 11, 12, 13, 14, 15, 422, 22, 5, 23, 16, 7, 58, 59, 6, 60, 10, 61, 423, 424, 425, 426, 427, 236])).then(o => o.default),
        condition: ({
            data: {
                isBlocked: o,
                country: e
            }
        }) => G === "sweeps",
        persistent: !0
    },
    an = {
        header: r._("Sorry Stake.us is only available to customers from the United States, try Stake.com"),
        body: [r._("Unfortunately Stake.us cannot accept customers outside the United States.")],
        cta: r._("Start Playing on Stake.com")
    },
    b = {
        gb: Qt,
        ontario: zt,
        colombia: xt,
        us: Jt,
        pe: Xt,
        defaultRedirect: $t
    },
    M = {
        restrictions: b,
        getKey: o => {
            const e = Object.values(b).find(i => {
                if (i.condition(o)) return i.key
            });
            return (e == null ? void 0 : e.key) ? ? null
        },
        getRestriction: o => Object.values(b).find(e => e.key === o) ? ? null
    },
    eo = {
        key: "US-MI",
        component: () => l(() =>
            import ("./index.C1zskijt.js"), __vite__mapDeps([434, 1, 2, 57, 435, 11, 12, 13, 14, 15, 422, 22, 5, 23, 16, 7, 58, 59, 6, 60, 10, 61, 423, 424, 425, 426, 236])).then(o => o.default),
        condition: ({
            data: {
                isDiscontinuedBlocked: o,
                state: e,
                country: i
            }
        }) => G === "sweeps"
    },
    rn = {
        header: r._("Notice to Customers Located in Michigan"),
        body: [r._("Based on your IP address, it seems you are currently located within Michigan."), r._("Due to a change in local regulation, Stake is unable to accept registrations from customers who are located within your state. However, if you have tokens or any unclaimed bonuses on your account you can continue to redeem as usual."), r._("Stake will never hold, freeze or confiscate your tokens or unclaimed bonuses.")]
    },
    to = {
        key: "US",
        component: () => l(() =>
            import ("./index.Dg-QYPcw.js"), __vite__mapDeps([436, 1, 2, 57, 435, 11, 12, 13, 14, 15, 422, 22, 5, 23, 16, 7, 58, 59, 6, 60, 10, 61, 423, 424, 425, 426, 236])).then(o => o.default),
        condition: ({
            data: {
                isBlocked: o,
                country: e,
                info: i,
                state: s
            }
        }) => !1
    },
    ln = {
        header: ({
            region: o
        }) => ({
            id: "Sorry, Stake.us is not available in {region}",
            values: {
                region: o
            }
        }),
        body: [({
            region: o
        }) => ({
            id: "Unfortunately we are not allowed to accept customers from the state of {region}. If you are not located in {region}, please disregard this notice.",
            values: {
                region: o
            }
        })]
    },
    oo = {
        key: "default",
        component: () => l(() =>
            import ("./index.DBva-sFz.js"), __vite__mapDeps([437, 1, 2, 57, 11, 12, 13, 14, 15, 422, 22, 5, 23, 16, 7, 58, 59, 6, 60, 10, 61, 423, 424, 425, 426, 236, 438])).then(o => o.default),
        condition: ({
            data: {
                isBlocked: o
            },
            page: e
        }) => o && !e.url.pathname.startsWith(Y(Q.blog, e.params.lang)),
        persistent: !0
    },
    cn = {
        header: ({
            site: o
        }) => ({
            id: "Sorry, {site} is not available in your region",
            values: {
                site: o
            }
        }),
        body: [({
            country: o,
            email: e
        }) => ({
            id: "Due to our gaming license, we cannot accept players from {country}. Contact us via support or email at {email} if you require further assistance.",
            values: {
                country: o,
                email: e
            }
        })]
    },
    no = {
        key: "softBlocked",
        component: () => l(() =>
            import ("./index.D8ZQohQD.js"), __vite__mapDeps([439, 1, 2, 57, 11, 12, 13, 14, 15, 422, 22, 5, 23, 16, 7, 58, 59, 6, 60, 10, 61, 423, 424, 425, 426, 236, 438])).then(o => o.default),
        condition: ({
            data: {
                isSoftBlocked: o,
                country: e
            },
            page: i,
            meta: s
        }) => e === w.IT && o && !s.isAuthenticated && !i.url.pathname.startsWith(Y(Q.blog, i.params.lang))
    },
    un = {
        header: ({
            site: o
        }) => ({
            id: "Sorry, {site} is not available in your region",
            values: {
                site: o
            }
        }),
        body: [({
            country: o,
            email: e
        }) => ({
            id: "Due to our gaming license, we cannot accept players from {country}. Contact us via support or email at {email} if you require further assistance.",
            values: {
                country: o,
                email: e
            }
        })]
    },
    Z = {
        michigan: eo,
        insideUSFromSweeps: to,
        defaultBlock: oo,
        softBlocked: no
    },
    N = {
        restrictions: Z,
        getKey: o => {
            const e = Object.values(Z).find(i => {
                if (i.condition(o)) return i.key
            });
            return (e == null ? void 0 : e.key) ? ? null
        },
        getRestriction: o => Object.values(Z).find(e => e.key === o) ? ? null
    },
    io = {
        component: () => l(() =>
            import ("./index.ChuNlIgD.js"), __vite__mapDeps([440, 1, 67, 2, 321, 12, 322, 5, 323, 11, 13, 14, 15, 94, 324, 63, 64, 114, 115, 6, 7, 116, 117])),
        removeSearchParams: ["country", "region", "dir", "key"],
        header: null,
        persistent: ({
            key: o,
            dir: e
        }) => {
            if (e === "redirect") {
                const s = M.getRestriction(o);
                return s ? s.persistent ? ? !1 : !0
            }
            const i = N.getRestriction(o);
            return i ? i.persistent ? ? !1 : !0
        },
        legallyDark: ({
            key: o,
            dir: e
        }) => {
            if (e === "redirect") {
                const s = M.getRestriction(o);
                return (s == null ? void 0 : s.legallyDark) ? ? !1
            }
            const i = N.getRestriction(o);
            return (i == null ? void 0 : i.legallyDark) ? ? !1
        }
    },
    so = {
        component: () => l(() =>
            import ("./index.Ckrm8qkl.js"), __vite__mapDeps([441, 1, 2, 57, 11, 12, 13, 14, 15, 321, 322, 5, 323, 94, 324, 22, 23, 63, 64, 58, 59, 6, 7, 60, 16, 10, 123, 442])),
        title: r._("Self Excluded"),
        removeSearchParams: [],
        restricted: m,
        persistent: !0
    },
    ao = {
        component: () => l(() =>
            import ("./index.HIeGUq4t.js"), __vite__mapDeps([443, 1, 2, 11, 12, 13, 14, 15, 69, 5, 68, 70, 34, 10, 35, 27, 36, 37, 30, 38, 39, 40, 22, 23, 89, 81, 57, 74, 75, 78, 82, 83, 91, 16, 7, 4, 6, 8, 9, 61, 60, 42, 43, 244, 63, 64])),
        title: r._("Self Exclusion"),
        removeSearchParams: ["key"],
        icon: H
    },
    ro = {
        component: () => l(() =>
            import ("./index.D552V4c0.js"), __vite__mapDeps([444, 1, 2, 57, 16, 7, 14, 22, 5, 23, 63, 64, 59, 11, 12, 13, 15, 6, 60, 237, 238, 4, 8, 9, 10, 61])),
        title: r._("Server Seed Changed"),
        icon: re,
        restricted: m
    },
    lo = {
        component: () => l(() =>
            import ("./index.BwLxXbkX.js"), __vite__mapDeps([445, 1, 2, 11, 12, 13, 14, 15, 63, 64, 313, 5, 16, 7, 36, 27, 37, 30, 61, 60, 6, 22, 23])),
        title: r._("Session Expired"),
        icon: j
    };
r._("Manage Postback"), q;
const co = {
        component: () => l(() =>
            import ("./index.BNKhA_XP.js"), __vite__mapDeps([446, 1, 2, 447, 57, 11, 12, 13, 14, 15, 262, 10, 237, 58, 5, 59, 6, 7, 60, 16, 238, 263, 39, 42, 43, 50, 51, 264, 54, 265, 218, 73, 22, 23, 38, 24, 25, 26, 27, 28, 29, 74, 75, 76, 77, 78, 79, 80, 61, 219, 32, 33, 19, 20, 21, 30, 31, 223, 221, 137, 210, 158, 159, 160, 211, 198, 36, 37, 199, 212, 150, 151, 152, 47, 48, 49, 35, 52, 53, 55, 213, 214, 138, 139, 215, 216, 217, 220, 222, 266, 114, 115, 116, 117, 260, 261, 56, 448, 364, 449, 450, 451, 452, 333])),
        title: r._("Slide Game"),
        icon: S,
        removeSearchParams: ["gameId"]
    },
    uo = {
        component: () => l(() =>
            import ("./index.B4qbwh5l.js"), __vite__mapDeps([453, 1, 2, 11, 12, 13, 14, 15, 16, 7, 22, 5, 23, 34, 10, 35, 27, 36, 37, 30, 38, 39, 40, 63, 64, 61, 60, 6])),
        title: r._("Sportsbook Disabled"),
        icon: Ie
    },
    _o = {
        component: () => l(() =>
            import ("./index.C7klA33a.js"), __vite__mapDeps([454, 1, 2, 63, 64, 69, 5, 11, 12, 13, 14, 15, 68, 70, 41, 10, 38, 118, 32, 33, 22, 23, 119, 56, 120, 76, 74, 75, 77, 91, 16, 7, 4, 6, 8, 9, 61, 60, 121, 114, 115, 116, 117, 34, 35, 27, 36, 37, 30, 39, 40, 122, 57, 58, 59, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 48, 49, 43, 50, 51, 52, 53, 54, 141, 19, 20, 21, 24, 25, 26, 28, 29, 31, 142, 42, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 82, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185])),
        title: r._("Terms and Conditions"),
        icon: D,
        persistent: !0,
        restricted: m
    },
    mo = {
        component: () => l(() =>
            import ("./index.C7klA33a.js"), __vite__mapDeps([454, 1, 2, 63, 64, 69, 5, 11, 12, 13, 14, 15, 68, 70, 41, 10, 38, 118, 32, 33, 22, 23, 119, 56, 120, 76, 74, 75, 77, 91, 16, 7, 4, 6, 8, 9, 61, 60, 121, 114, 115, 116, 117, 34, 35, 27, 36, 37, 30, 39, 40, 122, 57, 58, 59, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 48, 49, 43, 50, 51, 52, 53, 54, 141, 19, 20, 21, 24, 25, 26, 28, 29, 31, 142, 42, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 82, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185])),
        title: r._("Terms and Conditions"),
        icon: D,
        persistent: !1,
        restricted: m
    },
    vo = {
        component: () => l(() =>
            import ("./index.Bc8CKQff.js"), __vite__mapDeps([455, 1, 2, 63, 64, 69, 5, 11, 12, 13, 14, 15, 68, 70, 342, 57, 343, 276, 277, 25, 28, 159, 16, 7, 61, 60, 6, 26, 278, 279, 172, 10, 82, 22, 23, 49, 43, 280, 251, 20, 164, 165, 35, 27, 36, 37, 30, 19, 21, 24, 29, 31, 281, 73, 38, 74, 75, 76, 77, 78, 79, 80, 282, 283, 284, 236, 344, 85, 345, 89, 81, 83, 346, 347, 200, 45, 41, 104, 42, 4, 8, 9, 105, 102, 348, 304, 305, 306, 307, 91])),
        title: r._("Two Factor"),
        icon: z,
        restricted: m
    },
    fo = {
        races: r._("Races"),
        statistics: r._("Statistics"),
        trophies: r._("Trophies"),
        raffles: r._("Raffles"),
        signIn: r._("You need to be signed in to do that..."),
        register: r._("Register"),
        login: r._("Sign In"),
        user: r._("User"),
        account: r._("Account")
    },
    ho = {
        component: () => l(() =>
            import ("./index.DdrXw2Cq.js"), __vite__mapDeps([456, 1, 2, 11, 12, 13, 14, 15, 22, 5, 23, 260, 261, 32, 33, 16, 7, 17, 18, 177, 10, 178, 134, 179, 221, 19, 20, 21, 24, 25, 26, 27, 6, 28, 29, 30, 31, 57, 277, 159, 61, 60, 278, 279, 172, 82, 280, 251, 49, 43, 74, 75, 164, 165, 341, 4, 8, 9, 42, 457, 35, 36, 37, 283, 158, 160, 39, 152, 211, 198, 199, 212, 150, 151, 47, 48, 50, 51, 52, 53, 54, 55, 213, 214, 458, 459, 460, 461, 395, 396, 397, 462, 463, 94, 137, 142, 248, 249, 250, 41, 38, 79, 253, 385, 383, 384, 124, 114, 115, 116, 117, 125, 59, 56, 63, 64, 67, 464, 465, 81, 78, 83, 291, 99, 292, 293, 100, 294, 295, 133, 101, 103, 296, 297, 298, 98, 299, 300, 222, 237, 238, 466])),
        title: o => `${fo[o.tab??"statistics"]}`,
        icon: Re,
        removeSearchParams: ["name", "tab"]
    },
    go = {
        component: () => l(() =>
            import ("./index.eKtawbnV.js"), __vite__mapDeps([467, 1, 2, 57, 11, 12, 13, 14, 15, 260, 5, 261, 16, 7, 468, 59, 6, 60, 22, 23, 198, 36, 27, 37, 30, 199, 237, 238, 469, 63, 64, 10, 19, 20, 21, 24, 25, 26, 28, 29, 31, 142, 69, 68, 70, 91, 4, 8, 9, 61, 202, 42, 43, 347, 200, 45, 41, 38, 104, 105, 102, 348, 85, 73, 74, 75, 76, 77, 78, 79, 80, 304, 305, 306, 164, 165, 307, 346, 343, 276, 277, 159, 278, 279, 172, 82, 49, 280, 251, 35, 281, 282, 283, 284, 236, 351, 470])),
        title: r._("Vault"),
        icon: xe
    },
    yo = {
        component: () => l(() =>
            import ("./index.B1bBPO6o.js"), __vite__mapDeps([471, 1, 2, 11, 12, 13, 14, 15, 63, 64, 330, 57, 22, 5, 23, 16, 7, 61, 60, 6, 331, 114, 115, 116, 117, 357, 34, 10, 35, 27, 36, 37, 30, 38, 39, 40, 17, 18, 358, 231, 110, 111, 359, 313, 68, 85, 73, 24, 25, 26, 28, 29, 74, 75, 76, 77, 78, 79, 80, 69, 70, 89, 81, 82, 83, 120, 91, 4, 8, 9, 90, 32, 33, 338, 238, 472])),
        title: r._("Identity verification"),
        icon: H,
        persistent: !0,
        restricted: m
    },
    po = {
        component: () => l(() =>
            import ("./index.CRzUBLDh.js"), __vite__mapDeps([473, 1, 2, 68, 11, 12, 13, 14, 15, 69, 5, 70, 42, 43, 85, 73, 10, 22, 23, 38, 24, 25, 26, 27, 6, 7, 28, 29, 74, 75, 76, 77, 78, 79, 80, 91, 16, 4, 8, 9, 61, 60, 63, 64])),
        title: r._("Verify Phone"),
        icon: Fe
    };
r._("Postback History"), S;
r._("Terms Of Service");
const Eo = {
        component: () => l(() =>
            import ("./index.CoDDQPu5.js"), __vite__mapDeps([474, 1, 2, 231, 57, 260, 5, 261, 114, 115, 12, 6, 7, 116, 117, 59, 11, 13, 14, 15, 60, 16, 63, 64, 10, 475, 198, 36, 27, 37, 30, 199, 22, 23, 458, 213, 459, 24, 25, 26, 28, 29, 460, 461, 395, 396, 397, 462, 463, 212, 94, 39, 297, 133, 35, 19, 20, 21, 31, 286, 330, 61, 331, 476, 477, 171, 172, 82, 173, 400, 401, 402, 58, 123, 142, 69, 68, 70, 91, 4, 8, 9, 42, 43, 343, 276, 277, 159, 278, 279, 49, 280, 251, 164, 165, 281, 73, 38, 74, 75, 76, 77, 78, 79, 80, 282, 283, 284, 236, 151, 152, 188, 189, 41, 305, 306, 307, 32, 33, 478, 177, 178, 134, 179, 237, 238, 479, 110, 111, 480])),
        title: r._("VIP"),
        icon: S
    },
    Po = {
        component: () => l(() =>
            import ("./index.DaopSbLI.js"), __vite__mapDeps([481, 1, 2, 468, 59, 5, 11, 12, 13, 14, 15, 6, 7, 60, 16, 22, 23, 198, 36, 27, 37, 30, 199, 237, 238, 469, 114, 115, 116, 117, 357, 34, 10, 35, 38, 39, 40, 17, 18, 358, 61, 231, 57, 110, 111, 359, 482, 73, 24, 25, 26, 28, 29, 74, 75, 76, 77, 78, 79, 80, 352, 341, 276, 277, 159, 278, 279, 172, 82, 49, 43, 280, 251, 20, 164, 165, 19, 21, 31, 281, 282, 283, 284, 236, 41, 42, 47, 48, 50, 51, 52, 53, 54, 55, 192, 191, 483, 195, 197, 63, 64, 367, 401, 402, 68, 69, 70, 32, 33, 189, 478, 177, 178, 134, 179, 461, 395, 396, 397, 479, 351, 350, 293, 202, 4, 8, 9, 85, 91, 344, 345, 353, 347, 200, 45, 104, 105, 102, 348, 304, 305, 306, 307, 346, 308, 309, 310, 209, 210, 158, 160, 211, 212, 150, 151, 152, 213, 214, 138, 139, 215, 216, 56, 142, 246, 247, 248, 249, 250, 252, 92, 3, 44, 46, 58, 62, 285, 484, 485, 354, 415, 239, 130, 260, 261, 330, 331, 123, 486, 487, 227, 488, 218, 219, 489, 490, 94, 491, 492, 153, 154, 221, 126, 493, 494, 188, 495, 496, 67, 497])),
        header: () => l(() =>
            import ("./index.BHp-3GN3.js"), __vite__mapDeps([498, 1, 2, 16, 7, 14, 22, 5, 23, 11, 12, 13, 15, 236, 482, 73, 10, 38, 24, 25, 26, 27, 6, 28, 29, 74, 75, 76, 77, 78, 79, 80, 352, 341, 276, 277, 159, 61, 60, 278, 279, 172, 82, 49, 43, 280, 251, 57, 20, 164, 165, 35, 36, 37, 30, 19, 21, 31, 281, 282, 283, 284, 41, 42, 47, 48, 50, 51, 52, 53, 54, 55, 192, 191, 483, 195, 197, 63, 64, 34, 39, 40, 367, 115, 116, 114, 117, 401, 402, 68, 69, 70, 32, 33, 189, 478, 177, 178, 134, 179, 461, 395, 396, 397, 59, 237, 238, 479, 351, 350, 293, 202, 4, 8, 9, 85, 91, 344, 345, 353, 347, 200, 45, 104, 105, 102, 348, 304, 305, 306, 307, 346, 308, 309, 310, 209, 210, 158, 160, 211, 198, 199, 212, 150, 151, 152, 213, 214, 138, 139, 215, 216, 56, 142, 246, 247, 248, 249, 250, 252, 92, 3, 17, 18, 44, 46, 58, 62, 285, 484, 485, 354, 110, 111, 415, 239, 130, 260, 261, 330, 331, 123, 486, 487, 227, 488, 218, 219, 489, 490, 94, 491, 492, 153, 154, 221, 126, 358, 493])),
        removeSearchParams: ["currency", "fiat", "name", "tab", "chain"],
        restricted: m
    },
    So = {
        component: () => l(() =>
            import ("./index.CEKDzRsq.js"), __vite__mapDeps([499, 1, 2, 57, 10, 20, 11, 12, 13, 14, 15, 16, 7, 76, 5, 74, 75, 22, 23, 38, 77, 63, 64, 309, 6, 310, 61, 60, 500])),
        title: r._("Wallet Settings"),
        icon: $e
    },
    Lo = {
        component: () => l(() =>
            import ("./index.D8Vi5kFO.js"), __vite__mapDeps([501, 1, 2, 114, 115, 12, 6, 7, 116, 117, 57, 16, 14, 32, 5, 33, 22, 23, 11, 13, 15, 10, 61, 60, 486, 251, 502, 67, 68, 69, 70, 72, 73, 38, 24, 25, 26, 27, 28, 29, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 89, 91, 4, 8, 9, 317, 34, 35, 36, 37, 30, 39, 40, 112, 86, 87, 110, 111, 90, 247, 42, 43, 227, 280, 49, 271, 178, 503, 315, 316, 188, 189, 41, 88, 308, 309, 310, 318, 494, 495, 341, 496, 504])),
        restricted: m,
        header: () => l(() =>
            import ("./index.DkKgEBic.js"), __vite__mapDeps([320, 1, 2, 11, 12, 13, 14, 15, 321, 322, 5, 323, 94, 324, 16, 7, 61, 60, 6, 325])),
        fullScreenMobile: !0,
        size: "lg",
        overscrollBehavior: "none"
    },
    ko = {
        component: () => l(() =>
            import ("./index.zN-vqw_u.js"), __vite__mapDeps([505, 1, 67, 2, 57, 5, 11, 12, 13, 14, 15, 22, 23, 10, 48, 49, 43, 36, 27, 37, 30, 35, 50, 51, 52, 53, 54, 55, 42, 210, 158, 21, 159, 24, 25, 26, 6, 7, 28, 29, 160, 211, 198, 199, 212, 150, 151, 152, 16, 61, 60, 47, 213, 214, 138, 139, 215, 216, 464, 221, 19, 20, 31, 506, 98, 114, 115, 116, 117, 34, 38, 39, 40, 507])),
        title: r._("Leaderboard"),
        icon: le,
        restricted: m
    },
    Io = {
        component: () => l(() =>
            import ("./index.DKJT1W9s.js"), __vite__mapDeps([508, 1, 2, 16, 7, 14, 17, 12, 18, 32, 5, 33, 22, 23, 11, 13, 15, 61, 60, 6, 336])),
        restricted: m,
        header: null
    },
    Ro = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "query",
            name: {
                kind: "Name",
                value: "GetCashierConfigurationByCountry"
            },
            variableDefinitions: [{
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "country"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "CountryEnum"
                        }
                    }
                }
            }],
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "cashierConfigurationByCountry"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "country"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "country"
                            }
                        }
                    }],
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "restricted"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "country"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currency"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "provider"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "transactionType"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "createdAt"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "updatedAt"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "updatedBy"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "configUsers"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "userId"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }]
    },
    Oo = async (o, e) => {
        var s, a;
        const i = await ee({
            doc: Ro,
            variables: {
                country: e
            },
            load: {
                fetch
            }
        });
        if ((s = i.data) != null && s.cashierConfigurationByCountry) {
            const n = (a = i.data) == null ? void 0 : a.cashierConfigurationByCountry,
                t = n.restricted,
                k = n.configUsers.filter(V => V.userId === o).length === 1;
            if (t && k) return !0;
            if (t) return !1
        }
        return !0
    },
    Vo = {
        activateDepositBonus: nt,
        automatedDepositBonus: at,
        auth: st,
        bet: ct,
        earlyAccess: yt,
        chatControls: _t,
        chatRules: mt,
        crashGame: vt,
        createCampaign: ht,
        createChallenge: gt,
        externalLink: Et,
        fairness: Pt,
        forgotPassword: kt,
        fundRetrieval: Rt,
        limited: wt,
        kycBanned: Vt,
        logout: Ct,
        landingPagePromotion: Tt,
        moderation: Zt,
        webpush: Mt,
        promotion: Nt,
        promotions: Bt,
        purchaseConfirmed: Ht,
        rain: Ut,
        redeemBonus: Yt,
        redemptionConfirmed: Gt,
        registerOauth: qt,
        resetPassword: jt,
        restrictedRegion: io,
        requestPostcardCode: Wt,
        selfExclusion: ao,
        immediateSelfExclusion: Ot,
        breakInPlay: ut,
        selfExcluded: so,
        serverSeedBlocked: ro,
        sessionExpire: lo,
        sportsbookExcluded: uo,
        slideGame: co,
        tfaToken: vo,
        user: ho,
        vault: go,
        verifyPhone: po,
        vip: Eo,
        veriffRequired: yo,
        wallet: Po,
        termsAndConditions: _o,
        termsAndConditionsError: mo,
        locationCheck: Dt,
        fitToPlay: Lt,
        raceLeaderboard: ko,
        walletSettings: So,
        managePostbacks: bt,
        raffleTickets: Ft,
        continueSetup: dt,
        enableLocalCurrency: pt,
        finishedSetup: St,
        kycRejected: At,
        walletSetup: Lo,
        welcome: Io
    },
    O = it(Vo),
    Ao = I.values(O).map(o => o.removeSearchParams || []),
    X = I.flatten(Ao),
    T = o => {
        const e = R.parse(location.search),
            i = e[L];
        if (o ? i === o : i) {
            const s = i || o,
                {
                    removeSearchParams: a
                } = O[s],
                n = a || X,
                t = [...s === void 0 || e[L] === s ? [L] : [], ...n],
                k = R.stringify(I.omit(e, t)),
                V = k ? `?${k}` : "",
                A = `${window.location.pathname}${V}`;
            if (`${window.location.pathname}${window.location.search}` !== A) return B(A, {
                noScroll: !0
            })
        }
    },
    To = o => {
        const {
            searchParams: e,
            pathname: i
        } = o.url, s = R.parse(e.toString()), a = s.modal;
        if (a) {
            const n = a,
                {
                    removeSearchParams: t
                } = O[n],
                k = t || X,
                V = [...n === void 0 || s[L] === n ? [L] : [], ...k],
                A = R.stringify(I.omit(s, V)),
                F = A ? `?${A}` : "",
                U = `${i}${F}`;
            if (`${i}${o.url.search}` !== U) return B(U, {
                noScroll: !0
            })
        }
    },
    wo = te(),
    Do = async (o, e, i) => {
        i == null || i.roles;
        const s = o.country,
            a = o.state,
            n = M.getKey({
                data: o,
                page: e,
                meta: i
            });
        if (n) {
            await T("restrictedRegion"), O.restrictedRegion.open({
                key: n,
                country: s ? ? "none",
                region: a ? ? "none",
                dir: "redirect"
            });
            return
        }
        const t = N.getKey({
            data: o,
            page: e,
            meta: i
        });
        if (t) {
            await T("restrictedRegion"), O.restrictedRegion.open({
                key: t,
                country: s ? ? "none",
                region: a ? ? "none",
                dir: "block"
            });
            return
        }
        T("restrictedRegion"), T("limited")
    },
    Co = async (o, e) => o !== void 0 && e !== void 0 ? await Oo(o, e) : !1,
    _n = Object.freeze(Object.defineProperty({
        __proto__: null,
        closeModal: T,
        closeModalInstant: To,
        fetchIsUserEligibleForPIQCashier: Co,
        modalEmitter: wo,
        modals: O,
        regionRestrictedModalHandler: Do
    }, Symbol.toStringTag, {
        value: "Module"
    }));
export {
    we as C, z as K, Me as L, K as N, Fe as P, Ge as R, je as S, xe as V, $e as W, rn as a, ln as b, T as c, cn as d, un as e, tn as f, nn as g, an as h, en as i, on as j, sn as k, Oo as l, O as m, Kt as n, N as o, wo as p, D as q, M as r, fo as s, Co as t, To as u, Do as v, _n as w
};