import {
    _ as N,
    av as c
} from "./index.B4-7gKq3.js";
import {
    W as w,
    r as d,
    S as y,
    R as P
} from "./constants.DX75DoF3.js";
import {
    a as R
} from "./index.B81orGJm.js";
var p = (e => (e[e.win = 0] = "win", e[e.runner = 1] = "runner", e))(p || {});
const j = e => {
        if (e) {
            const t = parseInt(e.split(":")[0]);
            return parseInt(e.split(" ")[1]) / t * 100
        }
    },
    M = e => {
        if (e) {
            const t = parseInt(e.split(":")[0]),
                n = parseInt(e.split(" ")[1]),
                s = parseInt(e.split(" ")[2]),
                i = parseInt(e.split(" ")[3]);
            return (n + s + i) / t * 100
        }
    };

function v({
    sortState: e,
    runners: t,
    isJapanese: n = !1
}) {
    return t.sort((s, i) => {
        if (s.scratched) return 1;
        if (i.scratched) return -1;
        if ((e == null ? void 0 : e.id) === p.win) {
            const a = n ? "jpWin" : "win",
                r = s.prices.find(u => u.marketName === a),
                o = i.prices.find(u => u.marketName === a);
            return e.direction === "ascending" ? ((r == null ? void 0 : r.odds) || 0) - ((o == null ? void 0 : o.odds) || 0) : ((o == null ? void 0 : o.odds) || 0) - ((r == null ? void 0 : r.odds) || 0)
        }
        if ((e == null ? void 0 : e.id) === p.runner) {
            const [a, r] = [parseInt(s.runnerNumber), parseInt(i.runnerNumber)];
            return e.direction === "ascending" ? a - r : r - a
        }
        return 0
    })
}

function x(e) {
    return e.reduce((t, n) => ({ ...t,
        [n.market.name]: n
    }), {})
}

function E(e = c.REFUNDED) {
    return e === c.WON ? "win" : e === c.LOST ? "lose" : "void"
}

function _(e, t, n) {
    var u, f, m, D;
    const s = e.reduce((T, g) => ({ ...T,
            [g.name]: g
        }), {}),
        i = ((u = s.SpWin) == null ? void 0 : u.enabled) === !1 && ((f = s.SpPlace) == null ? void 0 : f.enabled) === !1,
        a = ((m = s.Win) == null ? void 0 : m.enabled) === !1 && ((D = s.Place) == null ? void 0 : D.enabled) === !1 && !i,
        r = !t && !a,
        o = [];
    return a || o.push({
        id: w,
        route: "",
        markets: ["win", "place"],
        label: d.fixed,
        disabled: r
    }), i || o.push({
        id: y,
        route: "starting-price",
        markets: ["SpWin", "SpPlace"],
        label: n ? d.jpSpFull : d.spFull
    }), o
}

function b({
    marketName: e,
    prices: t
}) {
    let n = t.find(s => s.market.name === e);
    return e === "jpWin" && n === null && (e = "win", n = t.find(s => s.market.name === e)), n ? [n.openingOdds, n.previousOdds, n.odds].filter(s => typeof s == "number") : []
}
const C = e => e.toLowerCase().split(" ").map(t => N.capitalize(t)).join(" "),
    O = new RegExp(/^\d{4}-(1[0-2]|0?[1-9])-(3[01]|[12][0-9]|0?[1-9])$/),
    F = e => {
        const t = new Date(e);
        return t.setDate(t.getDate() + 7), t.toISOString().split("T")[0]
    },
    A = e => {
        if (!e) return {
            startDateTime: new Date().setHours(0, 0, 0, 0),
            endDateTime: new Date().setHours(23, 59, 59, 999)
        };
        if (O.test(e)) {
            const [t, n, s] = e.split("-");
            return {
                startDateTime: new Date(Number(t), Number(n) - 1, Number(s)).getTime(),
                endDateTime: new Date(Number(t), Number(n) - 1, Number(s)).setHours(23, 59, 59, 999)
            }
        }
        if (e === "today") return {
            startDateTime: new Date().setHours(0, 0, 0, 0),
            endDateTime: new Date().setHours(23, 59, 59, 999)
        };
        if (e === "tomorrow") {
            const t = new Date;
            return t.setDate(t.getDate() + 1), {
                startDateTime: t.setHours(0, 0, 0, 0),
                endDateTime: t.setHours(23, 59, 59, 999)
            }
        }
        if (e === "yesterday") {
            const t = new Date;
            return t.setDate(t.getDate() - 1), {
                startDateTime: t.setHours(0, 0, 0, 0),
                endDateTime: t.setHours(23, 59, 59, 999)
            }
        }
        return {
            startDateTime: new Date().setHours(0, 0, 0, 0),
            endDateTime: new Date().setHours(23, 59, 59, 999)
        }
    },
    J = e => {
        const t = {};
        return e.forEach(n => {
            typeof n.finalPosition == "number" && (t[n.finalPosition] ? t[n.finalPosition] = `${t[n.finalPosition]}/${n.runnerNumber}` : t[n.finalPosition] = n.runnerNumber.toString())
        }), Object.values(t).slice(0, 3).join(",")
    },
    L = e => {
        const t = R ? new Date(P) : new Date;
        if (e === "today") return t;
        if (e === "tomorrow") return t.setDate(t.getDate() + 1), t;
        if (e === "yesterday") return t.setDate(t.getDate() - 1), t;
        if (O.test(e)) {
            const [n, s, i] = e.split("-");
            return new Date(Number(n), Number(s) - 1, Number(i))
        }
        return t
    },
    $ = e => ["closed", "resulting", "finished", "suspended", "protest", "protest_dismissed", "protest_upheld", "dormant", "false_start"].includes(e) ? "closed" : e === "abandoned" ? "abandoned" : ["result", "final", "interim"].includes(e) ? "resulted" : "upcoming",
    l = (e, t) => {
        var i, a;
        const n = (i = e.result) == null ? void 0 : i.resultedPrices;
        if (n) try {
            const r = JSON.parse(n);
            if (r["*"]) {
                const o = Number(r["*"]);
                if (!isNaN(o)) return o
            }
        } catch {}
        return ((a = e.prices.find(r => (t === "win" ? ["win", "jpWin"] : ["place", "jpPlace"]).includes(r.marketName))) == null ? void 0 : a.odds) ? ? 0
    },
    h = e => {
        let t = 1;
        return e.outcomes.forEach(n => {
            let s = 0;
            n.type === "each_way" ? (s += l(n, "win"), s += l(n, "place"), s /= 2) : ["win", "place"].includes(n.type) && (s += l(n, n.type.toString())), t *= s
        }), t
    },
    k = (e, t = h(e)) => {
        var s, i;
        const n = e.adjustments.reduce((a, r) => a + r.payoutMultiplier, e.payoutMultiplier || 0);
        return (i = (s = e == null ? void 0 : e.betStatus) == null ? void 0 : s.startsWith) != null && i.call(s, "rejected") && (e != null && e.betPotentialMultiplier) ? t || e.betPotentialMultiplier : n || (e == null ? void 0 : e.payoutMultiplier) || t || (e == null ? void 0 : e.betPotentialMultiplier) || 0
    },
    z = e => {
        const t = new Date().setHours(0, 0, 0, 0);
        return e.setHours(0, 0, 0, 0) === t
    },
    G = e => {
        const t = /^(Mrs|Miss|Mr|Ms|Master|Sir|Lady|Lord|Jr|Sr|Dame|Dr|Prof|)$/gi,
            n = /^(Jr|Sr|Jnr|Snr|\(Jnr\)|\(Snr\))$/gi,
            s = e.trim().split(" "),
            i = s.at(-1) && n.test(s.at(-1)) ? s.pop() : void 0,
            a = t.test(s[0]) ? s.shift() : void 0,
            r = s[0],
            o = s.slice(1, -1).join(" "),
            u = s.at(-1) !== r ? s.at(-1) : void 0;
        return {
            title: a,
            firstName: r,
            middleNames: o,
            lastName: u,
            suffix: i
        }
    },
    S = e => Math.floor((new Date(e).getTime() - Date.now()) / 1e3) < 5 * 60;
export {
    p as S, x as a, C as b, $ as c, G as d, E as e, A as f, L as g, l as h, S as i, h as j, k, z as l, j as m, M as n, b as o, _ as p, F as r, v as s, J as t
};