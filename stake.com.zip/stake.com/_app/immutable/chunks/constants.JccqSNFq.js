import {
    h as o,
    _ as P,
    cG as y,
    cH as S,
    cI as k,
    cJ as I,
    aJ as l
} from "./index.B4-7gKq3.js";
const t = {
        baccarat: o._("Baccarat"),
        blackjack: o._("Blackjack"),
        diamonds: o._("Diamonds"),
        dice: o._("Dice"),
        hilo: o._("Hilo"),
        keno: o._("Keno"),
        limbo: o._("Limbo"),
        dragonTower: o._("Dragon Tower"),
        mines: o._("Mines"),
        slide: o._("Slide"),
        plinko: o._("Plinko"),
        roulette: o._("Roulette"),
        slotsSamurai: o._("Blue Samurai"),
        slots: o._("Scarab Spin"),
        wheel: o._("Wheel"),
        difficulty: o._("Difficulty"),
        videoPoker: o._("Video Poker"),
        slotsTomeOfLife: o._("Tome of Life"),
        crash: o._("Crash"),
        game: o._("Game"),
        clientSeed: o._("Client Seed"),
        serverSeed: o._("Server Seed"),
        nonce: o._("Nonce"),
        hash: o._("Hash"),
        seed: o._("Seed"),
        risk: o._("Risk"),
        row: o._("Rows"),
        segments: o._("Segments"),
        minesCount: o._("Mines"),
        roundIndex: o._("Round"),
        low: o._("Low"),
        medium: o._("Medium"),
        high: o._("High"),
        isSpecial: o._("Is special spin"),
        samuraiSlotsPreviousSpecialSpinsCount: o._("Past special free spins count")
    },
    L = ["D", "H", "S", "C"],
    A = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"],
    D = P.flatten(A.map(e => L.map(s => ({
        rank: e,
        suit: s
    })))),
    g = e => e.map(s => D[s]),
    w = [2, 3, 4, 5, 6, 7, 8, 9, 0, 0, 0, 0, 1],
    C = e => w[K(e)],
    b = e => P.sum(e.map(C)) % 10,
    K = e => Math.floor(e / 4),
    Y = [
        [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
        [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
        [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
        [1, 1, 1, 1, 1, 1, 1, 1, 0, 1],
        [0, 0, 1, 1, 1, 1, 1, 1, 0, 0],
        [0, 0, 0, 0, 1, 1, 1, 1, 0, 0],
        [0, 0, 0, 0, 0, 0, 1, 1, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    ],
    U = e => {
        const s = e;
        let a = s.slice(0, 2),
            n = s.slice(2, 4),
            p = s.slice(4, 6),
            d = b(n),
            m = b(a);
        if (d < 8 && m < 8) {
            if (m <= 5) {
                const _ = P.head(p),
                    R = C(_);
                if (p = p.slice(1), a = [...a, _], m = b(a), Y[d][R]) {
                    const M = p[0];
                    p = p.slice(1), n = [...n, M], d = b(n)
                }
            } else if (d <= 5) {
                const _ = p[0];
                p = p.slice(1), n = [...n, _], d = b(n)
            }
        }
        const E = m > d && y.player || d > m && y.banker || y.tie;
        return {
            playerCards: a,
            bankerCards: n,
            result: E
        }
    },
    z = e => {
        const {
            playerCards: s,
            bankerCards: a,
            result: n
        } = U(e);
        return {
            playerCards: g(s),
            bankerCards: g(a),
            result: n,
            scale: 1
        }
    },
    H = e => {
        const s = g(e);
        return {
            scale: 1,
            noStatus: !0,
            player: [{
                cards: [s[0], s[1]],
                value: 0,
                actions: []
            }],
            dealer: [{
                cards: [s[2], s[3]],
                value: 0,
                actions: []
            }],
            cards: s.slice(4)
        }
    },
    G = [S.green, S.purple, S.yellow, S.red, S.cyan, S.orange, S.blue],
    B = e => ({
        hand: e.map(s => G[s])
    }),
    x = ({
        rounds: e,
        difficulty: s
    }) => ({
        rounds: e,
        difficulty: s
    }),
    F = e => ({
        disabled: !0,
        target: "0",
        condition: "above",
        status: "positive",
        result: e
    }),
    W = e => ({
        scale: 1,
        startCard: null,
        rounds: g(e).map(a => ({
            card: a
        }))
    }),
    V = e => ({
        scale: 1,
        drawnNumbers: e,
        selectedNumbers: e
    }),
    j = e => ({
        value: e
    }),
    J = e => ({
        scale: 1,
        rounds: Array(25).fill(1).map((s, a) => ({
            field: a
        })),
        mines: e
    }),
    X = (e, {
        plinkoRisk: s,
        plinkoRow: a
    }) => ({
        risk: s,
        rows: Number(a),
        path: e.map(n => n ? k.R : k.L)
    }),
    q = e => ({
        stacked: !1,
        result: e,
        chips: {}
    }),
    Q = [{
        symbol: "s1",
        outer: .075,
        inner: .09
    }, {
        symbol: "s2",
        outer: .075,
        inner: .09
    }, {
        symbol: "s3",
        outer: .08,
        inner: .07
    }, {
        symbol: "s4",
        outer: .08,
        inner: .06
    }, {
        symbol: "s5",
        outer: .08,
        inner: .09
    }, {
        symbol: "s6",
        outer: .08,
        inner: .08
    }, {
        symbol: "s7",
        outer: .08,
        inner: .08
    }, {
        symbol: "s8",
        outer: .08,
        inner: .065
    }, {
        symbol: "s9",
        outer: .15,
        inner: .15
    }, {
        symbol: "samurai",
        outer: .17,
        inner: .12
    }, {
        symbol: "scatter",
        outer: 0,
        inner: .04
    }, {
        symbol: "wild",
        outer: .05,
        inner: .065
    }],
    Z = Q.reduce((e, s, a) => {
        if (a === 0) return [s]; {
            const n = e[e.length - 1],
                p = {
                    symbol: s.symbol,
                    outer: n.outer + s.outer,
                    inner: n.inner + s.inner
                };
            return [...e, p]
        }
    }, []),
    $ = (e, s) => Z.find(n => (s ? n.outer : n.inner) > e).symbol,
    ee = (e, {
        samuraiSlotsRound: s,
        samuraiSlotsIsSpecial: a
    }) => {
        const n = e.map((m, E) => {
                const _ = (() => {
                    if (e.length === 3) return !1;
                    if (e.length === 5) return E === 0 || E === 4
                })();
                return m.map(R => $(R, _))
            }),
            p = Number(s);
        return {
            currentRound: {
                type: a === "Yes" && p !== 0 ? I.special : I.regular,
                data: {
                    view: n,
                    paylines: []
                }
            }
        }
    },
    se = e => ({
        props: {
            type: "display",
            offsets: e
        }
    }),
    te = (e, {
        wheelRisk: s,
        wheelSegments: a
    }) => ({
        risk: s,
        segments: Number(a),
        multiplierIndex: e,
        multiplier: void 0,
        currency: void 0,
        amount: void 0
    }),
    oe = e => {
        const s = g(e);
        return {
            scale: 1,
            playerHand: void 0,
            initialHand: s.slice(0, 5),
            comingCards: s.slice(5, 10)
        }
    },
    ae = e => ({
        multiplier: e
    }),
    ne = e => ({
        multiplier: e
    }),
    le = e => ({
        type: "result",
        offsets: e
    }),
    re = [{
        label: t.baccarat,
        value: l.baccarat
    }, {
        label: t.blackjack,
        value: l.blackjack
    }, {
        label: t.diamonds,
        value: l.diamonds
    }, {
        label: t.dice,
        value: l.dice
    }, {
        label: t.hilo,
        value: l.hilo
    }, {
        label: t.keno,
        value: l.keno
    }, {
        label: t.limbo,
        value: l.limbo
    }, {
        label: t.mines,
        value: l.mines
    }, {
        label: t.plinko,
        value: l.plinko
    }, {
        label: t.roulette,
        value: l.roulette
    }, {
        label: t.slotsSamurai,
        value: l.slotsSamurai
    }, {
        label: t.slots,
        value: l.slots
    }, {
        label: t.wheel,
        value: l.wheel
    }, {
        label: t.videoPoker,
        value: l.videoPoker
    }, {
        label: t.crash,
        value: l.crash
    }, {
        label: t.slide,
        value: l.slide
    }, {
        label: t.dragonTower,
        value: l.dragonTower
    }, {
        label: t.slotsTomeOfLife,
        value: l.slotsTomeOfLife
    }].sort((e, s) => e.value.localeCompare(s.value)),
    ie = {
        easy: {
            count: 3,
            size: 4
        },
        medium: {
            count: 2,
            size: 3
        },
        hard: {
            count: 1,
            size: 2
        },
        expert: {
            count: 1,
            size: 3
        },
        master: {
            count: 1,
            size: 4
        }
    },
    ue = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24"].map(e => ({
        label: e,
        value: e
    })),
    T = [{
        label: t.low,
        value: "low"
    }, {
        label: t.medium,
        value: "medium"
    }, {
        label: t.high,
        value: "high"
    }],
    ce = ["8", "9", "10", "11", "12", "13", "14", "15", "16"].map(e => ({
        label: e,
        value: e
    })),
    pe = ["10", "20", "30", "40", "50"].map(e => ({
        label: e,
        value: e
    })),
    de = ["No", "Yes"].map(e => ({
        label: e,
        value: e
    })),
    me = ["easy", "medium", "hard", "expert", "master"].map(e => ({
        label: e,
        value: e
    })),
    Se = "game",
    _e = "clientSeed",
    be = "serverSeed",
    ge = "nonce",
    Ee = "hash",
    fe = "seed",
    Re = "minesCount",
    ye = "plinkoRisk",
    Pe = "plinkoRow",
    ke = "slotsRound",
    Ie = "slotsTomeOfLifeRound",
    Te = "samuraiSlotsRound",
    Oe = "samuraiSlotsIsSpecial",
    Ne = "samuraiSlotsPreviousSpecialSpinsCount",
    he = "wheelRisk",
    ve = "wheelSegments",
    Ce = "dragonTowerDifficulty",
    r = {
        type: "select",
        props: {
            key: Se,
            options: re,
            translateOptions: !0,
            label: t.game
        }
    },
    O = [{
        type: "input",
        props: {
            key: Ee,
            isNumber: !1,
            label: t.hash
        }
    }, {
        type: "input",
        props: {
            key: fe,
            isNumber: !1,
            label: t.seed
        }
    }],
    i = [{
        type: "input",
        props: {
            key: _e,
            isNumber: !1,
            label: t.clientSeed
        }
    }, {
        type: "input",
        props: {
            key: be,
            isNumber: !1,
            label: t.serverSeed
        }
    }, {
        type: "input",
        props: {
            key: ge,
            isNumber: !0,
            label: t.nonce
        }
    }],
    u = "seedsToBytes",
    c = "bytesToNumber",
    f = "shuffle",
    Me = "edged",
    N = "seedsToHex",
    h = "hexToDecimal",
    v = "multiEdged",
    Ae = {
        baccarat: {
            getResultProps: z,
            inputsMeta: [r, ...i],
            steps: [u, c],
            config: {
                size: 52,
                count: 6
            }
        },
        blackjack: {
            getResultProps: H,
            inputsMeta: [r, ...i],
            steps: [u, c],
            config: {
                size: 52,
                count: 52
            }
        },
        diamonds: {
            getResultProps: B,
            inputsMeta: [r, ...i],
            steps: [u, c],
            config: {
                size: 7,
                count: 5
            }
        },
        dice: {
            getResultProps: F,
            inputsMeta: [r, ...i],
            steps: [u, c],
            config: {
                size: 10001,
                count: 1
            }
        },
        hilo: {
            getResultProps: W,
            inputsMeta: [r, ...i],
            steps: [u, c],
            config: {
                size: 52,
                count: 100
            }
        },
        keno: {
            getResultProps: V,
            inputsMeta: [r, ...i],
            steps: [u, c, f],
            config: {
                size: 40,
                count: 10,
                isShuffle: !0
            }
        },
        limbo: {
            getResultProps: j,
            inputsMeta: [r, ...i],
            steps: [u, c, Me],
            config: {
                size: 2 ** 24,
                count: 1,
                edge: .01
            }
        },
        mines: {
            getResultProps: J,
            inputsMeta: [r, ...i, {
                type: "select",
                props: {
                    key: Re,
                    options: ue,
                    translateOptions: !1,
                    label: t.minesCount
                }
            }],
            steps: [u, c, f],
            config: {
                size: 25,
                count: 24,
                isShuffle: !0
            }
        },
        plinko: {
            getResultProps: X,
            inputsMeta: [r, ...i, {
                type: "select",
                props: {
                    key: ye,
                    options: T,
                    translateOptions: !0,
                    label: t.risk
                }
            }, {
                type: "select",
                props: {
                    key: Pe,
                    options: ce,
                    translateOptions: !1,
                    label: t.row
                }
            }],
            steps: [u, c],
            config: {
                size: 2,
                count: 20
            }
        },
        roulette: {
            getResultProps: q,
            inputsMeta: [r, ...i],
            steps: [u, c],
            config: {
                size: 37,
                count: 1
            }
        },
        slotsSamurai: {
            getResultProps: ee,
            inputsMeta: [r, ...i, {
                type: "input",
                props: {
                    key: Te,
                    isNumber: !0,
                    label: t.roundIndex
                }
            }, {
                type: "input",
                props: {
                    key: Ne,
                    isNumber: !0,
                    label: t.samuraiSlotsPreviousSpecialSpinsCount
                }
            }, {
                type: "select",
                props: {
                    key: Oe,
                    label: t.isSpecial,
                    options: de
                }
            }],
            steps: [u, c],
            config: ({
                samuraiSlotsRound: e
            }) => {
                const s = Number(e);
                return {
                    count: 18 * ((s < 0 ? 0 : s) + 1),
                    size: 1
                }
            }
        },
        slots: {
            getResultProps: se,
            inputsMeta: [r, ...i, {
                type: "input",
                props: {
                    key: ke,
                    isNumber: !0,
                    label: t.roundIndex
                }
            }],
            steps: [u, c],
            config: ({
                slotsRound: e
            }) => {
                const s = Number(e);
                return {
                    count: 5 * ((s < 0 ? 0 : s) + 1),
                    isSlots: !0
                }
            }
        },
        wheel: {
            getResultProps: te,
            inputsMeta: [r, ...i, {
                type: "select",
                props: {
                    key: he,
                    options: T,
                    translateOptions: !0,
                    label: t.risk
                }
            }, {
                type: "select",
                props: {
                    key: ve,
                    options: pe,
                    translateOptions: !1,
                    label: t.segments
                }
            }],
            steps: [u, c],
            config: ({
                wheelSegments: e
            }) => ({
                size: Number(e),
                count: 1
            })
        },
        videoPoker: {
            getResultProps: oe,
            inputsMeta: [r, ...i],
            steps: [u, c, f],
            config: {
                size: 52,
                count: 52,
                isShuffle: !0
            }
        },
        crash: {
            getResultProps: ae,
            inputsMeta: [r, ...O],
            steps: [N, h, v],
            config: {
                size: 2 ** 32,
                edge: .01
            }
        },
        slide: {
            getResultProps: ne,
            inputsMeta: [r, ...O],
            steps: [N, h, v],
            config: {
                size: 2 ** 32,
                edge: .02
            }
        },
        dragonTower: {
            getResultProps: x,
            inputsMeta: [r, ...i, {
                type: "select",
                props: {
                    key: Ce,
                    options: me,
                    translateOptions: !0,
                    label: t.difficulty
                }
            }],
            steps: [u, c, f],
            config: ({
                dragonTowerDifficulty: e
            }) => ie[e]
        },
        slotsTomeOfLife: {
            getResultProps: le,
            inputsMeta: [r, ...i, {
                type: "input",
                props: {
                    key: Ie,
                    isNumber: !0,
                    label: t.roundIndex
                }
            }],
            steps: [u, c],
            config: ({
                slotsTomeOfLifeRound: e
            }) => {
                const s = Number(e);
                return {
                    count: 5 * ((s < 0 ? 0 : s) + 1),
                    isSlots: !0
                }
            }
        }
    };
export {
    c as B, _e as C, Ce as D, Me as E, Ae as G, Ee as H, N as M, ge as N, ye as P, T as R, u as S, he as W, f as a, h as b, v as c, Se as d, re as e, be as f, fe as g, Re as h, ue as i, Pe as j, ce as k, ke as l, Te as m, Oe as n, de as o, Ne as p, ve as q, pe as r, me as s, Ie as t, G as u, $ as v
};