import {
    j as T
} from "./jsonScript.84xs9Vds.js";
import {
    ax as b,
    ac as h,
    ag as st,
    aa as ht
} from "./index.B4-7gKq3.js";
import {
    k as bt
} from "./index.B81orGJm.js";

function x(t, e) {
    var n = Object.keys(t);
    if (Object.getOwnPropertySymbols) {
        var i = Object.getOwnPropertySymbols(t);
        e && (i = i.filter(function(r) {
            return Object.getOwnPropertyDescriptor(t, r).enumerable
        })), n.push.apply(n, i)
    }
    return n
}

function tt(t) {
    for (var e = 1; e < arguments.length; e++) {
        var n = arguments[e] != null ? arguments[e] : {};
        e % 2 ? x(Object(n), !0).forEach(function(i) {
            ut(t, i, n[i])
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : x(Object(n)).forEach(function(i) {
            Object.defineProperty(t, i, Object.getOwnPropertyDescriptor(n, i))
        })
    }
    return t
}

function ut(t, e, n) {
    return e = kt(e), e in t ? Object.defineProperty(t, e, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = n, t
}

function kt(t) {
    var e = $t(t, "string");
    return typeof e == "symbol" ? e : e + ""
}

function $t(t, e) {
    if (typeof t != "object" || !t) return t;
    var n = t[Symbol.toPrimitive];
    if (n !== void 0) {
        var i = n.call(t, e || "default");
        if (typeof i != "object") return i;
        throw new TypeError("@@toPrimitive must return a primitive value.")
    }
    return (e === "string" ? String : Number)(t)
}

function G(t) {
    return t._type === "span" && "text" in t && typeof t.text == "string" && (typeof t.marks > "u" || Array.isArray(t.marks) && t.marks.every(e => typeof e == "string"))
}

function ct(t) {
    return typeof t._type == "string" && t._type[0] !== "@" && (!("markDefs" in t) || !t.markDefs || Array.isArray(t.markDefs) && t.markDefs.every(e => typeof e._key == "string")) && "children" in t && Array.isArray(t.children) && t.children.every(e => typeof e == "object" && "_type" in e)
}

function at(t) {
    return ct(t) && "listItem" in t && typeof t.listItem == "string" && (typeof t.level > "u" || typeof t.level == "number")
}

function lt(t) {
    return t._type === "@list"
}

function mt(t) {
    return t._type === "@span"
}

function ot(t) {
    return t._type === "@text"
}
const et = ["strong", "em", "code", "underline", "strike-through"];

function Ot(t, e, n) {
    if (!G(t) || !t.marks) return [];
    if (!t.marks.length) return [];
    const i = t.marks.slice(),
        r = {};
    return i.forEach(s => {
        r[s] = 1;
        for (let m = e + 1; m < n.length; m++) {
            const y = n[m];
            if (y && G(y) && Array.isArray(y.marks) && y.marks.indexOf(s) !== -1) r[s]++;
            else break
        }
    }), i.sort((s, m) => Lt(r, s, m))
}

function Lt(t, e, n) {
    const i = t[e],
        r = t[n];
    if (i !== r) return r - i;
    const s = et.indexOf(e),
        m = et.indexOf(n);
    return s !== m ? s - m : e.localeCompare(n)
}

function St(t) {
    var e;
    const {
        children: n,
        markDefs: i = []
    } = t;
    if (!n || !n.length) return [];
    const r = n.map(Ot),
        s = {
            _type: "@span",
            children: [],
            markType: "<unknown>"
        };
    let m = [s];
    for (let y = 0; y < n.length; y++) {
        const u = n[y];
        if (!u) continue;
        const o = r[y] || [];
        let a = 1;
        if (m.length > 1)
            for (a; a < m.length; a++) {
                const d = ((e = m[a]) == null ? void 0 : e.markKey) || "",
                    p = o.indexOf(d);
                if (p === -1) break;
                o.splice(p, 1)
            }
        m = m.slice(0, a);
        let l = m[m.length - 1];
        if (l) {
            for (const d of o) {
                const p = i.find($ => $._key === d),
                    k = p ? p._type : d,
                    c = {
                        _type: "@span",
                        _key: u._key,
                        children: [],
                        markDef: p,
                        markType: k,
                        markKey: d
                    };
                l.children.push(c), m.push(c), l = c
            }
            if (G(u)) {
                const d = u.text.split(`
`);
                for (let p = d.length; p-- > 1;) d.splice(p, 0, `
`);
                l.children = l.children.concat(d.map(p => ({
                    _type: "@text",
                    text: p
                })))
            } else l.children = l.children.concat(u)
        }
    }
    return s.children
}

function It(t, e) {
    const n = [];
    let i;
    for (let r = 0; r < t.length; r++) {
        const s = t[r];
        if (s) {
            if (!at(s)) {
                n.push(s), i = void 0;
                continue
            }
            if (!i) {
                i = Z(s, r, e), n.push(i);
                continue
            }
            if (Tt(s, i)) {
                i.children.push(s);
                continue
            }
            if ((s.level || 1) > i.level) {
                const m = Z(s, r, e); {
                    const y = i.children[i.children.length - 1],
                        u = tt(tt({}, y), {}, {
                            children: [...y.children, m]
                        });
                    i.children[i.children.length - 1] = u
                }
                i = m;
                continue
            }
            if ((s.level || 1) < i.level) {
                const m = n[n.length - 1],
                    y = m && J(m, s);
                if (y) {
                    i = y, i.children.push(s);
                    continue
                }
                i = Z(s, r, e), n.push(i);
                continue
            }
            if (s.listItem !== i.listItem) {
                const m = n[n.length - 1],
                    y = m && J(m, {
                        level: s.level || 1
                    });
                if (y && y.listItem === s.listItem) {
                    i = y, i.children.push(s);
                    continue
                } else {
                    i = Z(s, r, e), n.push(i);
                    continue
                }
            }
            console.warn("Unknown state encountered for block", s), n.push(s)
        }
    }
    return n
}

function Tt(t, e) {
    return (t.level || 1) === e.level && t.listItem === e.listItem
}

function Z(t, e, n) {
    return {
        _type: "@list",
        _key: `${t._key||`${e}`}-parent`,
        mode: n,
        level: t.level || 1,
        listItem: t.listItem,
        children: [t]
    }
}

function J(t, e) {
    const n = e.level || 1,
        i = e.listItem || "normal",
        r = typeof e.listItem == "string";
    if (lt(t) && (t.level || 1) === n && r && (t.listItem || "normal") === i) return t;
    if (!("children" in t)) return;
    const s = t.children[t.children.length - 1];
    return s && !G(s) ? J(s, e) : void 0
}

function pt(t) {
    let e = "";
    return t.children.forEach(n => {
        ot(n) ? e += n.text : mt(n) && (e += pt(n))
    }), e
}
const Pt = ["block", "list", "listItem", "marks", "types"],
    gt = ["listItem"],
    wt = ["_key"];

function nt(t, e) {
    var n = Object.keys(t);
    if (Object.getOwnPropertySymbols) {
        var i = Object.getOwnPropertySymbols(t);
        e && (i = i.filter(function(r) {
            return Object.getOwnPropertyDescriptor(t, r).enumerable
        })), n.push.apply(n, i)
    }
    return n
}

function O(t) {
    for (var e = 1; e < arguments.length; e++) {
        var n = arguments[e] != null ? arguments[e] : {};
        e % 2 ? nt(Object(n), !0).forEach(function(i) {
            jt(t, i, n[i])
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : nt(Object(n)).forEach(function(i) {
            Object.defineProperty(t, i, Object.getOwnPropertyDescriptor(n, i))
        })
    }
    return t
}

function jt(t, e, n) {
    return e = vt(e), e in t ? Object.defineProperty(t, e, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = n, t
}

function vt(t) {
    var e = _t(t, "string");
    return typeof e == "symbol" ? e : e + ""
}

function _t(t, e) {
    if (typeof t != "object" || !t) return t;
    var n = t[Symbol.toPrimitive];
    if (n !== void 0) {
        var i = n.call(t, e || "default");
        if (typeof i != "object") return i;
        throw new TypeError("@@toPrimitive must return a primitive value.")
    }
    return (e === "string" ? String : Number)(t)
}

function C(t, e) {
    if (t == null) return {};
    var n = ft(t, e),
        i, r;
    if (Object.getOwnPropertySymbols) {
        var s = Object.getOwnPropertySymbols(t);
        for (r = 0; r < s.length; r++) i = s[r], !(e.indexOf(i) >= 0) && Object.prototype.propertyIsEnumerable.call(t, i) && (n[i] = t[i])
    }
    return n
}

function ft(t, e) {
    if (t == null) return {};
    var n = {},
        i = Object.keys(t),
        r, s;
    for (s = 0; s < i.length; s++) r = i[s], !(e.indexOf(r) >= 0) && (n[r] = t[r]);
    return n
}
const Et = {
        number: ({
            children: t
        }) => `<ol>${t}</ol>`,
        bullet: ({
            children: t
        }) => `<ul>${t}</ul>`
    },
    Ht = ({
        children: t
    }) => `<li>${t}</li>`,
    Bt = ["http", "https", "mailto", "tel"],
    At = {
        "&": "amp",
        "<": "lt",
        ">": "gt",
        '"': "quot",
        "'": "#x27"
    };

function yt(t) {
    return t.replace(/[&<>"']/g, e => `&${At[e]};`)
}

function Mt(t) {
    const e = (t || "").trim(),
        n = e.charAt(0);
    if (n === "#" || n === "/") return !0;
    const i = e.indexOf(":");
    if (i === -1) return !0;
    const r = e.slice(0, i).toLowerCase();
    if (Bt.indexOf(r) !== -1) return !0;
    const s = e.indexOf("?");
    if (s !== -1 && i > s) return !0;
    const m = e.indexOf("#");
    return m !== -1 && i > m
}
const Dt = ({
        children: t,
        value: e
    }) => {
        const n = (e == null ? void 0 : e.href) || "";
        return Mt(n) ? `<a href="${yt(n)}">${t}</a>` : t
    },
    Nt = {
        em: ({
            children: t
        }) => `<em>${t}</em>`,
        strong: ({
            children: t
        }) => `<strong>${t}</strong>`,
        code: ({
            children: t
        }) => `<code>${t}</code>`,
        underline: ({
            children: t
        }) => `<span style="text-decoration:underline">${t}</span>`,
        "strike-through": ({
            children: t
        }) => `<del>${t}</del>`,
        link: Dt
    },
    Y = (t, e) => `Unknown ${t}, specify a component for it in the \`components.${e}\` option`,
    dt = t => Y(`block type "${t}"`, "types"),
    Ut = t => Y(`mark type "${t}"`, "marks"),
    Wt = t => Y(`block style "${t}"`, "block"),
    zt = t => Y(`list style "${t}"`, "list"),
    Vt = t => Y(`list item style "${t}"`, "listItem");

function qt(t) {
    console.warn(t)
}
const Ft = ({
        value: t,
        isInline: e
    }) => {
        const n = dt(t._type);
        return e ? `<span style="display:none">${n}</span>` : `<div style="display:none">${n}</div>`
    },
    Rt = ({
        markType: t,
        children: e
    }) => `<span class="unknown__pt__mark__${t}">${e}</span>`,
    Yt = ({
        children: t
    }) => `<p>${t}</p>`,
    Qt = ({
        children: t
    }) => `<ul>${t}</ul>`,
    Xt = ({
        children: t
    }) => `<li>${t}</li>`,
    Zt = () => "<br/>",
    Gt = {
        normal: ({
            children: t
        }) => `<p>${t}</p>`,
        blockquote: ({
            children: t
        }) => `<blockquote>${t}</blockquote>`,
        h1: ({
            children: t
        }) => `<h1>${t}</h1>`,
        h2: ({
            children: t
        }) => `<h2>${t}</h2>`,
        h3: ({
            children: t
        }) => `<h3>${t}</h3>`,
        h4: ({
            children: t
        }) => `<h4>${t}</h4>`,
        h5: ({
            children: t
        }) => `<h5>${t}</h5>`,
        h6: ({
            children: t
        }) => `<h6>${t}</h6>`
    },
    it = {
        types: {},
        block: Gt,
        marks: Nt,
        list: Et,
        listItem: Ht,
        hardBreak: Zt,
        unknownType: Ft,
        unknownMark: Rt,
        unknownList: Qt,
        unknownListItem: Xt,
        unknownBlockStyle: Yt
    };

function Kt(t, e) {
    const n = C(e, Pt);
    return O(O({}, t), {}, {
        block: R(t, e, "block"),
        list: R(t, e, "list"),
        listItem: R(t, e, "listItem"),
        marks: R(t, e, "marks"),
        types: R(t, e, "types")
    }, n)
}

function R(t, e, n) {
    const i = e[n],
        r = t[n];
    return typeof i == "function" || i && typeof r == "function" ? i : i ? O(O({}, r), i) : r
}

function Jt(t, e = {}) {
    const {
        components: n,
        onMissingComponent: i = qt
    } = e, r = i || xt, s = Array.isArray(t) ? t : [t], m = It(s, "html"), y = n ? Kt(it, n) : it, u = Ct(y, r);
    return m.map((o, a) => u({
        node: o,
        index: a,
        isInline: !1,
        renderNode: u
    })).join("")
}
const Ct = (t, e) => {
    function n(o) {
        const {
            node: a,
            index: l,
            isInline: d
        } = o;
        return lt(a) ? r(a, l) : at(a) ? i(a, l) : mt(a) ? s(a) : ct(a) ? m(a, l, d) : ot(a) ? y(a) : u(a, l, d)
    }

    function i(o, a) {
        const l = rt({
                node: o,
                index: a,
                isInline: !1,
                renderNode: n
            }),
            d = t.listItem,
            p = (typeof d == "function" ? d : d[o.listItem]) || t.unknownListItem;
        if (p === t.unknownListItem) {
            const c = o.listItem || "bullet";
            e(Vt(c), {
                type: c,
                nodeType: "listItemStyle"
            })
        }
        let k = l.children;
        if (o.style && o.style !== "normal") {
            const c = C(o, gt);
            k = n({
                node: c,
                index: a,
                isInline: !1,
                renderNode: n
            })
        }
        return p({
            value: o,
            index: a,
            isInline: !1,
            renderNode: n,
            children: k
        })
    }

    function r(o, a) {
        const l = o.children.map((k, c) => n({
                node: k._key ? k : O(O({}, k), {}, {
                    _key: `li-${a}-${c}`
                }),
                index: a,
                isInline: !1,
                renderNode: n
            })),
            d = t.list,
            p = (typeof d == "function" ? d : d[o.listItem]) || t.unknownList;
        if (p === t.unknownList) {
            const k = o.listItem || "bullet";
            e(zt(k), {
                nodeType: "listStyle",
                type: k
            })
        }
        return p({
            value: o,
            index: a,
            isInline: !1,
            renderNode: n,
            children: l.join("")
        })
    }

    function s(o) {
        const {
            markDef: a,
            markType: l,
            markKey: d
        } = o, p = t.marks[l] || t.unknownMark, k = o.children.map((c, $) => n({
            node: c,
            index: $,
            isInline: !0,
            renderNode: n
        }));
        return p === t.unknownMark && e(Ut(l), {
            nodeType: "mark",
            type: l
        }), p({
            text: pt(o),
            value: a,
            markType: l,
            markKey: d,
            renderNode: n,
            children: k.join("")
        })
    }

    function m(o, a, l) {
        const d = rt({
                node: o,
                index: a,
                isInline: l,
                renderNode: n
            }),
            p = C(d, wt),
            k = p.node.style || "normal",
            c = (typeof t.block == "function" ? t.block : t.block[k]) || t.unknownBlockStyle;
        return c === t.unknownBlockStyle && e(Wt(k), {
            nodeType: "blockStyle",
            type: k
        }), c(O(O({}, p), {}, {
            value: p.node,
            renderNode: n
        }))
    }

    function y(o) {
        if (o.text === `
`) {
            const a = t.hardBreak;
            return a ? a() : `
`
        }
        return yt(o.text)
    }

    function u(o, a, l) {
        const d = t.types[o._type];
        return d || e(dt(o._type), {
            nodeType: "block",
            type: o._type
        }), (d || t.unknownType)({
            value: o,
            isInline: l,
            index: a,
            renderNode: n
        })
    }
    return n
};

function rt(t) {
    const {
        node: e,
        index: n,
        isInline: i,
        renderNode: r
    } = t, s = St(e).map((m, y) => r({
        node: m,
        isInline: !0,
        index: y,
        renderNode: r
    }));
    return {
        _key: e._key || `block-${n}`,
        children: s.join(""),
        index: n,
        isInline: i,
        node: e
    }
}

function xt() {}

function te(t) {
    return `
    <table>
      ${t==null?void 0:t.rows.map(n=>`<tr>${n.cells.map(r=>`<td>${r}</td>`).join("")}</tr>`).join("")}
    </table>
  `
}
const Q = t => Jt(t, {
        components: {
            types: {
                table: ({
                    value: e
                }) => te(e)
            }
        }
    }),
    I = t => t && t.replace(/ /g, "-").replace(/,/g, "").toLowerCase(),
    re = (t, e, n) => {
        var o;
        const i = t != null && t.content ? Q(t == null ? void 0 : t.content) : t == null ? void 0 : t.description,
            r = {
                "@context": "https://schema.org",
                "@type": "CollectionPage",
                "@id": "#casino-group-page",
                url: b(`${h.HOST}casino/group/${e==null?void 0:e.slug}`, n),
                name: t == null ? void 0 : t.title,
                description: t == null ? void 0 : t.description,
                isPartOf: {
                    "@id": "#stake-website"
                },
                mainEntity: {
                    "@type": "ItemList",
                    "@id": "#casino-games-list",
                    name: e == null ? void 0 : e.translation,
                    description: i,
                    itemListOrder: "https://schema.org/ItemListUnordered"
                },
                breadcrumb: {
                    "@type": "BreadcrumbList",
                    "@id": "#breadcrumb",
                    itemListElement: [{
                        "@type": "ListItem",
                        position: 1,
                        item: {
                            "@id": b(h.HOST, n),
                            name: bt
                        }
                    }, {
                        "@type": "ListItem",
                        position: 2,
                        item: {
                            "@id": b(`${h.HOST}casino/home`, n),
                            name: "Casino Games"
                        }
                    }]
                }
            },
            m = {
                "@context": "https://schema.org",
                "@type": "ItemList",
                "@id": "#casino-games-list",
                itemListElement: [...((o = e == null ? void 0 : e.groupGamesList) == null ? void 0 : o.map(({
                    game: a
                }) => {
                    var d;
                    const l = (d = a.groupGames.filter(p => p.group.type === "provider")[0]) == null ? void 0 : d.group;
                    return {
                        "@type": "VideoGame",
                        "@id": `#game-${a==null?void 0:a.slug}`,
                        name: a == null ? void 0 : a.name,
                        url: b(`${h.HOST}casino/games/${a==null?void 0:a.slug}`, n),
                        image: {
                            "@type": "ImageObject",
                            "@id": `#game-feature-image-${a==null?void 0:a.slug}`,
                            url: a == null ? void 0 : a.thumbnailUrl
                        },
                        gamePlatform: "HTML5 Web",
                        publisher: {
                            "@type": "Organization",
                            "@id": `#game-publisher-${l==null?void 0:l.slug}`,
                            name: l == null ? void 0 : l.translation,
                            url: b(`${h.HOST}casino/group/${l==null?void 0:l.slug}`, n)
                        }
                    }
                })) || []]
            },
            y = {
                "@id": "#casino-games-list",
                numberOfItems: e == null ? void 0 : e.gameCount
            };
        return T(JSON.stringify([r, m, y]))
    },
    se = (t, e, n, i) => {
        const r = [],
            s = [];
        let m;
        n.groupGames.forEach(({
            group: l
        }) => {
            const d = b(`${h.HOST}casino/group/${l==null?void 0:l.slug}`, i),
                p = l == null ? void 0 : l.translation;
            (l == null ? void 0 : l.type) === "provider" && (m = {
                "@type": "Organization",
                "@id": "#game-publisher",
                name: l == null ? void 0 : l.translation,
                url: b(`${h.HOST}casino/group/${l==null?void 0:l.slug}`, i)
            }), r.push(d), s.push(p)
        });
        const {
            name: y
        } = n, u = t != null && t.content ? Q(t == null ? void 0 : t.content) : (t == null ? void 0 : t.description) || (n == null ? void 0 : n.description), o = `${h.HOST.slice(0,-1)}${e}`, a = {
            "@context": "https://schema.org",
            "@type": "ItemPage",
            "@id": "#page-game",
            url: o,
            name: t == null ? void 0 : t.title,
            primaryImageOfPage: {
                "@id": `#game-feature-image-${y}`
            },
            relatedLink: [b(`${h.HOST}casino/home`, i), ...r],
            description: (t == null ? void 0 : t.description) || (n == null ? void 0 : n.description),
            isPartOf: {
                "@id": "#stake-website"
            },
            mainEntity: {
                "@id": "#game-info",
                "@type": "VideoGame",
                name: y,
                url: o,
                image: {
                    "@type": "ImageObject",
                    "@id": `#game-feature-image-${y}`,
                    url: n == null ? void 0 : n.thumbnailUrl
                },
                description: u,
                inLanguage: "English",
                gamePlatform: "HTML5 Web",
                playMode: "https://schema.org/SinglePlayer",
                publisher: m,
                genre: [...s]
            },
            breadcrumb: {
                "@type": "BreadcrumbList",
                "@id": "#breadcrumb",
                itemListElement: [{
                    "@type": "ListItem",
                    position: 1,
                    item: {
                        "@id": b(h.HOST, i),
                        name: "Stake.com"
                    }
                }, {
                    "@type": "ListItem",
                    position: 2,
                    item: {
                        "@id": b(`${h.HOST}casino/home`, i),
                        name: "Casino Games"
                    }
                }]
            }
        };
        return T(JSON.stringify(a))
    },
    ce = (t, e, n, i, r, s) => {
        const m = typeof(t == null ? void 0 : t.title) == "string" ? t.title : e.title,
            y = t != null && t.content ? Q(t == null ? void 0 : t.content) : (t == null ? void 0 : t.description) || (e == null ? void 0 : e.description),
            u = [],
            o = st(r, s).split("/").slice(2);
        o.forEach((c, $) => {
            const L = o.slice(0, $ + 1).join("/"),
                S = {
                    "@type": "ListItem",
                    position: $ + 3,
                    item: {
                        "@id": b(`${h.HOST}sports/${L}`, s),
                        name: c
                    }
                };
            u.push(S)
        });
        const l = {
                "@context": "https://schema.org",
                "@type": "CollectionPage",
                "@id": "#sport-events-page",
                url: `${h.HOST.slice(0,-1)}${r}`,
                name: m,
                description: (t == null ? void 0 : t.description) || (e == null ? void 0 : e.description),
                isPartOf: {
                    "@id": "#stake-website"
                },
                mainEntity: {
                    "@type": "ItemList",
                    "@id": "#fixture-list",
                    name: `${n} fixtures`,
                    description: y,
                    itemListOrder: "https://schema.org/ItemListUnordered"
                },
                breadcrumb: {
                    "@type": "BreadcrumbList",
                    "@id": "#breadcrumb",
                    itemListElement: [{
                        "@type": "ListItem",
                        position: 1,
                        item: {
                            "@id": b(h.HOST, s),
                            name: "Stake.com"
                        }
                    }, {
                        "@type": "ListItem",
                        position: 2,
                        item: {
                            "@id": b(`${h.HOST}sports/home`, s),
                            name: "Sports"
                        }
                    }, ...u]
                }
            },
            d = [];
        i !== void 0 && i.forEach(c => {
            var L, S, P, g, w, j, v, _, f, E, H, B, A, M, D, N, U, W, z, X, V, q, K, F;
            const $ = {
                "@type": ["SportsEvent"],
                "@id": `#event-${c==null?void 0:c.slug}`,
                url: b(`${h.HOST}sports/${(P=(S=(L=c==null?void 0:c.tournament)==null?void 0:L.category)==null?void 0:S.sport)==null?void 0:P.slug}/${(w=(g=c==null?void 0:c.tournament)==null?void 0:g.category)==null?void 0:w.slug}/${(j=c==null?void 0:c.tournament)==null?void 0:j.slug}/${c==null?void 0:c.slug}`, s),
                name: c == null ? void 0 : c.name,
                homeTeam: {
                    "@type": "SportsTeam",
                    "@id": `#sports-team-${I((_=(v=c==null?void 0:c.data)==null?void 0:v.competitors[0])==null?void 0:_.name)}`,
                    name: (E = (f = c == null ? void 0 : c.data) == null ? void 0 : f.competitors[0]) == null ? void 0 : E.name
                },
                awayTeam: {
                    "@type": "SportsTeam",
                    "@id": `#sports-team-${I((B=(H=c==null?void 0:c.data)==null?void 0:H.competitors[1])==null?void 0:B.name)}`,
                    name: (M = (A = c == null ? void 0 : c.data) == null ? void 0 : A.competitors[1]) == null ? void 0 : M.name
                },
                location: {
                    "@id": `#location-team-${I((N=(D=c==null?void 0:c.data)==null?void 0:D.competitors[0])==null?void 0:N.name)}`,
                    "@type": "Place",
                    address: {
                        "@id": `#address-team-${I((W=(U=c==null?void 0:c.data)==null?void 0:U.competitors[0])==null?void 0:W.name)}`
                    }
                },
                sport: b(`${h.HOST}sports/${(V=(X=(z=c==null?void 0:c.tournament)==null?void 0:z.category)==null?void 0:X.sport)==null?void 0:V.slug}`, s),
                startDate: (q = c == null ? void 0 : c.data) == null ? void 0 : q.startTime,
                eventStatus: "https://schema.org/EventScheduled",
                organizer: {
                    "@type": "Organization",
                    "@id": `#tournament-${(K=c==null?void 0:c.tournament)==null?void 0:K.slug}`,
                    name: (F = c == null ? void 0 : c.tournament) == null ? void 0 : F.name
                }
            };
            d.push($)
        });
        const p = {
            "@context": "https://schema.org",
            "@type": "ItemList",
            "@id": "#fixture-list",
            itemListElement: [...d]
        };
        return T(JSON.stringify([l, p]))
    },
    ae = (t, e, n, i) => {
        var d, p, k, c, $, L, S, P, g, w, j, v, _, f, E, H, B, A, M, D, N, U;
        let r = {
            team1: "team1",
            team2: "team2",
            startTime: "",
            title: "",
            description: ""
        };
        ((d = e == null ? void 0 : e.data) == null ? void 0 : d.__typename) === "SportFixtureDataMatch" && (r = {
            team1: (k = (p = e == null ? void 0 : e.data) == null ? void 0 : p.competitors[0]) != null && k.name ? I(($ = (c = e == null ? void 0 : e.data) == null ? void 0 : c.competitors[0]) == null ? void 0 : $.name) : "",
            team2: (S = (L = e == null ? void 0 : e.data) == null ? void 0 : L.competitors[1]) != null && S.name ? I((g = (P = e == null ? void 0 : e.data) == null ? void 0 : P.competitors[1]) == null ? void 0 : g.name) : "",
            startTime: (w = e == null ? void 0 : e.data) == null ? void 0 : w.startTime,
            title: `${(v=(j=e==null?void 0:e.data)==null?void 0:j.competitors[0])==null?void 0:v.name} VS ${(f=(_=e==null?void 0:e.data)==null?void 0:_.competitors[1])==null?void 0:f.name}`,
            description: `${(H=(E=e==null?void 0:e.data)==null?void 0:E.competitors[0])==null?void 0:H.name} VS ${(A=(B=e==null?void 0:e.data)==null?void 0:B.competitors[1])==null?void 0:A.name} on ${(M=e==null?void 0:e.data)==null?void 0:M.startTime}. Explore all ${(D=e==null?void 0:e.tournament)==null?void 0:D.name}.`
        });
        const s = (t == null ? void 0 : t.title) || (r == null ? void 0 : r.title),
            m = t != null && t.content ? Q(t == null ? void 0 : t.content) : r == null ? void 0 : r.description,
            y = st(n, i).split("/").slice(2),
            u = y.map((W, z) => {
                const X = y.slice(0, z + 1).join("/");
                let V = W.split("-").map(q => {
                    var F;
                    return ((F = q[0]) == null ? void 0 : F.toUpperCase()) + q.substring(1)
                }).join(" ");
                return W === (e == null ? void 0 : e.slug) && (V = e.name), {
                    "@type": "ListItem",
                    position: z + 3,
                    item: {
                        "@id": b(`${h.HOST}sports/${X}`, i),
                        name: V
                    }
                }
            }),
            o = `${h.HOST.slice(0,-1)}${n}`,
            l = [{
                "@context": "https://schema.org",
                "@type": "ItemPage",
                "@id": "#sport-fixture-page",
                url: o,
                name: s || (e == null ? void 0 : e.name),
                description: r == null ? void 0 : r.description,
                isPartOf: {
                    "@id": "#stake-website"
                },
                mainEntity: {
                    "@type": "SportsEvent",
                    "@id": "#sports-fixture",
                    name: e == null ? void 0 : e.name,
                    description: m,
                    url: o,
                    homeTeam: {
                        "@type": "SportsTeam",
                        "@id": `#sports-team-${r==null?void 0:r.team1}`,
                        name: r == null ? void 0 : r.team1
                    },
                    awayTeam: {
                        "@type": "SportsTeam",
                        "@id": `#sports-team-${r==null?void 0:r.team2}`,
                        name: r == null ? void 0 : r.team2
                    },
                    sport: b(`${h.HOST}sports/soccer`, i),
                    startDate: r == null ? void 0 : r.startTime,
                    eventStatus: "https://schema.org/EventScheduled",
                    location: {
                        "@type": "Place",
                        "@id": `#location-team-${r==null?void 0:r.team1}`,
                        address: {
                            "@id": `#address-team-${r==null?void 0:r.team1}`
                        }
                    },
                    organizer: {
                        "@type": "Organization",
                        "@id": `#tournament-org-${(N=e==null?void 0:e.tournament)==null?void 0:N.slug}`,
                        name: (U = e == null ? void 0 : e.tournament) == null ? void 0 : U.name
                    }
                },
                breadcrumb: {
                    "@type": "BreadcrumbList",
                    "@id": "#breadcrumb",
                    itemListElement: [{
                        "@type": "ListItem",
                        position: 1,
                        item: {
                            "@id": b(h.HOST, i),
                            name: "Stake.com"
                        }
                    }, {
                        "@type": "ListItem",
                        position: 2,
                        item: {
                            "@id": b(`${h.HOST}sports/home`, i),
                            name: "Sports"
                        }
                    }, ...u]
                }
            }];
        return T(JSON.stringify(l))
    },
    le = (t, e, n, i, r, s, m) => {
        var o;
        const u = [{
            "@context": "https://schema.org",
            "@type": "WebPage",
            "@id": "#blog-post",
            name: t,
            description: e,
            url: b(`${h.HOST}blog/${n}`, m),
            isPartOf: {
                "@id": "#stake-website"
            },
            primaryImageOfPage: {
                "@type": "ImageObject",
                "@id": "#blog-image",
                representativeOfPage: "http://schema.org/True"
            },
            mainEntity: {
                "@type": "BlogPosting",
                headline: t,
                articleBody: e,
                image: {
                    "@type": "ImageObject",
                    "@id": "#blog-image",
                    url: i
                },
                author: s,
                publisher: {
                    "@id": "#stake-org"
                }
            },
            breadcrumb: {
                "@type": "BreadcrumbList",
                "@id": "#breadcrumb",
                itemListElement: [{
                    "@type": "ListItem",
                    position: 1,
                    item: {
                        "@id": b(h.HOST, m),
                        name: "Stake.com"
                    }
                }, {
                    "@type": "ListItem",
                    position: 2,
                    item: {
                        "@id": b(`${h.HOST}blog`, m),
                        name: "Stake News & Blog"
                    }
                }, {
                    "@type": "ListItem",
                    position: 3,
                    item: {
                        "@id": b(`${h.HOST}blog/category/${(o=r==null?void 0:r.slug)==null?void 0:o.current}`, m),
                        name: `${r==null?void 0:r.name} Blog Posts`
                    }
                }]
            }
        }];
        return T(JSON.stringify(u))
    },
    me = (t, e, n, i) => {
        const r = e.slice(e.lastIndexOf("/") + 1),
            s = {
                title: `Blog - ${r}`,
                description: `The latest news and offers for ${r}`
            },
            m = typeof(t == null ? void 0 : t.title) == "string" ? t.title : s.title,
            y = t != null && t.content ? Q(t == null ? void 0 : t.content) : (t == null ? void 0 : t.description) || (s == null ? void 0 : s.description),
            u = `${h.HOST.slice(0,-1)}${e}`,
            o = {
                "@context": "https://schema.org",
                "@type": "CollectionPage",
                "@id": "#blog-list",
                name: m,
                description: y,
                url: u,
                isPartOf: {
                    "@id": "#stake-website"
                },
                mainEntity: {
                    "@type": "ItemList",
                    "@id": "#article-list",
                    name: e === ht("/blog", i) ? "List of Blog Posts" : "Category blog posts"
                },
                breadcrumb: {
                    "@type": "BreadcrumbList",
                    "@id": "#breadcrumb",
                    itemListElement: [{
                        "@type": "ListItem",
                        position: 1,
                        item: {
                            "@id": b(h.HOST, i),
                            name: "Stake.com"
                        }
                    }, {
                        "@type": "ListItem",
                        position: 2,
                        item: {
                            "@id": b(`${h.HOST}blog`, i),
                            name: "Stake News & Blog"
                        }
                    }]
                }
            },
            l = {
                "@context": "https://schema.org",
                "@type": "ItemList",
                "@id": "#article-list",
                itemListElement: [...n.map(p => {
                    var k;
                    return {
                        "@type": "BlogPosting",
                        headline: p == null ? void 0 : p.title,
                        url: b(`${h.HOST}blog/${(k=p==null?void 0:p.slug)==null?void 0:k.current}`, i)
                    }
                })]
            };
        return T(JSON.stringify([o, l]))
    };
export {
    ae as a, me as b, ce as c, le as d, re as e, se as f
};