const e = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "subscription",
            name: {
                kind: "Name",
                value: "racingBets"
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "racingBets"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "RacingBet"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "RunnerOutcomeButton_RacingOutcome"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "RacingOutcome"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "odds"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "market"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "status"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "RunnerOutcomeButton_RacingRunner"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "RacingRunner"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "scratched"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "runnerNumber"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "barrierPosition"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "hcpDraw"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "attributes"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "weight"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "careerStats"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "last6Runs"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "jockey"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "trainer"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "prices"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "active"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "odds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "market"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "status"
                                    }
                                }]
                            }
                        }, {
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "RunnerOutcomeButton_RacingOutcome"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "RacingBet"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "RacingBet"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "amount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "updatedAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "resultType"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "outcomes"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "updatedAt"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "prices"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "odds"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "marketName"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "result"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "resultedPrices"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "status"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "deadheatMultiplier"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "deductions"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "key"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "percentage"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "type"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "derivativeType"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "event"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "eventNumber"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "slug"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "startTime"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "status"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "streamUrl"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "streamGeoBlocked"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "meeting"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "slug"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "racing"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "slug"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "name"
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "racingGroup"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "slug"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "name"
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "venue"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "name"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "geoBlocked"
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "category"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "name"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "slug"
                                                    }
                                                }]
                                            }
                                        }]
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "topRunnerList"
                                    },
                                    arguments: [{
                                        kind: "Argument",
                                        name: {
                                            kind: "Name",
                                            value: "limit"
                                        },
                                        value: {
                                            kind: "IntValue",
                                            value: "4"
                                        }
                                    }],
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "finalPosition"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "runnerNumber"
                                            }
                                        }]
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "selectionSlots"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "runners"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "FragmentSpread",
                                            name: {
                                                kind: "Name",
                                                value: "RunnerOutcomeButton_RacingRunner"
                                            }
                                        }]
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "selections"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "type"
                                    }
                                }]
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payout"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payoutMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "adjustments"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "payoutMultiplier"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "updatedAt"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "createdAt"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    alias: {
                        kind: "Name",
                        value: "betStatus"
                    },
                    name: {
                        kind: "Name",
                        value: "status"
                    }
                }, {
                    kind: "Field",
                    alias: {
                        kind: "Name",
                        value: "betPotentialMultiplier"
                    },
                    name: {
                        kind: "Name",
                        value: "potentialMultiplier"
                    }
                }]
            }
        }]
    },
    n = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "subscription",
            name: {
                kind: "Name",
                value: "RacingEvent_RacingEvent"
            },
            variableDefinitions: [{
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "eventId"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "String"
                        }
                    }
                }
            }],
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "racingEvent"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "eventId"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "eventId"
                            }
                        }
                    }],
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "RaceDetails_RacingEvent"
                            }
                        }, {
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "RaceResults_RacingEvent"
                            }
                        }, {
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "RunnerOutcomeButton_RacingEvent"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "slug"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "status"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "eventNumber"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "betTypes"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "enabled"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "runners"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "EventRunners_RacingRunner"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "RunnerDeductions_RacingRunner"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "RacingRunner"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "placeDeduction"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "winDeduction"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "RunnerScratched_RacingRunner"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "RacingRunner"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "FragmentSpread",
                    name: {
                        kind: "Name",
                        value: "RunnerDeductions_RacingRunner"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "scratchingTime"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "scratchType"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "RunnerCard_RacingRunner"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "RacingRunner"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "FragmentSpread",
                    name: {
                        kind: "Name",
                        value: "RunnerDeductions_RacingRunner"
                    }
                }, {
                    kind: "FragmentSpread",
                    name: {
                        kind: "Name",
                        value: "RunnerScratched_RacingRunner"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "runnerNumber"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "scratched"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "barrierPosition"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "hcpDraw"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "attributes"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "weight"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "careerStats"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "last6Runs"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "jockey"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "jockeyClaim"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "trainer"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "prices"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "active"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "odds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "market"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "status"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "RunnerOutcomeButton_RacingOutcome"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "RacingOutcome"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "odds"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "market"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "status"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "RunnerOutcomeButton_RacingRunner"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "RacingRunner"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "scratched"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "runnerNumber"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "barrierPosition"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "hcpDraw"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "attributes"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "weight"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "careerStats"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "last6Runs"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "jockey"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "trainer"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "prices"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "active"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "odds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "market"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "status"
                                    }
                                }]
                            }
                        }, {
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "RunnerOutcomeButton_RacingOutcome"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "RaceDetails_RacingEvent"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "RacingEvent"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "eventClass"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "startTime"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "status"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "distance"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "trackCondition"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "streamUrl"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "streamGeoBlocked"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "trackRating"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "eventNumber"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "meeting"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "weather"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "venue"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "RaceResults_RacingEvent"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "RacingEvent"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "silkStrip"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "topRunnerList"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "limit"
                        },
                        value: {
                            kind: "IntValue",
                            value: "4"
                        }
                    }],
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "RunnerCard_RacingRunner"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "runnerNumber"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "barrierPosition"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "hcpDraw"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "finalPosition"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "attributes"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "weight"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "careerStats"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "last6Runs"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "jockey"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "trainer"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "prices"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "marketName"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "odds"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "RunnerOutcomeButton_RacingEvent"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "RacingEvent"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "slug"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "eventNumber"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "distance"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "startTime"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "silkStrip"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "status"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "meeting"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "slug"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "venue"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "geoBlocked"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "category"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "slug"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "racing"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "slug"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "racingGroup"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "slug"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "EventRunners_RacingRunner"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "RacingRunner"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "FragmentSpread",
                    name: {
                        kind: "Name",
                        value: "RunnerCard_RacingRunner"
                    }
                }, {
                    kind: "FragmentSpread",
                    name: {
                        kind: "Name",
                        value: "RunnerOutcomeButton_RacingRunner"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "scratched"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "scratchType"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "scratchingTime"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "winDeduction"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "placeDeduction"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "prices"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "RunnerOutcomeButton_RacingOutcome"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "marketName"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "odds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "previousOdds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "openingOdds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "active"
                            }
                        }]
                    }
                }]
            }
        }]
    },
    i = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "subscription",
            name: {
                kind: "Name",
                value: "EventRunners_RacingRunnerOddsChange"
            },
            variableDefinitions: [{
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "runnerIds"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "ListType",
                        type: {
                            kind: "NonNullType",
                            type: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "String"
                                }
                            }
                        }
                    }
                }
            }],
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "racingRunnerOddsChange"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "runnerIds"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "runnerIds"
                            }
                        }
                    }],
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "EventRunners_RacingRunner"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "RunnerDeductions_RacingRunner"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "RacingRunner"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "placeDeduction"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "winDeduction"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "RunnerScratched_RacingRunner"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "RacingRunner"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "FragmentSpread",
                    name: {
                        kind: "Name",
                        value: "RunnerDeductions_RacingRunner"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "scratchingTime"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "scratchType"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "RunnerCard_RacingRunner"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "RacingRunner"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "FragmentSpread",
                    name: {
                        kind: "Name",
                        value: "RunnerDeductions_RacingRunner"
                    }
                }, {
                    kind: "FragmentSpread",
                    name: {
                        kind: "Name",
                        value: "RunnerScratched_RacingRunner"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "runnerNumber"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "scratched"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "barrierPosition"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "hcpDraw"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "attributes"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "weight"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "careerStats"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "last6Runs"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "jockey"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "jockeyClaim"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "trainer"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "prices"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "active"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "odds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "market"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "status"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "RunnerOutcomeButton_RacingOutcome"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "RacingOutcome"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "odds"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "market"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "status"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "RunnerOutcomeButton_RacingRunner"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "RacingRunner"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "scratched"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "runnerNumber"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "barrierPosition"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "hcpDraw"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "attributes"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "weight"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "careerStats"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "last6Runs"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "jockey"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "trainer"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "prices"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "active"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "odds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "market"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "status"
                                    }
                                }]
                            }
                        }, {
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "RunnerOutcomeButton_RacingOutcome"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "EventRunners_RacingRunner"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "RacingRunner"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "FragmentSpread",
                    name: {
                        kind: "Name",
                        value: "RunnerCard_RacingRunner"
                    }
                }, {
                    kind: "FragmentSpread",
                    name: {
                        kind: "Name",
                        value: "RunnerOutcomeButton_RacingRunner"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "scratched"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "scratchType"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "scratchingTime"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "winDeduction"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "placeDeduction"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "prices"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "RunnerOutcomeButton_RacingOutcome"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "marketName"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "odds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "previousOdds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "openingOdds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "active"
                            }
                        }]
                    }
                }]
            }
        }]
    };
export {
    i as E, n as R, e as a
};