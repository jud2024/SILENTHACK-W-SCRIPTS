var b = function(r, i) {
    return b = Object.setPrototypeOf || {
        __proto__: []
    }
    instanceof Array && function(e, n) {
        e.__proto__ = n
    } || function(e, n) {
        for (var o in n) Object.prototype.hasOwnProperty.call(n, o) && (e[o] = n[o])
    }, b(r, i)
};

function g(r, i) {
    if (typeof i != "function" && i !== null) throw new TypeError("Class extends value " + String(i) + " is not a constructor or null");
    b(r, i);

    function e() {
        this.constructor = r
    }
    r.prototype = i === null ? Object.create(i) : (e.prototype = i.prototype, new e)
}
var d = function() {
    return d = Object.assign || function(i) {
        for (var e, n = 1, o = arguments.length; n < o; n++) {
            e = arguments[n];
            for (var t in e) Object.prototype.hasOwnProperty.call(e, t) && (i[t] = e[t])
        }
        return i
    }, d.apply(this, arguments)
};

function O(r, i) {
    var e = {};
    for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && i.indexOf(n) < 0 && (e[n] = r[n]);
    if (r != null && typeof Object.getOwnPropertySymbols == "function")
        for (var o = 0, n = Object.getOwnPropertySymbols(r); o < n.length; o++) i.indexOf(n[o]) < 0 && Object.prototype.propertyIsEnumerable.call(r, n[o]) && (e[n[o]] = r[n[o]]);
    return e
}

function x(r, i, e, n) {
    function o(t) {
        return t instanceof e ? t : new e(function(u) {
            u(t)
        })
    }
    return new(e || (e = Promise))(function(t, u) {
        function l(f) {
            try {
                a(n.next(f))
            } catch (h) {
                u(h)
            }
        }

        function s(f) {
            try {
                a(n.throw(f))
            } catch (h) {
                u(h)
            }
        }

        function a(f) {
            f.done ? t(f.value) : o(f.value).then(l, s)
        }
        a((n = n.apply(r, i || [])).next())
    })
}

function j(r, i) {
    var e = {
            label: 0,
            sent: function() {
                if (t[0] & 1) throw t[1];
                return t[1]
            },
            trys: [],
            ops: []
        },
        n, o, t, u;
    return u = {
        next: l(0),
        throw: l(1),
        return: l(2)
    }, typeof Symbol == "function" && (u[Symbol.iterator] = function() {
        return this
    }), u;

    function l(a) {
        return function(f) {
            return s([a, f])
        }
    }

    function s(a) {
        if (n) throw new TypeError("Generator is already executing.");
        for (; u && (u = 0, a[0] && (e = 0)), e;) try {
            if (n = 1, o && (t = a[0] & 2 ? o.return : a[0] ? o.throw || ((t = o.return) && t.call(o), 0) : o.next) && !(t = t.call(o, a[1])).done) return t;
            switch (o = 0, t && (a = [a[0] & 2, t.value]), a[0]) {
                case 0:
                case 1:
                    t = a;
                    break;
                case 4:
                    return e.label++, {
                        value: a[1],
                        done: !1
                    };
                case 5:
                    e.label++, o = a[1], a = [0];
                    continue;
                case 7:
                    a = e.ops.pop(), e.trys.pop();
                    continue;
                default:
                    if (t = e.trys, !(t = t.length > 0 && t[t.length - 1]) && (a[0] === 6 || a[0] === 2)) {
                        e = 0;
                        continue
                    }
                    if (a[0] === 3 && (!t || a[1] > t[0] && a[1] < t[3])) {
                        e.label = a[1];
                        break
                    }
                    if (a[0] === 6 && e.label < t[1]) {
                        e.label = t[1], t = a;
                        break
                    }
                    if (t && e.label < t[2]) {
                        e.label = t[2], e.ops.push(a);
                        break
                    }
                    t[2] && e.ops.pop(), e.trys.pop();
                    continue
            }
            a = i.call(r, e)
        } catch (f) {
            a = [6, f], o = 0
        } finally {
            n = t = 0
        }
        if (a[0] & 5) throw a[1];
        return {
            value: a[0] ? a[1] : void 0,
            done: !0
        }
    }
}

function v(r) {
    var i = typeof Symbol == "function" && Symbol.iterator,
        e = i && r[i],
        n = 0;
    if (e) return e.call(r);
    if (r && typeof r.length == "number") return {
        next: function() {
            return r && n >= r.length && (r = void 0), {
                value: r && r[n++],
                done: !r
            }
        }
    };
    throw new TypeError(i ? "Object is not iterable." : "Symbol.iterator is not defined.")
}

function E(r, i) {
    var e = typeof Symbol == "function" && r[Symbol.iterator];
    if (!e) return r;
    var n = e.call(r),
        o, t = [],
        u;
    try {
        for (;
            (i === void 0 || i-- > 0) && !(o = n.next()).done;) t.push(o.value)
    } catch (l) {
        u = {
            error: l
        }
    } finally {
        try {
            o && !o.done && (e = n.return) && e.call(n)
        } finally {
            if (u) throw u.error
        }
    }
    return t
}

function P(r, i, e) {
    if (e || arguments.length === 2)
        for (var n = 0, o = i.length, t; n < o; n++)(t || !(n in i)) && (t || (t = Array.prototype.slice.call(i, 0, n)), t[n] = i[n]);
    return r.concat(t || Array.prototype.slice.call(i))
}

function w(r) {
    return this instanceof w ? (this.v = r, this) : new w(r)
}

function I(r, i, e) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var n = e.apply(r, i || []),
        o, t = [];
    return o = {}, l("next"), l("throw"), l("return", u), o[Symbol.asyncIterator] = function() {
        return this
    }, o;

    function u(c) {
        return function(y) {
            return Promise.resolve(y).then(c, h)
        }
    }

    function l(c, y) {
        n[c] && (o[c] = function(p) {
            return new Promise(function(m, S) {
                t.push([c, p, m, S]) > 1 || s(c, p)
            })
        }, y && (o[c] = y(o[c])))
    }

    function s(c, y) {
        try {
            a(n[c](y))
        } catch (p) {
            _(t[0][3], p)
        }
    }

    function a(c) {
        c.value instanceof w ? Promise.resolve(c.value.v).then(f, h) : _(t[0][2], c)
    }

    function f(c) {
        s("next", c)
    }

    function h(c) {
        s("throw", c)
    }

    function _(c, y) {
        c(y), t.shift(), t.length && s(t[0][0], t[0][1])
    }
}

function T(r) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var i = r[Symbol.asyncIterator],
        e;
    return i ? i.call(r) : (r = typeof v == "function" ? v(r) : r[Symbol.iterator](), e = {}, n("next"), n("throw"), n("return"), e[Symbol.asyncIterator] = function() {
        return this
    }, e);

    function n(t) {
        e[t] = r[t] && function(u) {
            return new Promise(function(l, s) {
                u = r[t](u), o(l, s, u.done, u.value)
            })
        }
    }

    function o(t, u, l, s) {
        Promise.resolve(s).then(function(a) {
            t({
                value: a,
                done: l
            })
        }, u)
    }
}
export {
    g as _, P as a, E as b, I as c, j as d, w as e, v as f, x as g, T as h, d as i, O as j
};