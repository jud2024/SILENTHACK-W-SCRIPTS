import {
    s as r,
    C as o,
    H as m,
    D as u,
    f as v,
    E as _,
    i as h,
    F as f,
    j as g,
    n as c
} from "./scheduler.DXu26z7T.js";
import {
    S as d,
    i as y
} from "./index.Dz_MmNB3.js";

function M(n) {
    let t, e, a = ` <title>${n[1]||""}</title> <path d="M48 96c26.51 0 48-21.49 48-48S74.51 0 48 0 0 21.49 0 48s21.49 48 48 48Z" fill="#E9113C"></path><path d="M81.762 55.24V40.8h-67.48v14.44h67.48Z" fill="#fff"></path>`,
        i;
    return {
        c() {
            t = o("svg"), e = new m(!0), this.h()
        },
        l(s) {
            t = u(s, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var l = v(t);
            e = _(l, !0), l.forEach(h), this.h()
        },
        h() {
            e.a = null, f(t, "fill", "none"), f(t, "viewBox", "0 0 96 96"), f(t, "class", i = "svg-icon " + n[2]), f(t, "style", n[0])
        },
        m(s, l) {
            g(s, t, l), e.m(a, t)
        },
        p(s, [l]) {
            l & 2 && a !== (a = ` <title>${s[1]||""}</title> <path d="M48 96c26.51 0 48-21.49 48-48S74.51 0 48 0 0 21.49 0 48s21.49 48 48 48Z" fill="#E9113C"></path><path d="M81.762 55.24V40.8h-67.48v14.44h67.48Z" fill="#fff"></path>`) && e.p(a), l & 4 && i !== (i = "svg-icon " + s[2]) && f(t, "class", i), l & 1 && f(t, "style", s[0])
        },
        i: c,
        o: c,
        d(s) {
            s && h(t)
        }
    }
}

function S(n, t, e) {
    let {
        style: a = ""
    } = t, {
        alt: i = ""
    } = t, {
        class: s = ""
    } = t;
    return n.$$set = l => {
        "style" in l && e(0, a = l.style), "alt" in l && e(1, i = l.alt), "class" in l && e(2, s = l.class)
    }, [a, i, s]
}
class E extends d {
    constructor(t) {
        super(), y(this, t, S, M, r, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    E as M
};