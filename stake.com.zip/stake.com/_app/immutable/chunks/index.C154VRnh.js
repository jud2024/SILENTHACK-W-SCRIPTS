import {
    s as O,
    e as E,
    O as j,
    d as L,
    f as M,
    P as q,
    i as m,
    F as p,
    V as b,
    j as V,
    k as F,
    c as S,
    o as N,
    a as P,
    u as T,
    g as z,
    b as A,
    a6 as B
} from "./scheduler.DXu26z7T.js";
import {
    S as G,
    i as H,
    t as f,
    g as k,
    b as c,
    e as v,
    c as J,
    a as K,
    m as Q,
    d as R,
    f as U
} from "./index.Dz_MmNB3.js";
import {
    s as h
} from "./scrollTopContainer.DLbcGdPu.js";
import {
    n as W,
    p as X
} from "./index.B4-7gKq3.js";
import {
    M as Y
} from "./index.CVJ30NdW.js";
import {
    a as Z
} from "./index.Bhhzp5qA.js";
const y = new Set([window.location.pathname]);

function w(i) {
    let e, o;
    return e = new Y({}), {
        c() {
            J(e.$$.fragment)
        },
        l(l) {
            K(e.$$.fragment, l)
        },
        m(l, n) {
            Q(e, l, n), o = !0
        },
        i(l) {
            o || (f(e.$$.fragment, l), o = !0)
        },
        o(l) {
            c(e.$$.fragment, l), o = !1
        },
        d(l) {
            R(e, l)
        }
    }
}

function C(i) {
    let e, o, l;
    const n = i[6].default,
        t = P(n, i, i[5], null);
    return {
        c() {
            e = E("div"), t && t.c(), this.h()
        },
        l(a) {
            e = L(a, "DIV", {
                class: !0,
                id: !0
            });
            var s = M(e);
            t && t.l(s), s.forEach(m), this.h()
        },
        h() {
            p(e, "class", "page-content"), p(e, "id", "main-content")
        },
        m(a, s) {
            V(a, e, s), t && t.m(e, null), l = !0
        },
        p(a, s) {
            t && t.p && (!l || s & 32) && T(t, n, a, a[5], l ? A(n, a[5], s, null) : z(a[5]), null)
        },
        i(a) {
            l || (f(t, a), a && (o || B(() => {
                o = U(e, Z, {
                    y: 10,
                    opacity: 0,
                    duration: 300
                }), o.start()
            })), l = !0)
        },
        o(a) {
            c(t, a), l = !1
        },
        d(a) {
            a && m(e), t && t.d(a)
        }
    }
}

function x(i) {
    let e, o, l, n = i[0] && w(),
        t = !i[0] && C(i);
    return {
        c() {
            e = E("div"), n && n.c(), o = j(), t && t.c(), this.h()
        },
        l(a) {
            e = L(a, "DIV", {
                class: !0
            });
            var s = M(e);
            n && n.l(s), o = q(s), t && t.l(s), s.forEach(m), this.h()
        },
        h() {
            p(e, "class", "content-wrapper svelte-vlgd3s"), b(e, "loading", i[0])
        },
        m(a, s) {
            V(a, e, s), n && n.m(e, null), F(e, o), t && t.m(e, null), l = !0
        },
        p(a, [s]) {
            a[0] ? n ? s & 1 && f(n, 1) : (n = w(), n.c(), f(n, 1), n.m(e, o)) : n && (k(), c(n, 1, 1, () => {
                n = null
            }), v()), a[0] ? t && (k(), c(t, 1, 1, () => {
                t = null
            }), v()) : t ? (t.p(a, s), s & 1 && f(t, 1)) : (t = C(a), t.c(), f(t, 1), t.m(e, null)), (!l || s & 1) && b(e, "loading", a[0])
        },
        i(a) {
            l || (f(n), f(t), l = !0)
        },
        o(a) {
            c(n), c(t), l = !1
        },
        d(a) {
            a && m(e), n && n.d(), t && t.d()
        }
    }
}

function $(i, e, o) {
    let l, n;
    S(i, W, r => o(4, l = r)), S(i, X, r => o(8, n = r));
    let {
        $$slots: t = {},
        $$scope: a
    } = e, {
        loading: s
    } = e, {
        noScroll: u = !1
    } = e, _ = n.url.pathname ? ? "", d, g = !1;
    const D = () => {
        let r = y.has(_),
            I = !u;
        o(0, g = !0), r === !1 ? (o(3, d = !1), y.add(_), I && h()) : o(3, d = !0)
    };
    return N(() => () => {
        u || h()
    }), i.$$set = r => {
        "loading" in r && o(1, s = r.loading), "noScroll" in r && o(2, u = r.noScroll), "$$scope" in r && o(5, a = r.$$scope)
    }, i.$$.update = () => {
        var r;
        i.$$.dirty & 16 && l && (_ = ((r = l.to) == null ? void 0 : r.url.pathname) ? ? ""), i.$$.dirty & 2 && (s ? D() : o(0, g = !1)), i.$$.dirty & 28 && !l && d && (u || h(), o(3, d = !1))
    }, [g, s, u, d, l, a, t]
}
class se extends G {
    constructor(e) {
        super(), H(this, e, $, x, O, {
            loading: 1,
            noScroll: 2
        })
    }
}
export {
    se as C
};