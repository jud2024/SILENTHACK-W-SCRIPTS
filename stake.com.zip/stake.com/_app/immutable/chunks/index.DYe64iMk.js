import {
    s as S,
    K as M,
    e as j,
    d as P,
    f as T,
    i as h,
    F as v,
    V as g,
    Q as N,
    j as V,
    k,
    L as q,
    c as b,
    M as U,
    t as F,
    O as w,
    h as C,
    P as K,
    l as D,
    n as p
} from "./scheduler.DXu26z7T.js";
import {
    S as L,
    i as Q,
    g as R,
    b as W,
    e as z,
    t as E,
    c as A,
    a as G,
    m as H,
    d as J
} from "./index.Dz_MmNB3.js";
import {
    g as X
} from "./spread.CgU5AtxT.js";
import {
    R as Y,
    O as Z,
    i as x,
    F as $,
    P as B,
    aq as O
} from "./index.B4-7gKq3.js";
import {
    P as ee
} from "./index.B1KDSkU5.js";
import {
    f as te
} from "./fiatNumberFormat.CcHMsn0U.js";

function re(n) {
    var f;
    let e, r = B(n[1], n[0], n[2]) + "",
        t, i, m = ((f = n[0]) == null ? void 0 : f.toUpperCase()) + "",
        c;
    return {
        c() {
            e = j("div"), t = F(r), i = w(), c = F(m), this.h()
        },
        l(s) {
            e = P(s, "DIV", {
                class: !0,
                "data-testid": !0
            });
            var u = T(e);
            t = C(u, r), i = K(u), c = C(u, m), u.forEach(h), this.h()
        },
        h() {
            v(e, "class", "crypto svelte-e4myuj"), v(e, "data-testid", "conversion-amount")
        },
        m(s, u) {
            V(s, e, u), k(e, t), k(e, i), k(e, c)
        },
        p(s, u) {
            var d;
            u & 7 && r !== (r = B(s[1], s[0], s[2]) + "") && D(t, r), u & 1 && m !== (m = ((d = s[0]) == null ? void 0 : d.toUpperCase()) + "") && D(c, m)
        },
        i: p,
        o: p,
        d(s) {
            s && h(e)
        }
    }
}

function ne(n) {
    let e = n[8].number(n[6] * n[1], {
            style: "currency",
            currency: n[4],
            minimumFractionDigits: 2
        }) + "",
        r;
    return {
        c() {
            r = F(e)
        },
        l(t) {
            r = C(t, e)
        },
        m(t, i) {
            V(t, r, i)
        },
        p(t, i) {
            i & 338 && e !== (e = t[8].number(t[6] * t[1], {
                style: "currency",
                currency: t[4],
                minimumFractionDigits: 2
            }) + "") && D(r, e)
        },
        i: p,
        o: p,
        d(t) {
            t && h(r)
        }
    }
}

function ie(n) {
    let e = O(n[1], n[7], {
            style: "currency",
            currency: n[0],
            minimumFractionDigits: 2
        }) + "",
        r;
    return {
        c() {
            r = F(e)
        },
        l(t) {
            r = C(t, e)
        },
        m(t, i) {
            V(t, r, i)
        },
        p(t, i) {
            i & 131 && e !== (e = O(t[1], t[7], {
                style: "currency",
                currency: t[0],
                minimumFractionDigits: 2
            }) + "") && D(r, e)
        },
        i: p,
        o: p,
        d(t) {
            t && h(r)
        }
    }
}

function ae(n) {
    let e, r;
    return e = new ee({
        props: {
            width: "4ch"
        }
    }), {
        c() {
            A(e.$$.fragment)
        },
        l(t) {
            G(e.$$.fragment, t)
        },
        m(t, i) {
            H(e, t, i), r = !0
        },
        p,
        i(t) {
            r || (E(e.$$.fragment, t), r = !0)
        },
        o(t) {
            W(e.$$.fragment, t), r = !1
        },
        d(t) {
            J(e, t)
        }
    }
}

function se(n) {
    let e, r, t, i, m, c;
    const f = [ae, ie, ne, re],
        s = [];

    function u(a, l) {
        return a[6] === void 0 ? 0 : a[0] in $ ? 1 : a[5] === "crypto" ? 2 : 3
    }
    t = u(n), i = s[t] = f[t](n);
    let d = [{
            class: "currency-conversion"
        }, n[9]],
        y = {};
    for (let a = 0; a < d.length; a += 1) y = M(y, d[a]);
    return {
        c() {
            e = j("div"), r = j("div"), i.c(), this.h()
        },
        l(a) {
            e = P(a, "DIV", {
                class: !0
            });
            var l = T(e);
            r = P(l, "DIV", {
                style: !0,
                class: !0
            });
            var _ = T(r);
            i.l(_), _.forEach(h), l.forEach(h), this.h()
        },
        h() {
            v(r, "style", m = n[3] ? `max-width: ${n[3]}` : void 0), v(r, "class", "svelte-e4myuj"), g(r, "is-truncate", !!n[3]), N(e, y), g(e, "svelte-e4myuj", !0)
        },
        m(a, l) {
            V(a, e, l), k(e, r), s[t].m(r, null), c = !0
        },
        p(a, [l]) {
            let _ = t;
            t = u(a), t === _ ? s[t].p(a, l) : (R(), W(s[_], 1, 1, () => {
                s[_] = null
            }), z(), i = s[t], i ? i.p(a, l) : (i = s[t] = f[t](a), i.c()), E(i, 1), i.m(r, null)), (!c || l & 8 && m !== (m = a[3] ? `max-width: ${a[3]}` : void 0)) && v(r, "style", m), (!c || l & 8) && g(r, "is-truncate", !!a[3]), N(e, y = X(d, [{
                class: "currency-conversion"
            }, l & 512 && a[9]])), g(e, "svelte-e4myuj", !0)
        },
        i(a) {
            c || (E(i), c = !0)
        },
        o(a) {
            W(i), c = !1
        },
        d(a) {
            a && h(e), s[t].d()
        }
    }
}

function oe(n, e, r) {
    let t, i;
    const m = ["currency", "amount", "roundingType", "truncateMaxWidth"];
    let c = q(e, m),
        f, s, u, d;
    b(n, Y, o => r(10, f = o)), b(n, Z, o => r(5, s = o)), b(n, te, o => r(7, u = o)), b(n, x, o => r(8, d = o));
    let {
        currency: y
    } = e, {
        amount: a
    } = e, {
        roundingType: l = "round"
    } = e, {
        truncateMaxWidth: _ = void 0
    } = e;
    return n.$$set = o => {
        e = M(M({}, e), U(o)), r(9, c = q(e, m)), "currency" in o && r(0, y = o.currency), "amount" in o && r(1, a = o.amount), "roundingType" in o && r(2, l = o.roundingType), "truncateMaxWidth" in o && r(3, _ = o.truncateMaxWidth)
    }, n.$$.update = () => {
        var o, I;
        n.$$.dirty & 32 && r(4, t = s === "crypto" ? "usd" : s), n.$$.dirty & 1041 && r(6, i = ((I = (o = f == null ? void 0 : f.rates) == null ? void 0 : o[y]) == null ? void 0 : I[t]) || void 0)
    }, [y, a, l, _, t, s, i, u, d, c, f]
}
class _e extends L {
    constructor(e) {
        super(), Q(this, e, oe, se, S, {
            currency: 0,
            amount: 1,
            roundingType: 2,
            truncateMaxWidth: 3
        })
    }
}
export {
    _e as C
};