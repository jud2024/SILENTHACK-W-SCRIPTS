import {
    z as m
} from "./variables.CIGccMR5.js";
const s = document.getElementsByTagName("body")[0],
    h = 400,
    C = (r, e) => {
        const t = r.getBoundingClientRect(),
            o = document.createElement("button"),
            {
                innerWidth: c,
                innerHeight: n
            } = window;
        window.requestAnimationFrame(() => {
            const g = document.getElementById("betslipFooter") ? "betslipFooter" : "betslipBet",
                a = g === "betslipBet" ? document.getElementById(`betslipBet_${e}`) : document.getElementById("betslipFooter");
            if (a) {
                const i = a.getBoundingClientRect();
                if (n - i.top !== 0) {
                    o.className = r.className;
                    const d = t.x,
                        l = t.top;
                    o.setAttribute("style", `
                    position: fixed;
                    width: ${t.width}px;
                    height: ${t.height}px;
                    border-radius: var(--radius-base);
                    top: ${l}px;
                    left: ${d}px;
                    background: var(--blue-500);
                    will-change: transform, opacity;
                    transform: translate(0, 0);
                    transform-origin: left top;
                    transition-property: transform, opacity;
                    transition-duration: ${h}ms;
                    z-index: ${m.betslip+1};
                    pointer-events: none;
                  `), s == null || s.appendChild(o), window.requestAnimationFrame(() => {
                        const p = document.getElementById("right-sidebar"),
                            f = g === "betslipFooter" ? i.left : p ? c - p.getBoundingClientRect().width + 14 : i.left,
                            u = i.top,
                            x = f - d,
                            b = u - l,
                            $ = i.width / t.width,
                            y = i.height / t.height;
                        o.style.opacity = "0.2", o.style.transform = `translate(${x}px, ${b}px) scale(${$}, ${y})`, o.style.zIndex = `${m.betslip+1}`, setTimeout(() => {
                            o.remove()
                        }, h - 10)
                    })
                }
            }
        })
    },
    I = r => {
        const e = r.getBoundingClientRect(),
            t = document.createElement("button"),
            {
                innerHeight: o
            } = window;
        window.requestAnimationFrame(() => {
            const c = document.getElementById("custom-bet-sticky-add");
            if (c) {
                const n = c.getBoundingClientRect();
                if (o - n.top !== 0) {
                    t.className = r.className;
                    const a = e.x,
                        i = e.top;
                    t.setAttribute("style", `
                    position: fixed;
                    width: ${e.width}px;
                    height: ${e.height}px;
                    border-radius: var(--radius-base);
                    top: ${i}px;
                    left: ${a}px;
                    background: var(--blue-500);
                    will-change: transform, opacity;
                    transform: translate(0, 0);
                    transform-origin: left top;
                    transition-property: transform, opacity;
                    transition-duration: ${h}ms;
                    z-index: ${m.betslip+1};
                    pointer-events: none;
                  `), s == null || s.appendChild(t), window.requestAnimationFrame(() => {
                        const w = n.left,
                            d = n.top,
                            l = w - a,
                            p = d - i,
                            f = n.width / e.width,
                            u = n.height / e.height;
                        t.style.opacity = "0.2", t.style.transform = `translate(${l}px, ${p}px) scale(${f}, ${u})`, t.style.zIndex = `${m.betslip+1}`, setTimeout(() => {
                            t.remove()
                        }, h - 10)
                    })
                }
            }
        })
    },
    v = r => {
        const e = r.getBoundingClientRect(),
            t = document.createElement("button"),
            {
                innerHeight: o
            } = window;
        window.requestAnimationFrame(() => {
            const c = document.getElementById("custom-swish-bet-sticky-add");
            if (c) {
                const n = c.getBoundingClientRect();
                if (o - n.top !== 0) {
                    t.className = r.className;
                    const a = e.x,
                        i = e.top;
                    t.setAttribute("style", `
                    position: fixed;
                    width: ${e.width}px;
                    height: ${e.height}px;
                    border-radius: var(--radius-base);
                    top: ${i}px;
                    left: ${a}px;
                    background: var(--blue-500);
                    will-change: transform, opacity;
                    transform: translate(0, 0);
                    transform-origin: left top;
                    transition-property: transform, opacity;
                    transition-duration: ${h}ms;
                    z-index: ${m.betslip+1};
                    pointer-events: none;
                  `), s == null || s.appendChild(t), window.requestAnimationFrame(() => {
                        const w = n.left,
                            d = n.top,
                            l = w - a,
                            p = d - i,
                            f = n.width / e.width,
                            u = n.height / e.height;
                        t.style.opacity = "0.2", t.style.transform = `translate(${l}px, ${p}px) scale(${f}, ${u})`, t.style.zIndex = `${m.betslip+1}`, setTimeout(() => {
                            t.remove()
                        }, h - 10)
                    })
                }
            }
        })
    };
export {
    I as a, v as b, C as c
};