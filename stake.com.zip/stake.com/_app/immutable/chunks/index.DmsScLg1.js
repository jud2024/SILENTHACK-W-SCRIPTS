import {
    v as G,
    x as H,
    s as J,
    a as F,
    e as w,
    O as A,
    d as O,
    f as D,
    P as E,
    i as p,
    F as g,
    V as I,
    j as V,
    k as b,
    W as K,
    u as P,
    g as W,
    b as X,
    X as L
} from "./scheduler.DXu26z7T.js";
import {
    S as M,
    i as N,
    t as h,
    g as y,
    b as v,
    e as S,
    c as Q,
    a as R,
    m as T,
    d as U
} from "./index.Dz_MmNB3.js";
import {
    A as Y
} from "./index.Cp95w4vW.js";
import {
    w as Z
} from "./index.C2-CG2CN.js"; /* empty css                                            */
const z = "isOpen",
    $ = t => {
        const e = Z(t);
        return G(z, e), e
    },
    re = () => H(z),
    x = t => ({
        isOpen: t & 4
    }),
    B = t => ({
        isOpen: t[2]
    }),
    ee = t => ({}),
    C = t => ({});

function j(t) {
    let e, l, f;
    return l = new Y({
        props: {
            isOpen: t[2]
        }
    }), {
        c() {
            e = w("div"), Q(l.$$.fragment), this.h()
        },
        l(o) {
            e = O(o, "DIV", {
                class: !0
            });
            var a = D(e);
            R(l.$$.fragment, a), a.forEach(p), this.h()
        },
        h() {
            g(e, "class", "arrow svelte-i9feae")
        },
        m(o, a) {
            V(o, e, a), T(l, e, null), f = !0
        },
        p(o, a) {
            const s = {};
            a & 4 && (s.isOpen = o[2]), l.$set(s)
        },
        i(o) {
            f || (h(l.$$.fragment, o), f = !0)
        },
        o(o) {
            v(l.$$.fragment, o), f = !1
        },
        d(o) {
            o && p(e), U(l)
        }
    }
}

function q(t) {
    let e, l, f;
    const o = t[6].default,
        a = F(o, t, t[5], B);
    return {
        c() {
            e = w("div"), l = w("div"), a && a.c(), this.h()
        },
        l(s) {
            e = O(s, "DIV", {
                class: !0
            });
            var c = D(e);
            l = O(c, "DIV", {});
            var m = D(l);
            a && a.l(m), m.forEach(p), c.forEach(p), this.h()
        },
        h() {
            g(e, "class", "content svelte-i9feae"), I(e, "is-open", t[2])
        },
        m(s, c) {
            V(s, e, c), b(e, l), a && a.m(l, null), f = !0
        },
        p(s, c) {
            a && a.p && (!f || c & 36) && P(a, o, s, s[5], f ? X(o, s[5], c, x) : W(s[5]), B), (!f || c & 4) && I(e, "is-open", s[2])
        },
        i(s) {
            f || (h(a, s), f = !0)
        },
        o(s) {
            v(a, s), f = !1
        },
        d(s) {
            s && p(e), a && a.d(s)
        }
    }
}

function se(t) {
    let e, l, f, o, a, s, c, m;
    const d = t[6].header,
        u = F(d, t, t[5], C);
    let r = t[1] && j(t),
        n = t[2] && q(t);
    return {
        c() {
            e = w("div"), l = w("div"), u && u.c(), f = A(), r && r.c(), o = A(), n && n.c(), this.h()
        },
        l(i) {
            e = O(i, "DIV", {
                class: !0
            });
            var _ = D(e);
            l = O(_, "DIV", {
                class: !0
            });
            var k = D(l);
            u && u.l(k), f = E(k), r && r.l(k), k.forEach(p), o = E(_), n && n.l(_), _.forEach(p), this.h()
        },
        h() {
            g(l, "class", "header svelte-i9feae"), g(e, "class", a = "secondary-accordion level-" + t[0] + " svelte-i9feae"), I(e, "is-open", t[2])
        },
        m(i, _) {
            V(i, e, _), b(e, l), u && u.m(l, null), b(l, f), r && r.m(l, null), b(e, o), n && n.m(e, null), s = !0, c || (m = K(l, "click", t[3]), c = !0)
        },
        p(i, [_]) {
            u && u.p && (!s || _ & 32) && P(u, d, i, i[5], s ? X(d, i[5], _, ee) : W(i[5]), C), i[1] ? r ? (r.p(i, _), _ & 2 && h(r, 1)) : (r = j(i), r.c(), h(r, 1), r.m(l, null)) : r && (y(), v(r, 1, 1, () => {
                r = null
            }), S()), i[2] ? n ? (n.p(i, _), _ & 4 && h(n, 1)) : (n = q(i), n.c(), h(n, 1), n.m(e, null)) : n && (y(), v(n, 1, 1, () => {
                n = null
            }), S()), (!s || _ & 1 && a !== (a = "secondary-accordion level-" + i[0] + " svelte-i9feae")) && g(e, "class", a), (!s || _ & 5) && I(e, "is-open", i[2])
        },
        i(i) {
            s || (h(u, i), h(r), h(n), s = !0)
        },
        o(i) {
            v(u, i), v(r), v(n), s = !1
        },
        d(i) {
            i && p(e), u && u.d(i), r && r.d(), n && n.d(), c = !1, m()
        }
    }
}

function te(t, e, l) {
    let {
        $$slots: f = {},
        $$scope: o
    } = e;
    const a = L();
    let {
        isOpenByDefault: s = !0
    } = e, {
        level: c = "2"
    } = e, {
        showArrow: m = !0
    } = e, d = s;
    const u = $(d),
        r = () => {
            l(2, d = !d), a("click", {
                isOpen: d
            })
        };
    return t.$$set = n => {
        "isOpenByDefault" in n && l(4, s = n.isOpenByDefault), "level" in n && l(0, c = n.level), "showArrow" in n && l(1, m = n.showArrow), "$$scope" in n && l(5, o = n.$$scope)
    }, t.$$.update = () => {
        t.$$.dirty & 4 && u.set(d)
    }, [c, m, d, r, s, o, f]
}
class fe extends M {
    constructor(e) {
        super(), N(this, e, te, se, J, {
            isOpenByDefault: 4,
            level: 0,
            showArrow: 1
        })
    }
}
export {
    fe as S, re as g
};