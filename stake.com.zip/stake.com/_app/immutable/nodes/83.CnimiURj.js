import {
    G as M,
    s as K,
    c as C,
    m as R,
    j as T,
    i as S,
    K as ut,
    e as se,
    O as w,
    d as le,
    f as re,
    P as B,
    F as ne,
    I as Re,
    k as oe,
    t as me,
    h as ue,
    l as ce,
    n as we,
    R as $e,
    o as ct
} from "../chunks/scheduler.DXu26z7T.js";
import {
    S as j,
    i as J,
    c as g,
    a as N,
    m as _,
    t as p,
    b as k,
    d as b,
    g as q,
    e as z
} from "../chunks/index.Dz_MmNB3.js";
import {
    e as Pe,
    u as dt,
    o as ft
} from "../chunks/each.DvgCmocI.js";
import {
    _ as de,
    aJ as Be,
    bq as pt,
    a$ as kt,
    br as $t,
    q as gt,
    P as _t,
    J as bt,
    h as E,
    i as _e
} from "../chunks/index.B4-7gKq3.js";
import {
    d as O,
    w as Z
} from "../chunks/index.C2-CG2CN.js";
import {
    c as vt
} from "../chunks/general.CID39R0-.js";
import {
    m as L
} from "../chunks/utils.Csgj0yys.js";
import {
    a as Nt,
    e as St
} from "../chunks/stateful.BQs6zK-E.js";
import {
    s as ie,
    M as yt,
    n as Tt
} from "../chunks/interpreter.CJhK2JTN.js";
import {
    e as ht
} from "../chunks/index.CIxv_5F2.js";
import {
    i as Ft
} from "../chunks/index.CgjaLSob.js";
import {
    a as Ct
} from "../chunks/index.C9RlN5Un.js";
import {
    b as wt,
    g as Bt,
    d as Dt,
    e as Et,
    f as Mt
} from "../chunks/autobet.C8QF9kCw.js";
import {
    e as ae
} from "../chunks/index.BxooaYHE.js";
import {
    c as At,
    g as De,
    s as Gt,
    b as Lt
} from "../chunks/setup.D-_1lgCN.js";
import {
    o as Ot,
    c as He,
    n as It,
    f as Rt
} from "../chunks/dateTimestampProvider.DBRuHdww.js";
import {
    d as Pt
} from "../chunks/debounceTime.Bb8mI86N.js";
import {
    i as Ht
} from "../chunks/innerFrom.BRHulYBS.js";
import {
    g as Vt
} from "../chunks/helpers.D2PNFi1L.js";
import {
    h as Y
} from "../chunks/howler.D2eOmZSY.js";
import {
    T as Ut
} from "../chunks/Tile.B1jkOndR.js";
import {
    g as qt,
    a as zt
} from "../chunks/spread.CgU5AtxT.js";
import {
    G as Kt
} from "../chunks/index.Cye6Vi7v.js";
import {
    G as Ee,
    c as jt
} from "../chunks/hotkeys.C2xOC7yd.js";
import {
    G as be
} from "../chunks/index.Bjt131AT.js";
import {
    G as Jt,
    a as je
} from "../chunks/index.DdQkJfwb.js";
import {
    a as Qt,
    b as Wt,
    c as xt,
    d as Yt,
    H as Zt,
    e as Xt,
    f as en
} from "../chunks/index.B-xtSfdy.js";
import {
    G as tn
} from "../chunks/index.BMPnnJxD.js";
import {
    G as nn,
    a as an
} from "../chunks/index.B0K9hyrm.js";
import {
    g as sn
} from "../chunks/stacked.pbGZL9o6.js";
import {
    S as ln
} from "../chunks/index.BvEEXkHb.js";
import {
    V as Je,
    u as rn
} from "../chunks/index.B81orGJm.js";
import {
    P as on
} from "../chunks/index.Cv1Qqo-5.js";
import {
    G as mn
} from "../chunks/index.BroebIup.js";
import {
    a as Ve
} from "../chunks/index.Dx3GbCCc.js"; /* empty css                                                    */
import {
    L as un
} from "../chunks/index.C0vu60o-.js";
import "../chunks/index.B3dW9TVs.js";
import {
    C as cn
} from "../chunks/contentOrLoader.Ol9dNjON.js";
import {
    B as dn
} from "../chunks/button.BwmFDw8u.js";
import {
    M as fn
} from "../chunks/index.D9vhXEWp.js";

function pn(s) {
    return Ot(function(t, n) {
        var e = [];
        return t.subscribe(He(n, function(i) {
                return e.push(i)
            }, function() {
                n.next(e), n.complete()
            })), Ht(s).subscribe(He(n, function() {
                var i = e;
                e = [], n.next(i)
            }, It)),
            function() {
                e = null
            }
    })
}
const kn = .99,
    Ce = de.range(0, 25),
    $n = ({
        fetchingTiles: s,
        rounds: t
    }) => {
        const n = Ce.filter(e => ![...s, ...t.map(({
            field: i
        }) => i)].includes(e));
        return n[Math.floor(Math.random() * n.length)]
    },
    gn = ({
        rounds: s,
        amount: t
    }) => {
        var a;
        const n = s.length - 1,
            e = ((a = s == null ? void 0 : s[n]) == null ? void 0 : a.payoutMultiplier) || 1;
        return {
            payout: t * e,
            multiplier: e
        }
    },
    _n = ({
        minesCount: s,
        rounds: t,
        amount: n
    }) => {
        const e = de.range(0, t.length + 1).reduce((a, l) => a * (Ce.length - l) / (Ce.length - s - l), kn);
        return {
            payout: n * (e - 1),
            multiplier: e
        }
    },
    {
        amount: X,
        currency: fe,
        lastBet: ve,
        tab: Ne,
        xstate: x,
        conversion: bn,
        amountValidationError: vn,
        fetching: Nn,
        disabled: Qe,
        hotkeysEnabled: Sn,
        inPlay: yn,
        modal: Tn,
        initialState: hn,
        balance: Fn
    } = vt({}),
    We = O([x], ([s]) => L("betTab.play", s) || L("autobetTab.betting", s)),
    xe = O([x], ([s]) => L("betTab", s) ? !L("betTab.play", s) : !L("autobetTab.idle", s)),
    Ye = O([x, ve], ([s, t]) => t !== null && (L("betTab.idle", s) || L("autobetTab.betting.base.revealing", s))),
    Se = Object.freeze(Object.defineProperty({
        __proto__: null,
        amount: X,
        amountValidationError: vn,
        balance: Fn,
        conversion: bn,
        currency: fe,
        disabled: Qe,
        fetching: Nn,
        hotkeysEnabled: Sn,
        inPlay: yn,
        initialState: hn,
        isInPlay: We,
        lastBet: ve,
        modal: Tn,
        showGameResult: Ye,
        tab: Ne,
        tileDisabled: xe,
        xstate: x
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    I = Z([]),
    ee = Z([]),
    Q = (() => {
        const s = Z([]);
        return { ...s,
            toggle: n => {
                const i = M(s).includes(n);
                I.set([]), ee.set([]), i ? Q.update(a => a.filter(l => l !== n)) : Q.update(a => [...a, n])
            }
        }
    })(),
    Cn = O([Q], ([s]) => s.length === 0),
    Ze = 3,
    V = (() => {
        const s = Z(Ze);
        return { ...s,
            change: t => {
                s.set(t), 25 - (M(Q).length + t) < 0 && Q.set([])
            }
        }
    })(),
    W = (() => {
        const s = Z([]);
        return { ...s,
            add: t => {
                s.update(n => [...n, t])
            },
            removeTiles: t => {
                s.update(n => de.without(n, ...t))
            }
        }
    })(),
    Xe = O([X, I], ([s, t]) => {
        const n = gn({
            rounds: t,
            amount: Number(s)
        });
        return {
            multiplier: n.multiplier,
            payout: Number(s) * n.multiplier,
            profit: Number(s) * (n.multiplier - 1)
        }
    });
O([X, V, Xe, I], ([s, t, n, e]) => {
    const i = _n({
        minesCount: t,
        rounds: e,
        amount: Number(s)
    });
    return {
        multiplier: 1 + (i.multiplier - n.multiplier),
        payout: Number(s) * (i.multiplier - n.multiplier)
    }
});
O([I], ([s]) => s.length === 0);
const et = O([x, ee, W], ([s, t, n]) => !L("betTab.play.idle", s) || n.length !== 0 || t.length !== 0),
    tt = O([I, x], ([s, t]) => s.length === 0 || !L("betTab.play.idle", t)),
    wn = O([V, I], ([s, t]) => 25 - s - t.filter(n => n.payoutMultiplier !== 0).length),
    Bn = O([x, ee, Ne], ([s, t, n]) => t.length !== 0 && (n === "manual" ? L("betTab.idle", s) || L("betTab.play.bustedRevealed", s) : L("autobetTab.betting.base.idle", s) || L("autobetTab.betting.base.revealing", s))),
    ge = ["addBetToContext", "setBetState"],
    Ue = {
        TILE_CLICK: {
            target: "next",
            actions: "fetchTile"
        },
        ADD_GEM: {
            target: "next",
            actions: ge
        },
        FINISH_GAME: {
            target: "nextBusted",
            actions: ge
        }
    },
    Dn = {
        initial: "idle",
        id: "betTab.play",
        exit: "finishGame",
        entry: ge,
        states: {
            idle: {
                on: { ...Ue,
                    CASHOUT: "cashingout"
                }
            },
            next: {
                on: { ...Ue,
                    ERROR: "idle",
                    NOT_FOUND: "#betTab.idle",
                    FINISHED_ALL_FETCHING: "idle"
                }
            },
            nextBusted: {
                on: {
                    TO_IDLE: "#betTab.idle"
                },
                invoke: {
                    id: "#play.nextBusted",
                    src: () => s => {
                        setTimeout(() => {
                            s("TO_IDLE")
                        }, 500)
                    }
                }
            },
            cashingout: {
                invoke: {
                    id: "mutationCashout",
                    src: "mutationCashout",
                    onDone: {
                        actions: ie((s, t) => ({
                            type: "CASHOUT_SUCCESS",
                            bet: t.data
                        }))
                    },
                    onError: {
                        actions: ie("CASHOUT_ERROR")
                    }
                },
                on: {
                    CASHOUT_SUCCESS: {
                        target: "#betTab.idle",
                        actions: ge
                    },
                    CASHOUT_ERROR: "idle"
                }
            }
        }
    },
    En = {
        states: {
            idle: {
                exit: "resetBetState"
            },
            fetching: {
                entry: ie({
                    type: "BET",
                    bet: {
                        rounds: [],
                        mines: []
                    }
                })
            },
            play: Dn
        }
    },
    Mn = Nt(En),
    An = {
        entry: ["resetBetState", "autobetEnter", "initAutobetDefaultStrategies"],
        exit: ["resetBetState", "resetLastBet"],
        states: {
            idle: {
                on: {
                    TILE_CLICK: {
                        actions: "toggleSelectedTile",
                        cond: (s, t) => {
                            const n = M(Q),
                                e = M(V),
                                i = 25 - (n.length + e);
                            return n.includes(t.tileNumber) || i !== 0
                        }
                    }
                }
            },
            betting: {
                states: {
                    base: {
                        states: {
                            idle: {},
                            fetching: {
                                entry: ["resetBetState"],
                                invoke: {
                                    id: "mutationAutobet",
                                    src: "mutationAutobet",
                                    onDone: {
                                        actions: ie((s, t) => ({
                                            type: "SUCCESS",
                                            bet: t.data
                                        }))
                                    },
                                    onError: {
                                        actions: ie("ERROR")
                                    }
                                },
                                on: {
                                    SUCCESS: {
                                        actions: ["addBetToContext", "setBetState", "finishAutobetGame"]
                                    },
                                    ERROR: "#autobetTab.idle"
                                }
                            },
                            revealing: {
                                on: {
                                    TO_IDLE: "idle"
                                },
                                invoke: {
                                    id: "revealingTimeout",
                                    src: () => s => {
                                        M(Ft) === !1 ? setTimeout(() => {
                                            s("TO_IDLE")
                                        }, 1e3) : setTimeout(() => {
                                            s("TO_IDLE")
                                        }, 500)
                                    }
                                }
                            }
                        }
                    },
                    nextBet: {
                        states: {
                            continue: {},
                            stop: {}
                        }
                    }
                }
            }
        }
    },
    Gn = ht(An),
    Ln = {
        states: {
            idle: {},
            fetching: {}
        }
    },
    On = St(Ln),
    In = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "mutation",
            name: {
                kind: "Name",
                value: "MinesBet"
            },
            variableDefinitions: [{
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "amount"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "Float"
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "CurrencyEnum"
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "minesCount"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "Int"
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "fields"
                    }
                },
                type: {
                    kind: "ListType",
                    type: {
                        kind: "NonNullType",
                        type: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "Int"
                            }
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "identifier"
                    }
                },
                type: {
                    kind: "NamedType",
                    name: {
                        kind: "Name",
                        value: "String"
                    }
                }
            }],
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "minesBet"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "amount"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "amount"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "currency"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "currency"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "minesCount"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "minesCount"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "fields"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "fields"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "identifier"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "identifier"
                            }
                        }
                    }],
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "CasinoBet"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "state"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "CasinoGameMines"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "CasinoBet"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "CasinoBet"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payoutMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "amountMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "amount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payout"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "updatedAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "game"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "CasinoGameMines"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "CasinoGameMines"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "mines"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "minesCount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "rounds"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "field"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "payoutMultiplier"
                            }
                        }]
                    }
                }]
            }
        }]
    },
    Rn = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "mutation",
            name: {
                kind: "Name",
                value: "MinesNext"
            },
            variableDefinitions: [{
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "fields"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "ListType",
                        type: {
                            kind: "NonNullType",
                            type: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "Int"
                                }
                            }
                        }
                    }
                }
            }],
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "minesNext"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "fields"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "fields"
                            }
                        }
                    }],
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "CasinoBet"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "state"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "CasinoGameMines"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "CasinoBet"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "CasinoBet"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payoutMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "amountMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "amount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payout"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "updatedAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "game"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "CasinoGameMines"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "CasinoGameMines"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "mines"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "minesCount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "rounds"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "field"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "payoutMultiplier"
                            }
                        }]
                    }
                }]
            }
        }]
    },
    Pn = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "mutation",
            name: {
                kind: "Name",
                value: "MinesCashout"
            },
            variableDefinitions: [{
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "identifier"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "String"
                        }
                    }
                }
            }],
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "minesCashout"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "identifier"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "identifier"
                            }
                        }
                    }],
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "CasinoBet"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "state"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "CasinoGameMines"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "CasinoBet"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "CasinoBet"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payoutMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "amountMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "amount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payout"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "updatedAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "game"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "CasinoGameMines"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "CasinoGameMines"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "mines"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "minesCount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "rounds"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "field"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "payoutMultiplier"
                            }
                        }]
                    }
                }]
            }
        }]
    },
    Hn = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "query",
            name: {
                kind: "Name",
                value: "MinesActiveBet"
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "activeCasinoBet"
                            },
                            arguments: [{
                                kind: "Argument",
                                name: {
                                    kind: "Name",
                                    value: "game"
                                },
                                value: {
                                    kind: "EnumValue",
                                    value: "mines"
                                }
                            }],
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "CasinoBet"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "state"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "FragmentSpread",
                                            name: {
                                                kind: "Name",
                                                value: "CasinoGameMines"
                                            }
                                        }]
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "CasinoBet"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "CasinoBet"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payoutMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "amountMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "amount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payout"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "updatedAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "game"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "CasinoGameMines"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "CasinoGameMines"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "mines"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "minesCount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "rounds"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "field"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "payoutMultiplier"
                            }
                        }]
                    }
                }]
            }
        }]
    },
    {
        config: Vn,
        requestClient: ye
    } = At({
        name: Be.mines,
        slug: "mines",
        apiUrl: pt,
        getSession: kt,
        headers: {
            "x-lockdown-token": $t
        }
    }),
    nt = "NOT_FOUND",
    it = async s => new Promise((t, n) => {
        async function e() {
            try {
                const {
                    data: i
                } = await ye(In, s);
                i != null && i.minesBet ? t({ ...i.minesBet,
                    identifier: s.identifier
                }) : n()
            } catch (i) {
                n(i)
            }
        }
        e()
    }),
    Un = async s => new Promise((t, n) => {
        async function e() {
            try {
                const {
                    data: i
                } = await ye(Rn, s);
                i != null && i.minesNext ? t(i.minesNext) : n()
            } catch (i) {
                const l = (i.errors || []).some(o => o.errorType === "notFound");
                n(l ? nt : i)
            }
        }
        e()
    }),
    qn = async s => new Promise((t, n) => {
        async function e() {
            try {
                const {
                    data: i
                } = await ye(Pn, s);
                i != null && i.minesCashout ? t({ ...i.minesCashout,
                    identifier: s.identifier
                }) : n()
            } catch (i) {
                n(i)
            }
        }
        e()
    }),
    zn = async () => new Promise((s, t) => {
        async function n() {
            var e;
            try {
                const {
                    data: i
                } = await ye(Hn, {}), a = (e = i == null ? void 0 : i.user) == null ? void 0 : e.activeCasinoBet;
                a ? s(a) : t()
            } catch (i) {
                t(i)
            }
        }
        n()
    }),
    {
        betHistory: Kn,
        blockTriggers: jn,
        blocks: Jn,
        currentStrategyLabel: Qn,
        gamesLeft: Wn,
        loadStrategy: xn,
        saveStrategy: Yn,
        resetState: at,
        allowedActions: Zn,
        initDefaultAdvancedStrategies: Xn,
        initDefaultStrategies: ei
    } = wt(),
    st = () => new Promise((s, t) => {
        async function n() {
            const e = gt[M(fe)],
                i = Number(M(X)),
                a = ae.generate({
                    game: "mines",
                    amount: i,
                    currency: e
                });
            try {
                const l = await it({
                    amount: i,
                    currency: e,
                    identifier: a,
                    minesCount: M(V),
                    fields: M(Q)
                });
                s(l)
            } catch (l) {
                ae.remove(a), t(l)
            }
        }
        n()
    }),
    {
        entry: ti,
        exit: ni,
        resetAutobetState: ii
    } = Bt(at),
    Me = Object.freeze(Object.defineProperty({
        __proto__: null,
        allowedActions: Zn,
        betHistory: Kn,
        blockTriggers: jn,
        blocks: Jn,
        currentStrategyLabel: Qn,
        entry: ti,
        exit: ni,
        gamesLeft: Wn,
        initDefaultAdvancedStrategies: Xn,
        initDefaultStrategies: ei,
        loadStrategy: xn,
        mutationAutobet: st,
        resetAutobetState: ii,
        resetState: at,
        saveStrategy: Yn
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    Ae = new Rt,
    ai = Ae.pipe(Pt(200)),
    si = Ae.pipe(pn(ai)),
    {
        assign: li
    } = Ct,
    Ge = Dt({
        initialState: {},
        removeDeduction: s => {
            ae.remove(s)
        },
        setLastBet: s => {
            ve.set(s)
        },
        removeActiveBet: () => {},
        general: Se,
        autobet: Me
    }),
    {
        addBetToContext: ri,
        snapshotAutobetInfo: oi,
        setInitialBettingState: mi,
        initAutobetDefaultStrategies: ui
    } = Ge,
    ci = Ge.finishGame(() => !0),
    di = Ge.finishGame(() => !1),
    lt = () => ve.set(null),
    fi = () => {
        li({
            bet: () => null
        }), I.set([]), ee.set([]), lt()
    },
    pi = (s, t) => {
        Q.toggle(t.tileNumber)
    },
    ki = s => {
        const {
            bet: t
        } = s, {
            state: n,
            amount: e,
            currency: i
        } = t;
        fe.set(i), X.set(_t(e, i)), t.active === !1 && W.set([]), ee.set((n == null ? void 0 : n.mines) || []), I.set(n.rounds), V.set(n.minesCount)
    },
    $i = (s, t) => {
        const {
            tileNumber: n
        } = t;
        W.add(n), Ae.next({
            tileNumber: n
        })
    },
    gi = Object.freeze(Object.defineProperty({
        __proto__: null,
        addBetToContext: ri,
        fetchTile: $i,
        finishAutobetGame: di,
        finishGame: ci,
        initAutobetDefaultStrategies: ui,
        resetBetState: fi,
        resetLastBet: lt,
        setBetState: ki,
        setInitialBettingState: mi,
        snapshotAutobetInfo: oi,
        toggleSelectedTile: pi
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    _i = async () => await zn(),
    bi = async () => {
        const s = {
            currency: M(fe),
            amount: Number(M(X)),
            minesCount: M(V)
        };
        return await it(s)
    },
    vi = async () => {
        const s = ae.generate({
            game: "mines"
        });
        try {
            return await qn({
                identifier: s
            })
        } catch (t) {
            throw ae.remove(s), t
        }
    },
    Ni = ({
        blockResults: s,
        general: t
    }) => Vt({
        blockResults: s,
        amount: t == null ? void 0 : t.amount
    }),
    Si = () => st(),
    {
        requestState: yi,
        mutationBet: Ti,
        mutationCashout: hi,
        decideOnNextBet: Fi
    } = Et({
        services: {
            mutationBet: bi,
            mutationCashout: vi,
            requestState: _i
        },
        moduleName: Be.mines,
        general: Se,
        autobet: Me,
        handler: Ni
    }),
    Ci = Object.freeze(Object.defineProperty({
        __proto__: null,
        decideOnNextBet: Fi,
        mutationAutobet: Si,
        mutationBet: Ti,
        mutationCashout: hi,
        requestState: yi
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    wi = {
        id: "mines",
        initial: "getState",
        context: {
            bet: null,
            firstBet: null
        },
        states: {
            getState: On,
            betTab: Mn,
            autobetTab: Gn,
            advancedTab: {
                id: "advancedTab",
                states: {}
            }
        }
    },
    Bi = yt(wi, {
        actions: gi,
        services: Ci
    }),
    U = Tt(Bi, {
        deferEvents: !0,
        devTools: !0
    }),
    Di = Mt({
        service: U,
        gameName: "mines",
        resetState: () => {},
        tab: Ne,
        xstate: x
    }),
    Ei = "/_app/immutable/assets/idle.CnoNmvUu.mp3",
    Mi = "/_app/immutable/assets/selected.BhRFqzlq.mp3",
    Ai = "/_app/immutable/assets/mine.DwyaPDKk.mp3",
    Gi = "/_app/immutable/assets/gem0.-F12_z-j.mp3",
    Li = "/_app/immutable/assets/gem1.GsL8JfTB.mp3",
    Oi = "/_app/immutable/assets/gem2.LRZteFQ0.mp3",
    Fe = {
        idle: new Y.Howl({
            src: [Ei]
        }),
        isSelected: new Y.Howl({
            src: [Mi]
        }),
        mine: new Y.Howl({
            src: [Ai]
        }),
        gem0: new Y.Howl({
            src: [Gi]
        }),
        gem1: new Y.Howl({
            src: [Li]
        }),
        gem2: new Y.Howl({
            src: [Oi]
        })
    };

function Ii(s) {
    let t, n;
    return t = new Ut({
        props: {
            index: s[0],
            status: s[4],
            selected: s[2],
            disabled: s[5] || s[1] === "automated" ? !1 : s[3],
            revealed: s[3]
        }
    }), t.$on("click", s[10]), {
        c() {
            g(t.$$.fragment)
        },
        l(e) {
            N(t.$$.fragment, e)
        },
        m(e, i) {
            _(t, e, i), n = !0
        },
        p(e, [i]) {
            const a = {};
            i & 1 && (a.index = e[0]), i & 16 && (a.status = e[4]), i & 4 && (a.selected = e[2]), i & 42 && (a.disabled = e[5] || e[1] === "automated" ? !1 : e[3]), i & 8 && (a.revealed = e[3]), t.$set(a)
        },
        i(e) {
            n || (p(t.$$.fragment, e), n = !0)
        },
        o(e) {
            k(t.$$.fragment, e), n = !1
        },
        d(e) {
            b(t, e)
        }
    }
}

function Ri(s, t, n) {
    let e, i, a, l, o, r;
    C(s, V, m => n(11, e = m)), C(s, I, m => n(12, i = m)), C(s, Q, m => n(9, l = m)), C(s, xe, m => n(5, r = m));
    let {
        index: u
    } = t, {
        tab: c
    } = t, y = !1, h = !1;
    const d = O([I], ([m]) => m.some(F => F.field === u));
    C(s, d, m => n(3, a = m));
    const v = O([I, ee, W, Bn], ([m, F, A, G]) => {
        const pe = m.some(ke => ke.field === u),
            te = c === "manual" && pe || G,
            H = F.includes(u);
        return te && H ? "mine" : te && !H ? "gem" : A.includes(u) ? "fetching" : "idle"
    });
    C(s, v, m => n(4, o = m)), bt(v, ({
        current: m
    }) => {
        if (a && c === "manual") {
            if (m === "gem") {
                const F = i.length / (25 - e),
                    A = `gem${Math.min(2,Math.floor(F*3))}`;
                Fe[A].play()
            }
            m === "mine" && Fe.mine.play()
        }
    });
    const $ = () => U.send({
        type: "TILE_CLICK",
        tileNumber: u
    });
    return s.$$set = m => {
        "index" in m && n(0, u = m.index), "tab" in m && n(1, c = m.tab)
    }, s.$$.update = () => {
        s.$$.dirty & 775 && (n(8, h = y), n(2, y = l.includes(u) && c === "automated"), h !== y && c === "automated" && Fe.isSelected.play())
    }, [u, c, y, a, o, r, d, v, h, l, $]
}
class Pi extends j {
    constructor(t) {
        super(), J(this, t, Ri, Ii, K, {
            index: 0,
            tab: 1
        })
    }
}

function qe(s) {
    let t, n;
    const e = [s[1]];
    let i = {};
    for (let a = 0; a < e.length; a += 1) i = ut(i, e[a]);
    return t = new Kt({
        props: i
    }), {
        c() {
            g(t.$$.fragment)
        },
        l(a) {
            N(t.$$.fragment, a)
        },
        m(a, l) {
            _(t, a, l), n = !0
        },
        p(a, l) {
            const o = l & 2 ? qt(e, [zt(a[1])]) : {};
            t.$set(o)
        },
        i(a) {
            n || (p(t.$$.fragment, a), n = !0)
        },
        o(a) {
            k(t.$$.fragment, a), n = !1
        },
        d(a) {
            b(t, a)
        }
    }
}

function Hi(s) {
    let t, n, e = s[0] && qe(s);
    return {
        c() {
            e && e.c(), t = R()
        },
        l(i) {
            e && e.l(i), t = R()
        },
        m(i, a) {
            e && e.m(i, a), T(i, t, a), n = !0
        },
        p(i, [a]) {
            i[0] ? e ? (e.p(i, a), a & 1 && p(e, 1)) : (e = qe(i), e.c(), p(e, 1), e.m(t.parentNode, t)) : e && (q(), k(e, 1, 1, () => {
                e = null
            }), z())
        },
        i(i) {
            n || (p(e), n = !0)
        },
        o(i) {
            k(e), n = !1
        },
        d(i) {
            i && S(t), e && e.d(i)
        }
    }
}

function Vi(s, t, n) {
    let e, i;
    C(s, Ye, l => n(0, e = l));
    const {
        lastBet: a
    } = De();
    return C(s, a, l => n(1, i = l)), [e, i, a]
}
class Ui extends j {
    constructor(t) {
        super(), J(this, t, Vi, Hi, K, {})
    }
}

function ze(s, t, n) {
    const e = s.slice();
    return e[3] = t[n], e
}

function Ke(s, t) {
    let n, e, i;
    return e = new Pi({
        props: {
            index: t[3],
            tab: t[1]
        }
    }), {
        key: s,
        first: null,
        c() {
            n = R(), g(e.$$.fragment), this.h()
        },
        l(a) {
            n = R(), N(e.$$.fragment, a), this.h()
        },
        h() {
            this.first = n
        },
        m(a, l) {
            T(a, n, l), _(e, a, l), i = !0
        },
        p(a, l) {
            t = a;
            const o = {};
            l & 2 && (o.tab = t[1]), e.$set(o)
        },
        i(a) {
            i || (p(e.$$.fragment, a), i = !0)
        },
        o(a) {
            k(e.$$.fragment, a), i = !1
        },
        d(a) {
            a && S(n), b(e, a)
        }
    }
}

function qi(s) {
    let t, n = [],
        e = new Map,
        i, a, l, o = Pe(s[2]);
    const r = u => u[3];
    for (let u = 0; u < o.length; u += 1) {
        let c = ze(s, o, u),
            y = r(c);
        e.set(y, n[u] = Ke(y, c))
    }
    return a = new Ui({}), {
        c() {
            t = se("div");
            for (let u = 0; u < n.length; u += 1) n[u].c();
            i = w(), g(a.$$.fragment), this.h()
        },
        l(u) {
            t = le(u, "DIV", {
                class: !0,
                style: !0,
                "data-test": !0
            });
            var c = re(t);
            for (let y = 0; y < n.length; y += 1) n[y].l(c);
            i = B(c), N(a.$$.fragment, c), c.forEach(S), this.h()
        },
        h() {
            ne(t, "class", "wrap svelte-mm6hdp"), Re(t, "font-size", s[0] + "em"), ne(t, "data-test", "game-mines")
        },
        m(u, c) {
            T(u, t, c);
            for (let y = 0; y < n.length; y += 1) n[y] && n[y].m(t, null);
            oe(t, i), _(a, t, null), l = !0
        },
        p(u, [c]) {
            c & 6 && (o = Pe(u[2]), q(), n = dt(n, c, r, 1, u, o, e, t, ft, Ke, i, ze), z()), (!l || c & 1) && Re(t, "font-size", u[0] + "em")
        },
        i(u) {
            if (!l) {
                for (let c = 0; c < o.length; c += 1) p(n[c]);
                p(a.$$.fragment, u), l = !0
            }
        },
        o(u) {
            for (let c = 0; c < n.length; c += 1) k(n[c]);
            k(a.$$.fragment, u), l = !1
        },
        d(u) {
            u && S(t);
            for (let c = 0; c < n.length; c += 1) n[c].d();
            b(a)
        }
    }
}

function zi(s, t, n) {
    let {
        scale: e
    } = t;
    const i = de.range(0, 25);
    let {
        tab: a
    } = t;
    return s.$$set = l => {
        "scale" in l && n(0, e = l.scale), "tab" in l && n(1, a = l.tab)
    }, [e, a, i]
}
class Ki extends j {
    constructor(t) {
        super(), J(this, t, zi, qi, K, {
            scale: 0,
            tab: 1
        })
    }
}
const Le = {
        minesCountLabel: E._("Mines"),
        low: E._("Low"),
        classic: E._("Classic"),
        medium: E._("Medium"),
        high: E._("High"),
        autoPick: E._("Auto Pick"),
        clear: E._("Clear Table"),
        explanation: E._("Select 1 - 10 numbers to play"),
        payout: E._("Payout"),
        chance: E._("Chance"),
        totalProfit: s => ({
            id: "Total profit ({multiplier}×)",
            values: {
                multiplier: s
            }
        }),
        minesLeft: E._("Mines"),
        gemsLeft: E._("Gems"),
        pickRandomTile: E._("Pick random tile"),
        cashout: E._("Cashout")
    },
    ji = { ...Le,
        payout: E._("Winnings"),
        totalProfit: s => ({
            id: "Total net gain ({multiplier}×)",
            values: {
                multiplier: s
            }
        })
    },
    Ji = {
        stake: Le,
        sweeps: ji
    },
    P = Ji[Je] || Le;

function Qi(s) {
    let t = s[2]._(P.minesCountLabel) + "",
        n;
    return {
        c() {
            n = me(t)
        },
        l(e) {
            n = ue(e, t)
        },
        m(e, i) {
            T(e, n, i)
        },
        p(e, i) {
            i & 4 && t !== (t = e[2]._(P.minesCountLabel) + "") && ce(n, t)
        },
        d(e) {
            e && S(n)
        }
    }
}

function Wi(s) {
    let t, n;
    return t = new ln({
        props: {
            "data-test": "mines-count",
            name: "mines-count",
            stacked: !0,
            disabled: s[0],
            value: String(s[1]),
            options: s[3],
            $$slots: {
                label: [Qi]
            },
            $$scope: {
                ctx: s
            }
        }
    }), t.$on("change", s[4]), {
        c() {
            g(t.$$.fragment)
        },
        l(e) {
            N(t.$$.fragment, e)
        },
        m(e, i) {
            _(t, e, i), n = !0
        },
        p(e, [i]) {
            const a = {};
            i & 1 && (a.disabled = e[0]), i & 2 && (a.value = String(e[1])), i & 36 && (a.$$scope = {
                dirty: i,
                ctx: e
            }), t.$set(a)
        },
        i(e) {
            n || (p(t.$$.fragment, e), n = !0)
        },
        o(e) {
            k(t.$$.fragment, e), n = !1
        },
        d(e) {
            b(t, e)
        }
    }
}

function xi(s, t, n) {
    let e, i, a;
    return C(s, Qe, r => n(0, e = r)), C(s, V, r => n(1, i = r)), C(s, _e, r => n(2, a = r)), [e, i, a, ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24"], r => {
        V.change(Number(r.detail.currentTarget.value))
    }]
}
class Oe extends j {
    constructor(t) {
        super(), J(this, t, xi, Wi, K, {})
    }
}

function Yi(s) {
    let t, n = s[2]._(P.totalProfit(s[1].multiplier.toFixed(2))) + "",
        e;
    return {
        c() {
            t = se("span"), e = me(n), this.h()
        },
        l(i) {
            t = le(i, "SPAN", {
                slot: !0
            });
            var a = re(t);
            e = ue(a, n), a.forEach(S), this.h()
        },
        h() {
            ne(t, "slot", "label")
        },
        m(i, a) {
            T(i, t, a), oe(t, e)
        },
        p(i, a) {
            a & 6 && n !== (n = i[2]._(P.totalProfit(i[1].multiplier.toFixed(2))) + "") && ce(e, n)
        },
        d(i) {
            i && S(t)
        }
    }
}

function Zi(s) {
    let t, n;
    return t = new on({
        props: {
            currency: s[0],
            value: s[1].profit,
            hideConversion: rn === !1,
            $$slots: {
                label: [Yi]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            g(t.$$.fragment)
        },
        l(e) {
            N(t.$$.fragment, e)
        },
        m(e, i) {
            _(t, e, i), n = !0
        },
        p(e, [i]) {
            const a = {};
            i & 1 && (a.currency = e[0]), i & 2 && (a.value = e[1].profit), i & 14 && (a.$$scope = {
                dirty: i,
                ctx: e
            }), t.$set(a)
        },
        i(e) {
            n || (p(t.$$.fragment, e), n = !0)
        },
        o(e) {
            k(t.$$.fragment, e), n = !1
        },
        d(e) {
            b(t, e)
        }
    }
}

function Xi(s, t, n) {
    let e, i, a;
    return C(s, fe, l => n(0, e = l)), C(s, Xe, l => n(1, i = l)), C(s, _e, l => n(2, a = l)), [e, i, a]
}
class rt extends j {
    constructor(t) {
        super(), J(this, t, Xi, Zi, K, {})
    }
}

function ea(s) {
    let t, n = s[1]._(P.minesLeft) + "",
        e;
    return {
        c() {
            t = se("span"), e = me(n), this.h()
        },
        l(i) {
            t = le(i, "SPAN", {
                slot: !0
            });
            var a = re(t);
            e = ue(a, n), a.forEach(S), this.h()
        },
        h() {
            ne(t, "slot", "label")
        },
        m(i, a) {
            T(i, t, a), oe(t, e)
        },
        p(i, a) {
            a & 2 && n !== (n = i[1]._(P.minesLeft) + "") && ce(e, n)
        },
        d(i) {
            i && S(t)
        }
    }
}

function ta(s) {
    let t, n = s[1]._(P.gemsLeft) + "",
        e;
    return {
        c() {
            t = se("span"), e = me(n), this.h()
        },
        l(i) {
            t = le(i, "SPAN", {
                slot: !0
            });
            var a = re(t);
            e = ue(a, n), a.forEach(S), this.h()
        },
        h() {
            ne(t, "slot", "label")
        },
        m(i, a) {
            T(i, t, a), oe(t, e)
        },
        p(i, a) {
            a & 2 && n !== (n = i[1]._(P.gemsLeft) + "") && ce(e, n)
        },
        d(i) {
            i && S(t)
        }
    }
}

function na(s) {
    let t, n, e, i;
    return t = new Ve({
        props: {
            readOnly: !0,
            stacked: !0,
            value: s[0],
            iconAfter: "stake-game-mines",
            $$slots: {
                label: [ea]
            },
            $$scope: {
                ctx: s
            }
        }
    }), e = new Ve({
        props: {
            readOnly: !0,
            stacked: !0,
            value: s[2],
            iconAfter: "stake-game-diamond-poker",
            $$slots: {
                label: [ta]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            g(t.$$.fragment), n = w(), g(e.$$.fragment)
        },
        l(a) {
            N(t.$$.fragment, a), n = B(a), N(e.$$.fragment, a)
        },
        m(a, l) {
            _(t, a, l), T(a, n, l), _(e, a, l), i = !0
        },
        p(a, l) {
            const o = {};
            l & 1 && (o.value = a[0]), l & 10 && (o.$$scope = {
                dirty: l,
                ctx: a
            }), t.$set(o);
            const r = {};
            l & 4 && (r.value = a[2]), l & 10 && (r.$$scope = {
                dirty: l,
                ctx: a
            }), e.$set(r)
        },
        i(a) {
            i || (p(t.$$.fragment, a), p(e.$$.fragment, a), i = !0)
        },
        o(a) {
            k(t.$$.fragment, a), k(e.$$.fragment, a), i = !1
        },
        d(a) {
            a && S(n), b(t, a), b(e, a)
        }
    }
}

function ia(s) {
    let t, n;
    return t = new mn({
        props: {
            $$slots: {
                default: [na]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            g(t.$$.fragment)
        },
        l(e) {
            N(t.$$.fragment, e)
        },
        m(e, i) {
            _(t, e, i), n = !0
        },
        p(e, [i]) {
            const a = {};
            i & 15 && (a.$$scope = {
                dirty: i,
                ctx: e
            }), t.$set(a)
        },
        i(e) {
            n || (p(t.$$.fragment, e), n = !0)
        },
        o(e) {
            k(t.$$.fragment, e), n = !1
        },
        d(e) {
            b(t, e)
        }
    }
}

function aa(s, t, n) {
    let e, i, a;
    return C(s, V, l => n(0, e = l)), C(s, _e, l => n(1, i = l)), C(s, wn, l => n(2, a = l)), [e, i, a]
}
class ot extends j {
    constructor(t) {
        super(), J(this, t, aa, ia, K, {})
    }
}
const mt = () => {
        const s = $n({
            rounds: M(I),
            fetchingTiles: M(W)
        });
        U.send({
            type: "TILE_CLICK",
            tileNumber: s
        })
    },
    sa = () => si.subscribe(async s => {
        const t = de.uniq(s.map(e => e.tileNumber)),
            n = {
                fields: t
            };
        try {
            const e = await Un(n);
            W.removeTiles(t), e.active ? (U.send({
                type: "ADD_GEM",
                bet: e
            }), M(W).length === 0 && U.send({
                type: "FINISHED_ALL_FETCHING"
            })) : U.send({
                type: "FINISH_GAME",
                bet: e
            })
        } catch (e) {
            const i = e === nt;
            W.removeTiles(t), U.send({
                type: i ? "NOT_FOUND" : "ERROR"
            })
        }
    });

function la(s) {
    let t, n = s[2]._(P.pickRandomTile) + "",
        e;
    return {
        c() {
            t = se("span"), e = me(n)
        },
        l(i) {
            t = le(i, "SPAN", {});
            var a = re(t);
            e = ue(a, n), a.forEach(S)
        },
        m(i, a) {
            T(i, t, a), oe(t, e)
        },
        p(i, a) {
            a & 4 && n !== (n = i[2]._(P.pickRandomTile) + "") && ce(e, n)
        },
        d(i) {
            i && S(t)
        }
    }
}

function ra(s) {
    let t, n;
    return t = new cn({
        props: {
            loader: un,
            loading: s[1],
            $$slots: {
                default: [la]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            g(t.$$.fragment)
        },
        l(e) {
            N(t.$$.fragment, e)
        },
        m(e, i) {
            _(t, e, i), n = !0
        },
        p(e, i) {
            const a = {};
            i & 2 && (a.loading = e[1]), i & 20 && (a.$$scope = {
                dirty: i,
                ctx: e
            }), t.$set(a)
        },
        i(e) {
            n || (p(t.$$.fragment, e), n = !0)
        },
        o(e) {
            k(t.$$.fragment, e), n = !1
        },
        d(e) {
            b(t, e)
        }
    }
}

function oa(s) {
    let t, n;
    return t = new dn({
        props: {
            "data-testid": "random-tile",
            "data-test": "random-tile",
            "data-test-action-enabled": !s[0],
            disabled: s[0] || s[1],
            variant: "neutral",
            size: "sm",
            $$slots: {
                default: [ra]
            },
            $$scope: {
                ctx: s
            }
        }
    }), t.$on("click", mt), {
        c() {
            g(t.$$.fragment)
        },
        l(e) {
            N(t.$$.fragment, e)
        },
        m(e, i) {
            _(t, e, i), n = !0
        },
        p(e, [i]) {
            const a = {};
            i & 1 && (a["data-test-action-enabled"] = !e[0]), i & 3 && (a.disabled = e[0] || e[1]), i & 22 && (a.$$scope = {
                dirty: i,
                ctx: e
            }), t.$set(a)
        },
        i(e) {
            n || (p(t.$$.fragment, e), n = !0)
        },
        o(e) {
            k(t.$$.fragment, e), n = !1
        },
        d(e) {
            b(t, e)
        }
    }
}

function ma(s, t, n) {
    let e, i, a;
    C(s, et, o => n(0, e = o)), C(s, _e, o => n(2, a = o));
    const {
        fetching: l
    } = De();
    return C(s, l, o => n(1, i = o)), [e, i, a, l]
}
class ua extends j {
    constructor(t) {
        super(), J(this, t, ma, oa, K, {})
    }
}

function ca(s) {
    let t, n, e, i, a, l, o, r, u, c, y, h, d, v, $, m, F;
    const A = [pa, fa],
        G = [];

    function pe(f, D) {
        return f[3] ? 0 : 1
    }
    t = pe(s), n = G[t] = A[t](s), i = new Ee({}), l = new Oe({}), r = new Jt({}), c = new nn({}), h = new an({});
    const te = [$a, ka],
        H = [];

    function ke(f, D) {
        return f[3] === !1 ? 0 : 1
    }
    return v = ke(s), $ = H[v] = te[v](s), {
        c() {
            n.c(), e = w(), g(i.$$.fragment), a = w(), g(l.$$.fragment), o = w(), g(r.$$.fragment), u = w(), g(c.$$.fragment), y = w(), g(h.$$.fragment), d = w(), $.c(), m = R()
        },
        l(f) {
            n.l(f), e = B(f), N(i.$$.fragment, f), a = B(f), N(l.$$.fragment, f), o = B(f), N(r.$$.fragment, f), u = B(f), N(c.$$.fragment, f), y = B(f), N(h.$$.fragment, f), d = B(f), $.l(f), m = R()
        },
        m(f, D) {
            G[t].m(f, D), T(f, e, D), _(i, f, D), T(f, a, D), _(l, f, D), T(f, o, D), _(r, f, D), T(f, u, D), _(c, f, D), T(f, y, D), _(h, f, D), T(f, d, D), H[v].m(f, D), T(f, m, D), F = !0
        },
        p(f, D) {
            let Te = t;
            t = pe(f), t === Te ? G[t].p(f, D) : (q(), k(G[Te], 1, 1, () => {
                G[Te] = null
            }), z(), n = G[t], n ? n.p(f, D) : (n = G[t] = A[t](f), n.c()), p(n, 1), n.m(e.parentNode, e));
            let he = v;
            v = ke(f), v === he ? H[v].p(f, D) : (q(), k(H[he], 1, 1, () => {
                H[he] = null
            }), z(), $ = H[v], $ ? $.p(f, D) : ($ = H[v] = te[v](f), $.c()), p($, 1), $.m(m.parentNode, m))
        },
        i(f) {
            F || (p(n), p(i.$$.fragment, f), p(l.$$.fragment, f), p(r.$$.fragment, f), p(c.$$.fragment, f), p(h.$$.fragment, f), p($), F = !0)
        },
        o(f) {
            k(n), k(i.$$.fragment, f), k(l.$$.fragment, f), k(r.$$.fragment, f), k(c.$$.fragment, f), k(h.$$.fragment, f), k($), F = !1
        },
        d(f) {
            f && (S(e), S(a), S(o), S(u), S(y), S(d), S(m)), G[t].d(f), b(i, f), b(l, f), b(r, f), b(c, f), b(h, f), H[v].d(f)
        }
    }
}

function da(s) {
    let t, n, e, i;
    const a = [_a, ga],
        l = [];

    function o(r, u) {
        return r[3] ? 0 : 1
    }
    return t = o(s), n = l[t] = a[t](s), {
        c() {
            n.c(), e = R()
        },
        l(r) {
            n.l(r), e = R()
        },
        m(r, u) {
            l[t].m(r, u), T(r, e, u), i = !0
        },
        p(r, u) {
            let c = t;
            t = o(r), t === c ? l[t].p(r, u) : (q(), k(l[c], 1, 1, () => {
                l[c] = null
            }), z(), n = l[t], n ? n.p(r, u) : (n = l[t] = a[t](r), n.c()), p(n, 1), n.m(e.parentNode, e))
        },
        i(r) {
            i || (p(n), i = !0)
        },
        o(r) {
            k(n), i = !1
        },
        d(r) {
            r && S(e), l[t].d(r)
        }
    }
}

function fa(s) {
    let t, n;
    return t = new be({
        props: {
            manual: !0,
            automated: !0
        }
    }), {
        c() {
            g(t.$$.fragment)
        },
        l(e) {
            N(t.$$.fragment, e)
        },
        m(e, i) {
            _(t, e, i), n = !0
        },
        p: we,
        i(e) {
            n || (p(t.$$.fragment, e), n = !0)
        },
        o(e) {
            k(t.$$.fragment, e), n = !1
        },
        d(e) {
            b(t, e)
        }
    }
}

function pa(s) {
    let t, n;
    return t = new je({
        props: {
            disabled: s[4]
        }
    }), {
        c() {
            g(t.$$.fragment)
        },
        l(e) {
            N(t.$$.fragment, e)
        },
        m(e, i) {
            _(t, e, i), n = !0
        },
        p(e, i) {
            const a = {};
            i & 16 && (a.disabled = e[4]), t.$set(a)
        },
        i(e) {
            n || (p(t.$$.fragment, e), n = !0)
        },
        o(e) {
            k(t.$$.fragment, e), n = !1
        },
        d(e) {
            b(t, e)
        }
    }
}

function ka(s) {
    let t, n;
    return t = new be({
        props: {
            manual: !0,
            automated: !0
        }
    }), {
        c() {
            g(t.$$.fragment)
        },
        l(e) {
            N(t.$$.fragment, e)
        },
        m(e, i) {
            _(t, e, i), n = !0
        },
        p: we,
        i(e) {
            n || (p(t.$$.fragment, e), n = !0)
        },
        o(e) {
            k(t.$$.fragment, e), n = !1
        },
        d(e) {
            b(t, e)
        }
    }
}

function $a(s) {
    let t, n;
    return t = new je({
        props: {
            disabled: s[4]
        }
    }), {
        c() {
            g(t.$$.fragment)
        },
        l(e) {
            N(t.$$.fragment, e)
        },
        m(e, i) {
            _(t, e, i), n = !0
        },
        p(e, i) {
            const a = {};
            i & 16 && (a.disabled = e[4]), t.$set(a)
        },
        i(e) {
            n || (p(t.$$.fragment, e), n = !0)
        },
        o(e) {
            k(t.$$.fragment, e), n = !1
        },
        d(e) {
            b(t, e)
        }
    }
}

function ga(s) {
    let t, n, e, i, a, l, o, r, u, c;
    t = new be({
        props: {
            manual: !0,
            automated: !0
        }
    }), e = new Ee({});
    const y = [va, ba],
        h = [];

    function d(m, F) {
        return m[0] ? 0 : 1
    }
    a = d(s), l = h[a] = y[a](s);
    var v = s[1];

    function $(m, F) {
        return {}
    }
    return v && (r = $e(v, $())), {
        c() {
            g(t.$$.fragment), n = w(), g(e.$$.fragment), i = w(), l.c(), o = w(), r && g(r.$$.fragment), u = R()
        },
        l(m) {
            N(t.$$.fragment, m), n = B(m), N(e.$$.fragment, m), i = B(m), l.l(m), o = B(m), r && N(r.$$.fragment, m), u = R()
        },
        m(m, F) {
            _(t, m, F), T(m, n, F), _(e, m, F), T(m, i, F), h[a].m(m, F), T(m, o, F), r && _(r, m, F), T(m, u, F), c = !0
        },
        p(m, F) {
            let A = a;
            if (a = d(m), a !== A && (q(), k(h[A], 1, 1, () => {
                    h[A] = null
                }), z(), l = h[a], l || (l = h[a] = y[a](m), l.c()), p(l, 1), l.m(o.parentNode, o)), F & 2 && v !== (v = m[1])) {
                if (r) {
                    q();
                    const G = r;
                    k(G.$$.fragment, 1, 0, () => {
                        b(G, 1)
                    }), z()
                }
                v ? (r = $e(v, $()), g(r.$$.fragment), p(r.$$.fragment, 1), _(r, u.parentNode, u)) : r = null
            }
        },
        i(m) {
            c || (p(t.$$.fragment, m), p(e.$$.fragment, m), p(l), r && p(r.$$.fragment, m), c = !0)
        },
        o(m) {
            k(t.$$.fragment, m), k(e.$$.fragment, m), k(l), r && k(r.$$.fragment, m), c = !1
        },
        d(m) {
            m && (S(n), S(i), S(o), S(u)), b(t, m), b(e, m), h[a].d(m), r && b(r, m)
        }
    }
}

function _a(s) {
    let t, n, e, i, a, l, o, r, u;
    t = new Ee({});
    var c = s[1];

    function y($, m) {
        return {}
    }
    c && (e = $e(c, y()));
    const h = [Sa, Na],
        d = [];

    function v($, m) {
        return $[0] ? 0 : 1
    }
    return a = v(s), l = d[a] = h[a](s), r = new be({
        props: {
            manual: !0,
            automated: !0
        }
    }), {
        c() {
            g(t.$$.fragment), n = w(), e && g(e.$$.fragment), i = w(), l.c(), o = w(), g(r.$$.fragment)
        },
        l($) {
            N(t.$$.fragment, $), n = B($), e && N(e.$$.fragment, $), i = B($), l.l($), o = B($), N(r.$$.fragment, $)
        },
        m($, m) {
            _(t, $, m), T($, n, m), e && _(e, $, m), T($, i, m), d[a].m($, m), T($, o, m), _(r, $, m), u = !0
        },
        p($, m) {
            if (m & 2 && c !== (c = $[1])) {
                if (e) {
                    q();
                    const A = e;
                    k(A.$$.fragment, 1, 0, () => {
                        b(A, 1)
                    }), z()
                }
                c ? (e = $e(c, y()), g(e.$$.fragment), p(e.$$.fragment, 1), _(e, i.parentNode, i)) : e = null
            }
            let F = a;
            a = v($), a !== F && (q(), k(d[F], 1, 1, () => {
                d[F] = null
            }), z(), l = d[a], l || (l = d[a] = h[a]($), l.c()), p(l, 1), l.m(o.parentNode, o))
        },
        i($) {
            u || (p(t.$$.fragment, $), e && p(e.$$.fragment, $), p(l), p(r.$$.fragment, $), u = !0)
        },
        o($) {
            k(t.$$.fragment, $), e && k(e.$$.fragment, $), k(l), k(r.$$.fragment, $), u = !1
        },
        d($) {
            $ && (S(n), S(i), S(o)), b(t, $), e && b(e, $), d[a].d($), b(r, $)
        }
    }
}

function ba(s) {
    let t, n;
    return t = new Oe({}), {
        c() {
            g(t.$$.fragment)
        },
        l(e) {
            N(t.$$.fragment, e)
        },
        m(e, i) {
            _(t, e, i), n = !0
        },
        i(e) {
            n || (p(t.$$.fragment, e), n = !0)
        },
        o(e) {
            k(t.$$.fragment, e), n = !1
        },
        d(e) {
            b(t, e)
        }
    }
}

function va(s) {
    let t, n, e, i, a, l;
    return t = new ot({}), e = new rt({}), a = new ua({}), {
        c() {
            g(t.$$.fragment), n = w(), g(e.$$.fragment), i = w(), g(a.$$.fragment)
        },
        l(o) {
            N(t.$$.fragment, o), n = B(o), N(e.$$.fragment, o), i = B(o), N(a.$$.fragment, o)
        },
        m(o, r) {
            _(t, o, r), T(o, n, r), _(e, o, r), T(o, i, r), _(a, o, r), l = !0
        },
        i(o) {
            l || (p(t.$$.fragment, o), p(e.$$.fragment, o), p(a.$$.fragment, o), l = !0)
        },
        o(o) {
            k(t.$$.fragment, o), k(e.$$.fragment, o), k(a.$$.fragment, o), l = !1
        },
        d(o) {
            o && (S(n), S(i)), b(t, o), b(e, o), b(a, o)
        }
    }
}

function Na(s) {
    let t, n;
    return t = new Oe({}), {
        c() {
            g(t.$$.fragment)
        },
        l(e) {
            N(t.$$.fragment, e)
        },
        m(e, i) {
            _(t, e, i), n = !0
        },
        i(e) {
            n || (p(t.$$.fragment, e), n = !0)
        },
        o(e) {
            k(t.$$.fragment, e), n = !1
        },
        d(e) {
            b(t, e)
        }
    }
}

function Sa(s) {
    let t, n, e, i;
    return t = new ot({}), e = new rt({}), {
        c() {
            g(t.$$.fragment), n = w(), g(e.$$.fragment)
        },
        l(a) {
            N(t.$$.fragment, a), n = B(a), N(e.$$.fragment, a)
        },
        m(a, l) {
            _(t, a, l), T(a, n, l), _(e, a, l), i = !0
        },
        i(a) {
            i || (p(t.$$.fragment, a), p(e.$$.fragment, a), i = !0)
        },
        o(a) {
            k(t.$$.fragment, a), k(e.$$.fragment, a), i = !1
        },
        d(a) {
            a && S(n), b(t, a), b(e, a)
        }
    }
}

function ya(s) {
    let t, n, e, i;
    const a = [da, ca],
        l = [];

    function o(r, u) {
        return r[2] === "manual" ? 0 : 1
    }
    return t = o(s), n = l[t] = a[t](s), {
        c() {
            n.c(), e = R()
        },
        l(r) {
            n.l(r), e = R()
        },
        m(r, u) {
            l[t].m(r, u), T(r, e, u), i = !0
        },
        p(r, [u]) {
            let c = t;
            t = o(r), t === c ? l[t].p(r, u) : (q(), k(l[c], 1, 1, () => {
                l[c] = null
            }), z(), n = l[t], n ? n.p(r, u) : (n = l[t] = a[t](r), n.c()), p(n, 1), n.m(e.parentNode, e))
        },
        i(r) {
            i || (p(n), i = !0)
        },
        o(r) {
            k(n), i = !1
        },
        d(r) {
            r && S(e), l[t].d(r)
        }
    }
}

function Ta(s, t, n) {
    let e, i, a, l, o;
    C(s, We, c => n(0, i = c)), C(s, Cn, c => n(4, o = c));
    const {
        tab: r
    } = De();
    C(s, r, c => n(2, a = c));
    const u = sn();
    return C(s, u, c => n(3, l = c)), s.$$.update = () => {
        s.$$.dirty & 1 && n(1, e = i ? tn : Qt)
    }, [i, e, a, l, o, r, u]
}
class ha extends j {
    constructor(t) {
        super(), J(this, t, Ta, ya, K, {})
    }
}
const Fa = jt({
        general: Se,
        send: U.send
    }),
    Ca = { ...Fa,
        q: {
            action: () => {
                M(et) === !1 && mt()
            },
            description: P.pickRandomTile
        },
        w: {
            action: () => {
                M(tt) === !1 && U.send({
                    type: "CASHOUT"
                })
            },
            description: P.cashout
        }
    },
    wa = Z(!0),
    Ie = {
        "1.": E._("Reveal mines to increase payout multiplier."),
        "2.": E._("Cash out at any point to win at the last recorded multiplier."),
        "3.": E._("Once a bomb is revealed the game is ended and wager is lost."),
        "4.": E._("Increase of configured bombs will increase multipliers on reveal.")
    },
    Ba = { ...Ie,
        "3.": E._("Once a bomb is revealed the game is ended and lost.")
    },
    Da = {
        stake: Ie,
        sweeps: Ba
    },
    Ea = Da[Je] || Ie;

function Ma(s) {
    let t, n;
    return t = new ha({}), {
        c() {
            g(t.$$.fragment)
        },
        l(e) {
            N(t.$$.fragment, e)
        },
        m(e, i) {
            _(t, e, i), n = !0
        },
        i(e) {
            n || (p(t.$$.fragment, e), n = !0)
        },
        o(e) {
            k(t.$$.fragment, e), n = !1
        },
        d(e) {
            b(t, e)
        }
    }
}

function Aa(s) {
    let t, n;
    return t = new Ki({
        props: {
            scale: s[1],
            tab: s[0]
        }
    }), {
        c() {
            g(t.$$.fragment)
        },
        l(e) {
            N(t.$$.fragment, e)
        },
        m(e, i) {
            _(t, e, i), n = !0
        },
        p(e, i) {
            const a = {};
            i & 2 && (a.scale = e[1]), i & 1 && (a.tab = e[0]), t.$set(a)
        },
        i(e) {
            n || (p(t.$$.fragment, e), n = !0)
        },
        o(e) {
            k(t.$$.fragment, e), n = !1
        },
        d(e) {
            b(t, e)
        }
    }
}

function Ga(s) {
    let t, n, e, i, a, l, o, r, u, c, y, h;
    return t = new xt({
        props: {
            $$slots: {
                default: [Ma]
            },
            $$scope: {
                ctx: s
            }
        }
    }), e = new Yt({
        props: {
            $$slots: {
                default: [Aa, ({
                    scale: d
                }) => ({
                    1: d
                }), ({
                    scale: d
                }) => d ? 2 : 0]
            },
            $$scope: {
                ctx: s
            }
        }
    }), a = new Zt({
        props: {
            hotkeyMap: Ca
        }
    }), o = new Xt({
        props: {
            rules: Ea
        }
    }), u = new en({}), y = new fn({}), {
        c() {
            g(t.$$.fragment), n = w(), g(e.$$.fragment), i = w(), g(a.$$.fragment), l = w(), g(o.$$.fragment), r = w(), g(u.$$.fragment), c = w(), g(y.$$.fragment)
        },
        l(d) {
            N(t.$$.fragment, d), n = B(d), N(e.$$.fragment, d), i = B(d), N(a.$$.fragment, d), l = B(d), N(o.$$.fragment, d), r = B(d), N(u.$$.fragment, d), c = B(d), N(y.$$.fragment, d)
        },
        m(d, v) {
            _(t, d, v), T(d, n, v), _(e, d, v), T(d, i, v), _(a, d, v), T(d, l, v), _(o, d, v), T(d, r, v), _(u, d, v), T(d, c, v), _(y, d, v), h = !0
        },
        p(d, v) {
            const $ = {};
            v & 4 && ($.$$scope = {
                dirty: v,
                ctx: d
            }), t.$set($);
            const m = {};
            v & 7 && (m.$$scope = {
                dirty: v,
                ctx: d
            }), e.$set(m)
        },
        i(d) {
            h || (p(t.$$.fragment, d), p(e.$$.fragment, d), p(a.$$.fragment, d), p(o.$$.fragment, d), p(u.$$.fragment, d), p(y.$$.fragment, d), h = !0)
        },
        o(d) {
            k(t.$$.fragment, d), k(e.$$.fragment, d), k(a.$$.fragment, d), k(o.$$.fragment, d), k(u.$$.fragment, d), k(y.$$.fragment, d), h = !1
        },
        d(d) {
            d && (S(n), S(i), S(l), S(r), S(c)), b(t, d), b(e, d), b(a, d), b(o, d), b(u, d), b(y, d)
        }
    }
}

function La(s) {
    let t, n;
    return t = new Wt({
        props: {
            game: Be.mines,
            $$slots: {
                default: [Ga]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            g(t.$$.fragment)
        },
        l(e) {
            N(t.$$.fragment, e)
        },
        m(e, i) {
            _(t, e, i), n = !0
        },
        p(e, [i]) {
            const a = {};
            i & 5 && (a.$$scope = {
                dirty: i,
                ctx: e
            }), t.$set(a)
        },
        i(e) {
            n || (p(t.$$.fragment, e), n = !0)
        },
        o(e) {
            k(t.$$.fragment, e), n = !1
        },
        d(e) {
            b(t, e)
        }
    }
}

function Oa(s, t, n) {
    let e;
    return C(s, Ne, i => n(0, e = i)), Gt(Vn), Lt({
        listener: Di,
        general: { ...Se,
            cashoutDisabled: tt,
            valid: wa,
            send: U.send
        },
        autobet: Me
    }), ct(() => {
        const i = sa();
        return () => {
            i.unsubscribe(), V.set(Ze)
        }
    }), [e]
}
class Ia extends j {
    constructor(t) {
        super(), J(this, t, Oa, La, K, {})
    }
}

function Ra(s) {
    let t, n;
    return t = new Ia({}), {
        c() {
            g(t.$$.fragment)
        },
        l(e) {
            N(t.$$.fragment, e)
        },
        m(e, i) {
            _(t, e, i), n = !0
        },
        p: we,
        i(e) {
            n || (p(t.$$.fragment, e), n = !0)
        },
        o(e) {
            k(t.$$.fragment, e), n = !1
        },
        d(e) {
            b(t, e)
        }
    }
}
class Fs extends j {
    constructor(t) {
        super(), J(this, t, null, Ra, K, {})
    }
}
export {
    Fs as component
};