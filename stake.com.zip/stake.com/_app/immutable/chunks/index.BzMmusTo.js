import {
    s as d,
    K as w,
    t as F,
    h as D,
    j as v,
    l as z,
    i as h
} from "./scheduler.DXu26z7T.js";
import {
    S as C,
    i as S,
    c as M,
    a as N,
    m as j,
    t as A,
    b as I,
    d as O
} from "./index.Dz_MmNB3.js";
import {
    g as q,
    a as E
} from "./spread.CgU5AtxT.js";
import {
    F as G
} from "./index.CIBDG73T.js";
import {
    U as b
} from "./index.B4-7gKq3.js";

function K(u) {
    let t = u[11] + "",
        e, r;
    return {
        c() {
            e = F(t), r = F("×")
        },
        l(a) {
            e = D(a, t), r = D(a, "×")
        },
        m(a, i) {
            v(a, e, i), v(a, r, i)
        },
        p(a, i) {
            i & 2048 && t !== (t = a[11] + "") && z(e, t)
        },
        d(a) {
            a && (h(e), h(r))
        }
    }
}

function L(u) {
    let t, e;
    const r = [u[6], {
        value: u[0]
    }, {
        variant: u[1]
    }, {
        size: u[2]
    }, {
        weight: u[3]
    }, {
        align: u[4]
    }, {
        numeric: u[5]
    }];
    let a = {
        $$slots: {
            default: [K, ({
                formattedValue: i
            }) => ({
                11: i
            }), ({
                formattedValue: i
            }) => i ? 2048 : 0]
        },
        $$scope: {
            ctx: u
        }
    };
    for (let i = 0; i < r.length; i += 1) a = w(a, r[i]);
    return t = new G({
        props: a
    }), {
        c() {
            M(t.$$.fragment)
        },
        l(i) {
            N(t.$$.fragment, i)
        },
        m(i, m) {
            j(t, i, m), e = !0
        },
        p(i, [m]) {
            const o = m & 127 ? q(r, [m & 64 && E(i[6]), m & 1 && {
                value: i[0]
            }, m & 2 && {
                variant: i[1]
            }, m & 4 && {
                size: i[2]
            }, m & 8 && {
                weight: i[3]
            }, m & 16 && {
                align: i[4]
            }, m & 32 && {
                numeric: i[5]
            }]) : {};
            m & 6144 && (o.$$scope = {
                dirty: m,
                ctx: i
            }), t.$set(o)
        },
        i(i) {
            e || (A(t.$$.fragment, i), e = !0)
        },
        o(i) {
            I(t.$$.fragment, i), e = !1
        },
        d(i) {
            O(t, i)
        }
    }
}

function R(u, t, e) {
    let r;
    const a = {
        smallSpace: n => ({
            maximumFractionDigits: n.value >= 10 ? 0 : 2,
            minimumFractionDigits: n.value >= 10 ? 0 : 2
        }),
        none: () => ({})
    };
    let {
        maximumFractionDigits: i = b.maximumFractionDigits
    } = t, {
        minimumFractionDigits: m = b.minimumFractionDigits
    } = t, {
        value: o
    } = t, {
        variant: l = void 0
    } = t, {
        size: f = void 0
    } = t, {
        weight: g = void 0
    } = t, {
        align: c = void 0
    } = t, {
        numeric: _ = !0
    } = t, {
        config: s = "smallSpace"
    } = t;
    return u.$$set = n => {
        "maximumFractionDigits" in n && e(7, i = n.maximumFractionDigits), "minimumFractionDigits" in n && e(8, m = n.minimumFractionDigits), "value" in n && e(0, o = n.value), "variant" in n && e(1, l = n.variant), "size" in n && e(2, f = n.size), "weight" in n && e(3, g = n.weight), "align" in n && e(4, c = n.align), "numeric" in n && e(5, _ = n.numeric), "config" in n && e(9, s = n.config)
    }, u.$$.update = () => {
        u.$$.dirty & 897 && e(6, r = {
            maximumFractionDigits: i,
            minimumFractionDigits: m,
            ...s && s in a ? a[s]({
                value: o
            }) : {}
        })
    }, [o, l, f, g, c, _, r, i, m, s]
}
class J extends C {
    constructor(t) {
        super(), S(this, t, R, L, d, {
            maximumFractionDigits: 7,
            minimumFractionDigits: 8,
            value: 0,
            variant: 1,
            size: 2,
            weight: 3,
            align: 4,
            numeric: 5,
            config: 9
        })
    }
}
export {
    J as F
};