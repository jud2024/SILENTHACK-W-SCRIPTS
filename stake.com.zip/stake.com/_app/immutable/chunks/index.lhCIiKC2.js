import {
    w as g,
    d as s
} from "./index.C2-CG2CN.js";
import {
    v as Se,
    f as pe,
    P as A,
    H as f,
    _ as F,
    aW as w,
    B as ye,
    u as R,
    aX as ge,
    O as Q,
    R as he,
    bY as H,
    aK as fe,
    S as K,
    bZ as z,
    b_ as _,
    b$ as q,
    c0 as U,
    c1 as X,
    c2 as Te,
    c3 as Z,
    A as x
} from "./index.B4-7gKq3.js";
import {
    v as we,
    x as Be,
    G as r
} from "./scheduler.DXu26z7T.js";
import {
    d as be
} from "./index.BxooaYHE.js";
import {
    s as J
} from "./index.1CTKaDY2.js";
import {
    a as Y
} from "./index.CY6-K88d.js";
import {
    o as O
} from "./index.CgjaLSob.js";
import {
    D as Ce,
    a as De,
    b as j
} from "./constants.DX75DoF3.js";
import {
    m as $
} from "./makeFetchStore.Bw6N3EDt.js";
import {
    m as D
} from "./utils.Csgj0yys.js";
const ee = "__stores__sportsEmitter",
    M = Se(),
    Me = e => M.subscribe(n => {
        const i = n.type in e ? e[n.type] : void 0;
        i && i(n)
    }),
    Mn = () => {
        const e = {
            emitter: M,
            subscribeToSportsEmitter: Me
        };
        return we(ee, e), e
    },
    Vn = () => Be(ee),
    Ve = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "query",
            name: {
                kind: "Name",
                value: "SportSportList"
            },
            variableDefinitions: [{
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "limit"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "Int"
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "offset"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "Int"
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                },
                type: {
                    kind: "NamedType",
                    name: {
                        kind: "Name",
                        value: "String"
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "status"
                    }
                },
                type: {
                    kind: "ListType",
                    type: {
                        kind: "NonNullType",
                        type: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportBetStatusEnum"
                            }
                        }
                    }
                }
            }],
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "name"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }
                    }],
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "sportBetList"
                            },
                            arguments: [{
                                kind: "Argument",
                                name: {
                                    kind: "Name",
                                    value: "limit"
                                },
                                value: {
                                    kind: "Variable",
                                    name: {
                                        kind: "Name",
                                        value: "limit"
                                    }
                                }
                            }, {
                                kind: "Argument",
                                name: {
                                    kind: "Name",
                                    value: "offset"
                                },
                                value: {
                                    kind: "Variable",
                                    name: {
                                        kind: "Name",
                                        value: "offset"
                                    }
                                }
                            }, {
                                kind: "Argument",
                                name: {
                                    kind: "Name",
                                    value: "status"
                                },
                                value: {
                                    kind: "Variable",
                                    name: {
                                        kind: "Name",
                                        value: "status"
                                    }
                                }
                            }],
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "iid"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "bet"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "InlineFragment",
                                            typeCondition: {
                                                kind: "NamedType",
                                                name: {
                                                    kind: "Name",
                                                    value: "SportBet"
                                                }
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "FragmentSpread",
                                                    name: {
                                                        kind: "Name",
                                                        value: "SportBet"
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "InlineFragment",
                                            typeCondition: {
                                                kind: "NamedType",
                                                name: {
                                                    kind: "Name",
                                                    value: "SwishBet"
                                                }
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "FragmentSpread",
                                                    name: {
                                                        kind: "Name",
                                                        value: "SwishBetFragment"
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "InlineFragment",
                                            typeCondition: {
                                                kind: "NamedType",
                                                name: {
                                                    kind: "Name",
                                                    value: "RacingBet"
                                                }
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "FragmentSpread",
                                                    name: {
                                                        kind: "Name",
                                                        value: "RacingBet"
                                                    }
                                                }]
                                            }
                                        }]
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportMarketOutcome"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportMarketOutcome"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "odds"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "customBetAvailable"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportMarket"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportMarket"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "status"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "extId"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "specifiers"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "customBetAvailable"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "provider"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportFixtureCompetitor"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportFixtureCompetitor"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "extId"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "countryCode"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "abbreviation"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "iconPath"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportFixtureDataMatch"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportFixtureDataMatch"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "startTime"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "competitors"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "SportFixtureCompetitor"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "teams"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "qualifier"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "tvChannels"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "language"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "streamUrl"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportFixtureDataOutright"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportFixtureDataOutright"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "startTime"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "endTime"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "CategoryTreeNested"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportCategory"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "slug"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "sport"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "slug"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "TournamentTreeNested"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportTournament"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "slug"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "category"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "CategoryTreeNested"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "cashoutEnabled"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportOutcomeFixtureEventStatus"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportFixtureEventStatusData"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "homeScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "awayScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "matchStatus"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "clock"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "matchTime"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "remainingTime"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "periodScores"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "matchStatus"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currentTeamServing"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "homeGameScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "awayGameScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "statistic"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "yellowCards"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "away"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "home"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "redCards"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "away"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "home"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "corners"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "home"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "away"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "EsportOutcomeFixtureEventStatus"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "EsportFixtureEventStatus"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "matchStatus"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "homeScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "awayScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "scoreboard"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeGold"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayGold"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "gameTime"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeDestroyedTowers"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayDestroyedTurrets"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currentRound"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currentCtTeam"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currentDefTeam"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "time"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "remainingGameTime"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "periodScores"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "type"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "number"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "matchStatus"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportFixtureLiveStreamExists"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportFixture"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "betradarStream"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "exists"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "imgArenaStream"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "exists"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "abiosStream"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "exists"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "stream"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "startTime"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }]
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "geniussportsStream"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "deliveryType"
                        },
                        value: {
                            kind: "EnumValue",
                            value: "hls"
                        }
                    }],
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "exists"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportFixtureEventStatus"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportFixtureEventStatusData"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "homeScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "awayScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "matchStatus"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "clock"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "matchTime"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "remainingTime"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "periodScores"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "matchStatus"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currentTeamServing"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "homeGameScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "awayGameScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "statistic"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "yellowCards"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "away"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "home"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "redCards"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "away"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "home"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "corners"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "home"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "away"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "EsportFixtureEventStatus"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "EsportFixtureEventStatus"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "matchStatus"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "homeScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "awayScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "scoreboard"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeGold"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayGold"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "gameTime"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeDestroyedTowers"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayDestroyedTurrets"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currentRound"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currentCtTeam"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currentDefTeam"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "time"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "remainingGameTime"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "periodScores"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "type"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "number"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "matchStatus"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SwishMarketOutcomeFragment"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SwishMarketOutcome"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "line"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "over"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "under"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "gradeOver"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "gradeUnder"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "suspended"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "balanced"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "competitor"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "stats"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "dataConfirmed"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "played"
                                    }
                                }]
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "market"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "stat"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "value"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "game"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "fixture"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "id"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "extId"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "name"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "slug"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "status"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "provider"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "swishGame"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "swishSportId"
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "eventStatus"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "FragmentSpread",
                                                    name: {
                                                        kind: "Name",
                                                        value: "SportFixtureEventStatus"
                                                    }
                                                }, {
                                                    kind: "FragmentSpread",
                                                    name: {
                                                        kind: "Name",
                                                        value: "EsportFixtureEventStatus"
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "data"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "InlineFragment",
                                                    typeCondition: {
                                                        kind: "NamedType",
                                                        name: {
                                                            kind: "Name",
                                                            value: "SportFixtureDataMatch"
                                                        }
                                                    },
                                                    selectionSet: {
                                                        kind: "SelectionSet",
                                                        selections: [{
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "__typename"
                                                            }
                                                        }, {
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "startTime"
                                                            }
                                                        }, {
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "competitors"
                                                            },
                                                            selectionSet: {
                                                                kind: "SelectionSet",
                                                                selections: [{
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "name"
                                                                    }
                                                                }, {
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "extId"
                                                                    }
                                                                }, {
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "countryCode"
                                                                    }
                                                                }, {
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "abbreviation"
                                                                    }
                                                                }]
                                                            }
                                                        }]
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "tournament"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "id"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "slug"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "name"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "category"
                                                    },
                                                    selectionSet: {
                                                        kind: "SelectionSet",
                                                        selections: [{
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "id"
                                                            }
                                                        }, {
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "slug"
                                                            }
                                                        }, {
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "name"
                                                            }
                                                        }, {
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "sport"
                                                            },
                                                            selectionSet: {
                                                                kind: "SelectionSet",
                                                                selections: [{
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "id"
                                                                    }
                                                                }, {
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "name"
                                                                    }
                                                                }, {
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "slug"
                                                                    }
                                                                }]
                                                            }
                                                        }]
                                                    }
                                                }]
                                            }
                                        }]
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "RunnerOutcomeButton_RacingOutcome"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "RacingOutcome"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "odds"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "market"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "status"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "RunnerOutcomeButton_RacingRunner"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "RacingRunner"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "scratched"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "runnerNumber"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "barrierPosition"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "hcpDraw"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "attributes"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "weight"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "careerStats"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "last6Runs"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "jockey"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "trainer"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "prices"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "active"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "odds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "market"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "status"
                                    }
                                }]
                            }
                        }, {
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "RunnerOutcomeButton_RacingOutcome"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportBet"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportBet"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "customBet"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "amount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "status"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payoutMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "cashoutMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "cashoutDisabled"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "updatedAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payout"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "potentialMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "adjustments"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "payoutMultiplier"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "updatedAt"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "createdAt"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "promotionBet"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "settleType"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "status"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "payout"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currency"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "promotion"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }]
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "bet"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "iid"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "outcomes"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "__typename"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "odds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "status"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "outcome"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "__typename"
                                    }
                                }, {
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "SportMarketOutcome"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "probabilities"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "voidFactor"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "payout"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "sport"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "cashoutEnabled"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "market"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "SportMarket"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "fixture"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "status"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "slug"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "provider"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "marketCount"
                                    },
                                    arguments: [{
                                        kind: "Argument",
                                        name: {
                                            kind: "Name",
                                            value: "status"
                                        },
                                        value: {
                                            kind: "ListValue",
                                            values: [{
                                                kind: "EnumValue",
                                                value: "active"
                                            }, {
                                                kind: "EnumValue",
                                                value: "suspended"
                                            }]
                                        }
                                    }]
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "extId"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "cashoutEnabled"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "data"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "FragmentSpread",
                                            name: {
                                                kind: "Name",
                                                value: "SportFixtureDataMatch"
                                            }
                                        }, {
                                            kind: "FragmentSpread",
                                            name: {
                                                kind: "Name",
                                                value: "SportFixtureDataOutright"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "__typename"
                                            }
                                        }]
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "tournament"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "FragmentSpread",
                                            name: {
                                                kind: "Name",
                                                value: "TournamentTreeNested"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "cashoutEnabled"
                                            }
                                        }]
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "eventStatus"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "FragmentSpread",
                                            name: {
                                                kind: "Name",
                                                value: "SportOutcomeFixtureEventStatus"
                                            }
                                        }, {
                                            kind: "FragmentSpread",
                                            name: {
                                                kind: "Name",
                                                value: "EsportOutcomeFixtureEventStatus"
                                            }
                                        }]
                                    }
                                }, {
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "SportFixtureLiveStreamExists"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SwishBetFragment"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SwishBet"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "amount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "cashoutMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "potentialMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "customBet"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "odds"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payout"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payoutMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "adjustments"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "payoutMultiplier"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "updatedAt"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "createdAt"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "updatedAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "status"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "preferenceHideBets"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "outcomes"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "__typename"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "odds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "lineType"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "outcome"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "SwishMarketOutcomeFragment"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "RacingBet"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "RacingBet"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "amount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "updatedAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "resultType"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "outcomes"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "updatedAt"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "prices"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "odds"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "marketName"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "result"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "resultedPrices"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "status"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "deadheatMultiplier"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "deductions"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "key"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "percentage"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "type"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "derivativeType"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "event"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "eventNumber"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "slug"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "startTime"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "status"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "streamUrl"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "streamGeoBlocked"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "meeting"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "slug"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "racing"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "slug"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "name"
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "racingGroup"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "slug"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "name"
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "venue"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "name"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "geoBlocked"
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "category"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "name"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "slug"
                                                    }
                                                }]
                                            }
                                        }]
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "topRunnerList"
                                    },
                                    arguments: [{
                                        kind: "Argument",
                                        name: {
                                            kind: "Name",
                                            value: "limit"
                                        },
                                        value: {
                                            kind: "IntValue",
                                            value: "4"
                                        }
                                    }],
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "finalPosition"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "runnerNumber"
                                            }
                                        }]
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "selectionSlots"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "runners"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "FragmentSpread",
                                            name: {
                                                kind: "Name",
                                                value: "RunnerOutcomeButton_RacingRunner"
                                            }
                                        }]
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "selections"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "type"
                                    }
                                }]
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payout"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payoutMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "adjustments"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "payoutMultiplier"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "updatedAt"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "createdAt"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    alias: {
                        kind: "Name",
                        value: "betStatus"
                    },
                    name: {
                        kind: "Name",
                        value: "status"
                    }
                }, {
                    kind: "Field",
                    alias: {
                        kind: "Name",
                        value: "betPotentialMultiplier"
                    },
                    name: {
                        kind: "Name",
                        value: "potentialMultiplier"
                    }
                }]
            }
        }]
    },
    Ae = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "query",
            name: {
                kind: "Name",
                value: "ActiveSportBets"
            },
            variableDefinitions: [{
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "limit"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "Int"
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "sort"
                    }
                },
                type: {
                    kind: "NamedType",
                    name: {
                        kind: "Name",
                        value: "UserBetsSortEnum"
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                },
                type: {
                    kind: "NamedType",
                    name: {
                        kind: "Name",
                        value: "String"
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "status"
                    }
                },
                type: {
                    kind: "ListType",
                    type: {
                        kind: "NonNullType",
                        type: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportBetStatusEnum"
                            }
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "offset"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "Int"
                        }
                    }
                }
            }],
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "name"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }
                    }],
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "activeSportBets"
                            },
                            arguments: [{
                                kind: "Argument",
                                name: {
                                    kind: "Name",
                                    value: "limit"
                                },
                                value: {
                                    kind: "Variable",
                                    name: {
                                        kind: "Name",
                                        value: "limit"
                                    }
                                }
                            }, {
                                kind: "Argument",
                                name: {
                                    kind: "Name",
                                    value: "sort"
                                },
                                value: {
                                    kind: "Variable",
                                    name: {
                                        kind: "Name",
                                        value: "sort"
                                    }
                                }
                            }, {
                                kind: "Argument",
                                name: {
                                    kind: "Name",
                                    value: "offset"
                                },
                                value: {
                                    kind: "Variable",
                                    name: {
                                        kind: "Name",
                                        value: "offset"
                                    }
                                }
                            }],
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "SportBet"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "activeSwishBetList"
                            },
                            arguments: [{
                                kind: "Argument",
                                name: {
                                    kind: "Name",
                                    value: "limit"
                                },
                                value: {
                                    kind: "Variable",
                                    name: {
                                        kind: "Name",
                                        value: "limit"
                                    }
                                }
                            }, {
                                kind: "Argument",
                                name: {
                                    kind: "Name",
                                    value: "sort"
                                },
                                value: {
                                    kind: "Variable",
                                    name: {
                                        kind: "Name",
                                        value: "sort"
                                    }
                                }
                            }, {
                                kind: "Argument",
                                name: {
                                    kind: "Name",
                                    value: "status"
                                },
                                value: {
                                    kind: "Variable",
                                    name: {
                                        kind: "Name",
                                        value: "status"
                                    }
                                }
                            }, {
                                kind: "Argument",
                                name: {
                                    kind: "Name",
                                    value: "offset"
                                },
                                value: {
                                    kind: "Variable",
                                    name: {
                                        kind: "Name",
                                        value: "offset"
                                    }
                                }
                            }],
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "SwishBetFragment"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "activeRacingBets"
                            },
                            arguments: [{
                                kind: "Argument",
                                name: {
                                    kind: "Name",
                                    value: "limit"
                                },
                                value: {
                                    kind: "Variable",
                                    name: {
                                        kind: "Name",
                                        value: "limit"
                                    }
                                }
                            }, {
                                kind: "Argument",
                                name: {
                                    kind: "Name",
                                    value: "offset"
                                },
                                value: {
                                    kind: "Variable",
                                    name: {
                                        kind: "Name",
                                        value: "offset"
                                    }
                                }
                            }],
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "RacingBet"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "activeSportBetCount"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "activeSwishBetCount"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "activeRacingBetCount"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportMarketOutcome"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportMarketOutcome"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "odds"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "customBetAvailable"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportMarket"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportMarket"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "status"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "extId"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "specifiers"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "customBetAvailable"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "provider"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportFixtureCompetitor"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportFixtureCompetitor"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "extId"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "countryCode"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "abbreviation"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "iconPath"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportFixtureDataMatch"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportFixtureDataMatch"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "startTime"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "competitors"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "SportFixtureCompetitor"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "teams"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "qualifier"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "tvChannels"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "language"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "streamUrl"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportFixtureDataOutright"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportFixtureDataOutright"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "startTime"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "endTime"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "CategoryTreeNested"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportCategory"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "slug"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "sport"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "slug"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "TournamentTreeNested"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportTournament"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "slug"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "category"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "CategoryTreeNested"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "cashoutEnabled"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportOutcomeFixtureEventStatus"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportFixtureEventStatusData"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "homeScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "awayScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "matchStatus"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "clock"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "matchTime"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "remainingTime"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "periodScores"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "matchStatus"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currentTeamServing"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "homeGameScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "awayGameScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "statistic"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "yellowCards"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "away"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "home"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "redCards"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "away"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "home"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "corners"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "home"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "away"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "EsportOutcomeFixtureEventStatus"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "EsportFixtureEventStatus"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "matchStatus"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "homeScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "awayScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "scoreboard"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeGold"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayGold"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "gameTime"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeDestroyedTowers"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayDestroyedTurrets"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currentRound"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currentCtTeam"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currentDefTeam"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "time"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "remainingGameTime"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "periodScores"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "type"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "number"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "matchStatus"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportFixtureLiveStreamExists"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportFixture"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "betradarStream"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "exists"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "imgArenaStream"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "exists"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "abiosStream"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "exists"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "stream"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "startTime"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }]
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "geniussportsStream"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "deliveryType"
                        },
                        value: {
                            kind: "EnumValue",
                            value: "hls"
                        }
                    }],
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "exists"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportFixtureEventStatus"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportFixtureEventStatusData"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "homeScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "awayScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "matchStatus"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "clock"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "matchTime"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "remainingTime"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "periodScores"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "matchStatus"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currentTeamServing"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "homeGameScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "awayGameScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "statistic"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "yellowCards"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "away"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "home"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "redCards"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "away"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "home"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "corners"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "home"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "away"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "EsportFixtureEventStatus"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "EsportFixtureEventStatus"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "matchStatus"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "homeScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "awayScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "scoreboard"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeGold"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayGold"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "gameTime"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeDestroyedTowers"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayDestroyedTurrets"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currentRound"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currentCtTeam"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currentDefTeam"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "time"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "remainingGameTime"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "periodScores"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "type"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "number"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "matchStatus"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SwishMarketOutcomeFragment"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SwishMarketOutcome"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "line"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "over"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "under"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "gradeOver"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "gradeUnder"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "suspended"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "balanced"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "competitor"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "stats"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "dataConfirmed"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "played"
                                    }
                                }]
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "market"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "stat"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "value"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "game"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "fixture"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "id"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "extId"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "name"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "slug"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "status"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "provider"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "swishGame"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "swishSportId"
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "eventStatus"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "FragmentSpread",
                                                    name: {
                                                        kind: "Name",
                                                        value: "SportFixtureEventStatus"
                                                    }
                                                }, {
                                                    kind: "FragmentSpread",
                                                    name: {
                                                        kind: "Name",
                                                        value: "EsportFixtureEventStatus"
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "data"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "InlineFragment",
                                                    typeCondition: {
                                                        kind: "NamedType",
                                                        name: {
                                                            kind: "Name",
                                                            value: "SportFixtureDataMatch"
                                                        }
                                                    },
                                                    selectionSet: {
                                                        kind: "SelectionSet",
                                                        selections: [{
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "__typename"
                                                            }
                                                        }, {
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "startTime"
                                                            }
                                                        }, {
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "competitors"
                                                            },
                                                            selectionSet: {
                                                                kind: "SelectionSet",
                                                                selections: [{
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "name"
                                                                    }
                                                                }, {
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "extId"
                                                                    }
                                                                }, {
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "countryCode"
                                                                    }
                                                                }, {
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "abbreviation"
                                                                    }
                                                                }]
                                                            }
                                                        }]
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "tournament"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "id"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "slug"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "name"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "category"
                                                    },
                                                    selectionSet: {
                                                        kind: "SelectionSet",
                                                        selections: [{
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "id"
                                                            }
                                                        }, {
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "slug"
                                                            }
                                                        }, {
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "name"
                                                            }
                                                        }, {
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "sport"
                                                            },
                                                            selectionSet: {
                                                                kind: "SelectionSet",
                                                                selections: [{
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "id"
                                                                    }
                                                                }, {
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "name"
                                                                    }
                                                                }, {
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "slug"
                                                                    }
                                                                }]
                                                            }
                                                        }]
                                                    }
                                                }]
                                            }
                                        }]
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "RunnerOutcomeButton_RacingOutcome"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "RacingOutcome"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "odds"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "market"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "status"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "RunnerOutcomeButton_RacingRunner"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "RacingRunner"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "scratched"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "runnerNumber"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "barrierPosition"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "hcpDraw"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "attributes"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "weight"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "careerStats"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "last6Runs"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "jockey"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "trainer"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "prices"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "active"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "odds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "market"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "status"
                                    }
                                }]
                            }
                        }, {
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "RunnerOutcomeButton_RacingOutcome"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportBet"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportBet"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "customBet"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "amount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "status"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payoutMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "cashoutMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "cashoutDisabled"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "updatedAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payout"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "potentialMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "adjustments"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "payoutMultiplier"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "updatedAt"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "createdAt"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "promotionBet"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "settleType"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "status"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "payout"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currency"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "promotion"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }]
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "bet"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "iid"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "outcomes"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "__typename"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "odds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "status"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "outcome"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "__typename"
                                    }
                                }, {
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "SportMarketOutcome"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "probabilities"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "voidFactor"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "payout"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "sport"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "cashoutEnabled"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "market"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "SportMarket"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "fixture"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "status"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "slug"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "provider"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "marketCount"
                                    },
                                    arguments: [{
                                        kind: "Argument",
                                        name: {
                                            kind: "Name",
                                            value: "status"
                                        },
                                        value: {
                                            kind: "ListValue",
                                            values: [{
                                                kind: "EnumValue",
                                                value: "active"
                                            }, {
                                                kind: "EnumValue",
                                                value: "suspended"
                                            }]
                                        }
                                    }]
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "extId"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "cashoutEnabled"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "data"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "FragmentSpread",
                                            name: {
                                                kind: "Name",
                                                value: "SportFixtureDataMatch"
                                            }
                                        }, {
                                            kind: "FragmentSpread",
                                            name: {
                                                kind: "Name",
                                                value: "SportFixtureDataOutright"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "__typename"
                                            }
                                        }]
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "tournament"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "FragmentSpread",
                                            name: {
                                                kind: "Name",
                                                value: "TournamentTreeNested"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "cashoutEnabled"
                                            }
                                        }]
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "eventStatus"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "FragmentSpread",
                                            name: {
                                                kind: "Name",
                                                value: "SportOutcomeFixtureEventStatus"
                                            }
                                        }, {
                                            kind: "FragmentSpread",
                                            name: {
                                                kind: "Name",
                                                value: "EsportOutcomeFixtureEventStatus"
                                            }
                                        }]
                                    }
                                }, {
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "SportFixtureLiveStreamExists"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SwishBetFragment"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SwishBet"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "amount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "cashoutMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "potentialMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "customBet"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "odds"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payout"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payoutMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "adjustments"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "payoutMultiplier"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "updatedAt"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "createdAt"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "updatedAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "status"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "preferenceHideBets"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "outcomes"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "__typename"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "odds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "lineType"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "outcome"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "SwishMarketOutcomeFragment"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "RacingBet"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "RacingBet"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "amount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "updatedAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "resultType"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "outcomes"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "updatedAt"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "prices"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "odds"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "marketName"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "result"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "resultedPrices"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "status"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "deadheatMultiplier"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "deductions"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "key"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "percentage"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "type"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "derivativeType"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "event"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "eventNumber"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "slug"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "startTime"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "status"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "streamUrl"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "streamGeoBlocked"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "meeting"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "slug"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "racing"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "slug"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "name"
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "racingGroup"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "slug"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "name"
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "venue"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "name"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "geoBlocked"
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "category"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "name"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "slug"
                                                    }
                                                }]
                                            }
                                        }]
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "topRunnerList"
                                    },
                                    arguments: [{
                                        kind: "Argument",
                                        name: {
                                            kind: "Name",
                                            value: "limit"
                                        },
                                        value: {
                                            kind: "IntValue",
                                            value: "4"
                                        }
                                    }],
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "finalPosition"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "runnerNumber"
                                            }
                                        }]
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "selectionSlots"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "runners"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "FragmentSpread",
                                            name: {
                                                kind: "Name",
                                                value: "RunnerOutcomeButton_RacingRunner"
                                            }
                                        }]
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "selections"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "type"
                                    }
                                }]
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payout"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payoutMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "adjustments"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "payoutMultiplier"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "updatedAt"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "createdAt"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    alias: {
                        kind: "Name",
                        value: "betStatus"
                    },
                    name: {
                        kind: "Name",
                        value: "status"
                    }
                }, {
                    kind: "Field",
                    alias: {
                        kind: "Name",
                        value: "betPotentialMultiplier"
                    },
                    name: {
                        kind: "Name",
                        value: "potentialMultiplier"
                    }
                }]
            }
        }]
    },
    ne = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "mutation",
            name: {
                kind: "Name",
                value: "SportBetMutation"
            },
            variableDefinitions: [{
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "amount"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "Float"
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "CurrencyEnum"
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "outcomeIds"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "ListType",
                        type: {
                            kind: "NonNullType",
                            type: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "String"
                                }
                            }
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "oddsChange"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "SportOddsChangeEnum"
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "identifier"
                    }
                },
                type: {
                    kind: "NamedType",
                    name: {
                        kind: "Name",
                        value: "String"
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "betType"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "SportBetTypeEnum"
                        }
                    }
                }
            }],
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "sportBet"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "amount"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "amount"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "currency"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "currency"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "outcomeIds"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "outcomeIds"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "oddsChange"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "oddsChange"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "identifier"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "identifier"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "betType"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "betType"
                            }
                        }
                    }],
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "amount"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currency"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "payoutMultiplier"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "potentialMultiplier"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "outcomes"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "odds"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "outcome"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "FragmentSpread",
                                            name: {
                                                kind: "Name",
                                                value: "SportMarketOutcome"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "market"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "FragmentSpread",
                                                    name: {
                                                        kind: "Name",
                                                        value: "SportMarket"
                                                    }
                                                }]
                                            }
                                        }]
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportMarketOutcome"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportMarketOutcome"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "odds"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "customBetAvailable"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportMarket"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportMarket"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "status"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "extId"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "specifiers"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "customBetAvailable"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "provider"
                    }
                }]
            }
        }]
    },
    Ee = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "mutation",
            name: {
                kind: "Name",
                value: "CustomSportBetMutation"
            },
            variableDefinitions: [{
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "amount"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "Float"
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "CurrencyEnum"
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "outcomeIds"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "ListType",
                        type: {
                            kind: "NonNullType",
                            type: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "String"
                                }
                            }
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "oddsChange"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "SportOddsChangeEnum"
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "identifier"
                    }
                },
                type: {
                    kind: "NamedType",
                    name: {
                        kind: "Name",
                        value: "String"
                    }
                }
            }],
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "customSportBet"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "amount"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "amount"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "currency"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "currency"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "outcomeIds"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "outcomeIds"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "oddsChange"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "oddsChange"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "identifier"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "identifier"
                            }
                        }
                    }],
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "amount"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currency"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "payoutMultiplier"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "outcomes"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "odds"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "outcome"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "FragmentSpread",
                                            name: {
                                                kind: "Name",
                                                value: "SportMarketOutcome"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "market"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "FragmentSpread",
                                                    name: {
                                                        kind: "Name",
                                                        value: "SportMarket"
                                                    }
                                                }]
                                            }
                                        }]
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportMarketOutcome"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportMarketOutcome"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "odds"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "customBetAvailable"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportMarket"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportMarket"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "status"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "extId"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "specifiers"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "customBetAvailable"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "provider"
                    }
                }]
            }
        }]
    },
    ie = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "mutation",
            name: {
                kind: "Name",
                value: "CreateSwishBet"
            },
            variableDefinitions: [{
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "amount"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "Float"
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "CurrencyEnum"
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "lines"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "ListType",
                        type: {
                            kind: "NonNullType",
                            type: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "CreateSwishBetLinesInput"
                                }
                            }
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "requestedMultiplier"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "Float"
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "identifier"
                    }
                },
                type: {
                    kind: "NamedType",
                    name: {
                        kind: "Name",
                        value: "String"
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "oddsChange"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "SwishOddsChangeEnum"
                        }
                    }
                }
            }],
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createSwishBet"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "amount"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "amount"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "currency"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "currency"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "lines"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "lines"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "requestedMultiplier"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "requestedMultiplier"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "identifier"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "identifier"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "oddsChange"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "oddsChange"
                            }
                        }
                    }],
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "SwishBetFragment"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportFixtureEventStatus"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportFixtureEventStatusData"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "homeScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "awayScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "matchStatus"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "clock"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "matchTime"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "remainingTime"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "periodScores"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "matchStatus"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currentTeamServing"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "homeGameScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "awayGameScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "statistic"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "yellowCards"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "away"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "home"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "redCards"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "away"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "home"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "corners"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "home"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "away"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "EsportFixtureEventStatus"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "EsportFixtureEventStatus"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "matchStatus"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "homeScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "awayScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "scoreboard"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeGold"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayGold"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "gameTime"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeDestroyedTowers"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayDestroyedTurrets"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currentRound"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currentCtTeam"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currentDefTeam"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "time"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "remainingGameTime"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "periodScores"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "type"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "number"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "matchStatus"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SwishMarketOutcomeFragment"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SwishMarketOutcome"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "line"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "over"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "under"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "gradeOver"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "gradeUnder"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "suspended"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "balanced"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "competitor"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "stats"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "dataConfirmed"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "played"
                                    }
                                }]
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "market"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "stat"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "value"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "game"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "fixture"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "id"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "extId"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "name"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "slug"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "status"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "provider"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "swishGame"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "swishSportId"
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "eventStatus"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "FragmentSpread",
                                                    name: {
                                                        kind: "Name",
                                                        value: "SportFixtureEventStatus"
                                                    }
                                                }, {
                                                    kind: "FragmentSpread",
                                                    name: {
                                                        kind: "Name",
                                                        value: "EsportFixtureEventStatus"
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "data"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "InlineFragment",
                                                    typeCondition: {
                                                        kind: "NamedType",
                                                        name: {
                                                            kind: "Name",
                                                            value: "SportFixtureDataMatch"
                                                        }
                                                    },
                                                    selectionSet: {
                                                        kind: "SelectionSet",
                                                        selections: [{
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "__typename"
                                                            }
                                                        }, {
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "startTime"
                                                            }
                                                        }, {
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "competitors"
                                                            },
                                                            selectionSet: {
                                                                kind: "SelectionSet",
                                                                selections: [{
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "name"
                                                                    }
                                                                }, {
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "extId"
                                                                    }
                                                                }, {
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "countryCode"
                                                                    }
                                                                }, {
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "abbreviation"
                                                                    }
                                                                }]
                                                            }
                                                        }]
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "tournament"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "id"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "slug"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "name"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "category"
                                                    },
                                                    selectionSet: {
                                                        kind: "SelectionSet",
                                                        selections: [{
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "id"
                                                            }
                                                        }, {
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "slug"
                                                            }
                                                        }, {
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "name"
                                                            }
                                                        }, {
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "sport"
                                                            },
                                                            selectionSet: {
                                                                kind: "SelectionSet",
                                                                selections: [{
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "id"
                                                                    }
                                                                }, {
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "name"
                                                                    }
                                                                }, {
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "slug"
                                                                    }
                                                                }]
                                                            }
                                                        }]
                                                    }
                                                }]
                                            }
                                        }]
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SwishBetFragment"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SwishBet"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "amount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "cashoutMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "potentialMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "customBet"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "odds"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payout"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payoutMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "adjustments"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "payoutMultiplier"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "updatedAt"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "createdAt"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "updatedAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "status"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "preferenceHideBets"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "outcomes"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "__typename"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "odds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "lineType"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "outcome"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "SwishMarketOutcomeFragment"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }]
    },
    _e = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "mutation",
            name: {
                kind: "Name",
                value: "CreateSwishCustomBet"
            },
            variableDefinitions: [{
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "amount"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "Float"
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "CurrencyEnum"
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "identifier"
                    }
                },
                type: {
                    kind: "NamedType",
                    name: {
                        kind: "Name",
                        value: "String"
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "lines"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "ListType",
                        type: {
                            kind: "NonNullType",
                            type: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "CreateSwishCustomBetLinesInput"
                                }
                            }
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "oddsChange"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "SwishOddsChangeEnum"
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "requestedMultiplier"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "Float"
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "sport"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "SwishSportEnum"
                        }
                    }
                }
            }],
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createSwishCustomBet"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "amount"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "amount"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "currency"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "currency"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "identifier"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "identifier"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "lines"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "lines"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "oddsChange"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "oddsChange"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "requestedMultiplier"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "requestedMultiplier"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "sport"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "sport"
                            }
                        }
                    }],
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "SwishBetFragment"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportFixtureEventStatus"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportFixtureEventStatusData"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "homeScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "awayScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "matchStatus"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "clock"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "matchTime"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "remainingTime"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "periodScores"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "matchStatus"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currentTeamServing"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "homeGameScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "awayGameScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "statistic"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "yellowCards"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "away"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "home"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "redCards"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "away"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "home"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "corners"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "home"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "away"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "EsportFixtureEventStatus"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "EsportFixtureEventStatus"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "matchStatus"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "homeScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "awayScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "scoreboard"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeGold"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayGold"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "gameTime"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeDestroyedTowers"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayDestroyedTurrets"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currentRound"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currentCtTeam"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currentDefTeam"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "time"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "remainingGameTime"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "periodScores"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "type"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "number"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "matchStatus"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SwishMarketOutcomeFragment"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SwishMarketOutcome"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "line"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "over"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "under"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "gradeOver"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "gradeUnder"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "suspended"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "balanced"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "competitor"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "stats"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "dataConfirmed"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "played"
                                    }
                                }]
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "market"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "stat"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "value"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "game"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "fixture"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "id"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "extId"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "name"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "slug"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "status"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "provider"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "swishGame"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "swishSportId"
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "eventStatus"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "FragmentSpread",
                                                    name: {
                                                        kind: "Name",
                                                        value: "SportFixtureEventStatus"
                                                    }
                                                }, {
                                                    kind: "FragmentSpread",
                                                    name: {
                                                        kind: "Name",
                                                        value: "EsportFixtureEventStatus"
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "data"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "InlineFragment",
                                                    typeCondition: {
                                                        kind: "NamedType",
                                                        name: {
                                                            kind: "Name",
                                                            value: "SportFixtureDataMatch"
                                                        }
                                                    },
                                                    selectionSet: {
                                                        kind: "SelectionSet",
                                                        selections: [{
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "__typename"
                                                            }
                                                        }, {
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "startTime"
                                                            }
                                                        }, {
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "competitors"
                                                            },
                                                            selectionSet: {
                                                                kind: "SelectionSet",
                                                                selections: [{
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "name"
                                                                    }
                                                                }, {
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "extId"
                                                                    }
                                                                }, {
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "countryCode"
                                                                    }
                                                                }, {
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "abbreviation"
                                                                    }
                                                                }]
                                                            }
                                                        }]
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "tournament"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "id"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "slug"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "name"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "category"
                                                    },
                                                    selectionSet: {
                                                        kind: "SelectionSet",
                                                        selections: [{
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "id"
                                                            }
                                                        }, {
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "slug"
                                                            }
                                                        }, {
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "name"
                                                            }
                                                        }, {
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "sport"
                                                            },
                                                            selectionSet: {
                                                                kind: "SelectionSet",
                                                                selections: [{
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "id"
                                                                    }
                                                                }, {
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "name"
                                                                    }
                                                                }, {
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "slug"
                                                                    }
                                                                }]
                                                            }
                                                        }]
                                                    }
                                                }]
                                            }
                                        }]
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SwishBetFragment"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SwishBet"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "amount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "cashoutMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "potentialMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "customBet"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "odds"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payout"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payoutMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "adjustments"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "payoutMultiplier"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "updatedAt"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "createdAt"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "updatedAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "status"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "preferenceHideBets"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "outcomes"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "__typename"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "odds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "lineType"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "outcome"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "SwishMarketOutcomeFragment"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }]
    },
    xe = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "query",
            name: {
                kind: "Name",
                value: "SportsMinBet"
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "info"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currencies"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "sportBetMin"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "value"
                                            }
                                        }]
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }]
    },
    Re = async e => {
        try {
            const n = await pe({
                doc: xe,
                load: e,
                variables: {}
            });
            return (n == null ? void 0 : n.info.currencies) || []
        } catch {
            return []
        }
    },
    ae = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "mutation",
            name: {
                kind: "Name",
                value: "RacingBet"
            },
            variableDefinitions: [{
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "amount"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "Float"
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "CurrencyEnum"
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "identifier"
                    }
                },
                type: {
                    kind: "NamedType",
                    name: {
                        kind: "Name",
                        value: "String"
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "oddsChange"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "RacingOddsChangeEnum"
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "multiplier"
                    }
                },
                type: {
                    kind: "NamedType",
                    name: {
                        kind: "Name",
                        value: "Float"
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "type"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "RacingBetTypeEnum"
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "selections"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "ListType",
                        type: {
                            kind: "NonNullType",
                            type: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "RacingBetSelectionsInput"
                                }
                            }
                        }
                    }
                }
            }],
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "racingBet"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "amount"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "amount"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "multiplier"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "multiplier"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "currency"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "currency"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "identifier"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "identifier"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "oddsChange"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "oddsChange"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "selections"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "selections"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "type"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "type"
                            }
                        }
                    }],
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "status"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "amount"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "refundAmount"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "potentialMultiplier"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currency"
                            }
                        }]
                    }
                }]
            }
        }]
    },
    G = g("betSlip"),
    b = g(A(0, r(f))),
    V = g(""),
    S = s(V, e => D("betSlip.single", e) ? "single" : "multi"),
    Oe = (() => {
        const e = g([]);
        return { ...e,
            add: n => {
                r(e).some(a => a.id === n.id && a.type === n.type) === !1 && e.update(a => [...a, n])
            },
            remove: n => {
                e.update(i => i.filter(a => !(a.id === n.id && a.type === n.type)))
            }
        }
    })(),
    Ge = (() => {
        const e = g([]);
        return { ...e,
            add: n => {
                r(e).some(a => a.id === n.id) === !1 && e.update(a => [...a, n])
            },
            remove: n => {
                e.update(i => i.filter(a => a.id !== n.id))
            }
        }
    })(),
    Ie = (() => {
        const e = g([]);
        return { ...e,
            add: n => {
                r(e).some(a => a.fixtureId === n.fixtureId) === !1 && e.update(a => [...a, n])
            },
            remove: n => {
                e.update(i => i.filter(a => a.fixtureId !== n.fixtureId))
            }
        }
    })(),
    y = (() => {
        const e = g({}),
            n = () => {
                const i = A(0, r(f));
                r(S) === "single" ? e.update(d => F.mapValues(d, () => i)) : b.set(i)
            };
        return f.subscribe(() => {
            n()
        }), { ...e,
            clear: () => e.set({}),
            removeInput: i => e.update(a => F.omit(a, i)),
            setBetIdValue: ({
                betId: i,
                value: a
            }) => {
                e.update(d => ({ ...d,
                    [i]: a
                }))
            },
            reset: n
        }
    })(),
    E = (() => {
        const e = g({});

        function n(i, a) {
            e.update(d => {
                const t = d[i];
                return t ? { ...d,
                    [i]: a(t)
                } : d
            })
        }
        return { ...e,
            remove: i => {
                const a = i.id;
                y.removeInput(a), e.update(d => F.omit(d, a))
            },
            replaceAll: i => {
                const a = F.fromPairs(i.map(d => [d.id, d]));
                e.set(a)
            },
            add: i => {
                const a = r(y)[i.id];
                r(Y) === !1 && J.set("betslip"), G.set("betSlip"), e.update(d => ({ ...d,
                    [i.id]: i
                })), a === void 0 && y.setBetIdValue({
                    betId: i.id,
                    value: A(0, r(f))
                })
            },
            updateBet: n,
            removeBetResponses: () => {
                e.update(i => F.mapValues(i, a => ({ ...a,
                    state: { ...a.state,
                        response: void 0
                    }
                })))
            },
            removeEachWaySelections: () => {
                e.update(i => F.mapValues(i, a => {
                    var t;
                    return a.type !== "racingBet" ? a : { ...a,
                        data: { ...a.data,
                            betType: ((t = a.data.outcome) == null ? void 0 : t.market.name) === "win" ? w.win : w.place,
                            eachWaySelected: !1
                        },
                        state: { ...a.state,
                            acceptedOdds: a.data.odds
                        }
                    }
                }))
            },
            acceptNewOdds: (i = "") => {
                e.update(a => F.mapValues(a, d => i && i !== d.id ? d : { ...d,
                    state: { ...d.state,
                        acceptedOdds: T(d)
                    }
                }))
            },
            removeAll: () => {
                y.reset(), e.set({})
            },
            removeSuccessfulBets: () => {
                e.update(i => F.mapValues(F.pickBy(i, a => {
                    var d;
                    return ((d = a.state.response) == null ? void 0 : d.type) === "error"
                }), a => ({ ...a,
                    state: { ...a.state,
                        response: void 0
                    }
                })))
            }
        }
    })(),
    de = (() => {
        const e = ye("sportMarketGroupMap", {});
        return { ...e,
            setSportMarketGroup: ({
                sport: n,
                group: i
            }) => {
                e.update(a => ({ ...a,
                    [n]: i
                }))
            }
        }
    })(),
    Pe = e => {
        const n = g(e),
            i = s([de, n], ([a, d]) => a[d] || fe);
        return {
            changeSport: a => n.set(a),
            ...i
        }
    },
    c = s(E, e => F.values(e)),
    te = s(E, e => Object.keys(e).length),
    le = s(c, e => {
        const n = e.filter(m => m.type === "swish"),
            i = e.filter(m => m.type === "customSportBet"),
            a = e.filter(m => m.type === "customSwish"),
            d = e.filter(m => m.type === "sportBet"),
            t = e.filter(m => m.type === "racingBet");
        return {
            swishBets: n,
            sportsBets: d,
            racingBets: t,
            customSwishBets: a,
            customSportsBets: i
        }
    }),
    me = s(c, e => e.filter(n => {
        var i;
        return n.type === "swish" ? n.data.outcome.suspended : n.type === "customSwish" ? n.data.bets.some(a => a.data.outcome.suspended) : n.type === "customSportBet" ? n.data.bets.some(a => a.market.status !== R.active) : n.type === "racingBet" ? n.data.spMarket ? n.data.event.status !== "open" : ((i = n.data.outcome) == null ? void 0 : i.market.status) !== ge.active : n.type === "sportBet" ? n.data.market.status !== R.active : n.data.market.status !== R.active
    })),
    We = s(c, e => e.map(n => n.id)),
    ke = s(c, e => e.filter(n => n.state.response)),
    Le = s(ke, e => e.some(n => {
        var i;
        return ((i = n.state.response) == null ? void 0 : i.type) === "error"
    })),
    Ke = (() => {
        const e = i => F.fromPairs(i.map(a => [a.name, Number(a.sportBetMin.value)])),
            n = g({});
        return { ...n,
            requestCurrencyMinBets: async i => {
                const a = await Re(i),
                    d = e(a);
                return n.set(d), d
            }
        }
    })(),
    I = s(c, e => e.reduce((n, i) => n * T(i), 1)),
    ue = s(me, e => e.length !== 0),
    oe = s(c, e => e.some(n => n.type === "racingBet" && (![w.exacta, w.trifecta, w.quinella, w.first_four].includes(n.type) || n.data.spMarket) ? !1 : T(n) === 0)),
    se = s(c, e => e.some(n => T(n) !== n.state.acceptedOdds)),
    qe = e => e.id,
    T = e => {
        var n, i, a, d;
        return e.type === "swish" ? e.data.outcome[e.state.type] : e.type === "customSportBet" || e.type === "customSwish" ? e.data.odds : e.type === "racingBet" ? e.data.eachWaySelected ? (((i = (n = e.data.runner) == null ? void 0 : n.prices.find(t => t.market.name === "win")) == null ? void 0 : i.odds) || 0) + (((d = (a = e.data.runner) == null ? void 0 : a.prices.find(t => t.market.name === "place")) == null ? void 0 : d.odds) || 0) : e.data.odds ? ? 0 : e.data.outcome.odds
    },
    re = s(c, e => e.map(n => {
        var i, a, d, t;
        return n.type === "racingBet" ? (a = (i = n.data) == null ? void 0 : i.event) == null ? void 0 : a.id : (t = (d = n.data) == null ? void 0 : d.fixture) == null ? void 0 : t.id
    }).reduce((n, i, a, d) => n.includes(i) === !1 && d.slice(a + 1).includes(i) ? [...n, i] : n, [])),
    ce = s([S, b, c, y], ([e, n, i, a]) => e === "multi" ? Number(n) : i.reduce((d, t) => {
        let m = Number(a[t.id]);
        return t.type === "racingBet" && t.data.eachWaySelected && (m *= 2), d + m
    }, 0)),
    Ue = s([y, c], ([e, n]) => {
        const i = n,
            a = i[0] ? Number(e[i[0].id]) : void 0;
        return i.every(d => Number(e[d.id]) === a)
    }),
    je = s([S, c], ([e, n]) => {
        const i = n.filter(d => !d.state.response).length,
            a = n.filter(d => d.state.response).length;
        return e === "multi" && a !== 0 ? 0 : i
    }),
    Qe = s([S, I, c, y, b], ([e, n, i, a, d]) => e === "multi" ? n * Number(d) : i.reduce((t, m) => t + T(m) * Number(a[m.id]), 0)),
    He = e => {
        const n = A(0, r(f)),
            i = F.fromPairs(e.map(d => [d.id, d])),
            a = F.fromPairs(e.map(d => [d.id, n]));
        r(Y) === !1 && J.set("betslip"), G.set("betSlip"), E.set(i), b.set(n), y.update(d => ({ ...d,
            ...a
        }))
    },
    ze = s([ce, be], ([e, n]) => e > n),
    Xe = s(V, e => D("betSlip.multi.fetching", e) || D("betSlip.single.fetching", e)),
    Ze = s(V, e => D("betSlip.single.fetching", e) === !1),
    Je = s(V, e => D("betSlip.multi.completedBet", e) || D("betSlip.single.completedBet", e)),
    Ye = g("active");

function C(e) {
    return e != null && e.type ? e.type === "swish" || e.type === "customSwish" ? "swish" : e.type === "customSportBet" ? "betradar" : ["racingBet"].includes(e.type) ? "racing" : e.data.market.provider : null
}
const $e = s([c, S], ([e, n]) => {
        if (n === "multi" && e.length === 1) return !0
    }),
    en = s([c, S], ([e, n]) => n !== "multi" ? !1 : e.some(i => i.type === "swish")),
    nn = s([c, S], ([e, n]) => n === "multi" && e.some(i => i.type === "customSportBet" || i.type === "customSwish")),
    an = s([c, S], ([e]) => {
        if (!e[0]) return "invalidMultiFallback";
        const n = C(e[0]),
            i = e.find(d => C(d) !== n),
            a = i ? C(i) : "";
        if (!n || !a) return "invalidMultiFallback";
        if (n === "betradar") {
            if (a === "oddin") return "invalidMultiSportEsport";
            if (a === "racing") return "invalidMultiSportRacing";
            if (a === "swish") return "invalidMultiSportSwish"
        }
        if (n === "oddin") {
            if (a === "betradar") return "invalidMultiEsportSport";
            if (a === "racing") return "invalidMultiEsportRacing";
            if (a === "swish") return "invalidMultiEsportSwish"
        }
        if (n === "racing") {
            if (a === "oddin") return "invalidMultiRacingEsport";
            if (a === "betradar") return "invalidMultiRacingSport";
            if (a === "swish") return "invalidMultiRacingSwish"
        }
        if (n === "swish") {
            if (a === "oddin") return "invalidMultiSwishEsport";
            if (a === "racing") return "invalidMultiSwishRacing";
            if (a === "betradar") return "invalidMultiSwishSwish"
        }
        return "invalidMultiFallback"
    }),
    dn = s([c, S], ([e, n]) => {
        if (n !== "multi") return !1;
        const i = e[0],
            a = i ? C(i) : void 0;
        return a ? !e.every(d => C(d) === a) : !e.every(d => d.type === i.type)
    }),
    ve = (() => {
        const e = $(Ae);
        return { ...e,
            updateBet: (n, i) => {
                e.update(a => {
                    var l, k, u, o, v, N, B, W, L;
                    const d = ((u = (k = (l = a == null ? void 0 : a.data) == null ? void 0 : l.user) == null ? void 0 : k.activeSportBets) == null ? void 0 : u.map(p => p.id === n ? i(p) : p)) || [],
                        t = ((N = (v = (o = a == null ? void 0 : a.data) == null ? void 0 : o.user) == null ? void 0 : v.activeSwishBetList) == null ? void 0 : N.map(p => p.id === n ? i(p) : p)) || [],
                        m = ((L = (W = (B = a == null ? void 0 : a.data) == null ? void 0 : B.user) == null ? void 0 : W.activeRacingBets) == null ? void 0 : L.map(p => p.id === n ? i(p) : p)) || [];
                    return d.length !== 0 || t.length !== 0 || m.length !== 0 ? { ...a,
                        data: { ...a.data,
                            user: { ...a.data.user,
                                activeSportBets: d,
                                activeSwishBetList: t,
                                activeRacingBets: m
                            }
                        }
                    } : a
                })
            },
            removeBet: n => {
                e.update(i => {
                    var m, l, k, u, o, v, N;
                    const a = (((l = (m = i == null ? void 0 : i.data) == null ? void 0 : m.user) == null ? void 0 : l.activeSportBets) || []).filter(B => B.id !== n),
                        d = (((u = (k = i == null ? void 0 : i.data) == null ? void 0 : k.user) == null ? void 0 : u.activeRacingBets) || []).filter(B => B.id !== n),
                        t = (((v = (o = i == null ? void 0 : i.data) == null ? void 0 : o.user) == null ? void 0 : v.activeSwishBetList) || []).filter(B => B.id !== n);
                    return { ...i,
                        data: (N = i == null ? void 0 : i.data) != null && N.user ? { ...i.data,
                            user: { ...i.data.user,
                                activeSportBets: a,
                                activeRacingBets: d,
                                activeSwishBetList: t
                            }
                        } : null
                    }
                })
            },
            updateFixtureEventStatus: ({
                betId: n,
                outcomeId: i,
                matchStatus: a,
                eventStatus: d
            }) => {
                e.update(t => {
                    var m, l, k;
                    return (m = t == null ? void 0 : t.data) != null && m.user ? { ...t,
                        data: { ...t.data,
                            user: { ...t.data.user,
                                activeSportBets: ((l = t.data.user.activeSportBets) == null ? void 0 : l.map(u => u.id === n ? { ...u,
                                    outcomes: u.outcomes.map(o => o.outcome.id === i ? { ...o,
                                        fixture: { ...o.fixture,
                                            status: a,
                                            eventStatus: d
                                        }
                                    } : o)
                                } : u)) ? ? [],
                                activeSwishBetList: ((k = t.data.user.activeSwishBetList) == null ? void 0 : k.map(u => u.id === n ? { ...u,
                                    outcomes: u.outcomes.map(o => o.id === i ? { ...o,
                                        outcome: { ...o.outcome,
                                            market: { ...o.outcome.market,
                                                game: { ...o.outcome.market.game,
                                                    fixture: { ...o.outcome.market.game.fixture,
                                                        eventStatus: d
                                                    }
                                                }
                                            }
                                        }
                                    } : o)
                                } : u)) ? ? []
                            }
                        }
                    } : t
                })
            },
            addBet: n => {
                e.update(i => {
                    var t, m, l, k, u, o;
                    const a = [...((m = (t = i == null ? void 0 : i.data) == null ? void 0 : t.user) == null ? void 0 : m.activeSportBets) || [], !(n != null && n.outcome) && n].filter(Boolean) || [],
                        d = [...((k = (l = i == null ? void 0 : i.data) == null ? void 0 : l.user) == null ? void 0 : k.activeSwishBetList) || [], (n == null ? void 0 : n.outcome) && n].filter(Boolean) || [];
                    return { ...i,
                        data: (u = i == null ? void 0 : i.data) != null && u.user ? { ...i.data,
                            user: { ...(o = i == null ? void 0 : i.data) == null ? void 0 : o.user,
                                activeSportBets: a,
                                activeSwishBetList: d
                            }
                        } : null
                    }
                })
            }
        }
    })(),
    tn = s(ve, e => {
        var n, i, a, d, t, m;
        return (((i = (n = e == null ? void 0 : e.data) == null ? void 0 : n.user) == null ? void 0 : i.activeSportBetCount) ? ? 0) + (((d = (a = e == null ? void 0 : e.data) == null ? void 0 : a.user) == null ? void 0 : d.activeSwishBetCount) ? ? 0) + (((m = (t = e == null ? void 0 : e.data) == null ? void 0 : t.user) == null ? void 0 : m.activeRacingBetCount) ? ? 0)
    }),
    ln = s([c, S], ([e, n]) => n === "multi" && e.some(i => i.type === "swish")),
    mn = $(Ve),
    kn = s([re, se, te, ue, oe, V], ([e, n, i, a, d, t]) => {
        const m = D("betSlip.multi.fetching", t);
        return e.length !== 0 || n || i === 0 || a || d || m
    }),
    un = {
        replaceBets: He,
        repeatStake: () => {
            const e = r(c);
            y.update(n => {
                const i = Number(n[e[0].id]);
                return F.mapValues(n, () => A(i, r(f)))
            })
        }
    },
    on = () => {
        const e = x(),
            n = r(le),
            i = r(f),
            a = r(y),
            d = r(O);
        return {
            placeSportBets: () => n.sportsBets.map(t => {
                const m = {
                    amount: Number(a[t.id]),
                    currency: i,
                    outcomeIds: [t.id],
                    oddsChange: K[d],
                    betType: t.data.fixture.provider === z.oddin ? _.esports : _.sports
                };
                return e.mutation(ne, m).toPromise().then(l => {
                    var u;
                    const k = (u = l.data) == null ? void 0 : u.sportBet;
                    return { ...t,
                        state: { ...t.state,
                            response: k ? {
                                type: "success",
                                bet: k
                            } : {
                                type: "error",
                                error: h(l.error)
                            }
                        }
                    }
                }).catch(l => ({ ...t,
                    state: { ...t.state,
                        response: {
                            type: "error",
                            error: h(l)
                        }
                    }
                }))
            }),
            placeCustomSportBets: () => n.customSportsBets.map(t => {
                const m = {
                    amount: Number(a[t.id]),
                    currency: i,
                    outcomeIds: t.data.bets.map(l => l.outcome.id),
                    oddsChange: K[d]
                };
                return e.mutation(Ee, m).toPromise().then(l => {
                    var u;
                    const k = (u = l.data) == null ? void 0 : u.customSportBet;
                    return { ...t,
                        state: { ...t.state,
                            response: k ? {
                                type: "success",
                                bet: k
                            } : {
                                type: "error",
                                error: h(l.error)
                            }
                        }
                    }
                }).catch(l => ({ ...t,
                    state: { ...t.state,
                        response: {
                            type: "error",
                            error: h(l)
                        }
                    }
                }))
            }),
            placeSwishBets: () => n.swishBets.map(t => {
                const m = {
                    amount: Number(a[t.id]),
                    currency: i,
                    oddsChange: q[d],
                    requestedMultiplier: T(t),
                    lines: [{
                        lineType: U[t.state.type],
                        outcomeId: t.data.outcome.id
                    }]
                };
                return e.mutation(ie, m).toPromise().then(l => {
                    var u;
                    const k = (u = l.data) == null ? void 0 : u.createSwishBet;
                    return { ...t,
                        state: { ...t.state,
                            response: k ? {
                                type: "success",
                                bet: k
                            } : {
                                type: "error",
                                error: h(l.error)
                            }
                        }
                    }
                }).catch(l => ({ ...t,
                    state: { ...t.state,
                        response: {
                            type: "error",
                            error: h(l)
                        }
                    }
                }))
            }),
            placeCustomSwishBets: () => n.customSwishBets.map(t => {
                var l;
                const m = {
                    amount: Number(a[t.id]),
                    currency: i,
                    oddsChange: q[d],
                    requestedMultiplier: T(t),
                    lines: t.data.bets.map(k => ({
                        lineType: U[k.state.type],
                        outcomeId: k.data.outcome.id
                    })),
                    sport: Ne(t.data.fixture.tournament.slug, ((l = t.data.fixture.swishGame) == null ? void 0 : l.swishSportId) || void 0)
                };
                return e.mutation(_e, m).toPromise().then(k => {
                    var o;
                    const u = (o = k.data) == null ? void 0 : o.createSwishCustomBet;
                    return { ...t,
                        state: { ...t.state,
                            response: u ? {
                                type: "success",
                                bet: u
                            } : {
                                type: "error",
                                error: h(k.error)
                            }
                        }
                    }
                }).catch(k => ({ ...t,
                    state: { ...t.state,
                        response: {
                            type: "error",
                            error: h(k)
                        }
                    }
                }))
            }),
            placeRacingBets: () => n.racingBets.map(t => {
                const m = sn(t, a);
                return e.mutation(ae, m).toPromise().then(l => {
                    var u;
                    const k = (u = l.data) == null ? void 0 : u.racingBet;
                    return { ...t,
                        state: { ...t.state,
                            response: k ? {
                                type: "success",
                                bet: k
                            } : {
                                type: "error",
                                error: h(l.error)
                            }
                        }
                    }
                }).catch(l => ({ ...t,
                    state: { ...t.state,
                        response: {
                            type: "error",
                            error: h(l)
                        }
                    }
                }))
            })
        }
    },
    sn = (e, n) => {
        var i, a;
        return {
            amount: e.data.eachWaySelected ? Number(n[e.id]) * 2 : Number(n[e.id]),
            type: X.single,
            currency: r(f),
            identifier: "",
            oddsChange: Te[r(O)],
            multiplier: e.data.spMarket || e.data.eachWaySelected ? null : T(e),
            selections: [{
                selectionSlots: (i = e.data.runner) != null && i.runnerNumber ? [
                    [e.data.runner.runnerNumber.toString()]
                ] : [],
                type: e.data.eachWaySelected ? w.each_way : w[(a = e.data.outcome) == null ? void 0 : a.market.name],
                eventId: e.data.event.id,
                derivative: e.data.spMarket ? Z.sp : null
            }]
        }
    },
    Ne = (e, n) => e === "ncaa-regular" && n ? n === "5" ? "cfb" : "cbb" : e === "nba-in-season-tournament" ? "nba" : e,
    h = e => {
        var n, i, a, d, t, m;
        return (i = (n = e == null ? void 0 : e.graphQLErrors) == null ? void 0 : n[0]) == null || i.message, {
            message: ((d = (a = e == null ? void 0 : e.graphQLErrors) == null ? void 0 : a[0]) == null ? void 0 : d.message) || "Network disconnected",
            errorType: ((m = (t = e == null ? void 0 : e.graphQLErrors) == null ? void 0 : t[0]) == null ? void 0 : m.errorType) || "error"
        }
    },
    rn = async () => {
        const {
            placeSportBets: e,
            placeSwishBets: n,
            placeCustomSportBets: i,
            placeCustomSwishBets: a,
            placeRacingBets: d
        } = on(), t = [...e(), ...n(), ...i(), ...a(), ...d()], m = await Promise.all(t);
        return E.replaceAll(m), M.next({
            type: "fetchActiveBets"
        }), m
    };
async function cn({
    bets: e,
    amount: n,
    currency: i,
    oddsChange: a
}) {
    var m;
    const d = {
            amount: n,
            currency: i,
            outcomeIds: e.map(l => l.id),
            oddsChange: a,
            betType: C(e[0]) === z.oddin ? _.esports : _.sports
        },
        t = x();
    try {
        const l = await t.mutation(ne, d).toPromise(),
            k = (m = l.data) == null ? void 0 : m.sportBet;
        return k ? {
            bets: e.map(u => ({ ...u,
                state: { ...u.state,
                    response: {
                        type: "success",
                        bet: k
                    }
                }
            })),
            type: "success",
            variables: d
        } : {
            bets: e.map(u => {
                var o, v, N;
                return { ...u,
                    state: { ...u.state,
                        response: {
                            type: "error",
                            error: ((N = (v = (o = l.error) == null ? void 0 : o.graphQLErrors) == null ? void 0 : v[0]) == null ? void 0 : N.message) || "Network disconnected"
                        }
                    }
                }
            }),
            type: "error",
            variables: d
        }
    } catch (l) {
        return {
            bets: e.map(k => ({ ...k,
                state: { ...k.state,
                    response: {
                        type: "error",
                        error: l instanceof Error && l.message ? l.message : "Network disconnected"
                    }
                }
            })),
            type: "error",
            variables: d
        }
    }
}
async function vn({
    bets: e,
    amount: n,
    currency: i,
    oddsChange: a
}) {
    var m;
    const d = {
            amount: n,
            currency: i,
            requestedMultiplier: e.reduce((l, k) => T(k) * l, 1),
            lines: e.map(l => ({
                outcomeId: l.data.outcome.id,
                lineType: l.state.type
            })),
            oddsChange: a
        },
        t = x();
    try {
        const l = await t.mutation(ie, d).toPromise(),
            k = (m = l.data) == null ? void 0 : m.createSwishBet;
        return k ? {
            bets: e.map(u => ({ ...u,
                state: { ...u.state,
                    response: {
                        type: "success",
                        bet: k
                    }
                }
            })),
            type: "success",
            variables: d
        } : {
            bets: e.map(u => {
                var o, v, N;
                return { ...u,
                    state: { ...u.state,
                        response: {
                            type: "error",
                            error: ((N = (v = (o = l.error) == null ? void 0 : o.graphQLErrors) == null ? void 0 : v[0]) == null ? void 0 : N.message) || "Network disconnected"
                        }
                    }
                }
            }),
            type: "error",
            variables: d
        }
    } catch (l) {
        return {
            bets: e.map(k => ({ ...k,
                state: { ...k.state,
                    response: {
                        type: "error",
                        error: l instanceof Error && l.message ? l.message : "Network disconnected"
                    }
                }
            })),
            type: "error",
            variables: d
        }
    }
}
async function Nn({
    bets: e,
    amount: n,
    currency: i,
    oddsChange: a
}) {
    var m;
    const d = {
            amount: n,
            type: X.multi,
            currency: i,
            identifier: "",
            oddsChange: a,
            multiplier: e.every(l => l.data.spMarket) ? 0 : r(I),
            selections: e.map(l => {
                var k, u;
                return {
                    selectionSlots: [
                        [(k = l.data.runner) == null ? void 0 : k.runnerNumber.toString()]
                    ],
                    eventId: l.data.event.id,
                    type: w[(u = l.data.outcome) == null ? void 0 : u.market.name],
                    derivative: l.data.spMarket ? Z.sp : null
                }
            })
        },
        t = x();
    try {
        const l = await t.mutation(ae, d).toPromise(),
            k = (m = l.data) == null ? void 0 : m.racingBet;
        if (k) {
            const u = (k.refundAmount || 0) > 0;
            return b.set(k.amount.toString()), {
                bets: e.map(o => ({ ...o,
                    state: { ...o.state,
                        response: {
                            type: "success",
                            bet: k
                        }
                    }
                })),
                type: "success",
                variables: { ...d,
                    amount: k.amount,
                    partial: u
                }
            }
        }
        return {
            bets: e.map(u => {
                var o, v, N;
                return { ...u,
                    state: { ...u.state,
                        response: {
                            type: "error",
                            error: ((N = (v = (o = l.error) == null ? void 0 : o.graphQLErrors) == null ? void 0 : v[0]) == null ? void 0 : N.message) || "Network disconnected"
                        }
                    }
                }
            }),
            type: "error",
            variables: d
        }
    } catch (l) {
        return {
            bets: e.map(k => ({ ...k,
                state: { ...k.state,
                    response: {
                        type: "error",
                        error: l instanceof Error && l.message ? l.message : "Network disconnected"
                    }
                }
            })),
            type: "error",
            variables: d
        }
    }
}
const Fn = () => new Promise((e, n) => {
        async function i() {
            try {
                const a = r(c),
                    d = r(f),
                    t = r(O),
                    m = Number(r(b));
                if (a[0].type === "swish") {
                    const l = await vn({
                        bets: a,
                        amount: m,
                        currency: d,
                        oddsChange: t
                    });
                    l.type === "success" ? (M.next({
                        type: "fetchActiveBets"
                    }), e(l)) : n(l.bets)
                } else if (a[0].type === "racingBet") {
                    const l = await Nn({
                        bets: a,
                        amount: m,
                        currency: d,
                        oddsChange: t
                    });
                    l.type === "success" ? (M.next({
                        type: "fetchActiveBets"
                    }), e(l)) : n(l.bets)
                } else {
                    const l = await cn({
                        bets: a,
                        amount: m,
                        currency: d,
                        oddsChange: t
                    });
                    l.type === "success" ? (M.next({
                        type: "fetchActiveBets"
                    }), e(l)) : n(l)
                }
            } catch (a) {
                n(a)
            }
        }
        i()
    }),
    Fe = s([c], ([e]) => e.reduce((n, i) => {
        if (i.type === "racingBet") {
            const a = i.data.spMarket === "win" ? Ce : i.data.spMarket === "place" ? De : i.data.odds || 1;
            return n * a
        }
        return n
    }, 1)),
    P = s([Q, he, f], ([e, n, i]) => {
        var d, t;
        const a = e !== "crypto" ? (d = n.rates) == null ? void 0 : d.usd[e] : (t = n.rates) == null ? void 0 : t[i].usd;
        if (a) return e !== "crypto" ? j * a : j / a
    }),
    Sn = s([Fe, S, H, P], ([e, n, i, a]) => n === "multi" && a ? a / (i || 1) / e : null),
    pn = s([S, b, H, Fe, P, c, Q], ([e, n, i, a, d, t, m]) => {
        if (e === "multi" && d && t.some(l => l.type === "racingBet")) {
            const l = m === "crypto" ? 1e8 : 100;
            return Math.trunc(a * Number(n) * (i || 1) * l) / l > d
        }
        return !1
    }),
    An = Object.freeze(Object.defineProperty({
        __proto__: null,
        actions: un,
        activeBets: ve,
        activeBetsCount: tn,
        activeTab: G,
        amountMoreThanBalance: ze,
        betCount: te,
        betIds: We,
        betList: c,
        betListCount: je,
        betMap: E,
        betsWithResponses: ke,
        completedBet: Je,
        createDerivedSportMarketGroup: Pe,
        currencyMinBets: Ke,
        estimatedPayout: Qe,
        everyAmountIsSame: Ue,
        exceedsMaxRacingBetAmount: pn,
        fetching: Xe,
        filterBetsByProvider: le,
        fixtureIdsWithMultipleBets: re,
        getBetProvider: C,
        getBetslipBetId: qe,
        getBetslipBetOdds: T,
        getSwishSportSlug: Ne,
        hasChangedOdds: se,
        hasFailed: Le,
        hasInactiveBets: ue,
        hasPropBet: ln,
        hasZeroOdds: oe,
        inactiveBets: me,
        inputs: y,
        invalidMulti: dn,
        invalidMultiMessage: an,
        invalidSameGameMulti: nn,
        isSwishMulti: en,
        matchStatistics: Ie,
        maximumRacingBetAmount: Sn,
        multiBetAmount: b,
        multiMaxBetDisabled: kn,
        myBetsTab: Ye,
        placeMultiBet: Fn,
        placeSingleBet: rn,
        racingMaxWinningsInViewCurrency: P,
        racingWidgets: Ge,
        settledBets: mn,
        showMessages: Ze,
        singularMultiBet: $e,
        sportMarketGroupMap: de,
        sportWidgets: Oe,
        tab: S,
        totalBetAmount: ce,
        totalOdds: I,
        xstate: V
    }, Symbol.toStringTag, {
        value: "Module"
    }));
export {
    Ae as A, dn as B, nn as C, oe as D, ze as E, ue as F, kn as G, c as H, G as I, Ye as J, Le as K, Je as L, T as M, qe as N, C as O, Ue as P, We as Q, Ke as R, Ve as S, Vn as T, je as U, Mn as V, mn as a, E as b, Pe as c, ve as d, Oe as e, un as f, re as g, se as h, rn as i, y as j, ne as k, b as l, Ie as m, Ne as n, Xe as o, Fn as p, tn as q, Ge as r, de as s, S as t, te as u, An as v, Sn as w, V as x, pn as y, an as z
};