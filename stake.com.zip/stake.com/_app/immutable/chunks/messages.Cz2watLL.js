import {
    h as e
} from "./index.B4-7gKq3.js";
import {
    V as s
} from "./index.B81orGJm.js";
const r = {
        username: e._("Username"),
        password: e._("Password"),
        email: e._("Email"),
        state: e._("State"),
        continue: e._("Continue"),
        playNow: e._("Play Now"),
        checkBox: e._("checkbox"),
        code: e._("Code (Optional)"),
        or: e._("OR"),
        dob: e._("Date of Birth"),
        phoneNumber: e._("Phone (Optional)"),
        hostBanned: e._("Email domain not supported"),
        stateBanned: e._("Not available in this state currently"),
        usernameInvalid: e._("Username contains invalid characters"),
        usernameExists: e._("This username is taken, please enter another"),
        dateOfBirthRequired: e._("Please enter your date of birth"),
        minimumAge: a => ({
            id: "You need to be at least {age} years old",
            values: {
                age: a
            }
        }),
        maximumAge: e._("You cannot be more than 120 years old"),
        termsAndConditionsAgeCheck: a => ({
            id: "I am {age} years or older",
            values: {
                age: a
            }
        }),
        termsAndConditionsPlayingForSelf: e._("I am playing for myself and with my own money"),
        termsAndConditionsIsNotBanned: e._("I have not self-excluded myself nor have been banned from any gambling website"),
        termsAndConditionsInfoIsCorrect: e._("I declare that all information provided by me is correct, complete and can be verified"),
        termsAndConditionsUnderstandAndAdhere: e._("I understand that I am required to adhere to the Terms & Conditions* set forth by this website"),
        termsAndConditions: e._("I comply to the following statements:"),
        checkboxRequired: e._("This field is required"),
        usernameHint: e._("Your username must be 3-14 characters long."),
        passwordHint: e._("Your password must be 8-48 characters long."),
        passwordCaseError: e._("Password must include a lower and upper case character"),
        passwordNumberError: e._("Password must include at least one number"),
        invalidEmail: e._("Please enter a valid email address"),
        invalidEmailMissingAtSymbol: e._("Please include an ‘@’ in your email address"),
        invalidEmailMissingFullStop: e._("Please include a ‘.’ in your email address"),
        invalidPasswordUsernameMatches: e._("Your username and password must be different"),
        minimumCharacters: (a, n) => ({
            id: "Your {field} must be at least {characters} characters long",
            values: {
                field: a,
                characters: n
            }
        }),
        maximumCharacters: (a, n) => ({
            id: "Your {field} must be less than {characters} characters long",
            values: {
                field: a,
                characters: n
            }
        }),
        unknownErrorAccount: e._("An unknown error has occurred whilst registering your account, please try again later"),
        unknownError: e._("An unknown error has occurred, please try again later"),
        termsDesc: e._("To continue, please take the time to read and understand the terms and conditions. Once you are ready, scroll to the end to begin your acceptance and start playing."),
        checkboxValidation: e._("Please read the terms and conditions in full and scroll to the end to accept"),
        signupCodeError: e._("There is a problem updating offer code. Please contact support"),
        signUpStepDesc: e._("Fill out your details"),
        termsStepDesc: e._("Read and accept the terms and conditions"),
        phoneInvalid: e._("Phone number is not valid"),
        errorLoadingData: e._("Error loading data - please contact support if the issue persists")
    },
    t = { ...r
    },
    o = {
        stake: r,
        sweeps: t
    },
    l = o[s] || r;
export {
    l as r
};