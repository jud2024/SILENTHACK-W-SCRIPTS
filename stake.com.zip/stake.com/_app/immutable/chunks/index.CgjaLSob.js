import {
    h as n
} from "./howler.D2eOmZSY.js";
import {
    j as t,
    S as d,
    k as m
} from "./index.B4-7gKq3.js";
import {
    w as o
} from "./index.C2-CG2CN.js";
const a = m("settings"),
    e = (s, r) => t.toggle(a(s, r)),
    l = a("soundsVolume", 1),
    c = e("soundsEnabled", !0),
    b = e("maxBetEnabled", !1),
    g = e("hotKeysEnabled", !1),
    u = e("advancedBetTermsAccepted", !1),
    i = e("customBetTermsAccepted", !1),
    f = t.toggle(o(!0)),
    p = t.toggle(o(!1)),
    h = t.toggle(o(!1)),
    E = t.toggle(o(!0)),
    S = e("betsBoardEnabled", !1),
    B = a("oddsChange", d.none);
c.subscribe(s => {
    n.Howler.mute(!s)
}), l.subscribe(s => {
    n.Howler.volume(s)
});
const v = Object.freeze(Object.defineProperty({
    __proto__: null,
    advancedBetTermsAccepted: u,
    animationsEnabled: f,
    betsBoardEnabled: S,
    customBetTermsAccepted: i,
    hotKeysEnabled: g,
    instantResult: p,
    maxBetEnabled: b,
    oddsChange: B,
    showPlayerResults: E,
    soundsEnabled: c,
    soundsVolume: l,
    theaterModeEnabled: h
}, Symbol.toStringTag, {
    value: "Module"
}));
export {
    f as a, u as b, l as c, E as d, v as e, g as h, p as i, b as m, B as o, c as s, h as t
};