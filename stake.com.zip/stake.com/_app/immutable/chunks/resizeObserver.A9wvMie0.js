function o(s, n) {
    const e = new ResizeObserver(([r]) => {
        r && n(r.contentRect)
    });
    return e.observe(s), {
        destroy() {
            e.disconnect()
        }
    }
}
export {
    o as r
};