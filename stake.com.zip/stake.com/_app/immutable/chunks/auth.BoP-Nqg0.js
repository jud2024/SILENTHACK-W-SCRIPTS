import {
    f as l,
    ap as d,
    aI as m,
    aQ as t
} from "./index.B4-7gKq3.js";
import {
    g as k
} from "./utils.CiRndAdN.js";
const o = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "mutation",
            name: {
                kind: "Name",
                value: "CompleteEnableUserTfa"
            },
            variableDefinitions: [{
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "enableTfaKey"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "String"
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "sessionName"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "String"
                        }
                    }
                }
            }],
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "completeEnableUserTfa"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "enableTfaKey"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "enableTfaKey"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "sessionName"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "sessionName"
                            }
                        }
                    }],
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "UserAuthenticatedSession"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "UserSession"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "UserSession"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "sessionName"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "ip"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "country"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "city"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "updatedAt"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "UserBalance"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "UserBalance"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "available"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "amount"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currency"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "vault"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "amount"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currency"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "UserVerification"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "IdentityUserVerification"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "status"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "verified"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "AgeVerification"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "IdentityAgeVerification"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "birthDate"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "expireAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "type"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "verified"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "AddressVerification"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "IdentityAddressVerification"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "city"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "country"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "expireAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "state"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "street"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "type"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "verified"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "zip"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "DocumentVerification"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "IdentityDocumentVerification"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "documentBirthDate"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "documentCity"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "documentCountry"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "documentExpiry"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "documentFirstName"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "documentId"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "documentLastName"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "documentNationality"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "documentState"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "documentStreet"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "documentType"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "documentZip"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "expireAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "type"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "verified"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "RiskVerification"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "IdentityRiskVerification"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "expireAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "nationalityCountry"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "nonPoliticallyExposed"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "nonThirdPartyAccount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "preferredName"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "type"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "verified"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "EmploymentVerification"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "IdentityEmploymentVerification"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "employerCity"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "employerCountry"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "employerName"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "employerPhone"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "employerState"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "employerStreet"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "employerZip"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "expireAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "type"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "verified"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "occupation"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "UserAuth"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "User"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "email"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "hasPhoneNumberVerified"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "hasEmailVerified"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "hasPassword"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "intercomHash"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "hasTfaEnabled"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "mixpanelId"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "hasOauth"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "isMaxBetEnabled"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "isReferred"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "isSportsbookExcluded"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "registeredWithVpn"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "flags"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "flag"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "createdAt"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "signupCode"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "code"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "code"
                                    }
                                }]
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "roles"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "balances"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "UserBalance"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "activeClientSeed"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "seed"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "previousServerSeed"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "seed"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "activeDepositBonus"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "status"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "minDepositValue"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "maxDepositValue"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "maxBetMultiplier"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "bonusMultiplier"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "expectedAmountMultiplier"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currency"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "activeServerSeed"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "seedHash"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "nextSeedHash"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "nonce"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "blocked"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "veriffStatus"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "verifications"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "userVerification"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "UserVerification"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "ageVerification"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "AgeVerification"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "addressVerification"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "AddressVerification"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "documentVerification"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "DocumentVerification"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "riskVerification"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "RiskVerification"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "employmentVerification"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "EmploymentVerification"
                                    }
                                }]
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "termsOfService"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "status"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "veriffBiometricVerificationStatus"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "notificationCount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currentPlaySession"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "fitToPlay"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "UserAuthenticatedSession"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "UserAuthenticatedSession"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "token"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "session"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "UserSession"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "user"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "UserAuth"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }]
    },
    u = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "query",
            name: {
                kind: "Name",
                value: "InitialUserRequest"
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "UserAuth"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "UserBalance"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "UserBalance"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "available"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "amount"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currency"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "vault"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "amount"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currency"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "UserVerification"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "IdentityUserVerification"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "status"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "verified"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "AgeVerification"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "IdentityAgeVerification"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "birthDate"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "expireAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "type"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "verified"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "AddressVerification"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "IdentityAddressVerification"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "city"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "country"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "expireAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "state"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "street"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "type"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "verified"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "zip"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "DocumentVerification"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "IdentityDocumentVerification"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "documentBirthDate"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "documentCity"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "documentCountry"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "documentExpiry"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "documentFirstName"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "documentId"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "documentLastName"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "documentNationality"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "documentState"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "documentStreet"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "documentType"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "documentZip"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "expireAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "type"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "verified"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "RiskVerification"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "IdentityRiskVerification"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "expireAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "nationalityCountry"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "nonPoliticallyExposed"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "nonThirdPartyAccount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "preferredName"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "type"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "verified"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "EmploymentVerification"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "IdentityEmploymentVerification"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "employerCity"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "employerCountry"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "employerName"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "employerPhone"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "employerState"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "employerStreet"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "employerZip"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "expireAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "type"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "verified"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "occupation"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "UserAuth"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "User"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "email"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "hasPhoneNumberVerified"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "hasEmailVerified"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "hasPassword"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "intercomHash"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "hasTfaEnabled"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "mixpanelId"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "hasOauth"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "isMaxBetEnabled"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "isReferred"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "isSportsbookExcluded"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "registeredWithVpn"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "flags"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "flag"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "createdAt"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "signupCode"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "code"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "code"
                                    }
                                }]
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "roles"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "balances"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "UserBalance"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "activeClientSeed"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "seed"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "previousServerSeed"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "seed"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "activeDepositBonus"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "status"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "minDepositValue"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "maxDepositValue"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "maxBetMultiplier"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "bonusMultiplier"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "expectedAmountMultiplier"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currency"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "activeServerSeed"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "seedHash"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "nextSeedHash"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "nonce"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "blocked"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "veriffStatus"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "verifications"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "userVerification"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "UserVerification"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "ageVerification"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "AgeVerification"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "addressVerification"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "AddressVerification"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "documentVerification"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "DocumentVerification"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "riskVerification"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "RiskVerification"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "employmentVerification"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "EmploymentVerification"
                                    }
                                }]
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "termsOfService"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "status"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "veriffBiometricVerificationStatus"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "notificationCount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currentPlaySession"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "fitToPlay"
                            }
                        }]
                    }
                }]
            }
        }]
    };
async function v(i) {
    if (i.isAuthenticated) {
        const [n] = await Promise.all([l({
            doc: u,
            variables: {},
            load: i
        })]);
        return n != null && n.user ? { ...n
        } : null
    }
    return null
}
const N = async i => {
        const n = e => t(o, e);
        try {
            const e = await n({
                    enableTfaKey: i,
                    sessionName: k()
                }),
                a = e == null ? void 0 : e.completeEnableUserTfa;
            a && d.next({
                type: "twoFactor",
                subtype: "enable",
                userAuthenticatedSession: { ...a,
                    session: { ...a.session,
                        user: { ...a.session.user,
                            hasTfaEnabled: !0
                        }
                    }
                }
            })
        } catch (e) {
            e && m.next({
                type: (e == null ? void 0 : e.errorType) || "errorExchange",
                error: e
            })
        }
    },
    r = i => {
        d.next({
            type: "firstUserResponse",
            user: i
        })
    };
export {
    u as I, N as e, r as i, v as l
};