import {
    s as H,
    C as ee,
    H as Pe,
    D as te,
    f as V,
    E as Be,
    i as g,
    F as y,
    j as b,
    n as j,
    k as F,
    m as T,
    c as z,
    o as Ce,
    O,
    e as P,
    t as N,
    P as L,
    d as B,
    h as M,
    l as C,
    V as se
} from "./scheduler.DXu26z7T.js";
import {
    S as U,
    i as q,
    g as A,
    b as _,
    e as I,
    t as m,
    c as v,
    a as k,
    m as S,
    d as w
} from "./index.Dz_MmNB3.js";
import {
    h as D,
    i as Y,
    T as Ze,
    ai as fe,
    bZ as ie,
    cK as ue
} from "./index.B4-7gKq3.js";
import {
    F as Oe
} from "./index.DUHuGv4r.js";
import {
    a as Le
} from "./index.Drh4nwD9.js";
import {
    B as ae
} from "./index.DlOe5U6J.js";
import {
    F as Re,
    g as Ne
} from "./utils.PGvbthip.js";
import {
    e as ce,
    u as He,
    o as Ue
} from "./each.DvgCmocI.js";
import {
    g as W
} from "./index.CUgLGuIE.js";
import {
    T as qe
} from "./index.D7nbRHfU.js";
import "./index.ByMdEFI5.js";
import {
    d as x
} from "./index.C2-CG2CN.js";
import {
    e as J,
    m as le
} from "./index.lhCIiKC2.js";
import "./index.B3dW9TVs.js";
import {
    H as Q
} from "./index.u8ZD9oiA.js";
import {
    B as X
} from "./button.BwmFDw8u.js";
import {
    G as oe
} from "./Graph.5H4YYOLp.js";
import {
    L as re
} from "./Live.DUBCovZv.js";

function Ge(i) {
    let t, r, e = ` <title>${i[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M0 49.5v-46h64v46H0Zm26.5-7c2.21 0 4-1.79 4-4v-24c0-2.21-1.79-4-4-4h-16c-2.21 0-4 1.79-4 4v24c0 2.21 1.79 4 4 4h16Zm27 0c2.21 0 4-1.79 4-4v-24c0-2.21-1.79-4-4-4h-16c-2.21 0-4 1.79-4 4v24c0 2.21 1.79 4 4 4h16Zm-4.25 12h-34v6h34v-6Zm-30.75-38c-4.64 0-7.28 3.73-7.28 10s2.64 10 7.28 10c4.64 0 7.28-3.73 7.28-10s-2.65-10-7.28-10Zm0 15.78c-1.74 0-2.7-2.07-2.7-5.83 0-3.76 1-5.83 2.7-5.83 1.7 0 2.7 2.11 2.7 5.83s-.97 5.83-2.7 5.83Zm19.72-5.78c0-6.27 2.64-10 7.28-10 4.63 0 7.28 3.73 7.28 10s-2.64 10-7.28 10c-4.64 0-7.28-3.73-7.28-10Zm4.58-.05c0 3.76.96 5.83 2.7 5.83 1.73 0 2.7-2.11 2.7-5.83s-1-5.83-2.7-5.83c-1.7 0-2.7 2.07-2.7 5.83Z"></path>`,
        n;
    return {
        c() {
            t = ee("svg"), r = new Pe(!0), this.h()
        },
        l(l) {
            t = te(l, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var o = V(t);
            r = Be(o, !0), o.forEach(g), this.h()
        },
        h() {
            r.a = null, y(t, "fill", "currentColor"), y(t, "viewBox", "0 0 64 64"), y(t, "class", n = "svg-icon " + i[2]), y(t, "style", i[0])
        },
        m(l, o) {
            b(l, t, o), r.m(e, t)
        },
        p(l, [o]) {
            o & 2 && e !== (e = ` <title>${l[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M0 49.5v-46h64v46H0Zm26.5-7c2.21 0 4-1.79 4-4v-24c0-2.21-1.79-4-4-4h-16c-2.21 0-4 1.79-4 4v24c0 2.21 1.79 4 4 4h16Zm27 0c2.21 0 4-1.79 4-4v-24c0-2.21-1.79-4-4-4h-16c-2.21 0-4 1.79-4 4v24c0 2.21 1.79 4 4 4h16Zm-4.25 12h-34v6h34v-6Zm-30.75-38c-4.64 0-7.28 3.73-7.28 10s2.64 10 7.28 10c4.64 0 7.28-3.73 7.28-10s-2.65-10-7.28-10Zm0 15.78c-1.74 0-2.7-2.07-2.7-5.83 0-3.76 1-5.83 2.7-5.83 1.7 0 2.7 2.11 2.7 5.83s-.97 5.83-2.7 5.83Zm19.72-5.78c0-6.27 2.64-10 7.28-10 4.63 0 7.28 3.73 7.28 10s-2.64 10-7.28 10c-4.64 0-7.28-3.73-7.28-10Zm4.58-.05c0 3.76.96 5.83 2.7 5.83 1.73 0 2.7-2.11 2.7-5.83s-1-5.83-2.7-5.83c-1.7 0-2.7 2.07-2.7 5.83Z"></path>`) && r.p(e), o & 4 && n !== (n = "svg-icon " + l[2]) && y(t, "class", n), o & 1 && y(t, "style", l[0])
        },
        i: j,
        o: j,
        d(l) {
            l && g(t)
        }
    }
}

function ze(i, t, r) {
    let {
        style: e = ""
    } = t, {
        alt: n = ""
    } = t, {
        class: l = ""
    } = t;
    return i.$$set = o => {
        "style" in o && r(0, e = o.style), "alt" in o && r(1, n = o.alt), "class" in o && r(2, l = o.class)
    }, [e, n, l]
}
class Ke extends U {
    constructor(t) {
        super(), q(this, t, ze, Ge, H, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}

function je(i) {
    let t, r, e, n;
    return {
        c() {
            t = ee("svg"), r = ee("circle"), e = ee("circle"), this.h()
        },
        l(l) {
            t = te(l, "svg", {
                height: !0,
                width: !0,
                viewBox: !0,
                class: !0
            });
            var o = V(t);
            r = te(o, "circle", {
                r: !0,
                cx: !0,
                cy: !0,
                fill: !0
            }), V(r).forEach(g), e = te(o, "circle", {
                r: !0,
                cx: !0,
                cy: !0,
                fill: !0,
                stroke: !0,
                "stroke-width": !0,
                "stroke-dasharray": !0,
                transform: !0
            }), V(e).forEach(g), o.forEach(g), this.h()
        },
        h() {
            y(r, "r", G / 2), y(r, "cx", G / 2), y(r, "cy", G / 2), y(r, "fill", i[1]), y(e, "r", G / 4), y(e, "cx", G / 2), y(e, "cy", G / 2), y(e, "fill", "transparent"), y(e, "stroke", i[2]), y(e, "stroke-width", G / 2 + .5), y(e, "stroke-dasharray", n = "calc(" + i[0] + " * 31.4 / 100) 31.4"), y(e, "transform", "rotate(-90) translate(-" + G + ")"), y(t, "height", G * 2), y(t, "width", G * 2), y(t, "viewBox", "0 0 " + G + " " + G), y(t, "class", "svelte-l8nfzs")
        },
        m(l, o) {
            b(l, t, o), F(t, r), F(t, e)
        },
        p(l, [o]) {
            o & 2 && y(r, "fill", l[1]), o & 4 && y(e, "stroke", l[2]), o & 1 && n !== (n = "calc(" + l[0] + " * 31.4 / 100) 31.4") && y(e, "stroke-dasharray", n)
        },
        i: j,
        o: j,
        d(l) {
            l && g(t)
        }
    }
}
let G = 20;

function Je(i, t, r) {
    let {
        percent: e
    } = t, {
        background: n
    } = t, {
        foreground: l
    } = t;
    return i.$$set = o => {
        "percent" in o && r(0, e = o.percent), "background" in o && r(1, n = o.background), "foreground" in o && r(2, l = o.foreground)
    }, [e, n, l]
}
class Qe extends U {
    constructor(t) {
        super(), q(this, t, Je, je, H, {
            percent: 0,
            background: 1,
            foreground: 2
        })
    }
}
const K = {
    live: D._("Live"),
    ended: D._("Ended"),
    notStarted: D._("Not Started"),
    aboutToStart: D._("About to start"),
    startsAt: D._("Starts"),
    noMarkets: D._("No Markets Available"),
    scores: D._("Scores"),
    liveStream: D._("Live Stream"),
    liveStreamComingSoon: D._("Available soon"),
    matchTracker: D._("Match Tracker")
};

function Xe(i) {
    let t, r, e, n = i[5]._(K.startsAt) + "",
        l, o, s, a;
    return t = new Qe({
        props: {
            background: "var(--blue-300)",
            foreground: "var(--blue-600)",
            percent: i[2]
        }
    }), s = new Oe({
        props: {
            value: i[6]
        }
    }), {
        c() {
            v(t.$$.fragment), r = O(), e = P("span"), l = N(n), o = O(), v(s.$$.fragment)
        },
        l(f) {
            k(t.$$.fragment, f), r = L(f), e = B(f, "SPAN", {});
            var u = V(e);
            l = M(u, n), o = L(u), k(s.$$.fragment, u), u.forEach(g)
        },
        m(f, u) {
            S(t, f, u), b(f, r, u), b(f, e, u), F(e, l), F(e, o), S(s, e, null), a = !0
        },
        p(f, u) {
            const d = {};
            u & 4 && (d.percent = f[2]), t.$set(d), (!a || u & 32) && n !== (n = f[5]._(K.startsAt) + "") && C(l, n)
        },
        i(f) {
            a || (m(t.$$.fragment, f), m(s.$$.fragment, f), a = !0)
        },
        o(f) {
            _(t.$$.fragment, f), _(s.$$.fragment, f), a = !1
        },
        d(f) {
            f && (g(r), g(e)), w(t, f), w(s)
        }
    }
}

function Ye(i) {
    let t, r = i[5]._(K.aboutToStart) + "",
        e;
    return {
        c() {
            t = P("span"), e = N(r)
        },
        l(n) {
            t = B(n, "SPAN", {});
            var l = V(t);
            e = M(l, r), l.forEach(g)
        },
        m(n, l) {
            b(n, t, l), F(t, e)
        },
        p(n, l) {
            l & 32 && r !== (r = n[5]._(K.aboutToStart) + "") && C(e, r)
        },
        i: j,
        o: j,
        d(n) {
            n && g(t)
        }
    }
}

function We(i) {
    var o;
    let t, r, e, n = i[1] && me(i),
        l = ((o = i[0].data) == null ? void 0 : o.__typename) !== "SportFixtureDataOutright" && i[7] && _e(i);
    return {
        c() {
            t = P("p"), n && n.c(), r = O(), l && l.c(), this.h()
        },
        l(s) {
            t = B(s, "P", {
                class: !0
            });
            var a = V(t);
            n && n.l(a), r = L(a), l && l.l(a), a.forEach(g), this.h()
        },
        h() {
            y(t, "class", "time svelte-1k0nl59")
        },
        m(s, a) {
            b(s, t, a), n && n.m(t, null), F(t, r), l && l.m(t, null), e = !0
        },
        p(s, a) {
            var f;
            s[1] ? n ? n.p(s, a) : (n = me(s), n.c(), n.m(t, r)) : n && (n.d(1), n = null), ((f = s[0].data) == null ? void 0 : f.__typename) !== "SportFixtureDataOutright" && s[7] ? l ? (l.p(s, a), a & 1 && m(l, 1)) : (l = _e(s), l.c(), m(l, 1), l.m(t, null)) : l && (A(), _(l, 1, 1, () => {
                l = null
            }), I())
        },
        i(s) {
            e || (m(l), e = !0)
        },
        o(s) {
            _(l), e = !1
        },
        d(s) {
            s && g(t), n && n.d(), l && l.d()
        }
    }
}

function me(i) {
    let t;

    function r(l, o) {
        return l[7] ? et : xe
    }
    let n = r(i)(i);
    return {
        c() {
            n.c(), t = T()
        },
        l(l) {
            n.l(l), t = T()
        },
        m(l, o) {
            n.m(l, o), b(l, t, o)
        },
        p(l, o) {
            n.p(l, o)
        },
        d(l) {
            l && g(t), n.d(l)
        }
    }
}

function xe(i) {
    let t;
    return {
        c() {
            t = N("Invalid startTime")
        },
        l(r) {
            t = M(r, "Invalid startTime")
        },
        m(r, e) {
            b(r, t, e)
        },
        p: j,
        d(r) {
            r && g(t)
        }
    }
}

function et(i) {
    var e;
    let t = i[5].date(i[7], {
            weekday: "short",
            day: "2-digit",
            month: "short",
            year: ((e = i[0].data) == null ? void 0 : e.__typename) === "SportFixtureDataOutright" ? "numeric" : void 0
        }) + "",
        r;
    return {
        c() {
            r = N(t)
        },
        l(n) {
            r = M(n, t)
        },
        m(n, l) {
            b(n, r, l)
        },
        p(n, l) {
            var o;
            l & 33 && t !== (t = n[5].date(n[7], {
                weekday: "short",
                day: "2-digit",
                month: "short",
                year: ((o = n[0].data) == null ? void 0 : o.__typename) === "SportFixtureDataOutright" ? "numeric" : void 0
            }) + "") && C(r, t)
        },
        d(n) {
            n && g(r)
        }
    }
}

function _e(i) {
    let t, r;
    return t = new Le({
        props: {
            value: i[7]
        }
    }), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p: j,
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function tt(i) {
    let t, r, e, n;
    const l = [We, Ye, Xe],
        o = [];

    function s(a, f) {
        return a[3] ? 0 : a[4] ? 1 : a[2] && a[6] ? 2 : -1
    }
    return ~(t = s(i)) && (r = o[t] = l[t](i)), {
        c() {
            r && r.c(), e = T()
        },
        l(a) {
            r && r.l(a), e = T()
        },
        m(a, f) {
            ~t && o[t].m(a, f), b(a, e, f), n = !0
        },
        p(a, [f]) {
            let u = t;
            t = s(a), t === u ? ~t && o[t].p(a, f) : (r && (A(), _(o[u], 1, 1, () => {
                o[u] = null
            }), I()), ~t ? (r = o[t], r ? r.p(a, f) : (r = o[t] = l[t](a), r.c()), m(r, 1), r.m(e.parentNode, e)) : r = null)
        },
        i(a) {
            n || (m(r), n = !0)
        },
        o(a) {
            _(r), n = !1
        },
        d(a) {
            a && g(e), ~t && o[t].d(a)
        }
    }
}

function rt(i, t, r) {
    var c, p;
    let e, n, l, o, s;
    z(i, Y, $ => r(5, s = $));
    let {
        fixture: a
    } = t, {
        showFullDate: f
    } = t;
    const u = ((c = a.data) == null ? void 0 : c.__typename) === "SportFixtureDataMatch" ? a.data.startTime : ((p = a.data) == null ? void 0 : p.__typename) === "SportFixtureDataOutright" ? a.data.endTime : void 0,
        d = u ? new Date(u).getTime() : void 0;
    let h = new Date().getTime();
    return Ce(() => {
        let $ = setInterval(() => {
            r(8, h = new Date().getTime())
        }, Ze);
        return () => {
            clearInterval($)
        }
    }), i.$$set = $ => {
        "fixture" in $ && r(0, a = $.fixture), "showFullDate" in $ && r(1, f = $.showFullDate)
    }, i.$$.update = () => {
        var $;
        i.$$.dirty & 256 && r(9, e = d ? d - h : void 0), i.$$.dirty & 512 && r(4, n = e ? e < 0 : !1), i.$$.dirty & 513 && r(3, l = e && e > fe || (($ = a.data) == null ? void 0 : $.__typename) === "SportFixtureDataOutright"), i.$$.dirty & 512 && r(2, o = e ? Math.floor((1 - e / fe) * 100) : void 0)
    }, [a, f, o, l, n, s, u, d, h, e]
}
class nt extends U {
    constructor(t) {
        super(), q(this, t, rt, tt, H, {
            fixture: 0,
            showFullDate: 1
        })
    }
}

function de(i) {
    let t, r;
    return {
        c() {
            t = P("span"), r = N(i[0]), this.h()
        },
        l(e) {
            t = B(e, "SPAN", {
                class: !0
            });
            var n = V(t);
            r = M(n, i[0]), n.forEach(g), this.h()
        },
        h() {
            y(t, "class", "prop-value svelte-lsujo")
        },
        m(e, n) {
            b(e, t, n), F(t, r)
        },
        p(e, n) {
            n & 1 && C(r, e[0])
        },
        d(e) {
            e && g(t)
        }
    }
}

function lt(i) {
    let t, r = i[0] !== void 0 && de(i);
    return {
        c() {
            r && r.c(), t = T()
        },
        l(e) {
            r && r.l(e), t = T()
        },
        m(e, n) {
            r && r.m(e, n), b(e, t, n)
        },
        p(e, [n]) {
            e[0] !== void 0 ? r ? r.p(e, n) : (r = de(e), r.c(), r.m(t.parentNode, t)) : r && (r.d(1), r = null)
        },
        i: j,
        o: j,
        d(e) {
            e && g(t), r && r.d(e)
        }
    }
}

function it(i, t, r) {
    let {
        propValue: e = void 0
    } = t;
    return i.$$set = n => {
        "propValue" in n && r(0, e = n.propValue)
    }, [e]
}
class Me extends U {
    constructor(t) {
        super(), q(this, t, it, lt, H, {
            propValue: 0
        })
    }
}

function at(i) {
    let t, r, e;
    return {
        c() {
            t = N(i[1]), r = N("-"), e = N(i[2])
        },
        l(n) {
            t = M(n, i[1]), r = M(n, "-"), e = M(n, i[2])
        },
        m(n, l) {
            b(n, t, l), b(n, r, l), b(n, e, l)
        },
        p(n, l) {
            l & 2 && C(t, n[1]), l & 4 && C(e, n[2])
        },
        d(n) {
            n && (g(t), g(r), g(e))
        }
    }
}

function ot(i) {
    let t, r;
    return t = new qe({
        props: {
            variant: i[0],
            weight: "semibold",
            $$slots: {
                default: [at]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, [n]) {
            const l = {};
            n & 1 && (l.variant = e[0]), n & 14 && (l.$$scope = {
                dirty: n,
                ctx: e
            }), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function st(i, t, r) {
    let {
        variant: e = "subtle"
    } = t, {
        home: n
    } = t, {
        away: l
    } = t;
    return i.$$set = o => {
        "variant" in o && r(0, e = o.variant), "home" in o && r(1, n = o.home), "away" in o && r(2, l = o.away)
    }, [e, n, l]
}
class ft extends U {
    constructor(t) {
        super(), q(this, t, st, ot, H, {
            variant: 0,
            home: 1,
            away: 2
        })
    }
}

function pe(i, t, r) {
    const e = i.slice();
    return e[6] = t[r], e[8] = r, e
}

function $e(i) {
    let t, r = [],
        e = new Map,
        n, l = ce(i[0]);
    const o = s => s[8];
    for (let s = 0; s < l.length; s += 1) {
        let a = pe(i, l, s),
            f = o(a);
        e.set(f, r[s] = ge(f, a))
    }
    return {
        c() {
            t = P("div");
            for (let s = 0; s < r.length; s += 1) r[s].c();
            this.h()
        },
        l(s) {
            t = B(s, "DIV", {
                class: !0
            });
            var a = V(t);
            for (let f = 0; f < r.length; f += 1) r[f].l(a);
            a.forEach(g), this.h()
        },
        h() {
            y(t, "class", "fixture-score svelte-xadbix")
        },
        m(s, a) {
            b(s, t, a);
            for (let f = 0; f < r.length; f += 1) r[f] && r[f].m(t, null);
            n = !0
        },
        p(s, a) {
            a & 1 && (l = ce(s[0]), A(), r = He(r, a, o, 1, s, l, e, t, Ue, ge, null, pe), I())
        },
        i(s) {
            if (!n) {
                for (let a = 0; a < l.length; a += 1) m(r[a]);
                n = !0
            }
        },
        o(s) {
            for (let a = 0; a < r.length; a += 1) _(r[a]);
            n = !1
        },
        d(s) {
            s && g(t);
            for (let a = 0; a < r.length; a += 1) r[a].d()
        }
    }
}

function he(i) {
    let t, r;
    return t = new ft({
        props: {
            variant: i[8] + 1 === i[0].length ? "warn" : "subtle",
            home: i[6].home,
            away: i[6].away
        }
    }), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const l = {};
            n & 1 && (l.variant = e[8] + 1 === e[0].length ? "warn" : "subtle"), n & 1 && (l.home = e[6].home), n & 1 && (l.away = e[6].away), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function ge(i, t) {
    let r, e, n, l = t[6].home !== null && t[6].away !== null && he(t);
    return {
        key: i,
        first: null,
        c() {
            r = T(), l && l.c(), e = T(), this.h()
        },
        l(o) {
            r = T(), l && l.l(o), e = T(), this.h()
        },
        h() {
            this.first = r
        },
        m(o, s) {
            b(o, r, s), l && l.m(o, s), b(o, e, s), n = !0
        },
        p(o, s) {
            t = o, t[6].home !== null && t[6].away !== null ? l ? (l.p(t, s), s & 1 && m(l, 1)) : (l = he(t), l.c(), m(l, 1), l.m(e.parentNode, e)) : l && (A(), _(l, 1, 1, () => {
                l = null
            }), I())
        },
        i(o) {
            n || (m(l), n = !0)
        },
        o(o) {
            _(l), n = !1
        },
        d(o) {
            o && (g(r), g(e)), l && l.d(o)
        }
    }
}

function ut(i) {
    let t, r, e = i[0].length !== 0 && $e(i);
    return {
        c() {
            e && e.c(), t = T()
        },
        l(n) {
            e && e.l(n), t = T()
        },
        m(n, l) {
            e && e.m(n, l), b(n, t, l), r = !0
        },
        p(n, [l]) {
            n[0].length !== 0 ? e ? (e.p(n, l), l & 1 && m(e, 1)) : (e = $e(n), e.c(), m(e, 1), e.m(t.parentNode, t)) : e && (A(), _(e, 1, 1, () => {
                e = null
            }), I())
        },
        i(n) {
            r || (m(e), r = !0)
        },
        o(n) {
            _(e), r = !1
        },
        d(n) {
            n && g(t), e && e.d(n)
        }
    }
}

function ct(i, t, r) {
    let e, n, l, o, {
            fixture: s
        } = t,
        {
            hidePeriodScores: a = !1
        } = t;
    return i.$$set = f => {
        "fixture" in f && r(1, s = f.fixture), "hidePeriodScores" in f && r(2, a = f.hidePeriodScores)
    }, i.$$.update = () => {
        var f, u, d, h;
        i.$$.dirty & 2 && r(5, e = W(s.tournament.category.sport.slug, "scoring").preview), i.$$.dirty & 38 && r(4, n = e === "periods" && !a && ((f = s == null ? void 0 : s.eventStatus) != null && f.periodScores) && ((u = s == null ? void 0 : s.eventStatus) == null ? void 0 : u.periodScores.length) > 0 ? s.eventStatus.periodScores[s.eventStatus.periodScores.length - 1] : void 0), i.$$.dirty & 2 && r(3, l = ((d = s == null ? void 0 : s.eventStatus) == null ? void 0 : d.homeScore) !== void 0 && ((h = s == null ? void 0 : s.eventStatus) == null ? void 0 : h.awayScore) !== void 0 ? {
            home: s.eventStatus.homeScore,
            away: s.eventStatus.awayScore
        } : void 0), i.$$.dirty & 26 && r(0, o = [...n ? [{
            home: (() => {
                var c, p, $, E, Z;
                return ((c = s.eventStatus) == null ? void 0 : c.__typename) === "EsportFixtureEventStatus" ? (($ = (p = s.eventStatus) == null ? void 0 : p.scoreboard) == null ? void 0 : $.homeKills) ? ? ((Z = (E = s.eventStatus) == null ? void 0 : E.scoreboard) == null ? void 0 : Z.homeWonRounds) : n.homeScore ? ? 0
            })(),
            away: (() => {
                var c, p, $, E, Z;
                return ((c = s.eventStatus) == null ? void 0 : c.__typename) === "EsportFixtureEventStatus" ? (($ = (p = s.eventStatus) == null ? void 0 : p.scoreboard) == null ? void 0 : $.awayKills) ? ? ((Z = (E = s.eventStatus) == null ? void 0 : E.scoreboard) == null ? void 0 : Z.awayWonRounds) : n.awayScore ? ? 0
            })()
        }] : [], ...l ? [{
            home: l.home,
            away: l.away
        }] : []])
    }, [o, s, a, l, n, e]
}
class De extends U {
    constructor(t) {
        super(), q(this, t, ct, ut, H, {
            fixture: 1,
            hidePeriodScores: 2
        })
    }
}

function mt(i) {
    let t = i[5]._(K.live) + "",
        r;
    return {
        c() {
            r = N(t)
        },
        l(e) {
            r = M(e, t)
        },
        m(e, n) {
            b(e, r, n)
        },
        p(e, n) {
            n & 32 && t !== (t = e[5]._(K.live) + "") && C(r, t)
        },
        d(e) {
            e && g(r)
        }
    }
}

function be(i) {
    let t, r;
    return t = new Re({
        props: {
            clock: i[3],
            sport: i[0].tournament.category.sport.slug
        }
    }), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const l = {};
            n & 8 && (l.clock = e[3]), n & 1 && (l.sport = e[0].tournament.category.sport.slug), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function ve(i) {
    let t, r, e, n;
    const l = [dt, _t],
        o = [];

    function s(a, f) {
        return a[2] !== void 0 ? 0 : 1
    }
    return t = s(i), r = o[t] = l[t](i), {
        c() {
            r.c(), e = T()
        },
        l(a) {
            r.l(a), e = T()
        },
        m(a, f) {
            o[t].m(a, f), b(a, e, f), n = !0
        },
        p(a, f) {
            let u = t;
            t = s(a), t === u ? o[t].p(a, f) : (A(), _(o[u], 1, 1, () => {
                o[u] = null
            }), I(), r = o[t], r ? r.p(a, f) : (r = o[t] = l[t](a), r.c()), m(r, 1), r.m(e.parentNode, e))
        },
        i(a) {
            n || (m(r), n = !0)
        },
        o(a) {
            _(r), n = !1
        },
        d(a) {
            a && g(e), o[t].d(a)
        }
    }
}

function _t(i) {
    let t, r;
    return t = new De({
        props: {
            fixture: i[0]
        }
    }), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const l = {};
            n & 1 && (l.fixture = e[0]), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function dt(i) {
    let t, r;
    return t = new Me({
        props: {
            propValue: i[2]
        }
    }), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const l = {};
            n & 4 && (l.propValue = e[2]), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function pt(i) {
    var d, h;
    let t, r, e, n, l, o, s, a;
    t = new ae({
        props: {
            size: "sm",
            variant: "live",
            $$slots: {
                default: [mt]
            },
            $$scope: {
                ctx: i
            }
        }
    });
    let f = (((d = i[3]) == null ? void 0 : d.remainingTime) || ((h = i[3]) == null ? void 0 : h.matchTime)) && be(i),
        u = i[1] && ve(i);
    return {
        c() {
            v(t.$$.fragment), r = O(), f && f.c(), e = O(), n = P("span"), l = N(i[4]), o = O(), u && u.c(), s = T()
        },
        l(c) {
            k(t.$$.fragment, c), r = L(c), f && f.l(c), e = L(c), n = B(c, "SPAN", {});
            var p = V(n);
            l = M(p, i[4]), p.forEach(g), o = L(c), u && u.l(c), s = T()
        },
        m(c, p) {
            S(t, c, p), b(c, r, p), f && f.m(c, p), b(c, e, p), b(c, n, p), F(n, l), b(c, o, p), u && u.m(c, p), b(c, s, p), a = !0
        },
        p(c, [p]) {
            var E, Z;
            const $ = {};
            p & 288 && ($.$$scope = {
                dirty: p,
                ctx: c
            }), t.$set($), (E = c[3]) != null && E.remainingTime || (Z = c[3]) != null && Z.matchTime ? f ? (f.p(c, p), p & 8 && m(f, 1)) : (f = be(c), f.c(), m(f, 1), f.m(e.parentNode, e)) : f && (A(), _(f, 1, 1, () => {
                f = null
            }), I()), (!a || p & 16) && C(l, c[4]), c[1] ? u ? (u.p(c, p), p & 2 && m(u, 1)) : (u = ve(c), u.c(), m(u, 1), u.m(s.parentNode, s)) : u && (A(), _(u, 1, 1, () => {
                u = null
            }), I())
        },
        i(c) {
            a || (m(t.$$.fragment, c), m(f), m(u), a = !0)
        },
        o(c) {
            _(t.$$.fragment, c), _(f), _(u), a = !1
        },
        d(c) {
            c && (g(r), g(e), g(n), g(o), g(s)), w(t, c), f && f.d(c), u && u.d(c)
        }
    }
}

function $t(i, t, r) {
    let e, n, l, o, s;
    z(i, Y, d => r(5, s = d));
    let {
        fixture: a
    } = t, {
        stacked: f = !1
    } = t, {
        propValue: u = void 0
    } = t;
    return i.$$set = d => {
        "fixture" in d && r(0, a = d.fixture), "stacked" in d && r(1, f = d.stacked), "propValue" in d && r(2, u = d.propValue)
    }, i.$$.update = () => {
        var d, h, c, p, $, E;
        i.$$.dirty & 1 && r(7, e = (d = a == null ? void 0 : a.eventStatus) == null ? void 0 : d.periodScores), i.$$.dirty & 128 && r(6, n = e && e.length !== 0 ? e[e.length - 1].matchStatus : ""), i.$$.dirty & 65 && r(4, l = ((h = a == null ? void 0 : a.eventStatus) == null ? void 0 : h.matchStatus) || n), i.$$.dirty & 1 && r(3, o = a.provider === ie.betradar ? a.eventStatus && "clock" in a.eventStatus ? {
            matchTime: (c = a.eventStatus.clock) == null ? void 0 : c.matchTime,
            remainingTime: (p = a.eventStatus.clock) == null ? void 0 : p.remainingTime
        } : null : a.eventStatus && "scoreboard" in a.eventStatus ? {
            matchTime: ($ = a.eventStatus.scoreboard) == null ? void 0 : $.gameTime,
            remainingTime: (E = a.eventStatus.scoreboard) == null ? void 0 : E.remainingGameTime
        } : null)
    }, [a, f, u, o, l, s, n, e]
}
class ht extends U {
    constructor(t) {
        super(), q(this, t, $t, pt, H, {
            fixture: 0,
            stacked: 1,
            propValue: 2
        })
    }
}

function ke(i) {
    let t, r;
    return t = new ae({
        props: {
            variant: "dark",
            $$slots: {
                default: [gt]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const l = {};
            n & 96 && (l.$$scope = {
                dirty: n,
                ctx: e
            }), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function gt(i) {
    let t = i[5]._(K.ended) + "",
        r;
    return {
        c() {
            r = N(t)
        },
        l(e) {
            r = M(e, t)
        },
        m(e, n) {
            b(e, r, n)
        },
        p(e, n) {
            n & 32 && t !== (t = e[5]._(K.ended) + "") && C(r, t)
        },
        d(e) {
            e && g(r)
        }
    }
}

function Se(i) {
    let t, r, e, n;
    const l = [vt, bt],
        o = [];

    function s(a, f) {
        return a[3] !== void 0 ? 0 : 1
    }
    return t = s(i), r = o[t] = l[t](i), {
        c() {
            r.c(), e = T()
        },
        l(a) {
            r.l(a), e = T()
        },
        m(a, f) {
            o[t].m(a, f), b(a, e, f), n = !0
        },
        p(a, f) {
            let u = t;
            t = s(a), t === u ? o[t].p(a, f) : (A(), _(o[u], 1, 1, () => {
                o[u] = null
            }), I(), r = o[t], r ? r.p(a, f) : (r = o[t] = l[t](a), r.c()), m(r, 1), r.m(e.parentNode, e))
        },
        i(a) {
            n || (m(r), n = !0)
        },
        o(a) {
            _(r), n = !1
        },
        d(a) {
            a && g(e), o[t].d(a)
        }
    }
}

function bt(i) {
    let t, r;
    return t = new De({
        props: {
            fixture: i[0],
            hidePeriodScores: !0
        }
    }), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const l = {};
            n & 1 && (l.fixture = e[0]), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function vt(i) {
    let t, r;
    return t = new Me({
        props: {
            propValue: i[3]
        }
    }), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const l = {};
            n & 8 && (l.propValue = e[3]), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function kt(i) {
    let t, r = i[2] && i[4] && !W(i[4], "hideResultsInFixtureStatus"),
        e, n, l = !i[1] && ke(i),
        o = r && Se(i);
    return {
        c() {
            l && l.c(), t = O(), o && o.c(), e = T()
        },
        l(s) {
            l && l.l(s), t = L(s), o && o.l(s), e = T()
        },
        m(s, a) {
            l && l.m(s, a), b(s, t, a), o && o.m(s, a), b(s, e, a), n = !0
        },
        p(s, [a]) {
            s[1] ? l && (A(), _(l, 1, 1, () => {
                l = null
            }), I()) : l ? (l.p(s, a), a & 2 && m(l, 1)) : (l = ke(s), l.c(), m(l, 1), l.m(t.parentNode, t)), a & 20 && (r = s[2] && s[4] && !W(s[4], "hideResultsInFixtureStatus")), r ? o ? (o.p(s, a), a & 20 && m(o, 1)) : (o = Se(s), o.c(), m(o, 1), o.m(e.parentNode, e)) : o && (A(), _(o, 1, 1, () => {
                o = null
            }), I())
        },
        i(s) {
            n || (m(l), m(o), n = !0)
        },
        o(s) {
            _(l), _(o), n = !1
        },
        d(s) {
            s && (g(t), g(e)), l && l.d(s), o && o.d(s)
        }
    }
}

function St(i, t, r) {
    let e, n;
    z(i, Y, f => r(5, n = f));
    let {
        fixture: l
    } = t, {
        hideEnded: o
    } = t, {
        stacked: s = !1
    } = t, {
        propValue: a = void 0
    } = t;
    return i.$$set = f => {
        "fixture" in f && r(0, l = f.fixture), "hideEnded" in f && r(1, o = f.hideEnded), "stacked" in f && r(2, s = f.stacked), "propValue" in f && r(3, a = f.propValue)
    }, i.$$.update = () => {
        i.$$.dirty & 1 && r(4, e = l.tournament.category.sport.slug)
    }, [l, o, s, a, e, n]
}
class wt extends U {
    constructor(t) {
        super(), q(this, t, St, kt, H, {
            fixture: 0,
            hideEnded: 1,
            stacked: 2,
            propValue: 3
        })
    }
}

function yt(i) {
    let t = i[0]._(K.noMarkets) + "",
        r;
    return {
        c() {
            r = N(t)
        },
        l(e) {
            r = M(e, t)
        },
        m(e, n) {
            b(e, r, n)
        },
        p(e, n) {
            n & 1 && t !== (t = e[0]._(K.noMarkets) + "") && C(r, t)
        },
        d(e) {
            e && g(r)
        }
    }
}

function Et(i) {
    let t, r;
    return t = new ae({
        props: {
            variant: "dark",
            $$slots: {
                default: [yt]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, [n]) {
            const l = {};
            n & 3 && (l.$$scope = {
                dirty: n,
                ctx: e
            }), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function Tt(i, t, r) {
    let e;
    return z(i, Y, n => r(0, e = n)), [e]
}
class At extends U {
    constructor(t) {
        super(), q(this, t, Tt, Et, H, {})
    }
}
const R = {
    noAvailable: D._("No Available Markets"),
    seeAll: D._("See All Markets"),
    winner: D._("Winner"),
    suspended: D._("Suspended"),
    liveStream: D._("Live Stream"),
    liveStreamComingSoon: D._("Available soon"),
    matchStats: D._("Live Stats"),
    matchStatsComingSoon: D._("Pre match available in fixture")
};

function we(i) {
    let t, r;
    return t = new Q({
        props: {
            $$slots: {
                tooltip: [Vt],
                default: [Ft]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const l = {};
            n & 2061 && (l.$$scope = {
                dirty: n,
                ctx: e
            }), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function It(i) {
    let t, r;
    return t = new oe({}), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function Ft(i) {
    let t, r;
    return t = new X({
        props: {
            variant: "subtle-link",
            disabled: i[3],
            "data-analytics": "sports-livestats-button",
            $$slots: {
                default: [It]
            },
            $$scope: {
                ctx: i
            }
        }
    }), t.$on("click", i[9]), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const l = {};
            n & 8 && (l.disabled = e[3]), n & 2048 && (l.$$scope = {
                dirty: n,
                ctx: e
            }), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function Vt(i) {
    let t, r = i[2]._(R.matchStats) + "",
        e;
    return {
        c() {
            t = P("span"), e = N(r), this.h()
        },
        l(n) {
            t = B(n, "SPAN", {
                slot: !0
            });
            var l = V(t);
            e = M(l, r), l.forEach(g), this.h()
        },
        h() {
            y(t, "slot", "tooltip")
        },
        m(n, l) {
            b(n, t, l), F(t, e)
        },
        p(n, l) {
            l & 4 && r !== (r = n[2]._(R.matchStats) + "") && C(e, r)
        },
        d(n) {
            n && g(t)
        }
    }
}

function Nt(i) {
    let t, r;
    return t = new Q({
        props: {
            $$slots: {
                tooltip: [Bt],
                default: [Pt]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const l = {};
            n & 2052 && (l.$$scope = {
                dirty: n,
                ctx: e
            }), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function Mt(i) {
    let t, r;
    return t = new Q({
        props: {
            $$slots: {
                tooltip: [Ot],
                default: [Zt]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const l = {};
            n & 2069 && (l.$$scope = {
                dirty: n,
                ctx: e
            }), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function Dt(i) {
    let t, r;
    return t = new re({}), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function Pt(i) {
    let t, r;
    return t = new X({
        props: {
            variant: "subtle-link",
            disabled: !0,
            $$slots: {
                default: [Dt]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const l = {};
            n & 2048 && (l.$$scope = {
                dirty: n,
                ctx: e
            }), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function Bt(i) {
    let t, r = i[2]._(R.liveStreamComingSoon) + "",
        e;
    return {
        c() {
            t = P("span"), e = N(r), this.h()
        },
        l(n) {
            t = B(n, "SPAN", {
                slot: !0
            });
            var l = V(t);
            e = M(l, r), l.forEach(g), this.h()
        },
        h() {
            y(t, "slot", "tooltip")
        },
        m(n, l) {
            b(n, t, l), F(t, e)
        },
        p(n, l) {
            l & 4 && r !== (r = n[2]._(R.liveStreamComingSoon) + "") && C(e, r)
        },
        d(n) {
            n && g(t)
        }
    }
}

function Ct(i) {
    let t, r;
    return t = new re({}), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function Zt(i) {
    let t, r;
    return t = new X({
        props: {
            variant: "subtle-link",
            disabled: i[4],
            "data-analytics": "sports-stream-button",
            $$slots: {
                default: [Ct]
            },
            $$scope: {
                ctx: i
            }
        }
    }), t.$on("click", i[10]), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const l = {};
            n & 16 && (l.disabled = e[4]), n & 2048 && (l.$$scope = {
                dirty: n,
                ctx: e
            }), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function Ot(i) {
    let t, r = i[2]._(R.liveStream) + "",
        e;
    return {
        c() {
            t = P("span"), e = N(r), this.h()
        },
        l(n) {
            t = B(n, "SPAN", {
                slot: !0
            });
            var l = V(t);
            e = M(l, r), l.forEach(g), this.h()
        },
        h() {
            y(t, "slot", "tooltip")
        },
        m(n, l) {
            b(n, t, l), F(t, e)
        },
        p(n, l) {
            l & 4 && r !== (r = n[2]._(R.liveStream) + "") && C(e, r)
        },
        d(n) {
            n && g(t)
        }
    }
}

function Lt(i) {
    let t = ue.includes(i[0].tournament.category.sport.slug) && i[5](i[0], i[0].tournament.category.sport.slug),
        r, e, n, l, o, s, a = t && we(i);
    const f = [Mt, Nt],
        u = [];

    function d(h, c) {
        return c & 1 && (e = null), h[1] ? 0 : (e == null && (e = !!W(h[0].tournament.category.sport.slug, "displayStreamComingSoonIcon")), e ? 1 : -1)
    }
    return ~(n = d(i, -1)) && (l = u[n] = f[n](i)), {
        c() {
            a && a.c(), r = O(), l && l.c(), o = T()
        },
        l(h) {
            a && a.l(h), r = L(h), l && l.l(h), o = T()
        },
        m(h, c) {
            a && a.m(h, c), b(h, r, c), ~n && u[n].m(h, c), b(h, o, c), s = !0
        },
        p(h, [c]) {
            c & 1 && (t = ue.includes(h[0].tournament.category.sport.slug) && h[5](h[0], h[0].tournament.category.sport.slug)), t ? a ? (a.p(h, c), c & 1 && m(a, 1)) : (a = we(h), a.c(), m(a, 1), a.m(r.parentNode, r)) : a && (A(), _(a, 1, 1, () => {
                a = null
            }), I());
            let p = n;
            n = d(h, c), n === p ? ~n && u[n].p(h, c) : (l && (A(), _(u[p], 1, 1, () => {
                u[p] = null
            }), I()), ~n ? (l = u[n], l ? l.p(h, c) : (l = u[n] = f[n](h), l.c()), m(l, 1), l.m(o.parentNode, o)) : l = null)
        },
        i(h) {
            s || (m(a), m(l), s = !0)
        },
        o(h) {
            _(a), _(l), s = !1
        },
        d(h) {
            h && (g(r), g(o)), a && a.d(h), ~n && u[n].d(h)
        }
    }
}

function Rt(i, t, r) {
    let e, n, l, o, s;
    z(i, Y, p => r(2, l = p));
    let {
        fixture: a
    } = t;
    const f = (p, $) => {
            var E;
            return $ === "mma" ? !!((E = p.tournament) != null && E.frontRowSeatEvent || p.frontRowSeatFight) : !0
        },
        u = x(J, p => p.some($ => $.id === a.id && $.type === "matchtracker"));
    z(i, u, p => r(3, o = p));
    const d = x(J, p => p.some($ => $.id === a.id && $.type === "live"));
    z(i, d, p => r(4, s = p));
    const h = () => {
            J.add({ ...a,
                type: "matchtracker"
            })
        },
        c = () => {
            J.add({ ...a,
                type: "live"
            })
        };
    return i.$$set = p => {
        "fixture" in p && r(0, a = p.fixture)
    }, i.$$.update = () => {
        i.$$.dirty & 1 && r(8, e = Ne(a)), i.$$.dirty & 256 && r(1, n = e.streamExists)
    }, [a, n, l, o, s, f, u, d, e, h, c]
}
class Ht extends U {
    constructor(t) {
        super(), q(this, t, Rt, Lt, H, {
            fixture: 0
        })
    }
}

function Ut(i) {
    let t, r;
    return t = new Q({
        props: {
            $$slots: {
                tooltip: [Kt],
                default: [zt]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const l = {};
            n & 1037 && (l.$$scope = {
                dirty: n,
                ctx: e
            }), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function qt(i) {
    let t, r;
    return t = new Q({
        props: {
            $$slots: {
                tooltip: [Qt],
                default: [Jt]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const l = {};
            n & 1028 && (l.$$scope = {
                dirty: n,
                ctx: e
            }), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function Gt(i) {
    let t, r;
    return t = new oe({}), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function zt(i) {
    let t, r;
    return t = new X({
        props: {
            variant: "subtle-link",
            disabled: i[3],
            "data-analytics": "sports-livestats-button",
            $$slots: {
                default: [Gt]
            },
            $$scope: {
                ctx: i
            }
        }
    }), t.$on("click", i[8]), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const l = {};
            n & 8 && (l.disabled = e[3]), n & 1024 && (l.$$scope = {
                dirty: n,
                ctx: e
            }), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function Kt(i) {
    let t, r = i[2]._(R.matchStats) + "",
        e;
    return {
        c() {
            t = P("span"), e = N(r), this.h()
        },
        l(n) {
            t = B(n, "SPAN", {
                slot: !0
            });
            var l = V(t);
            e = M(l, r), l.forEach(g), this.h()
        },
        h() {
            y(t, "slot", "tooltip")
        },
        m(n, l) {
            b(n, t, l), F(t, e)
        },
        p(n, l) {
            l & 4 && r !== (r = n[2]._(R.matchStats) + "") && C(e, r)
        },
        d(n) {
            n && g(t)
        }
    }
}

function jt(i) {
    let t, r;
    return t = new oe({}), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function Jt(i) {
    let t, r;
    return t = new X({
        props: {
            disabled: !0,
            $$slots: {
                default: [jt]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const l = {};
            n & 1024 && (l.$$scope = {
                dirty: n,
                ctx: e
            }), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function Qt(i) {
    let t, r = i[2]._(R.matchStatsComingSoon) + "",
        e;
    return {
        c() {
            t = P("span"), e = N(r), this.h()
        },
        l(n) {
            t = B(n, "SPAN", {
                slot: !0
            });
            var l = V(t);
            e = M(l, r), l.forEach(g), this.h()
        },
        h() {
            y(t, "slot", "tooltip")
        },
        m(n, l) {
            b(n, t, l), F(t, e)
        },
        p(n, l) {
            l & 4 && r !== (r = n[2]._(R.matchStatsComingSoon) + "") && C(e, r)
        },
        d(n) {
            n && g(t)
        }
    }
}

function Xt(i) {
    let t, r;
    return t = new Q({
        props: {
            $$slots: {
                tooltip: [er],
                default: [xt]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const l = {};
            n & 1028 && (l.$$scope = {
                dirty: n,
                ctx: e
            }), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function Yt(i) {
    let t, r;
    return t = new Q({
        props: {
            $$slots: {
                tooltip: [nr],
                default: [rr]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const l = {};
            n & 1045 && (l.$$scope = {
                dirty: n,
                ctx: e
            }), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function Wt(i) {
    let t, r;
    return t = new re({}), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function xt(i) {
    let t, r;
    return t = new X({
        props: {
            variant: "subtle-link",
            disabled: !0,
            $$slots: {
                default: [Wt]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const l = {};
            n & 1024 && (l.$$scope = {
                dirty: n,
                ctx: e
            }), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function er(i) {
    let t, r = i[2]._(R.liveStreamComingSoon) + "",
        e;
    return {
        c() {
            t = P("span"), e = N(r), this.h()
        },
        l(n) {
            t = B(n, "SPAN", {
                slot: !0
            });
            var l = V(t);
            e = M(l, r), l.forEach(g), this.h()
        },
        h() {
            y(t, "slot", "tooltip")
        },
        m(n, l) {
            b(n, t, l), F(t, e)
        },
        p(n, l) {
            l & 4 && r !== (r = n[2]._(R.liveStreamComingSoon) + "") && C(e, r)
        },
        d(n) {
            n && g(t)
        }
    }
}

function tr(i) {
    let t, r;
    return t = new re({}), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function rr(i) {
    let t, r;
    return t = new X({
        props: {
            variant: "subtle-link",
            disabled: i[4],
            "data-analytics": "sports-stream-button",
            $$slots: {
                default: [tr]
            },
            $$scope: {
                ctx: i
            }
        }
    }), t.$on("click", i[9]), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const l = {};
            n & 16 && (l.disabled = e[4]), n & 1024 && (l.$$scope = {
                dirty: n,
                ctx: e
            }), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function nr(i) {
    let t, r = i[2]._(R.liveStream) + "",
        e;
    return {
        c() {
            t = P("span"), e = N(r), this.h()
        },
        l(n) {
            t = B(n, "SPAN", {
                slot: !0
            });
            var l = V(t);
            e = M(l, r), l.forEach(g), this.h()
        },
        h() {
            y(t, "slot", "tooltip")
        },
        m(n, l) {
            b(n, t, l), F(t, e)
        },
        p(n, l) {
            l & 4 && r !== (r = n[2]._(R.liveStream) + "") && C(e, r)
        },
        d(n) {
            n && g(t)
        }
    }
}

function lr(i) {
    let t, r, e, n, l, o, s, a;
    const f = [qt, Ut],
        u = [];

    function d($, E) {
        var Z;
        return $[0].status === "active" && $[0].widgetUrl ? 0 : ($[0].status === "live" || $[0].status === "suspended") && ((Z = $[0]) != null && Z.liveWidgetUrl) ? 1 : -1
    }~(t = d(i)) && (r = u[t] = f[t](i));
    const h = [Yt, Xt],
        c = [];

    function p($, E) {
        return E & 1 && (n = null), $[1] ? 0 : (n == null && (n = !!W($[0].tournament.category.sport.slug, "displayStreamComingSoonIcon")), n ? 1 : -1)
    }
    return ~(l = p(i, -1)) && (o = c[l] = h[l](i)), {
        c() {
            r && r.c(), e = O(), o && o.c(), s = T()
        },
        l($) {
            r && r.l($), e = L($), o && o.l($), s = T()
        },
        m($, E) {
            ~t && u[t].m($, E), b($, e, E), ~l && c[l].m($, E), b($, s, E), a = !0
        },
        p($, [E]) {
            let Z = t;
            t = d($), t === Z ? ~t && u[t].p($, E) : (r && (A(), _(u[Z], 1, 1, () => {
                u[Z] = null
            }), I()), ~t ? (r = u[t], r ? r.p($, E) : (r = u[t] = f[t]($), r.c()), m(r, 1), r.m(e.parentNode, e)) : r = null);
            let ne = l;
            l = p($, E), l === ne ? ~l && c[l].p($, E) : (o && (A(), _(c[ne], 1, 1, () => {
                c[ne] = null
            }), I()), ~l ? (o = c[l], o ? o.p($, E) : (o = c[l] = h[l]($), o.c()), m(o, 1), o.m(s.parentNode, s)) : o = null)
        },
        i($) {
            a || (m(r), m(o), a = !0)
        },
        o($) {
            _(r), _(o), a = !1
        },
        d($) {
            $ && (g(e), g(s)), ~t && u[t].d($), ~l && c[l].d($)
        }
    }
}

function ir(i, t, r) {
    let e, n, l, o, s;
    z(i, Y, c => r(2, l = c));
    let {
        fixture: a
    } = t;
    const f = x(J, c => c.some(p => p.id === a.id && p.type === "matchtracker"));
    z(i, f, c => r(3, o = c));
    const u = x(J, c => c.some(p => p.id === a.id && p.type === "live"));
    z(i, u, c => r(4, s = c));
    const d = () => {
            J.add({ ...a,
                type: "matchtracker"
            })
        },
        h = () => {
            J.add({ ...a,
                type: "live"
            })
        };
    return i.$$set = c => {
        "fixture" in c && r(0, a = c.fixture)
    }, i.$$.update = () => {
        i.$$.dirty & 1 && r(7, e = Ne(a)), i.$$.dirty & 128 && r(1, n = e.streamExists)
    }, [a, n, l, o, s, f, u, e, d, h]
}
class ar extends U {
    constructor(t) {
        super(), q(this, t, ir, lr, H, {
            fixture: 0
        })
    }
}

function ye(i) {
    let t, r, e, n;
    const l = [sr, or],
        o = [];

    function s(a, f) {
        var u, d;
        return ((u = a[0]) == null ? void 0 : u.provider) === ie.oddin ? 0 : ((d = a[0]) == null ? void 0 : d.provider) === ie.betradar ? 1 : -1
    }
    return ~(r = s(i)) && (e = o[r] = l[r](i)), {
        c() {
            t = P("div"), e && e.c(), this.h()
        },
        l(a) {
            t = B(a, "DIV", {
                class: !0
            });
            var f = V(t);
            e && e.l(f), f.forEach(g), this.h()
        },
        h() {
            y(t, "class", "options-wrapper svelte-141d72v"), se(t, "stacked", i[1])
        },
        m(a, f) {
            b(a, t, f), ~r && o[r].m(t, null), n = !0
        },
        p(a, f) {
            let u = r;
            r = s(a), r === u ? ~r && o[r].p(a, f) : (e && (A(), _(o[u], 1, 1, () => {
                o[u] = null
            }), I()), ~r ? (e = o[r], e ? e.p(a, f) : (e = o[r] = l[r](a), e.c()), m(e, 1), e.m(t, null)) : e = null), (!n || f & 2) && se(t, "stacked", a[1])
        },
        i(a) {
            n || (m(e), n = !0)
        },
        o(a) {
            _(e), n = !1
        },
        d(a) {
            a && g(t), ~r && o[r].d()
        }
    }
}

function or(i) {
    let t, r;
    return t = new Ht({
        props: {
            fixture: i[0]
        }
    }), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const l = {};
            n & 1 && (l.fixture = e[0]), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function sr(i) {
    let t, r;
    return t = new ar({
        props: {
            fixture: i[0]
        }
    }), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const l = {};
            n & 1 && (l.fixture = e[0]), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function fr(i) {
    var n, l, o;
    let t, r, e = (((n = i[0]) == null ? void 0 : n.status) === "active" || ((l = i[0]) == null ? void 0 : l.status) === "live" || ((o = i[0]) == null ? void 0 : o.status) === "suspended") && ye(i);
    return {
        c() {
            e && e.c(), t = T()
        },
        l(s) {
            e && e.l(s), t = T()
        },
        m(s, a) {
            e && e.m(s, a), b(s, t, a), r = !0
        },
        p(s, [a]) {
            var f, u, d;
            ((f = s[0]) == null ? void 0 : f.status) === "active" || ((u = s[0]) == null ? void 0 : u.status) === "live" || ((d = s[0]) == null ? void 0 : d.status) === "suspended" ? e ? (e.p(s, a), a & 1 && m(e, 1)) : (e = ye(s), e.c(), m(e, 1), e.m(t.parentNode, t)): e && (A(), _(e, 1, 1, () => {
                e = null
            }), I())
        },
        i(s) {
            r || (m(e), r = !0)
        },
        o(s) {
            _(e), r = !1
        },
        d(s) {
            s && g(t), e && e.d(s)
        }
    }
}

function ur(i, t, r) {
    let {
        fixture: e
    } = t, {
        stacked: n = !1
    } = t;
    return i.$$set = l => {
        "fixture" in l && r(0, e = l.fixture), "stacked" in l && r(1, n = l.stacked)
    }, [e, n]
}
class cr extends U {
    constructor(t) {
        super(), q(this, t, ur, fr, H, {
            fixture: 0,
            stacked: 1
        })
    }
}

function mr(i) {
    let t, r;
    return t = new Ke({}), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function _r(i) {
    let t, r;
    return t = new X({
        props: {
            variant: "subtle-link",
            active: i[3],
            $$slots: {
                default: [mr]
            },
            $$scope: {
                ctx: i
            }
        }
    }), t.$on("click", i[5]), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const l = {};
            n & 8 && (l.active = e[3]), n & 64 && (l.$$scope = {
                dirty: n,
                ctx: e
            }), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function dr(i) {
    let t, r = i[2]._(K.scores) + "",
        e;
    return {
        c() {
            t = P("div"), e = N(r), this.h()
        },
        l(n) {
            t = B(n, "DIV", {
                slot: !0
            });
            var l = V(t);
            e = M(l, r), l.forEach(g), this.h()
        },
        h() {
            y(t, "slot", "tooltip")
        },
        m(n, l) {
            b(n, t, l), F(t, e)
        },
        p(n, l) {
            l & 4 && r !== (r = n[2]._(K.scores) + "") && C(e, r)
        },
        d(n) {
            n && g(t)
        }
    }
}

function pr(i) {
    let t, r;
    return t = new Q({
        props: {
            $$slots: {
                tooltip: [dr],
                default: [_r]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, [n]) {
            const l = {};
            n & 79 && (l.$$scope = {
                dirty: n,
                ctx: e
            }), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function $r(i, t, r) {
    let e, n;
    z(i, Y, f => r(2, e = f));
    let {
        betId: l = void 0
    } = t, {
        fixtureId: o
    } = t, s = x(le, f => f.some(u => (u == null ? void 0 : u.fixtureId) === o && (u == null ? void 0 : u.betId) === l));
    z(i, s, f => r(3, n = f));
    const a = () => {
        n ? le.remove({
            fixtureId: o,
            betId: l || ""
        }) : le.add({
            fixtureId: o,
            betId: l || ""
        })
    };
    return i.$$set = f => {
        "betId" in f && r(0, l = f.betId), "fixtureId" in f && r(1, o = f.fixtureId)
    }, [l, o, e, n, s, a]
}
class hr extends U {
    constructor(t) {
        super(), q(this, t, $r, pr, H, {
            betId: 0,
            fixtureId: 1
        })
    }
}

function Ee(i) {
    let t, r;
    return t = new nt({
        props: {
            fixture: i[0],
            showFullDate: i[2]
        }
    }), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const l = {};
            n & 1 && (l.fixture = e[0]), n & 4 && (l.showFullDate = e[2]), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function Te(i) {
    let t, r;
    return t = new ht({
        props: {
            fixture: i[0],
            propValue: i[5],
            stacked: i[1]
        }
    }), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const l = {};
            n & 1 && (l.fixture = e[0]), n & 32 && (l.propValue = e[5]), n & 2 && (l.stacked = e[1]), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function Ae(i) {
    let t, r;
    return t = new wt({
        props: {
            fixture: i[0],
            hideEnded: i[3],
            stacked: i[1],
            propValue: i[5]
        }
    }), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const l = {};
            n & 1 && (l.fixture = e[0]), n & 8 && (l.hideEnded = e[3]), n & 2 && (l.stacked = e[1]), n & 32 && (l.propValue = e[5]), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function Ie(i) {
    let t, r;
    return t = new At({}), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function Fe(i) {
    let t, r, e, n;
    r = new cr({
        props: {
            fixture: i[0],
            stacked: !1
        }
    });
    let l = i[6] && i[7] && Ve(i);
    return {
        c() {
            t = P("div"), v(r.$$.fragment), e = O(), l && l.c(), this.h()
        },
        l(o) {
            t = B(o, "DIV", {
                class: !0
            });
            var s = V(t);
            k(r.$$.fragment, s), e = L(s), l && l.l(s), s.forEach(g), this.h()
        },
        h() {
            y(t, "class", "widget-buttons svelte-19qis73")
        },
        m(o, s) {
            b(o, t, s), S(r, t, null), F(t, e), l && l.m(t, null), n = !0
        },
        p(o, s) {
            const a = {};
            s & 1 && (a.fixture = o[0]), r.$set(a), o[6] && o[7] ? l ? (l.p(o, s), s & 192 && m(l, 1)) : (l = Ve(o), l.c(), m(l, 1), l.m(t, null)) : l && (A(), _(l, 1, 1, () => {
                l = null
            }), I())
        },
        i(o) {
            n || (m(r.$$.fragment, o), m(l), n = !0)
        },
        o(o) {
            _(r.$$.fragment, o), _(l), n = !1
        },
        d(o) {
            o && g(t), w(r), l && l.d()
        }
    }
}

function Ve(i) {
    let t, r;
    return t = new hr({
        props: {
            fixtureId: i[0].id,
            betId: i[6]
        }
    }), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            k(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const l = {};
            n & 1 && (l.fixtureId = e[0].id), n & 64 && (l.betId = e[6]), t.$set(l)
        },
        i(e) {
            r || (m(t.$$.fragment, e), r = !0)
        },
        o(e) {
            _(t.$$.fragment, e), r = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function gr(i) {
    let t, r, e, n, l, o, s, a = i[0].status === "active" && Ee(i),
        f = (i[0].status === "live" || i[0].status === "suspended") && Te(i),
        u = i[0].status === "ended" && Ae(i),
        d = i[0].status === "inactive" && Ie(),
        h = i[4] && i[0] && Fe(i);
    return {
        c() {
            t = P("div"), r = P("div"), a && a.c(), e = O(), f && f.c(), n = O(), u && u.c(), l = O(), d && d.c(), o = O(), h && h.c(), this.h()
        },
        l(c) {
            t = B(c, "DIV", {
                class: !0
            });
            var p = V(t);
            r = B(p, "DIV", {
                class: !0
            });
            var $ = V(r);
            a && a.l($), e = L($), f && f.l($), n = L($), u && u.l($), l = L($), d && d.l($), $.forEach(g), o = L(p), h && h.l(p), p.forEach(g), this.h()
        },
        h() {
            y(r, "class", "fixture-details svelte-19qis73"), y(t, "class", "wrapper svelte-19qis73")
        },
        m(c, p) {
            b(c, t, p), F(t, r), a && a.m(r, null), F(r, e), f && f.m(r, null), F(r, n), u && u.m(r, null), F(r, l), d && d.m(r, null), F(t, o), h && h.m(t, null), s = !0
        },
        p(c, [p]) {
            c[0].status === "active" ? a ? (a.p(c, p), p & 1 && m(a, 1)) : (a = Ee(c), a.c(), m(a, 1), a.m(r, e)) : a && (A(), _(a, 1, 1, () => {
                a = null
            }), I()), c[0].status === "live" || c[0].status === "suspended" ? f ? (f.p(c, p), p & 1 && m(f, 1)) : (f = Te(c), f.c(), m(f, 1), f.m(r, n)) : f && (A(), _(f, 1, 1, () => {
                f = null
            }), I()), c[0].status === "ended" ? u ? (u.p(c, p), p & 1 && m(u, 1)) : (u = Ae(c), u.c(), m(u, 1), u.m(r, l)) : u && (A(), _(u, 1, 1, () => {
                u = null
            }), I()), c[0].status === "inactive" ? d ? p & 1 && m(d, 1) : (d = Ie(), d.c(), m(d, 1), d.m(r, null)) : d && (A(), _(d, 1, 1, () => {
                d = null
            }), I()), c[4] && c[0] ? h ? (h.p(c, p), p & 17 && m(h, 1)) : (h = Fe(c), h.c(), m(h, 1), h.m(t, null)) : h && (A(), _(h, 1, 1, () => {
                h = null
            }), I())
        },
        i(c) {
            s || (m(a), m(f), m(u), m(d), m(h), s = !0)
        },
        o(c) {
            _(a), _(f), _(u), _(d), _(h), s = !1
        },
        d(c) {
            c && g(t), a && a.d(), f && f.d(), u && u.d(), d && d.d(), h && h.d()
        }
    }
}

function br(i, t, r) {
    let {
        fixture: e
    } = t, {
        stacked: n = !1
    } = t, {
        showFullDate: l = !1
    } = t, {
        hideEnded: o = !1
    } = t, {
        isMyBets: s = !1
    } = t, {
        propValue: a = void 0
    } = t, {
        betId: f = void 0
    } = t, {
        displayMatchStatisticsButton: u = !1
    } = t;
    return i.$$set = d => {
        "fixture" in d && r(0, e = d.fixture), "stacked" in d && r(1, n = d.stacked), "showFullDate" in d && r(2, l = d.showFullDate), "hideEnded" in d && r(3, o = d.hideEnded), "isMyBets" in d && r(4, s = d.isMyBets), "propValue" in d && r(5, a = d.propValue), "betId" in d && r(6, f = d.betId), "displayMatchStatisticsButton" in d && r(7, u = d.displayMatchStatisticsButton)
    }, [e, n, l, o, s, a, f, u]
}
class Or extends U {
    constructor(t) {
        super(), q(this, t, br, gr, H, {
            fixture: 0,
            stacked: 1,
            showFullDate: 2,
            hideEnded: 3,
            isMyBets: 4,
            propValue: 5,
            betId: 6,
            displayMatchStatisticsButton: 7
        })
    }
}
export {
    Or as F, cr as a, R as m
};