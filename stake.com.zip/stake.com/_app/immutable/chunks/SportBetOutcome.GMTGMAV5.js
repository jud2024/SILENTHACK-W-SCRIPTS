import {
    s as X,
    e as E,
    O as Z,
    d as T,
    f as w,
    P as x,
    i as b,
    F as v,
    V as m,
    j as y,
    k as D,
    W as ee,
    c as U,
    m as j,
    t as H,
    h as R,
    l as Y
} from "./scheduler.DXu26z7T.js";
import {
    S as te,
    i as se,
    c as $,
    a as B,
    m as N,
    t as p,
    g as G,
    b as g,
    e as J,
    d as z
} from "./index.Dz_MmNB3.js";
import {
    b as ne
} from "./index.lhCIiKC2.js";
import {
    s as q,
    O as ae
} from "./index.A2FRVEtT.js";
import {
    T as K
} from "./index.CTIl3dBv.js";
import {
    T as L
} from "./index.rqxo2ccV.js";
import {
    h as _,
    i as re,
    u as O
} from "./index.B4-7gKq3.js";
import {
    c as le
} from "./clickTransform.BPJZMoSk.js";
const M = {
    suspended: _._("Suspended"),
    settled: _._("Settled"),
    yes: _._("Yes"),
    no: _._("No"),
    odd: _._("Odd"),
    even: _._("Even"),
    over: _._("Over"),
    under: _._("Under"),
    draw: _._("Draw"),
    or: _._("or"),
    hextech: _._("Hextech"),
    chemtech: _._("Chemtech"),
    mountain: _._("Mountain"),
    cloud: _._("Cloud"),
    ocean: _._("Ocean"),
    infernal: _._("Infernal")
};

function ie(a) {
    let t, s;
    return {
        c() {
            t = E("span"), s = H(a[7]), this.h()
        },
        l(e) {
            t = T(e, "SPAN", {
                class: !0
            });
            var n = w(t);
            s = R(n, a[7]), n.forEach(b), this.h()
        },
        h() {
            v(t, "class", "name svelte-1yo4ude"), m(t, "suspended-name", a[4] !== O.active)
        },
        m(e, n) {
            y(e, t, n), D(t, s)
        },
        p(e, n) {
            n & 128 && Y(s, e[7]), n & 16 && m(t, "suspended-name", e[4] !== O.active)
        },
        d(e) {
            e && b(t)
        }
    }
}

function oe(a) {
    let t, s;
    return t = new L({
        props: {
            $$slots: {
                default: [ie]
            },
            $$scope: {
                ctx: a
            }
        }
    }), {
        c() {
            $(t.$$.fragment)
        },
        l(e) {
            B(t.$$.fragment, e)
        },
        m(e, n) {
            N(t, e, n), s = !0
        },
        p(e, n) {
            const r = {};
            n & 262288 && (r.$$scope = {
                dirty: n,
                ctx: e
            }), t.$set(r)
        },
        i(e) {
            s || (p(t.$$.fragment, e), s = !0)
        },
        o(e) {
            g(t.$$.fragment, e), s = !1
        },
        d(e) {
            z(t, e)
        }
    }
}

function F(a) {
    let t, s, e, n;
    const r = [ue, ce],
        l = [];

    function f(c, o) {
        return c[4] !== O.active ? 0 : 1
    }
    return t = f(a), s = l[t] = r[t](a), {
        c() {
            s.c(), e = j()
        },
        l(c) {
            s.l(c), e = j()
        },
        m(c, o) {
            l[t].m(c, o), y(c, e, o), n = !0
        },
        p(c, o) {
            let i = t;
            t = f(c), t === i ? l[t].p(c, o) : (G(), g(l[i], 1, 1, () => {
                l[i] = null
            }), J(), s = l[t], s ? s.p(c, o) : (s = l[t] = r[t](c), s.c()), p(s, 1), s.m(e.parentNode, e))
        },
        i(c) {
            n || (p(s), n = !0)
        },
        o(c) {
            g(s), n = !1
        },
        d(c) {
            c && b(e), l[t].d(c)
        }
    }
}

function ce(a) {
    var n;
    let t, s, e;
    return s = new ae({
        props: {
            "data-test": "fixture-odds",
            alignArrow: a[2] ? "left" : "right",
            selected: a[5],
            odds: (n = a[3]) == null ? void 0 : n.odds
        }
    }), {
        c() {
            t = E("div"), $(s.$$.fragment), this.h()
        },
        l(r) {
            t = T(r, "DIV", {
                class: !0
            });
            var l = w(t);
            B(s.$$.fragment, l), l.forEach(b), this.h()
        },
        h() {
            v(t, "class", "odds svelte-1yo4ude")
        },
        m(r, l) {
            y(r, t, l), N(s, t, null), e = !0
        },
        p(r, l) {
            var c;
            const f = {};
            l & 4 && (f.alignArrow = r[2] ? "left" : "right"), l & 32 && (f.selected = r[5]), l & 8 && (f.odds = (c = r[3]) == null ? void 0 : c.odds), s.$set(f)
        },
        i(r) {
            e || (p(s.$$.fragment, r), e = !0)
        },
        o(r) {
            g(s.$$.fragment, r), e = !1
        },
        d(r) {
            r && b(t), z(s)
        }
    }
}

function ue(a) {
    let t, s;
    return t = new K({
        props: {
            maxWidth: "100%",
            $$slots: {
                default: [de]
            },
            $$scope: {
                ctx: a
            }
        }
    }), {
        c() {
            $(t.$$.fragment)
        },
        l(e) {
            B(t.$$.fragment, e)
        },
        m(e, n) {
            N(t, e, n), s = !0
        },
        p(e, n) {
            const r = {};
            n & 262400 && (r.$$scope = {
                dirty: n,
                ctx: e
            }), t.$set(r)
        },
        i(e) {
            s || (p(t.$$.fragment, e), s = !0)
        },
        o(e) {
            g(t.$$.fragment, e), s = !1
        },
        d(e) {
            z(t, e)
        }
    }
}

function fe(a) {
    let t, s;
    return {
        c() {
            t = E("span"), s = H(a[8]), this.h()
        },
        l(e) {
            t = T(e, "SPAN", {
                class: !0
            });
            var n = w(t);
            s = R(n, a[8]), n.forEach(b), this.h()
        },
        h() {
            v(t, "class", "suspended-odds svelte-1yo4ude")
        },
        m(e, n) {
            y(e, t, n), D(t, s)
        },
        p(e, n) {
            n & 256 && Y(s, e[8])
        },
        d(e) {
            e && b(t)
        }
    }
}

function de(a) {
    let t, s;
    return t = new L({
        props: {
            style: "flex-shrink: 0",
            $$slots: {
                default: [fe]
            },
            $$scope: {
                ctx: a
            }
        }
    }), {
        c() {
            $(t.$$.fragment)
        },
        l(e) {
            B(t.$$.fragment, e)
        },
        m(e, n) {
            N(t, e, n), s = !0
        },
        p(e, n) {
            const r = {};
            n & 262400 && (r.$$scope = {
                dirty: n,
                ctx: e
            }), t.$set(r)
        },
        i(e) {
            s || (p(t.$$.fragment, e), s = !0)
        },
        o(e) {
            g(t.$$.fragment, e), s = !1
        },
        d(e) {
            z(t, e)
        }
    }
}

function _e(a) {
    let t, s, e, n, r, l, f, c;
    e = new K({
        props: {
            maxWidth: "100%",
            $$slots: {
                default: [oe]
            },
            $$scope: {
                ctx: a
            }
        }
    });
    let o = !a[0] && F(a);
    return {
        c() {
            t = E("button"), s = E("div"), $(e.$$.fragment), n = Z(), o && o.c(), this.h()
        },
        l(i) {
            t = T(i, "BUTTON", {
                "aria-label": !0,
                "data-test": !0,
                class: !0
            });
            var u = w(t);
            s = T(u, "DIV", {
                class: !0
            });
            var h = w(s);
            B(e.$$.fragment, h), n = x(h), o && o.l(h), h.forEach(b), u.forEach(b), this.h()
        },
        h() {
            var i;
            v(s, "class", "outcome-content svelte-1yo4ude"), m(s, "horizontal", a[2]), m(s, "center", a[0]), v(t, "aria-label", r = (i = a[3]) == null ? void 0 : i.name), v(t, "data-test", "fixture-outcome"), v(t, "class", "outcome active:scale-[0.98] svelte-1yo4ude"), t.disabled = a[9], m(t, "isMulti", a[1]), m(t, "inactive", !a[6]), m(t, "selected", a[5])
        },
        m(i, u) {
            y(i, t, u), D(t, s), N(e, s, null), D(s, n), o && o.m(s, null), l = !0, f || (c = ee(t, "click", a[10]), f = !0)
        },
        p(i, [u]) {
            var k;
            const h = {};
            u & 262288 && (h.$$scope = {
                dirty: u,
                ctx: i
            }), e.$set(h), i[0] ? o && (G(), g(o, 1, 1, () => {
                o = null
            }), J()) : o ? (o.p(i, u), u & 1 && p(o, 1)) : (o = F(i), o.c(), p(o, 1), o.m(s, null)), (!l || u & 4) && m(s, "horizontal", i[2]), (!l || u & 1) && m(s, "center", i[0]), (!l || u & 8 && r !== (r = (k = i[3]) == null ? void 0 : k.name)) && v(t, "aria-label", r), (!l || u & 512) && (t.disabled = i[9]), (!l || u & 2) && m(t, "isMulti", i[1]), (!l || u & 64) && m(t, "inactive", !i[6]), (!l || u & 32) && m(t, "selected", i[5])
        },
        i(i) {
            l || (p(e.$$.fragment, i), p(o), l = !0)
        },
        o(i) {
            g(e.$$.fragment, i), g(o), l = !1
        },
        d(i) {
            i && b(t), z(e), o && o.d(), f = !1, c()
        }
    }
}

function me(a, t, s) {
    let e, n, r, l, f, c, o, i, u, h, k, A;
    U(a, re, d => s(16, k = d)), U(a, ne, d => s(17, A = d));
    let {
        bet: S
    } = t, {
        hideOdds: I = !1
    } = t, {
        name: C = void 0
    } = t, {
        isMulti: P = !1
    } = t, {
        horizontal: W = !1
    } = t;
    const Q = d => {
        const V = {
            id: e == null ? void 0 : e.id,
            type: "sportBet",
            state: {
                acceptedOdds: r.status === O.active ? e == null ? void 0 : e.odds : 0
            },
            data: {
                fixture: n,
                outcome: e,
                market: r
            }
        };
        f ? q.send({
            type: "REMOVE_BET",
            bet: V
        }) : (q.send({
            type: "ADD_BET",
            bet: V
        }), le(d.currentTarget, V.id))
    };
    return a.$$set = d => {
        "bet" in d && s(11, S = d.bet), "hideOdds" in d && s(0, I = d.hideOdds), "name" in d && s(12, C = d.name), "isMulti" in d && s(1, P = d.isMulti), "horizontal" in d && s(2, W = d.horizontal)
    }, a.$$.update = () => {
        a.$$.dirty & 2048 && s(3, {
            outcome: e,
            fixture: n,
            market: r
        } = S, e, (s(15, n), s(11, S)), (s(14, r), s(11, S))), a.$$.dirty & 16392 && s(4, c = (e == null ? void 0 : e.odds) === 0 ? O.suspended : r == null ? void 0 : r.status), a.$$.dirty & 16 && s(6, l = c === O.active), a.$$.dirty & 163848 && s(5, f = n != null && n.id ? (e == null ? void 0 : e.id) in A && !A[e == null ? void 0 : e.id].state.response : !1), a.$$.dirty & 96 && s(9, o = !f && !l), a.$$.dirty & 65552 && s(8, i = c in M ? k._(M[c]) : k._(M.suspended)), a.$$.dirty & 4104 && s(13, u = C ? ? (e == null ? void 0 : e.name)), a.$$.dirty & 73728 && s(7, h = u in M ? k._(M[u]) : u)
    }, [I, P, W, e, c, f, l, h, i, o, Q, S, C, u, r, n, k, A]
}
class Me extends te {
    constructor(t) {
        super(), se(this, t, me, _e, X, {
            bet: 11,
            hideOdds: 0,
            name: 12,
            isMulti: 1,
            horizontal: 2
        })
    }
}
export {
    Me as S, M as m
};