import {
    s as u,
    C as f,
    H as m,
    D as h,
    f as v,
    E as _,
    i as c,
    F as r,
    j as d,
    n as o
} from "./scheduler.DXu26z7T.js";
import {
    S as g,
    i as y
} from "./index.Dz_MmNB3.js";

function Z(n) {
    let e, a, s = ` <title>${n[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M10.266 3.893a23.1 23.1 0 1 1 25.668 38.414A23.1 23.1 0 0 1 10.266 3.893Zm5.112 30.764a13.9 13.9 0 1 0 15.444-23.114 13.9 13.9 0 0 0-15.444 23.114ZM38.55 46.33a28.002 28.002 0 0 0 7.78-7.78L64 56.22 56.22 64 38.55 46.33Z"></path>`,
        i;
    return {
        c() {
            e = f("svg"), a = new m(!0), this.h()
        },
        l(l) {
            e = h(l, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var t = v(e);
            a = _(t, !0), t.forEach(c), this.h()
        },
        h() {
            a.a = null, r(e, "fill", "currentColor"), r(e, "viewBox", "0 0 64 64"), r(e, "class", i = "svg-icon " + n[2]), r(e, "style", n[0])
        },
        m(l, t) {
            d(l, e, t), a.m(s, e)
        },
        p(l, [t]) {
            t & 2 && s !== (s = ` <title>${l[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M10.266 3.893a23.1 23.1 0 1 1 25.668 38.414A23.1 23.1 0 0 1 10.266 3.893Zm5.112 30.764a13.9 13.9 0 1 0 15.444-23.114 13.9 13.9 0 0 0-15.444 23.114ZM38.55 46.33a28.002 28.002 0 0 0 7.78-7.78L64 56.22 56.22 64 38.55 46.33Z"></path>`) && a.p(s), t & 4 && i !== (i = "svg-icon " + l[2]) && r(e, "class", i), t & 1 && r(e, "style", l[0])
        },
        i: o,
        o,
        d(l) {
            l && c(e)
        }
    }
}

function w(n, e, a) {
    let {
        style: s = ""
    } = e, {
        alt: i = ""
    } = e, {
        class: l = ""
    } = e;
    return n.$$set = t => {
        "style" in t && a(0, s = t.style), "alt" in t && a(1, i = t.alt), "class" in t && a(2, l = t.class)
    }, [s, i, l]
}
class C extends g {
    constructor(e) {
        super(), y(this, e, w, Z, u, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    C as S
};