import {
    w as e
} from "./index.C2-CG2CN.js";
const s = e(void 0),
    i = e(void 0);
export {
    s as a, i as s
};