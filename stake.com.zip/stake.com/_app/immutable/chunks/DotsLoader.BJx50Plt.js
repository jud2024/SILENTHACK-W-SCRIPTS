import {
    s as n,
    e as l,
    d as r,
    S as d,
    F as v,
    j as c,
    n as s,
    i as m
} from "./scheduler.DXu26z7T.js";
import {
    S as p,
    i as h
} from "./index.Dz_MmNB3.js"; /* empty css                                            */
function u(o) {
    let t, a = '<div class="dot dot-one svelte-5ovsvp"></div> <div class="dot dot-two svelte-5ovsvp"></div>';
    return {
        c() {
            t = l("div"), t.innerHTML = a, this.h()
        },
        l(e) {
            t = r(e, "DIV", {
                class: !0,
                "data-svelte-h": !0
            }), d(t) !== "svelte-1uejlni" && (t.innerHTML = a), this.h()
        },
        h() {
            v(t, "class", "loader svelte-5ovsvp")
        },
        m(e, i) {
            c(e, t, i)
        },
        p: s,
        i: s,
        o: s,
        d(e) {
            e && m(t)
        }
    }
}
class D extends p {
    constructor(t) {
        super(), h(this, t, null, u, n, {})
    }
}
export {
    D
};