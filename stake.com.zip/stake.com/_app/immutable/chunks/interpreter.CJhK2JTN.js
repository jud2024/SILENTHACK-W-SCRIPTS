import {
    i as L,
    t as Vt,
    g as Ht,
    a as j,
    b as O,
    _ as d,
    c as Z,
    p as qt,
    u as ue,
    f as I,
    d as C,
    e as Xt,
    h as Gt,
    j as At,
    k as R,
    l as P,
    n as F,
    o as _t,
    m as Yt,
    E as kt,
    q as Wt,
    r as lt,
    s as rt,
    v as mt,
    w as he,
    x as Ft,
    y as fe,
    z as ce,
    A as zt,
    B as st,
    C as Ut,
    D as wt,
    F as le,
    G as de,
    H as X,
    S as ve,
    I as xt,
    J as Ct,
    K as pe,
    L as ye,
    M as ge
} from "./utils.Csgj0yys.js";
var b;
(function(r) {
    r.Start = "xstate.start", r.Stop = "xstate.stop", r.Raise = "xstate.raise", r.Send = "xstate.send", r.Cancel = "xstate.cancel", r.NullEvent = "", r.Assign = "xstate.assign", r.After = "xstate.after", r.DoneState = "done.state", r.DoneInvoke = "done.invoke", r.Log = "xstate.log", r.Init = "xstate.init", r.Invoke = "xstate.invoke", r.ErrorExecution = "error.execution", r.ErrorCommunication = "error.communication", r.ErrorPlatform = "error.platform", r.ErrorCustom = "xstate.error", r.Update = "xstate.update", r.Pure = "xstate.pure", r.Choose = "xstate.choose"
})(b || (b = {}));
var V;
(function(r) {
    r.Parent = "#_parent", r.Internal = "#_internal"
})(V || (V = {}));
var Nt = b.Start,
    Dt = b.Stop,
    yt = b.Raise,
    gt = b.Send,
    Qt = b.Cancel,
    me = b.NullEvent,
    Zt = b.Assign;
b.After;
b.DoneState;
var Rt = b.Log,
    we = b.Init,
    Tt = b.Invoke;
b.ErrorExecution;
var Jt = b.ErrorPlatform,
    Kt = b.ErrorCustom,
    Mt = b.Update,
    xe = b.Choose,
    Se = b.Pure,
    dt = j({
        type: we
    });

function Pt(r, t) {
    return t && t[r] || void 0
}

function nt(r, t) {
    var e;
    if (O(r) || typeof r == "number") {
        var n = Pt(r, t);
        L(n) ? e = {
            type: r,
            exec: n
        } : n ? e = n : e = {
            type: r,
            exec: void 0
        }
    } else if (L(r)) e = {
        type: r.name || r.toString(),
        exec: r
    };
    else {
        var n = Pt(r.type, t);
        if (L(n)) e = d(d({}, r), {
            exec: n
        });
        else if (n) {
            var a = n.type || r.type;
            e = d(d(d({}, n), r), {
                type: a
            })
        } else e = r
    }
    return Object.defineProperty(e, "toString", {
        value: function() {
            return e.type
        },
        enumerable: !1,
        configurable: !0
    }), e
}
var vt = function(r, t) {
    if (!r) return [];
    var e = At(r) ? r : [r];
    return e.map(function(n) {
        return nt(n, t)
    })
};

function jt(r) {
    var t = nt(r);
    return d(d({
        id: O(r) ? r : t.id
    }, t), {
        type: t.type
    })
}

function Ee(r) {
    return O(r) ? {
        type: yt,
        event: r
    } : it(r, {
        to: V.Internal
    })
}

function be(r) {
    return {
        type: yt,
        _event: j(r.event)
    }
}

function it(r, t) {
    return {
        to: t ? t.to : void 0,
        type: gt,
        event: L(r) ? r : Vt(r),
        delay: t ? t.delay : void 0,
        id: t && t.id !== void 0 ? t.id : L(r) ? r.name : Ht(r)
    }
}

function Ne(r, t, e, n) {
    var a = {
            _event: e
        },
        i = j(L(r.event) ? r.event(t, e.data, a) : r.event),
        s;
    if (O(r.delay)) {
        var h = n && n[r.delay];
        s = L(h) ? h(t, e.data, a) : h
    } else s = L(r.delay) ? r.delay(t, e.data, a) : r.delay;
    var o = L(r.to) ? r.to(t, e.data, a) : r.to;
    return d(d({}, r), {
        to: o,
        _event: i,
        event: i.data,
        delay: s
    })
}

function te(r, t) {
    return it(r, d(d({}, t), {
        to: V.Parent
    }))
}

function We() {
    return te(Mt)
}

function Qe(r, t) {
    return it(r, d(d({}, t), {
        to: function(e, n, a) {
            var i = a._event;
            return i.origin
        }
    }))
}
var Te = function(r, t) {
    return {
        context: r,
        event: t
    }
};

function Ze(r, t) {
    return r === void 0 && (r = Te), {
        type: Rt,
        label: t,
        expr: r
    }
}
var Pe = function(r, t, e) {
        return d(d({}, r), {
            value: O(r.expr) ? r.expr : r.expr(t, e.data, {
                _event: e
            })
        })
    },
    Oe = function(r) {
        return {
            type: Qt,
            sendId: r
        }
    };

function Ie(r) {
    var t = jt(r);
    return {
        type: b.Start,
        activity: t,
        exec: void 0
    }
}

function Le(r) {
    var t = L(r) ? r : jt(r);
    return {
        type: b.Stop,
        activity: t,
        exec: void 0
    }
}

function Ae(r, t, e) {
    var n = L(r.activity) ? r.activity(t, e.data) : r.activity,
        a = typeof n == "string" ? {
            id: n
        } : n,
        i = {
            type: b.Stop,
            activity: a
        };
    return i
}
var Ke = function(r) {
    return {
        type: Zt,
        assignment: r
    }
};

function _e(r, t) {
    var e = t ? "#" + t : "";
    return b.After + "(" + r + ")" + e
}

function ot(r, t) {
    var e = b.DoneState + "." + r,
        n = {
            type: e,
            data: t
        };
    return n.toString = function() {
        return e
    }, n
}

function ft(r, t) {
    var e = b.DoneInvoke + "." + r,
        n = {
            type: e,
            data: t
        };
    return n.toString = function() {
        return e
    }, n
}

function K(r, t) {
    var e = b.ErrorPlatform + "." + r,
        n = {
            type: e,
            data: t
        };
    return n.toString = function() {
        return e
    }, n
}

function tr(r) {
    return {
        type: b.Pure,
        get: r
    }
}

function er(r, t) {
    return it(function(e, n) {
        return n
    }, d(d({}, t), {
        to: r
    }))
}

function rr(r, t) {
    return te(function(e, n, a) {
        return {
            type: Kt,
            data: L(r) ? r(e, n, a) : r
        }
    }, d(d({}, t), {
        to: V.Parent
    }))
}

function nr(r) {
    return {
        type: b.Choose,
        conds: r
    }
}

function Ot(r, t, e, n, a) {
    var i = Z(qt(a, function(u) {
            return u.type === Zt
        }), 2),
        s = i[0],
        h = i[1],
        o = s.length ? ue(e, n, s, t) : e,
        l = I(h.map(function(u) {
            var c;
            switch (u.type) {
                case yt:
                    return be(u);
                case gt:
                    var f = Ne(u, o, n, r.options.delays);
                    return f;
                case Rt:
                    return Pe(u, o, n);
                case xe:
                    {
                        var v = u,
                            y = (c = v.conds.find(function(g) {
                                var x = Xt(g.cond, r.options.guards);
                                return !x || Gt(r, x, o, n, t)
                            })) === null || c === void 0 ? void 0 : c.actions;
                        if (!y) return [];
                        var m = Ot(r, t, o, n, vt(C(y), r.options.actions));
                        return o = m[1],
                        m[0]
                    }
                case Se:
                    {
                        var y = u.get(o, n.data);
                        if (!y) return [];
                        var m = Ot(r, t, o, n, vt(C(y), r.options.actions));
                        return o = m[1],
                        m[0]
                    }
                case Dt:
                    return Ae(u, o, n);
                default:
                    return nt(u, r.options.actions)
            }
        }));
    return [l, o]
}
var pt = function(r) {
    return r.type === "atomic" || r.type === "final"
};

function Q(r) {
    return R(r.states).map(function(t) {
        return r.states[t]
    })
}

function ee(r) {
    var t = [r];
    return pt(r) ? t : t.concat(I(Q(r).map(ee)))
}

function W(r, t) {
    var e, n, a, i, s, h, o, l, u = new Set(r),
        c = It(u),
        f = new Set(t);
    try {
        for (var v = P(f), y = v.next(); !y.done; y = v.next())
            for (var m = y.value, g = m.parent; g && !f.has(g);) f.add(g), g = g.parent
    } catch (N) {
        e = {
            error: N
        }
    } finally {
        try {
            y && !y.done && (n = v.return) && n.call(v)
        } finally {
            if (e) throw e.error
        }
    }
    var x = It(f);
    try {
        for (var p = P(f), S = p.next(); !S.done; S = p.next()) {
            var m = S.value;
            if (m.type === "compound" && (!x.get(m) || !x.get(m).length)) c.get(m) ? c.get(m).forEach(function(_) {
                return f.add(_)
            }) : m.initialStateNodes.forEach(function(_) {
                return f.add(_)
            });
            else if (m.type === "parallel") try {
                for (var A = (s = void 0, P(Q(m))), T = A.next(); !T.done; T = A.next()) {
                    var D = T.value;
                    D.type !== "history" && (f.has(D) || (f.add(D), c.get(D) ? c.get(D).forEach(function(_) {
                        return f.add(_)
                    }) : D.initialStateNodes.forEach(function(_) {
                        return f.add(_)
                    })))
                }
            } catch (_) {
                s = {
                    error: _
                }
            } finally {
                try {
                    T && !T.done && (h = A.return) && h.call(A)
                } finally {
                    if (s) throw s.error
                }
            }
        }
    } catch (N) {
        a = {
            error: N
        }
    } finally {
        try {
            S && !S.done && (i = p.return) && i.call(p)
        } finally {
            if (a) throw a.error
        }
    }
    try {
        for (var E = P(f), w = E.next(); !w.done; w = E.next())
            for (var m = w.value, g = m.parent; g && !f.has(g);) f.add(g), g = g.parent
    } catch (N) {
        o = {
            error: N
        }
    } finally {
        try {
            w && !w.done && (l = E.return) && l.call(E)
        } finally {
            if (o) throw o.error
        }
    }
    return f
}

function re(r, t) {
    var e = t.get(r);
    if (!e) return {};
    if (r.type === "compound") {
        var n = e[0];
        if (n) {
            if (pt(n)) return n.key
        } else return {}
    }
    var a = {};
    return e.forEach(function(i) {
        a[i.key] = re(i, t)
    }), a
}

function It(r) {
    var t, e, n = new Map;
    try {
        for (var a = P(r), i = a.next(); !i.done; i = a.next()) {
            var s = i.value;
            n.has(s) || n.set(s, []), s.parent && (n.has(s.parent) || n.set(s.parent, []), n.get(s.parent).push(s))
        }
    } catch (h) {
        t = {
            error: h
        }
    } finally {
        try {
            i && !i.done && (e = a.return) && e.call(a)
        } finally {
            if (t) throw t.error
        }
    }
    return n
}

function De(r, t) {
    var e = W([r], t);
    return re(r, It(e))
}

function ct(r, t) {
    return Array.isArray(r) ? r.some(function(e) {
        return e === t
    }) : r instanceof Set ? r.has(t) : !1
}

function Re(r) {
    return I(F(new Set(r.map(function(t) {
        return t.ownEvents
    }))))
}

function et(r, t) {
    return t.type === "compound" ? Q(t).some(function(e) {
        return e.type === "final" && ct(r, e)
    }) : t.type === "parallel" ? Q(t).every(function(e) {
        return et(r, e)
    }) : !1
}

function ne(r, t) {
    if (r === t) return !0;
    if (r === void 0 || t === void 0) return !1;
    if (O(r) || O(t)) return r === t;
    var e = R(r),
        n = R(t);
    return e.length === n.length && e.every(function(a) {
        return ne(r[a], t[a])
    })
}

function Me(r) {
    return O(r) ? !1 : "value" in r && "history" in r
}

function je(r, t) {
    var e = r.exec,
        n = d(d({}, r), {
            exec: e !== void 0 ? function() {
                return e(t.context, t.event, {
                    action: r,
                    state: t,
                    _event: t._event
                })
            } : void 0
        });
    return n
}
var $ = function() {
        function r(t) {
            var e = this;
            this.actions = [], this.activities = kt, this.meta = {}, this.events = [], this.value = t.value, this.context = t.context, this._event = t._event, this._sessionid = t._sessionid, this.event = this._event.data, this.historyValue = t.historyValue, this.history = t.history, this.actions = t.actions || [], this.activities = t.activities || kt, this.meta = t.meta || {}, this.events = t.events || [], this.matches = this.matches.bind(this), this.toStrings = this.toStrings.bind(this), this.configuration = t.configuration, this.transitions = t.transitions, this.children = t.children, this.done = !!t.done, Object.defineProperty(this, "nextEvents", {
                get: function() {
                    return Re(e.configuration)
                }
            })
        }
        return r.from = function(t, e) {
            if (t instanceof r) return t.context !== e ? new r({
                value: t.value,
                context: e,
                _event: t._event,
                _sessionid: null,
                historyValue: t.historyValue,
                history: t.history,
                actions: [],
                activities: t.activities,
                meta: {},
                events: [],
                configuration: [],
                transitions: [],
                children: {}
            }) : t;
            var n = dt;
            return new r({
                value: t,
                context: e,
                _event: n,
                _sessionid: null,
                historyValue: void 0,
                history: void 0,
                actions: [],
                activities: void 0,
                meta: void 0,
                events: [],
                configuration: [],
                transitions: [],
                children: {}
            })
        }, r.create = function(t) {
            return new r(t)
        }, r.inert = function(t, e) {
            if (t instanceof r) {
                if (!t.actions.length) return t;
                var n = dt;
                return new r({
                    value: t.value,
                    context: e,
                    _event: n,
                    _sessionid: null,
                    historyValue: t.historyValue,
                    history: t.history,
                    activities: t.activities,
                    configuration: t.configuration,
                    transitions: [],
                    children: {}
                })
            }
            return r.from(t, e)
        }, r.prototype.toStrings = function(t, e) {
            var n = this;
            if (t === void 0 && (t = this.value), e === void 0 && (e = "."), O(t)) return [t];
            var a = R(t);
            return a.concat.apply(a, F(a.map(function(i) {
                return n.toStrings(t[i], e).map(function(s) {
                    return i + e + s
                })
            })))
        }, r.prototype.toJSON = function() {
            var t = this;
            t.configuration, t.transitions;
            var e = _t(t, ["configuration", "transitions"]);
            return e
        }, r.prototype.matches = function(t) {
            return Yt(t, this.value)
        }, r
    }(),
    Bt = [],
    tt = function(r, t) {
        Bt.push(r);
        var e = t(r);
        return Bt.pop(), e
    };

function ie(r) {
    return {
        id: r,
        send: function() {},
        subscribe: function() {
            return {
                unsubscribe: function() {}
            }
        },
        toJSON: function() {
            return {
                id: r
            }
        }
    }
}

function ke(r, t, e, n) {
    var a, i = Wt(r.src),
        s = (a = t == null ? void 0 : t.options.services) === null || a === void 0 ? void 0 : a[i.type],
        h = r.data ? lt(r.data, e, n) : void 0,
        o = s ? Fe(s, r.id, h) : ie(r.id);
    return o.meta = r, o
}

function Fe(r, t, e) {
    var n = ie(t);
    return n.deferred = !0, rt(r) && (n.state = tt(void 0, function() {
        return (e ? r.withContext(e) : r).initialState
    })), n
}

function ze(r) {
    try {
        return typeof r.send == "function"
    } catch {
        return !1
    }
}

function Ue(r) {
    return ze(r) && "id" in r
}

function Ce(r) {
    if (typeof r == "string") {
        var t = {
            type: r
        };
        return t.toString = function() {
            return r
        }, t
    }
    return r
}

function ut(r) {
    return d(d({
        type: Tt
    }, r), {
        toJSON: function() {
            r.onDone, r.onError;
            var t = _t(r, ["onDone", "onError"]);
            return d(d({}, t), {
                type: Tt,
                src: Ce(r.src)
            })
        }
    })
}
var St = "",
    Lt = "#",
    Et = "*",
    G = {},
    Y = function(r) {
        return r[0] === Lt
    },
    Je = function() {
        return {
            actions: {},
            guards: {},
            services: {},
            activities: {},
            delays: {}
        }
    },
    Be = function() {
        function r(t, e, n) {
            var a = this;
            n === void 0 && (n = void 0);
            var i;
            this.config = t, this.context = n, this.order = -1, this.__xstatenode = !0, this.__cache = {
                events: void 0,
                relativeValue: new Map,
                initialStateValue: void 0,
                initialState: void 0,
                on: void 0,
                transitions: void 0,
                candidates: {},
                delayedTransitions: void 0
            }, this.idMap = {}, this.options = Object.assign(Je(), e), this.parent = this.options._parent, this.key = this.config.key || this.options._key || this.config.id || "(machine)", this.machine = this.parent ? this.parent.machine : this, this.path = this.parent ? this.parent.path.concat(this.key) : [], this.delimiter = this.config.delimiter || (this.parent ? this.parent.delimiter : ve), this.id = this.config.id || F([this.machine.key], this.path).join(this.delimiter), this.version = this.parent ? this.parent.version : this.config.version, this.type = this.config.type || (this.config.parallel ? "parallel" : this.config.states && R(this.config.states).length ? "compound" : this.config.history ? "history" : "atomic"), this.schema = this.parent ? this.machine.schema : (i = this.config.schema) !== null && i !== void 0 ? i : {}, this.initial = this.config.initial, this.states = this.config.states ? st(this.config.states, function(o, l) {
                var u, c = new r(o, {
                    _parent: a,
                    _key: l
                });
                return Object.assign(a.idMap, d((u = {}, u[c.id] = c, u), c.idMap)), c
            }) : G;
            var s = 0;

            function h(o) {
                var l, u;
                o.order = s++;
                try {
                    for (var c = P(Q(o)), f = c.next(); !f.done; f = c.next()) {
                        var v = f.value;
                        h(v)
                    }
                } catch (y) {
                    l = {
                        error: y
                    }
                } finally {
                    try {
                        f && !f.done && (u = c.return) && u.call(c)
                    } finally {
                        if (l) throw l.error
                    }
                }
            }
            h(this), this.history = this.config.history === !0 ? "shallow" : this.config.history || !1, this._transient = !!this.config.always || (this.config.on ? Array.isArray(this.config.on) ? this.config.on.some(function(o) {
                var l = o.event;
                return l === St
            }) : St in this.config.on : !1), this.strict = !!this.config.strict, this.onEntry = C(this.config.entry || this.config.onEntry).map(function(o) {
                return nt(o)
            }), this.onExit = C(this.config.exit || this.config.onExit).map(function(o) {
                return nt(o)
            }), this.meta = this.config.meta, this.doneData = this.type === "final" ? this.config.data : void 0, this.invoke = C(this.config.invoke).map(function(o, l) {
                var u, c;
                if (rt(o)) return a.machine.options.services = d((u = {}, u[o.id] = o, u), a.machine.options.services), ut({
                    src: o.id,
                    id: o.id
                });
                if (O(o.src)) return ut(d(d({}, o), {
                    id: o.id || o.src,
                    src: o.src
                }));
                if (rt(o.src) || L(o.src)) {
                    var f = a.id + ":invocation[" + l + "]";
                    return a.machine.options.services = d((c = {}, c[f] = o.src, c), a.machine.options.services), ut(d(d({
                        id: f
                    }, o), {
                        src: f
                    }))
                } else {
                    var v = o.src;
                    return ut(d(d({
                        id: v.type
                    }, o), {
                        src: v
                    }))
                }
            }), this.activities = C(this.config.activities).concat(this.invoke).map(function(o) {
                return jt(o)
            }), this.transition = this.transition.bind(this)
        }
        return r.prototype._init = function() {
            this.__cache.transitions || ee(this).forEach(function(t) {
                return t.on
            })
        }, r.prototype.withConfig = function(t, e) {
            e === void 0 && (e = this.context);
            var n = this.options,
                a = n.actions,
                i = n.activities,
                s = n.guards,
                h = n.services,
                o = n.delays;
            return new r(this.config, {
                actions: d(d({}, a), t.actions),
                activities: d(d({}, i), t.activities),
                guards: d(d({}, s), t.guards),
                services: d(d({}, h), t.services),
                delays: d(d({}, o), t.delays)
            }, e)
        }, r.prototype.withContext = function(t) {
            return new r(this.config, this.options, t)
        }, Object.defineProperty(r.prototype, "definition", {
            get: function() {
                return {
                    id: this.id,
                    key: this.key,
                    version: this.version,
                    context: this.context,
                    type: this.type,
                    initial: this.initial,
                    history: this.history,
                    states: st(this.states, function(t) {
                        return t.definition
                    }),
                    on: this.on,
                    transitions: this.transitions,
                    entry: this.onEntry,
                    exit: this.onExit,
                    activities: this.activities || [],
                    meta: this.meta,
                    order: this.order || -1,
                    data: this.doneData,
                    invoke: this.invoke
                }
            },
            enumerable: !1,
            configurable: !0
        }), r.prototype.toJSON = function() {
            return this.definition
        }, Object.defineProperty(r.prototype, "on", {
            get: function() {
                if (this.__cache.on) return this.__cache.on;
                var t = this.transitions;
                return this.__cache.on = t.reduce(function(e, n) {
                    return e[n.eventType] = e[n.eventType] || [], e[n.eventType].push(n), e
                }, {})
            },
            enumerable: !1,
            configurable: !0
        }), Object.defineProperty(r.prototype, "after", {
            get: function() {
                return this.__cache.delayedTransitions || (this.__cache.delayedTransitions = this.getDelayedTransitions(), this.__cache.delayedTransitions)
            },
            enumerable: !1,
            configurable: !0
        }), Object.defineProperty(r.prototype, "transitions", {
            get: function() {
                return this.__cache.transitions || (this.__cache.transitions = this.formatTransitions(), this.__cache.transitions)
            },
            enumerable: !1,
            configurable: !0
        }), r.prototype.getCandidates = function(t) {
            if (this.__cache.candidates[t]) return this.__cache.candidates[t];
            var e = t === St,
                n = this.transitions.filter(function(a) {
                    var i = a.eventType === t;
                    return e ? i : i || a.eventType === Et
                });
            return this.__cache.candidates[t] = n, n
        }, r.prototype.getDelayedTransitions = function() {
            var t = this,
                e = this.config.after;
            if (!e) return [];
            var n = function(i, s) {
                    var h = L(i) ? t.id + ":delay[" + s + "]" : i,
                        o = _e(h, t.id);
                    return t.onEntry.push(it(o, {
                        delay: i
                    })), t.onExit.push(Oe(o)), o
                },
                a = At(e) ? e.map(function(i, s) {
                    var h = n(i.delay, s);
                    return d(d({}, i), {
                        event: h
                    })
                }) : I(R(e).map(function(i, s) {
                    var h = e[i],
                        o = O(h) ? {
                            target: h
                        } : h,
                        l = isNaN(+i) ? i : +i,
                        u = n(l, s);
                    return C(o).map(function(c) {
                        return d(d({}, c), {
                            event: u,
                            delay: l
                        })
                    })
                }));
            return a.map(function(i) {
                var s = i.delay;
                return d(d({}, t.formatTransition(i)), {
                    delay: s
                })
            })
        }, r.prototype.getStateNodes = function(t) {
            var e, n = this;
            if (!t) return [];
            var a = t instanceof $ ? t.value : mt(t, this.delimiter);
            if (O(a)) {
                var i = this.getStateNode(a).initial;
                return i !== void 0 ? this.getStateNodes((e = {}, e[a] = i, e)) : [this.states[a]]
            }
            var s = R(a),
                h = s.map(function(o) {
                    return n.getStateNode(o)
                });
            return h.concat(s.reduce(function(o, l) {
                var u = n.getStateNode(l).getStateNodes(a[l]);
                return o.concat(u)
            }, []))
        }, r.prototype.handles = function(t) {
            var e = Ht(t);
            return this.events.includes(e)
        }, r.prototype.resolveState = function(t) {
            var e = Array.from(W([], this.getStateNodes(t.value)));
            return new $(d(d({}, t), {
                value: this.resolve(t.value),
                configuration: e,
                done: et(e, this)
            }))
        }, r.prototype.transitionLeafNode = function(t, e, n) {
            var a = this.getStateNode(t),
                i = a.next(e, n);
            return !i || !i.transitions.length ? this.next(e, n) : i
        }, r.prototype.transitionCompoundNode = function(t, e, n) {
            var a = R(t),
                i = this.getStateNode(a[0]),
                s = i._transition(t[a[0]], e, n);
            return !s || !s.transitions.length ? this.next(e, n) : s
        }, r.prototype.transitionParallelNode = function(t, e, n) {
            var a, i, s = {};
            try {
                for (var h = P(R(t)), o = h.next(); !o.done; o = h.next()) {
                    var l = o.value,
                        u = t[l];
                    if (u) {
                        var c = this.getStateNode(l),
                            f = c._transition(u, e, n);
                        f && (s[l] = f)
                    }
                }
            } catch (p) {
                a = {
                    error: p
                }
            } finally {
                try {
                    o && !o.done && (i = h.return) && i.call(h)
                } finally {
                    if (a) throw a.error
                }
            }
            var v = R(s).map(function(p) {
                    return s[p]
                }),
                y = I(v.map(function(p) {
                    return p.transitions
                })),
                m = v.some(function(p) {
                    return p.transitions.length > 0
                });
            if (!m) return this.next(e, n);
            var g = I(v.map(function(p) {
                    return p.entrySet
                })),
                x = I(R(s).map(function(p) {
                    return s[p].configuration
                }));
            return {
                transitions: y,
                entrySet: g,
                exitSet: I(v.map(function(p) {
                    return p.exitSet
                })),
                configuration: x,
                source: e,
                actions: I(R(s).map(function(p) {
                    return s[p].actions
                }))
            }
        }, r.prototype._transition = function(t, e, n) {
            return O(t) ? this.transitionLeafNode(t, e, n) : R(t).length === 1 ? this.transitionCompoundNode(t, e, n) : this.transitionParallelNode(t, e, n)
        }, r.prototype.next = function(t, e) {
            var n, a, i = this,
                s = e.name,
                h = [],
                o = [],
                l;
            try {
                for (var u = P(this.getCandidates(s)), c = u.next(); !c.done; c = u.next()) {
                    var f = c.value,
                        v = f.cond,
                        y = f.in,
                        m = t.context,
                        g = y ? O(y) && Y(y) ? t.matches(mt(this.getStateNodeById(y).path, this.delimiter)) : Yt(mt(y, this.delimiter), he(this.path.slice(0, -2))(t.value)) : !0,
                        x = !1;
                    try {
                        x = !v || Gt(this.machine, v, m, e, t)
                    } catch (T) {
                        throw new Error("Unable to evaluate guard '" + (v.name || v.type) + "' in transition for event '" + s + "' in state node '" + this.id + `':
` + T.message)
                    }
                    if (x && g) {
                        f.target !== void 0 && (o = f.target), h.push.apply(h, F(f.actions)), l = f;
                        break
                    }
                }
            } catch (T) {
                n = {
                    error: T
                }
            } finally {
                try {
                    c && !c.done && (a = u.return) && a.call(u)
                } finally {
                    if (n) throw n.error
                }
            }
            if (l) {
                if (!o.length) return {
                    transitions: [l],
                    entrySet: [],
                    exitSet: [],
                    configuration: t.value ? [this] : [],
                    source: t,
                    actions: h
                };
                var p = I(o.map(function(T) {
                        return i.getRelativeStateNodes(T, t.historyValue)
                    })),
                    S = !!l.internal,
                    A = S ? [] : I(p.map(function(T) {
                        return i.nodesFromChild(T)
                    }));
                return {
                    transitions: [l],
                    entrySet: A,
                    exitSet: S ? [] : [this],
                    configuration: p,
                    source: t,
                    actions: h
                }
            }
        }, r.prototype.nodesFromChild = function(t) {
            if (t.escapes(this)) return [];
            for (var e = [], n = t; n && n !== this;) e.push(n), n = n.parent;
            return e.push(this), e
        }, r.prototype.escapes = function(t) {
            if (this === t) return !1;
            for (var e = this.parent; e;) {
                if (e === t) return !1;
                e = e.parent
            }
            return !0
        }, r.prototype.getActions = function(t, e, n, a) {
            var i, s, h, o, l = W([], a ? this.getStateNodes(a.value) : [this]),
                u = t.configuration.length ? W(l, t.configuration) : l;
            try {
                for (var c = P(u), f = c.next(); !f.done; f = c.next()) {
                    var v = f.value;
                    ct(l, v) || t.entrySet.push(v)
                }
            } catch (E) {
                i = {
                    error: E
                }
            } finally {
                try {
                    f && !f.done && (s = c.return) && s.call(c)
                } finally {
                    if (i) throw i.error
                }
            }
            try {
                for (var y = P(l), m = y.next(); !m.done; m = y.next()) {
                    var v = m.value;
                    (!ct(u, v) || ct(t.exitSet, v.parent)) && t.exitSet.push(v)
                }
            } catch (E) {
                h = {
                    error: E
                }
            } finally {
                try {
                    m && !m.done && (o = y.return) && o.call(y)
                } finally {
                    if (h) throw h.error
                }
            }
            t.source || (t.exitSet = [], t.entrySet.push(this));
            var g = I(t.entrySet.map(function(E) {
                var w = [];
                if (E.type !== "final") return w;
                var N = E.parent;
                if (!N.parent) return w;
                w.push(ot(E.id, E.doneData), ot(N.id, E.doneData ? lt(E.doneData, e, n) : void 0));
                var _ = N.parent;
                return _.type === "parallel" && Q(_).every(function(J) {
                    return et(t.configuration, J)
                }) && w.push(ot(_.id)), w
            }));
            t.exitSet.sort(function(E, w) {
                return w.order - E.order
            }), t.entrySet.sort(function(E, w) {
                return E.order - w.order
            });
            var x = new Set(t.entrySet),
                p = new Set(t.exitSet),
                S = Z([I(Array.from(x).map(function(E) {
                    return F(E.activities.map(function(w) {
                        return Ie(w)
                    }), E.onEntry)
                })).concat(g.map(Ee)), I(Array.from(p).map(function(E) {
                    return F(E.onExit, E.activities.map(function(w) {
                        return Le(w)
                    }))
                }))], 2),
                A = S[0],
                T = S[1],
                D = vt(T.concat(t.actions).concat(A), this.machine.options.actions);
            return D
        }, r.prototype.transition = function(t, e, n) {
            t === void 0 && (t = this.initialState);
            var a = j(e),
                i;
            if (t instanceof $) i = n === void 0 ? t : this.resolveState($.from(t, n));
            else {
                var s = O(t) ? this.resolve(Ft(this.getResolvedPath(t))) : this.resolve(t),
                    h = n || this.machine.context;
                i = this.resolveState($.from(s, h))
            }
            if (this.strict && !this.events.includes(a.name) && !fe(a.name)) throw new Error("Machine '" + this.id + "' does not accept event '" + a.name + "'");
            var o = this._transition(i.value, i, a) || {
                    transitions: [],
                    configuration: [],
                    entrySet: [],
                    exitSet: [],
                    source: i,
                    actions: []
                },
                l = W([], this.getStateNodes(i.value)),
                u = o.configuration.length ? W(l, o.configuration) : l;
            return o.configuration = F(u), this.resolveTransition(o, i, a)
        }, r.prototype.resolveRaisedTransition = function(t, e, n) {
            var a, i = t.actions;
            return t = this.transition(t, e), t._event = n, t.event = n.data, (a = t.actions).unshift.apply(a, F(i)), t
        }, r.prototype.resolveTransition = function(t, e, n, a) {
            var i, s, h = this;
            n === void 0 && (n = dt), a === void 0 && (a = this.machine.context);
            var o = t.configuration,
                l = !e || t.transitions.length > 0,
                u = l ? De(this.machine, o) : void 0,
                c = e ? e.historyValue ? e.historyValue : t.source ? this.machine.historyValue(e.value) : void 0 : void 0,
                f = e ? e.context : a,
                v = this.getActions(t, f, n, e),
                y = e ? d({}, e.activities) : {};
            try {
                for (var m = P(v), g = m.next(); !g.done; g = m.next()) {
                    var x = g.value;
                    x.type === Nt ? y[x.activity.id || x.activity.type] = x : x.type === Dt && (y[x.activity.id || x.activity.type] = !1)
                }
            } catch (M) {
                i = {
                    error: M
                }
            } finally {
                try {
                    g && !g.done && (s = m.return) && s.call(m)
                } finally {
                    if (i) throw i.error
                }
            }
            var p = Z(Ot(this, e, f, n, v), 2),
                S = p[0],
                A = p[1],
                T = Z(qt(S, function(M) {
                    return M.type === yt || M.type === gt && M.to === V.Internal
                }), 2),
                D = T[0],
                E = T[1],
                w = S.filter(function(M) {
                    var U;
                    return M.type === Nt && ((U = M.activity) === null || U === void 0 ? void 0 : U.type) === Tt
                }),
                N = w.reduce(function(M, U) {
                    return M[U.activity.id] = ke(U.activity, h.machine, A, n), M
                }, e ? d({}, e.children) : {}),
                _ = u ? t.configuration : e ? e.configuration : [],
                J = _.reduce(function(M, U) {
                    return U.meta !== void 0 && (M[U.id] = U.meta), M
                }, {}),
                B = et(_, this),
                H = new $({
                    value: u || e.value,
                    context: A,
                    _event: n,
                    _sessionid: e ? e._sessionid : null,
                    historyValue: u ? c ? ce(c, u) : void 0 : e ? e.historyValue : void 0,
                    history: !u || t.source ? e : void 0,
                    actions: u ? E : [],
                    activities: u ? y : e ? e.activities : {},
                    meta: u ? J : e ? e.meta : void 0,
                    events: [],
                    configuration: _,
                    transitions: t.transitions,
                    children: N,
                    done: B
                }),
                at = f !== A;
            H.changed = n.name === Mt || at;
            var q = H.history;
            if (q && delete q.history, !u) return H;
            var z = H;
            if (!B) {
                var ae = this._transient || o.some(function(M) {
                    return M._transient
                });
                for (ae && (z = this.resolveRaisedTransition(z, {
                        type: me
                    }, n)); D.length;) {
                    var se = D.shift();
                    z = this.resolveRaisedTransition(z, se._event, n)
                }
            }
            var oe = z.changed || (q ? !!z.actions.length || at || typeof q.value != typeof z.value || !ne(z.value, q.value) : void 0);
            return z.changed = oe, z.history = q, z
        }, r.prototype.getStateNode = function(t) {
            if (Y(t)) return this.machine.getStateNodeById(t);
            if (!this.states) throw new Error("Unable to retrieve child state '" + t + "' from '" + this.id + "'; no child states exist.");
            var e = this.states[t];
            if (!e) throw new Error("Child state '" + t + "' does not exist on '" + this.id + "'");
            return e
        }, r.prototype.getStateNodeById = function(t) {
            var e = Y(t) ? t.slice(Lt.length) : t;
            if (e === this.id) return this;
            var n = this.machine.idMap[e];
            if (!n) throw new Error("Child state node '#" + e + "' does not exist on machine '" + this.id + "'");
            return n
        }, r.prototype.getStateNodeByPath = function(t) {
            if (typeof t == "string" && Y(t)) try {
                return this.getStateNodeById(t.slice(1))
            } catch {}
            for (var e = zt(t, this.delimiter).slice(), n = this; e.length;) {
                var a = e.shift();
                if (!a.length) break;
                n = n.getStateNode(a)
            }
            return n
        }, r.prototype.resolve = function(t) {
            var e, n = this;
            if (!t) return this.initialStateValue || G;
            switch (this.type) {
                case "parallel":
                    return st(this.initialStateValue, function(i, s) {
                        return i ? n.getStateNode(s).resolve(t[s] || i) : G
                    });
                case "compound":
                    if (O(t)) {
                        var a = this.getStateNode(t);
                        return a.type === "parallel" || a.type === "compound" ? (e = {}, e[t] = a.initialStateValue, e) : t
                    }
                    return R(t).length ? st(t, function(i, s) {
                        return i ? n.getStateNode(s).resolve(i) : G
                    }) : this.initialStateValue || {};
                default:
                    return t || G
            }
        }, r.prototype.getResolvedPath = function(t) {
            if (Y(t)) {
                var e = this.machine.idMap[t.slice(Lt.length)];
                if (!e) throw new Error("Unable to find state node '" + t + "'");
                return e.path
            }
            return zt(t, this.delimiter)
        }, Object.defineProperty(r.prototype, "initialStateValue", {
            get: function() {
                var t;
                if (this.__cache.initialStateValue) return this.__cache.initialStateValue;
                var e;
                if (this.type === "parallel") e = Ut(this.states, function(n) {
                    return n.initialStateValue || G
                }, function(n) {
                    return n.type !== "history"
                });
                else if (this.initial !== void 0) {
                    if (!this.states[this.initial]) throw new Error("Initial state '" + this.initial + "' not found on '" + this.key + "'");
                    e = pt(this.states[this.initial]) ? this.initial : (t = {}, t[this.initial] = this.states[this.initial].initialStateValue, t)
                }
                return this.__cache.initialStateValue = e, this.__cache.initialStateValue
            },
            enumerable: !1,
            configurable: !0
        }), r.prototype.getInitialState = function(t, e) {
            var n = this.getStateNodes(t);
            return this.resolveTransition({
                configuration: n,
                entrySet: n,
                exitSet: [],
                transitions: [],
                source: void 0,
                actions: []
            }, void 0, void 0, e)
        }, Object.defineProperty(r.prototype, "initialState", {
            get: function() {
                this._init();
                var t = this.initialStateValue;
                if (!t) throw new Error("Cannot retrieve initial state from simple state '" + this.id + "'.");
                return this.getInitialState(t)
            },
            enumerable: !1,
            configurable: !0
        }), Object.defineProperty(r.prototype, "target", {
            get: function() {
                var t;
                if (this.type === "history") {
                    var e = this.config;
                    O(e.target) ? t = Y(e.target) ? Ft(this.machine.getStateNodeById(e.target).path.slice(this.path.length - 1)) : e.target : t = e.target
                }
                return t
            },
            enumerable: !1,
            configurable: !0
        }), r.prototype.getRelativeStateNodes = function(t, e, n) {
            return n === void 0 && (n = !0), n ? t.type === "history" ? t.resolveHistory(e) : t.initialStateNodes : [t]
        }, Object.defineProperty(r.prototype, "initialStateNodes", {
            get: function() {
                var t = this;
                if (pt(this)) return [this];
                if (this.type === "compound" && !this.initial) return [this];
                var e = wt(this.initialStateValue);
                return I(e.map(function(n) {
                    return t.getFromRelativePath(n)
                }))
            },
            enumerable: !1,
            configurable: !0
        }), r.prototype.getFromRelativePath = function(t) {
            if (!t.length) return [this];
            var e = Z(t),
                n = e[0],
                a = e.slice(1);
            if (!this.states) throw new Error("Cannot retrieve subPath '" + n + "' from node with no states");
            var i = this.getStateNode(n);
            if (i.type === "history") return i.resolveHistory();
            if (!this.states[n]) throw new Error("Child state '" + n + "' does not exist on '" + this.id + "'");
            return this.states[n].getFromRelativePath(a)
        }, r.prototype.historyValue = function(t) {
            if (R(this.states).length) return {
                current: t || this.initialStateValue,
                states: Ut(this.states, function(e, n) {
                    if (!t) return e.historyValue();
                    var a = O(t) ? void 0 : t[n];
                    return e.historyValue(a || e.initialStateValue)
                }, function(e) {
                    return !e.history
                })
            }
        }, r.prototype.resolveHistory = function(t) {
            var e = this;
            if (this.type !== "history") return [this];
            var n = this.parent;
            if (!t) {
                var a = this.target;
                return a ? I(wt(a).map(function(s) {
                    return n.getFromRelativePath(s)
                })) : n.initialStateNodes
            }
            var i = le(n.path, "states")(t).current;
            return O(i) ? [n.getStateNode(i)] : I(wt(i).map(function(s) {
                return e.history === "deep" ? n.getFromRelativePath(s) : [n.states[s[0]]]
            }))
        }, Object.defineProperty(r.prototype, "stateIds", {
            get: function() {
                var t = this,
                    e = I(R(this.states).map(function(n) {
                        return t.states[n].stateIds
                    }));
                return [this.id].concat(e)
            },
            enumerable: !1,
            configurable: !0
        }), Object.defineProperty(r.prototype, "events", {
            get: function() {
                var t, e, n, a;
                if (this.__cache.events) return this.__cache.events;
                var i = this.states,
                    s = new Set(this.ownEvents);
                if (i) try {
                    for (var h = P(R(i)), o = h.next(); !o.done; o = h.next()) {
                        var l = o.value,
                            u = i[l];
                        if (u.states) try {
                            for (var c = (n = void 0, P(u.events)), f = c.next(); !f.done; f = c.next()) {
                                var v = f.value;
                                s.add("" + v)
                            }
                        } catch (y) {
                            n = {
                                error: y
                            }
                        } finally {
                            try {
                                f && !f.done && (a = c.return) && a.call(c)
                            } finally {
                                if (n) throw n.error
                            }
                        }
                    }
                } catch (y) {
                    t = {
                        error: y
                    }
                } finally {
                    try {
                        o && !o.done && (e = h.return) && e.call(h)
                    } finally {
                        if (t) throw t.error
                    }
                }
                return this.__cache.events = Array.from(s)
            },
            enumerable: !1,
            configurable: !0
        }), Object.defineProperty(r.prototype, "ownEvents", {
            get: function() {
                var t = new Set(this.transitions.filter(function(e) {
                    return !(!e.target && !e.actions.length && e.internal)
                }).map(function(e) {
                    return e.eventType
                }));
                return Array.from(t)
            },
            enumerable: !1,
            configurable: !0
        }), r.prototype.resolveTarget = function(t) {
            var e = this;
            if (t !== void 0) return t.map(function(n) {
                if (!O(n)) return n;
                var a = n[0] === e.delimiter;
                if (a && !e.parent) return e.getStateNodeByPath(n.slice(1));
                var i = a ? e.key + n : n;
                if (e.parent) try {
                    var s = e.parent.getStateNodeByPath(i);
                    return s
                } catch (h) {
                    throw new Error("Invalid transition definition for state node '" + e.id + `':
` + h.message)
                } else return e.getStateNodeByPath(i)
            })
        }, r.prototype.formatTransition = function(t) {
            var e = this,
                n = de(t.target),
                a = "internal" in t ? t.internal : n ? n.some(function(o) {
                    return O(o) && o[0] === e.delimiter
                }) : !0,
                i = this.machine.options.guards,
                s = this.resolveTarget(n),
                h = d(d({}, t), {
                    actions: vt(C(t.actions)),
                    cond: Xt(t.cond, i),
                    target: s,
                    source: this,
                    internal: a,
                    eventType: t.event,
                    toJSON: function() {
                        return d(d({}, h), {
                            target: h.target ? h.target.map(function(o) {
                                return "#" + o.id
                            }) : void 0,
                            source: "#" + e.id
                        })
                    }
                });
            return h
        }, r.prototype.formatTransitions = function() {
            var t, e, n = this,
                a;
            if (!this.config.on) a = [];
            else if (Array.isArray(this.config.on)) a = this.config.on;
            else {
                var i = this.config.on,
                    s = Et,
                    h = i[s],
                    o = h === void 0 ? [] : h,
                    l = _t(i, [typeof s == "symbol" ? s : s + ""]);
                a = I(R(l).map(function(p) {
                    var S = X(p, l[p]);
                    return S
                }).concat(X(Et, o)))
            }
            var u = this.config.always ? X("", this.config.always) : [],
                c = this.config.onDone ? X(String(ot(this.id)), this.config.onDone) : [],
                f = I(this.invoke.map(function(p) {
                    var S = [];
                    return p.onDone && S.push.apply(S, F(X(String(ft(p.id)), p.onDone))), p.onError && S.push.apply(S, F(X(String(K(p.id)), p.onError))), S
                })),
                v = this.after,
                y = I(F(c, f, a, u).map(function(p) {
                    return C(p).map(function(S) {
                        return n.formatTransition(S)
                    })
                }));
            try {
                for (var m = P(v), g = m.next(); !g.done; g = m.next()) {
                    var x = g.value;
                    y.push(x)
                }
            } catch (p) {
                t = {
                    error: p
                }
            } finally {
                try {
                    g && !g.done && (e = m.return) && e.call(m)
                } finally {
                    if (t) throw t.error
                }
            }
            return y
        }, r
    }();

function ir(r, t, e) {
    e === void 0 && (e = r.context);
    var n = typeof e == "function" ? e() : e;
    return new Be(r, t, n)
}
var $e = {
        deferEvents: !1
    },
    $t = function() {
        function r(t) {
            this.processingEvent = !1, this.queue = [], this.initialized = !1, this.options = d(d({}, $e), t)
        }
        return r.prototype.initialize = function(t) {
            if (this.initialized = !0, t) {
                if (!this.options.deferEvents) {
                    this.schedule(t);
                    return
                }
                this.process(t)
            }
            this.flushEvents()
        }, r.prototype.schedule = function(t) {
            if (!this.initialized || this.processingEvent) {
                this.queue.push(t);
                return
            }
            if (this.queue.length !== 0) throw new Error("Event queue should be empty when it is not processing events");
            this.process(t), this.flushEvents()
        }, r.prototype.clear = function() {
            this.queue = []
        }, r.prototype.flushEvents = function() {
            for (var t = this.queue.shift(); t;) this.process(t), t = this.queue.shift()
        }, r.prototype.process = function(t) {
            this.processingEvent = !0;
            try {
                t()
            } catch (e) {
                throw this.clear(), e
            } finally {
                this.processingEvent = !1
            }
        }, r
    }(),
    bt = new Map,
    Ve = 0,
    ht = {
        bookId: function() {
            return "x:" + Ve++
        },
        register: function(r, t) {
            return bt.set(r, t), r
        },
        get: function(r) {
            return bt.get(r)
        },
        free: function(r) {
            bt.delete(r)
        }
    };

function He() {
    if (typeof self < "u") return self;
    if (typeof window < "u") return window;
    if (typeof global < "u") return global
}
var qe = {
        sync: !1,
        autoForward: !1
    },
    k;
(function(r) {
    r[r.NotStarted = 0] = "NotStarted", r[r.Running = 1] = "Running", r[r.Stopped = 2] = "Stopped"
})(k || (k = {}));
var Xe = function() {
    function r(t, e) {
        var n = this;
        e === void 0 && (e = r.defaultOptions), this.machine = t, this.scheduler = new $t, this.delayedEventsMap = {}, this.listeners = new Set, this.contextListeners = new Set, this.stopListeners = new Set, this.doneListeners = new Set, this.eventListeners = new Set, this.sendListeners = new Set, this.initialized = !1, this.status = k.NotStarted, this.children = new Map, this.forwardTo = new Set, this.init = this.start, this.send = function(u, c) {
            if (At(u)) return n.batch(u), n.state;
            var f = j(Vt(u, c));
            if (n.status === k.Stopped) return n.state;
            if (n.status !== k.Running && !n.options.deferEvents) throw new Error('Event "' + f.name + '" was sent to uninitialized service "' + n.machine.id + `". Make sure .start() is called for this service, or set { deferEvents: true } in the service options.
Event: ` + JSON.stringify(f.data));
            return n.scheduler.schedule(function() {
                n.forward(f);
                var v = n.nextState(f);
                n.update(v, f)
            }), n._state
        }, this.sendTo = function(u, c) {
            var f = n.parent && (c === V.Parent || n.parent.id === c),
                v = f ? n.parent : O(c) ? n.children.get(c) || ht.get(c) : ye(c) ? c : void 0;
            if (!v) {
                if (!f) throw new Error("Unable to send event to child '" + c + "' from service '" + n.id + "'.");
                return
            }
            "machine" in v ? v.send(d(d({}, u), {
                name: u.name === Kt ? "" + K(n.id) : u.name,
                origin: n.sessionId
            })) : v.send(u.data)
        };
        var a = d(d({}, r.defaultOptions), e),
            i = a.clock,
            s = a.logger,
            h = a.parent,
            o = a.id,
            l = o !== void 0 ? o : t.id;
        this.id = l, this.logger = s, this.clock = i, this.parent = h, this.options = a, this.scheduler = new $t({
            deferEvents: this.options.deferEvents
        }), this.sessionId = ht.bookId()
    }
    return Object.defineProperty(r.prototype, "initialState", {
        get: function() {
            var t = this;
            return this._initialState ? this._initialState : tt(this, function() {
                return t._initialState = t.machine.initialState, t._initialState
            })
        },
        enumerable: !1,
        configurable: !0
    }), Object.defineProperty(r.prototype, "state", {
        get: function() {
            return this._state
        },
        enumerable: !1,
        configurable: !0
    }), r.prototype.execute = function(t, e) {
        var n, a;
        try {
            for (var i = P(t.actions), s = i.next(); !s.done; s = i.next()) {
                var h = s.value;
                this.exec(h, t, e)
            }
        } catch (o) {
            n = {
                error: o
            }
        } finally {
            try {
                s && !s.done && (a = i.return) && a.call(i)
            } finally {
                if (n) throw n.error
            }
        }
    }, r.prototype.update = function(t, e) {
        var n, a, i, s, h, o, l, u, c = this;
        if (t._sessionid = this.sessionId, this._state = t, this.options.execute && this.execute(this.state), this.children.forEach(function(N) {
                c.state.children[N.id] = N
            }), this.devTools && this.devTools.send(e.data, t), t.event) try {
            for (var f = P(this.eventListeners), v = f.next(); !v.done; v = f.next()) {
                var y = v.value;
                y(t.event)
            }
        } catch (N) {
            n = {
                error: N
            }
        } finally {
            try {
                v && !v.done && (a = f.return) && a.call(f)
            } finally {
                if (n) throw n.error
            }
        }
        try {
            for (var m = P(this.listeners), g = m.next(); !g.done; g = m.next()) {
                var y = g.value;
                y(t, t.event)
            }
        } catch (N) {
            i = {
                error: N
            }
        } finally {
            try {
                g && !g.done && (s = m.return) && s.call(m)
            } finally {
                if (i) throw i.error
            }
        }
        try {
            for (var x = P(this.contextListeners), p = x.next(); !p.done; p = x.next()) {
                var S = p.value;
                S(this.state.context, this.state.history ? this.state.history.context : void 0)
            }
        } catch (N) {
            h = {
                error: N
            }
        } finally {
            try {
                p && !p.done && (o = x.return) && o.call(x)
            } finally {
                if (h) throw h.error
            }
        }
        var A = et(t.configuration || [], this.machine);
        if (this.state.configuration && A) {
            var T = t.configuration.find(function(N) {
                    return N.type === "final" && N.parent === c.machine
                }),
                D = T && T.doneData ? lt(T.doneData, t.context, e) : void 0;
            try {
                for (var E = P(this.doneListeners), w = E.next(); !w.done; w = E.next()) {
                    var y = w.value;
                    y(ft(this.id, D))
                }
            } catch (N) {
                l = {
                    error: N
                }
            } finally {
                try {
                    w && !w.done && (u = E.return) && u.call(E)
                } finally {
                    if (l) throw l.error
                }
            }
            this.stop()
        }
    }, r.prototype.onTransition = function(t) {
        return this.listeners.add(t), this.status === k.Running && t(this.state, this.state.event), this
    }, r.prototype.subscribe = function(t, e, n) {
        var a = this;
        if (!t) return {
            unsubscribe: function() {}
        };
        var i, s = n;
        return typeof t == "function" ? i = t : (i = t.next.bind(t), s = t.complete.bind(t)), this.listeners.add(i), this.status === k.Running && i(this.state), s && this.onDone(s), {
            unsubscribe: function() {
                i && a.listeners.delete(i), s && a.doneListeners.delete(s)
            }
        }
    }, r.prototype.onEvent = function(t) {
        return this.eventListeners.add(t), this
    }, r.prototype.onSend = function(t) {
        return this.sendListeners.add(t), this
    }, r.prototype.onChange = function(t) {
        return this.contextListeners.add(t), this
    }, r.prototype.onStop = function(t) {
        return this.stopListeners.add(t), this
    }, r.prototype.onDone = function(t) {
        return this.doneListeners.add(t), this
    }, r.prototype.off = function(t) {
        return this.listeners.delete(t), this.eventListeners.delete(t), this.sendListeners.delete(t), this.stopListeners.delete(t), this.doneListeners.delete(t), this.contextListeners.delete(t), this
    }, r.prototype.start = function(t) {
        var e = this;
        if (this.status === k.Running) return this;
        ht.register(this.sessionId, this), this.initialized = !0, this.status = k.Running;
        var n = t === void 0 ? this.initialState : tt(this, function() {
            return Me(t) ? e.machine.resolveState(t) : e.machine.resolveState($.from(t, e.machine.context))
        });
        return this.options.devTools && this.attachDev(), this.scheduler.initialize(function() {
            e.update(n, dt)
        }), this
    }, r.prototype.stop = function() {
        var t, e, n, a, i, s, h, o, l, u, c = this;
        try {
            for (var f = P(this.listeners), v = f.next(); !v.done; v = f.next()) {
                var y = v.value;
                this.listeners.delete(y)
            }
        } catch (w) {
            t = {
                error: w
            }
        } finally {
            try {
                v && !v.done && (e = f.return) && e.call(f)
            } finally {
                if (t) throw t.error
            }
        }
        try {
            for (var m = P(this.stopListeners), g = m.next(); !g.done; g = m.next()) {
                var y = g.value;
                y(), this.stopListeners.delete(y)
            }
        } catch (w) {
            n = {
                error: w
            }
        } finally {
            try {
                g && !g.done && (a = m.return) && a.call(m)
            } finally {
                if (n) throw n.error
            }
        }
        try {
            for (var x = P(this.contextListeners), p = x.next(); !p.done; p = x.next()) {
                var y = p.value;
                this.contextListeners.delete(y)
            }
        } catch (w) {
            i = {
                error: w
            }
        } finally {
            try {
                p && !p.done && (s = x.return) && s.call(x)
            } finally {
                if (i) throw i.error
            }
        }
        try {
            for (var S = P(this.doneListeners), A = S.next(); !A.done; A = S.next()) {
                var y = A.value;
                this.doneListeners.delete(y)
            }
        } catch (w) {
            h = {
                error: w
            }
        } finally {
            try {
                A && !A.done && (o = S.return) && o.call(S)
            } finally {
                if (h) throw h.error
            }
        }
        if (!this.initialized) return this;
        this.state.configuration.forEach(function(w) {
            var N, _;
            try {
                for (var J = P(w.definition.exit), B = J.next(); !B.done; B = J.next()) {
                    var H = B.value;
                    c.exec(H, c.state)
                }
            } catch (at) {
                N = {
                    error: at
                }
            } finally {
                try {
                    B && !B.done && (_ = J.return) && _.call(J)
                } finally {
                    if (N) throw N.error
                }
            }
        }), this.children.forEach(function(w) {
            L(w.stop) && w.stop()
        });
        try {
            for (var T = P(R(this.delayedEventsMap)), D = T.next(); !D.done; D = T.next()) {
                var E = D.value;
                this.clock.clearTimeout(this.delayedEventsMap[E])
            }
        } catch (w) {
            l = {
                error: w
            }
        } finally {
            try {
                D && !D.done && (u = T.return) && u.call(T)
            } finally {
                if (l) throw l.error
            }
        }
        return this.scheduler.clear(), this.initialized = !1, this.status = k.Stopped, ht.free(this.sessionId), this
    }, r.prototype.batch = function(t) {
        var e = this;
        if (!(this.status === k.NotStarted && this.options.deferEvents)) {
            if (this.status !== k.Running) throw new Error(t.length + ' event(s) were sent to uninitialized service "' + this.machine.id + '". Make sure .start() is called for this service, or set { deferEvents: true } in the service options.')
        }
        this.scheduler.schedule(function() {
            var n, a, i = e.state,
                s = !1,
                h = [],
                o = function(f) {
                    var v = j(f);
                    e.forward(v), i = tt(e, function() {
                        return e.machine.transition(i, v)
                    }), h.push.apply(h, F(i.actions.map(function(y) {
                        return je(y, i)
                    }))), s = s || !!i.changed
                };
            try {
                for (var l = P(t), u = l.next(); !u.done; u = l.next()) {
                    var c = u.value;
                    o(c)
                }
            } catch (f) {
                n = {
                    error: f
                }
            } finally {
                try {
                    u && !u.done && (a = l.return) && a.call(l)
                } finally {
                    if (n) throw n.error
                }
            }
            i.changed = s, i.actions = h, e.update(i, j(t[t.length - 1]))
        })
    }, r.prototype.sender = function(t) {
        return this.send.bind(this, t)
    }, r.prototype.nextState = function(t) {
        var e = this,
            n = j(t);
        if (n.name.indexOf(Jt) === 0 && !this.state.nextEvents.some(function(i) {
                return i.indexOf(Jt) === 0
            })) throw n.data.data;
        var a = tt(this, function() {
            return e.machine.transition(e.state, n)
        });
        return a
    }, r.prototype.forward = function(t) {
        var e, n;
        try {
            for (var a = P(this.forwardTo), i = a.next(); !i.done; i = a.next()) {
                var s = i.value,
                    h = this.children.get(s);
                if (!h) throw new Error("Unable to forward event '" + t + "' from interpreter '" + this.id + "' to nonexistant child '" + s + "'.");
                h.send(t)
            }
        } catch (o) {
            e = {
                error: o
            }
        } finally {
            try {
                i && !i.done && (n = a.return) && n.call(a)
            } finally {
                if (e) throw e.error
            }
        }
    }, r.prototype.defer = function(t) {
        var e = this;
        this.delayedEventsMap[t.id] = this.clock.setTimeout(function() {
            t.to ? e.sendTo(t._event, t.to) : e.send(t._event)
        }, t.delay)
    }, r.prototype.cancel = function(t) {
        this.clock.clearTimeout(this.delayedEventsMap[t]), delete this.delayedEventsMap[t]
    }, r.prototype.exec = function(t, e, n) {
        n === void 0 && (n = this.machine.options.actions);
        var a = e.context,
            i = e._event,
            s = t.exec || Pt(t.type, n),
            h = L(s) ? s : s ? s.exec : t.exec;
        if (h) try {
            return h(a, i.data, {
                action: t,
                state: this.state,
                _event: i
            })
        } catch (S) {
            throw this.parent && this.parent.send({
                type: "xstate.error",
                data: S
            }), S
        }
        switch (t.type) {
            case gt:
                var o = t;
                if (typeof o.delay == "number") {
                    this.defer(o);
                    return
                } else o.to ? this.sendTo(o._event, o.to) : this.send(o._event);
                break;
            case Qt:
                this.cancel(t.sendId);
                break;
            case Nt:
                {
                    var l = t.activity;
                    if (!this.state.activities[l.id || l.type]) break;
                    if (l.type === b.Invoke) {
                        var u = Wt(l.src),
                            c = this.machine.options.services ? this.machine.options.services[u.type] : void 0,
                            f = l.id,
                            v = l.data,
                            y = "autoForward" in l ? l.autoForward : !!l.forward;
                        if (!c) return;
                        var m = v ? lt(v, a, i) : void 0,
                            g = L(c) ? c(a, i.data, {
                                data: m,
                                src: u
                            }) : c;
                        xt(g) ? this.spawnPromise(Promise.resolve(g), f) : L(g) ? this.spawnCallback(g, f) : Ct(g) ? this.spawnObservable(g, f) : rt(g) && this.spawnMachine(m ? g.withContext(m) : g, {
                            id: f,
                            autoForward: y
                        })
                    } else this.spawnActivity(l);
                    break
                }
            case Dt:
                {
                    this.stopChild(t.activity.id);
                    break
                }
            case Rt:
                var x = t.label,
                    p = t.value;
                x ? this.logger(x, p) : this.logger(p);
                break
        }
    }, r.prototype.removeChild = function(t) {
        this.children.delete(t), this.forwardTo.delete(t), delete this.state.children[t]
    }, r.prototype.stopChild = function(t) {
        var e = this.children.get(t);
        e && (this.removeChild(t), L(e.stop) && e.stop())
    }, r.prototype.spawn = function(t, e, n) {
        if (xt(t)) return this.spawnPromise(Promise.resolve(t), e);
        if (L(t)) return this.spawnCallback(t, e);
        if (Ue(t)) return this.spawnActor(t);
        if (Ct(t)) return this.spawnObservable(t, e);
        if (rt(t)) return this.spawnMachine(t, d(d({}, n), {
            id: e
        }));
        throw new Error('Unable to spawn entity "' + e + '" of type "' + typeof t + '".')
    }, r.prototype.spawnMachine = function(t, e) {
        var n = this;
        e === void 0 && (e = {});
        var a = new r(t, d(d({}, this.options), {
                parent: this,
                id: e.id || t.id
            })),
            i = d(d({}, qe), e);
        i.sync && a.onTransition(function(h) {
            n.send(Mt, {
                state: h,
                id: a.id
            })
        });
        var s = a;
        return this.children.set(a.id, s), i.autoForward && this.forwardTo.add(a.id), a.onDone(function(h) {
            n.removeChild(a.id), n.send(j(h, {
                origin: a.id
            }))
        }).start(), s
    }, r.prototype.spawnPromise = function(t, e) {
        var n = this,
            a = !1;
        t.then(function(s) {
            a || (n.removeChild(e), n.send(j(ft(e, s), {
                origin: e
            })))
        }, function(s) {
            if (!a) {
                n.removeChild(e);
                var h = K(e, s);
                try {
                    n.send(j(h, {
                        origin: e
                    }))
                } catch {
                    n.devTools && n.devTools.send(h, n.state), n.machine.strict && n.stop()
                }
            }
        });
        var i = {
            id: e,
            send: function() {},
            subscribe: function(s, h, o) {
                var l = ge(s, h, o),
                    u = !1;
                return t.then(function(c) {
                    u || (l.next(c), !u && l.complete())
                }, function(c) {
                    u || l.error(c)
                }), {
                    unsubscribe: function() {
                        return u = !0
                    }
                }
            },
            stop: function() {
                a = !0
            },
            toJSON: function() {
                return {
                    id: e
                }
            }
        };
        return this.children.set(e, i), i
    }, r.prototype.spawnCallback = function(t, e) {
        var n = this,
            a = !1,
            i = new Set,
            s = new Set,
            h = function(u) {
                s.forEach(function(c) {
                    return c(u)
                }), !a && n.send(j(u, {
                    origin: e
                }))
            },
            o;
        try {
            o = t(h, function(u) {
                i.add(u)
            })
        } catch (u) {
            this.send(K(e, u))
        }
        if (xt(o)) return this.spawnPromise(o, e);
        var l = {
            id: e,
            send: function(u) {
                return i.forEach(function(c) {
                    return c(u)
                })
            },
            subscribe: function(u) {
                return s.add(u), {
                    unsubscribe: function() {
                        s.delete(u)
                    }
                }
            },
            stop: function() {
                a = !0, L(o) && o()
            },
            toJSON: function() {
                return {
                    id: e
                }
            }
        };
        return this.children.set(e, l), l
    }, r.prototype.spawnObservable = function(t, e) {
        var n = this,
            a = t.subscribe(function(s) {
                n.send(j(s, {
                    origin: e
                }))
            }, function(s) {
                n.removeChild(e), n.send(j(K(e, s), {
                    origin: e
                }))
            }, function() {
                n.removeChild(e), n.send(j(ft(e), {
                    origin: e
                }))
            }),
            i = {
                id: e,
                send: function() {},
                subscribe: function(s, h, o) {
                    return t.subscribe(s, h, o)
                },
                stop: function() {
                    return a.unsubscribe()
                },
                toJSON: function() {
                    return {
                        id: e
                    }
                }
            };
        return this.children.set(e, i), i
    }, r.prototype.spawnActor = function(t) {
        return this.children.set(t.id, t), t
    }, r.prototype.spawnActivity = function(t) {
        var e = this.machine.options && this.machine.options.activities ? this.machine.options.activities[t.type] : void 0;
        if (e) {
            var n = e(this.state.context, t);
            this.spawnEffect(t.id, n)
        }
    }, r.prototype.spawnEffect = function(t, e) {
        this.children.set(t, {
            id: t,
            send: function() {},
            subscribe: function() {
                return {
                    unsubscribe: function() {}
                }
            },
            stop: e || void 0,
            toJSON: function() {
                return {
                    id: t
                }
            }
        })
    }, r.prototype.attachDev = function() {
        var t = He();
        if (this.options.devTools && t && t.__REDUX_DEVTOOLS_EXTENSION__) {
            var e = typeof this.options.devTools == "object" ? this.options.devTools : void 0;
            this.devTools = t.__REDUX_DEVTOOLS_EXTENSION__.connect(d(d({
                name: this.id,
                autoPause: !0,
                stateSanitizer: function(n) {
                    return {
                        value: n.value,
                        context: n.context,
                        actions: n.actions
                    }
                }
            }, e), {
                features: d({
                    jump: !1,
                    skip: !1
                }, e ? e.features : void 0)
            }), this.machine), this.devTools.init(this.state)
        }
    }, r.prototype.toJSON = function() {
        return {
            id: this.id
        }
    }, r.prototype[pe] = function() {
        return this
    }, r.defaultOptions = function(t) {
        return {
            execute: !0,
            deferEvents: !0,
            clock: {
                setTimeout: function(e, n) {
                    return setTimeout(e, n)
                },
                clearTimeout: function(e) {
                    return clearTimeout(e)
                }
            },
            logger: t.console.log.bind(console),
            devTools: !1
        }
    }(typeof self < "u" ? self : global), r.interpret = Ge, r
}();

function Ge(r, t) {
    var e = new Xe(r, t);
    return e
}
export {
    ir as M, te as a, We as b, Oe as c, Ie as d, Le as e, Ke as f, _e as g, ot as h, Qe as i, er as j, rr as k, Ze as l, nr as m, Ge as n, tr as p, Ee as r, it as s
};