import {
    s as l,
    a as r,
    u,
    g as f,
    b as _
} from "./scheduler.DXu26z7T.js";
import {
    S as m,
    i as c,
    t as d,
    b as h
} from "./index.Dz_MmNB3.js";
import {
    s as p
} from "./index.D7nbRHfU.js";

function g(n) {
    let s;
    const i = n[2].default,
        e = r(i, n, n[1], null);
    return {
        c() {
            e && e.c()
        },
        l(t) {
            e && e.l(t)
        },
        m(t, a) {
            e && e.m(t, a), s = !0
        },
        p(t, [a]) {
            e && e.p && (!s || a & 2) && u(e, i, t, t[1], s ? _(i, t[1], a, null) : f(t[1]), null)
        },
        i(t) {
            s || (d(e, t), s = !0)
        },
        o(t) {
            h(e, t), s = !1
        },
        d(t) {
            e && e.d(t)
        }
    }
}

function W(n, s, i) {
    let {
        $$slots: e = {},
        $$scope: t
    } = s, {
        maxWidth: a
    } = s;
    return p(a), n.$$set = o => {
        "maxWidth" in o && i(0, a = o.maxWidth), "$$scope" in o && i(1, t = o.$$scope)
    }, [a, t, e]
}
class q extends m {
    constructor(s) {
        super(), c(this, s, W, g, l, {
            maxWidth: 0
        })
    }
}
export {
    q as T
};