import {
    h as o
} from "./index.B4-7gKq3.js";
o._("Copied to clipboard"), o._("Something went wrong when copying the text");