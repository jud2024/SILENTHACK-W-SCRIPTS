function p(t) {
    return `<script type="application/ld+json">${t}<\/script>`
}
export {
    p as j
};