import {
    t as i
} from "./bundle-mjs.BQkiJtvj.js";

function s(r) {
    var n, o, t = "";
    if (typeof r == "string" || typeof r == "number") t += r;
    else if (typeof r == "object")
        if (Array.isArray(r)) {
            var e = r.length;
            for (n = 0; n < e; n++) r[n] && (o = s(r[n])) && (t && (t += " "), t += o)
        } else
            for (o in r) r[o] && (t && (t += " "), t += o);
    return t
}

function a() {
    for (var r, n, o = 0, t = "", e = arguments.length; o < e; o++)(r = arguments[o]) && (n = s(r)) && (t && (t += " "), t += n);
    return t
}

function f(...r) {
    return i(a(r))
}
async function u(r) {
    return Promise.all(r.map(n => n.catch(() => {})))
}

function g() {
    const r = new Date;
    return r.setSeconds(0, 0), r.toISOString()
}
export {
    f as c, g, u as r
};