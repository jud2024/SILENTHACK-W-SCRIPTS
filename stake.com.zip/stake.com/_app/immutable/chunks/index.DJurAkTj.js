import {
    s as B,
    a as K,
    K as C,
    e as M,
    d as Q,
    f as U,
    i as V,
    Q as j,
    j as X,
    W as F,
    u as G,
    g as H,
    b as J,
    L as A,
    c as b,
    X as R,
    M as Y
} from "./scheduler.DXu26z7T.js";
import {
    S as Z,
    i as p,
    t as w,
    b as x
} from "./index.Dz_MmNB3.js";
import {
    g as $
} from "./spread.CgU5AtxT.js";
import {
    p as tt,
    n as et,
    r as at,
    aj as lt
} from "./index.B4-7gKq3.js";
import {
    c as E
} from "./index.BljstGtu.js";
import {
    g as st,
    a as it
} from "./ctx.CWJzPttI.js";
import "./entry.GPJbNZcP.js";
import {
    c as ot,
    b as ct
} from "./index.B3dW9TVs.js";
const ft = a => ({
        active: a & 512
    }),
    P = a => ({
        active: a[9]
    });

function nt(a) {
    let l, s, n, f, d, c, u, m;
    const r = a[21].default,
        i = K(r, a, a[20], P);
    let _ = [{
            "data-test": a[5]
        }, {
            class: s = E(S({
                variant: a[1],
                active: a[9],
                size: a[4],
                disabled: a[7],
                className: a[0],
                iconOnly: a[6]
            }))
        }, {
            href: a[8]
        }, {
            "data-sveltekit-reload": n = a[10] ? "" : "off"
        }, {
            "data-sveltekit-preload-data": f = a[7] ? "off" : a[2]
        }, {
            "data-sveltekit-noscroll": d = a[3] === !1 ? "" : "off"
        }, a[12]],
        v = {};
    for (let e = 0; e < _.length; e += 1) v = C(v, _[e]);
    return {
        c() {
            l = M("a"), i && i.c(), this.h()
        },
        l(e) {
            l = Q(e, "A", {
                "data-test": !0,
                class: !0,
                href: !0,
                "data-sveltekit-reload": !0,
                "data-sveltekit-preload-data": !0,
                "data-sveltekit-noscroll": !0
            });
            var o = U(l);
            i && i.l(o), o.forEach(V), this.h()
        },
        h() {
            j(l, v)
        },
        m(e, o) {
            X(e, l, o), i && i.m(l, null), c = !0, u || (m = F(l, "click", a[11]), u = !0)
        },
        p(e, [o]) {
            i && i.p && (!c || o & 1049088) && G(i, r, e, e[20], c ? J(r, e[20], o, ft) : H(e[20]), P), j(l, v = $(_, [(!c || o & 32) && {
                "data-test": e[5]
            }, (!c || o & 723 && s !== (s = E(S({
                variant: e[1],
                active: e[9],
                size: e[4],
                disabled: e[7],
                className: e[0],
                iconOnly: e[6]
            })))) && {
                class: s
            }, (!c || o & 256) && {
                href: e[8]
            }, (!c || o & 1024 && n !== (n = e[10] ? "" : "off")) && {
                "data-sveltekit-reload": n
            }, (!c || o & 132 && f !== (f = e[7] ? "off" : e[2])) && {
                "data-sveltekit-preload-data": f
            }, (!c || o & 8 && d !== (d = e[3] === !1 ? "" : "off")) && {
                "data-sveltekit-noscroll": d
            }, o & 4096 && e[12]]))
        },
        i(e) {
            c || (w(i, e), c = !0)
        },
        o(e) {
            x(i, e), c = !1
        },
        d(e) {
            e && V(l), i && i.d(e), u = !1, m()
        }
    }
}

function rt(a, l, s) {
    let n, f, d;
    const c = ["class", "active", "to", "variant", "prefetch", "scrollTopOnClick", "exact", "size", "testId", "iconOnly", "disabled"];
    let u = A(l, c),
        m, r, i, _;
    b(a, tt, t => s(17, m = t)), b(a, et, t => s(18, r = t)), b(a, at, t => s(19, i = t)), b(a, lt, t => s(10, _ = t));
    let {
        $$slots: v = {},
        $$scope: e
    } = l;
    const o = R(),
        W = st();
    let {
        class: T = void 0
    } = l, {
        active: h = void 0
    } = l, {
        to: g
    } = l, {
        variant: y = it({
            parent: W
        })
    } = l, {
        prefetch: I = "off"
    } = l, {
        scrollTopOnClick: O = !0
    } = l, {
        exact: z = !1
    } = l, {
        size: D = "md"
    } = l, {
        testId: L = void 0
    } = l, {
        iconOnly: N = !1
    } = l, {
        disabled: k = !1
    } = l, q = t => {
        k && t.preventDefault(), O && !k && window.scrollTo({
            top: 0
        }), o("click", t)
    };
    return a.$$set = t => {
        l = C(C({}, l), Y(t)), s(12, u = A(l, c)), "class" in t && s(0, T = t.class), "active" in t && s(13, h = t.active), "to" in t && s(14, g = t.to), "variant" in t && s(1, y = t.variant), "prefetch" in t && s(2, I = t.prefetch), "scrollTopOnClick" in t && s(3, O = t.scrollTopOnClick), "exact" in t && s(15, z = t.exact), "size" in t && s(4, D = t.size), "testId" in t && s(5, L = t.testId), "iconOnly" in t && s(6, N = t.iconOnly), "disabled" in t && s(7, k = t.disabled), "$$scope" in t && s(20, e = t.$$scope)
    }, a.$$.update = () => {
        var t;
        a.$$.dirty & 540672 && s(8, n = i(g)), a.$$.dirty & 393216 && s(16, f = r ? (t = r == null ? void 0 : r.to) == null ? void 0 : t.url.pathname : m.url.pathname), a.$$.dirty & 106752 && s(9, d = !!(h === void 0 ? z ? f === n : n && (f != null && f.startsWith(n)) : h))
    }, [T, y, I, O, D, L, N, k, n, d, _, q, u, h, g, z, f, m, r, i, e, v]
}
class gt extends Z {
    constructor(l) {
        super(), p(this, l, rt, nt, B, {
            class: 0,
            active: 13,
            to: 14,
            variant: 1,
            prefetch: 2,
            scrollTopOnClick: 3,
            exact: 15,
            size: 4,
            testId: 5,
            iconOnly: 6,
            disabled: 7
        })
    }
}
const S = ot({
    extend: ct,
    variants: {
        disabled: {
            true: "pointer-events-none opacity-50"
        }
    }
});
export {
    gt as L
};