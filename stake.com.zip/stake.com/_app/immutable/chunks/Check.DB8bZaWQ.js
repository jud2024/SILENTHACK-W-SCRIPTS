import {
    s as f,
    C as h,
    H as u,
    D as m,
    f as _,
    E as g,
    i as r,
    F as c,
    j as v,
    n as o
} from "./scheduler.DXu26z7T.js";
import {
    S as y,
    i as d
} from "./index.Dz_MmNB3.js";

function C(n) {
    let t, s, a = ` <title>${n[1]||""}</title> <path d="M26.922 50.04 8.147 32.014l7.175-7.174 11.6 10.906L48.708 13.96l7.145 7.146L26.922 50.04Z"></path>`,
        i;
    return {
        c() {
            t = h("svg"), s = new u(!0), this.h()
        },
        l(l) {
            t = m(l, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var e = _(t);
            s = g(e, !0), e.forEach(r), this.h()
        },
        h() {
            s.a = null, c(t, "fill", "currentColor"), c(t, "viewBox", "0 0 64 64"), c(t, "class", i = "svg-icon " + n[2]), c(t, "style", n[0])
        },
        m(l, e) {
            v(l, t, e), s.m(a, t)
        },
        p(l, [e]) {
            e & 2 && a !== (a = ` <title>${l[1]||""}</title> <path d="M26.922 50.04 8.147 32.014l7.175-7.174 11.6 10.906L48.708 13.96l7.145 7.146L26.922 50.04Z"></path>`) && s.p(a), e & 4 && i !== (i = "svg-icon " + l[2]) && c(t, "class", i), e & 1 && c(t, "style", l[0])
        },
        i: o,
        o,
        d(l) {
            l && r(t)
        }
    }
}

function w(n, t, s) {
    let {
        style: a = ""
    } = t, {
        alt: i = ""
    } = t, {
        class: l = ""
    } = t;
    return n.$$set = e => {
        "style" in e && s(0, a = e.style), "alt" in e && s(1, i = e.alt), "class" in e && s(2, l = e.class)
    }, [a, i, l]
}
class B extends y {
    constructor(t) {
        super(), d(this, t, w, C, f, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    B as C
};