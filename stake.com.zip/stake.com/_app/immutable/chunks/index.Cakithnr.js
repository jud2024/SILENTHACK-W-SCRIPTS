import {
    s as v,
    e as l,
    d as c,
    f as m,
    i,
    F as r,
    V as g,
    a5 as d,
    j as q,
    k as I,
    n as _,
    L as u,
    K as p,
    M as V
} from "./scheduler.DXu26z7T.js";
import {
    S as b,
    i as y
} from "./index.Dz_MmNB3.js";
import {
    a as C
} from "./index.B81orGJm.js";
import {
    c as f
} from "./index.BljstGtu.js";

function E(n) {
    let s, t, o;
    return {
        c() {
            s = l("div"), t = l("div"), this.h()
        },
        l(a) {
            s = c(a, "DIV", {
                class: !0
            });
            var e = m(s);
            t = c(e, "DIV", {
                class: !0
            }), m(t).forEach(i), e.forEach(i), this.h()
        },
        h() {
            r(t, "class", "loader-animation svelte-lq0ub9"), g(t, "no-animation-chromatic", n[0]), r(s, "class", o = d(f("loader top-[46%]", n[1].class)) + " svelte-lq0ub9")
        },
        m(a, e) {
            q(a, s, e), I(s, t)
        },
        p(a, [e]) {
            e & 2 && o !== (o = d(f("loader top-[46%]", a[1].class)) + " svelte-lq0ub9") && r(s, "class", o)
        },
        i: _,
        o: _,
        d(a) {
            a && i(s)
        }
    }
}

function R(n, s, t) {
    const o = [];
    let a = u(s, o);
    const e = C;
    return n.$$set = h => {
        s = p(p({}, s), V(h)), t(1, a = u(s, o))
    }, [e, a]
}
class M extends b {
    constructor(s) {
        super(), y(this, s, R, E, v, {})
    }
}
export {
    M as R
};