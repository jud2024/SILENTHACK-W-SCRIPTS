import {
    d as i
} from "./index.C2-CG2CN.js";
import {
    b
} from "./index.BxooaYHE.js";
import {
    O as d,
    P as v,
    Q as p,
    G as m,
    R as y
} from "./index.B4-7gKq3.js";
const C = ({
        currency: r
    }) => i([m, r], ([e, t]) => p(e, t) === "crypto" ? t : e),
    f = ({
        currency: r
    }) => i([m, r, y], ([e, t, a]) => {
        var o, n;
        return ((n = (o = a == null ? void 0 : a.rates) == null ? void 0 : o[t]) == null ? void 0 : n[p(e, t)]) || 0
    }),
    l = ({
        currency: r,
        formatFiat: e = v
    }) => {
        const t = C({
                currency: r
            }),
            a = f({
                currency: r
            });
        return i([d, t, a], ([o, n, c]) => s => o === "crypto" ? s : Number(e(s * c, n)))
    },
    B = ({
        currency: r,
        balanceType: e = "available"
    }) => {
        const t = l({
            currency: r
        });
        return i([b, r, t], ([a, o, n]) => {
            const c = a[o][e],
                s = n(c);
            return {
                original: c,
                converted: s
            }
        })
    };
export {
    C as a, B as b, l as c
};