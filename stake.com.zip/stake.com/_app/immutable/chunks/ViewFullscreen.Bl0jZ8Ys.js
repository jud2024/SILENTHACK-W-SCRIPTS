import {
    s as c,
    C as o,
    H as u,
    D as m,
    f,
    E as _,
    i as v,
    F as h,
    j as d,
    n as r
} from "./scheduler.DXu26z7T.js";
import {
    S as g,
    i as V
} from "./index.Dz_MmNB3.js";

function H(n) {
    let e, s, a = ` <title>${n[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M0 25h8V8h17V0H0v25Zm56 0h8V0H39v8h17v17ZM25 64H0V39h8v17h17v8Zm14 0h25V39h-8v17H39v8Z"></path>`,
        i;
    return {
        c() {
            e = o("svg"), s = new u(!0), this.h()
        },
        l(l) {
            e = m(l, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var t = f(e);
            s = _(t, !0), t.forEach(v), this.h()
        },
        h() {
            s.a = null, h(e, "fill", "currentColor"), h(e, "viewBox", "0 0 64 64"), h(e, "class", i = "svg-icon " + n[2]), h(e, "style", n[0])
        },
        m(l, t) {
            d(l, e, t), s.m(a, e)
        },
        p(l, [t]) {
            t & 2 && a !== (a = ` <title>${l[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M0 25h8V8h17V0H0v25Zm56 0h8V0H39v8h17v17ZM25 64H0V39h8v17h17v8Zm14 0h25V39h-8v17H39v8Z"></path>`) && s.p(a), t & 4 && i !== (i = "svg-icon " + l[2]) && h(e, "class", i), t & 1 && h(e, "style", l[0])
        },
        i: r,
        o: r,
        d(l) {
            l && v(e)
        }
    }
}

function Z(n, e, s) {
    let {
        style: a = ""
    } = e, {
        alt: i = ""
    } = e, {
        class: l = ""
    } = e;
    return n.$$set = t => {
        "style" in t && s(0, a = t.style), "alt" in t && s(1, i = t.alt), "class" in t && s(2, l = t.class)
    }, [a, i, l]
}
class M extends g {
    constructor(e) {
        super(), V(this, e, Z, H, c, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    M as V
};