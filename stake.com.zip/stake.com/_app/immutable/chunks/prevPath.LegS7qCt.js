import {
    w as o
} from "./index.C2-CG2CN.js";
const a = o(window.location.pathname);
export {
    a as p
};