import {
    _ as u,
    q as F,
    A as v,
    a6 as p,
    F as N,
    R as y,
    G as b,
    H as C
} from "./index.B4-7gKq3.js";
import {
    n as g
} from "./index.Cpg-fJ3N.js";
import {
    d as r,
    w as c
} from "./index.C2-CG2CN.js";
const f = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "query",
            name: {
                kind: "Name",
                value: "UserBalances"
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "balances"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "available"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "amount"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "currency"
                                            }
                                        }]
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "vault"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "amount"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "currency"
                                            }
                                        }]
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }]
    },
    q = c(!1),
    S = (() => {
        const n = u.mapValues(F, () => ({
                available: 0,
                vault: 0
            })),
            a = t => u.fromPairs(t.map(i => [i.available.currency, {
                available: i.available.amount,
                vault: i.vault.amount
            }])),
            l = (() => {
                var t; {
                    const s = v().readQuery(f);
                    if ((t = s == null ? void 0 : s.data) != null && t.user) return a(s.data.user.balances)
                }
                return n
            })(),
            e = c(l);
        return { ...e,
            updateBalance: (t, i) => {
                e.update(s => ({ ...s,
                    [t]: i(s[t])
                }))
            },
            rawSet: t => {
                e.set(a(t))
            },
            changeCurrencyAvailable: t => {
                e.update(i => ({ ...i,
                    [t.currency]: { ...i[t.currency],
                        available: t.amount
                    }
                }))
            },
            changeCurrencyVault: t => {
                e.update(i => ({ ...i,
                    [t.currency]: { ...i[t.currency],
                        vault: t.amount
                    }
                }))
            },
            fetch: async () => {
                var m, k;
                const s = (k = (m = (await v().query(f, {}, {
                    requestPolicy: "network-only"
                }).toPromise()).data) == null ? void 0 : m.user) == null ? void 0 : k.balances;
                s && e.update(B => ({ ...B,
                    ...a(s)
                }))
            }
        }
    })(),
    A = (() => {
        const n = c({}),
            {
                update: a
            } = n;
        return { ...n,
            updateDeduction: ({
                balance: l,
                deduction: e,
                type: o = "available"
            }) => {
                a(t => {
                    if (e.id in t) {
                        const i = t[e.id],
                            s = ("amount" in i ? i.amount : 0) + e.amount;
                        t[e.id] = {
                            type: "available",
                            ...i,
                            ...e,
                            amount: s
                        }
                    }
                    return t
                }), S.updateBalance(l.currency, t => ({ ...t,
                    [o]: l.amount
                }))
            },
            generate: l => {
                const e = g();
                return a(o => ({ ...o,
                    [e]: {
                        type: "available",
                        ...l
                    }
                })), e
            },
            remove: l => {
                a(e => u.omit(e, l))
            },
            removeByGame: l => {
                a(e => u.pickBy(e, o => o.game !== l))
            }
        }
    })(),
    w = r(A, n => ({
        available: [],
        vault: [],
        ...u.groupBy(u.map(n, (a, l) => ({
            id: l,
            ...a
        })).filter(a => "amount" in a && "type" in a), a => a.type)
    })),
    h = r(w, n => u.mapValues(n, a => u.reduce(a, (l, e) => (e.currency in l ? l[e.currency] += e.amount : l[e.currency] = e.amount, l), {}))),
    d = r([S, h], ([n, a]) => u.mapValues(n, (l, e) => {
        var o, t;
        return { ...l,
            vault: p(l.vault - (((o = a == null ? void 0 : a.vault) == null ? void 0 : o[e]) || 0), e),
            available: p(l.available - (((t = a == null ? void 0 : a.available) == null ? void 0 : t[e]) || 0), e)
        }
    })),
    E = r([d], ([n]) => Object.keys(n).filter(a => n[a].available)),
    P = r([d], ([n]) => Object.keys(n).filter(a => (n[a].available || n[a].vault) && a in N)),
    G = r([d, y, b], ([n, a, l]) => {
        const e = Object.keys(n),
            o = l === "crypto" ? "usd" : l;
        let t = 0;
        return e.forEach(i => {
            var m;
            const s = (m = a == null ? void 0 : a.rates) != null && m[i] ? a.rates[i][o] * n[i].available : n[i].available;
            t += s
        }), t
    }),
    U = r([d, y, b], ([n, a, l]) => {
        const e = Object.keys(n),
            o = l === "crypto" ? "usd" : l;
        let t = 0;
        return e.forEach(i => {
            var m;
            const s = (m = a == null ? void 0 : a.rates) != null && m[i] ? a.rates[i][o] * n[i].vault : n[i].vault;
            t += s
        }), t
    }),
    x = r([d, C], ([n, a]) => n[a].available),
    H = c(!1);
export {
    P as a, d as b, G as c, x as d, A as e, E as f, H as i, q as l, S as r, U as t
};