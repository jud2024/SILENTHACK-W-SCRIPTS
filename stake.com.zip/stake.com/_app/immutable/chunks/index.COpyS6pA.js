import {
    s as Y,
    e as S,
    O as M,
    d as I,
    f as R,
    P as E,
    i as g,
    F as B,
    V as Q,
    j as b,
    k as P,
    c as A,
    t as L,
    h as O,
    l as Z,
    m as W,
    n as fe,
    S as Ke,
    K as ie,
    J as Ae,
    a3 as Xe,
    a7 as ze,
    q as Qe,
    L as ve,
    X as _e,
    M as xe,
    a as ee,
    u as te,
    g as ne,
    b as re,
    R as oe,
    a5 as ye
} from "./scheduler.DXu26z7T.js";
import {
    S as G,
    i as J,
    c as y,
    a as C,
    m as $,
    t as h,
    g as F,
    b as p,
    e as j,
    d as k,
    h as Te
} from "./index.Dz_MmNB3.js";
import {
    D as et,
    a as tt,
    b as nt
} from "./DropdownContent.DaecMGoH.js";
import {
    D as rt
} from "./DropdownArrow.C_ADoLvp.js";
import {
    T as H,
    s as lt
} from "./index.D7nbRHfU.js";
import {
    R as it,
    G as at,
    bm as ce,
    cg as se,
    q as $e,
    h as z,
    bb as ct,
    i as me,
    ch as st,
    a6 as ot
} from "./index.B4-7gKq3.js";
import {
    b as qe,
    l as Le
} from "./index.BxooaYHE.js";
import {
    w as ut
} from "./index.DO-ZTgvx.js";
import {
    b as ke
} from "./index.B3dW9TVs.js";
import {
    e as Ce,
    u as ft,
    o as _t
} from "./each.DvgCmocI.js";
import {
    g as de,
    a as he
} from "./spread.CgU5AtxT.js";
import "./index.ByMdEFI5.js";
import {
    C as mt
} from "./index.Na6KaqFL.js";
import {
    P as Oe
} from "./index.B1KDSkU5.js";
import {
    a as dt
} from "./index.CY6-K88d.js";
import {
    a as ht,
    F as pt,
    C as ue
} from "./index.CAbJJJ2j.js";
import {
    c as gt
} from "./clickOutside.B3QPj_Ml.js";
import {
    a as wt
} from "./index.Dx3GbCCc.js";
import {
    W as bt,
    m as vt
} from "./utils.92_vUFxq.js";
import {
    d as Ve
} from "./index.B81orGJm.js";
import {
    c as x
} from "./index.BljstGtu.js";
import {
    S as yt
} from "./Search.Dsf-x3-k.js";
import {
    B as Ue
} from "./button.BwmFDw8u.js";
import {
    c as He
} from "./stores.C1s9-Gyh.js";
import {
    s as $t
} from "./utils.Q9FbZDbP.js";

function kt(i) {
    let e = (i[1] in ce ? ce[i[1]] : i[1].toUpperCase()) + "",
        n;
    return {
        c() {
            n = L(e)
        },
        l(t) {
            n = O(t, e)
        },
        m(t, r) {
            b(t, n, r)
        },
        p(t, r) {
            r & 2 && e !== (e = (t[1] in ce ? ce[t[1]] : t[1].toUpperCase()) + "") && Z(n, e)
        },
        d(t) {
            t && g(n)
        }
    }
}

function Ct(i) {
    let e = (i[1] in se ? se[i[1]] : i[1].toUpperCase()) + "",
        n;
    return {
        c() {
            n = L(e)
        },
        l(t) {
            n = O(t, e)
        },
        m(t, r) {
            b(t, n, r)
        },
        p(t, r) {
            r & 2 && e !== (e = (t[1] in se ? se[t[1]] : t[1].toUpperCase()) + "") && Z(n, e)
        },
        d(t) {
            t && g(n)
        }
    }
}

function De(i) {
    let e, n, t, r, l;
    t = new H({
        props: {
            weight: "semibold",
            variant: "highlighted",
            lineHeight: "120pct",
            numeric: !0,
            $$slots: {
                default: [Bt]
            },
            $$scope: {
                ctx: i
            }
        }
    });
    let a = !i[3] && Be(i);
    return {
        c() {
            e = S("div"), n = S("span"), y(t.$$.fragment), r = M(), a && a.c(), this.h()
        },
        l(s) {
            e = I(s, "DIV", {
                class: !0
            });
            var c = R(e);
            n = I(c, "SPAN", {
                class: !0
            });
            var o = R(n);
            C(t.$$.fragment, o), o.forEach(g), r = E(c), a && a.l(c), c.forEach(g), this.h()
        },
        h() {
            B(n, "class", "content svelte-1la41np"), B(e, "class", "value-ctainer svelte-1la41np")
        },
        m(s, c) {
            b(s, e, c), P(e, n), $(t, n, null), P(e, r), a && a.m(e, null), l = !0
        },
        p(s, c) {
            const o = {};
            c & 2051 && (o.$$scope = {
                dirty: c,
                ctx: s
            }), t.$set(o), s[3] ? a && (F(), p(a, 1, 1, () => {
                a = null
            }), j()) : a ? (a.p(s, c), c & 8 && h(a, 1)) : (a = Be(s), a.c(), h(a, 1), a.m(e, null))
        },
        i(s) {
            l || (h(t.$$.fragment, s), h(a), l = !0)
        },
        o(s) {
            p(t.$$.fragment, s), p(a), l = !1
        },
        d(s) {
            s && g(e), k(t), a && a.d()
        }
    }
}

function Vt(i) {
    let e, n;
    return e = new ht({
        props: {
            currency: i[1],
            value: Number(i[0])
        }
    }), {
        c() {
            y(e.$$.fragment)
        },
        l(t) {
            C(e.$$.fragment, t)
        },
        m(t, r) {
            $(e, t, r), n = !0
        },
        p(t, r) {
            const l = {};
            r & 2 && (l.currency = t[1]), r & 1 && (l.value = Number(t[0])), e.$set(l)
        },
        i(t) {
            n || (h(e.$$.fragment, t), n = !0)
        },
        o(t) {
            p(e.$$.fragment, t), n = !1
        },
        d(t) {
            k(e, t)
        }
    }
}

function Dt(i) {
    let e;
    return {
        c() {
            e = L(i[0])
        },
        l(n) {
            e = O(n, i[0])
        },
        m(n, t) {
            b(n, e, t)
        },
        p(n, t) {
            t & 1 && Z(e, n[0])
        },
        i: fe,
        o: fe,
        d(n) {
            n && g(e)
        }
    }
}

function Bt(i) {
    let e, n, t, r, l;
    const a = [Dt, Vt],
        s = [];

    function c(o, f) {
        return f & 1 && (e = null), e == null && (e = !!Number.isNaN(Number(o[0]))), e ? 0 : 1
    }
    return n = c(i, -1), t = s[n] = a[n](i), {
        c() {
            t.c(), r = W()
        },
        l(o) {
            t.l(o), r = W()
        },
        m(o, f) {
            s[n].m(o, f), b(o, r, f), l = !0
        },
        p(o, f) {
            let d = n;
            n = c(o, f), n === d ? s[n].p(o, f) : (F(), p(s[d], 1, 1, () => {
                s[d] = null
            }), j(), t = s[n], t ? t.p(o, f) : (t = s[n] = a[n](o), t.c()), h(t, 1), t.m(r.parentNode, r))
        },
        i(o) {
            l || (h(t), l = !0)
        },
        o(o) {
            p(t), l = !1
        },
        d(o) {
            o && g(r), s[n].d(o)
        }
    }
}

function Be(i) {
    let e, n, t;
    return n = new H({
        props: {
            size: "sm",
            lineHeight: "120pct",
            numeric: !0,
            $$slots: {
                default: [Rt]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            e = S("span"), y(n.$$.fragment), this.h()
        },
        l(r) {
            e = I(r, "SPAN", {
                class: !0
            });
            var l = R(e);
            C(n.$$.fragment, l), l.forEach(g), this.h()
        },
        h() {
            B(e, "class", "content svelte-1la41np")
        },
        m(r, l) {
            b(r, e, l), $(n, e, null), t = !0
        },
        p(r, l) {
            const a = {};
            l & 2548 && (a.$$scope = {
                dirty: l,
                ctx: r
            }), n.$set(a)
        },
        i(r) {
            t || (h(n.$$.fragment, r), t = !0)
        },
        o(r) {
            p(n.$$.fragment, r), t = !1
        },
        d(r) {
            r && g(e), k(n)
        }
    }
}

function St(i) {
    let e, n;
    return e = new Oe({
        props: {
            width: "10ch"
        }
    }), {
        c() {
            y(e.$$.fragment)
        },
        l(t) {
            C(e.$$.fragment, t)
        },
        m(t, r) {
            $(e, t, r), n = !0
        },
        p: fe,
        i(t) {
            n || (h(e.$$.fragment, t), n = !0)
        },
        o(t) {
            p(e.$$.fragment, t), n = !1
        },
        d(t) {
            k(e, t)
        }
    }
}

function It(i) {
    let e, n, t, r;
    e = new pt({
        props: {
            fiatRounding: i[2],
            currency: $e[i[6]],
            showTooltip: !1,
            value: i[8],
            view: i[7],
            maximumFractionDigits: i[5],
            minimumFractionDigits: i[4]
        }
    });
    let l = (i[7] === "crypto" || i[7] === "usd") && Se();
    return {
        c() {
            y(e.$$.fragment), n = M(), l && l.c(), t = W()
        },
        l(a) {
            C(e.$$.fragment, a), n = E(a), l && l.l(a), t = W()
        },
        m(a, s) {
            $(e, a, s), b(a, n, s), l && l.m(a, s), b(a, t, s), r = !0
        },
        p(a, s) {
            const c = {};
            s & 4 && (c.fiatRounding = a[2]), s & 64 && (c.currency = $e[a[6]]), s & 256 && (c.value = a[8]), s & 128 && (c.view = a[7]), s & 32 && (c.maximumFractionDigits = a[5]), s & 16 && (c.minimumFractionDigits = a[4]), e.$set(c), a[7] === "crypto" || a[7] === "usd" ? l || (l = Se(), l.c(), l.m(t.parentNode, t)) : l && (l.d(1), l = null)
        },
        i(a) {
            r || (h(e.$$.fragment, a), r = !0)
        },
        o(a) {
            p(e.$$.fragment, a), r = !1
        },
        d(a) {
            a && (g(n), g(t)), k(e, a), l && l.d(a)
        }
    }
}

function Se(i) {
    let e, n = "USD";
    return {
        c() {
            e = S("span"), e.textContent = n
        },
        l(t) {
            e = I(t, "SPAN", {
                "data-svelte-h": !0
            }), Ke(e) !== "svelte-17ki20m" && (e.textContent = n)
        },
        m(t, r) {
            b(t, e, r)
        },
        d(t) {
            t && g(e)
        }
    }
}

function Rt(i) {
    let e, n, t, r;
    const l = [It, St],
        a = [];

    function s(c, o) {
        return c[8] !== void 0 ? 0 : 1
    }
    return e = s(i), n = a[e] = l[e](i), {
        c() {
            n.c(), t = W()
        },
        l(c) {
            n.l(c), t = W()
        },
        m(c, o) {
            a[e].m(c, o), b(c, t, o), r = !0
        },
        p(c, o) {
            let f = e;
            e = s(c), e === f ? a[e].p(c, o) : (F(), p(a[f], 1, 1, () => {
                a[f] = null
            }), j(), n = a[e], n ? n.p(c, o) : (n = a[e] = l[e](c), n.c()), h(n, 1), n.m(t.parentNode, t))
        },
        i(c) {
            r || (h(n), r = !0)
        },
        o(c) {
            p(n), r = !1
        },
        d(c) {
            c && g(t), a[e].d(c)
        }
    }
}

function Nt(i) {
    let e, n, t, r, l, a, s, c, o, f;
    t = new mt({
        props: {
            currency: i[1]
        }
    }), a = new H({
        props: {
            weight: "semibold",
            variant: "highlighted",
            lineHeight: "120pct",
            $$slots: {
                default: [kt]
            },
            $$scope: {
                ctx: i
            }
        }
    }), c = new H({
        props: {
            size: "sm",
            lineHeight: "120pct",
            $$slots: {
                default: [Ct]
            },
            $$scope: {
                ctx: i
            }
        }
    });
    let d = i[0] !== void 0 && De(i);
    return {
        c() {
            e = S("div"), n = S("div"), y(t.$$.fragment), r = M(), l = S("div"), y(a.$$.fragment), s = M(), y(c.$$.fragment), o = M(), d && d.c(), this.h()
        },
        l(u) {
            e = I(u, "DIV", {
                class: !0
            });
            var m = R(e);
            n = I(m, "DIV", {
                class: !0
            });
            var _ = R(n);
            C(t.$$.fragment, _), r = E(_), l = I(_, "DIV", {
                class: !0
            });
            var v = R(l);
            C(a.$$.fragment, v), s = E(v), C(c.$$.fragment, v), v.forEach(g), _.forEach(g), o = E(m), d && d.l(m), m.forEach(g), this.h()
        },
        h() {
            B(l, "class", "currency-ctainer svelte-1la41np"), B(n, "class", "currency-details svelte-1la41np"), B(e, "class", "ctainer svelte-1la41np"), Q(e, "hide-conversion", i[3])
        },
        m(u, m) {
            b(u, e, m), P(e, n), $(t, n, null), P(n, r), P(n, l), $(a, l, null), P(l, s), $(c, l, null), P(e, o), d && d.m(e, null), f = !0
        },
        p(u, [m]) {
            const _ = {};
            m & 2 && (_.currency = u[1]), t.$set(_);
            const v = {};
            m & 2050 && (v.$$scope = {
                dirty: m,
                ctx: u
            }), a.$set(v);
            const N = {};
            m & 2050 && (N.$$scope = {
                dirty: m,
                ctx: u
            }), c.$set(N), u[0] !== void 0 ? d ? (d.p(u, m), m & 1 && h(d, 1)) : (d = De(u), d.c(), h(d, 1), d.m(e, null)) : d && (F(), p(d, 1, 1, () => {
                d = null
            }), j()), (!f || m & 8) && Q(e, "hide-conversion", u[3])
        },
        i(u) {
            f || (h(t.$$.fragment, u), h(a.$$.fragment, u), h(c.$$.fragment, u), h(d), f = !0)
        },
        o(u) {
            p(t.$$.fragment, u), p(a.$$.fragment, u), p(c.$$.fragment, u), p(d), f = !1
        },
        d(u) {
            u && g(e), k(t), k(a), k(c), d && d.d()
        }
    }
}

function Wt(i, e, n) {
    let t, r, l, a, s;
    A(i, it, _ => n(9, l = _)), A(i, at, _ => n(7, a = _)), A(i, dt, _ => n(10, s = _));
    let {
        value: c = void 0
    } = e, {
        currency: o
    } = e, {
        fiatRounding: f = "round"
    } = e, {
        hideConversion: d = !1
    } = e, {
        minimumFractionDigits: u = 2
    } = e, {
        maximumFractionDigits: m = 2
    } = e;
    return i.$$set = _ => {
        "value" in _ && n(0, c = _.value), "currency" in _ && n(1, o = _.currency), "fiatRounding" in _ && n(2, f = _.fiatRounding), "hideConversion" in _ && n(3, d = _.hideConversion), "minimumFractionDigits" in _ && n(4, u = _.minimumFractionDigits), "maximumFractionDigits" in _ && n(5, m = _.maximumFractionDigits)
    }, i.$$.update = () => {
        var _;
        i.$$.dirty & 1024 && lt(s ? "12ch" : "22ch"), i.$$.dirty & 128 && n(6, t = a === "crypto" ? "usd" : a), i.$$.dirty & 579 && n(8, r = ((_ = l == null ? void 0 : l.rates) == null ? void 0 : _[o]) && l.rates[o][t] * Number(c))
    }, [c, o, f, d, u, m, t, a, r, l, s]
}
class pe extends G {
    constructor(e) {
        super(), J(this, e, Wt, Nt, Y, {
            value: 0,
            currency: 1,
            fiatRounding: 2,
            hideConversion: 3,
            minimumFractionDigits: 4,
            maximumFractionDigits: 5
        })
    }
}
const Mt = i => ({}),
    Ie = i => ({
        slot: "label"
    }),
    Et = i => ({}),
    Re = i => ({}),
    Ft = i => ({}),
    Ne = i => ({}),
    jt = i => ({}),
    We = i => ({});

function Pt(i) {
    let e;
    const n = i[7].label,
        t = ee(n, i, i[14], Ie);
    return {
        c() {
            t && t.c()
        },
        l(r) {
            t && t.l(r)
        },
        m(r, l) {
            t && t.m(r, l), e = !0
        },
        p(r, l) {
            t && t.p && (!e || l & 16384) && te(t, n, r, r[14], e ? re(n, r[14], l, Mt) : ne(r[14]), Ie)
        },
        i(r) {
            e || (h(t, r), e = !0)
        },
        o(r) {
            p(t, r), e = !1
        },
        d(r) {
            t && t.d(r)
        }
    }
}

function At(i) {
    let e;
    const n = i[7].buttons,
        t = ee(n, i, i[14], Re);
    return {
        c() {
            t && t.c()
        },
        l(r) {
            t && t.l(r)
        },
        m(r, l) {
            t && t.m(r, l), e = !0
        },
        p(r, l) {
            t && t.p && (!e || l & 16384) && te(t, n, r, r[14], e ? re(n, r[14], l, Et) : ne(r[14]), Re)
        },
        i(r) {
            e || (h(t, r), e = !0)
        },
        o(r) {
            p(t, r), e = !1
        },
        d(r) {
            t && t.d(r)
        }
    }
}

function zt(i) {
    let e;
    const n = i[7].afterIcon,
        t = ee(n, i, i[14], Ne);
    return {
        c() {
            t && t.c()
        },
        l(r) {
            t && t.l(r)
        },
        m(r, l) {
            t && t.m(r, l), e = !0
        },
        p(r, l) {
            t && t.p && (!e || l & 16384) && te(t, n, r, r[14], e ? re(n, r[14], l, Ft) : ne(r[14]), Ne)
        },
        i(r) {
            e || (h(t, r), e = !0)
        },
        o(r) {
            p(t, r), e = !1
        },
        d(r) {
            t && t.d(r)
        }
    }
}

function Tt(i) {
    let e;
    const n = i[7].iconBefore,
        t = ee(n, i, i[14], We);
    return {
        c() {
            t && t.c()
        },
        l(r) {
            t && t.l(r)
        },
        m(r, l) {
            t && t.m(r, l), e = !0
        },
        p(r, l) {
            t && t.p && (!e || l & 16384) && te(t, n, r, r[14], e ? re(n, r[14], l, jt) : ne(r[14]), We)
        },
        i(r) {
            e || (h(t, r), e = !0)
        },
        o(r) {
            p(t, r), e = !1
        },
        d(r) {
            t && t.d(r)
        }
    }
}

function Me(i) {
    let e, n;
    const t = i[7].default,
        r = ee(t, i, i[14], null);
    return {
        c() {
            e = S("div"), r && r.c(), this.h()
        },
        l(l) {
            e = I(l, "DIV", {
                class: !0
            });
            var a = R(e);
            r && r.l(a), a.forEach(g), this.h()
        },
        h() {
            B(e, "class", "search-content svelte-xyfpr4")
        },
        m(l, a) {
            b(l, e, a), r && r.m(e, null), n = !0
        },
        p(l, a) {
            r && r.p && (!n || a & 16384) && te(r, t, l, l[14], n ? re(t, l[14], a, null) : ne(l[14]), null)
        },
        i(l) {
            n || (h(r, l), n = !0)
        },
        o(l) {
            p(r, l), n = !1
        },
        d(l) {
            l && g(e), r && r.d(l)
        }
    }
}

function qt(i) {
    let e, n, t, r, l, a, s, c, o;
    const f = [i[5], {
        value: i[1]
    }];

    function d(_) {
        i[8](_)
    }
    let u = {
        $$slots: {
            iconBefore: [Tt],
            afterIcon: [zt],
            buttons: [At],
            label: [Pt]
        },
        $$scope: {
            ctx: i
        }
    };
    for (let _ = 0; _ < f.length; _ += 1) u = ie(u, f[_]);
    i[0] !== void 0 && (u.inputRef = i[0]), t = new wt({
        props: u
    }), Ae.push(() => Te(t, "inputRef", d)), t.$on("focus", i[9]), t.$on("blur", i[10]), t.$on("input", i[11]), t.$on("click", i[12]);
    let m = i[3] && Me(i);
    return {
        c() {
            e = S("div"), n = S("div"), y(t.$$.fragment), l = M(), m && m.c(), this.h()
        },
        l(_) {
            e = I(_, "DIV", {
                class: !0
            });
            var v = R(e);
            n = I(v, "DIV", {
                class: !0
            });
            var N = R(n);
            C(t.$$.fragment, N), N.forEach(g), l = E(v), m && m.l(v), v.forEach(g), this.h()
        },
        h() {
            B(n, "class", "search-wrapper svelte-xyfpr4"), Q(n, "show-content", i[3]), B(e, "class", "input-search svelte-xyfpr4"), Q(e, "raise", i[3])
        },
        m(_, v) {
            b(_, e, v), P(e, n), $(t, n, null), P(e, l), m && m.m(e, null), s = !0, c || (o = Xe(a = gt.call(null, e, i[13])), c = !0)
        },
        p(_, [v]) {
            const N = v & 34 ? de(f, [v & 32 && he(_[5]), v & 2 && {
                value: _[1]
            }]) : {};
            v & 16384 && (N.$$scope = {
                dirty: v,
                ctx: _
            }), !r && v & 1 && (r = !0, N.inputRef = _[0], ze(() => r = !1)), t.$set(N), (!s || v & 8) && Q(n, "show-content", _[3]), _[3] ? m ? (m.p(_, v), v & 8 && h(m, 1)) : (m = Me(_), m.c(), h(m, 1), m.m(e, null)) : m && (F(), p(m, 1, 1, () => {
                m = null
            }), j()), a && Qe(a.update) && v & 4 && a.update.call(null, _[13]), (!s || v & 8) && Q(e, "raise", _[3])
        },
        i(_) {
            s || (h(t.$$.fragment, _), h(m), s = !0)
        },
        o(_) {
            p(t.$$.fragment, _), p(m), s = !1
        },
        d(_) {
            _ && g(e), k(t), m && m.d(), c = !1, o()
        }
    }
}

function Lt(i, e, n) {
    let t;
    const r = ["value", "showSearchContent", "inputRef"];
    let l = ve(e, r),
        {
            $$slots: a = {},
            $$scope: s
        } = e;
    const c = _e();
    let {
        value: o
    } = e, {
        showSearchContent: f
    } = e, {
        inputRef: d = void 0
    } = e, u = !1;

    function m(D) {
        d = D, n(0, d)
    }
    const _ = D => {
            n(2, u = !0), c("focus", D.detail)
        },
        v = D => {
            c("blur", D.detail)
        },
        N = D => c("input", D.detail),
        K = D => {
            c("click", D.detail)
        },
        X = () => {
            n(2, u = !1)
        };
    return i.$$set = D => {
        e = ie(ie({}, e), xe(D)), n(5, l = ve(e, r)), "value" in D && n(1, o = D.value), "showSearchContent" in D && n(6, f = D.showSearchContent), "inputRef" in D && n(0, d = D.inputRef), "$$scope" in D && n(14, s = D.$$scope)
    }, i.$$.update = () => {
        i.$$.dirty & 68 && n(3, t = f && u)
    }, [d, o, u, t, c, l, f, a, m, _, v, N, K, X, s]
}
class Ot extends G {
    constructor(e) {
        super(), J(this, e, Lt, qt, Y, {
            value: 1,
            showSearchContent: 6,
            inputRef: 0
        })
    }
}
const T = {
    inPlay: z._("In Play"),
    view: z._("Display crypto in fiat"),
    crypto: z._("Crypto"),
    fiat: z._("Banking"),
    sweeps: z._("Sweeps"),
    currency: z._("Currency"),
    settings: z._("Wallet Settings"),
    addCurrencies: z._("Add Currencies"),
    viewTerms: z._("All bets & transactions will be settled in the crypto equivalent"),
    add: z._("Add"),
    noCurrencies: z._("Currency not available"),
    search: z._("Search"),
    searchCurrencies: z._("Search Currencies")
};

function Ee(i, e, n) {
    const t = i.slice();
    return t[17] = e[n], t
}

function Ut(i) {
    let e, n, t, r, l;

    function a(c) {
        i[12](c)
    }
    let s = {
        placeholder: i[3] === "noBalance" ? i[8]._(T.search) : i[8]._(T.searchCurrencies),
        type: "search",
        showSearchContent: !1,
        value: i[5],
        style: i[4] === "compact" && `background-color: white; border: 2px solid var(--grey-100); color: var(--grey-400); max-width: ${i[3]==="noBalance"?"7rem":""}`,
        $$slots: {
            iconBefore: [Ht]
        },
        $$scope: {
            ctx: i
        }
    };
    return i[6] !== void 0 && (s.inputRef = i[6]), n = new Ot({
        props: s
    }), Ae.push(() => Te(n, "inputRef", a)), n.$on("input", i[13]), n.$on("click", i[14]), {
        c() {
            e = S("div"), y(n.$$.fragment), this.h()
        },
        l(c) {
            e = I(c, "DIV", {
                class: !0
            });
            var o = R(e);
            C(n.$$.fragment, o), o.forEach(g), this.h()
        },
        h() {
            B(e, "class", r = "wrapper currency-view-" + i[4] + " svelte-mdrjfw")
        },
        m(c, o) {
            b(c, e, o), $(n, e, null), l = !0
        },
        p(c, o) {
            const f = {};
            o & 264 && (f.placeholder = c[3] === "noBalance" ? c[8]._(T.search) : c[8]._(T.searchCurrencies)), o & 32 && (f.value = c[5]), o & 24 && (f.style = c[4] === "compact" && `background-color: white; border: 2px solid var(--grey-100); color: var(--grey-400); max-width: ${c[3]==="noBalance"?"7rem":""}`), o & 1048576 && (f.$$scope = {
                dirty: o,
                ctx: c
            }), !t && o & 64 && (t = !0, f.inputRef = c[6], ze(() => t = !1)), n.$set(f), (!l || o & 16 && r !== (r = "wrapper currency-view-" + c[4] + " svelte-mdrjfw")) && B(e, "class", r)
        },
        i(c) {
            l || (h(n.$$.fragment, c), l = !0)
        },
        o(c) {
            p(n.$$.fragment, c), l = !1
        },
        d(c) {
            c && g(e), k(n)
        }
    }
}

function Ht(i) {
    let e, n;
    return e = new yt({}), {
        c() {
            y(e.$$.fragment)
        },
        l(t) {
            C(e.$$.fragment, t)
        },
        m(t, r) {
            $(e, t, r), n = !0
        },
        i(t) {
            n || (h(e.$$.fragment, t), n = !0)
        },
        o(t) {
            p(e.$$.fragment, t), n = !1
        },
        d(t) {
            k(e, t)
        }
    }
}

function Yt(i) {
    let e, n;
    return e = new H({
        props: {
            weight: "semibold",
            size: "sm",
            style: "color: var(--grey-400); display: flex; justify-content: center; padding: var(--space-2);",
            $$slots: {
                default: [Gt]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            y(e.$$.fragment)
        },
        l(t) {
            C(e.$$.fragment, t)
        },
        m(t, r) {
            $(e, t, r), n = !0
        },
        p(t, r) {
            const l = {};
            r & 1048832 && (l.$$scope = {
                dirty: r,
                ctx: t
            }), e.$set(l)
        },
        i(t) {
            n || (h(e.$$.fragment, t), n = !0)
        },
        o(t) {
            p(e.$$.fragment, t), n = !1
        },
        d(t) {
            k(e, t)
        }
    }
}

function Zt(i) {
    let e, n = [],
        t = new Map,
        r, l, a = Ce(i[7]);
    const s = c => c[17].currency;
    for (let c = 0; c < a.length; c += 1) {
        let o = Ee(i, a, c),
            f = s(o);
        t.set(f, n[c] = Fe(f, o))
    }
    return {
        c() {
            e = S("div");
            for (let c = 0; c < n.length; c += 1) n[c].c();
            this.h()
        },
        l(c) {
            e = I(c, "DIV", {
                class: !0
            });
            var o = R(e);
            for (let f = 0; f < n.length; f += 1) n[f].l(o);
            o.forEach(g), this.h()
        },
        h() {
            B(e, "class", r = "content-wrapper scrollY scroll-light currency-view-" + i[4] + " svelte-mdrjfw")
        },
        m(c, o) {
            b(c, e, o);
            for (let f = 0; f < n.length; f += 1) n[f] && n[f].m(e, null);
            l = !0
        },
        p(c, o) {
            o & 670 && (a = Ce(c[7]), F(), n = ft(n, o, s, 1, c, a, t, e, _t, Fe, null, Ee), j()), (!l || o & 16 && r !== (r = "content-wrapper scrollY scroll-light currency-view-" + c[4] + " svelte-mdrjfw")) && B(e, "class", r)
        },
        i(c) {
            if (!l) {
                for (let o = 0; o < a.length; o += 1) h(n[o]);
                l = !0
            }
        },
        o(c) {
            for (let o = 0; o < n.length; o += 1) p(n[o]);
            l = !1
        },
        d(c) {
            c && g(e);
            for (let o = 0; o < n.length; o += 1) n[o].d()
        }
    }
}

function Gt(i) {
    let e = i[8]._(T.noCurrencies) + "",
        n;
    return {
        c() {
            n = L(e)
        },
        l(t) {
            n = O(t, e)
        },
        m(t, r) {
            b(t, n, r)
        },
        p(t, r) {
            r & 256 && e !== (e = t[8]._(T.noCurrencies) + "") && Z(n, e)
        },
        d(t) {
            t && g(n)
        }
    }
}

function Jt(i) {
    let e, n;
    const t = [i[17], {
        value: i[3] === "noBalance" ? void 0 : i[17].value
    }];
    let r = {};
    for (let l = 0; l < t.length; l += 1) r = ie(r, t[l]);
    return e = new pe({
        props: r
    }), {
        c() {
            y(e.$$.fragment)
        },
        l(l) {
            C(e.$$.fragment, l)
        },
        m(l, a) {
            $(e, l, a), n = !0
        },
        p(l, a) {
            const s = a & 136 ? de(t, [a & 128 && he(l[17]), {
                value: l[3] === "noBalance" ? void 0 : l[17].value
            }]) : {};
            e.$set(s)
        },
        i(l) {
            n || (h(e.$$.fragment, l), n = !0)
        },
        o(l) {
            p(e.$$.fragment, l), n = !1
        },
        d(l) {
            k(e, l)
        }
    }
}

function Kt(i) {
    let e, n;
    const t = [{
        fixWidth: !0
    }, {
        symbolAfter: !0
    }, {
        showTooltip: !1
    }, {
        weight: "semibold"
    }, {
        variant: "inherit"
    }, {
        truncateMaxWidth: i[1]
    }, i[17], {
        value: i[3] === "noBalance" ? void 0 : i[17].value
    }];
    let r = {};
    for (let l = 0; l < t.length; l += 1) r = ie(r, t[l]);
    return e = new ue({
        props: r
    }), {
        c() {
            y(e.$$.fragment)
        },
        l(l) {
            C(e.$$.fragment, l)
        },
        m(l, a) {
            $(e, l, a), n = !0
        },
        p(l, a) {
            const s = a & 138 ? de(t, [t[0], t[1], t[2], t[3], t[4], a & 2 && {
                truncateMaxWidth: l[1]
            }, a & 128 && he(l[17]), a & 136 && {
                value: l[3] === "noBalance" ? void 0 : l[17].value
            }]) : {};
            e.$set(s)
        },
        i(l) {
            n || (h(e.$$.fragment, l), n = !0)
        },
        o(l) {
            p(e.$$.fragment, l), n = !1
        },
        d(l) {
            k(e, l)
        }
    }
}

function Xt(i) {
    let e, n, t, r;
    const l = [Kt, Jt],
        a = [];

    function s(c, o) {
        return c[4] === "compact" ? 0 : 1
    }
    return e = s(i), n = a[e] = l[e](i), {
        c() {
            n.c(), t = M()
        },
        l(c) {
            n.l(c), t = E(c)
        },
        m(c, o) {
            a[e].m(c, o), b(c, t, o), r = !0
        },
        p(c, o) {
            let f = e;
            e = s(c), e === f ? a[e].p(c, o) : (F(), p(a[f], 1, 1, () => {
                a[f] = null
            }), j(), n = a[e], n ? n.p(c, o) : (n = a[e] = l[e](c), n.c()), h(n, 1), n.m(t.parentNode, t))
        },
        i(c) {
            r || (h(n), r = !0)
        },
        o(c) {
            p(n), r = !1
        },
        d(c) {
            c && g(t), a[e].d(c)
        }
    }
}

function Fe(i, e) {
    let n, t, r;

    function l() {
        return e[15](e[17])
    }
    return t = new Ue({
        props: {
            size: "xs",
            "data-testid": "coin-toggle-currency-" + e[17].currency,
            "data-test": "coin-toggle-currency-" + e[17].currency,
            "aria-label": "Select " + e[17].currency,
            variant: e[2],
            class: x("justify-start px-3 py-[6px] shadow-none", (e[3] === "noBalance" && Ve !== "sweeps" || e[4] === "detailed") && "w-full rounded-none", e[4] === "detailed" && "py-2 px-4"),
            $$slots: {
                default: [Xt]
            },
            $$scope: {
                ctx: e
            }
        }
    }), t.$on("click", l), {
        key: i,
        first: null,
        c() {
            n = W(), y(t.$$.fragment), this.h()
        },
        l(a) {
            n = W(), C(t.$$.fragment, a), this.h()
        },
        h() {
            this.first = n
        },
        m(a, s) {
            b(a, n, s), $(t, a, s), r = !0
        },
        p(a, s) {
            e = a;
            const c = {};
            s & 128 && (c["data-testid"] = "coin-toggle-currency-" + e[17].currency), s & 128 && (c["data-test"] = "coin-toggle-currency-" + e[17].currency), s & 128 && (c["aria-label"] = "Select " + e[17].currency), s & 4 && (c.variant = e[2]), s & 24 && (c.class = x("justify-start px-3 py-[6px] shadow-none", (e[3] === "noBalance" && Ve !== "sweeps" || e[4] === "detailed") && "w-full rounded-none", e[4] === "detailed" && "py-2 px-4")), s & 1048730 && (c.$$scope = {
                dirty: s,
                ctx: e
            }), t.$set(c)
        },
        i(a) {
            r || (h(t.$$.fragment, a), r = !0)
        },
        o(a) {
            p(t.$$.fragment, a), r = !1
        },
        d(a) {
            a && g(n), k(t, a)
        }
    }
}

function je(i) {
    let e, n, t = Qt(i);
    return {
        c() {
            t && t.c(), e = W()
        },
        l(r) {
            t && t.l(r), e = W()
        },
        m(r, l) {
            t && t.m(r, l), b(r, e, l), n = !0
        },
        p(r, l) {
            t.p(r, l)
        },
        i(r) {
            n || (h(t), n = !0)
        },
        o(r) {
            p(t), n = !1
        },
        d(r) {
            r && g(e), t && t.d(r)
        }
    }
}

function Qt(i) {
    let e, n, t, r, l;
    return r = new Ue({
        props: {
            type: "button",
            size: "sm",
            class: "w-full",
            "data-testid": "open-wallet-settings",
            "data-test": "open-wallet-settings",
            $$slots: {
                default: [en]
            },
            $$scope: {
                ctx: i
            }
        }
    }), r.$on("click", i[16]), {
        c() {
            e = S("div"), n = M(), t = S("div"), y(r.$$.fragment), this.h()
        },
        l(a) {
            e = I(a, "DIV", {
                class: !0
            }), R(e).forEach(g), n = E(a), t = I(a, "DIV", {
                class: !0
            });
            var s = R(t);
            C(r.$$.fragment, s), s.forEach(g), this.h()
        },
        h() {
            B(e, "class", "divider svelte-mdrjfw"), B(t, "class", "open-wallet-button svelte-mdrjfw")
        },
        m(a, s) {
            b(a, e, s), b(a, n, s), b(a, t, s), $(r, t, null), l = !0
        },
        p(a, s) {
            const c = {};
            s & 1048832 && (c.$$scope = {
                dirty: s,
                ctx: a
            }), r.$set(c)
        },
        i(a) {
            l || (h(r.$$.fragment, a), l = !0)
        },
        o(a) {
            p(r.$$.fragment, a), l = !1
        },
        d(a) {
            a && (g(e), g(n), g(t)), k(r)
        }
    }
}

function xt(i) {
    let e = i[8]._(T.settings) + "",
        n;
    return {
        c() {
            n = L(e)
        },
        l(t) {
            n = O(t, e)
        },
        m(t, r) {
            b(t, n, r)
        },
        p(t, r) {
            r & 256 && e !== (e = t[8]._(T.settings) + "") && Z(n, e)
        },
        d(t) {
            t && g(n)
        }
    }
}

function en(i) {
    let e, n, t, r;
    return e = new bt({}), t = new H({
        props: {
            weight: "semibold",
            style: "color: var(--grey-400",
            $$slots: {
                default: [xt]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            y(e.$$.fragment), n = M(), y(t.$$.fragment)
        },
        l(l) {
            C(e.$$.fragment, l), n = E(l), C(t.$$.fragment, l)
        },
        m(l, a) {
            $(e, l, a), b(l, n, a), $(t, l, a), r = !0
        },
        p(l, a) {
            const s = {};
            a & 1048832 && (s.$$scope = {
                dirty: a,
                ctx: l
            }), t.$set(s)
        },
        i(l) {
            r || (h(e.$$.fragment, l), h(t.$$.fragment, l), r = !0)
        },
        o(l) {
            p(e.$$.fragment, l), p(t.$$.fragment, l), r = !1
        },
        d(l) {
            l && g(n), k(e, l), k(t, l)
        }
    }
}

function tn(i) {
    let e, n, t, r, l, a, s = Ut(i);
    const c = [Zt, Yt],
        o = [];

    function f(u, m) {
        return u[7].length !== 0 ? 0 : 1
    }
    n = f(i), t = o[n] = c[n](i);
    let d = i[0] && je(i);
    return {
        c() {
            s && s.c(), e = M(), t.c(), r = M(), d && d.c(), l = W()
        },
        l(u) {
            s && s.l(u), e = E(u), t.l(u), r = E(u), d && d.l(u), l = W()
        },
        m(u, m) {
            s && s.m(u, m), b(u, e, m), o[n].m(u, m), b(u, r, m), d && d.m(u, m), b(u, l, m), a = !0
        },
        p(u, [m]) {
            s.p(u, m);
            let _ = n;
            n = f(u), n === _ ? o[n].p(u, m) : (F(), p(o[_], 1, 1, () => {
                o[_] = null
            }), j(), t = o[n], t ? t.p(u, m) : (t = o[n] = c[n](u), t.c()), h(t, 1), t.m(r.parentNode, r)), u[0] ? d ? (d.p(u, m), m & 1 && h(d, 1)) : (d = je(u), d.c(), h(d, 1), d.m(l.parentNode, l)) : d && (F(), p(d, 1, 1, () => {
                d = null
            }), j())
        },
        i(u) {
            a || (h(s), h(t), h(d), a = !0)
        },
        o(u) {
            p(s), p(t), p(d), a = !1
        },
        d(u) {
            u && (g(e), g(r), g(l)), s && s.d(u), o[n].d(u), d && d.d(u)
        }
    }
}

function nn(i, e, n) {
    let t, r, l;
    A(i, ct, V => n(11, r = V)), A(i, me, V => n(8, l = V));
    let {
        header: a = !1
    } = e, {
        truncateMaxWidth: s = "14ch"
    } = e, {
        variant: c = "dropdown"
    } = e, {
        view: o = "default"
    } = e, {
        currencyView: f = "compact"
    } = e, {
        balances: d
    } = e, u = "", m;
    const _ = _e();

    function v(V) {
        m = V, n(6, m)
    }
    const N = V => {
            var U, le;
            n(5, u = String((le = (U = V == null ? void 0 : V.detail) == null ? void 0 : U.target) == null ? void 0 : le.value))
        },
        K = () => {
            u !== "" && n(5, u = "")
        },
        X = V => {
            _("changeCurrency", V.currency), _("closeDropdown")
        },
        D = () => {
            _("closeDropdown"), vt.walletSettings.open()
        };
    return i.$$set = V => {
        "header" in V && n(0, a = V.header), "truncateMaxWidth" in V && n(1, s = V.truncateMaxWidth), "variant" in V && n(2, c = V.variant), "view" in V && n(3, o = V.view), "currencyView" in V && n(4, f = V.currencyView), "balances" in V && n(10, d = V.balances)
    }, i.$$.update = () => {
        i.$$.dirty & 3112 && n(7, t = d == null ? void 0 : d.filter(V => {
            if (u.trim() === "") return o !== "noBalance" && r ? Number(V.formattedForFilter) !== 0 : !0;
            const {
                name: U
            } = st[V.currency];
            return U.toLowerCase().includes(u.toLowerCase().replace("\\W+", "")) ? V : !1
        }))
    }, [a, s, c, o, f, u, m, t, l, _, d, r, v, N, K, X, D]
}
class rn extends G {
    constructor(e) {
        super(), J(this, e, nn, tn, Y, {
            header: 0,
            truncateMaxWidth: 1,
            variant: 2,
            view: 3,
            currencyView: 4,
            balances: 10
        })
    }
}

function ln(i) {
    let e, n;
    return e = new pe({
        props: {
            value: i[3],
            currency: i[1]
        }
    }), {
        c() {
            y(e.$$.fragment)
        },
        l(t) {
            C(e.$$.fragment, t)
        },
        m(t, r) {
            $(e, t, r), n = !0
        },
        p(t, r) {
            const l = {};
            r & 8 && (l.value = t[3]), r & 2 && (l.currency = t[1]), e.$set(l)
        },
        i(t) {
            n || (h(e.$$.fragment, t), n = !0)
        },
        o(t) {
            p(e.$$.fragment, t), n = !1
        },
        d(t) {
            k(e, t)
        }
    }
}

function an(i) {
    let e, n;
    return e = new ue({
        props: {
            weight: "semibold",
            variant: "highlighted",
            iconAfter: !0,
            value: i[3],
            currency: i[1],
            truncateMaxWidth: i[2]
        }
    }), {
        c() {
            y(e.$$.fragment)
        },
        l(t) {
            C(e.$$.fragment, t)
        },
        m(t, r) {
            $(e, t, r), n = !0
        },
        p(t, r) {
            const l = {};
            r & 8 && (l.value = t[3]), r & 2 && (l.currency = t[1]), r & 4 && (l.truncateMaxWidth = t[2]), e.$set(l)
        },
        i(t) {
            n || (h(e.$$.fragment, t), n = !0)
        },
        o(t) {
            p(e.$$.fragment, t), n = !1
        },
        d(t) {
            k(e, t)
        }
    }
}

function cn(i) {
    let e, n;
    return e = new Oe({
        props: {
            width: i[2]
        }
    }), {
        c() {
            y(e.$$.fragment)
        },
        l(t) {
            C(e.$$.fragment, t)
        },
        m(t, r) {
            $(e, t, r), n = !0
        },
        p(t, r) {
            const l = {};
            r & 4 && (l.width = t[2]), e.$set(l)
        },
        i(t) {
            n || (h(e.$$.fragment, t), n = !0)
        },
        o(t) {
            p(e.$$.fragment, t), n = !1
        },
        d(t) {
            k(e, t)
        }
    }
}

function sn(i) {
    let e, n, t, r;
    const l = [cn, an, ln],
        a = [];

    function s(c, o) {
        return c[4] ? 0 : c[0] === "compact" ? 1 : 2
    }
    return n = s(i), t = a[n] = l[n](i), {
        c() {
            e = S("div"), t.c(), this.h()
        },
        l(c) {
            e = I(c, "DIV", {
                class: !0
            });
            var o = R(e);
            t.l(o), o.forEach(g), this.h()
        },
        h() {
            B(e, "class", "wrap svelte-lnje3m")
        },
        m(c, o) {
            b(c, e, o), a[n].m(e, null), r = !0
        },
        p(c, [o]) {
            let f = n;
            n = s(c), n === f ? a[n].p(c, o) : (F(), p(a[f], 1, 1, () => {
                a[f] = null
            }), j(), t = a[n], t ? t.p(c, o) : (t = a[n] = l[n](c), t.c()), h(t, 1), t.m(e, null))
        },
        i(c) {
            r || (h(t), r = !0)
        },
        o(c) {
            p(t), r = !1
        },
        d(c) {
            c && g(e), a[n].d()
        }
    }
}

function on(i, e, n) {
    let t, r, l, a, s;
    A(i, He, u => n(7, l = u)), A(i, qe, u => n(8, a = u)), A(i, Le, u => n(4, s = u));
    let {
        type: c = "available"
    } = e, {
        currencyView: o = "compact"
    } = e, {
        currency: f
    } = e, {
        truncateMaxWidth: d = "12ch"
    } = e;
    return i.$$set = u => {
        "type" in u && n(5, c = u.type), "currencyView" in u && n(0, o = u.currencyView), "currency" in u && n(1, f = u.currency), "truncateMaxWidth" in u && n(2, d = u.truncateMaxWidth)
    }, i.$$.update = () => {
        i.$$.dirty & 258 && n(6, t = a == null ? void 0 : a[f]), i.$$.dirty & 224 && n(3, r = l ? (t == null ? void 0 : t.available) + (t == null ? void 0 : t.vault) : (t == null ? void 0 : t[c]) || 0)
    }, [o, f, d, r, s, c, t, l, a]
}
class un extends G {
    constructor(e) {
        super(), J(this, e, on, sn, Y, {
            type: 5,
            currencyView: 0,
            currency: 1,
            truncateMaxWidth: 2
        })
    }
}

function fn(i) {
    let e, n, t = i[1]._(T.inPlay) + "",
        r, l, a, s, c;
    return s = new ue({
        props: {
            weight: "semibold",
            variant: "highlighted",
            iconAfter: !0,
            symbolAfter: !0,
            currency: i[0]
        }
    }), {
        c() {
            e = S("span"), n = L("("), r = L(t), l = L(")"), a = M(), y(s.$$.fragment)
        },
        l(o) {
            e = I(o, "SPAN", {});
            var f = R(e);
            n = O(f, "("), r = O(f, t), l = O(f, ")"), f.forEach(g), a = E(o), C(s.$$.fragment, o)
        },
        m(o, f) {
            b(o, e, f), P(e, n), P(e, r), P(e, l), b(o, a, f), $(s, o, f), c = !0
        },
        p(o, [f]) {
            (!c || f & 2) && t !== (t = o[1]._(T.inPlay) + "") && Z(r, t);
            const d = {};
            f & 1 && (d.currency = o[0]), s.$set(d)
        },
        i(o) {
            c || (h(s.$$.fragment, o), c = !0)
        },
        o(o) {
            p(s.$$.fragment, o), c = !1
        },
        d(o) {
            o && (g(e), g(a)), k(s, o)
        }
    }
}

function _n(i, e, n) {
    let t;
    A(i, me, l => n(1, t = l));
    let {
        currency: r
    } = e;
    return i.$$set = l => {
        "currency" in l && n(0, r = l.currency)
    }, [r, t]
}
class mn extends G {
    constructor(e) {
        super(), J(this, e, _n, fn, Y, {
            currency: 0
        })
    }
}

function dn(i) {
    let e, n;
    return e = new pe({
        props: {
            currency: i[0]
        }
    }), {
        c() {
            y(e.$$.fragment)
        },
        l(t) {
            C(e.$$.fragment, t)
        },
        m(t, r) {
            $(e, t, r), n = !0
        },
        p(t, r) {
            const l = {};
            r & 1 && (l.currency = t[0]), e.$set(l)
        },
        i(t) {
            n || (h(e.$$.fragment, t), n = !0)
        },
        o(t) {
            p(e.$$.fragment, t), n = !1
        },
        d(t) {
            k(e, t)
        }
    }
}

function hn(i) {
    let e, n;
    return e = new ue({
        props: {
            weight: "semibold",
            variant: "highlighted",
            iconAfter: !0,
            symbolAfter: !0,
            view: i[1],
            currency: i[0]
        }
    }), {
        c() {
            y(e.$$.fragment)
        },
        l(t) {
            C(e.$$.fragment, t)
        },
        m(t, r) {
            $(e, t, r), n = !0
        },
        p(t, r) {
            const l = {};
            r & 2 && (l.view = t[1]), r & 1 && (l.currency = t[0]), e.$set(l)
        },
        i(t) {
            n || (h(e.$$.fragment, t), n = !0)
        },
        o(t) {
            p(e.$$.fragment, t), n = !1
        },
        d(t) {
            k(e, t)
        }
    }
}

function pn(i) {
    let e, n, t, r;
    const l = [hn, dn],
        a = [];

    function s(c, o) {
        return c[1] === "compact" ? 0 : 1
    }
    return e = s(i), n = a[e] = l[e](i), {
        c() {
            n.c(), t = W()
        },
        l(c) {
            n.l(c), t = W()
        },
        m(c, o) {
            a[e].m(c, o), b(c, t, o), r = !0
        },
        p(c, [o]) {
            let f = e;
            e = s(c), e === f ? a[e].p(c, o) : (F(), p(a[f], 1, 1, () => {
                a[f] = null
            }), j(), n = a[e], n ? n.p(c, o) : (n = a[e] = l[e](c), n.c()), h(n, 1), n.m(t.parentNode, t))
        },
        i(c) {
            r || (h(n), r = !0)
        },
        o(c) {
            p(n), r = !1
        },
        d(c) {
            c && g(t), a[e].d(c)
        }
    }
}

function gn(i, e, n) {
    let {
        currency: t
    } = e, {
        currencyView: r = "compact"
    } = e;
    return i.$$set = l => {
        "currency" in l && n(0, t = l.currency), "currencyView" in l && n(1, r = l.currencyView)
    }, [t, r]
}
class wn extends G {
    constructor(e) {
        super(), J(this, e, gn, pn, Y, {
            currency: 0,
            currencyView: 1
        })
    }
}

function Pe(i) {
    let e, n;
    return e = new H({
        props: {
            weight: "semibold",
            $$slots: {
                default: [bn]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            y(e.$$.fragment)
        },
        l(t) {
            C(e.$$.fragment, t)
        },
        m(t, r) {
            $(e, t, r), n = !0
        },
        p(t, r) {
            const l = {};
            r & 16785408 && (l.$$scope = {
                dirty: r,
                ctx: t
            }), e.$set(l)
        },
        i(t) {
            n || (h(e.$$.fragment, t), n = !0)
        },
        o(t) {
            p(e.$$.fragment, t), n = !1
        },
        d(t) {
            k(e, t)
        }
    }
}

function bn(i) {
    let e = i[13]._(T.currency) + "",
        n;
    return {
        c() {
            n = L(e)
        },
        l(t) {
            n = O(t, e)
        },
        m(t, r) {
            b(t, n, r)
        },
        p(t, r) {
            r & 8192 && e !== (e = t[13]._(T.currency) + "") && Z(n, e)
        },
        d(t) {
            t && g(n)
        }
    }
}

function vn(i) {
    let e, n;
    return e = new et({
        props: {
            fullWidth: i[8] === "detailed",
            $$slots: {
                default: [Vn, ({
                    state: t
                }) => ({
                    26: t
                }), ({
                    state: t
                }) => t ? 67108864 : 0]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            y(e.$$.fragment)
        },
        l(t) {
            C(e.$$.fragment, t)
        },
        m(t, r) {
            $(e, t, r), n = !0
        },
        p(t, r) {
            const l = {};
            r & 256 && (l.fullWidth = t[8] === "detailed"), r & 83910143 && (l.$$scope = {
                dirty: r,
                ctx: t
            }), e.$set(l)
        },
        i(t) {
            n || (h(e.$$.fragment, t), n = !0)
        },
        o(t) {
            p(e.$$.fragment, t), n = !1
        },
        d(t) {
            k(e, t)
        }
    }
}

function yn(i) {
    let e, n, t, r;
    var l = i[12];

    function a(s, c) {
        return {
            props: {
                loading: s[14],
                currency: s[1],
                type: s[3],
                currencyView: s[8]
            }
        }
    }
    return l && (n = oe(l, a(i))), {
        c() {
            e = S("div"), n && y(n.$$.fragment), this.h()
        },
        l(s) {
            e = I(s, "DIV", {
                class: !0
            });
            var c = R(e);
            n && C(n.$$.fragment, c), c.forEach(g), this.h()
        },
        h() {
            B(e, "class", t = ye(x("w-full pointer-events-none", ke({
                variant: "neutral",
                size: "sm"
            }), i[4] && "opacity-50")) + " svelte-1hjozqf")
        },
        m(s, c) {
            b(s, e, c), n && $(n, e, null), r = !0
        },
        p(s, c) {
            if (c & 4096 && l !== (l = s[12])) {
                if (n) {
                    F();
                    const o = n;
                    p(o.$$.fragment, 1, 0, () => {
                        k(o, 1)
                    }), j()
                }
                l ? (n = oe(l, a(s)), y(n.$$.fragment), h(n.$$.fragment, 1), $(n, e, null)) : n = null
            } else if (l) {
                const o = {};
                c & 16384 && (o.loading = s[14]), c & 2 && (o.currency = s[1]), c & 8 && (o.type = s[3]), c & 256 && (o.currencyView = s[8]), n.$set(o)
            }(!r || c & 16 && t !== (t = ye(x("w-full pointer-events-none", ke({
                variant: "neutral",
                size: "sm"
            }), s[4] && "opacity-50")) + " svelte-1hjozqf")) && B(e, "class", t)
        },
        i(s) {
            r || (n && h(n.$$.fragment, s), r = !0)
        },
        o(s) {
            n && p(n.$$.fragment, s), r = !1
        },
        d(s) {
            s && g(e), n && k(n)
        }
    }
}

function $n(i) {
    let e, n, t;
    var r = i[12];

    function l(a, s) {
        return {
            props: {
                loading: a[14],
                currency: a[1],
                type: a[3],
                truncateMaxWidth: a[10],
                currencyView: a[8]
            }
        }
    }
    return r && (e = oe(r, l(i))), {
        c() {
            e && y(e.$$.fragment), n = W()
        },
        l(a) {
            e && C(e.$$.fragment, a), n = W()
        },
        m(a, s) {
            e && $(e, a, s), b(a, n, s), t = !0
        },
        p(a, s) {
            if (s & 4096 && r !== (r = a[12])) {
                if (e) {
                    F();
                    const c = e;
                    p(c.$$.fragment, 1, 0, () => {
                        k(c, 1)
                    }), j()
                }
                r ? (e = oe(r, l(a)), y(e.$$.fragment), h(e.$$.fragment, 1), $(e, n.parentNode, n)) : e = null
            } else if (r) {
                const c = {};
                s & 16384 && (c.loading = a[14]), s & 2 && (c.currency = a[1]), s & 8 && (c.type = a[3]), s & 1024 && (c.truncateMaxWidth = a[10]), s & 256 && (c.currencyView = a[8]), e.$set(c)
            }
        },
        i(a) {
            t || (e && h(e.$$.fragment, a), t = !0)
        },
        o(a) {
            e && p(e.$$.fragment, a), t = !1
        },
        d(a) {
            a && g(n), e && k(e, a)
        }
    }
}

function kn(i) {
    let e, n;
    return e = new rt({}), {
        c() {
            y(e.$$.fragment)
        },
        l(t) {
            C(e.$$.fragment, t)
        },
        m(t, r) {
            $(e, t, r), n = !0
        },
        i(t) {
            n || (h(e.$$.fragment, t), n = !0)
        },
        o(t) {
            p(e.$$.fragment, t), n = !1
        },
        d(t) {
            k(e, t)
        }
    }
}

function Cn(i) {
    let e, n, t;

    function r() {
        return i[23](i[26])
    }
    e = new rn({
        props: {
            view: i[2],
            header: i[0],
            truncateMaxWidth: i[10],
            currencyView: i[8],
            variant: i[7] === "light" ? "dropdown" : "neutral",
            balances: i[11]
        }
    }), e.$on("changeCurrency", i[22]), e.$on("closeDropdown", r);
    const l = i[21].default,
        a = ee(l, i, i[24], null);
    return {
        c() {
            y(e.$$.fragment), n = M(), a && a.c()
        },
        l(s) {
            C(e.$$.fragment, s), n = E(s), a && a.l(s)
        },
        m(s, c) {
            $(e, s, c), b(s, n, c), a && a.m(s, c), t = !0
        },
        p(s, c) {
            i = s;
            const o = {};
            c & 4 && (o.view = i[2]), c & 1 && (o.header = i[0]), c & 1024 && (o.truncateMaxWidth = i[10]), c & 256 && (o.currencyView = i[8]), c & 128 && (o.variant = i[7] === "light" ? "dropdown" : "neutral"), c & 2048 && (o.balances = i[11]), e.$set(o), a && a.p && (!t || c & 16777216) && te(a, l, i, i[24], t ? re(l, i[24], c, null) : ne(i[24]), null)
        },
        i(s) {
            t || (h(e.$$.fragment, s), h(a, s), t = !0)
        },
        o(s) {
            p(e.$$.fragment, s), p(a, s), t = !1
        },
        d(s) {
            s && g(n), k(e, s), a && a.d(s)
        }
    }
}

function Vn(i) {
    let e, n, t, r;
    return e = new tt({
        props: {
            type: "button",
            variant: i[7] === "light" ? "tab" : "neutral",
            "aria-label": "Selected Currency",
            "data-test": "coin-toggle",
            "data-active-currency": i[1],
            disabled: i[4],
            parentNode: i[6],
            class: x("rounded-sm", i[8] === "detailed" && "w-full", i[5] && "shadow-none"),
            $$slots: {
                icon: [kn],
                default: [$n]
            },
            $$scope: {
                ctx: i
            }
        }
    }), t = new nt({
        props: {
            closeOnClick: !1,
            variant: i[7],
            $$slots: {
                default: [Cn]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            y(e.$$.fragment), n = M(), y(t.$$.fragment)
        },
        l(l) {
            C(e.$$.fragment, l), n = E(l), C(t.$$.fragment, l)
        },
        m(l, a) {
            $(e, l, a), b(l, n, a), $(t, l, a), r = !0
        },
        p(l, a) {
            const s = {};
            a & 128 && (s.variant = l[7] === "light" ? "tab" : "neutral"), a & 2 && (s["data-active-currency"] = l[1]), a & 16 && (s.disabled = l[4]), a & 64 && (s.parentNode = l[6]), a & 288 && (s.class = x("rounded-sm", l[8] === "detailed" && "w-full", l[5] && "shadow-none")), a & 16798986 && (s.$$scope = {
                dirty: a,
                ctx: l
            }), e.$set(s);
            const c = {};
            a & 128 && (c.variant = l[7]), a & 83889541 && (c.$$scope = {
                dirty: a,
                ctx: l
            }), t.$set(c)
        },
        i(l) {
            r || (h(e.$$.fragment, l), h(t.$$.fragment, l), r = !0)
        },
        o(l) {
            p(e.$$.fragment, l), p(t.$$.fragment, l), r = !1
        },
        d(l) {
            l && g(n), k(e, l), k(t, l)
        }
    }
}

function Dn(i) {
    let e, n, t, r, l, a, s, c = i[9] && Pe(i);
    const o = [yn, vn],
        f = [];

    function d(u, m) {
        var _;
        return ((_ = u[11]) == null ? void 0 : _.length) < 2 ? 0 : 1
    }
    return r = d(i), l = f[r] = o[r](i), {
        c() {
            e = S("div"), n = S("div"), c && c.c(), t = M(), l.c(), this.h()
        },
        l(u) {
            e = I(u, "DIV", {
                class: !0
            });
            var m = R(e);
            n = I(m, "DIV", {
                class: !0
            });
            var _ = R(n);
            c && c.l(_), t = E(_), l.l(_), _.forEach(g), m.forEach(g), this.h()
        },
        h() {
            B(n, "class", a = "wrapper currency-view-" + i[8] + " svelte-1hjozqf"), B(e, "class", "coin-toggle svelte-1hjozqf")
        },
        m(u, m) {
            b(u, e, m), P(e, n), c && c.m(n, null), P(n, t), f[r].m(n, null), s = !0
        },
        p(u, [m]) {
            u[9] ? c ? (c.p(u, m), m & 512 && h(c, 1)) : (c = Pe(u), c.c(), h(c, 1), c.m(n, t)) : c && (F(), p(c, 1, 1, () => {
                c = null
            }), j());
            let _ = r;
            r = d(u), r === _ ? f[r].p(u, m) : (F(), p(f[_], 1, 1, () => {
                f[_] = null
            }), j(), l = f[r], l ? l.p(u, m) : (l = f[r] = o[r](u), l.c()), h(l, 1), l.m(n, null)), (!s || m & 256 && a !== (a = "wrapper currency-view-" + u[8] + " svelte-1hjozqf")) && B(n, "class", a)
        },
        i(u) {
            s || (h(c), h(l), s = !0)
        },
        o(u) {
            p(c), p(l), s = !1
        },
        d(u) {
            u && g(e), c && c.d(), f[r].d()
        }
    }
}

function Bn(i, e, n) {
    let t, r, l, a, s, c, o, f;
    A(i, He, w => n(18, a = w)), A(i, qe, w => n(19, s = w)), A(i, ut, w => n(20, c = w)), A(i, me, w => n(13, o = w)), A(i, Le, w => n(14, f = w));
    let {
        $$slots: d = {},
        $$scope: u
    } = e, {
        header: m = !1
    } = e, {
        currency: _
    } = e, {
        view: v = "default"
    } = e, {
        type: N = "available"
    } = e, {
        disabled: K = !1
    } = e, {
        noShadow: X = !1
    } = e, {
        parentNode: D = void 0
    } = e, {
        dropdownContentVariant: V = "light"
    } = e, {
        currencyView: U = "compact"
    } = e, {
        showLabel: le = !1
    } = e, {
        currencies: ae = void 0
    } = e, {
        truncateMaxWidth: ge = "12ch"
    } = e;
    const we = _e(),
        Ye = {
            default: un,
            inPlay: mn,
            noBalance: wn
        },
        Ze = ({
            detail: w
        }) => {
            we("changeCurrency", w)
        },
        Ge = w => {
            w.closeDropdown()
        };
    return i.$$set = w => {
        "header" in w && n(0, m = w.header), "currency" in w && n(1, _ = w.currency), "view" in w && n(2, v = w.view), "type" in w && n(3, N = w.type), "disabled" in w && n(4, K = w.disabled), "noShadow" in w && n(5, X = w.noShadow), "parentNode" in w && n(6, D = w.parentNode), "dropdownContentVariant" in w && n(7, V = w.dropdownContentVariant), "currencyView" in w && n(8, U = w.currencyView), "showLabel" in w && n(9, le = w.showLabel), "currencies" in w && n(16, ae = w.currencies), "truncateMaxWidth" in w && n(10, ge = w.truncateMaxWidth), "$$scope" in w && n(24, u = w.$$scope)
    }, i.$$.update = () => {
        i.$$.dirty & 4 && n(12, t = Ye[v]), i.$$.dirty & 1114112 && n(17, r = ae || c), i.$$.dirty & 917512 && n(11, l = $t(r).map(w => {
            const q = s[w],
                be = a ? (q == null ? void 0 : q.available) + (q == null ? void 0 : q.vault) : q == null ? void 0 : q[N],
                Je = ot(be || 0);
            return {
                value: be,
                formattedForFilter: Je,
                currency: w
            }
        }))
    }, [m, _, v, N, K, X, D, V, U, le, ge, l, t, o, f, we, ae, r, a, s, c, d, Ze, Ge, u]
}
class xn extends G {
    constructor(e) {
        super(), J(this, e, Bn, Dn, Y, {
            header: 0,
            currency: 1,
            view: 2,
            type: 3,
            disabled: 4,
            noShadow: 5,
            parentNode: 6,
            dropdownContentVariant: 7,
            currencyView: 8,
            showLabel: 9,
            currencies: 16,
            truncateMaxWidth: 10
        })
    }
}
export {
    xn as C, pe as D, Ot as I
};