import {
    s as o,
    e as w,
    d as m,
    f as u,
    i as r,
    F as d,
    I as t,
    j as y,
    n as c
} from "./scheduler.DXu26z7T.js";
import {
    S as _,
    i as g
} from "./index.Dz_MmNB3.js";

function S(l) {
    let e;
    return {
        c() {
            e = w("span"), this.h()
        },
        l(a) {
            e = m(a, "SPAN", {
                class: !0,
                style: !0
            }), u(e).forEach(r), this.h()
        },
        h() {
            d(e, "class", "space"), t(e, "width", "var(--space-" + l[0] + ")"), t(e, "height", "var(--space-" + l[1] + ")"), t(e, "display", l[2]), t(e, "flex-grow", l[3] ? 1 : 0)
        },
        m(a, s) {
            y(a, e, s)
        },
        p(a, [s]) {
            s & 1 && t(e, "width", "var(--space-" + a[0] + ")"), s & 2 && t(e, "height", "var(--space-" + a[1] + ")"), s & 4 && t(e, "display", a[2]), s & 8 && t(e, "flex-grow", a[3] ? 1 : 0)
        },
        i: c,
        o: c,
        d(a) {
            a && r(e)
        }
    }
}

function G(l, e, a) {
    let {
        w: s = "0"
    } = e, {
        h: n = "0"
    } = e, {
        display: f = "inline-block"
    } = e, {
        flexGrow: h = !1
    } = e;
    return l.$$set = i => {
        "w" in i && a(0, s = i.w), "h" in i && a(1, n = i.h), "display" in i && a(2, f = i.display), "flexGrow" in i && a(3, h = i.flexGrow)
    }, [s, n, f, h]
}
class b extends _ {
    constructor(e) {
        super(), g(this, e, G, S, o, {
            w: 0,
            h: 1,
            display: 2,
            flexGrow: 3
        })
    }
}
export {
    b as S
};