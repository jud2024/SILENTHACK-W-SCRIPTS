import {
    s as L,
    e as I,
    d as M,
    f as V,
    i as p,
    F as A,
    j as C,
    n as F,
    O as N,
    P,
    V as z,
    k as D,
    W as re,
    c as K,
    t as ae,
    h as se,
    l as ne,
    m as G,
    a1 as oe
} from "./scheduler.DXu26z7T.js";
import {
    S as R,
    i as O,
    c as $,
    a as v,
    m as k,
    t as c,
    g as B,
    b as _,
    e as j,
    d as S
} from "./index.Dz_MmNB3.js";
import {
    e as q,
    u as fe,
    o as ue
} from "./each.DvgCmocI.js";
import {
    R as ge,
    T as me,
    A as de,
    S as U
} from "./Slide.B1qMR9s0.js";
import {
    G as ce
} from "./index.DVWgQdxd.js";
import {
    g as he
} from "./helpers.DrdznBvg.js";
import {
    s as _e
} from "./scrollTopContainer.DLbcGdPu.js";
import {
    I as pe
} from "./index.BmTk3-ns.js";
import {
    h as H,
    aw as be,
    r as we,
    i as $e
} from "./index.B4-7gKq3.js";
import {
    T as ve
} from "./index.D7nbRHfU.js";
import {
    P as ke
} from "./index.B1KDSkU5.js";

function Se(a) {
    let e;
    return {
        c() {
            e = I("div"), this.h()
        },
        l(t) {
            e = M(t, "DIV", {
                class: !0
            }), V(e).forEach(p), this.h()
        },
        h() {
            A(e, "class", "wrap rounded-lg bg-grey-700 svelte-1js21o4")
        },
        m(t, i) {
            C(t, e, i)
        },
        p: F,
        i: F,
        o: F,
        d(t) {
            t && p(e)
        }
    }
}
class Ae extends R {
    constructor(e) {
        super(), O(this, e, null, Se, L, {})
    }
}
const Q = {
    edge: H._("Edge"),
    na: H._("N/A"),
    seeAll: H._("See All")
};

function X(a) {
    let e, t, i;
    return t = new ke({
        props: {
            height: "100%"
        }
    }), {
        c() {
            e = I("div"), $(t.$$.fragment), this.h()
        },
        l(l) {
            e = M(l, "DIV", {
                class: !0
            });
            var r = V(e);
            v(t.$$.fragment, r), r.forEach(p), this.h()
        },
        h() {
            A(e, "class", "placeholder svelte-oc519e")
        },
        m(l, r) {
            C(l, e, r), k(t, e, null), i = !0
        },
        i(l) {
            i || (c(t.$$.fragment, l), i = !0)
        },
        o(l) {
            _(t.$$.fragment, l), i = !1
        },
        d(l) {
            l && p(e), S(t)
        }
    }
}

function Ce(a) {
    let e = a[6]._(Q.seeAll) + "",
        t;
    return {
        c() {
            t = ae(e)
        },
        l(i) {
            t = se(i, e)
        },
        m(i, l) {
            C(i, t, l)
        },
        p(i, l) {
            l & 64 && e !== (e = i[6]._(Q.seeAll) + "") && ne(t, e)
        },
        d(i) {
            i && p(t)
        }
    }
}

function Te(a) {
    let e, t, i, l, r, s, o, g, m, u, b, n, d;
    r = new pe({
        props: {
            src: be("seeAll-en.jpg"),
            alt: "See All Card",
            draggable: !1,
            loading: "lazy",
            imgixParams: {
                q: 50,
                w: ie
            },
            width: Math.floor(a[2]),
            height: Math.floor(a[2] * 1.341)
        }
    });
    let f = a[1] && X();
    return m = new ve({
        props: {
            size: "lg",
            variant: "highlighted",
            $$slots: {
                default: [Ce]
            },
            $$scope: {
                ctx: a
            }
        }
    }), {
        c() {
            e = I("div"), t = I("a"), i = I("div"), l = I("div"), $(r.$$.fragment), s = N(), f && f.c(), o = N(), g = I("div"), $(m.$$.fragment), this.h()
        },
        l(h) {
            e = M(h, "DIV", {
                class: !0
            });
            var w = V(e);
            t = M(w, "A", {
                class: !0,
                "data-sveltekit-preload-data": !0,
                href: !0,
                "data-analytics": !0
            });
            var E = V(t);
            i = M(E, "DIV", {
                class: !0
            });
            var T = V(i);
            l = M(T, "DIV", {
                class: !0
            });
            var W = V(l);
            v(r.$$.fragment, W), s = P(W), f && f.l(W), W.forEach(p), o = P(T), g = M(T, "DIV", {
                class: !0
            });
            var J = V(g);
            v(m.$$.fragment, J), J.forEach(p), T.forEach(p), E.forEach(p), w.forEach(p), this.h()
        },
        h() {
            A(l, "class", "image"), A(g, "class", "info-wrap svelte-oc519e"), A(i, "class", "card-wrap wrap svelte-oc519e"), A(t, "class", "link svelte-oc519e"), A(t, "data-sveltekit-preload-data", "hover"), A(t, "href", u = a[4] ? a[5](a[4]) : null), A(t, "data-analytics", "see-all-card-link"), z(t, "horizontal", a[3]), z(t, "is-mobile", a[0]), A(e, "class", "wrap see-all svelte-oc519e"), z(e, "horizontal", a[3])
        },
        m(h, w) {
            C(h, e, w), D(e, t), D(t, i), D(i, l), k(r, l, null), D(l, s), f && f.m(l, null), D(i, o), D(i, g), k(m, g, null), b = !0, n || (d = re(t, "click", a[8]), n = !0)
        },
        p(h, [w]) {
            const E = {};
            w & 4 && (E.width = Math.floor(h[2])), w & 4 && (E.height = Math.floor(h[2] * 1.341)), r.$set(E), h[1] ? f ? w & 2 && c(f, 1) : (f = X(), f.c(), c(f, 1), f.m(l, null)) : f && (B(), _(f, 1, 1, () => {
                f = null
            }), j());
            const T = {};
            w & 576 && (T.$$scope = {
                dirty: w,
                ctx: h
            }), m.$set(T), (!b || w & 48 && u !== (u = h[4] ? h[5](h[4]) : null)) && A(t, "href", u), (!b || w & 8) && z(t, "horizontal", h[3]), (!b || w & 1) && z(t, "is-mobile", h[0]), (!b || w & 8) && z(e, "horizontal", h[3])
        },
        i(h) {
            b || (c(r.$$.fragment, h), c(f), c(m.$$.fragment, h), b = !0)
        },
        o(h) {
            _(r.$$.fragment, h), _(f), _(m.$$.fragment, h), b = !1
        },
        d(h) {
            h && p(e), S(r), f && f.d(), S(m), n = !1, d()
        }
    }
}
const ie = 220;

function Ie(a, e, t) {
    let i, l, r;
    K(a, we, n => t(5, l = n)), K(a, $e, n => t(6, r = n));
    let {
        isMobile: s = !1
    } = e, {
        loading: o = void 0
    } = e, {
        width: g = ie
    } = e, {
        horizontal: m = !1
    } = e, {
        group: u
    } = e;
    const b = () => {
        _e()
    };
    return a.$$set = n => {
        "isMobile" in n && t(0, s = n.isMobile), "loading" in n && t(1, o = n.loading), "width" in n && t(2, g = n.width), "horizontal" in n && t(3, m = n.horizontal), "group" in n && t(7, u = n.group)
    }, a.$$.update = () => {
        a.$$.dirty & 128 && t(4, i = (u == null ? void 0 : u.to) || (u == null ? void 0 : u.slug) && `/casino/group/${u==null?void 0:u.slug}` || null)
    }, [s, o, g, m, i, l, r, u, b]
}
class Me extends R {
    constructor(e) {
        super(), O(this, e, Ie, Te, L, {
            isMobile: 0,
            loading: 1,
            width: 2,
            horizontal: 3,
            group: 7
        })
    }
}

function Y(a, e, t) {
    const i = a.slice();
    return i[15] = e[t], i[17] = t, i
}

function Z(a, e, t) {
    const i = a.slice();
    return i[18] = e[t], i[17] = t, i
}

function Ve(a) {
    let e, t;
    return e = new ce({
        props: {
            dataAnalytics: `casino-slider-${a[0].slug}-item-${a[17]+1}`,
            loading: a[2],
            groupGames: a[18].groupGames,
            width: te,
            card: a[18],
            provider: a[18].provider,
            edge: a[18].edge,
            isMobile: a[10] === 5,
            isBlocked: a[18].isBlocked,
            ribbon: a[6],
            index: a[17]
        }
    }), {
        c() {
            $(e.$$.fragment)
        },
        l(i) {
            v(e.$$.fragment, i)
        },
        m(i, l) {
            k(e, i, l), t = !0
        },
        p(i, l) {
            const r = {};
            l & 3 && (r.dataAnalytics = `casino-slider-${i[0].slug}-item-${i[17]+1}`), l & 4 && (r.loading = i[2]), l & 2 && (r.groupGames = i[18].groupGames), l & 2 && (r.card = i[18]), l & 2 && (r.provider = i[18].provider), l & 2 && (r.edge = i[18].edge), l & 1024 && (r.isMobile = i[10] === 5), l & 2 && (r.isBlocked = i[18].isBlocked), l & 64 && (r.ribbon = i[6]), l & 2 && (r.index = i[17]), e.$set(r)
        },
        i(i) {
            t || (c(e.$$.fragment, i), t = !0)
        },
        o(i) {
            _(e.$$.fragment, i), t = !1
        },
        d(i) {
            S(e, i)
        }
    }
}

function y(a, e) {
    let t, i, l;
    return i = new U({
        props: {
            index: e[17],
            gap: e[10],
            $$slots: {
                default: [Ve]
            },
            $$scope: {
                ctx: e
            }
        }
    }), {
        key: a,
        first: null,
        c() {
            t = G(), $(i.$$.fragment), this.h()
        },
        l(r) {
            t = G(), v(i.$$.fragment, r), this.h()
        },
        h() {
            this.first = t
        },
        m(r, s) {
            C(r, t, s), k(i, r, s), l = !0
        },
        p(r, s) {
            e = r;
            const o = {};
            s & 2 && (o.index = e[17]), s & 1024 && (o.gap = e[10]), s & 1049671 && (o.$$scope = {
                dirty: s,
                ctx: e
            }), i.$set(o)
        },
        i(r) {
            l || (c(i.$$.fragment, r), l = !0)
        },
        o(r) {
            _(i.$$.fragment, r), l = !1
        },
        d(r) {
            r && p(t), S(i, r)
        }
    }
}

function x(a) {
    let e, t, i = q({
            length: a[7]
        }),
        l = [];
    for (let s = 0; s < i.length; s += 1) l[s] = ee(Y(a, i, s));
    const r = s => _(l[s], 1, 1, () => {
        l[s] = null
    });
    return {
        c() {
            for (let s = 0; s < l.length; s += 1) l[s].c();
            e = G()
        },
        l(s) {
            for (let o = 0; o < l.length; o += 1) l[o].l(s);
            e = G()
        },
        m(s, o) {
            for (let g = 0; g < l.length; g += 1) l[g] && l[g].m(s, o);
            C(s, e, o), t = !0
        },
        p(s, o) {
            if (o & 1152) {
                i = q({
                    length: s[7]
                });
                let g;
                for (g = 0; g < i.length; g += 1) {
                    const m = Y(s, i, g);
                    l[g] ? (l[g].p(m, o), c(l[g], 1)) : (l[g] = ee(m), l[g].c(), c(l[g], 1), l[g].m(e.parentNode, e))
                }
                for (B(), g = i.length; g < l.length; g += 1) r(g);
                j()
            }
        },
        i(s) {
            if (!t) {
                for (let o = 0; o < i.length; o += 1) c(l[o]);
                t = !0
            }
        },
        o(s) {
            l = l.filter(Boolean);
            for (let o = 0; o < l.length; o += 1) _(l[o]);
            t = !1
        },
        d(s) {
            s && p(e), oe(l, s)
        }
    }
}

function Ee(a) {
    let e, t, i;
    return e = new Ae({}), {
        c() {
            $(e.$$.fragment), t = N()
        },
        l(l) {
            v(e.$$.fragment, l), t = P(l)
        },
        m(l, r) {
            k(e, l, r), C(l, t, r), i = !0
        },
        i(l) {
            i || (c(e.$$.fragment, l), i = !0)
        },
        o(l) {
            _(e.$$.fragment, l), i = !1
        },
        d(l) {
            l && p(t), S(e, l)
        }
    }
}

function ee(a) {
    let e, t;
    return e = new U({
        props: {
            index: a[17],
            gap: a[10],
            $$slots: {
                default: [Ee]
            },
            $$scope: {
                ctx: a
            }
        }
    }), {
        c() {
            $(e.$$.fragment)
        },
        l(i) {
            v(e.$$.fragment, i)
        },
        m(i, l) {
            k(e, i, l), t = !0
        },
        p(i, l) {
            const r = {};
            l & 1024 && (r.gap = i[10]), l & 1048576 && (r.$$scope = {
                dirty: l,
                ctx: i
            }), e.$set(r)
        },
        i(i) {
            t || (c(e.$$.fragment, i), t = !0)
        },
        o(i) {
            _(e.$$.fragment, i), t = !1
        },
        d(i) {
            S(e, i)
        }
    }
}

function le(a) {
    let e, t;
    return e = new U({
        props: {
            index: a[1].length,
            gap: a[10],
            $$slots: {
                default: [ze]
            },
            $$scope: {
                ctx: a
            }
        }
    }), {
        c() {
            $(e.$$.fragment)
        },
        l(i) {
            v(e.$$.fragment, i)
        },
        m(i, l) {
            k(e, i, l), t = !0
        },
        p(i, l) {
            const r = {};
            l & 2 && (r.index = i[1].length), l & 1024 && (r.gap = i[10]), l & 1049601 && (r.$$scope = {
                dirty: l,
                ctx: i
            }), e.$set(r)
        },
        i(i) {
            t || (c(e.$$.fragment, i), t = !0)
        },
        o(i) {
            _(e.$$.fragment, i), t = !1
        },
        d(i) {
            S(e, i)
        }
    }
}

function ze(a) {
    let e, t;
    return e = new Me({
        props: {
            width: te,
            group: a[0],
            isMobile: a[10] === 5
        }
    }), {
        c() {
            $(e.$$.fragment)
        },
        l(i) {
            v(e.$$.fragment, i)
        },
        m(i, l) {
            k(e, i, l), t = !0
        },
        p(i, l) {
            const r = {};
            l & 1 && (r.group = i[0]), l & 1024 && (r.isMobile = i[10] === 5), e.$set(r)
        },
        i(i) {
            t || (c(e.$$.fragment, i), t = !0)
        },
        o(i) {
            _(e.$$.fragment, i), t = !1
        },
        d(i) {
            S(e, i)
        }
    }
}

function De(a) {
    var b;
    let e = [],
        t = new Map,
        i, l, r, s, o = q(a[1]);
    const g = n => n[18].id;
    for (let n = 0; n < o.length; n += 1) {
        let d = Z(a, o, n),
            f = g(d);
        t.set(f, e[n] = y(f, d))
    }
    let m = a[7] > 0 && x(a),
        u = ((b = a[0]) == null ? void 0 : b.gameCount) > a[5] && le(a);
    return {
        c() {
            for (let n = 0; n < e.length; n += 1) e[n].c();
            i = N(), m && m.c(), l = N(), u && u.c(), r = G()
        },
        l(n) {
            for (let d = 0; d < e.length; d += 1) e[d].l(n);
            i = P(n), m && m.l(n), l = P(n), u && u.l(n), r = G()
        },
        m(n, d) {
            for (let f = 0; f < e.length; f += 1) e[f] && e[f].m(n, d);
            C(n, i, d), m && m.m(n, d), C(n, l, d), u && u.m(n, d), C(n, r, d), s = !0
        },
        p(n, d) {
            var f;
            d & 1095 && (o = q(n[1]), B(), e = fe(e, d, g, 1, n, o, t, i.parentNode, ue, y, i, Z), j()), n[7] > 0 ? m ? (m.p(n, d), d & 128 && c(m, 1)) : (m = x(n), m.c(), c(m, 1), m.m(l.parentNode, l)) : m && (B(), _(m, 1, 1, () => {
                m = null
            }), j()), ((f = n[0]) == null ? void 0 : f.gameCount) > n[5] ? u ? (u.p(n, d), d & 33 && c(u, 1)) : (u = le(n), u.c(), c(u, 1), u.m(r.parentNode, r)) : u && (B(), _(u, 1, 1, () => {
                u = null
            }), j())
        },
        i(n) {
            if (!s) {
                for (let d = 0; d < o.length; d += 1) c(e[d]);
                c(m), c(u), s = !0
            }
        },
        o(n) {
            for (let d = 0; d < e.length; d += 1) _(e[d]);
            _(m), _(u), s = !1
        },
        d(n) {
            n && (p(i), p(l), p(r));
            for (let d = 0; d < e.length; d += 1) e[d].d(n);
            m && m.d(n), u && u.d(n)
        }
    }
}

function Ne(a) {
    let e, t, i, l;
    return e = new me({
        props: {
            group: a[0],
            loading: !1
        }
    }), i = new de({
        props: {
            previous: a[14],
            next: a[13],
            disablePrevious: a[12],
            disableNext: a[11]
        }
    }), {
        c() {
            $(e.$$.fragment), t = N(), $(i.$$.fragment)
        },
        l(r) {
            v(e.$$.fragment, r), t = P(r), v(i.$$.fragment, r)
        },
        m(r, s) {
            k(e, r, s), C(r, t, s), k(i, r, s), l = !0
        },
        p(r, s) {
            const o = {};
            s & 1 && (o.group = r[0]), e.$set(o);
            const g = {};
            s & 16384 && (g.previous = r[14]), s & 8192 && (g.next = r[13]), s & 4096 && (g.disablePrevious = r[12]), s & 2048 && (g.disableNext = r[11]), i.$set(g)
        },
        i(r) {
            l || (c(e.$$.fragment, r), c(i.$$.fragment, r), l = !0)
        },
        o(r) {
            _(e.$$.fragment, r), _(i.$$.fragment, r), l = !1
        },
        d(r) {
            r && p(t), S(e, r), S(i, r)
        }
    }
}

function Pe(a) {
    var i;
    let e, t;
    return e = new ge({
        props: {
            slideCount: ((i = a[0]) == null ? void 0 : i.gameCount) > a[5] ? a[1].length + 1 : a[1].length + a[7],
            mobileView: a[3],
            slidesToShow: a[9],
            gap: a[10],
            slidesToScroll: a[8],
            width: a[4],
            $$slots: {
                header: [Ne, ({
                    disableNext: l,
                    disablePrevious: r,
                    next: s,
                    previous: o
                }) => ({
                    11: l,
                    12: r,
                    13: s,
                    14: o
                }), ({
                    disableNext: l,
                    disablePrevious: r,
                    next: s,
                    previous: o
                }) => (l ? 2048 : 0) | (r ? 4096 : 0) | (s ? 8192 : 0) | (o ? 16384 : 0)],
                default: [De]
            },
            $$scope: {
                ctx: a
            }
        }
    }), {
        c() {
            $(e.$$.fragment)
        },
        l(l) {
            v(e.$$.fragment, l)
        },
        m(l, r) {
            k(e, l, r), t = !0
        },
        p(l, [r]) {
            var o;
            const s = {};
            r & 163 && (s.slideCount = ((o = l[0]) == null ? void 0 : o.gameCount) > l[5] ? l[1].length + 1 : l[1].length + l[7]), r & 8 && (s.mobileView = l[3]), r & 512 && (s.slidesToShow = l[9]), r & 1024 && (s.gap = l[10]), r & 256 && (s.slidesToScroll = l[8]), r & 16 && (s.width = l[4]), r & 1080551 && (s.$$scope = {
                dirty: r,
                ctx: l
            }), e.$set(s)
        },
        i(l) {
            t || (c(e.$$.fragment, l), t = !0)
        },
        o(l) {
            _(e.$$.fragment, l), t = !1
        },
        d(l) {
            S(e, l)
        }
    }
}
const te = 167;

function Ge(a, e, t) {
    let i, l, r, {
            group: s
        } = e,
        {
            cards: o = []
        } = e,
        {
            loading: g = !1
        } = e,
        {
            mobileView: m = !1
        } = e,
        {
            width: u
        } = e,
        {
            limit: b = 21
        } = e,
        {
            ribbon: n = !1
        } = e,
        {
            placeholders: d = 0
        } = e;
    return a.$$set = f => {
        "group" in f && t(0, s = f.group), "cards" in f && t(1, o = f.cards), "loading" in f && t(2, g = f.loading), "mobileView" in f && t(3, m = f.mobileView), "width" in f && t(4, u = f.width), "limit" in f && t(5, b = f.limit), "ribbon" in f && t(6, n = f.ribbon), "placeholders" in f && t(7, d = f.placeholders)
    }, a.$$.update = () => {
        a.$$.dirty & 16 && t(10, {
            gap: i,
            slidesToShow: l,
            slidesToScroll: r
        } = he(u), i, (t(9, l), t(4, u)), (t(8, r), t(4, u)))
    }, [s, o, g, m, u, b, n, d, r, l, i]
}
class Ke extends R {
    constructor(e) {
        super(), O(this, e, Ge, Pe, L, {
            group: 0,
            cards: 1,
            loading: 2,
            mobileView: 3,
            width: 4,
            limit: 5,
            ribbon: 6,
            placeholders: 7
        })
    }
}
export {
    Ke as C
};