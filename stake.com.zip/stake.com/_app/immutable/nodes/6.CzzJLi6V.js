const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["_app/immutable/chunks/index.D9N4rHXO.js", "_app/immutable/chunks/scheduler.DXu26z7T.js", "_app/immutable/chunks/index.Dz_MmNB3.js", "_app/immutable/chunks/index.B3dW9TVs.js", "_app/immutable/chunks/bundle-mjs.BQkiJtvj.js", "_app/immutable/chunks/index.C2-CG2CN.js", "_app/immutable/chunks/index.BvEEXkHb.js", "_app/immutable/chunks/each.DvgCmocI.js", "_app/immutable/chunks/spread.CgU5AtxT.js", "_app/immutable/chunks/index.ByMdEFI5.js", "_app/immutable/chunks/index.D7nbRHfU.js", "_app/immutable/assets/index.BdirPLLy.css", "_app/immutable/chunks/index.BL_Dq_5k.js", "_app/immutable/assets/index.xmF2RXh7.css", "_app/immutable/chunks/context.Bn3Uf8lc.js", "_app/immutable/chunks/ChevronDown.D-lyczpB.js", "_app/immutable/chunks/Error.DAkWdr3O.js", "_app/immutable/assets/index.bkZiabwo.css", "_app/immutable/chunks/index.DChG_RHX.js", "_app/immutable/assets/index.Cd8tiyDO.css", "_app/immutable/chunks/index.zmvGeK6M.js", "_app/immutable/assets/index.eqST3Hm6.css", "_app/immutable/chunks/index.BavbWpNs.js", "_app/immutable/assets/index.BeAU0Ht7.css", "_app/immutable/chunks/index.B4-7gKq3.js", "_app/immutable/chunks/index.B81orGJm.js", "_app/immutable/chunks/entry.GPJbNZcP.js", "_app/immutable/chunks/control.CYgJF_JY.js", "_app/immutable/chunks/GhostModeOn.cYfUwU7X.js", "_app/immutable/chunks/UpdateUserPreference.generated.Clpjpbn7.js", "_app/immutable/chunks/DotsLoader.BJx50Plt.js", "_app/immutable/assets/index.CokKH7f8.css", "_app/immutable/chunks/index.u8ZD9oiA.js", "_app/immutable/chunks/shared.G3i0PjK-.js", "_app/immutable/chunks/context.C4qMQqMz.js", "_app/immutable/chunks/index.CYsK4uyl.js", "_app/immutable/chunks/resizeObserver.A9wvMie0.js", "_app/immutable/chunks/index.D1aiuvC7.js", "_app/immutable/chunks/variables.CIGccMR5.js", "_app/immutable/chunks/index.BljstGtu.js", "_app/immutable/chunks/popper.Dvb6l-Oe.js", "_app/immutable/assets/index.DNFzbYhI.css", "_app/immutable/assets/index.DDdK-dz-.css", "_app/immutable/chunks/index.DGKYLdH2.js", "_app/immutable/chunks/index.Cpg-fJ3N.js", "_app/immutable/chunks/button.BwmFDw8u.js", "_app/immutable/chunks/ctx.CWJzPttI.js", "_app/immutable/chunks/index.CJLuklPK.js", "_app/immutable/chunks/index.Bhhzp5qA.js", "_app/immutable/chunks/SportsHorseRacing.B5gmVLgd.js", "_app/immutable/assets/index.DmlheggN.css", "_app/immutable/chunks/externalLink.D-xTc-p4.js", "_app/immutable/chunks/index.DJurAkTj.js", "_app/immutable/chunks/Popout.fuVBZN-2.js", "_app/immutable/chunks/activeRaces.C4-Kx8AU.js", "_app/immutable/chunks/helpers.ByXtmvj6.js", "_app/immutable/chunks/index.oTMdB5Eh.js", "_app/immutable/chunks/index.CVJ30NdW.js", "_app/immutable/chunks/index.Cakithnr.js", "_app/immutable/assets/index.BFVN46Uo.css", "_app/immutable/assets/index.CltSCZKY.css", "_app/immutable/assets/index.BUKkGvzh.css", "_app/immutable/chunks/index.CMsSFPoz.js", "_app/immutable/chunks/index.l0BdouX0.js", "_app/immutable/chunks/index.CIBDG73T.js", "_app/immutable/chunks/helpers.CobRd3cj.js", "_app/immutable/chunks/index.lhCIiKC2.js", "_app/immutable/chunks/index.BxooaYHE.js", "_app/immutable/chunks/index.1CTKaDY2.js", "_app/immutable/chunks/sessionInfo.6qRo2rSN.js", "_app/immutable/chunks/fiatNumberFormat.CcHMsn0U.js", "_app/immutable/chunks/index.CY6-K88d.js", "_app/immutable/chunks/index.CgjaLSob.js", "_app/immutable/chunks/howler.D2eOmZSY.js", "_app/immutable/chunks/constants.DX75DoF3.js", "_app/immutable/chunks/makeFetchStore.Bw6N3EDt.js", "_app/immutable/chunks/utils.Csgj0yys.js", "_app/immutable/chunks/messages.BhHwkfmF.js", "_app/immutable/assets/index.DbJ7nT-r.css", "_app/immutable/chunks/index.B1J2NdFH.js", "_app/immutable/chunks/utils.92_vUFxq.js", "_app/immutable/chunks/query-string.27nWWSq4.js", "_app/immutable/chunks/preload-helper.BqjOJQfC.js", "_app/immutable/chunks/List.DAtnvj0J.js", "_app/immutable/chunks/Settings.B9OSzQXJ.js", "_app/immutable/chunks/Trophy4.CNL_sHmf.js", "_app/immutable/chunks/SportsArchery.xCgY6FbW.js", "_app/immutable/chunks/constants.JccqSNFq.js", "_app/immutable/chunks/Info.D3JB_c9O.js", "_app/immutable/chunks/Account.Dy1oZprP.js", "_app/immutable/chunks/paths.RTtAVJV7.js", "_app/immutable/chunks/SportsBasketball.D8a7WuBk.js", "_app/immutable/chunks/Graph.5H4YYOLp.js", "_app/immutable/chunks/index.DTS6WF86.js", "_app/immutable/chunks/index.Ci34scWy.js", "_app/immutable/chunks/roles.CMi1bAOW.js", "_app/immutable/chunks/VIPSilver.CnTTpkRN.js", "_app/immutable/chunks/index.DUHuGv4r.js", "_app/immutable/chunks/index.Drh4nwD9.js", "_app/immutable/chunks/index.DCTjP2Ha.js", "_app/immutable/chunks/vip.rsPZMLqI.js", "_app/immutable/assets/index.FcFDsYzm.css", "_app/immutable/chunks/index.rqxo2ccV.js", "_app/immutable/assets/index.BxdntPdZ.css", "_app/immutable/assets/index.u00usa4u.css", "_app/immutable/chunks/index.CAbJJJ2j.js", "_app/immutable/chunks/index.Na6KaqFL.js", "_app/immutable/assets/index.Bnc4pGth.css", "_app/immutable/chunks/index.B1KDSkU5.js", "_app/immutable/assets/index.Dvb3PVlj.css", "_app/immutable/chunks/index.Lln_EedA.js", "_app/immutable/chunks/contentOrLoader.Ol9dNjON.js", "_app/immutable/chunks/Races.CQldkNqK.js", "_app/immutable/chunks/index.Bk7dAAE4.js", "_app/immutable/chunks/TableGames.DYIiz1a8.js", "_app/immutable/chunks/MiscStop.pqiEj6eq.js", "_app/immutable/chunks/StakeOriginalsStakeWheel.D9kbMuGs.js", "_app/immutable/chunks/StakeOriginalsStakeRoulette.C5Lbr9N-.js", "_app/immutable/chunks/LiveDealers.BoasVGZc.js", "_app/immutable/chunks/Fire.BfGK7z2X.js", "_app/immutable/chunks/BadgesUnignore.DF3Iqmag.js", "_app/immutable/chunks/Casino.DVF879Gw.js", "_app/immutable/chunks/BetInstant.BTtScKo0.js", "_app/immutable/chunks/Rewards.B7X_Gvty.js", "_app/immutable/chunks/Affiliate.6_vwcHfp.js", "_app/immutable/chunks/SortAZ._Orhvldh.js", "_app/immutable/chunks/index.Cq_eNUyU.js", "_app/immutable/chunks/index.BzMmusTo.js", "_app/immutable/chunks/index.BpuWy4yF.js", "_app/immutable/chunks/MyBetList.generated.MEuAH-ew.js", "_app/immutable/chunks/context.UnLgwODO.js", "_app/immutable/chunks/allHouseBets.tgPIjlrn.js", "_app/immutable/chunks/index.Cn-rinD1.js", "_app/immutable/chunks/FavouriteFilled.DMUm0W9G.js", "_app/immutable/chunks/index.A2FRVEtT.js", "_app/immutable/chunks/Wallet.B4hgSvlS.js", "_app/immutable/chunks/interpreter.CJhK2JTN.js", "_app/immutable/assets/index.C3SClUl_.css", "_app/immutable/chunks/index.c5a505nz.js", "_app/immutable/chunks/rum.C965eY3q.js", "_app/immutable/chunks/constants.CW0Xv01T.js", "_app/immutable/assets/index.BTR26FI7.css"]))) => i.map(i => d[i]);
import {
    s as le
} from "../chunks/pageSeo.DmcsyA6w.js";
import {
    f as ne,
    g as ae,
    a as se
} from "../chunks/sanity.Cu4Or4Eg.js";
import {
    _ as fe
} from "../chunks/preload-helper.BqjOJQfC.js";
import {
    s as x,
    m as p,
    j as w,
    n as S,
    i as $,
    a1 as ie,
    c as L,
    o as ce,
    O as C,
    P as N,
    e as ue,
    d as me,
    f as _e,
    a as pe,
    u as $e,
    g as ge,
    b as de
} from "../chunks/scheduler.DXu26z7T.js";
import {
    h as he
} from "../chunks/await_block.D0Ps1QAT.js";
import {
    e as q
} from "../chunks/each.DvgCmocI.js";
import {
    S as be,
    i as ke,
    t as c,
    b as u,
    e as P,
    c as g,
    a as d,
    m as h,
    g as W,
    d as b
} from "../chunks/index.Dz_MmNB3.js";
import {
    n as Se,
    p as we,
    a9 as ye,
    r as Le
} from "../chunks/index.B4-7gKq3.js";
import {
    j as Ee
} from "../chunks/index.B4v2Pvbr.js";
import {
    a as Pe
} from "../chunks/index.CY6-K88d.js";
import {
    g as We
} from "../chunks/index.Ci34scWy.js";
import {
    L as ee
} from "../chunks/index.CzcN9_ET.js";
import {
    L as te
} from "../chunks/LayoutSpacing.BhsDyAer.js";
import {
    C as Te
} from "../chunks/index.C154VRnh.js";
import {
    S as Oe
} from "../chunks/index.QCc5oEI0.js";
import {
    S as Ae,
    a as Me
} from "../chunks/index._VESKHkw.js";
import {
    L as Ce
} from "../chunks/index.CrLalDOl.js";
import {
    M as Ne
} from "../chunks/index.CVJ30NdW.js";
import {
    S as He
} from "../chunks/constants.CW0Xv01T.js";
const M = "/casino/home",
    Ie = async n => {
        const {
            pathname: t
        } = n.url, l = t.startsWith(M) ? M : t, e = l.includes("/casino/game/"), o = await ne(n, l, e ? ae : se), r = le[M];
        return {
            seo: o ? ? r
        }
    },
    $t = Object.freeze(Object.defineProperty({
        __proto__: null,
        load: Ie
    }, Symbol.toStringTag, {
        value: "Module"
    }));

function J(n, t, l) {
    const e = n.slice();
    return e[22] = t[l], e
}

function De(n) {
    n[26] = n[27].default
}

function K(n) {
    let t, l, e, o;
    t = new Te({
        props: {
            loading: n[2],
            $$slots: {
                default: [Re]
            },
            $$scope: {
                ctx: n
            }
        }
    });
    let r = (n[1] ? n[5] === !1 : !0) && Q(n);
    return {
        c() {
            g(t.$$.fragment), l = C(), r && r.c(), e = p()
        },
        l(a) {
            d(t.$$.fragment, a), l = N(a), r && r.l(a), e = p()
        },
        m(a, f) {
            h(t, a, f), w(a, l, f), r && r.m(a, f), w(a, e, f), o = !0
        },
        p(a, f) {
            const s = {};
            f & 4 && (s.loading = a[2]), f & 8194 && (s.$$scope = {
                dirty: f,
                ctx: a
            }), t.$set(s), !a[1] || a[5] === !1 ? r ? (r.p(a, f), f & 34 && c(r, 1)) : (r = Q(a), r.c(), c(r, 1), r.m(e.parentNode, e)) : r && (W(), u(r, 1, 1, () => {
                r = null
            }), P())
        },
        i(a) {
            o || (c(t.$$.fragment, a), c(r), o = !0)
        },
        o(a) {
            u(t.$$.fragment, a), u(r), o = !1
        },
        d(a) {
            a && ($(l), $(e)), b(t, a), r && r.d(a)
        }
    }
}

function je(n) {
    let t;
    const l = n[12].default,
        e = pe(l, n, n[13], null);
    return {
        c() {
            e && e.c()
        },
        l(o) {
            e && e.l(o)
        },
        m(o, r) {
            e && e.m(o, r), t = !0
        },
        p(o, r) {
            e && e.p && (!t || r & 8192) && $e(e, l, o, o[13], t ? de(l, o[13], r, null) : ge(o[13]), null)
        },
        i(o) {
            t || (c(e, o), t = !0)
        },
        o(o) {
            u(e, o), t = !1
        },
        d(o) {
            e && e.d(o)
        }
    }
}

function Ge(n) {
    let t, l;
    return t = new te({
        props: {
            reset: n[1],
            $$slots: {
                default: [je]
            },
            $$scope: {
                ctx: n
            }
        }
    }), {
        c() {
            g(t.$$.fragment)
        },
        l(e) {
            d(t.$$.fragment, e)
        },
        m(e, o) {
            h(t, e, o), l = !0
        },
        p(e, o) {
            const r = {};
            o & 2 && (r.reset = e[1]), o & 8192 && (r.$$scope = {
                dirty: o,
                ctx: e
            }), t.$set(r)
        },
        i(e) {
            l || (c(t.$$.fragment, e), l = !0)
        },
        o(e) {
            u(t.$$.fragment, e), l = !1
        },
        d(e) {
            b(t, e)
        }
    }
}

function Re(n) {
    let t, l;
    return t = new ee({
        props: {
            reset: n[1],
            $$slots: {
                default: [Ge]
            },
            $$scope: {
                ctx: n
            }
        }
    }), {
        c() {
            g(t.$$.fragment)
        },
        l(e) {
            d(t.$$.fragment, e)
        },
        m(e, o) {
            h(t, e, o), l = !0
        },
        p(e, o) {
            const r = {};
            o & 2 && (r.reset = e[1]), o & 8194 && (r.$$scope = {
                dirty: o,
                ctx: e
            }), t.$set(r)
        },
        i(e) {
            l || (c(t.$$.fragment, e), l = !0)
        },
        o(e) {
            u(t.$$.fragment, e), l = !1
        },
        d(e) {
            b(t, e)
        }
    }
}

function Q(n) {
    let t, l;
    return t = new ee({
        props: {
            $$slots: {
                default: [Ke]
            },
            $$scope: {
                ctx: n
            }
        }
    }), {
        c() {
            g(t.$$.fragment)
        },
        l(e) {
            d(t.$$.fragment, e)
        },
        m(e, o) {
            h(t, e, o), l = !0
        },
        p(e, o) {
            const r = {};
            o & 8287 && (r.$$scope = {
                dirty: o,
                ctx: e
            }), t.$set(r)
        },
        i(e) {
            l || (c(t.$$.fragment, e), l = !0)
        },
        o(e) {
            u(t.$$.fragment, e), l = !1
        },
        d(e) {
            b(t, e)
        }
    }
}

function X(n) {
    let t, l, e = {
        ctx: n,
        current: null,
        token: null,
        hasCatch: !1,
        pending: Be,
        then: ze,
        catch: Ve,
        value: 27,
        blocks: [, , , ]
    };
    return he(fe(() =>
        import ("../chunks/index.D9N4rHXO.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141])), e), {
        c() {
            t = p(), e.block.c()
        },
        l(o) {
            t = p(), e.block.l(o)
        },
        m(o, r) {
            w(o, t, r), e.block.m(o, e.anchor = r), e.mount = () => t.parentNode, e.anchor = t, l = !0
        },
        p(o, r) {
            n = o
        },
        i(o) {
            l || (c(e.block), l = !0)
        },
        o(o) {
            for (let r = 0; r < 3; r += 1) {
                const a = e.blocks[r];
                u(a)
            }
            l = !1
        },
        d(o) {
            o && $(t), e.block.d(o), e.token = null, e = null
        }
    }
}

function Ve(n) {
    return {
        c: S,
        l: S,
        m: S,
        i: S,
        o: S,
        d: S
    }
}

function ze(n) {
    De(n);
    let t, l;
    return t = new n[26]({}), {
        c() {
            g(t.$$.fragment)
        },
        l(e) {
            d(t.$$.fragment, e)
        },
        m(e, o) {
            h(t, e, o), l = !0
        },
        i(e) {
            l || (c(t.$$.fragment, e), l = !0)
        },
        o(e) {
            u(t.$$.fragment, e), l = !1
        },
        d(e) {
            b(t, e)
        }
    }
}

function Be(n) {
    let t, l;
    return t = new Ne({}), {
        c() {
            g(t.$$.fragment)
        },
        l(e) {
            d(t.$$.fragment, e)
        },
        m(e, o) {
            h(t, e, o), l = !0
        },
        i(e) {
            l || (c(t.$$.fragment, e), l = !0)
        },
        o(e) {
            u(t.$$.fragment, e), l = !1
        },
        d(e) {
            b(t, e)
        }
    }
}

function Ue(n) {
    let t, l, e = n[25] && X(n);
    return {
        c() {
            e && e.c(), t = p()
        },
        l(o) {
            e && e.l(o), t = p()
        },
        m(o, r) {
            e && e.m(o, r), w(o, t, r), l = !0
        },
        p(o, r) {
            o[25] ? e ? r & 33554432 && c(e, 1) : (e = X(o), e.c(), c(e, 1), e.m(t.parentNode, t)) : e && (W(), u(e, 1, 1, () => {
                e = null
            }), P())
        },
        i(o) {
            l || (c(e), l = !0)
        },
        o(o) {
            u(e), l = !1
        },
        d(o) {
            o && $(t), e && e.d(o)
        }
    }
}

function Y(n) {
    let t = n[0],
        l, e, o = Z(n);
    return {
        c() {
            o.c(), l = p()
        },
        l(r) {
            o.l(r), l = p()
        },
        m(r, a) {
            o.m(r, a), w(r, l, a), e = !0
        },
        p(r, a) {
            a & 1 && x(t, t = r[0]) ? (W(), u(o, 1, 1, S), P(), o = Z(r), o.c(), c(o, 1), o.m(l.parentNode, l)) : o.p(r, a)
        },
        i(r) {
            e || (c(o), e = !0)
        },
        o(r) {
            u(o), e = !1
        },
        d(r) {
            r && $(l), o.d(r)
        }
    }
}

function Fe(n) {
    let t, l;
    return t = new Oe({
        props: {
            blocks: n[3].content
        }
    }), {
        c() {
            g(t.$$.fragment)
        },
        l(e) {
            d(t.$$.fragment, e)
        },
        m(e, o) {
            h(t, e, o), l = !0
        },
        p(e, o) {
            const r = {};
            o & 8 && (r.blocks = e[3].content), t.$set(r)
        },
        i(e) {
            l || (c(t.$$.fragment, e), l = !0)
        },
        o(e) {
            u(t.$$.fragment, e), l = !1
        },
        d(e) {
            b(t, e)
        }
    }
}

function qe(n) {
    let t, l;
    return t = new Me({
        props: {
            loading: n[2],
            $$slots: {
                default: [Fe]
            },
            $$scope: {
                ctx: n
            }
        }
    }), {
        c() {
            g(t.$$.fragment)
        },
        l(e) {
            d(t.$$.fragment, e)
        },
        m(e, o) {
            h(t, e, o), l = !0
        },
        p(e, o) {
            const r = {};
            o & 4 && (r.loading = e[2]), o & 8200 && (r.$$scope = {
                dirty: o,
                ctx: e
            }), t.$set(r)
        },
        i(e) {
            l || (c(t.$$.fragment, e), l = !0)
        },
        o(e) {
            u(t.$$.fragment, e), l = !1
        },
        d(e) {
            b(t, e)
        }
    }
}

function Z(n) {
    let t, l;
    return t = new Ae({
        props: {
            defaultOpen: n[0],
            "data-content": He,
            $$slots: {
                default: [qe]
            },
            $$scope: {
                ctx: n
            }
        }
    }), {
        c() {
            g(t.$$.fragment)
        },
        l(e) {
            d(t.$$.fragment, e)
        },
        m(e, o) {
            h(t, e, o), l = !0
        },
        p(e, o) {
            const r = {};
            o & 1 && (r.defaultOpen = e[0]), o & 8204 && (r.$$scope = {
                dirty: o,
                ctx: e
            }), t.$set(r)
        },
        i(e) {
            l || (c(t.$$.fragment, e), l = !0)
        },
        o(e) {
            u(t.$$.fragment, e), l = !1
        },
        d(e) {
            b(t, e)
        }
    }
}

function Je(n) {
    var a, f;
    let t, l, e, o;
    t = new Ce({
        props: {
            $$slots: {
                default: [Ue, ({
                    visible: s
                }) => ({
                    25: s
                }), ({
                    visible: s
                }) => s ? 33554432 : 0]
            },
            $$scope: {
                ctx: n
            }
        }
    });
    let r = !n[1] && ((a = n[3]) == null ? void 0 : a.content) && !n[6].isAuthenticated && ((f = n[3]) == null ? void 0 : f.__i18n_lang) === n[4] && Y(n);
    return {
        c() {
            g(t.$$.fragment), l = C(), r && r.c(), e = p()
        },
        l(s) {
            d(t.$$.fragment, s), l = N(s), r && r.l(s), e = p()
        },
        m(s, m) {
            h(t, s, m), w(s, l, m), r && r.m(s, m), w(s, e, m), o = !0
        },
        p(s, m) {
            var k, E;
            const y = {};
            m & 33562624 && (y.$$scope = {
                dirty: m,
                ctx: s
            }), t.$set(y), !s[1] && ((k = s[3]) != null && k.content) && !s[6].isAuthenticated && ((E = s[3]) == null ? void 0 : E.__i18n_lang) === s[4] ? r ? (r.p(s, m), m & 90 && c(r, 1)) : (r = Y(s), r.c(), c(r, 1), r.m(e.parentNode, e)) : r && (W(), u(r, 1, 1, () => {
                r = null
            }), P())
        },
        i(s) {
            o || (c(t.$$.fragment, s), c(r), o = !0)
        },
        o(s) {
            u(t.$$.fragment, s), u(r), o = !1
        },
        d(s) {
            s && ($(l), $(e)), b(t, s), r && r.d(s)
        }
    }
}

function Ke(n) {
    let t, l, e;
    return t = new te({
        props: {
            $$slots: {
                default: [Je]
            },
            $$scope: {
                ctx: n
            }
        }
    }), {
        c() {
            g(t.$$.fragment), l = C()
        },
        l(o) {
            d(t.$$.fragment, o), l = N(o)
        },
        m(o, r) {
            h(t, o, r), w(o, l, r), e = !0
        },
        p(o, r) {
            const a = {};
            r & 8287 && (a.$$scope = {
                dirty: r,
                ctx: o
            }), t.$set(a)
        },
        i(o) {
            e || (c(t.$$.fragment, o), e = !0)
        },
        o(o) {
            u(t.$$.fragment, o), e = !1
        },
        d(o) {
            o && $(l), b(t, o)
        }
    }
}

function v(n) {
    let t;
    return {
        c() {
            t = ue("div")
        },
        l(l) {
            t = me(l, "DIV", {}), _e(t).forEach($)
        },
        m(l, e) {
            w(l, t, e)
        },
        p: S,
        d(l) {
            l && $(t)
        }
    }
}

function Qe(n) {
    let t, l = q([]),
        e = [];
    for (let r = 0; r < l.length; r += 1) e[r] = v(J(n, l, r));
    let o = null;
    return l.length || (o = K(n)), {
        c() {
            for (let r = 0; r < e.length; r += 1) e[r].c();
            t = p(), o && o.c()
        },
        l(r) {
            for (let a = 0; a < e.length; a += 1) e[a].l(r);
            t = p(), o && o.l(r)
        },
        m(r, a) {
            for (let f = 0; f < e.length; f += 1) e[f] && e[f].m(r, a);
            w(r, t, a), o && o.m(r, a)
        },
        p(r, [a]) {
            if (a & 33562751) {
                l = q([]);
                let f;
                for (f = 0; f < l.length; f += 1) {
                    const s = J(r, l, f);
                    e[f] ? e[f].p(s, a) : (e[f] = v(), e[f].c(), e[f].m(t.parentNode, t))
                }
                for (; f < e.length; f += 1) e[f].d(1);
                e.length = l.length, !l.length && o ? o.p(r, a) : l.length ? o && (W(), u(o, 1, 1, () => {
                    o = null
                }), P()) : (o = K(r), o.c(), c(o, 1), o.m(t.parentNode, t))
            }
        },
        i: S,
        o: S,
        d(r) {
            r && $(t), ie(e, r), o && o.d(r)
        }
    }
}

function Xe(n, t, l) {
    let e, o, r, a, f, s, m, y, k, E, H;
    L(n, Se, i => l(10, s = i)), L(n, we, i => l(11, m = i)), L(n, ye, i => l(4, y = i)), L(n, Le, i => l(14, k = i)), L(n, Pe, i => l(5, E = i));
    let {
        $$slots: oe = {},
        $$scope: I
    } = t, {
        data: T
    } = t;
    const {
        meta: D
    } = We();
    L(n, D, i => l(6, H = i));
    let O = k("/casino/games"),
        j = k("/casino/recent"),
        G = k("/casino/favourites"),
        R = k("/casino/group"),
        V = k("/casino/collection"),
        A = k("/casino/home"),
        re = [(i, _) => i.startsWith(j) !== _.startsWith(j), (i, _) => i.startsWith(A) !== _.startsWith(A), (i, _) => i.startsWith(G) !== _.startsWith(G), (i, _) => i.startsWith(R) !== _.startsWith(R), (i, _) => i.startsWith(V) !== _.startsWith(V), (i, _) => i.startsWith(O) !== _.startsWith(O)];
    return ce(() => {
        Ee(null, y)
    }), n.$$set = i => {
        "data" in i && l(8, T = i.data), "$$scope" in i && l(13, I = i.$$scope)
    }, n.$$.update = () => {
        var i;
        n.$$.dirty & 2304 && l(3, e = ((i = m.data) == null ? void 0 : i.seoCasinoGroup) ? ? T.seo), n.$$.dirty & 1024 && l(2, o = !!(s && re.some(_ => {
            var z, B, U, F;
            return _(((B = (z = s == null ? void 0 : s.from) == null ? void 0 : z.url) == null ? void 0 : B.pathname) ? ? "", ((F = (U = s == null ? void 0 : s.to) == null ? void 0 : U.url) == null ? void 0 : F.pathname) ? ? "")
        }))), n.$$.dirty & 2048 && l(1, r = m.url.pathname.startsWith(O)), n.$$.dirty & 2048 && l(9, a = m.url.pathname === A), n.$$.dirty & 1536 && l(0, f = !a && !s)
    }, [f, r, o, e, y, E, H, D, T, a, s, m, oe, I]
}
class gt extends be {
    constructor(t) {
        super(), ke(this, t, Xe, Qe, x, {
            data: 8
        })
    }
}
export {
    gt as component, $t as universal
};