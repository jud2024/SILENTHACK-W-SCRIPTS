import {
    a as s
} from "./index.B81orGJm.js";
const t = {
        sidebarFullWidth: 768,
        tablet: 992,
        logoCollapse: 375
    },
    a = {
        sidebarSmallWidth: "320px",
        sidebarWidth: "370px",
        leftSidebarWidth: "240px",
        leftSidebarMinimizedWidth: "60px",
        headerHeight: "60px",
        mobileFooterHeight: "60px",
        maxContainerWidth: "1200px",
        maxGameBoardWidth: "730px"
    },
    b = {
        gameModal: 80,
        header: 100,
        sidebar: 900,
        betslip: 1e3,
        mobileFooter: 1300,
        search: 1450,
        modal: 1500,
        draggable: 1550,
        dropdown: 1600,
        confirmationDialog: 1650,
        notification: 1700,
        tooltip: 1800,
        cookieAcceptance: 1900,
        fullscreen: 9999
    },
    h = 1200,
    m = t.sidebarFullWidth,
    d = ({
        width: e,
        min: i,
        max: o
    }) => e >= i && e <= o,
    l = e => e >= t.tablet,
    r = e => d({
        width: e,
        min: t.sidebarFullWidth,
        max: t.tablet - 1
    }),
    c = e => {
        var i;
        return (s ? ((i = document.getElementById("storybook-root")) == null ? void 0 : i.getBoundingClientRect().width) || 0 : e) < t.sidebarFullWidth
    },
    p = e => l(e) ? {
        name: "desktop",
        rightSidebarWidth: a.sidebarWidth
    } : r(e) ? {
        name: "tablet",
        rightSidebarWidth: a.sidebarSmallWidth
    } : {
        name: "mobile",
        rightSidebarWidth: "100%"
    };
export {
    m as F, h as L, l as a, t as b, p as g, c as i, a as s, b as z
};