import {
    s as d,
    a as _,
    e as m,
    d as v,
    f as h,
    i as u,
    F as r,
    j as y,
    u as g,
    g as b,
    b as j,
    K as o,
    M as c
} from "./scheduler.DXu26z7T.js";
import {
    S as C,
    i as S,
    t as q,
    b as D
} from "./index.Dz_MmNB3.js";

function E(i) {
    let t, n, l;
    const f = i[4].default,
        a = _(f, i, i[3], null);
    return {
        c() {
            t = m("div"), a && a.c(), this.h()
        },
        l(s) {
            t = v(s, "DIV", {
                class: !0,
                style: !0
            });
            var e = h(t);
            a && a.l(e), e.forEach(u), this.h()
        },
        h() {
            r(t, "class", n = "card variant-" + i[0] + " " + (i[2].class || "") + " svelte-hfdoji"), r(t, "style", i[1])
        },
        m(s, e) {
            y(s, t, e), a && a.m(t, null), l = !0
        },
        p(s, [e]) {
            a && a.p && (!l || e & 8) && g(a, f, s, s[3], l ? j(f, s[3], e, null) : b(s[3]), null), (!l || e & 5 && n !== (n = "card variant-" + s[0] + " " + (s[2].class || "") + " svelte-hfdoji")) && r(t, "class", n), (!l || e & 2) && r(t, "style", s[1])
        },
        i(s) {
            l || (q(a, s), l = !0)
        },
        o(s) {
            D(a, s), l = !1
        },
        d(s) {
            s && u(t), a && a.d(s)
        }
    }
}

function F(i, t, n) {
    let {
        $$slots: l = {},
        $$scope: f
    } = t, {
        variant: a = "default"
    } = t, {
        style: s = void 0
    } = t;
    return i.$$set = e => {
        n(2, t = o(o({}, t), c(e))), "variant" in e && n(0, a = e.variant), "style" in e && n(1, s = e.style), "$$scope" in e && n(3, f = e.$$scope)
    }, t = c(t), [a, s, t, f, l]
}
class M extends C {
    constructor(t) {
        super(), S(this, t, F, E, d, {
            variant: 0,
            style: 1
        })
    }
}
export {
    M as C
};