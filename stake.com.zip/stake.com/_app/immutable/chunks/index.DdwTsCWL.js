import {
    s as K,
    m as S,
    j as g,
    i as p,
    c as M,
    a as Q,
    e as E,
    O as y,
    d as B,
    f as D,
    P as I,
    F as j,
    k,
    u as R,
    g as U,
    b as X,
    S as Y,
    I as Z,
    t as z,
    h as O,
    l as T,
    a1 as ee,
    n as W
} from "./scheduler.DXu26z7T.js";
import {
    S as te,
    i as re,
    g as A,
    b as h,
    e as F,
    t as m,
    c as x,
    a as V,
    m as N,
    d as C
} from "./index.Dz_MmNB3.js";
import {
    e as G
} from "./each.DvgCmocI.js";
import {
    T as P
} from "./index.D7nbRHfU.js";
import "./index.B3dW9TVs.js";
import {
    h as q,
    i as ne
} from "./index.B4-7gKq3.js";
import {
    B as le
} from "./button.BwmFDw8u.js";
const v = {
    header: q._("We're sorry - something's gone wrong."),
    refreshBrowser: q._("refreshing your browser"),
    options: {
        id: "Our team has been notified, try {refreshBrowser}"
    },
    update: i => ({
        id: "Looks like there you need to update {hostname}, try {refreshBrowser}.",
        values: i
    }),
    disconnected: q._("No network connection!")
};

function H(i, e, t) {
    const r = i.slice();
    return r[6] = e[t], r
}

function se(i) {
    let e, t, r, n, c, s, o, l, a, $;
    r = new P({
        props: {
            align: "center",
            size: "xl",
            $$slots: {
                default: [ae]
            },
            $$scope: {
                ctx: i
            }
        }
    });
    const d = i[3].default,
        _ = Q(d, i, i[5], null);
    return o = new P({
        props: {
            align: "center",
            $$slots: {
                default: [ie]
            },
            $$scope: {
                ctx: i
            }
        }
    }), a = new P({
        props: {
            inline: !0,
            align: "center",
            $$slots: {
                default: [ue]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            e = E("div"), t = E("div"), x(r.$$.fragment), n = y(), _ && _.c(), c = y(), s = E("div"), x(o.$$.fragment), l = y(), x(a.$$.fragment), this.h()
        },
        l(f) {
            e = B(f, "DIV", {
                class: !0
            });
            var u = D(e);
            t = B(u, "DIV", {
                class: !0
            });
            var b = D(t);
            V(r.$$.fragment, b), n = I(b), _ && _.l(b), c = I(b), s = B(b, "DIV", {});
            var w = D(s);
            V(o.$$.fragment, w), l = I(w), V(a.$$.fragment, w), w.forEach(p), b.forEach(p), u.forEach(p), this.h()
        },
        h() {
            j(t, "class", "content svelte-kewhxg"), j(e, "class", "wrap svelte-kewhxg")
        },
        m(f, u) {
            g(f, e, u), k(e, t), N(r, t, null), k(t, n), _ && _.m(t, null), k(t, c), k(t, s), N(o, s, null), k(s, l), N(a, s, null), $ = !0
        },
        p(f, u) {
            const b = {};
            u & 32 && (b.$$scope = {
                dirty: u,
                ctx: f
            }), r.$set(b), _ && _.p && (!$ || u & 32) && R(_, d, f, f[5], $ ? X(d, f[5], u, null) : U(f[5]), null);
            const w = {};
            u & 34 && (w.$$scope = {
                dirty: u,
                ctx: f
            }), o.$set(w);
            const L = {};
            u & 38 && (L.$$scope = {
                dirty: u,
                ctx: f
            }), a.$set(L)
        },
        i(f) {
            $ || (m(r.$$.fragment, f), m(_, f), m(o.$$.fragment, f), m(a.$$.fragment, f), $ = !0)
        },
        o(f) {
            h(r.$$.fragment, f), h(_, f), h(o.$$.fragment, f), h(a.$$.fragment, f), $ = !1
        },
        d(f) {
            f && p(e), C(r), _ && _.d(f), C(o), C(a)
        }
    }
}

function oe(i) {
    let e, t, r, n = "🔌",
        c, s, o, l, a, $;
    return o = new P({
        props: {
            $$slots: {
                default: [$e]
            },
            $$scope: {
                ctx: i
            }
        }
    }), a = new P({
        props: {
            $$slots: {
                default: [de]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            e = E("div"), t = E("div"), r = E("span"), r.textContent = n, c = y(), s = E("div"), x(o.$$.fragment), l = y(), x(a.$$.fragment), this.h()
        },
        l(d) {
            e = B(d, "DIV", {
                class: !0
            });
            var _ = D(e);
            t = B(_, "DIV", {
                class: !0
            });
            var f = D(t);
            r = B(f, "SPAN", {
                style: !0,
                "data-svelte-h": !0
            }), Y(r) !== "svelte-m8t4ve" && (r.textContent = n), c = I(f), s = B(f, "DIV", {});
            var u = D(s);
            V(o.$$.fragment, u), l = I(u), V(a.$$.fragment, u), u.forEach(p), f.forEach(p), _.forEach(p), this.h()
        },
        h() {
            Z(r, "font-size", "2rem"), j(t, "class", "content svelte-kewhxg"), j(e, "class", "wrap svelte-kewhxg")
        },
        m(d, _) {
            g(d, e, _), k(e, t), k(t, r), k(t, c), k(t, s), N(o, s, null), k(s, l), N(a, s, null), $ = !0
        },
        p(d, _) {
            const f = {};
            _ & 34 && (f.$$scope = {
                dirty: _,
                ctx: d
            }), o.$set(f);
            const u = {};
            _ & 34 && (u.$$scope = {
                dirty: _,
                ctx: d
            }), a.$set(u)
        },
        i(d) {
            $ || (m(o.$$.fragment, d), m(a.$$.fragment, d), $ = !0)
        },
        o(d) {
            h(o.$$.fragment, d), h(a.$$.fragment, d), $ = !1
        },
        d(d) {
            d && p(e), C(o), C(a)
        }
    }
}

function ae(i) {
    let e;
    return {
        c() {
            e = z("😳")
        },
        l(t) {
            e = O(t, "😳")
        },
        m(t, r) {
            g(t, e, r)
        },
        d(t) {
            t && p(e)
        }
    }
}

function ie(i) {
    let e = i[1]._(v.header) + "",
        t;
    return {
        c() {
            t = z(e)
        },
        l(r) {
            t = O(r, e)
        },
        m(r, n) {
            g(r, t, n)
        },
        p(r, n) {
            n & 2 && e !== (e = r[1]._(v.header) + "") && T(t, e)
        },
        d(r) {
            r && p(t)
        }
    }
}

function fe(i) {
    let e, t;
    return e = new le({
        props: {
            variant: "link",
            $$slots: {
                default: [_e]
            },
            $$scope: {
                ctx: i
            }
        }
    }), e.$on("click", i[4]), {
        c() {
            x(e.$$.fragment)
        },
        l(r) {
            V(e.$$.fragment, r)
        },
        m(r, n) {
            N(e, r, n), t = !0
        },
        p(r, n) {
            const c = {};
            n & 34 && (c.$$scope = {
                dirty: n,
                ctx: r
            }), e.$set(c)
        },
        i(r) {
            t || (m(e.$$.fragment, r), t = !0)
        },
        o(r) {
            h(e.$$.fragment, r), t = !1
        },
        d(r) {
            C(e, r)
        }
    }
}

function ce(i) {
    let e = i[6] + "",
        t;
    return {
        c() {
            t = z(e)
        },
        l(r) {
            t = O(r, e)
        },
        m(r, n) {
            g(r, t, n)
        },
        p(r, n) {
            n & 4 && e !== (e = r[6] + "") && T(t, e)
        },
        i: W,
        o: W,
        d(r) {
            r && p(t)
        }
    }
}

function _e(i) {
    let e = i[1]._(v.refreshBrowser) + "",
        t, r;
    return {
        c() {
            t = z(e), r = y()
        },
        l(n) {
            t = O(n, e), r = I(n)
        },
        m(n, c) {
            g(n, t, c), g(n, r, c)
        },
        p(n, c) {
            c & 2 && e !== (e = n[1]._(v.refreshBrowser) + "") && T(t, e)
        },
        d(n) {
            n && (p(t), p(r))
        }
    }
}

function J(i) {
    let e, t, r, n;
    const c = [ce, fe],
        s = [];

    function o(l, a) {
        return typeof l[6] == "string" ? 0 : l[6][0] === "refreshBrowser" ? 1 : -1
    }
    return ~(e = o(i)) && (t = s[e] = c[e](i)), {
        c() {
            t && t.c(), r = S()
        },
        l(l) {
            t && t.l(l), r = S()
        },
        m(l, a) {
            ~e && s[e].m(l, a), g(l, r, a), n = !0
        },
        p(l, a) {
            let $ = e;
            e = o(l), e === $ ? ~e && s[e].p(l, a) : (t && (A(), h(s[$], 1, 1, () => {
                s[$] = null
            }), F()), ~e ? (t = s[e], t ? t.p(l, a) : (t = s[e] = c[e](l), t.c()), m(t, 1), t.m(r.parentNode, r)) : t = null)
        },
        i(l) {
            n || (m(t), n = !0)
        },
        o(l) {
            h(t), n = !1
        },
        d(l) {
            l && p(r), ~e && s[e].d(l)
        }
    }
}

function ue(i) {
    let e, t, r = G(i[2]),
        n = [];
    for (let s = 0; s < r.length; s += 1) n[s] = J(H(i, r, s));
    const c = s => h(n[s], 1, 1, () => {
        n[s] = null
    });
    return {
        c() {
            for (let s = 0; s < n.length; s += 1) n[s].c();
            e = S()
        },
        l(s) {
            for (let o = 0; o < n.length; o += 1) n[o].l(s);
            e = S()
        },
        m(s, o) {
            for (let l = 0; l < n.length; l += 1) n[l] && n[l].m(s, o);
            g(s, e, o), t = !0
        },
        p(s, o) {
            if (o & 6) {
                r = G(s[2]);
                let l;
                for (l = 0; l < r.length; l += 1) {
                    const a = H(s, r, l);
                    n[l] ? (n[l].p(a, o), m(n[l], 1)) : (n[l] = J(a), n[l].c(), m(n[l], 1), n[l].m(e.parentNode, e))
                }
                for (A(), l = r.length; l < n.length; l += 1) c(l);
                F()
            }
        },
        i(s) {
            if (!t) {
                for (let o = 0; o < r.length; o += 1) m(n[o]);
                t = !0
            }
        },
        o(s) {
            n = n.filter(Boolean);
            for (let o = 0; o < n.length; o += 1) h(n[o]);
            t = !1
        },
        d(s) {
            s && p(e), ee(n, s)
        }
    }
}

function $e(i) {
    let e = i[1]._(v.header) + "",
        t;
    return {
        c() {
            t = z(e)
        },
        l(r) {
            t = O(r, e)
        },
        m(r, n) {
            g(r, t, n)
        },
        p(r, n) {
            n & 2 && e !== (e = r[1]._(v.header) + "") && T(t, e)
        },
        d(r) {
            r && p(t)
        }
    }
}

function de(i) {
    let e = i[1]._(v.disconnected) + "",
        t;
    return {
        c() {
            t = z(e)
        },
        l(r) {
            t = O(r, e)
        },
        m(r, n) {
            g(r, t, n)
        },
        p(r, n) {
            n & 2 && e !== (e = r[1]._(v.disconnected) + "") && T(t, e)
        },
        d(r) {
            r && p(t)
        }
    }
}

function pe(i) {
    let e, t, r, n;
    const c = [oe, se],
        s = [];

    function o(l, a) {
        return l[0] ? 0 : 1
    }
    return e = o(i), t = s[e] = c[e](i), {
        c() {
            t.c(), r = S()
        },
        l(l) {
            t.l(l), r = S()
        },
        m(l, a) {
            s[e].m(l, a), g(l, r, a), n = !0
        },
        p(l, [a]) {
            let $ = e;
            e = o(l), e === $ ? s[e].p(l, a) : (A(), h(s[$], 1, 1, () => {
                s[$] = null
            }), F(), t = s[e], t ? t.p(l, a) : (t = s[e] = c[e](l), t.c()), m(t, 1), t.m(r.parentNode, r))
        },
        i(l) {
            n || (m(t), n = !0)
        },
        o(l) {
            h(t), n = !1
        },
        d(l) {
            l && p(r), s[e].d(l)
        }
    }
}

function me(i, e, t) {
    let r, n;
    M(i, ne, a => t(1, n = a));
    let {
        $$slots: c = {},
        $$scope: s
    } = e, {
        networkError: o = !1
    } = e;
    const l = () => window.location.reload();
    return i.$$set = a => {
        "networkError" in a && t(0, o = a.networkError), "$$scope" in a && t(5, s = a.$$scope)
    }, i.$$.update = () => {
        var a;
        i.$$.dirty & 2 && t(2, r = n.message((a = v == null ? void 0 : v.options) == null ? void 0 : a.id))
    }, [o, n, r, c, l, s]
}
class Be extends te {
    constructor(e) {
        super(), re(this, e, me, pe, K, {
            networkError: 0
        })
    }
}
export {
    Be as E
};