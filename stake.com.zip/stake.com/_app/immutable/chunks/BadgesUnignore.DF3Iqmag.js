import {
    s as u,
    C as r,
    H as v,
    D as o,
    f as g,
    E as m,
    i as c,
    F as f,
    j as d,
    n as h
} from "./scheduler.DXu26z7T.js";
import {
    S as _,
    i as y
} from "./index.Dz_MmNB3.js";

function B(n) {
    let l, s, a = ` <title>${n[1]||""}</title> <path d="M88 48c0 22.091-17.909 40-40 40S8 70.091 8 48 25.909 8 48 8s40 17.909 40 40Z" fill="#FF5773"></path><path fill="#fff" d="M24 41.2h48v14H24z"></path>`,
        i;
    return {
        c() {
            l = r("svg"), s = new v(!0), this.h()
        },
        l(e) {
            l = o(e, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var t = g(l);
            s = m(t, !0), t.forEach(c), this.h()
        },
        h() {
            s.a = null, f(l, "fill", "none"), f(l, "viewBox", "0 0 96 96"), f(l, "class", i = "svg-icon " + n[2]), f(l, "style", n[0])
        },
        m(e, t) {
            d(e, l, t), s.m(a, l)
        },
        p(e, [t]) {
            t & 2 && a !== (a = ` <title>${e[1]||""}</title> <path d="M88 48c0 22.091-17.909 40-40 40S8 70.091 8 48 25.909 8 48 8s40 17.909 40 40Z" fill="#FF5773"></path><path fill="#fff" d="M24 41.2h48v14H24z"></path>`) && s.p(a), t & 4 && i !== (i = "svg-icon " + e[2]) && f(l, "class", i), t & 1 && f(l, "style", e[0])
        },
        i: h,
        o: h,
        d(e) {
            e && c(l)
        }
    }
}

function w(n, l, s) {
    let {
        style: a = ""
    } = l, {
        alt: i = ""
    } = l, {
        class: e = ""
    } = l;
    return n.$$set = t => {
        "style" in t && s(0, a = t.style), "alt" in t && s(1, i = t.alt), "class" in t && s(2, e = t.class)
    }, [a, i, e]
}
class z extends _ {
    constructor(l) {
        super(), y(this, l, w, B, u, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}

function M(n) {
    let l, s, a = ` <title>${n[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M48 88c22.091 0 40-17.909 40-40S70.091 8 48 8 8 25.909 8 48s17.909 40 40 40Z" fill="#00B801"></path><path fill="#fff" d="M55 24.2v48H41v-48z"></path>`,
        i;
    return {
        c() {
            l = r("svg"), s = new v(!0), this.h()
        },
        l(e) {
            l = o(e, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var t = g(l);
            s = m(t, !0), t.forEach(c), this.h()
        },
        h() {
            s.a = null, f(l, "fill", "none"), f(l, "viewBox", "0 0 96 96"), f(l, "class", i = "svg-icon " + n[2]), f(l, "style", n[0])
        },
        m(e, t) {
            d(e, l, t), s.m(a, l)
        },
        p(e, [t]) {
            t & 2 && a !== (a = ` <title>${e[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M48 88c22.091 0 40-17.909 40-40S70.091 8 48 8 8 25.909 8 48s17.909 40 40 40Z" fill="#00B801"></path><path fill="#fff" d="M55 24.2v48H41v-48z"></path>`) && s.p(a), t & 4 && i !== (i = "svg-icon " + e[2]) && f(l, "class", i), t & 1 && f(l, "style", e[0])
        },
        i: h,
        o: h,
        d(e) {
            e && c(l)
        }
    }
}

function H(n, l, s) {
    let {
        style: a = ""
    } = l, {
        alt: i = ""
    } = l, {
        class: e = ""
    } = l;
    return n.$$set = t => {
        "style" in t && s(0, a = t.style), "alt" in t && s(1, i = t.alt), "class" in t && s(2, e = t.class)
    }, [a, i, e]
}
class Z extends _ {
    constructor(l) {
        super(), y(this, l, H, M, u, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    Z as B, z as a
};