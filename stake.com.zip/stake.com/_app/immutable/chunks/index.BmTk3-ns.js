import {
    s as G,
    m as O,
    j as d,
    n as c,
    i as h,
    N as Q,
    O as T,
    e as o,
    P as W,
    d as _,
    F as r,
    U as g,
    V as U,
    f as z,
    W as A
} from "./scheduler.DXu26z7T.js";
import {
    S as D,
    i as F
} from "./index.Dz_MmNB3.js";
import {
    a as b
} from "./index.B81orGJm.js";

function H(f) {
    let e, l, s, a = f[6] && S(f);
    return {
        c() {
            a && a.c(), e = T(), l = o("img"), this.h()
        },
        l(i) {
            a && a.l(i), e = W(i), l = _(i, "IMG", {
                id: !0,
                loading: !0,
                src: !0,
                alt: !0,
                width: !0,
                height: !0,
                style: !0,
                draggable: !0
            }), this.h()
        },
        h() {
            r(l, "id", f[2]), r(l, "loading", f[7]), g(l.src, s = f[10]) || r(l, "src", s), r(l, "alt", f[1]), r(l, "width", f[4]), r(l, "height", f[5]), r(l, "style", f[8]), r(l, "draggable", f[3]), U(l, "chromatic-ignore", b)
        },
        m(i, t) {
            a && a.m(i, t), d(i, e, t), d(i, l, t)
        },
        p(i, t) {
            i[6] ? a ? a.p(i, t) : (a = S(i), a.c(), a.m(e.parentNode, e)) : a && (a.d(1), a = null), t & 4 && r(l, "id", i[2]), t & 128 && r(l, "loading", i[7]), t & 1024 && !g(l.src, s = i[10]) && r(l, "src", s), t & 2 && r(l, "alt", i[1]), t & 16 && r(l, "width", i[4]), t & 32 && r(l, "height", i[5]), t & 256 && r(l, "style", i[8]), t & 8 && r(l, "draggable", i[3])
        },
        d(i) {
            i && (h(e), h(l)), a && a.d(i)
        }
    }
}

function B(f) {
    let e;
    return {
        c() {
            e = o("div")
        },
        l(l) {
            e = _(l, "DIV", {}), z(e).forEach(h)
        },
        m(l, s) {
            d(l, e, s)
        },
        p: c,
        d(l) {
            l && h(e)
        }
    }
}

function S(f) {
    let e, l, s, a;
    return {
        c() {
            e = o("img"), this.h()
        },
        l(i) {
            e = _(i, "IMG", {
                id: !0,
                src: !0,
                alt: !0,
                width: !0,
                height: !0,
                style: !0,
                draggable: !0
            }), this.h()
        },
        h() {
            r(e, "id", f[2]), g(e.src, l = f[9]) || r(e, "src", l), r(e, "alt", f[1]), r(e, "width", f[4]), r(e, "height", f[5]), r(e, "style", f[8]), r(e, "draggable", f[3]), U(e, "chromatic-ignore", b)
        },
        m(i, t) {
            d(i, e, t), s || (a = A(e, "load", f[12]), s = !0)
        },
        p(i, t) {
            t & 4 && r(e, "id", i[2]), t & 512 && !g(e.src, l = i[9]) && r(e, "src", l), t & 2 && r(e, "alt", i[1]), t & 16 && r(e, "width", i[4]), t & 32 && r(e, "height", i[5]), t & 256 && r(e, "style", i[8]), t & 8 && r(e, "draggable", i[3])
        },
        d(i) {
            i && h(e), s = !1, a()
        }
    }
}

function J(f) {
    let e;

    function l(i, t) {
        return i[0] ? H : B
    }
    let s = l(f),
        a = s(f);
    return {
        c() {
            a.c(), e = O()
        },
        l(i) {
            a.l(i), e = O()
        },
        m(i, t) {
            a.m(i, t), d(i, e, t)
        },
        p(i, [t]) {
            s === (s = l(i)) && a ? a.p(i, t) : (a.d(1), a = s(i), a && (a.c(), a.m(e.parentNode, e)))
        },
        i: c,
        o: c,
        d(i) {
            i && h(e), a.d(i)
        }
    }
}

function K(f, e, l) {
    let s, a, {
            src: i
        } = e,
        {
            alt: t
        } = e,
        {
            id: w = void 0
        } = e,
        {
            draggable: I = !1
        } = e,
        {
            width: k = void 0
        } = e,
        {
            height: P = void 0
        } = e,
        {
            placeholder: y = !0
        } = e,
        {
            imgixParams: m = {
                q: 50
            }
        } = e,
        {
            loading: C = "lazy"
        } = e,
        {
            style: q = void 0
        } = e;
    const R = n => Object.keys(n).reduce((N, u) => n[u] ? `${N}&${encodeURIComponent(u)}=${encodeURIComponent(n[u])}` : N, "?"),
        V = window.devicePixelRatio,
        j = {
            blur: 200,
            px: 6,
            quality: 15
        },
        M = {
            dpr: V,
            format: "auto",
            auto: "format",
            ...m,
            ...b ? {
                px: 50,
                quality: 15
            } : {}
        };

    function E(n) {
        Q.call(this, f, n)
    }
    return f.$$set = n => {
        "src" in n && l(0, i = n.src), "alt" in n && l(1, t = n.alt), "id" in n && l(2, w = n.id), "draggable" in n && l(3, I = n.draggable), "width" in n && l(4, k = n.width), "height" in n && l(5, P = n.height), "placeholder" in n && l(6, y = n.placeholder), "imgixParams" in n && l(11, m = n.imgixParams), "loading" in n && l(7, C = n.loading), "style" in n && l(8, q = n.style)
    }, f.$$.update = () => {
        f.$$.dirty & 1 && l(10, s = i + R({ ...M
        })), f.$$.dirty & 1 && l(9, a = i + R({ ...M,
            ...j
        }))
    }, [i, t, w, I, k, P, y, C, q, a, s, m, E]
}
class Z extends D {
    constructor(e) {
        super(), F(this, e, K, J, G, {
            src: 0,
            alt: 1,
            id: 2,
            draggable: 3,
            width: 4,
            height: 5,
            placeholder: 6,
            imgixParams: 11,
            loading: 7,
            style: 8
        })
    }
}
export {
    Z as I
};