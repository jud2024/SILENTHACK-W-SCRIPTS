import {
    s as S,
    a as C,
    e as w,
    d as k,
    f as O,
    i as v,
    F as D,
    V as E,
    j as y,
    u as z,
    g as P,
    b as R,
    X as ne,
    c as G,
    w as se,
    K as j,
    L as T,
    Y as oe,
    M as ie,
    O as Q,
    m as N,
    P as U,
    v as le,
    o as re,
    I as Y,
    k as I,
    J as F
} from "./scheduler.DXu26z7T.js";
import {
    S as q,
    i as B,
    t as _,
    b,
    c as V,
    a as A,
    m as L,
    d as M,
    g as Z,
    e as $
} from "./index.Dz_MmNB3.js";
import {
    r as ae
} from "./resizeObserver.A9wvMie0.js";
import {
    d as fe,
    c as ce
} from "./popper.Dvb6l-Oe.js";
import {
    s as ue,
    g as W
} from "./context.C4qMQqMz.js";
import {
    g as pe,
    a as de
} from "./spread.CgU5AtxT.js";
import "./index.B3dW9TVs.js";
import {
    B as me
} from "./button.BwmFDw8u.js";
import {
    P as _e
} from "./index.D1aiuvC7.js";
var he = {
    name: "maxSize",
    enabled: !0,
    phase: "main",
    requiresIfExists: ["offset", "preventOverflow", "flip"],
    fn: function(t) {
        var o = t.state,
            n = t.name,
            s = t.options,
            e = fe(o, s),
            l = o.modifiersData.preventOverflow || {
                x: 0,
                y: 0
            },
            r = l.x,
            f = l.y,
            a = o.rects.popper,
            u = a.width,
            p = a.height,
            c = o.placement.split("-"),
            h = c[0],
            g = h === "left" ? "left" : "right",
            d = h === "top" ? "top" : "bottom";
        o.modifiersData[n] = {
            width: u - e[g] - r,
            height: p - e[d] - f
        }
    }
};
const ge = i => ({}),
    H = i => ({
        state: i[2]
    });

function ve(i) {
    let t, o;
    const n = i[8].default,
        s = C(n, i, i[7], H);
    return {
        c() {
            t = w("div"), s && s.c(), this.h()
        },
        l(e) {
            t = k(e, "DIV", {
                class: !0
            });
            var l = O(t);
            s && s.l(l), l.forEach(v), this.h()
        },
        h() {
            D(t, "class", "dropdown svelte-1iau4lg"), E(t, "full-width", i[1]), E(t, "transparent", i[0])
        },
        m(e, l) {
            y(e, t, l), s && s.m(t, null), o = !0
        },
        p(e, [l]) {
            s && s.p && (!o || l & 128) && z(s, n, e, e[7], o ? R(n, e[7], l, ge) : P(e[7]), H), (!o || l & 2) && E(t, "full-width", e[1]), (!o || l & 1) && E(t, "transparent", e[0])
        },
        i(e) {
            o || (_(s, e), o = !0)
        },
        o(e) {
            b(s, e), o = !1
        },
        d(e) {
            e && v(t), s && s.d(e)
        }
    }
}

function be(i, t, o) {
    let n, s, e, l, r, {
        $$slots: f = {},
        $$scope: a
    } = t;
    const u = ne();
    ue();
    const p = W();
    G(i, p, m => o(6, r = m));
    let {
        transparent: c = !1
    } = t, {
        fullWidth: h = !1
    } = t, g, d;
    const x = () => {
            g && (g.destroy(), g = null), d && (d.destroy(), d = null)
        },
        ee = () => {
            g = ce(s, e, {
                strategy: "fixed",
                placement: "bottom",
                modifiers: [{
                    name: "offset",
                    options: {
                        offset: [0, 10]
                    }
                }, n && {
                    name: "arrow",
                    options: {
                        element: n
                    }
                }, { ...he,
                    options: {
                        padding: 10
                    }
                }, {
                    name: "applyMaxSize",
                    enabled: !0,
                    phase: "beforeWrite",
                    requires: ["maxSize"],
                    fn({
                        state: m
                    }) {
                        const {
                            height: te
                        } = m.modifiersData.maxSize;
                        m.styles.popper = { ...m.styles.popper,
                            maxHeight: `${te}px`
                        }
                    }
                }, {
                    name: "sameWidth",
                    enabled: h,
                    phase: "beforeWrite",
                    requires: ["computeStyles"],
                    fn: ({
                        state: m
                    }) => {
                        m.styles.popper.width = `${m.rects.reference.width}px`
                    },
                    effect: ({
                        state: m
                    }) => {
                        m.elements.popper.style.width = `${m.elements.reference.getBoundingClientRect().width}px`
                    }
                }].filter(Boolean)
            }), d = ae(e, () => g.update())
        };
    return se(() => {
        g && g.destroy()
    }), i.$$set = m => {
        "transparent" in m && o(0, c = m.transparent), "fullWidth" in m && o(1, h = m.fullWidth), "$$scope" in m && o(7, a = m.$$scope)
    }, i.$$.update = () => {
        i.$$.dirty & 64 && (n = r.arrowRef), i.$$.dirty & 64 && o(5, s = r.buttonRef), i.$$.dirty & 64 && o(4, e = r.tooltipRef), i.$$.dirty & 112 && o(3, l = r.isOpen && s && e), i.$$.dirty & 64 && r.shouldDispatchBlur && !r.isOpen && u("blur"), i.$$.dirty & 8 && (x(), l && ee())
    }, [c, h, p, l, e, s, r, a, f]
}
class Me extends q {
    constructor(t) {
        super(), B(this, t, be, ve, S, {
            transparent: 0,
            fullWidth: 1
        })
    }
}
const we = i => ({}),
    J = i => ({});

function K(i) {
    let t, o;
    const n = i[7].icon,
        s = C(n, i, i[10], J);
    return {
        c() {
            t = w("span"), s && s.c(), this.h()
        },
        l(e) {
            t = k(e, "SPAN", {
                class: !0
            });
            var l = O(t);
            s && s.l(l), l.forEach(v), this.h()
        },
        h() {
            D(t, "class", "dropdown-icon svelte-9n45i2")
        },
        m(e, l) {
            y(e, t, l), s && s.m(t, null), o = !0
        },
        p(e, l) {
            s && s.p && (!o || l & 1024) && z(s, n, e, e[10], o ? R(n, e[10], l, we) : P(e[10]), J)
        },
        i(e) {
            o || (_(s, e), o = !0)
        },
        o(e) {
            b(s, e), o = !1
        },
        d(e) {
            e && v(t), s && s.d(e)
        }
    }
}

function ke(i) {
    let t, o, n;
    const s = i[7].default,
        e = C(s, i, i[10], null);
    let l = "icon" in i[5] && K(i);
    return {
        c() {
            e && e.c(), t = Q(), l && l.c(), o = N()
        },
        l(r) {
            e && e.l(r), t = U(r), l && l.l(r), o = N()
        },
        m(r, f) {
            e && e.m(r, f), y(r, t, f), l && l.m(r, f), y(r, o, f), n = !0
        },
        p(r, f) {
            e && e.p && (!n || f & 1024) && z(e, s, r, r[10], n ? R(s, r[10], f, null) : P(r[10]), null), "icon" in r[5] ? l ? (l.p(r, f), f & 32 && _(l, 1)) : (l = K(r), l.c(), _(l, 1), l.m(o.parentNode, o)) : l && (Z(), b(l, 1, 1, () => {
                l = null
            }), $())
        },
        i(r) {
            n || (_(e, r), _(l), n = !0)
        },
        o(r) {
            b(e, r), b(l), n = !1
        },
        d(r) {
            r && (v(t), v(o)), e && e.d(r), l && l.d(r)
        }
    }
}

function Oe(i) {
    let t, o;
    const n = [i[4], {
        variant: i[0]
    }, {
        size: i[1]
    }, {
        builders: [{
            action: i[8]
        }]
    }, {
        "aria-label": "Open Dropdown"
    }];
    let s = {
        $$slots: {
            default: [ke]
        },
        $$scope: {
            ctx: i
        }
    };
    for (let e = 0; e < n.length; e += 1) s = j(s, n[e]);
    return t = new me({
        props: s
    }), t.$on("click", i[9]), {
        c() {
            V(t.$$.fragment)
        },
        l(e) {
            A(t.$$.fragment, e)
        },
        m(e, l) {
            L(t, e, l), o = !0
        },
        p(e, [l]) {
            const r = l & 23 ? pe(n, [l & 16 && de(e[4]), l & 1 && {
                variant: e[0]
            }, l & 2 && {
                size: e[1]
            }, l & 4 && {
                builders: [{
                    action: e[8]
                }]
            }, n[4]]) : {};
            l & 1056 && (r.$$scope = {
                dirty: l,
                ctx: e
            }), t.$set(r)
        },
        i(e) {
            o || (_(t.$$.fragment, e), o = !0)
        },
        o(e) {
            b(t.$$.fragment, e), o = !1
        },
        d(e) {
            M(t, e)
        }
    }
}

function De(i, t, o) {
    const n = ["variant", "parentNode", "size"];
    let s = T(t, n),
        {
            $$slots: e = {},
            $$scope: l
        } = t;
    const r = oe(e);
    let {
        variant: f = "link"
    } = t, {
        parentNode: a = void 0
    } = t, {
        size: u = "sm"
    } = t, p = W(), c;
    const h = d => {
            o(2, c = d)
        },
        g = d => {
            d.stopPropagation(), p.toggleIsOpen()
        };
    return i.$$set = d => {
        t = j(j({}, t), ie(d)), o(4, s = T(t, n)), "variant" in d && o(0, f = d.variant), "parentNode" in d && o(6, a = d.parentNode), "size" in d && o(1, u = d.size), "$$scope" in d && o(10, l = d.$$scope)
    }, i.$$.update = () => {
        i.$$.dirty & 68 && (a || c) && p.setButtonRef(a || c)
    }, [f, u, c, p, s, r, a, e, h, g, l]
}
class Te extends q {
    constructor(t) {
        super(), B(this, t, De, Oe, S, {
            variant: 0,
            parentNode: 6,
            size: 1
        })
    }
}

function ye(i) {
    let t, o, n, s, e, l, r;
    const f = i[4].default,
        a = C(f, i, i[7], null);
    return {
        c() {
            t = w("div"), o = w("div"), n = Q(), s = w("div"), e = w("div"), a && a.c(), this.h()
        },
        l(u) {
            t = k(u, "DIV", {
                class: !0
            });
            var p = O(t);
            o = k(p, "DIV", {
                class: !0
            }), O(o).forEach(v), n = U(p), s = k(p, "DIV", {
                style: !0
            });
            var c = O(s);
            e = k(c, "DIV", {
                class: !0,
                style: !0
            });
            var h = O(e);
            a && a.l(h), h.forEach(v), c.forEach(v), p.forEach(v), this.h()
        },
        h() {
            D(o, "class", "arrow svelte-yjqf2g"), D(e, "class", "dropdown-scroll-content scrollY scrollY-light scroll-light svelte-yjqf2g"), Y(e, "max-height", "inherit"), Y(s, "max-height", "inherit"), D(t, "class", l = "tooltip-wrapper tooltip variant-" + i[0] + " svelte-yjqf2g")
        },
        m(u, p) {
            y(u, t, p), I(t, o), i[5](o), I(t, n), I(t, s), I(s, e), a && a.m(e, null), i[6](t), r = !0
        },
        p(u, p) {
            a && a.p && (!r || p & 128) && z(a, f, u, u[7], r ? R(f, u[7], p, null) : P(u[7]), null), (!r || p & 1 && l !== (l = "tooltip-wrapper tooltip variant-" + u[0] + " svelte-yjqf2g")) && D(t, "class", l)
        },
        i(u) {
            r || (_(a, u), r = !0)
        },
        o(u) {
            b(a, u), r = !1
        },
        d(u) {
            u && v(t), i[5](null), a && a.d(u), i[6](null)
        }
    }
}

function Ce(i) {
    let t, o;
    return t = new _e({
        props: {
            $$slots: {
                default: [ye]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            V(t.$$.fragment)
        },
        l(n) {
            A(t.$$.fragment, n)
        },
        m(n, s) {
            L(t, n, s), o = !0
        },
        p(n, [s]) {
            const e = {};
            s & 135 && (e.$$scope = {
                dirty: s,
                ctx: n
            }), t.$set(e)
        },
        i(n) {
            o || (_(t.$$.fragment, n), o = !0)
        },
        o(n) {
            b(t.$$.fragment, n), o = !1
        },
        d(n) {
            M(t, n)
        }
    }
}

function ze(i, t, o) {
    let {
        $$slots: n = {},
        $$scope: s
    } = t, {
        closeOnClick: e = !0
    } = t, {
        variant: l
    } = t, r = W();
    le("parent", `dropdown-${l}`);
    let f, a;
    re(() => {
        let c = h => {
            if (f) {
                let g = f.contains(h.target);
                (e || g === !1) && r.closeDropdown()
            }
        };
        return setTimeout(() => {
            window.addEventListener("click", c)
        }, 250), () => {
            window.removeEventListener("click", c)
        }
    });

    function u(c) {
        F[c ? "unshift" : "push"](() => {
            a = c, o(2, a)
        })
    }

    function p(c) {
        F[c ? "unshift" : "push"](() => {
            f = c, o(1, f)
        })
    }
    return i.$$set = c => {
        "closeOnClick" in c && o(3, e = c.closeOnClick), "variant" in c && o(0, l = c.variant), "$$scope" in c && o(7, s = c.$$scope)
    }, i.$$.update = () => {
        i.$$.dirty & 2 && (f ? r.setTooltipRef(f) : r.setTooltipRef(null)), i.$$.dirty & 4 && (a ? r.setArrowRef(a) : r.setArrowRef(null))
    }, [l, f, a, e, n, u, p, s]
}
class Pe extends q {
    constructor(t) {
        super(), B(this, t, ze, Ce, S, {
            closeOnClick: 3,
            variant: 0
        })
    }
}

function X(i) {
    let t, o;
    return t = new Pe({
        props: {
            closeOnClick: i[0],
            variant: i[1],
            $$slots: {
                default: [Re]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            V(t.$$.fragment)
        },
        l(n) {
            A(t.$$.fragment, n)
        },
        m(n, s) {
            L(t, n, s), o = !0
        },
        p(n, s) {
            const e = {};
            s & 1 && (e.closeOnClick = n[0]), s & 2 && (e.variant = n[1]), s & 32 && (e.$$scope = {
                dirty: s,
                ctx: n
            }), t.$set(e)
        },
        i(n) {
            o || (_(t.$$.fragment, n), o = !0)
        },
        o(n) {
            b(t.$$.fragment, n), o = !1
        },
        d(n) {
            M(t, n)
        }
    }
}

function Re(i) {
    let t;
    const o = i[4].default,
        n = C(o, i, i[5], null);
    return {
        c() {
            n && n.c()
        },
        l(s) {
            n && n.l(s)
        },
        m(s, e) {
            n && n.m(s, e), t = !0
        },
        p(s, e) {
            n && n.p && (!t || e & 32) && z(n, o, s, s[5], t ? R(o, s[5], e, null) : P(s[5]), null)
        },
        i(s) {
            t || (_(n, s), t = !0)
        },
        o(s) {
            b(n, s), t = !1
        },
        d(s) {
            n && n.d(s)
        }
    }
}

function Ee(i) {
    let t, o, n = i[2].isOpen && X(i);
    return {
        c() {
            n && n.c(), t = N()
        },
        l(s) {
            n && n.l(s), t = N()
        },
        m(s, e) {
            n && n.m(s, e), y(s, t, e), o = !0
        },
        p(s, [e]) {
            s[2].isOpen ? n ? (n.p(s, e), e & 4 && _(n, 1)) : (n = X(s), n.c(), _(n, 1), n.m(t.parentNode, t)) : n && (Z(), b(n, 1, 1, () => {
                n = null
            }), $())
        },
        i(s) {
            o || (_(n), o = !0)
        },
        o(s) {
            b(n), o = !1
        },
        d(s) {
            s && v(t), n && n.d(s)
        }
    }
}

function Ie(i, t, o) {
    let n, {
            $$slots: s = {},
            $$scope: e
        } = t,
        {
            closeOnClick: l = !0
        } = t,
        {
            variant: r = "light"
        } = t,
        f = W();
    return G(i, f, a => o(2, n = a)), i.$$set = a => {
        "closeOnClick" in a && o(0, l = a.closeOnClick), "variant" in a && o(1, r = a.variant), "$$scope" in a && o(5, e = a.$$scope)
    }, [l, r, n, f, s, e]
}
class Ye extends q {
    constructor(t) {
        super(), B(this, t, Ie, Ee, S, {
            closeOnClick: 0,
            variant: 1
        })
    }
}
export {
    Me as D, Te as a, Ye as b
};