import {
    s as _,
    c
} from "./scheduler.DXu26z7T.js";
import {
    S as h,
    i as L,
    c as P,
    a as b,
    m as S,
    t as d,
    b as q,
    d as w
} from "./index.Dz_MmNB3.js";
import {
    J as C
} from "./index.B4-7gKq3.js";
import {
    P as J
} from "./Pagination.CKRSZVAD.js";

function j(e) {
    let n, o;
    return n = new J({
        props: {
            offset: e[2],
            limit: e[1],
            listLength: e[0]
        }
    }), n.$on("previous", e[5]), n.$on("next", e[6]), {
        c() {
            P(n.$$.fragment)
        },
        l(t) {
            b(n.$$.fragment, t)
        },
        m(t, s) {
            S(n, t, s), o = !0
        },
        p(t, [s]) {
            const a = {};
            s & 4 && (a.offset = t[2]), s & 2 && (a.limit = t[1]), s & 1 && (a.listLength = t[0]), n.$set(a)
        },
        i(t) {
            o || (d(n.$$.fragment, t), o = !0)
        },
        o(t) {
            q(n.$$.fragment, t), o = !1
        },
        d(t) {
            w(n, t)
        }
    }
}

function k(e, n, o) {
    let t, s, {
            listLength: a
        } = n,
        {
            pagination: f
        } = n;
    const {
        offset: r,
        limit: m,
        loading: l,
        refetch: g,
        previous: u,
        next: p
    } = f;
    return c(e, r, i => o(2, s = i)), c(e, m, i => o(1, t = i)), C(r, ({
        current: i
    }) => {
        l.set(!0), g && g({
            limit: t,
            offset: i
        }).finally(() => {
            l.set(!1)
        })
    }), e.$$set = i => {
        "listLength" in i && o(0, a = i.listLength), "pagination" in i && o(7, f = i.pagination)
    }, [a, t, s, r, m, u, p, f]
}
class B extends h {
    constructor(n) {
        super(), L(this, n, k, j, _, {
            listLength: 0,
            pagination: 7
        })
    }
}
export {
    B as P
};