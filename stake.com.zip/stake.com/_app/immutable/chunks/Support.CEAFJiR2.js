import {
    s as r,
    C as o,
    H as u,
    D as f,
    f as m,
    E as _,
    i as n,
    F as h,
    j as g,
    n as v
} from "./scheduler.DXu26z7T.js";
import {
    S as y,
    i as C
} from "./index.Dz_MmNB3.js";

function H(i) {
    let t, a, l = ` <title>${i[1]||""}</title> <path d="M32-.001h-.084C17.056-.001 5.01 12.045 5.01 26.905c0 .178.002.356.006.534v-.026 22.374h17.386V30.613h-8.186v-3.2a17.59 17.59 0 0 1-.01-.588c0-9.734 7.892-17.626 17.626-17.626h.178H32h.17c9.734 0 17.626 7.892 17.626 17.626 0 .206-.004.412-.01.618v-.03 3.2H41.6v19.174h7.546c-1.734 4.134-7.28 5.014-17.146 5.014v9.2c8.774 0 26.986 0 26.986-17.386v-19.2c.004-.15.004-.328.004-.506C58.99 12.049 46.944.003 32.084.003h-.09.004L32-.001Z"></path>`,
        c;
    return {
        c() {
            t = o("svg"), a = new u(!0), this.h()
        },
        l(s) {
            t = f(s, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var e = m(t);
            a = _(e, !0), e.forEach(n), this.h()
        },
        h() {
            a.a = null, h(t, "fill", "currentColor"), h(t, "viewBox", "0 0 64 64"), h(t, "class", c = "svg-icon " + i[2]), h(t, "style", i[0])
        },
        m(s, e) {
            g(s, t, e), a.m(l, t)
        },
        p(s, [e]) {
            e & 2 && l !== (l = ` <title>${s[1]||""}</title> <path d="M32-.001h-.084C17.056-.001 5.01 12.045 5.01 26.905c0 .178.002.356.006.534v-.026 22.374h17.386V30.613h-8.186v-3.2a17.59 17.59 0 0 1-.01-.588c0-9.734 7.892-17.626 17.626-17.626h.178H32h.17c9.734 0 17.626 7.892 17.626 17.626 0 .206-.004.412-.01.618v-.03 3.2H41.6v19.174h7.546c-1.734 4.134-7.28 5.014-17.146 5.014v9.2c8.774 0 26.986 0 26.986-17.386v-19.2c.004-.15.004-.328.004-.506C58.99 12.049 46.944.003 32.084.003h-.09.004L32-.001Z"></path>`) && a.p(l), e & 4 && c !== (c = "svg-icon " + s[2]) && h(t, "class", c), e & 1 && h(t, "style", s[0])
        },
        i: v,
        o: v,
        d(s) {
            s && n(t)
        }
    }
}

function d(i, t, a) {
    let {
        style: l = ""
    } = t, {
        alt: c = ""
    } = t, {
        class: s = ""
    } = t;
    return i.$$set = e => {
        "style" in e && a(0, l = e.style), "alt" in e && a(1, c = e.alt), "class" in e && a(2, s = e.class)
    }, [l, c, s]
}
class B extends y {
    constructor(t) {
        super(), C(this, t, d, H, r, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    B as S
};