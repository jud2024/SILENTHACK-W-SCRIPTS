import {
    s as c,
    a as g,
    e as h,
    d as b,
    f as v,
    i as u,
    F as _,
    V as r,
    j as d,
    u as S,
    g as B,
    b as j
} from "./scheduler.DXu26z7T.js";
import {
    S as L,
    i as V,
    t as q,
    b as C
} from "./index.Dz_MmNB3.js";

function D(n) {
    let e, i, l;
    const f = n[5].default,
        a = g(f, n, n[4], null);
    return {
        c() {
            e = h("div"), a && a.c(), this.h()
        },
        l(t) {
            e = b(t, "DIV", {
                class: !0
            });
            var s = v(e);
            a && a.l(s), s.forEach(u), this.h()
        },
        h() {
            _(e, "class", i = "layout-spacing variant-" + n[0] + " svelte-l4ghjo"), r(e, "reset", n[2]), r(e, "no-bottom-spacing", n[1]), r(e, "mobile", n[3])
        },
        m(t, s) {
            d(t, e, s), a && a.m(e, null), l = !0
        },
        p(t, [s]) {
            a && a.p && (!l || s & 16) && S(a, f, t, t[4], l ? j(f, t[4], s, null) : B(t[4]), null), (!l || s & 1 && i !== (i = "layout-spacing variant-" + t[0] + " svelte-l4ghjo")) && _(e, "class", i), (!l || s & 5) && r(e, "reset", t[2]), (!l || s & 3) && r(e, "no-bottom-spacing", t[1]), (!l || s & 9) && r(e, "mobile", t[3])
        },
        i(t) {
            l || (q(a, t), l = !0)
        },
        o(t) {
            C(a, t), l = !1
        },
        d(t) {
            t && u(e), a && a.d(t)
        }
    }
}

function E(n, e, i) {
    let {
        $$slots: l = {},
        $$scope: f
    } = e, {
        variant: a = "normal"
    } = e, {
        noBottomSpacing: t = !1
    } = e, {
        reset: s = !1
    } = e, {
        mobile: m = !1
    } = e;
    return n.$$set = o => {
        "variant" in o && i(0, a = o.variant), "noBottomSpacing" in o && i(1, t = o.noBottomSpacing), "reset" in o && i(2, s = o.reset), "mobile" in o && i(3, m = o.mobile), "$$scope" in o && i(4, f = o.$$scope)
    }, [a, t, s, m, f, l]
}
class k extends L {
    constructor(e) {
        super(), V(this, e, E, D, c, {
            variant: 0,
            noBottomSpacing: 1,
            reset: 2,
            mobile: 3
        })
    }
}
export {
    k as L
};