import {
    T as d
} from "./index.B4-7gKq3.js";
const T = 160;
var g = (n => (n.ar = "ar", n.de = "de", n.en = "en", n.es = "es", n.fr = "fr", n.hi = "hi", n.id = "id", n.ja = "ja", n.ko = "ko", n.pl = "pl", n.pt = "pt", n.fil = "fil", n.ru = "ru", n.tr = "tr", n.vi = "vi", n.zh = "zh", n.fi = "fi", n.da = "da", n.sv = "sv", n.no = "no", n))(g || {});
const r = "sports_",
    p = {
        ar: {
            name: "اَلْعَرَبِيَّةُ",
            icon: "flags-united-arab-emirates"
        },
        de: {
            name: "Deutsch",
            icon: "flags-germany"
        },
        en: {
            name: "English",
            icon: "flags-united-kingdom"
        },
        es: {
            name: "Español",
            icon: "flags-spain"
        },
        fr: {
            name: "Français",
            icon: "flags-france"
        },
        hi: {
            name: "हिन्दी",
            icon: "flags-india"
        },
        id: {
            name: "Indonesian",
            icon: "flags-indonesia"
        },
        ind: {
            name: "Indonesian",
            icon: "flags-indonesia"
        },
        ja: {
            name: "日本語",
            icon: "flags-japan"
        },
        ko: {
            name: "한국어",
            icon: "flags-south-korea"
        },
        fil: {
            name: "Filipino",
            icon: "flags-philippines"
        },
        pl: {
            name: "Polski",
            icon: "flags-poland"
        },
        pt: {
            name: "Português",
            icon: "flags-brazil"
        },
        ru: {
            name: "Pусский",
            icon: "flags-russia"
        },
        tr: {
            name: "Türkçe",
            icon: "flags-turkey"
        },
        vi: {
            name: "Tiếng Việt",
            icon: "flags-vietnam"
        },
        zh: {
            name: "中文",
            icon: "flags-china"
        },
        fi: {
            name: "Suomen",
            icon: "flags-finland"
        },
        da: {
            name: "Denmark",
            icon: "flags-dk"
        },
        sv: {
            name: "Sweden",
            icon: "flags-sweden"
        },
        no: {
            name: "Norway",
            icon: "flags-norway"
        },
        [`${r}en`]: {
            name: "Sports",
            icon: "basketball"
        },
        [`${r}ru`]: {
            name: "Русский спорт",
            icon: "basketball"
        }
    },
    o = { ...p,
        challenges: {
            name: "Challenges",
            icon: "chat-challenges"
        },
        crash: {
            name: "Crash",
            icon: "chat-crash"
        },
        sports_en: {
            name: "Sports",
            icon: "chat-sports"
        },
        hi: {
            name: "India",
            icon: "flags-india"
        },
        pakistan: {
            name: "Pakistan",
            icon: "flags-pakistan"
        }
    },
    k = n => {
        var s, t;
        const {
            id: i
        } = n, e = n.name.startsWith(r) ? "sports" : "casino", a = n.name;
        return {
            id: i,
            iso: a,
            type: e,
            name: a in o && ((s = o[a]) == null ? void 0 : s.name) || a,
            icon: a in o && ((t = o[a]) == null ? void 0 : t.icon) || a
        }
    },
    m = n => n ? Date.parse(n.createdAt) : 0,
    f = n => n.reduce((e, a, s) => {
        const t = m(a) - m(n[s - 1]) < d,
            c = e[e.length - 1];
        return t && c ? [...e.slice(0, e.length - 1), [...e[e.length - 1], a]] : [...e, [a]]
    }, []),
    h = n => ({
        createdAt: n.createdAt,
        data: {
            __typename: "Timestamp"
        },
        user: {
            name: ""
        }
    }),
    l = n => n.reduce((e, a) => [...e, h(a[0]), ...a], []),
    C = n => {
        const i = f(n);
        return l(i)
    };
export {
    T as C, p as L, r as S, g as a, C as b, k as n
};