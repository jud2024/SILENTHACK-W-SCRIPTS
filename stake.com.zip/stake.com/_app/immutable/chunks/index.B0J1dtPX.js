import {
    s as g,
    m as c,
    j as d,
    i as S,
    L as f,
    K as _,
    M as b
} from "./scheduler.DXu26z7T.js";
import {
    S as h,
    i as k,
    t as i,
    g as j,
    b as l,
    e as q,
    c as v,
    a as C,
    m as K,
    d as L
} from "./index.Dz_MmNB3.js";
import {
    g as M,
    a as m
} from "./spread.CgU5AtxT.js";
import {
    S as N
} from "./Seo.BLs26qMC.js";

function u(a) {
    let s, n;
    const e = [a[0], a[1]];
    let o = {};
    for (let t = 0; t < e.length; t += 1) o = _(o, e[t]);
    return s = new N({
        props: o
    }), {
        c() {
            v(s.$$.fragment)
        },
        l(t) {
            C(s.$$.fragment, t)
        },
        m(t, r) {
            K(s, t, r), n = !0
        },
        p(t, r) {
            const p = r & 3 ? M(e, [r & 1 && m(t[0]), r & 2 && m(t[1])]) : {};
            s.$set(p)
        },
        i(t) {
            n || (i(s.$$.fragment, t), n = !0)
        },
        o(t) {
            l(s.$$.fragment, t), n = !1
        },
        d(t) {
            L(s, t)
        }
    }
}

function P(a) {
    let s, n, e = a[0] && u(a);
    return {
        c() {
            e && e.c(), s = c()
        },
        l(o) {
            e && e.l(o), s = c()
        },
        m(o, t) {
            e && e.m(o, t), d(o, s, t), n = !0
        },
        p(o, [t]) {
            o[0] ? e ? (e.p(o, t), t & 1 && i(e, 1)) : (e = u(o), e.c(), i(e, 1), e.m(s.parentNode, s)) : e && (j(), l(e, 1, 1, () => {
                e = null
            }), q())
        },
        i(o) {
            n || (i(e), n = !0)
        },
        o(o) {
            l(e), n = !1
        },
        d(o) {
            o && S(s), e && e.d(o)
        }
    }
}

function y(a, s, n) {
    const e = ["seo"];
    let o = f(s, e),
        {
            seo: t
        } = s;
    return a.$$set = r => {
        s = _(_({}, s), b(r)), n(1, o = f(s, e)), "seo" in r && n(0, t = r.seo)
    }, [t, o]
}
class E extends h {
    constructor(s) {
        super(), k(this, s, y, P, g, {
            seo: 0
        })
    }
}
export {
    E as S
};