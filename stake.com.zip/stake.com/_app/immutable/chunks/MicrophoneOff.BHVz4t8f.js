import {
    s as o,
    C as f,
    H as u,
    D as h,
    f as m,
    E as _,
    i as v,
    F as c,
    j as d,
    n as r
} from "./scheduler.DXu26z7T.js";
import {
    S as g,
    i as y
} from "./index.Dz_MmNB3.js";

function H(n) {
    let l, s, a = ` <title>${n[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M47 14.996C46.998 6.714 40.284 0 32 0c-5.102 0-9.608 2.546-12.318 6.438l-.032.05L47 23.998v-9.002Zm-12.5 39.85a20.57 20.57 0 0 0 13.842-8.018l.038-.052-4.18-2.78c-2.854 3.648-7.256 5.97-12.2 5.97a15.422 15.422 0 0 1-12.174-5.936l-.026-.034-4.18 2.75c3.276 4.362 8.17 7.356 13.776 8.088l.104.012v4.15H8v5h49v-5H34.5v-4.15ZM0 6.876l3-4.75 61 39.052-3 4.75-15.34-9.8-.038.092c-2.378 5.142-7.584 8.71-13.622 8.71-8.26 0-14.962-6.678-15-14.934v-12.23L0 6.876Z"></path>`,
        i;
    return {
        c() {
            l = f("svg"), s = new u(!0), this.h()
        },
        l(t) {
            l = h(t, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var e = m(l);
            s = _(e, !0), e.forEach(v), this.h()
        },
        h() {
            s.a = null, c(l, "fill", "currentColor"), c(l, "viewBox", "0 0 64 64"), c(l, "class", i = "svg-icon " + n[2]), c(l, "style", n[0])
        },
        m(t, e) {
            d(t, l, e), s.m(a, l)
        },
        p(t, [e]) {
            e & 2 && a !== (a = ` <title>${t[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M47 14.996C46.998 6.714 40.284 0 32 0c-5.102 0-9.608 2.546-12.318 6.438l-.032.05L47 23.998v-9.002Zm-12.5 39.85a20.57 20.57 0 0 0 13.842-8.018l.038-.052-4.18-2.78c-2.854 3.648-7.256 5.97-12.2 5.97a15.422 15.422 0 0 1-12.174-5.936l-.026-.034-4.18 2.75c3.276 4.362 8.17 7.356 13.776 8.088l.104.012v4.15H8v5h49v-5H34.5v-4.15ZM0 6.876l3-4.75 61 39.052-3 4.75-15.34-9.8-.038.092c-2.378 5.142-7.584 8.71-13.622 8.71-8.26 0-14.962-6.678-15-14.934v-12.23L0 6.876Z"></path>`) && s.p(a), e & 4 && i !== (i = "svg-icon " + t[2]) && c(l, "class", i), e & 1 && c(l, "style", t[0])
        },
        i: r,
        o: r,
        d(t) {
            t && v(l)
        }
    }
}

function M(n, l, s) {
    let {
        style: a = ""
    } = l, {
        alt: i = ""
    } = l, {
        class: t = ""
    } = l;
    return n.$$set = e => {
        "style" in e && s(0, a = e.style), "alt" in e && s(1, i = e.alt), "class" in e && s(2, t = e.class)
    }, [a, i, t]
}
class w extends g {
    constructor(l) {
        super(), y(this, l, M, H, o, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    w as M
};