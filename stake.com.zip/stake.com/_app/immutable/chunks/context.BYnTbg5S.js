import {
    v as a,
    x as c
} from "./scheduler.DXu26z7T.js";
import {
    d as n,
    w as r
} from "./index.C2-CG2CN.js";
const d = t => t <= 540,
    e = "@@fixtureStacked",
    k = () => {
        const t = r(0),
            s = n(t, o => d(o));
        return a(e, s), t
    },
    S = () => c(e);
export {
    S as g, k as s
};