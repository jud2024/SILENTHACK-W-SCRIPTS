import {
    a as t
} from "./object.KBCZ3_4R.js";
import {
    h as o
} from "./index.B4-7gKq3.js";
import {
    V as i
} from "./index.B81orGJm.js";
const n = {
        cantBeLessThanMin: a => ({
            id: "This must be greater than or equal to {min}",
            values: {
                min: a
            }
        }),
        cantBetMoreThanBalance: o._("Can't bet more than your balance!")
    },
    m = { ...n,
        cantBetMoreThanBalance: o._("Can't play more than your balance!")
    },
    f = {
        stake: n,
        sweeps: m
    },
    u = f[i] || n,
    h = async (a, {
        min: e,
        balance: r
    }, s) => {
        try {
            return await t().min(e, s._(u.cantBeLessThanMin(e))).max(Number(r), s._(u.cantBetMoreThanBalance)).validate(Number(a)), !1
        } catch ({
            errors: c
        }) {
            return c[0]
        }
    },
    y = async a => {
        try {
            return await t().validate(Number(a)), !1
        } catch ({
            errors: e
        }) {
            return e[0]
        }
    },
    T = async (a, {
        min: e
    }) => {
        try {
            return await t().min(e).validate(Number(a)), !1
        } catch ({
            errors: r
        }) {
            return r[0]
        }
    },
    B = async (a, {
        min: e,
        max: r
    }) => a < e ? `Minimum is "${e}"` : a > r ? `Maximum is "${r}"` : !1,
    M = /^[a-z0-9\u3131-\uD79d\u0430-\u044f\u00df-\u00f6\u00f8-\u00fc\u3400-\u4dbf\u4e00-\u9faf\u30a0-\u30ff\u3040-\u309f\u3005 ]+$/i,
    g = /^\d{6,15}$/;
export {
    B as a, h as b, g as c, T as d, y as n, M as v
};