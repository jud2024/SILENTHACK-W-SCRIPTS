import {
    s as w,
    c as x,
    X as B,
    O as j,
    P as q,
    j as d,
    i as b,
    t as k,
    h as L,
    l as P
} from "./scheduler.DXu26z7T.js";
import {
    S as z,
    i as C,
    c,
    a as m,
    m as _,
    t as p,
    b as $,
    d as g
} from "./index.Dz_MmNB3.js";
import {
    h,
    i as D
} from "./index.B4-7gKq3.js";
import "./index.B3dW9TVs.js";
import {
    S as E
} from "./index.DChG_RHX.js";
import {
    B as v
} from "./button.BwmFDw8u.js";
const u = {
    previous: h._("Previous"),
    next: h._("Next")
};

function N(i) {
    let e = i[3]._(u.previous) + "",
        s;
    return {
        c() {
            s = k(e)
        },
        l(t) {
            s = L(t, e)
        },
        m(t, a) {
            d(t, s, a)
        },
        p(t, a) {
            a & 8 && e !== (e = t[3]._(u.previous) + "") && P(s, e)
        },
        d(t) {
            t && b(s)
        }
    }
}

function O(i) {
    let e = i[3]._(u.next) + "",
        s;
    return {
        c() {
            s = k(e)
        },
        l(t) {
            s = L(t, e)
        },
        m(t, a) {
            d(t, s, a)
        },
        p(t, a) {
            a & 8 && e !== (e = t[3]._(u.next) + "") && P(s, e)
        },
        d(t) {
            t && b(s)
        }
    }
}

function X(i) {
    let e, s, t, a;
    return e = new v({
        props: {
            disabled: i[1] === 0,
            "data-testid": "pagination-previous",
            "data-test": "pagination-previous",
            $$slots: {
                default: [N]
            },
            $$scope: {
                ctx: i
            }
        }
    }), e.$on("click", i[4]), t = new v({
        props: {
            disabled: i[0] < i[2],
            "data-testid": "pagination-next",
            "data-test": "pagination-next",
            $$slots: {
                default: [O]
            },
            $$scope: {
                ctx: i
            }
        }
    }), t.$on("click", i[5]), {
        c() {
            c(e.$$.fragment), s = j(), c(t.$$.fragment)
        },
        l(n) {
            m(e.$$.fragment, n), s = q(n), m(t.$$.fragment, n)
        },
        m(n, o) {
            _(e, n, o), d(n, s, o), _(t, n, o), a = !0
        },
        p(n, o) {
            const f = {};
            o & 2 && (f.disabled = n[1] === 0), o & 136 && (f.$$scope = {
                dirty: o,
                ctx: n
            }), e.$set(f);
            const l = {};
            o & 5 && (l.disabled = n[0] < n[2]), o & 136 && (l.$$scope = {
                dirty: o,
                ctx: n
            }), t.$set(l)
        },
        i(n) {
            a || (p(e.$$.fragment, n), p(t.$$.fragment, n), a = !0)
        },
        o(n) {
            $(e.$$.fragment, n), $(t.$$.fragment, n), a = !1
        },
        d(n) {
            n && b(s), g(e, n), g(t, n)
        }
    }
}

function A(i) {
    let e, s;
    return e = new E({
        props: {
            horizontal: !0,
            gap: "larger",
            x: "center",
            $$slots: {
                default: [X]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            c(e.$$.fragment)
        },
        l(t) {
            m(e.$$.fragment, t)
        },
        m(t, a) {
            _(e, t, a), s = !0
        },
        p(t, [a]) {
            const n = {};
            a & 143 && (n.$$scope = {
                dirty: a,
                ctx: t
            }), e.$set(n)
        },
        i(t) {
            s || (p(e.$$.fragment, t), s = !0)
        },
        o(t) {
            $(e.$$.fragment, t), s = !1
        },
        d(t) {
            g(e, t)
        }
    }
}

function F(i, e, s) {
    let t;
    x(i, D, r => s(3, t = r));
    let {
        listLength: a
    } = e, {
        offset: n
    } = e, {
        limit: o
    } = e;
    const f = B(),
        l = () => f("previous"),
        S = () => f("next");
    return i.$$set = r => {
        "listLength" in r && s(0, a = r.listLength), "offset" in r && s(1, n = r.offset), "limit" in r && s(2, o = r.limit)
    }, [a, n, o, t, l, S]
}
class Q extends z {
    constructor(e) {
        super(), C(this, e, F, A, w, {
            listLength: 0,
            offset: 1,
            limit: 2
        })
    }
}
export {
    Q as P
};