import {
    s as f,
    C as u,
    H as h,
    D as m,
    f as v,
    E as _,
    i as r,
    F as c,
    j as g,
    n as o
} from "./scheduler.DXu26z7T.js";
import {
    S as y,
    i as H
} from "./index.Dz_MmNB3.js";

function M(n) {
    let t, s, a = ` <title>${n[1]||""}</title> <path d="M64 21.946V52c0 2.21-1.79 4-4 4H4c-2.21 0-4-1.79-4-4V21.974l32 17.44 32-17.468ZM32 32.614 64 15.12V12a4 4 0 0 0-3.972-4H4c-2.21 0-4 1.79-4 4v3.146l32 17.468Z"></path>`,
        i;
    return {
        c() {
            t = u("svg"), s = new h(!0), this.h()
        },
        l(l) {
            t = m(l, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var e = v(t);
            s = _(e, !0), e.forEach(r), this.h()
        },
        h() {
            s.a = null, c(t, "fill", "currentColor"), c(t, "viewBox", "0 0 64 64"), c(t, "class", i = "svg-icon " + n[2]), c(t, "style", n[0])
        },
        m(l, e) {
            g(l, t, e), s.m(a, t)
        },
        p(l, [e]) {
            e & 2 && a !== (a = ` <title>${l[1]||""}</title> <path d="M64 21.946V52c0 2.21-1.79 4-4 4H4c-2.21 0-4-1.79-4-4V21.974l32 17.44 32-17.468ZM32 32.614 64 15.12V12a4 4 0 0 0-3.972-4H4c-2.21 0-4 1.79-4 4v3.146l32 17.468Z"></path>`) && s.p(a), e & 4 && i !== (i = "svg-icon " + l[2]) && c(t, "class", i), e & 1 && c(t, "style", l[0])
        },
        i: o,
        o,
        d(l) {
            l && r(t)
        }
    }
}

function V(n, t, s) {
    let {
        style: a = ""
    } = t, {
        alt: i = ""
    } = t, {
        class: l = ""
    } = t;
    return n.$$set = e => {
        "style" in e && s(0, a = e.style), "alt" in e && s(1, i = e.alt), "class" in e && s(2, l = e.class)
    }, [a, i, l]
}
class Z extends y {
    constructor(t) {
        super(), H(this, t, V, M, f, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    Z as M
};