import {
    s as v,
    C as m,
    H as o,
    D as f,
    f as u,
    E as _,
    i as r,
    F as n,
    j as g,
    n as h
} from "./scheduler.DXu26z7T.js";
import {
    S as V,
    i as H
} from "./index.Dz_MmNB3.js";

function Z(i) {
    let t, l, a = ` <title>${i[1]||""}</title> <path d="M28.651 60.5H11.883c-1.85 0-3.347-1.5-3.347-3.348V37.036c-1.85 0-3.348-1.5-3.348-3.348v-6.722c0-1.85 1.5-3.348 3.348-3.348h20.116V60.5Zm26.813-36.884H35.347V60.5h16.768c1.85 0 3.349-1.5 3.349-3.348V37.036c1.85 0 3.348-1.5 3.348-3.348v-6.722c0-1.85-1.5-3.348-3.348-3.348v-.002ZM45.416 3.5C38.005 3.5 32 9.508 32 16.918h13.418c1.85 0 3.349-1.5 3.349-3.348V6.848c0-1.85-1.5-3.348-3.349-3.348Zm-26.836 0c-1.85 0-3.348 1.5-3.348 3.348v6.722c0 1.85 1.5 3.348 3.348 3.348H32C32 9.506 25.99 3.5 18.58 3.5Z"></path>`,
        c;
    return {
        c() {
            t = m("svg"), l = new o(!0), this.h()
        },
        l(s) {
            t = f(s, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var e = u(t);
            l = _(e, !0), e.forEach(r), this.h()
        },
        h() {
            l.a = null, n(t, "fill", "currentColor"), n(t, "viewBox", "0 0 64 64"), n(t, "class", c = "svg-icon " + i[2]), n(t, "style", i[0])
        },
        m(s, e) {
            g(s, t, e), l.m(a, t)
        },
        p(s, [e]) {
            e & 2 && a !== (a = ` <title>${s[1]||""}</title> <path d="M28.651 60.5H11.883c-1.85 0-3.347-1.5-3.347-3.348V37.036c-1.85 0-3.348-1.5-3.348-3.348v-6.722c0-1.85 1.5-3.348 3.348-3.348h20.116V60.5Zm26.813-36.884H35.347V60.5h16.768c1.85 0 3.349-1.5 3.349-3.348V37.036c1.85 0 3.348-1.5 3.348-3.348v-6.722c0-1.85-1.5-3.348-3.348-3.348v-.002ZM45.416 3.5C38.005 3.5 32 9.508 32 16.918h13.418c1.85 0 3.349-1.5 3.349-3.348V6.848c0-1.85-1.5-3.348-3.349-3.348Zm-26.836 0c-1.85 0-3.348 1.5-3.348 3.348v6.722c0 1.85 1.5 3.348 3.348 3.348H32C32 9.506 25.99 3.5 18.58 3.5Z"></path>`) && l.p(a), e & 4 && c !== (c = "svg-icon " + s[2]) && n(t, "class", c), e & 1 && n(t, "style", s[0])
        },
        i: h,
        o: h,
        d(s) {
            s && r(t)
        }
    }
}

function y(i, t, l) {
    let {
        style: a = ""
    } = t, {
        alt: c = ""
    } = t, {
        class: s = ""
    } = t;
    return i.$$set = e => {
        "style" in e && l(0, a = e.style), "alt" in e && l(1, c = e.alt), "class" in e && l(2, s = e.class)
    }, [a, c, s]
}
class w extends V {
    constructor(t) {
        super(), H(this, t, y, Z, v, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    w as R
};