import {
    V as t
} from "./index.B4-7gKq3.js";
const {
    store: n,
    setStoreContext: o
} = t(null, "@@KURATOR_GAME"), a = e => e.includes("playngoarchived-") ? "old-playngo" : e.includes("netentold-") ? "old-netent" : e.includes("-mobile-html-sw") ? "netent-mobile" : e.includes("hacksaw-") || e.includes("backseat-") || e.includes("bullshark-") ? "hacksaw" : null;
export {
    a as g, n as k, o as s
};