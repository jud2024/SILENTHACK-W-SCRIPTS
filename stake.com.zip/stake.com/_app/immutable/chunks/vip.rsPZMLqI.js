import {
    h as a
} from "./index.B4-7gKq3.js";
var g = (e => (e.none = "none", e.bronze = "bronze", e.silver = "silver", e.gold = "gold", e.platinum = "platinum", e["wagered(500k)"] = "wagered(500k)", e["wagered(1m)"] = "wagered(1m)", e["wagered(2.5m)"] = "wagered(2.5m)", e["wagered(5m)"] = "wagered(5m)", e["wagered(10m)"] = "wagered(10m)", e["wagered(25m)"] = "wagered(25m)", e["wagered(50m)"] = "wagered(50m)", e["wagered(100m)"] = "wagered(100m)", e["wagered(250m)"] = "wagered(250m)", e["wagered(500m)"] = "wagered(500m)", e["wagered(1000m)"] = "wagered(1000m)", e["wagered(2500m)"] = "wagered(2500m)", e["wagered(5000m)"] = "wagered(5000m)", e["wagered(10000m)"] = "wagered(10000m)", e["wagered(25000m)"] = "wagered(25000m)", e))(g || {});
const d = {
        none: "#2f4553",
        bronze: "#C69C6D",
        silver: "#B2CCCC",
        gold: "#FED100",
        platinum: "#6FDDE7",
        diamond: "#00E4FB",
        obsidian: "#B555FF",
        opal: "#FFBA0A",
        opal2: "#EB6175",
        plutonium: "#FF6926"
    },
    r = {
        none: d.none,
        bronze: d.bronze,
        silver: d.silver,
        gold: d.gold,
        platinum: d.platinum,
        "wagered(500k)": d.platinum,
        "wagered(1m)": d.platinum,
        "wagered(2.5m)": d.platinum,
        "wagered(5m)": d.platinum,
        "wagered(10m)": d.platinum,
        "wagered(25m)": d.diamond,
        "wagered(50m)": d.diamond,
        "wagered(100m)": d.diamond,
        "wagered(250m)": d.diamond,
        "wagered(500m)": d.diamond,
        "wagered(1000m)": d.obsidian,
        "wagered(2500m)": d.obsidian,
        "wagered(5000m)": d.opal,
        "wagered(10000m)": d.opal2,
        "wagered(25000m)": d.plutonium
    },
    n = {
        none: "vip-none",
        bronze: "vip-bronze",
        silver: "vip-silver",
        gold: "vip-gold",
        platinum: "vip-platinum-1",
        "wagered(500k)": "vip-platinum-2",
        "wagered(1m)": "vip-platinum-3",
        "wagered(2.5m)": "vip-platinum-4",
        "wagered(5m)": "vip-platinum-5",
        "wagered(10m)": "vip-platinum-6",
        "wagered(25m)": "vip-diamond-1",
        "wagered(50m)": "vip-diamond-2",
        "wagered(100m)": "vip-diamond-3",
        "wagered(250m)": "vip-diamond-4",
        "wagered(500m)": "vip-diamond-5",
        "wagered(1000m)": "vip-obsidian-1",
        "wagered(2500m)": "vip-obsidian-2",
        "wagered(5000m)": "vip-opal-1",
        "wagered(10000m)": "vip-opal-2",
        "wagered(25000m)": "vip-plutonium-1"
    },
    m = {
        none: a._("None"),
        bronze: a._("Bronze"),
        silver: a._("Silver"),
        gold: a._("Gold"),
        platinum: a._("Platinum I"),
        "wagered(500k)": a._("Platinum II"),
        "wagered(1m)": a._("Platinum III"),
        "wagered(2.5m)": a._("Platinum IV"),
        "wagered(5m)": a._("Platinum V"),
        "wagered(10m)": a._("Platinum VI"),
        "wagered(25m)": a._("Diamond"),
        "wagered(50m)": a._("Diamond II"),
        "wagered(100m)": a._("Diamond III"),
        "wagered(250m)": a._("Diamond IV"),
        "wagered(500m)": a._("Diamond V"),
        "wagered(1000m)": a._("Obsidian I"),
        "wagered(2500m)": a._("Obsidian II"),
        "wagered(5000m)": a._("Opal I"),
        "wagered(10000m)": a._("Opal II"),
        "wagered(25000m)": a._("Plutonium")
    },
    t = e => {
        for (let o = e.length; o >= 0; o--) {
            const i = e[o];
            if (i in m) return {
                message: m[i],
                icon: n[i]
            }
        }
        return {
            message: m.none,
            icon: n.none
        }
    },
    l = e => e in n ? n[e] : n.none,
    p = e => e in r ? r[e] : r.none,
    u = e => e in m ? m[e] : m.none,
    v = e => e === "none" ? "var(--green-400)" : r[e];
export {
    m as F, g as U, p as a, v as b, u as c, t as d, l as g
};