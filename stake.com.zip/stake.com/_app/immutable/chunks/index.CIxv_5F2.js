import {
    _ as s
} from "./index.B4-7gKq3.js";
import {
    r,
    a as T,
    t as b
} from "./helpers.D2PNFi1L.js";
import {
    n as i
} from "./index.DGKYLdH2.js";
import {
    c as d,
    a as l
} from "./autobet.C8QF9kCw.js";
import {
    s as o
} from "./interpreter.CJhK2JTN.js";
const c = (a, t) => {
        var e;
        i.open(d((e = t.data) == null ? void 0 : e.stopReason))
    },
    g = () => {
        i.open(l())
    };

function m(a) {
    const t = {
        initial: "idle",
        id: "autobetTab",
        entry: ["initAutobetDefaultStrategies"],
        states: {
            idle: {
                id: "autobetTab.idle",
                on: {
                    TOGGLE_AUTOBETTING: {
                        target: "betting",
                        actions: ["setInitialBettingState"]
                    },
                    TO_BET: {
                        target: "#betTab"
                    },
                    TO_ADVANCED: {
                        target: "#advancedTab"
                    }
                }
            },
            betting: {
                entry: [r, "snapshotAutobetInfo", g],
                exit: [c],
                type: "parallel",
                states: {
                    base: {
                        initial: "idle",
                        states: {
                            idle: {
                                type: "final",
                                entry: [T, b],
                                invoke: {
                                    src: "decideOnNextBet",
                                    onDone: "fetching",
                                    onError: "#autobetTab.idle"
                                },
                                on: {
                                    FINISH_AUTOBET: "#autobetTab.idle",
                                    START_FETCHING: {
                                        target: "fetching"
                                    }
                                }
                            },
                            fetching: {
                                entry: ["resetBetState"],
                                invoke: {
                                    id: "mutationBet",
                                    src: "mutationBet",
                                    onDone: {
                                        actions: o((e, n) => ({
                                            type: "SUCCESS",
                                            bet: n.data
                                        }))
                                    },
                                    onError: {
                                        actions: o("ERROR")
                                    }
                                },
                                on: {
                                    SUCCESS: {
                                        target: "revealing"
                                    },
                                    ERROR: {
                                        target: "#autobetTab.idle"
                                    }
                                }
                            },
                            revealing: {}
                        }
                    },
                    nextBet: {
                        initial: "continue",
                        id: "autobetTab.betting.nextBet",
                        states: {
                            continue: {
                                on: {
                                    TOGGLE_AUTOBETTING: "stop",
                                    STOP_AUTOBETTING: "stop",
                                    TO_BET: "stop",
                                    ERROR: "stop"
                                }
                            },
                            stop: {
                                type: "final"
                            }
                        }
                    }
                },
                onDone: {
                    target: "#autobetTab.idle"
                }
            }
        }
    };
    return s.merge(t, a)
}
export {
    g as a, c as b, m as e
};