import {
    B as i,
    D as t,
    z as s,
    E as n,
    G as c,
    H as f
} from "./index.B4-7gKq3.js";
import {
    d as m
} from "./index.C2-CG2CN.js";
const a = "fiat_number_format",
    u = () => {
        const r = t(a);
        if (!r && s) {
            const e = t("locale");
            if (n(e)) return e
        }
        return r || "en"
    },
    F = i(a, u()),
    l = m([c, f, F], ([r, e, o]) => r === "inr" || e === "inr" ? "hi" : o);
export {
    a as F, F as a, l as f
};