import {
    s as B,
    m as k,
    j as N,
    i as g,
    L as z,
    K as y,
    M as W,
    N as m,
    J,
    a as q,
    e as F,
    d as G,
    f as H,
    a8 as E,
    W as h,
    u as S,
    g as U,
    b as V,
    r as I,
    a3 as fe,
    q as _e
} from "./scheduler.DXu26z7T.js";
import {
    S as Q,
    i as R,
    g as me,
    b as v,
    e as ce,
    t as p,
    c as de,
    a as he,
    m as be,
    d as ve
} from "./index.Dz_MmNB3.js";
import {
    g as D,
    a as pe
} from "./spread.CgU5AtxT.js";
import {
    g as ge,
    a as ye
} from "./ctx.CWJzPttI.js";
import {
    b as K
} from "./index.B3dW9TVs.js";
import {
    c as L
} from "./index.BljstGtu.js";

function ke(t, e) {
    const i = [];
    return e.builders.forEach(a => {
        const n = a.action(t);
        n && i.push(n)
    }), {
        destroy: () => {
            i.forEach(a => {
                a.destroy && a.destroy()
            })
        }
    }
}

function M(t) {
    const e = {};
    return t.forEach(i => {
        Object.keys(i).forEach(a => {
            a !== "action" && (e[a] = i[a])
        })
    }), e
}

function Ne(t) {
    let e = t[1] ? "a" : "button",
        i, a, n = (t[1] ? "a" : "button") && C(t);
    return {
        c() {
            n && n.c(), i = k()
        },
        l(l) {
            n && n.l(l), i = k()
        },
        m(l, f) {
            n && n.m(l, f), N(l, i, f), a = !0
        },
        p(l, f) {
            l[1], e ? B(e, l[1] ? "a" : "button") ? (n.d(1), n = C(l), e = l[1] ? "a" : "button", n.c(), n.m(i.parentNode, i)) : n.p(l, f) : (n = C(l), e = l[1] ? "a" : "button", n.c(), n.m(i.parentNode, i))
        },
        i(l) {
            a || (p(n, l), a = !0)
        },
        o(l) {
            v(n, l), a = !1
        },
        d(l) {
            l && g(i), n && n.d(l)
        }
    }
}

function Oe(t) {
    let e = t[1] ? "a" : "button",
        i, a, n = (t[1] ? "a" : "button") && P(t);
    return {
        c() {
            n && n.c(), i = k()
        },
        l(l) {
            n && n.l(l), i = k()
        },
        m(l, f) {
            n && n.m(l, f), N(l, i, f), a = !0
        },
        p(l, f) {
            l[1], e ? B(e, l[1] ? "a" : "button") ? (n.d(1), n = P(l), e = l[1] ? "a" : "button", n.c(), n.m(i.parentNode, i)) : n.p(l, f) : (n = P(l), e = l[1] ? "a" : "button", n.c(), n.m(i.parentNode, i))
        },
        i(l) {
            a || (p(n, l), a = !0)
        },
        o(l) {
            v(n, l), a = !1
        },
        d(l) {
            l && g(i), n && n.d(l)
        }
    }
}

function C(t) {
    let e, i, a, n, l;
    const f = t[7].default,
        _ = q(f, t, t[6], null);
    let r = [{
            type: i = t[1] ? void 0 : t[2]
        }, {
            href: t[1]
        }, {
            tabindex: "0"
        }, t[5], t[4]],
        c = {};
    for (let s = 0; s < r.length; s += 1) c = y(c, r[s]);
    return {
        c() {
            e = F(t[1] ? "a" : "button"), _ && _.c(), this.h()
        },
        l(s) {
            e = G(s, ((t[1] ? "a" : "button") || "null").toUpperCase(), {
                type: !0,
                href: !0,
                tabindex: !0
            });
            var u = H(e);
            _ && _.l(u), u.forEach(g), this.h()
        },
        h() {
            E(t[1] ? "a" : "button")(e, c)
        },
        m(s, u) {
            N(s, e, u), _ && _.m(e, null), t[29](e), a = !0, n || (l = [h(e, "click", t[18]), h(e, "change", t[19]), h(e, "keydown", t[20]), h(e, "keyup", t[21]), h(e, "mouseenter", t[22]), h(e, "mouseleave", t[23]), h(e, "mousedown", t[24]), h(e, "pointerdown", t[25]), h(e, "mouseup", t[26]), h(e, "pointerup", t[27])], n = !0)
        },
        p(s, u) {
            _ && _.p && (!a || u & 64) && S(_, f, s, s[6], a ? V(f, s[6], u, null) : U(s[6]), null), E(s[1] ? "a" : "button")(e, c = D(r, [(!a || u & 6 && i !== (i = s[1] ? void 0 : s[2])) && {
                type: i
            }, (!a || u & 2) && {
                href: s[1]
            }, {
                tabindex: "0"
            }, u & 32 && s[5], s[4]]))
        },
        i(s) {
            a || (p(_, s), a = !0)
        },
        o(s) {
            v(_, s), a = !1
        },
        d(s) {
            s && g(e), _ && _.d(s), t[29](null), n = !1, I(l)
        }
    }
}

function P(t) {
    let e, i, a, n, l, f;
    const _ = t[7].default,
        r = q(_, t, t[6], null);
    let c = [{
            type: i = t[1] ? void 0 : t[2]
        }, {
            href: t[1]
        }, {
            tabindex: "0"
        }, M(t[3]), t[5], t[4]],
        s = {};
    for (let u = 0; u < c.length; u += 1) s = y(s, c[u]);
    return {
        c() {
            e = F(t[1] ? "a" : "button"), r && r.c(), this.h()
        },
        l(u) {
            e = G(u, ((t[1] ? "a" : "button") || "null").toUpperCase(), {
                type: !0,
                href: !0,
                tabindex: !0
            });
            var b = H(e);
            r && r.l(b), b.forEach(g), this.h()
        },
        h() {
            E(t[1] ? "a" : "button")(e, s)
        },
        m(u, b) {
            N(u, e, b), r && r.m(e, null), t[28](e), n = !0, l || (f = [h(e, "click", t[8]), h(e, "change", t[9]), h(e, "keydown", t[10]), h(e, "keyup", t[11]), h(e, "mouseenter", t[12]), h(e, "mouseleave", t[13]), h(e, "mousedown", t[14]), h(e, "pointerdown", t[15]), h(e, "mouseup", t[16]), h(e, "pointerup", t[17]), fe(a = ke.call(null, e, {
                builders: t[3]
            }))], l = !0)
        },
        p(u, b) {
            r && r.p && (!n || b & 64) && S(r, _, u, u[6], n ? V(_, u[6], b, null) : U(u[6]), null), E(u[1] ? "a" : "button")(e, s = D(c, [(!n || b & 6 && i !== (i = u[1] ? void 0 : u[2])) && {
                type: i
            }, (!n || b & 2) && {
                href: u[1]
            }, {
                tabindex: "0"
            }, b & 8 && M(u[3]), b & 32 && u[5], u[4]])), a && _e(a.update) && b & 8 && a.update.call(null, {
                builders: u[3]
            })
        },
        i(u) {
            n || (p(r, u), n = !0)
        },
        o(u) {
            v(r, u), n = !1
        },
        d(u) {
            u && g(e), r && r.d(u), t[28](null), l = !1, I(f)
        }
    }
}

function ze(t) {
    let e, i, a, n;
    const l = [Oe, Ne],
        f = [];

    function _(r, c) {
        return r[3] && r[3].length ? 0 : 1
    }
    return e = _(t), i = f[e] = l[e](t), {
        c() {
            i.c(), a = k()
        },
        l(r) {
            i.l(r), a = k()
        },
        m(r, c) {
            f[e].m(r, c), N(r, a, c), n = !0
        },
        p(r, [c]) {
            let s = e;
            e = _(r), e === s ? f[e].p(r, c) : (me(), v(f[s], 1, 1, () => {
                f[s] = null
            }), ce(), i = f[e], i ? i.p(r, c) : (i = f[e] = l[e](r), i.c()), p(i, 1), i.m(a.parentNode, a))
        },
        i(r) {
            n || (p(i), n = !0)
        },
        o(r) {
            v(i), n = !1
        },
        d(r) {
            r && g(a), f[e].d(r)
        }
    }
}

function Ee(t, e, i) {
    const a = ["href", "type", "builders", "el"];
    let n = z(e, a),
        {
            $$slots: l = {},
            $$scope: f
        } = e,
        {
            href: _ = void 0
        } = e,
        {
            type: r = void 0
        } = e,
        {
            builders: c = []
        } = e,
        {
            el: s = void 0
        } = e;
    const u = {
        "data-button-root": ""
    };

    function b(o) {
        m.call(this, t, o)
    }

    function O(o) {
        m.call(this, t, o)
    }

    function j(o) {
        m.call(this, t, o)
    }

    function A(o) {
        m.call(this, t, o)
    }

    function d(o) {
        m.call(this, t, o)
    }

    function T(o) {
        m.call(this, t, o)
    }

    function X(o) {
        m.call(this, t, o)
    }

    function Y(o) {
        m.call(this, t, o)
    }

    function Z(o) {
        m.call(this, t, o)
    }

    function w(o) {
        m.call(this, t, o)
    }

    function x(o) {
        m.call(this, t, o)
    }

    function $(o) {
        m.call(this, t, o)
    }

    function ee(o) {
        m.call(this, t, o)
    }

    function te(o) {
        m.call(this, t, o)
    }

    function ne(o) {
        m.call(this, t, o)
    }

    function le(o) {
        m.call(this, t, o)
    }

    function ie(o) {
        m.call(this, t, o)
    }

    function ae(o) {
        m.call(this, t, o)
    }

    function oe(o) {
        m.call(this, t, o)
    }

    function se(o) {
        m.call(this, t, o)
    }

    function ue(o) {
        J[o ? "unshift" : "push"](() => {
            s = o, i(0, s)
        })
    }

    function re(o) {
        J[o ? "unshift" : "push"](() => {
            s = o, i(0, s)
        })
    }
    return t.$$set = o => {
        e = y(y({}, e), W(o)), i(5, n = z(e, a)), "href" in o && i(1, _ = o.href), "type" in o && i(2, r = o.type), "builders" in o && i(3, c = o.builders), "el" in o && i(0, s = o.el), "$$scope" in o && i(6, f = o.$$scope)
    }, [s, _, r, c, u, n, f, l, b, O, j, A, d, T, X, Y, Z, w, x, $, ee, te, ne, le, ie, ae, oe, se, ue, re]
}
let Be = class extends Q {
    constructor(e) {
        super(), R(this, e, Ee, ze, B, {
            href: 1,
            type: 2,
            builders: 3,
            el: 0
        })
    }
};

function je(t) {
    let e;
    const i = t[7].default,
        a = q(i, t, t[10], null);
    return {
        c() {
            a && a.c()
        },
        l(n) {
            a && a.l(n)
        },
        m(n, l) {
            a && a.m(n, l), e = !0
        },
        p(n, l) {
            a && a.p && (!e || l & 1024) && S(a, i, n, n[10], e ? V(i, n[10], l, null) : U(n[10]), null)
        },
        i(n) {
            e || (p(a, n), e = !0)
        },
        o(n) {
            v(a, n), e = !1
        },
        d(n) {
            a && a.d(n)
        }
    }
}

function Ae(t) {
    let e, i;
    const a = [{
        builders: t[5]
    }, {
        class: L(K({
            variant: t[1],
            size: t[2],
            className: t[0],
            iconOnly: t[3],
            active: t[4]
        }))
    }, {
        type: "button"
    }, t[6]];
    let n = {
        $$slots: {
            default: [je]
        },
        $$scope: {
            ctx: t
        }
    };
    for (let l = 0; l < a.length; l += 1) n = y(n, a[l]);
    return e = new Be({
        props: n
    }), e.$on("click", t[8]), e.$on("keydown", t[9]), {
        c() {
            de(e.$$.fragment)
        },
        l(l) {
            he(e.$$.fragment, l)
        },
        m(l, f) {
            be(e, l, f), i = !0
        },
        p(l, [f]) {
            const _ = f & 127 ? D(a, [f & 32 && {
                builders: l[5]
            }, f & 31 && {
                class: L(K({
                    variant: l[1],
                    size: l[2],
                    className: l[0],
                    iconOnly: l[3],
                    active: l[4]
                }))
            }, a[2], f & 64 && pe(l[6])]) : {};
            f & 1024 && (_.$$scope = {
                dirty: f,
                ctx: l
            }), e.$set(_)
        },
        i(l) {
            i || (p(e.$$.fragment, l), i = !0)
        },
        o(l) {
            v(e.$$.fragment, l), i = !1
        },
        d(l) {
            ve(e, l)
        }
    }
}

function Ce(t, e, i) {
    const a = ["class", "variant", "size", "iconOnly", "active", "builders"];
    let n = z(e, a),
        {
            $$slots: l = {},
            $$scope: f
        } = e;
    const _ = ge();
    let {
        class: r = void 0
    } = e, {
        variant: c = ye({
            parent: _
        })
    } = e, {
        size: s = "md"
    } = e, {
        iconOnly: u = !1
    } = e, {
        active: b = !1
    } = e, {
        builders: O = []
    } = e;

    function j(d) {
        m.call(this, t, d)
    }

    function A(d) {
        m.call(this, t, d)
    }
    return t.$$set = d => {
        e = y(y({}, e), W(d)), i(6, n = z(e, a)), "class" in d && i(0, r = d.class), "variant" in d && i(1, c = d.variant), "size" in d && i(2, s = d.size), "iconOnly" in d && i(3, u = d.iconOnly), "active" in d && i(4, b = d.active), "builders" in d && i(5, O = d.builders), "$$scope" in d && i(10, f = d.$$scope)
    }, [r, c, s, u, b, O, n, l, j, A, f]
}
class Ke extends Q {
    constructor(e) {
        super(), R(this, e, Ce, Ae, B, {
            class: 0,
            variant: 1,
            size: 2,
            iconOnly: 3,
            active: 4,
            builders: 5
        })
    }
}
export {
    Ke as B
};