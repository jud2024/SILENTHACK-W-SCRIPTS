import {
    s as T,
    C as he,
    H as _e,
    D as de,
    f as P,
    E as be,
    i as h,
    F as v,
    j as w,
    n as A,
    e as z,
    d as G,
    V as q,
    t as y,
    h as H,
    l as j,
    k as D,
    O as N,
    m as W,
    P as S,
    c as J,
    a as ae,
    W as ve,
    u as ne,
    g as le,
    b as ie
} from "./scheduler.DXu26z7T.js";
import {
    S as F,
    i as R,
    g as L,
    b as k,
    e as O,
    t as b,
    c as E,
    a as I,
    m as V,
    d as M
} from "./index.Dz_MmNB3.js";
import {
    cb as ke,
    h as Z,
    i as ce,
    r as we
} from "./index.B4-7gKq3.js";
import "./index.ByMdEFI5.js";
import {
    T as Q
} from "./index.D7nbRHfU.js";
import {
    I as pe
} from "./index.BmTk3-ns.js";
import {
    g as U
} from "./generatePath.DsXei5FM.js";
import {
    p as K
} from "./paths.RTtAVJV7.js";
import {
    P as X
} from "./index.B1KDSkU5.js";
import {
    I as Pe
} from "./index.D7QUfg7j.js";
import {
    P as ze
} from "./Play.D6w7pnpi.js";
import {
    F as Ge
} from "./index.CIBDG73T.js";
import {
    B as Ee
} from "./index.zmvGeK6M.js";
import {
    S as Ie
} from "./index.DChG_RHX.js";

function Ve(i) {
    let e, t, a = ` <title>${i[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M41.963 32H64c0 17.674-14.326 32-32 32S0 49.674 0 32 14.326 0 32 0v12.842H11.596l.012-.014c-3.873 4.102-6.515 9.379-7.354 15.386l9.813 2.79 8.967 13.947 7.97 2.99 2.58 11.187 5.39-16.17L41.963 32Zm15.94-18.93h1.992v14.945H38.974V13.07h2.989V8.09a7.97 7.97 0 0 1 15.94 0v4.98Zm-7.97-8.965a3.984 3.984 0 0 0-3.985 3.985v4.98h7.97V8.09a3.984 3.984 0 0 0-3.985-3.985Z"></path>`,
        n;
    return {
        c() {
            e = he("svg"), t = new _e(!0), this.h()
        },
        l(l) {
            e = de(l, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var r = P(e);
            t = be(r, !0), r.forEach(h), this.h()
        },
        h() {
            t.a = null, v(e, "fill", "currentColor"), v(e, "viewBox", "0 0 64 64"), v(e, "class", n = "svg-icon " + i[2]), v(e, "style", i[0])
        },
        m(l, r) {
            w(l, e, r), t.m(a, e)
        },
        p(l, [r]) {
            r & 2 && a !== (a = ` <title>${l[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M41.963 32H64c0 17.674-14.326 32-32 32S0 49.674 0 32 14.326 0 32 0v12.842H11.596l.012-.014c-3.873 4.102-6.515 9.379-7.354 15.386l9.813 2.79 8.967 13.947 7.97 2.99 2.58 11.187 5.39-16.17L41.963 32Zm15.94-18.93h1.992v14.945H38.974V13.07h2.989V8.09a7.97 7.97 0 0 1 15.94 0v4.98Zm-7.97-8.965a3.984 3.984 0 0 0-3.985 3.985v4.98h7.97V8.09a3.984 3.984 0 0 0-3.985-3.985Z"></path>`) && t.p(a), r & 4 && n !== (n = "svg-icon " + l[2]) && v(e, "class", n), r & 1 && v(e, "style", l[0])
        },
        i: A,
        o: A,
        d(l) {
            l && h(e)
        }
    }
}

function Me(i, e, t) {
    let {
        style: a = ""
    } = e, {
        alt: n = ""
    } = e, {
        class: l = ""
    } = e;
    return i.$$set = r => {
        "style" in r && t(0, a = r.style), "alt" in r && t(1, n = r.alt), "class" in r && t(2, l = r.class)
    }, [a, n, l]
}
class qe extends F {
    constructor(e) {
        super(), R(this, e, Me, Ve, T, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}

function De(i) {
    let e;
    return {
        c() {
            e = y(i[3])
        },
        l(t) {
            e = H(t, i[3])
        },
        m(t, a) {
            w(t, e, a)
        },
        p(t, a) {
            a & 8 && j(e, t[3])
        },
        i: A,
        o: A,
        d(t) {
            t && h(e)
        }
    }
}

function Be(i) {
    let e, t;
    return {
        c() {
            e = z("a"), t = y(i[3]), this.h()
        },
        l(a) {
            e = G(a, "A", {
                href: !0
            });
            var n = P(e);
            t = H(n, i[3]), n.forEach(h), this.h()
        },
        h() {
            v(e, "href", i[4])
        },
        m(a, n) {
            w(a, e, n), D(e, t)
        },
        p(a, n) {
            n & 8 && j(t, a[3]), n & 16 && v(e, "href", a[4])
        },
        i: A,
        o: A,
        d(a) {
            a && h(e)
        }
    }
}

function Ae(i) {
    let e, t;
    return e = new X({
        props: {
            width: "100%"
        }
    }), {
        c() {
            E(e.$$.fragment)
        },
        l(a) {
            I(e.$$.fragment, a)
        },
        m(a, n) {
            V(e, a, n), t = !0
        },
        p: A,
        i(a) {
            t || (b(e.$$.fragment, a), t = !0)
        },
        o(a) {
            k(e.$$.fragment, a), t = !1
        },
        d(a) {
            M(e, a)
        }
    }
}

function Ce(i) {
    let e, t, a, n;
    const l = [Ae, Be, De],
        r = [];

    function s(f, u) {
        return f[2] ? 0 : f[1] ? 1 : 2
    }
    return t = s(i), a = r[t] = l[t](i), {
        c() {
            e = z("strong"), a.c(), this.h()
        },
        l(f) {
            e = G(f, "STRONG", {
                class: !0
            });
            var u = P(e);
            a.l(u), u.forEach(h), this.h()
        },
        h() {
            v(e, "class", "gameName svelte-1gmhd6w"), q(e, "quick-game", i[0] === "quickGame")
        },
        m(f, u) {
            w(f, e, u), r[t].m(e, null), n = !0
        },
        p(f, [u]) {
            let m = t;
            t = s(f), t === m ? r[t].p(f, u) : (L(), k(r[m], 1, 1, () => {
                r[m] = null
            }), O(), a = r[t], a ? a.p(f, u) : (a = r[t] = l[t](f), a.c()), b(a, 1), a.m(e, null)), (!n || u & 1) && q(e, "quick-game", f[0] === "quickGame")
        },
        i(f) {
            n || (b(a), n = !0)
        },
        o(f) {
            k(a), n = !1
        },
        d(f) {
            f && h(e), r[t].d()
        }
    }
}

function Ne(i, e, t) {
    let {
        variant: a = "normal"
    } = e, {
        horizontal: n
    } = e, {
        loading: l
    } = e, {
        name: r
    } = e, {
        gamePath: s
    } = e;
    return i.$$set = f => {
        "variant" in f && t(0, a = f.variant), "horizontal" in f && t(1, n = f.horizontal), "loading" in f && t(2, l = f.loading), "name" in f && t(3, r = f.name), "gamePath" in f && t(4, s = f.gamePath)
    }, [a, n, l, r, s]
}
class Se extends F {
    constructor(e) {
        super(), R(this, e, Ne, Ce, T, {
            variant: 0,
            horizontal: 1,
            loading: 2,
            name: 3,
            gamePath: 4
        })
    }
}

function re(i) {
    let e, t, a, n, l, r, s, f;
    t = new ze({});
    const u = [He, ye],
        m = [];

    function _(c, o) {
        return c[0] ? 0 : 1
    }
    return r = _(i), s = m[r] = u[r](i), {
        c() {
            e = z("div"), E(t.$$.fragment), a = N(), n = z("div"), l = z("strong"), s.c(), this.h()
        },
        l(c) {
            e = G(c, "DIV", {
                class: !0
            });
            var o = P(e);
            I(t.$$.fragment, o), o.forEach(h), a = S(c), n = G(c, "DIV", {
                class: !0
            });
            var g = P(n);
            l = G(g, "STRONG", {});
            var p = P(l);
            s.l(p), p.forEach(h), g.forEach(h), this.h()
        },
        h() {
            v(e, "class", "wrap-icon svelte-1xxazmb"), q(e, "horizontal", i[4] && i[2] !== 0), v(n, "class", "game-info-wrap game-group svelte-1xxazmb"), q(n, "horizontal", i[4])
        },
        m(c, o) {
            w(c, e, o), V(t, e, null), w(c, a, o), w(c, n, o), D(n, l), m[r].m(l, null), f = !0
        },
        p(c, o) {
            (!f || o & 20) && q(e, "horizontal", c[4] && c[2] !== 0);
            let g = r;
            r = _(c), r === g ? m[r].p(c, o) : (L(), k(m[g], 1, 1, () => {
                m[g] = null
            }), O(), s = m[r], s ? s.p(c, o) : (s = m[r] = u[r](c), s.c()), b(s, 1), s.m(l, null)), (!f || o & 16) && q(n, "horizontal", c[4])
        },
        i(c) {
            f || (b(t.$$.fragment, c), b(s), f = !0)
        },
        o(c) {
            k(t.$$.fragment, c), k(s), f = !1
        },
        d(c) {
            c && (h(e), h(a), h(n)), M(t), m[r].d()
        }
    }
}

function ye(i) {
    var a, n, l;
    let e = (((n = (a = i[7]) == null ? void 0 : a.group) == null ? void 0 : n.translation) || ((l = i[6]) == null ? void 0 : l.name)) + "",
        t;
    return {
        c() {
            t = y(e)
        },
        l(r) {
            t = H(r, e)
        },
        m(r, s) {
            w(r, t, s)
        },
        p(r, s) {
            var f, u, m;
            s & 64 && e !== (e = (((u = (f = r[7]) == null ? void 0 : f.group) == null ? void 0 : u.translation) || ((m = r[6]) == null ? void 0 : m.name)) + "") && j(t, e)
        },
        i: A,
        o: A,
        d(r) {
            r && h(t)
        }
    }
}

function He(i) {
    let e, t;
    return e = new X({
        props: {
            width: "8ch"
        }
    }), {
        c() {
            E(e.$$.fragment)
        },
        l(a) {
            I(e.$$.fragment, a)
        },
        m(a, n) {
            V(e, a, n), t = !0
        },
        p: A,
        i(a) {
            t || (b(e.$$.fragment, a), t = !0)
        },
        o(a) {
            k(e.$$.fragment, a), t = !1
        },
        d(a) {
            M(e, a)
        }
    }
}

function Te(i) {
    let e, t, a, n, l, r;
    a = new Se({
        props: {
            horizontal: i[4],
            loading: i[0],
            gamePath: i[3],
            name: i[1],
            variant: i[5]
        }
    });
    let s = i[5] === "normal" && re(i);
    return {
        c() {
            e = z("div"), t = z("div"), E(a.$$.fragment), n = N(), s && s.c(), l = W(), this.h()
        },
        l(f) {
            e = G(f, "DIV", {
                class: !0
            });
            var u = P(e);
            t = G(u, "DIV", {
                class: !0
            });
            var m = P(t);
            I(a.$$.fragment, m), m.forEach(h), u.forEach(h), n = S(f), s && s.l(f), l = W(), this.h()
        },
        h() {
            v(t, "class", "game-info-wrap svelte-1xxazmb"), v(e, "class", "game-info-container svelte-1xxazmb"), q(e, "cover", i[5] === "quickGame")
        },
        m(f, u) {
            w(f, e, u), D(e, t), V(a, t, null), w(f, n, u), s && s.m(f, u), w(f, l, u), r = !0
        },
        p(f, [u]) {
            const m = {};
            u & 16 && (m.horizontal = f[4]), u & 1 && (m.loading = f[0]), u & 8 && (m.gamePath = f[3]), u & 2 && (m.name = f[1]), u & 32 && (m.variant = f[5]), a.$set(m), (!r || u & 32) && q(e, "cover", f[5] === "quickGame"), f[5] === "normal" ? s ? (s.p(f, u), u & 32 && b(s, 1)) : (s = re(f), s.c(), b(s, 1), s.m(l.parentNode, l)) : s && (L(), k(s, 1, 1, () => {
                s = null
            }), O())
        },
        i(f) {
            r || (b(a.$$.fragment, f), b(s), r = !0)
        },
        o(f) {
            k(a.$$.fragment, f), k(s), r = !1
        },
        d(f) {
            f && (h(e), h(n), h(l)), M(a), s && s.d(f)
        }
    }
}

function je(i, e, t) {
    let {
        loading: a
    } = e, {
        name: n
    } = e, {
        edge: l = 0
    } = e, {
        gamePath: r
    } = e, {
        horizontal: s = !1
    } = e, {
        variant: f = "normal"
    } = e, {
        provider: u
    } = e, {
        groupGames: m
    } = e;
    const _ = m == null ? void 0 : m.find(c => {
        var o;
        return ((o = c == null ? void 0 : c.group) == null ? void 0 : o.type) === ke.provider
    });
    return i.$$set = c => {
        "loading" in c && t(0, a = c.loading), "name" in c && t(1, n = c.name), "edge" in c && t(2, l = c.edge), "gamePath" in c && t(3, r = c.gamePath), "horizontal" in c && t(4, s = c.horizontal), "variant" in c && t(5, f = c.variant), "provider" in c && t(6, u = c.provider), "groupGames" in c && t(8, m = c.groupGames)
    }, [a, n, l, r, s, f, u, _, m]
}
class Fe extends F {
    constructor(e) {
        super(), R(this, e, je, Te, T, {
            loading: 0,
            name: 1,
            edge: 2,
            gamePath: 3,
            horizontal: 4,
            variant: 5,
            provider: 6,
            groupGames: 8
        })
    }
}
const se = {
        edge: Z._("Edge"),
        na: Z._("N/A"),
        notAvailableInRegion: Z._("Not available in your region")
    },
    fe = {
        readyToPlay: Z._("Ready to play"),
        playing: Z._("playing")
    };

function Re(i) {
    let e, t, a, n, l, r, s = i[1]._(fe.playing) + "",
        f, u;
    return e = new Ee({
        props: {
            relative: !0,
            animation: "pulse",
            style: "width: 6.5px; height: 6.5px"
        }
    }), l = new Ge({
        props: {
            value: i[0],
            minimumFractionDigits: 0,
            variant: "highlighted",
            weight: "semibold",
            size: "sm"
        }
    }), {
        c() {
            E(e.$$.fragment), t = N(), a = z("span"), n = y(` 
      `), E(l.$$.fragment), r = N(), f = y(s)
        },
        l(m) {
            I(e.$$.fragment, m), t = S(m), a = G(m, "SPAN", {});
            var _ = P(a);
            n = H(_, ` 
      `), I(l.$$.fragment, _), r = S(_), f = H(_, s), _.forEach(h)
        },
        m(m, _) {
            V(e, m, _), w(m, t, _), w(m, a, _), D(a, n), V(l, a, null), D(a, r), D(a, f), u = !0
        },
        p(m, _) {
            const c = {};
            _ & 1 && (c.value = m[0]), l.$set(c), (!u || _ & 2) && s !== (s = m[1]._(fe.playing) + "") && j(f, s)
        },
        i(m) {
            u || (b(e.$$.fragment, m), b(l.$$.fragment, m), u = !0)
        },
        o(m) {
            k(e.$$.fragment, m), k(l.$$.fragment, m), u = !1
        },
        d(m) {
            m && (h(t), h(a)), M(e, m), M(l)
        }
    }
}

function Ze(i) {
    let e, t;
    return e = new Q({
        props: {
            weight: "semibold",
            size: "sm",
            $$slots: {
                default: [Re]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            E(e.$$.fragment)
        },
        l(a) {
            I(e.$$.fragment, a)
        },
        m(a, n) {
            V(e, a, n), t = !0
        },
        p(a, n) {
            const l = {};
            n & 7 && (l.$$scope = {
                dirty: n,
                ctx: a
            }), e.$set(l)
        },
        i(a) {
            t || (b(e.$$.fragment, a), t = !0)
        },
        o(a) {
            k(e.$$.fragment, a), t = !1
        },
        d(a) {
            M(e, a)
        }
    }
}

function Le(i) {
    let e, t;
    return e = new Ie({
        props: {
            horizontal: !0,
            paddingTop: "smaller",
            $$slots: {
                default: [Ze]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            E(e.$$.fragment)
        },
        l(a) {
            I(e.$$.fragment, a)
        },
        m(a, n) {
            V(e, a, n), t = !0
        },
        p(a, [n]) {
            const l = {};
            n & 7 && (l.$$scope = {
                dirty: n,
                ctx: a
            }), e.$set(l)
        },
        i(a) {
            t || (b(e.$$.fragment, a), t = !0)
        },
        o(a) {
            k(e.$$.fragment, a), t = !1
        },
        d(a) {
            M(e, a)
        }
    }
}

function Oe(i, e, t) {
    let a;
    J(i, ce, l => t(1, a = l));
    let {
        playerCount: n
    } = e;
    return i.$$set = l => {
        "playerCount" in l && t(0, n = l.playerCount)
    }, [n, a]
}
class We extends F {
    constructor(e) {
        super(), R(this, e, Oe, Le, T, {
            playerCount: 0
        })
    }
}
const Ue = i => ({}),
    oe = i => ({});

function Ke(i) {
    let e, t, a, n, l, r, s, f;
    const u = i[4].default,
        m = ae(u, i, i[3], null),
        _ = i[4].ribbon,
        c = ae(_, i, i[3], oe);
    return {
        c() {
            e = z("div"), t = z("a"), m && m.c(), n = N(), l = z("div"), c && c.c(), this.h()
        },
        l(o) {
            e = G(o, "DIV", {
                class: !0
            });
            var g = P(e);
            t = G(g, "A", {
                class: !0,
                "data-sveltekit-preload-data": !0,
                tabindex: !0,
                href: !0
            });
            var p = P(t);
            m && m.l(p), p.forEach(h), n = S(g), l = G(g, "DIV", {
                class: !0
            });
            var C = P(l);
            c && c.l(C), C.forEach(h), g.forEach(h), this.h()
        },
        h() {
            v(t, "class", "link svelte-1tn6kqn"), v(t, "data-sveltekit-preload-data", "hover"), v(t, "tabindex", a = i[0] ? -1 : void 0), v(t, "href", i[2]), q(t, "is-mobile", i[1]), v(l, "class", "ribbon svelte-1tn6kqn"), v(e, "class", "game-card-wrap svelte-1tn6kqn")
        },
        m(o, g) {
            w(o, e, g), D(e, t), m && m.m(t, null), D(e, n), D(e, l), c && c.m(l, null), r = !0, s || (f = ve(t, "click", i[5]), s = !0)
        },
        p(o, [g]) {
            m && m.p && (!r || g & 8) && ne(m, u, o, o[3], r ? ie(u, o[3], g, null) : le(o[3]), null), (!r || g & 1 && a !== (a = o[0] ? -1 : void 0)) && v(t, "tabindex", a), (!r || g & 4) && v(t, "href", o[2]), (!r || g & 2) && q(t, "is-mobile", o[1]), c && c.p && (!r || g & 8) && ne(c, _, o, o[3], r ? ie(_, o[3], g, Ue) : le(o[3]), oe)
        },
        i(o) {
            r || (b(m, o), b(c, o), r = !0)
        },
        o(o) {
            k(m, o), k(c, o), r = !1
        },
        d(o) {
            o && h(e), m && m.d(o), c && c.d(o), s = !1, f()
        }
    }
}

function Je(i, e, t) {
    let {
        $$slots: a = {},
        $$scope: n
    } = e, {
        isBlocked: l = !1
    } = e, {
        isMobile: r = !1
    } = e, {
        gamePath: s
    } = e;
    const f = () => {
        window.scrollTo({
            top: 0
        })
    };
    return i.$$set = u => {
        "isBlocked" in u && t(0, l = u.isBlocked), "isMobile" in u && t(1, r = u.isMobile), "gamePath" in u && t(2, s = u.gamePath), "$$scope" in u && t(3, n = u.$$scope)
    }, [l, r, s, n, a, f]
}
class Qe extends F {
    constructor(e) {
        super(), R(this, e, Je, Ke, T, {
            isBlocked: 0,
            isMobile: 1,
            gamePath: 2
        })
    }
}

function Xe(i) {
    let e, t, a, n, l;
    return t = new Q({
        props: {
            weight: "bold",
            align: "center",
            size: "2xl",
            variant: "highlighted",
            contentStyle: "padding: 10px",
            $$slots: {
                default: [$e]
            },
            $$scope: {
                ctx: i
            }
        }
    }), n = new Q({
        props: {
            weight: "bold",
            align: "center",
            size: "base",
            variant: "highlighted",
            contentStyle: "margin: 10px",
            $$slots: {
                default: [xe]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            e = z("div"), E(t.$$.fragment), a = N(), E(n.$$.fragment), this.h()
        },
        l(r) {
            e = G(r, "DIV", {
                class: !0
            });
            var s = P(e);
            I(t.$$.fragment, s), a = S(s), I(n.$$.fragment, s), s.forEach(h), this.h()
        },
        h() {
            v(e, "class", "overlay-text svelte-1hjbnm9")
        },
        m(r, s) {
            w(r, e, s), V(t, e, null), D(e, a), V(n, e, null), l = !0
        },
        p(r, s) {
            const f = {};
            s & 2097152 && (f.$$scope = {
                dirty: s,
                ctx: r
            }), t.$set(f);
            const u = {};
            s & 2129920 && (u.$$scope = {
                dirty: s,
                ctx: r
            }), n.$set(u)
        },
        i(r) {
            l || (b(t.$$.fragment, r), b(n.$$.fragment, r), l = !0)
        },
        o(r) {
            k(t.$$.fragment, r), k(n.$$.fragment, r), l = !1
        },
        d(r) {
            r && h(e), M(t), M(n)
        }
    }
}

function Ye(i) {
    let e, t, a;
    return t = new X({
        props: {
            height: "100%"
        }
    }), {
        c() {
            e = z("div"), E(t.$$.fragment), this.h()
        },
        l(n) {
            e = G(n, "DIV", {
                class: !0
            });
            var l = P(e);
            I(t.$$.fragment, l), l.forEach(h), this.h()
        },
        h() {
            v(e, "class", "placeholder svelte-1hjbnm9")
        },
        m(n, l) {
            w(n, e, l), V(t, e, null), a = !0
        },
        p: A,
        i(n) {
            a || (b(t.$$.fragment, n), a = !0)
        },
        o(n) {
            k(t.$$.fragment, n), a = !1
        },
        d(n) {
            n && h(e), M(t)
        }
    }
}

function $e(i) {
    let e, t;
    return e = new qe({}), {
        c() {
            E(e.$$.fragment)
        },
        l(a) {
            I(e.$$.fragment, a)
        },
        m(a, n) {
            V(e, a, n), t = !0
        },
        i(a) {
            t || (b(e.$$.fragment, a), t = !0)
        },
        o(a) {
            k(e.$$.fragment, a), t = !1
        },
        d(a) {
            M(e, a)
        }
    }
}

function xe(i) {
    let e = i[15]._(se.notAvailableInRegion) + "",
        t;
    return {
        c() {
            t = y(e)
        },
        l(a) {
            t = H(a, e)
        },
        m(a, n) {
            w(a, t, n)
        },
        p(a, n) {
            n & 32768 && e !== (e = a[15]._(se.notAvailableInRegion) + "") && j(t, e)
        },
        d(a) {
            a && h(t)
        }
    }
}

function et(i) {
    let e, t, a, n, l, r, s, f, u;
    t = new pe({
        props: {
            src: i[13],
            alt: i[14],
            draggable: !1,
            loading: "lazy",
            imgixParams: {
                q: 50,
                w: i[3]
            },
            width: Math.floor(i[3]),
            height: Math.floor(i[3] * 1.341)
        }
    });
    const m = [Ye, Xe],
        _ = [];

    function c(o, g) {
        return o[2] ? 0 : o[5] ? 1 : -1
    }
    return ~(n = c(i)) && (l = _[n] = m[n](i)), f = new Fe({
        props: {
            horizontal: !1,
            name: i[14],
            edge: i[0],
            provider: i[7],
            groupGames: i[8],
            gamePath: i[11],
            loading: i[2],
            isMobile: i[1],
            variant: i[4]
        }
    }), {
        c() {
            e = z("div"), E(t.$$.fragment), a = N(), l && l.c(), r = N(), s = z("div"), E(f.$$.fragment), this.h()
        },
        l(o) {
            e = G(o, "DIV", {
                class: !0
            });
            var g = P(e);
            I(t.$$.fragment, g), a = S(g), l && l.l(g), g.forEach(h), r = S(o), s = G(o, "DIV", {
                class: !0
            });
            var p = P(s);
            I(f.$$.fragment, p), p.forEach(h), this.h()
        },
        h() {
            v(e, "class", "img-wrap wrap svelte-1hjbnm9"), v(s, "class", "info-wrap svelte-1hjbnm9"), q(s, "quick-game", i[4] === "quickGame")
        },
        m(o, g) {
            w(o, e, g), V(t, e, null), D(e, a), ~n && _[n].m(e, null), w(o, r, g), w(o, s, g), V(f, s, null), u = !0
        },
        p(o, g) {
            const p = {};
            g & 8192 && (p.src = o[13]), g & 16384 && (p.alt = o[14]), g & 8 && (p.imgixParams = {
                q: 50,
                w: o[3]
            }), g & 8 && (p.width = Math.floor(o[3])), g & 8 && (p.height = Math.floor(o[3] * 1.341)), t.$set(p);
            let C = n;
            n = c(o), n === C ? ~n && _[n].p(o, g) : (l && (L(), k(_[C], 1, 1, () => {
                _[C] = null
            }), O()), ~n ? (l = _[n], l ? l.p(o, g) : (l = _[n] = m[n](o), l.c()), b(l, 1), l.m(e, null)) : l = null);
            const B = {};
            g & 16384 && (B.name = o[14]), g & 1 && (B.edge = o[0]), g & 128 && (B.provider = o[7]), g & 256 && (B.groupGames = o[8]), g & 2048 && (B.gamePath = o[11]), g & 4 && (B.loading = o[2]), g & 2 && (B.isMobile = o[1]), g & 16 && (B.variant = o[4]), f.$set(B), (!u || g & 16) && q(s, "quick-game", o[4] === "quickGame")
        },
        i(o) {
            u || (b(t.$$.fragment, o), b(l), b(f.$$.fragment, o), u = !0)
        },
        o(o) {
            k(t.$$.fragment, o), k(l), k(f.$$.fragment, o), u = !1
        },
        d(o) {
            o && (h(e), h(r), h(s)), M(t), ~n && _[n].d(), M(f)
        }
    }
}

function me(i) {
    let e, t = i[10] + 1 + "",
        a;
    return {
        c() {
            e = z("div"), a = y(t), this.h()
        },
        l(n) {
            e = G(n, "DIV", {
                class: !0
            });
            var l = P(e);
            a = H(l, t), l.forEach(h), this.h()
        },
        h() {
            v(e, "class", "index-ribbon shadow-sm shadow-grey-600 rounded-tr rounded-br svelte-1hjbnm9")
        },
        m(n, l) {
            w(n, e, l), D(e, a)
        },
        p(n, l) {
            l & 1024 && t !== (t = n[10] + 1 + "") && j(a, t)
        },
        d(n) {
            n && h(e)
        }
    }
}

function tt(i) {
    let e, t = i[9] && me(i);
    return {
        c() {
            t && t.c(), e = W()
        },
        l(a) {
            t && t.l(a), e = W()
        },
        m(a, n) {
            t && t.m(a, n), w(a, e, n)
        },
        p(a, n) {
            a[9] ? t ? t.p(a, n) : (t = me(a), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null)
        },
        d(a) {
            a && h(e), t && t.d(a)
        }
    }
}

function at(i) {
    let e, t;
    return e = new Qe({
        props: {
            isBlocked: i[5],
            isMobile: i[1],
            gamePath: i[11],
            $$slots: {
                ribbon: [tt],
                default: [et]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            E(e.$$.fragment)
        },
        l(a) {
            I(e.$$.fragment, a)
        },
        m(a, n) {
            V(e, a, n), t = !0
        },
        p(a, n) {
            const l = {};
            n & 32 && (l.isBlocked = a[5]), n & 2 && (l.isMobile = a[1]), n & 2048 && (l.gamePath = a[11]), n & 2158527 && (l.$$scope = {
                dirty: n,
                ctx: a
            }), e.$set(l)
        },
        i(a) {
            t || (b(e.$$.fragment, a), t = !0)
        },
        o(a) {
            k(e.$$.fragment, a), t = !1
        },
        d(a) {
            M(e, a)
        }
    }
}

function ue(i) {
    let e, t;
    return e = new We({
        props: {
            playerCount: i[12]
        }
    }), {
        c() {
            E(e.$$.fragment)
        },
        l(a) {
            I(e.$$.fragment, a)
        },
        m(a, n) {
            V(e, a, n), t = !0
        },
        p(a, n) {
            const l = {};
            n & 4096 && (l.playerCount = a[12]), e.$set(l)
        },
        i(a) {
            t || (b(e.$$.fragment, a), t = !0)
        },
        o(a) {
            k(e.$$.fragment, a), t = !1
        },
        d(a) {
            M(e, a)
        }
    }
}

function nt(i) {
    let e, t, a, n;
    t = new Pe({
        props: {
            $$slots: {
                default: [at]
            },
            $$scope: {
                ctx: i
            }
        }
    });
    let l = i[12] && ue(i);
    return {
        c() {
            e = z("div"), E(t.$$.fragment), a = N(), l && l.c(), this.h()
        },
        l(r) {
            e = G(r, "DIV", {
                class: !0,
                "data-analytics": !0
            });
            var s = P(e);
            I(t.$$.fragment, s), a = S(s), l && l.l(s), s.forEach(h), this.h()
        },
        h() {
            v(e, "class", "wrap svelte-1hjbnm9"), v(e, "data-analytics", i[6]), q(e, "not-clickable", i[5])
        },
        m(r, s) {
            w(r, e, s), V(t, e, null), D(e, a), l && l.m(e, null), n = !0
        },
        p(r, [s]) {
            const f = {};
            s & 2158527 && (f.$$scope = {
                dirty: s,
                ctx: r
            }), t.$set(f), r[12] ? l ? (l.p(r, s), s & 4096 && b(l, 1)) : (l = ue(r), l.c(), b(l, 1), l.m(e, null)) : l && (L(), k(l, 1, 1, () => {
                l = null
            }), O()), (!n || s & 64) && v(e, "data-analytics", r[6]), (!n || s & 32) && q(e, "not-clickable", r[5])
        },
        i(r) {
            n || (b(t.$$.fragment, r), b(l), n = !0)
        },
        o(r) {
            k(t.$$.fragment, r), k(l), n = !1
        },
        d(r) {
            r && h(e), M(t), l && l.d()
        }
    }
}
const lt = 220;

function it(i, e, t) {
    let a, n, l, r, s, f, u, m;
    J(i, we, d => t(19, u = d)), J(i, ce, d => t(15, m = d));
    let {
        card: _
    } = e, {
        edge: c = 0
    } = e, {
        isMobile: o = !1
    } = e, {
        loading: g = void 0
    } = e, {
        width: p = lt
    } = e, {
        variant: C = "normal"
    } = e, {
        isBlocked: B = !1
    } = e, {
        dataAnalytics: Y = void 0
    } = e, {
        provider: $ = void 0
    } = e, {
        groupGames: x = []
    } = e, {
        ribbon: ee = !1
    } = e, {
        index: te = 0
    } = e;
    const ge = d => d ? u(s === "racing" ? U(K.racing) : s === "sport" || s === "esport" ? U(K.sport, {
        sport: d
    }) : U(K.game, {
        game: d
    })) : "";
    return i.$$set = d => {
        "card" in d && t(16, _ = d.card), "edge" in d && t(0, c = d.edge), "isMobile" in d && t(1, o = d.isMobile), "loading" in d && t(2, g = d.loading), "width" in d && t(3, p = d.width), "variant" in d && t(4, C = d.variant), "isBlocked" in d && t(5, B = d.isBlocked), "dataAnalytics" in d && t(6, Y = d.dataAnalytics), "provider" in d && t(7, $ = d.provider), "groupGames" in d && t(8, x = d.groupGames), "ribbon" in d && t(9, ee = d.ribbon), "index" in d && t(10, te = d.index)
    }, i.$$.update = () => {
        i.$$.dirty & 65536 && t(17, {
            slug: a,
            name: n,
            thumbnailUrl: l,
            playerCount: r,
            type: s
        } = _, a, (t(14, n), t(16, _)), (t(13, l), t(16, _)), (t(12, r), t(16, _))), i.$$.dirty & 131072 && t(11, f = ge(a))
    }, [c, o, g, p, C, B, Y, $, x, ee, te, f, r, l, n, m, _, a]
}
class wt extends F {
    constructor(e) {
        super(), R(this, e, it, nt, T, {
            card: 16,
            edge: 0,
            isMobile: 1,
            loading: 2,
            width: 3,
            variant: 4,
            isBlocked: 5,
            dataAnalytics: 6,
            provider: 7,
            groupGames: 8,
            ribbon: 9,
            index: 10
        })
    }
}
export {
    wt as G
};