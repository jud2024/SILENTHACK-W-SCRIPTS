import {
    s as g,
    m as _,
    j as c,
    n as u,
    i as m,
    c as S,
    t as F,
    h as y,
    l as T,
    O as w,
    P as A,
    e as D,
    d as I,
    S as P
} from "./scheduler.DXu26z7T.js";
import {
    S as C,
    i as N,
    g as j,
    b as p,
    e as q,
    t as d,
    c as v,
    a as k,
    m as h,
    d as $
} from "./index.Dz_MmNB3.js";
import {
    i as O
} from "./index.B4-7gKq3.js";
import {
    F as z
} from "./index.DCTjP2Ha.js";

function B(l) {
    let e;
    return {
        c() {
            e = F("Invalid FormattedTime")
        },
        l(r) {
            e = y(r, "Invalid FormattedTime")
        },
        m(r, n) {
            c(r, e, n)
        },
        p: u,
        d(r) {
            r && m(e)
        }
    }
}

function E(l) {
    let e = l[1].date(l[0], {
            hour: "numeric",
            minute: "numeric"
        }) + "",
        r;
    return {
        c() {
            r = F(e)
        },
        l(n) {
            r = y(n, e)
        },
        m(n, a) {
            c(n, r, a)
        },
        p(n, a) {
            a & 3 && e !== (e = n[1].date(n[0], {
                hour: "numeric",
                minute: "numeric"
            }) + "") && T(r, e)
        },
        d(n) {
            n && m(r)
        }
    }
}

function G(l) {
    let e;

    function r(t, o) {
        return t[0] ? E : B
    }
    let n = r(l),
        a = n(l);
    return {
        c() {
            a.c(), e = _()
        },
        l(t) {
            a.l(t), e = _()
        },
        m(t, o) {
            a.m(t, o), c(t, e, o)
        },
        p(t, [o]) {
            n === (n = r(t)) && a ? a.p(t, o) : (a.d(1), a = n(t), a && (a.c(), a.m(e.parentNode, e)))
        },
        i: u,
        o: u,
        d(t) {
            t && m(e), a.d(t)
        }
    }
}

function H(l, e, r) {
    let n;
    S(l, O, t => r(1, n = t));
    let {
        value: a
    } = e;
    return l.$$set = t => {
        "value" in t && r(0, a = t.value)
    }, [a, n]
}
class J extends C {
    constructor(e) {
        super(), N(this, e, H, G, g, {
            value: 0
        })
    }
}

function K(l) {
    let e, r, n, a;
    return e = new J({
        props: {
            value: l[1]
        }
    }), n = new z({
        props: {
            short: l[0],
            value: l[1]
        }
    }), {
        c() {
            v(e.$$.fragment), r = w(), v(n.$$.fragment)
        },
        l(t) {
            k(e.$$.fragment, t), r = A(t), k(n.$$.fragment, t)
        },
        m(t, o) {
            h(e, t, o), c(t, r, o), h(n, t, o), a = !0
        },
        p(t, o) {
            const f = {};
            o & 2 && (f.value = t[1]), e.$set(f);
            const s = {};
            o & 1 && (s.short = t[0]), o & 2 && (s.value = t[1]), n.$set(s)
        },
        i(t) {
            a || (d(e.$$.fragment, t), d(n.$$.fragment, t), a = !0)
        },
        o(t) {
            p(e.$$.fragment, t), p(n.$$.fragment, t), a = !1
        },
        d(t) {
            t && m(r), $(e, t), $(n, t)
        }
    }
}

function L(l) {
    let e, r = "N/A";
    return {
        c() {
            e = D("span"), e.textContent = r
        },
        l(n) {
            e = I(n, "SPAN", {
                "data-svelte-h": !0
            }), P(e) !== "svelte-mgbc10" && (e.textContent = r)
        },
        m(n, a) {
            c(n, e, a)
        },
        p: u,
        i: u,
        o: u,
        d(n) {
            n && m(e)
        }
    }
}

function M(l) {
    let e, r, n, a;
    const t = [L, K],
        o = [];

    function f(s, i) {
        return s[1] === null ? 0 : 1
    }
    return e = f(l), r = o[e] = t[e](l), {
        c() {
            r.c(), n = _()
        },
        l(s) {
            r.l(s), n = _()
        },
        m(s, i) {
            o[e].m(s, i), c(s, n, i), a = !0
        },
        p(s, [i]) {
            let b = e;
            e = f(s), e === b ? o[e].p(s, i) : (j(), p(o[b], 1, 1, () => {
                o[b] = null
            }), q(), r = o[e], r ? r.p(s, i) : (r = o[e] = t[e](s), r.c()), d(r, 1), r.m(n.parentNode, n))
        },
        i(s) {
            a || (d(r), a = !0)
        },
        o(s) {
            p(r), a = !1
        },
        d(s) {
            s && m(n), o[e].d(s)
        }
    }
}

function Q(l, e, r) {
    let {
        short: n = !0
    } = e, {
        value: a
    } = e;
    return l.$$set = t => {
        "short" in t && r(0, n = t.short), "value" in t && r(1, a = t.value)
    }, [n, a]
}
class X extends C {
    constructor(e) {
        super(), N(this, e, Q, M, g, {
            short: 0,
            value: 1
        })
    }
}
export {
    X as F, J as a
};