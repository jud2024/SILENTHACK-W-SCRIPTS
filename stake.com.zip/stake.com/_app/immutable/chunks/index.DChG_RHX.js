import {
    s as k,
    a as V,
    K as h,
    e as j,
    d as q,
    f as v,
    i as R,
    Q as T,
    V as u,
    j as C,
    u as D,
    g as E,
    b as I,
    L as S,
    M as K
} from "./scheduler.DXu26z7T.js";
import {
    S as M,
    i as P,
    t as Q,
    b as A
} from "./index.Dz_MmNB3.js";
import {
    g as F
} from "./spread.CgU5AtxT.js";

function G(e) {
    let i, d, s;
    const o = e[14].default,
        l = V(o, e, e[13], null);
    let f = [e[11], {
            class: d = "stack x-" + e[7] + " y-" + e[8] + " gap-" + e[0] + " padding-" + e[1] + " direction-" + e[10] + " padding-left-" + e[2] + " padding-top-" + e[4] + " padding-bottom-" + e[5] + " padding-right-" + e[3]
        }, {
            style: e[9]
        }],
        g = {};
    for (let t = 0; t < f.length; t += 1) g = h(g, f[t]);
    return {
        c() {
            i = j("div"), l && l.c(), this.h()
        },
        l(t) {
            i = q(t, "DIV", {
                class: !0,
                style: !0
            });
            var n = v(i);
            l && l.l(n), n.forEach(R), this.h()
        },
        h() {
            T(i, g), u(i, "stretch", e[6]), u(i, "svelte-1cd1boi", !0)
        },
        m(t, n) {
            C(t, i, n), l && l.m(i, null), s = !0
        },
        p(t, [n]) {
            l && l.p && (!s || n & 8192) && D(l, o, t, t[13], s ? I(o, t[13], n, null) : E(t[13]), null), T(i, g = F(f, [n & 2048 && t[11], (!s || n & 1471 && d !== (d = "stack x-" + t[7] + " y-" + t[8] + " gap-" + t[0] + " padding-" + t[1] + " direction-" + t[10] + " padding-left-" + t[2] + " padding-top-" + t[4] + " padding-bottom-" + t[5] + " padding-right-" + t[3])) && {
                class: d
            }, (!s || n & 512) && {
                style: t[9]
            }])), u(i, "stretch", t[6]), u(i, "svelte-1cd1boi", !0)
        },
        i(t) {
            s || (Q(l, t), s = !0)
        },
        o(t) {
            A(l, t), s = !1
        },
        d(t) {
            t && R(i), l && l.d(t)
        }
    }
}

function H(e, i, d) {
    const s = ["horizontal", "gap", "padding", "paddingLeft", "paddingRight", "paddingTop", "paddingBottom", "stretch", "x", "y", "style"];
    let o = S(i, s),
        {
            $$slots: l = {},
            $$scope: f
        } = i,
        {
            horizontal: g = !1
        } = i,
        {
            gap: t = "small"
        } = i,
        {
            padding: n = "none"
        } = i,
        {
            paddingLeft: m = "auto"
        } = i,
        {
            paddingRight: r = "auto"
        } = i,
        {
            paddingTop: c = "auto"
        } = i,
        {
            paddingBottom: y = "auto"
        } = i,
        {
            stretch: _ = !1
        } = i,
        {
            x: b = "stretch"
        } = i,
        {
            y: z = "center"
        } = i,
        {
            style: L = void 0
        } = i,
        B;
    return e.$$set = a => {
        i = h(h({}, i), K(a)), d(11, o = S(i, s)), "horizontal" in a && d(12, g = a.horizontal), "gap" in a && d(0, t = a.gap), "padding" in a && d(1, n = a.padding), "paddingLeft" in a && d(2, m = a.paddingLeft), "paddingRight" in a && d(3, r = a.paddingRight), "paddingTop" in a && d(4, c = a.paddingTop), "paddingBottom" in a && d(5, y = a.paddingBottom), "stretch" in a && d(6, _ = a.stretch), "x" in a && d(7, b = a.x), "y" in a && d(8, z = a.y), "style" in a && d(9, L = a.style), "$$scope" in a && d(13, f = a.$$scope)
    }, e.$$.update = () => {
        e.$$.dirty & 4096 && d(10, B = g ? "horizontal" : "vertical")
    }, [t, n, m, r, c, y, _, b, z, L, B, o, g, f, l]
}
class U extends M {
    constructor(i) {
        super(), P(this, i, H, G, k, {
            horizontal: 12,
            gap: 0,
            padding: 1,
            paddingLeft: 2,
            paddingRight: 3,
            paddingTop: 4,
            paddingBottom: 5,
            stretch: 6,
            x: 7,
            y: 8,
            style: 9
        })
    }
}
export {
    U as S
};