import {
    h as e
} from "./index.B4-7gKq3.js";
import "./index.ByMdEFI5.js";
import {
    U as n
} from "./Unfriend.Ce_l8c8_.js";
const t = () => ({
        title: e._("User Ignored"),
        icon: n,
        type: "negative"
    }),
    o = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "mutation",
            name: {
                kind: "Name",
                value: "addIgnoredUser"
            },
            variableDefinitions: [{
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "userId"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "String"
                        }
                    }
                }
            }],
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "addIgnoredUser"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "userId"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "userId"
                            }
                        }
                    }],
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "ignoredUser"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "isIgnored"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }]
    };
export {
    o as A, t as c
};