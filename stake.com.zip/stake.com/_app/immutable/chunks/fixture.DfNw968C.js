import {
    u as a
} from "./index.B4-7gKq3.js";
const s = t => {
    var n, r;
    if (t) {
        if (t.__typename === "SportFixtureDataMatch") return {
            startTime: t.startTime,
            name: ((n = t.competitors) == null ? void 0 : n.map(o => o == null ? void 0 : o.name).join(" - ")) || null,
            abbreviation: ((r = t.competitors) == null ? void 0 : r.map(o => o == null ? void 0 : o.abbreviation).join(" - ")) || null
        };
        if (t.__typename === "SportFixtureDataOutright") return {
            startTime: t.startTime,
            name: t.name || null,
            abbreviation: null
        };
        if (t.__typename === "SportCricketScore") return {
            startTime: null,
            name: t.name || null,
            abbreviation: null
        }
    }
    return {
        startTime: null,
        name: null,
        abbreviation: null
    }
};
a.active, a.suspended;
const l = t => {
        var n;
        return ["/sports", ((n = t == null ? void 0 : t.data) == null ? void 0 : n.__typename) === "SportFixtureDataOutright" ? "outright" : void 0, t == null ? void 0 : t.tournament.category.sport.slug, t == null ? void 0 : t.tournament.category.slug, t == null ? void 0 : t.tournament.slug, t == null ? void 0 : t.slug].filter(Boolean).join("/")
    },
    m = t => [t.category.sport, t.category, t],
    p = (t, n) => n === "sport" ? ["/sports", ...t].join("/") : ["/sports/racing", ...t].join("/"),
    g = t => t.toLocaleLowerCase().split(" ").join("-");
export {
    g as a, p as b, m as c, l as d, s as g
};