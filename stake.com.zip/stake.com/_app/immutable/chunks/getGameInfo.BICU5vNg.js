const c = n => {
    var i;
    const {
        slug: s,
        name: t,
        thumbnailUrl: l,
        edge: m,
        playerCount: o
    } = n.game, e = n.game.data;
    return {
        id: n.id,
        groupGames: ((i = n == null ? void 0 : n.game) == null ? void 0 : i.groupGames) || [],
        betEnum: e == null ? void 0 : e.extId,
        provider: (e == null ? void 0 : e.__typename) === "SoftswissGame" ? e.provider : (e == null ? void 0 : e.__typename) === "EvolutionGame" ? {
            name: "Evolution Gaming"
        } : {
            name: "Stake Originals"
        },
        slug: s,
        name: t,
        thumbnailUrl: l,
        edge: m,
        isBlocked: n.game.isBlocked,
        playerCount: o
    }
};
export {
    c as g
};