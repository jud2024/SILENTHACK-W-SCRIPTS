import {
    H as b,
    h as d,
    q as L,
    f as S,
    _ as k,
    v as j,
    bH as P,
    d5 as q,
    a0 as A,
    A as I,
    p as x,
    bd as O,
    N as H
} from "./index.B4-7gKq3.js";
import "./index.ByMdEFI5.js";
import {
    A as W
} from "./Account.Dy1oZprP.js";
import {
    A as $,
    c as G
} from "./AddIgnoredUser.generated.C970r58h.js";
import {
    w as l,
    d as M
} from "./index.C2-CG2CN.js";
import {
    D as z
} from "./DeleteIgnoredUser.generated.C_zmziUg.js";
import {
    n as N
} from "./index.DGKYLdH2.js";
import {
    G as o
} from "./scheduler.DXu26z7T.js";
import {
    V as J
} from "./index.B81orGJm.js";
import {
    u as _
} from "./index.1CTKaDY2.js";
import {
    m as v
} from "./utils.92_vUFxq.js";
import {
    f as K
} from "./stores.C1s9-Gyh.js";
import {
    a as Y,
    S as D
} from "./helpers.mdRln9WE.js";
const Q = l(!1),
    X = l("question"),
    fn = l(o(b)),
    bn = l(""),
    hn = l(""),
    Z = l(""),
    ee = l(null),
    ne = l(null),
    ae = (e, a) => e && e.trim().toLowerCase() === a.trim().toLowerCase(),
    yn = (e, a) => {
        var t, s;
        const n = new Date(e.createdAt),
            i = ((t = e == null ? void 0 : e.data) == null ? void 0 : t.__typename) === "ChatMessageDataText" ? e.data.message : "";
        n.getTime() > o(ee).getTime() && ae(i, o(Z)) && ((s = e == null ? void 0 : e.user) == null ? void 0 : s.id) !== a.id && (ne.set(e), X.set("credited"))
    },
    ie = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "mutation",
            name: {
                kind: "Name",
                value: "SendMessage"
            },
            variableDefinitions: [{
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "chatId"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "String"
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "message"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "String"
                        }
                    }
                }
            }],
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "sendMessage"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "chatId"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "chatId"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "message"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "message"
                            }
                        }
                    }],
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }]
                    }
                }]
            }
        }]
    },
    te = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "query",
            name: {
                kind: "Name",
                value: "MessageList"
            },
            variableDefinitions: [{
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "chatId"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "String"
                        }
                    }
                }
            }],
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "chat"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "chatId"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "chatId"
                            }
                        }
                    }],
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "messageList"
                            },
                            arguments: [{
                                kind: "Argument",
                                name: {
                                    kind: "Name",
                                    value: "limit"
                                },
                                value: {
                                    kind: "IntValue",
                                    value: "30"
                                }
                            }, {
                                kind: "Argument",
                                name: {
                                    kind: "Name",
                                    value: "offset"
                                },
                                value: {
                                    kind: "IntValue",
                                    value: "0"
                                }
                            }],
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "ChatMessage"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "RacePosition"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "RacePosition"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "position"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "preferenceHideBets"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "wageredAmount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payoutAmount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "percentage"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "UserTags"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "User"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "isMuted"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "isRainproof"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "isIgnored"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "isHighroller"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "isSportHighroller"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "leaderboardDailyProfitRank"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "leaderboardDailyWageredRank"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "leaderboardWeeklyProfitRank"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "leaderboardWeeklyWageredRank"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "flags"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "flag"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "rank"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "createdAt"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "roles"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "expireAt"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "message"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "preferenceHideBets"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "ChatMessage"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "ChatMessage"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "data"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "__typename"
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "ChatMessageDataRace"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "race"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "id"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "name"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "status"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "startTime"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "leaderboard"
                                            },
                                            arguments: [{
                                                kind: "Argument",
                                                name: {
                                                    kind: "Name",
                                                    value: "limit"
                                                },
                                                value: {
                                                    kind: "IntValue",
                                                    value: "10"
                                                }
                                            }],
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "FragmentSpread",
                                                    name: {
                                                        kind: "Name",
                                                        value: "RacePosition"
                                                    }
                                                }]
                                            }
                                        }]
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "ChatMessageDataTrivia"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "status"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "question"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "answer"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "currency"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "amount"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "winner"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "FragmentSpread",
                                            name: {
                                                kind: "Name",
                                                value: "UserTags"
                                            }
                                        }]
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "ChatMessageDataText"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "message"
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "ChatMessageDataBot"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "message"
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "ChatMessageDataTip"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "tip"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "id"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "amount"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "currency"
                                            }
                                        }, {
                                            kind: "Field",
                                            alias: {
                                                kind: "Name",
                                                value: "sender"
                                            },
                                            name: {
                                                kind: "Name",
                                                value: "sendBy"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "FragmentSpread",
                                                    name: {
                                                        kind: "Name",
                                                        value: "UserTags"
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            alias: {
                                                kind: "Name",
                                                value: "receiver"
                                            },
                                            name: {
                                                kind: "Name",
                                                value: "user"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "FragmentSpread",
                                                    name: {
                                                        kind: "Name",
                                                        value: "UserTags"
                                                    }
                                                }]
                                            }
                                        }]
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "ChatMessageDataRain"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "rain"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "amount"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "currency"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "rainUsers"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "user"
                                                    },
                                                    selectionSet: {
                                                        kind: "SelectionSet",
                                                        selections: [{
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "id"
                                                            }
                                                        }, {
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "name"
                                                            }
                                                        }]
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            alias: {
                                                kind: "Name",
                                                value: "giver"
                                            },
                                            name: {
                                                kind: "Name",
                                                value: "user"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "FragmentSpread",
                                                    name: {
                                                        kind: "Name",
                                                        value: "UserTags"
                                                    }
                                                }]
                                            }
                                        }]
                                    }
                                }]
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "UserTags"
                            }
                        }]
                    }
                }]
            }
        }]
    },
    se = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "query",
            name: {
                kind: "Name",
                value: "PublicChats"
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "publicChats"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "isPublic"
                            }
                        }]
                    }
                }]
            }
        }]
    },
    de = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "subscription",
            name: {
                kind: "Name",
                value: "ChatMessages"
            },
            variableDefinitions: [{
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "chatId"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "String"
                        }
                    }
                }
            }],
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "chatMessages"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "chatId"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "chatId"
                            }
                        }
                    }],
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "ChatMessage"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "RacePosition"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "RacePosition"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "position"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "preferenceHideBets"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "wageredAmount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payoutAmount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "percentage"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "UserTags"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "User"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "isMuted"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "isRainproof"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "isIgnored"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "isHighroller"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "isSportHighroller"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "leaderboardDailyProfitRank"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "leaderboardDailyWageredRank"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "leaderboardWeeklyProfitRank"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "leaderboardWeeklyWageredRank"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "flags"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "flag"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "rank"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "createdAt"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "roles"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "expireAt"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "message"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "preferenceHideBets"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "ChatMessage"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "ChatMessage"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "data"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "__typename"
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "ChatMessageDataRace"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "race"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "id"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "name"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "status"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "startTime"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "leaderboard"
                                            },
                                            arguments: [{
                                                kind: "Argument",
                                                name: {
                                                    kind: "Name",
                                                    value: "limit"
                                                },
                                                value: {
                                                    kind: "IntValue",
                                                    value: "10"
                                                }
                                            }],
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "FragmentSpread",
                                                    name: {
                                                        kind: "Name",
                                                        value: "RacePosition"
                                                    }
                                                }]
                                            }
                                        }]
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "ChatMessageDataTrivia"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "status"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "question"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "answer"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "currency"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "amount"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "winner"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "FragmentSpread",
                                            name: {
                                                kind: "Name",
                                                value: "UserTags"
                                            }
                                        }]
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "ChatMessageDataText"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "message"
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "ChatMessageDataBot"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "message"
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "ChatMessageDataTip"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "tip"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "id"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "amount"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "currency"
                                            }
                                        }, {
                                            kind: "Field",
                                            alias: {
                                                kind: "Name",
                                                value: "sender"
                                            },
                                            name: {
                                                kind: "Name",
                                                value: "sendBy"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "FragmentSpread",
                                                    name: {
                                                        kind: "Name",
                                                        value: "UserTags"
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            alias: {
                                                kind: "Name",
                                                value: "receiver"
                                            },
                                            name: {
                                                kind: "Name",
                                                value: "user"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "FragmentSpread",
                                                    name: {
                                                        kind: "Name",
                                                        value: "UserTags"
                                                    }
                                                }]
                                            }
                                        }]
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "ChatMessageDataRain"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "rain"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "amount"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "currency"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "rainUsers"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "user"
                                                    },
                                                    selectionSet: {
                                                        kind: "SelectionSet",
                                                        selections: [{
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "id"
                                                            }
                                                        }, {
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "name"
                                                            }
                                                        }]
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            alias: {
                                                kind: "Name",
                                                value: "giver"
                                            },
                                            name: {
                                                kind: "Name",
                                                value: "user"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "FragmentSpread",
                                                    name: {
                                                        kind: "Name",
                                                        value: "UserTags"
                                                    }
                                                }]
                                            }
                                        }]
                                    }
                                }]
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "UserTags"
                            }
                        }]
                    }
                }]
            }
        }]
    },
    F = () => ({
        title: d._("User not found"),
        body: d._("User not found."),
        icon: W,
        type: "negative"
    }),
    T = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "query",
            name: {
                kind: "Name",
                value: "slashCommandsUser"
            },
            variableDefinitions: [{
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                },
                type: {
                    kind: "NamedType",
                    name: {
                        kind: "Name",
                        value: "String"
                    }
                }
            }],
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "name"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }
                    }],
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }]
            }
        }]
    },
    h = {
        adminPanel: d._("Admin panel"),
        ignoreUser: d._("Ignore user"),
        makeRain: d._("Make it Rain"),
        tipUser: d._("Tip user"),
        trivia: d._("Trivia"),
        twitterAlt: d._("Share to Twitter"),
        unignoreUser: d._("Unignore user"),
        userNotFound: d._("User not found"),
        viewBet: d._("View bet"),
        viewCasinoBet: d._("Lookup casino bet"),
        viewGame: d._("View game"),
        viewSportBet: d._("Lookup sport bet"),
        viewUser: d._("View user")
    },
    le = { ...h,
        viewBet: d._("View game"),
        tipUser: d._("Gift user")
    },
    me = {
        stake: h,
        sweeps: le
    },
    u = me[J] || h,
    oe = "/_app/immutable/assets/adesanya.CINNhcpG.png",
    re = "/_app/immutable/assets/beer.DOzcSPdE.png",
    ke = "/_app/immutable/assets/biden.D-7WNx-u.png",
    ce = "/_app/immutable/assets/blob.BhNAP7xC.gif",
    ue = "/_app/immutable/assets/catbread.C7sg51oK.gif",
    pe = "/_app/immutable/assets/coffee.D9uPzjad.png",
    ge = "/_app/immutable/assets/coin.DH4RUKRf.gif",
    ve = "/_app/immutable/assets/cooldoge.D3gald4g.png",
    Ne = "/_app/immutable/assets/coupon.DkmE-UkA.png",
    Se = "/_app/immutable/assets/dendi.BSVeP1Hn.png",
    Fe = "/_app/immutable/assets/djokovic.Dhqf6Wby.png",
    fe = "/_app/immutable/assets/doge.DmW4OH59.png",
    be = "/_app/immutable/assets/donut.CAmR-JiE.png",
    he = "/_app/immutable/assets/easyms.BANdh91b.png",
    ye = "/_app/immutable/assets/eddie.BS3Ja2l0.png",
    Ce = "/_app/immutable/assets/ezpz.iBwtLgr4.png",
    _e = "/_app/immutable/assets/gary.hvGnLDhA.png",
    De = "/_app/immutable/assets/jordan.IloXmq7F.png",
    Te = "/_app/immutable/assets/kanye.Cx6a88UK.png",
    Ue = "/_app/immutable/assets/lambo.C9CTqcUO.png",
    we = "/_app/immutable/assets/lebron.B5wuXCRl.png",
    Ae = "/_app/immutable/assets/lefroge.DtXE-eRm.png",
    Ie = "/_app/immutable/assets/mahomes.CeMHYOQV.png",
    Me = "/_app/immutable/assets/mcgregor.wmJ7WBMM.png",
    Re = "/_app/immutable/assets/messi.DgU5q0Fs.png",
    Be = "/_app/immutable/assets/nadal.D6VNUC5Z.png",
    Ee = "/_app/immutable/assets/nightdoge.D6HIl35V.png",
    Ve = "/_app/immutable/assets/nyancat.CjRsNBF2.gif",
    Le = "/_app/immutable/assets/pepe.B32gQWHN.png",
    je = "/_app/immutable/assets/pikachu.BvDvUo-Y.png",
    Pe = "/_app/immutable/assets/rigged.Of8aUJ-R.png",
    qe = "/_app/immutable/assets/rish.CBwF6QZL.png",
    xe = "/_app/immutable/assets/ronaldo.1raaGRwB.png",
    Oe = "/_app/immutable/assets/santa.CZ9GJPf-.png",
    He = "/_app/immutable/assets/skem.CsUg9ujy.png",
    We = "/_app/immutable/assets/stonks.mzqv6Hrr.png",
    $e = "/_app/immutable/assets/trump.Bo34E6Sn.png",
    Ge = "/_app/immutable/assets/umbrella.CvDzwkSA.png",
    ze = "/_app/immutable/assets/sus.BeZB7tLY.png",
    Je = "/_app/immutable/assets/woods.BvwAK8Pm.png",
    Ke = "/_app/immutable/assets/elon.DBYG_7ni.png",
    Ye = "/_app/immutable/assets/feelsgoodman.D10s89PF.png",
    Qe = "/_app/immutable/assets/monkas.RWM4Ms62.png",
    Xe = "/_app/immutable/assets/pepehands.xqMoS0I3.png",
    Ze = "/_app/immutable/assets/pepelaugh.agB3vcK_.png",
    en = "/_app/immutable/assets/poggers.CHfLLpk5.png",
    U = {
        adesanya: oe,
        biden: ke,
        beer: re,
        blob: ce,
        catbread: ue,
        coffee: pe,
        cooldoge: ve,
        coupon: Ne,
        coin: ge,
        dendi: Se,
        djokovic: Fe,
        doge: fe,
        donut: be,
        easymoney: he,
        eddie: ye,
        ezpz: Ce,
        gary: _e,
        jordan: De,
        kanye: Te,
        lambo: Ue,
        lebron: we,
        lefroge: Ae,
        mahomes: Ie,
        mcgregor: Me,
        messi: Re,
        nadal: Be,
        nightdoge: Ee,
        nyancat: Ve,
        pepe: Le,
        pikachu: je,
        rigged: Pe,
        rish: qe,
        ronaldo: xe,
        santa: Oe,
        skem: He,
        stonks: We,
        sus: ze,
        trump: $e,
        umbrella: Ge,
        woods: Je,
        elon: Ke,
        feelsgoodman: Ye,
        monkas: Qe,
        pepehands: Xe,
        pepelaugh: Ze,
        poggers: en
    },
    nn = Object.keys(U).map(e => ({
        emoji: `:${e}:`,
        image: U[e]
    })).sort(),
    Cn = ["😁", "😂", "😃", "😄", "😅", "😆", "😉", "😊", "😋", "😌", "😍", "😏", "😒", "😓", "😔", "😖", "😘", "😚", "😜", "😝", "😞", "😠", "😡", "😢", "😣", "😤", "😥", "😨", "😩", "😪", "😫", "😭", "😰", "😱", "😲", "😳", "😵", "😷", "😸", "😹", "😺", "😻", "😼", "😽", "😾", "😿", "🙀", "🙅", "🙆", "🙇", "🙈", "🙉", "🙊", "🙋", "🙌", "🙍", "🙎", "🙏", "😀", "😇", "😈", "😎", "😐", "😑", "😕", "😗", "😙", "😛", "😟", "😦", "😧", "😬", "😮", "😯", "😴", "😶", "💚", "💛", "💝", "💞", "💟", "💔", "💕", "💖", "💗"].map(e => ({
        emoji: e
    })),
    an = M([K], ([e]) => {
        const a = [];
        return a.push({
            cmd: "/bet",
            icon: "emoji-stats",
            desc: "View bet",
            message: u.viewBet,
            syntax: "[bet id]",
            action: (...n) => {
                const i = n.join();
                i.length && v.bet.open({
                    iid: i
                })
            }
        }), a.push({
            cmd: "/casino",
            icon: "emoji-stats",
            desc: "View casino bet",
            message: u.viewCasinoBet,
            syntax: "[bet id]",
            hidden: !0,
            action: n => {
                const i = `house:${n.replace(/\D/g,"")}`;
                i.length && v.bet.open({
                    iid: i
                })
            }
        }), a.push({
            cmd: "/sport",
            icon: "emoji-stats",
            desc: "View sport bet",
            message: u.viewSportBet,
            syntax: "[bet id]",
            hidden: !0,
            action: n => {
                const i = `sport:${n.replace(/\D/g,"")}`;
                i.length && v.bet.open({
                    iid: i
                })
            }
        }), a.push({
            cmd: "/user",
            icon: "emoji-user",
            desc: "View user",
            message: u.viewUser,
            syntax: "@user",
            action: n => {
                v.user.open({
                    name: n
                })
            }
        }), e || a.push({
            cmd: "/tip",
            icon: "emoji-tip",
            desc: "Tip user",
            message: u.tipUser,
            syntax: "@user",
            action: n => v.wallet.open({
                tab: "tip",
                currency: o(b),
                name: typeof n == "string" ? n : ""
            })
        }), a.push({
            cmd: "/trivia",
            icon: "trivia",
            desc: "Trivia",
            message: u.trivia,
            admin: !0,
            action: () => {
                Q.set(!0)
            }
        }), a.push({
            cmd: "/rain",
            icon: "emoji-rain",
            desc: "Make it Rain",
            message: u.makeRain,
            action: () => {
                v.rain.open({
                    currency: L[o(b)]
                })
            }
        }), a.push({
            cmd: "/ignore",
            icon: "emoji-ignore",
            desc: "Ignore user",
            message: u.ignoreUser,
            syntax: "@user",
            action: async n => {
                if (!n) N.open(F());
                else {
                    const i = await S({
                            load: {
                                fetch
                            },
                            doc: T,
                            variables: {
                                name: n
                            }
                        }),
                        t = i == null ? void 0 : i.user;
                    if (!t) N.open(F());
                    else {
                        const s = await S({
                            load: {
                                fetch
                            },
                            doc: $,
                            variables: {
                                userId: t.id
                            }
                        });
                        s != null && s.addIgnoredUser && N.open(G())
                    }
                }
            }
        }), a.push({
            cmd: "/unignore",
            icon: "emoji-unignore",
            desc: "Unignore user",
            message: u.unignoreUser,
            syntax: "@user",
            action: async n => {
                if (!n) N.open(F());
                else {
                    const i = await S({
                            load: {
                                fetch
                            },
                            doc: T,
                            variables: {
                                name: n
                            }
                        }),
                        t = i == null ? void 0 : i.user;
                    t ? await S({
                        load: {
                            fetch
                        },
                        doc: z,
                        variables: {
                            userId: t.id
                        }
                    }) : N.open(F())
                }
            }
        }), a.push({
            cmd: "/admin",
            icon: "gear",
            desc: "Admin panel",
            message: u.adminPanel,
            syntax: "@user",
            admin: !0,
            action: n => {
                v.moderation.open({
                    name: n
                })
            }
        }), a.push({
            cmd: "/unsichtbar",
            hidden: !0,
            action: () => {
                _.set(!0)
            }
        }), a.push({
            cmd: "/sichtbar",
            hidden: !0,
            action: () => {
                _.set(!1)
            }
        }), a.filter(Boolean)
    }),
    tn = (e, a, n) => o(an).filter(i => (i.admin ? a : !0) && i.cmd.toLowerCase().includes(e.toLowerCase()) && (n ? !0 : !i.hidden)),
    _n = e => {
        var a;
        return e.substring(e.length - 1) === " " ? !1 : e.length === 1 && e.includes(":") ? !0 : (a = k.last(e.split(" "))) == null ? void 0 : a.includes(":")
    },
    Dn = e => {
        var a;
        return e.substring(e.length - 1) === " " ? !1 : e.length === 1 && e.includes("@") ? !0 : (a = k.last(e.split(" "))) == null ? void 0 : a.includes("@")
    },
    Tn = e => {
        var a, n;
        return e.ref ? ((n = (a = k.last(`${e.message}`.slice(0, e.ref.selectionStart).split("@"))) == null ? void 0 : a.replace("@", "")) == null ? void 0 : n.toLowerCase()) ? ? "" : ""
    },
    Un = e => {
        var a, n;
        return e.ref ? ((n = (a = k.last(`${e.message}`.slice(0, e.ref.selectionStart).split(":"))) == null ? void 0 : a.replace(":", "")) == null ? void 0 : n.toLowerCase()) ? ? "" : ""
    },
    wn = e => {
        const a = nn.filter(n => n.emoji.toLowerCase().includes(e.toLowerCase()));
        return k.uniq(a)
    },
    An = (e, a) => {
        const n = [...a].map(i => i.name).filter(i => i.toLowerCase().includes(e.toLowerCase()));
        return e.length > 0 && n.push(e), k.uniq(n).map(i => ({
            name: i
        }))
    },
    In = (e, {
        emoji: a
    }, n) => {
        if (n != null && n.shouldAddEmoji) return `${e.message}${a} `; {
            const i = k.last(e.message.split(":")) ? ? [];
            return `${e.message.substring(0,e.message.length-i.length-1)}${a} `
        }
    },
    Mn = (e, {
        name: a
    }) => {
        const n = k.last(e.message.split("@")) ? ? [];
        return `${e.message.substring(0,e.message.length-n.length)}${a} `
    },
    R = j(),
    Rn = e => R.subscribe(a => {
        const n = a.type in e ? e[a.type] : void 0;
        n && n(a)
    }),
    y = { ...l([]),
        fetchChatList: async n => {
            var i;
            if (!o(f)) try {
                const t = await A({
                    doc: se,
                    load: {
                        fetch
                    },
                    variables: {}
                });
                return t.data && (y.set(((i = t == null ? void 0 : t.data) == null ? void 0 : i.publicChats.filter(s => s && s.name)) || []), sn(o(B), n)), t
            } catch {}
        }
    },
    f = l(null),
    Bn = P(!1),
    En = M([y, f], ([e, a]) => e == null ? void 0 : e.find(n => n.id === a)),
    Vn = e => (() => {
        const a = l({
                loading: !0,
                messageList: []
            }),
            n = i => {
                a.update(t => ({ ...t,
                    messageList: k.uniqBy([...t.messageList.slice(-50), i], "id")
                })), w.update(t => k.uniqBy([...t, i.user], "id"))
            };
        return { ...a,
            addMessage: n,
            fetch: ({
                chatId: i,
                urqlId: t,
                onCompleted: s
            }) => {
                let m = !1;
                const p = I();
                return a.set({
                    loading: !0,
                    messageList: []
                }), A({
                    doc: te,
                    variables: {
                        chatId: i
                    },
                    load: e
                }).then(c => {
                    var r, C;
                    m = !0;
                    const g = [...((C = (r = c == null ? void 0 : c.data) == null ? void 0 : r.chat) == null ? void 0 : C.messageList) || []].reverse();
                    w.update(E => k.uniqBy([...g.map(V => V.user), ...E], "id")), a.set({
                        loading: !1,
                        messageList: g
                    }), s && s()
                }), O(p.subscription(de, {
                    chatId: i
                }), H(c => {
                    var g;
                    if (m) {
                        const r = (g = c.data) == null ? void 0 : g.chatMessages;
                        r && (n(r), R.next({
                            type: "message",
                            data: r
                        }))
                    }
                }))
            }
        }
    })(),
    w = l([]),
    Ln = (() => {
        const e = l({
            message: "",
            loading: !1,
            ref: null
        });
        return { ...e,
            sendMessage: async a => {
                const {
                    message: n,
                    ref: i
                } = o(e);
                if (dn.set(!1), n.trim().length >= 1 && n.length <= q)
                    if (i && i.focus(), n[0] === "/") {
                        const [t, ...s] = n.replace("@", "").split(" "), m = tn("", a.hasRole, !0).find(({
                            cmd: p
                        }) => p === t);
                        m && (e.update(p => ({ ...p,
                            message: ""
                        })), m.action(...s))
                    } else {
                        e.update(s => ({ ...s,
                            message: "",
                            loading: !0
                        }));
                        const t = I();
                        try {
                            (await t.mutation(ie, {
                                chatId: o(f),
                                message: n
                            }).toPromise()).error ? e.update(m => ({ ...m,
                                loading: !1,
                                message: n
                            })) : e.update(m => ({ ...m,
                                loading: !1
                            }))
                        } catch {
                            e.update(m => ({ ...m,
                                loading: !1,
                                message: n
                            }))
                        }
                    }
            }
        }
    })(),
    sn = (e, a) => {
        var g;
        const i = e === D ? D : "",
            t = ((g = o(x).data) == null ? void 0 : g.restrictedRegionData.country) === "IN",
            s = `${i}${a}`,
            m = `${i}${Y.en}`,
            p = o(y) || [],
            c = p.find(({
                name: r
            }) => t ? r === "hi" : r === s) || p.find(({
                name: r
            }) => r === m) || p[0];
        c != null && c.id ? f.set(c.id) : B.set(e)
    },
    dn = l(!1),
    B = l(null);
export {
    Rn as A, yn as B, nn as C, ne as D, Q as E, Cn as S, f as a, Ln as b, En as c, _n as d, dn as e, An as f, Tn as g, w as h, Un as i, sn as j, wn as k, Mn as l, tn as m, Vn as n, Bn as o, B as p, y as q, In as r, Dn as s, F as t, fn as u, Z as v, hn as w, bn as x, ee as y, X as z
};