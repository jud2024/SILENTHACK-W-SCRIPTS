import {
    u as w,
    k as F
} from "./stores.C1s9-Gyh.js";
import {
    a as G
} from "./index.BxooaYHE.js";
import {
    C as N
} from "./index.B4-7gKq3.js";
import {
    d as v
} from "./index.C2-CG2CN.js";
const O = v([w, F], ([e, m]) => {
        var r, C, d, p;
        const u = ((r = m == null ? void 0 : m.data) == null ? void 0 : r.user) ? ? ((C = e == null ? void 0 : e.data) == null ? void 0 : C.user);
        return (p = (d = u == null ? void 0 : u.transactionEligibilityState) == null ? void 0 : d.fiat) == null ? void 0 : p[0]
    }),
    L = v([O, G], ([e, m]) => [...e != null && e.currency ? [e == null ? void 0 : e.currency, ...m.filter(r => r !== (e == null ? void 0 : e.currency))] : m, ...N]);
export {
    O as f, L as w
};