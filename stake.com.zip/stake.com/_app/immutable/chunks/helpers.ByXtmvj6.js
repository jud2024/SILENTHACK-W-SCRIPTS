import {
    f as M,
    I as h
} from "./index.B4-7gKq3.js";
import {
    w as A
} from "./index.C2-CG2CN.js";
import {
    a as f
} from "./index.B81orGJm.js";
import {
    o as E
} from "./scheduler.DXu26z7T.js";

function y({
    queryDocument: m,
    subscriptionDocument: l,
    queryVariables: T,
    getQueryPath: b,
    getSubscriptionPath: I
}) {
    const n = A({
            data: [],
            loading: !1
        }),
        u = async (s, i = {}) => {
            n.set({
                data: [],
                loading: !0
            });
            const o = await M({
                    doc: m,
                    variables: {
                        limit: 10,
                        ...T,
                        ...i
                    },
                    load: s
                }),
                t = b(o);
            return n.set({
                data: t || [],
                loading: !1
            }), o
        },
        d = (s, i, o = () => !1) => {
            const t = i.limit || 10;
            return f ? {
                unsubscribe: () => {}
            } : (u(s, {
                limit: t
            }), {
                unsubscribe: h({
                    doc: l
                }, c => {
                    const a = I(c == null ? void 0 : c.data);
                    a && !o() && n.update(r => {
                        const p = r.data.some(e => (e == null ? void 0 : e.id) === (a == null ? void 0 : a.id));
                        return { ...r,
                            data: p ? r.data : [a, ...r.data].slice(0, t)
                        }
                    })
                })
            })
        };

    function L({
        load: s,
        fetchVariables: i,
        isPaused: o
    }) {
        E(() => {
            if (!f) {
                const t = d(s, i, o);
                return () => {
                    t == null || t.unsubscribe()
                }
            }
        })
    }
    return {
        store: n,
        load: u,
        subscribeToBets: d,
        subscribeToBetsOnMount: L
    }
}
export {
    y as c
};