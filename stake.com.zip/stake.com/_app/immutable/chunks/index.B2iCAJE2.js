const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["_app/immutable/chunks/index.umd.DR0UIy4-.js", "_app/immutable/chunks/index.B4-7gKq3.js", "_app/immutable/chunks/index.B81orGJm.js", "_app/immutable/chunks/entry.GPJbNZcP.js", "_app/immutable/chunks/scheduler.DXu26z7T.js", "_app/immutable/chunks/index.C2-CG2CN.js", "_app/immutable/chunks/control.CYgJF_JY.js"]))) => i.map(i => d[i]);
import {
    s as E,
    e as S,
    d as I,
    f as N,
    i as g,
    j as p,
    n as R,
    O as M,
    P as O,
    F as _,
    I as ue,
    V as P,
    k as V,
    c as W,
    o as J,
    ab as qe,
    J as ie,
    W as ce,
    r as He,
    U as G,
    m as L,
    a6 as re,
    ap as ne,
    a as Le,
    u as Ue,
    g as Ae,
    b as Pe,
    t as ae,
    h as le,
    l as se,
    R as Z
} from "./scheduler.DXu26z7T.js";
import {
    S as T,
    i as F,
    c as k,
    a as w,
    m as $,
    t as f,
    g as U,
    b as m,
    e as A,
    d as b
} from "./index.Dz_MmNB3.js";
import {
    a as de
} from "./index.B81orGJm.js";
import {
    g as We
} from "./context.UnLgwODO.js";
import {
    a9 as Ve,
    _ as Ge,
    bZ as fe,
    h as q,
    i as Ce,
    cX as me,
    cY as K,
    A as xe,
    z as Ke,
    f as Xe
} from "./index.B4-7gKq3.js";
import {
    D as oe
} from "./DotsLoader.BJx50Plt.js";
import "./index.ByMdEFI5.js";
import "./entry.GPJbNZcP.js"; /* empty css                                            */
import {
    S as Je
} from "./index.DChG_RHX.js";
import {
    _ as Qe
} from "./preload-helper.BqjOJQfC.js";
import {
    m as Be
} from "./index.Ci34scWy.js";
import {
    T as Ye
} from "./index.D7nbRHfU.js";
import {
    m as ge
} from "./utils.92_vUFxq.js";
import "./index.B3dW9TVs.js";
import {
    B as _e
} from "./button.BwmFDw8u.js";
import {
    a as Re,
    L as X,
    b as Ze,
    c as et
} from "./utils.PGvbthip.js";
const tt = () => new Promise(l => {
    (function(e, i, t, r, a, n, o, s, u) {
        e[a] || (u = e[a] = function() {
            (e[a].q = e[a].q || []).push(arguments)
        }, u.l = 1 * new Date().getTime(), u.o = n, o = i.createElement(t), s = i.getElementsByTagName(t)[0], o.onload = () => {
            l("completed")
        }, o.async = 1, o.src = r, o.setAttribute("n", a), s.parentNode.insertBefore(o, s))
    })(window, document, "script", "https://widgets.sir.sportradar.com/7d2f8da584734cf9ab52112c1022d183/widgetloader", "SIR", {
        theme: !1,
        language: "en"
    })
});

function it(l) {
    let e;
    return {
        c() {
            e = S("span")
        },
        l(i) {
            e = I(i, "SPAN", {}), N(e).forEach(g)
        },
        m(i, t) {
            p(i, e, t)
        },
        p: R,
        i: R,
        o: R,
        d(i) {
            i && g(e)
        }
    }
}
class rt extends T {
    constructor(e) {
        super(), F(this, e, null, it, E, {})
    }
}

function pe(l) {
    let e, i, t;
    return i = new oe({}), {
        c() {
            e = S("div"), k(i.$$.fragment), this.h()
        },
        l(r) {
            e = I(r, "DIV", {
                class: !0
            });
            var a = N(e);
            w(i.$$.fragment, a), a.forEach(g), this.h()
        },
        h() {
            _(e, "class", "loading-wrap svelte-ymam4n")
        },
        m(r, a) {
            p(r, e, a), $(i, e, null), t = !0
        },
        i(r) {
            t || (f(i.$$.fragment, r), t = !0)
        },
        o(r) {
            m(i.$$.fragment, r), t = !1
        },
        d(r) {
            r && g(e), b(i)
        }
    }
}

function nt(l) {
    let e, i, t, r, a, n, o;
    i = new rt({});
    let s = l[1] && pe();
    return {
        c() {
            e = S("div"), k(i.$$.fragment), t = M(), r = S("div"), a = S("div"), n = M(), s && s.c(), this.h()
        },
        l(u) {
            e = I(u, "DIV", {
                class: !0
            });
            var c = N(e);
            w(i.$$.fragment, c), t = O(c), r = I(c, "DIV", {
                class: !0
            });
            var d = N(r);
            a = I(d, "DIV", {
                id: !0,
                "data-sr-widget": !0,
                "data-sr-match-id": !0,
                style: !0
            }), N(a).forEach(g), d.forEach(g), n = O(c), s && s.l(c), c.forEach(g), this.h()
        },
        h() {
            _(a, "id", "sr-widget"), _(a, "data-sr-widget", "match.lmt"), _(a, "data-sr-match-id", l[0]), ue(a, "width", "100%"), ue(a, "height", "100%"), _(r, "class", "wrap svelte-ymam4n"), _(e, "class", "widget svelte-ymam4n"), P(e, "loading", l[1])
        },
        m(u, c) {
            p(u, e, c), $(i, e, null), V(e, t), V(e, r), V(r, a), l[6](a), V(e, n), s && s.m(e, null), o = !0
        },
        p(u, [c]) {
            (!o || c & 1) && _(a, "data-sr-match-id", u[0]), u[1] ? s ? c & 2 && f(s, 1) : (s = pe(), s.c(), f(s, 1), s.m(e, null)) : s && (U(), m(s, 1, 1, () => {
                s = null
            }), A()), (!o || c & 2) && P(e, "loading", u[1])
        },
        i(u) {
            o || (f(i.$$.fragment, u), f(s), o = !0)
        },
        o(u) {
            m(i.$$.fragment, u), m(s), o = !1
        },
        d(u) {
            u && g(e), b(i), l[6](null), s && s.d()
        }
    }
}

function at(l, e, i) {
    let t, r, a;
    W(l, Ve, y => i(5, a = y));
    let {
        matchId: n
    } = e, {
        stacked: o = !1
    } = e, s = !1;
    const u = y => {
            const [, , h] = Ge.split(y, ":");
            return Number(h)
        },
        c = async () => {
            i(1, s = !0), await qe(), window.SIR("addWidget", d, "match.lmtPlus", t, () => {
                setTimeout(() => {
                    i(1, s = !1)
                }, 2e3)
            })
        };
    let d;
    J(() => (typeof window.SIR > "u" ? tt().then(() => c()) : c(), () => {
        typeof window.SIR < "u" && window.SIR("removeWidget", d)
    }));

    function v(y) {
        ie[y ? "unshift" : "push"](() => {
            d = y, i(2, d)
        })
    }
    return l.$$set = y => {
        "matchId" in y && i(3, n = y.matchId), "stacked" in y && i(4, o = y.stacked)
    }, l.$$.update = () => {
        l.$$.dirty & 8 && i(0, r = u(n)), l.$$.dirty & 49 && (t = {
            language: a,
            adsFrequency: !1,
            pitchCustomBgColor: "#009048",
            layout: o ? void 0 : "topdown",
            scoreboard: "extended",
            momentum: "extended",
            matchId: r,
            expanded: !o,
            activeSwitcher: "scoreDetails",
            collapseTo: "momentum",
            goalBannerImage: !1,
            silent: !0,
            debug: !1
        })
    }, [r, s, d, n, o, a, v]
}
class lt extends T {
    constructor(e) {
        super(), F(this, e, at, nt, E, {
            matchId: 3,
            stacked: 4
        })
    }
}

function st(l) {
    let e, i, t, r;
    return t = new oe({}), {
        c() {
            e = S("div"), i = S("div"), k(t.$$.fragment), this.h()
        },
        l(a) {
            e = I(a, "DIV", {
                class: !0
            });
            var n = N(e);
            i = I(n, "DIV", {
                class: !0
            });
            var o = N(i);
            w(t.$$.fragment, o), o.forEach(g), n.forEach(g), this.h()
        },
        h() {
            _(i, "class", "loader svelte-15bd3"), _(e, "class", "loader-wrapper svelte-15bd3")
        },
        m(a, n) {
            p(a, e, n), V(e, i), $(t, i, null), r = !0
        },
        p: R,
        i(a) {
            r || (f(t.$$.fragment, a), r = !0)
        },
        o(a) {
            m(t.$$.fragment, a), r = !1
        },
        d(a) {
            a && g(e), b(t)
        }
    }
}
class x extends T {
    constructor(e) {
        super(), F(this, e, null, st, E, {})
    }
}

function he(l) {
    let e, i;
    return e = new x({}), {
        c() {
            k(e.$$.fragment)
        },
        l(t) {
            w(e.$$.fragment, t)
        },
        m(t, r) {
            $(e, t, r), i = !0
        },
        i(t) {
            i || (f(e.$$.fragment, t), i = !0)
        },
        o(t) {
            m(e.$$.fragment, t), i = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function ot(l) {
    let e, i;
    return {
        c() {
            e = S("iframe"), this.h()
        },
        l(t) {
            e = I(t, "IFRAME", {
                title: !0,
                src: !0,
                scrolling: !0,
                height: !0,
                id: !0,
                name: !0,
                class: !0
            }), N(e).forEach(g), this.h()
        },
        h() {
            _(e, "title", "url"), G(e.src, i = l[1]) || _(e, "src", i), _(e, "scrolling", "yes"), _(e, "height", 350), _(e, "id", l[0]), _(e, "name", l[0]), _(e, "class", "svelte-1pq3pkn"), P(e, "is-hidden", l[2])
        },
        m(t, r) {
            p(t, e, r)
        },
        p(t, r) {
            r & 2 && !G(e.src, i = t[1]) && _(e, "src", i), r & 1 && _(e, "id", t[0]), r & 1 && _(e, "name", t[0]), r & 4 && P(e, "is-hidden", t[2])
        },
        d(t) {
            t && g(e)
        }
    }
}

function ut(l) {
    let e, i, t, r, a, n = l[2] && he();
    return i = new Je({
        props: {
            spacing: "1",
            horizontal: !1,
            $$slots: {
                default: [ot]
            },
            $$scope: {
                ctx: l
            }
        }
    }), {
        c() {
            n && n.c(), e = M(), k(i.$$.fragment)
        },
        l(o) {
            n && n.l(o), e = O(o), w(i.$$.fragment, o)
        },
        m(o, s) {
            n && n.m(o, s), p(o, e, s), $(i, o, s), t = !0, r || (a = [ce(window, "message", l[4]), ce(window, "message", l[3])], r = !0)
        },
        p(o, [s]) {
            o[2] ? n ? s & 4 && f(n, 1) : (n = he(), n.c(), f(n, 1), n.m(e.parentNode, e)) : n && (U(), m(n, 1, 1, () => {
                n = null
            }), A());
            const u = {};
            s & 39 && (u.$$scope = {
                dirty: s,
                ctx: o
            }), i.$set(u)
        },
        i(o) {
            t || (f(n), f(i.$$.fragment, o), t = !0)
        },
        o(o) {
            m(n), m(i.$$.fragment, o), t = !1
        },
        d(o) {
            o && g(e), n && n.d(o), b(i, o), r = !1, He(a)
        }
    }
}
const ve = "https://disir.oddin.gg",
    ke = "https://disir.integration.oddin.gg";

function ct(l, e, i) {
    let {
        widgetId: t = `widget-od-${Math.floor(Math.random()*1e5)}`
    } = e, {
        widgetUrl: r
    } = e, a = !0;
    const n = s => {
            var u;
            (ve === (s == null ? void 0 : s.origin) || ke === (s == null ? void 0 : s.origin)) && ((u = JSON.parse(s.data)) == null ? void 0 : u.type) === "LOADED" && i(2, a = !1)
        },
        o = s => {
            if (ve === (s == null ? void 0 : s.origin) || ke === (s == null ? void 0 : s.origin)) {
                const u = document.getElementById(t);
                if (u && s.source === u.contentWindow) {
                    const c = JSON.parse(s.data).height;
                    c && (u.height = c)
                }
            }
        };
    return l.$$set = s => {
        "widgetId" in s && i(0, t = s.widgetId), "widgetUrl" in s && i(1, r = s.widgetUrl)
    }, [t, r, a, n, o]
}
class dt extends T {
    constructor(e) {
        super(), F(this, e, ct, ut, E, {
            widgetId: 0,
            widgetUrl: 1
        })
    }
}

function $e(l) {
    let e, i, t;
    return i = new oe({}), {
        c() {
            e = S("div"), k(i.$$.fragment), this.h()
        },
        l(r) {
            e = I(r, "DIV", {
                class: !0
            });
            var a = N(e);
            w(i.$$.fragment, a), a.forEach(g), this.h()
        },
        h() {
            _(e, "class", "loader-wrap svelte-3u126")
        },
        m(r, a) {
            p(r, e, a), $(i, e, null), t = !0
        },
        i(r) {
            t || (f(i.$$.fragment, r), t = !0)
        },
        o(r) {
            m(i.$$.fragment, r), t = !1
        },
        d(r) {
            r && g(e), b(i)
        }
    }
}

function ft(l) {
    let e, i, t, r = l[2] && $e();
    return {
        c() {
            r && r.c(), e = M(), i = S("div"), this.h()
        },
        l(a) {
            r && r.l(a), e = O(a), i = I(a, "DIV", {
                id: !0,
                class: !0
            }), N(i).forEach(g), this.h()
        },
        h() {
            _(i, "id", "img-arena-front-row-seat-" + l[3]), _(i, "class", "svelte-3u126"), P(i, "hide", l[2]), P(i, "mobile", l[1] === "onPage" && l[0] === "mobile")
        },
        m(a, n) {
            r && r.m(a, n), p(a, e, n), p(a, i, n), t = !0
        },
        p(a, [n]) {
            a[2] ? r ? n & 4 && f(r, 1) : (r = $e(), r.c(), f(r, 1), r.m(e.parentNode, e)) : r && (U(), m(r, 1, 1, () => {
                r = null
            }), A()), (!t || n & 4) && P(i, "hide", a[2]), (!t || n & 3) && P(i, "mobile", a[1] === "onPage" && a[0] === "mobile")
        },
        i(a) {
            t || (f(r), t = !0)
        },
        o(a) {
            m(r), t = !1
        },
        d(a) {
            a && (g(e), g(i)), r && r.d(a)
        }
    }
}

function mt(l, e, i) {
    let t;
    W(l, Ve, h => i(9, t = h));
    let {
        eventId: r
    } = e, {
        fightId: a
    } = e, {
        widgetSize: n
    } = e, {
        widgetContext: o
    } = e, s, u, c, d = !0;
    const y = Math.random().toString(36).substring(2);
    return J(async () => {
        try {
            const h = await Qe(() =>
                    import ("./index.umd.DR0UIy4-.js").then(D => D.i), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6])),
                {
                    eventCentre: z,
                    eventCentreUtils: j
                } = h,
                {
                    MessageTopics: B
                } = j;
            i(6, s = z({
                operator: "stake",
                sport: "ufc",
                eventId: r,
                targetModule: a ? "fight" : "full",
                version: "5.x",
                targetElementSelector: "#img-arena-front-row-seat-" + y,
                language: t,
                ...a ? {
                    initialContext: {
                        fightId: a,
                        view: "matchup"
                    }
                } : {}
            })), i(7, u = D => s.emit(B.CONTEXT_UPDATE, {
                fightId: D
            })), i(8, c = D => s.emit(B.CONTEXT_UPDATE, {
                eventId: D
            })), s.on(B.CONTEXT_UPDATE, () => {
                i(2, d = !1)
            })
        } catch (h) {
            console.error(h)
        }
    }), l.$$set = h => {
        "eventId" in h && i(4, r = h.eventId), "fightId" in h && i(5, a = h.fightId), "widgetSize" in h && i(0, n = h.widgetSize), "widgetContext" in h && i(1, o = h.widgetContext)
    }, l.$$.update = () => {
        l.$$.dirty & 224 && s && u && a && u(a), l.$$.dirty & 336 && s && c && c(r)
    }, [n, o, d, y, r, a, s, u, c]
}
class gt extends T {
    constructor(e) {
        super(), F(this, e, mt, ft, E, {
            eventId: 4,
            fightId: 5,
            widgetSize: 0,
            widgetContext: 1
        })
    }
}
const _t = l => ({}),
    be = l => ({});

function pt(l) {
    let e, i, t, r;
    const a = [kt, vt, ht],
        n = [];

    function o(s, u) {
        var c, d;
        return s[0].provider === fe.oddin ? 0 : (d = (c = s[0].tournament) == null ? void 0 : c.frontRowSeatEvent) != null && d.identifier ? 1 : s[0].provider === fe.betradar ? 2 : -1
    }
    return ~(e = o(l)) && (i = n[e] = a[e](l)), {
        c() {
            i && i.c(), t = L()
        },
        l(s) {
            i && i.l(s), t = L()
        },
        m(s, u) {
            ~e && n[e].m(s, u), p(s, t, u), r = !0
        },
        p(s, u) {
            let c = e;
            e = o(s), e === c ? ~e && n[e].p(s, u) : (i && (U(), m(n[c], 1, 1, () => {
                n[c] = null
            }), A()), ~e ? (i = n[e], i ? i.p(s, u) : (i = n[e] = a[e](s), i.c()), f(i, 1), i.m(t.parentNode, t)) : i = null)
        },
        i(s) {
            r || (f(i), r = !0)
        },
        o(s) {
            m(i), r = !1
        },
        d(s) {
            s && g(t), ~e && n[e].d(s)
        }
    }
}

function ht(l) {
    var c;
    let e, i, t, r, a, n, o, s;
    t = new lt({
        props: {
            matchId: (c = l[0]) == null ? void 0 : c.extId,
            stacked: l[1]
        }
    });
    let u = l[2] <= 30 && we(l);
    return {
        c() {
            e = S("div"), i = S("div"), k(t.$$.fragment), n = M(), u && u.c(), o = L(), this.h()
        },
        l(d) {
            e = I(d, "DIV", {
                "data-analytics": !0,
                class: !0
            });
            var v = N(e);
            i = I(v, "DIV", {
                class: !0
            });
            var y = N(i);
            w(t.$$.fragment, y), y.forEach(g), v.forEach(g), n = O(d), u && u.l(d), o = L(), this.h()
        },
        h() {
            _(i, "class", "lmt svelte-1c0gj4r"), _(e, "data-analytics", "sports-fixture-betRadar-widget"), _(e, "class", r = "widget-container tracker " + l[5] + " chromatic-ignore svelte-1c0gj4r"), re(() => l[14].call(e)), P(e, "hide-margin", l[3])
        },
        m(d, v) {
            p(d, e, v), V(e, i), $(t, i, null), a = ne(e, l[14].bind(e)), p(d, n, v), u && u.m(d, v), p(d, o, v), s = !0
        },
        p(d, v) {
            var h;
            const y = {};
            v & 1 && (y.matchId = (h = d[0]) == null ? void 0 : h.extId), v & 2 && (y.stacked = d[1]), t.$set(y), (!s || v & 32 && r !== (r = "widget-container tracker " + d[5] + " chromatic-ignore svelte-1c0gj4r")) && _(e, "class", r), (!s || v & 40) && P(e, "hide-margin", d[3]), d[2] <= 30 ? u ? (u.p(d, v), v & 4 && f(u, 1)) : (u = we(d), u.c(), f(u, 1), u.m(o.parentNode, o)) : u && (U(), m(u, 1, 1, () => {
                u = null
            }), A())
        },
        i(d) {
            s || (f(t.$$.fragment, d), f(u), s = !0)
        },
        o(d) {
            m(t.$$.fragment, d), m(u), s = !1
        },
        d(d) {
            d && (g(e), g(n), g(o)), b(t), a(), u && u.d(d)
        }
    }
}

function vt(l) {
    var n, o, s, u;
    let e, i, t, r, a;
    return i = new gt({
        props: {
            widgetContext: l[4],
            widgetSize: l[5],
            eventId: (o = (n = l[0].tournament) == null ? void 0 : n.frontRowSeatEvent) == null ? void 0 : o.identifier,
            fightId: (u = (s = l[0]) == null ? void 0 : s.frontRowSeatFight) == null ? void 0 : u.fightId
        }
    }), {
        c() {
            e = S("div"), k(i.$$.fragment), this.h()
        },
        l(c) {
            e = I(c, "DIV", {
                "data-analytics": !0,
                class: !0
            });
            var d = N(e);
            w(i.$$.fragment, d), d.forEach(g), this.h()
        },
        h() {
            _(e, "data-analytics", "sports-fixture-ufcEventCenter-widget"), _(e, "class", t = "widget-container " + l[5] + " svelte-1c0gj4r"), re(() => l[13].call(e)), P(e, "hide-margin", l[3])
        },
        m(c, d) {
            p(c, e, d), $(i, e, null), r = ne(e, l[13].bind(e)), a = !0
        },
        p(c, d) {
            var y, h, z, j;
            const v = {};
            d & 16 && (v.widgetContext = c[4]), d & 32 && (v.widgetSize = c[5]), d & 1 && (v.eventId = (h = (y = c[0].tournament) == null ? void 0 : y.frontRowSeatEvent) == null ? void 0 : h.identifier), d & 1 && (v.fightId = (j = (z = c[0]) == null ? void 0 : z.frontRowSeatFight) == null ? void 0 : j.fightId), i.$set(v), (!a || d & 32 && t !== (t = "widget-container " + c[5] + " svelte-1c0gj4r")) && _(e, "class", t), (!a || d & 40) && P(e, "hide-margin", c[3])
        },
        i(c) {
            a || (f(i.$$.fragment, c), a = !0)
        },
        o(c) {
            m(i.$$.fragment, c), a = !1
        },
        d(c) {
            c && g(e), b(i), r()
        }
    }
}

function kt(l) {
    let e, i, t = l[7] && $t(l);
    return {
        c() {
            t && t.c(), e = L()
        },
        l(r) {
            t && t.l(r), e = L()
        },
        m(r, a) {
            t && t.m(r, a), p(r, e, a), i = !0
        },
        p(r, a) {
            r[7] && t.p(r, a)
        },
        i(r) {
            i || (f(t), i = !0)
        },
        o(r) {
            m(t), i = !1
        },
        d(r) {
            r && g(e), t && t.d(r)
        }
    }
}

function we(l) {
    let e;
    const i = l[11].widgetFallback,
        t = Le(i, l, l[10], be);
    return {
        c() {
            t && t.c()
        },
        l(r) {
            t && t.l(r)
        },
        m(r, a) {
            t && t.m(r, a), e = !0
        },
        p(r, a) {
            t && t.p && (!e || a & 1024) && Ue(t, i, r, r[10], e ? Pe(i, r[10], a, _t) : Ae(r[10]), be)
        },
        i(r) {
            e || (f(t, r), e = !0)
        },
        o(r) {
            m(t, r), e = !1
        },
        d(r) {
            t && t.d(r)
        }
    }
}

function $t(l) {
    let e, i, t, r, a;
    return i = new dt({
        props: {
            widgetUrl: l[7]
        }
    }), {
        c() {
            e = S("div"), k(i.$$.fragment), this.h()
        },
        l(n) {
            e = I(n, "DIV", {
                "data-analytics": !0,
                class: !0
            });
            var o = N(e);
            w(i.$$.fragment, o), o.forEach(g), this.h()
        },
        h() {
            _(e, "data-analytics", "sports-fixture-oddin-widget"), _(e, "class", t = "widget-container tracker " + l[5] + " svelte-1c0gj4r"), re(() => l[12].call(e)), P(e, "hide-margin", l[3])
        },
        m(n, o) {
            p(n, e, o), $(i, e, null), r = ne(e, l[12].bind(e)), a = !0
        },
        p(n, o) {
            (!a || o & 32 && t !== (t = "widget-container tracker " + n[5] + " svelte-1c0gj4r")) && _(e, "class", t), (!a || o & 40) && P(e, "hide-margin", n[3])
        },
        i(n) {
            a || (f(i.$$.fragment, n), a = !0)
        },
        o(n) {
            m(i.$$.fragment, n), a = !1
        },
        d(n) {
            n && g(e), b(i), r()
        }
    }
}

function bt(l) {
    let e, i, t = !de && pt(l);
    return {
        c() {
            t && t.c(), e = L()
        },
        l(r) {
            t && t.l(r), e = L()
        },
        m(r, a) {
            t && t.m(r, a), p(r, e, a), i = !0
        },
        p(r, [a]) {
            de || t.p(r, a)
        },
        i(r) {
            i || (f(t), i = !0)
        },
        o(r) {
            m(t), i = !1
        },
        d(r) {
            r && g(e), t && t.d(r)
        }
    }
}

function wt(l, e, i) {
    let t, r, a, n, {
            $$slots: o = {},
            $$scope: s
        } = e,
        {
            widgetUrl: u = null
        } = e,
        {
            fixture: c
        } = e,
        {
            stacked: d = !1
        } = e;
    const v = We();
    W(l, v, D => i(9, n = D));
    const y = u;
    let h;

    function z() {
        h = this.clientHeight, i(2, h)
    }

    function j() {
        h = this.clientHeight, i(2, h)
    }

    function B() {
        h = this.clientHeight, i(2, h)
    }
    return l.$$set = D => {
        "widgetUrl" in D && i(8, u = D.widgetUrl), "fixture" in D && i(0, c = D.fixture), "stacked" in D && i(1, d = D.stacked), "$$scope" in D && i(10, s = D.$$scope)
    }, l.$$.update = () => {
        l.$$.dirty & 514 && i(5, t = d === !1 ? "desktop" : n > 540 ? "tablet" : "mobile"), l.$$.dirty & 512 && i(4, r = n ? "onPage" : "draggableFrame"), l.$$.dirty & 4 && i(3, a = h && h <= 15)
    }, [c, d, h, a, r, t, v, y, u, n, s, o, z, j, B]
}
class zi extends T {
    constructor(e) {
        super(), F(this, e, wt, bt, E, {
            widgetUrl: 8,
            fixture: 0,
            stacked: 1
        })
    }
}
const yt = {
    kind: "Document",
    definitions: [{
        kind: "OperationDefinition",
        operation: "query",
        name: {
            kind: "Name",
            value: "FixtureLivestream"
        },
        variableDefinitions: [{
            kind: "VariableDefinition",
            variable: {
                kind: "Variable",
                name: {
                    kind: "Name",
                    value: "fixtureId"
                }
            },
            type: {
                kind: "NonNullType",
                type: {
                    kind: "NamedType",
                    name: {
                        kind: "Name",
                        value: "String"
                    }
                }
            }
        }, {
            kind: "VariableDefinition",
            variable: {
                kind: "Variable",
                name: {
                    kind: "Name",
                    value: "deliveryType"
                }
            },
            type: {
                kind: "NonNullType",
                type: {
                    kind: "NamedType",
                    name: {
                        kind: "Name",
                        value: "GeniusSportsDeliveryTypeEnum"
                    }
                }
            }
        }],
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "sportFixture"
                },
                arguments: [{
                    kind: "Argument",
                    name: {
                        kind: "Name",
                        value: "fixtureId"
                    },
                    value: {
                        kind: "Variable",
                        name: {
                            kind: "Name",
                            value: "fixtureId"
                        }
                    }
                }],
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "FragmentSpread",
                        name: {
                            kind: "Name",
                            value: "SportFixtureLiveStream"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "data"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "InlineFragment",
                                typeCondition: {
                                    kind: "NamedType",
                                    name: {
                                        kind: "Name",
                                        value: "SportFixtureDataMatch"
                                    }
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "tvChannels"
                                        },
                                        selectionSet: {
                                            kind: "SelectionSet",
                                            selections: [{
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "language"
                                                }
                                            }, {
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "name"
                                                }
                                            }, {
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "streamUrl"
                                                }
                                            }]
                                        }
                                    }]
                                }
                            }]
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "geniussportsStream"
                        },
                        arguments: [{
                            kind: "Argument",
                            name: {
                                kind: "Name",
                                value: "deliveryType"
                            },
                            value: {
                                kind: "Variable",
                                name: {
                                    kind: "Name",
                                    value: "deliveryType"
                                }
                            }
                        }],
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "exists"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "isAvailable"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "data"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "customerId"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "fixtureId"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "maxSize"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "token"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "url"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "drm"
                                        },
                                        selectionSet: {
                                            kind: "SelectionSet",
                                            selections: [{
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "fairplay"
                                                }
                                            }, {
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "fairplayCertificate"
                                                }
                                            }, {
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "playready"
                                                }
                                            }, {
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "widevine"
                                                }
                                            }]
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "SportFixtureLiveStream"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixture"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "imgArenaStream"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "url"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "exists"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "isAvailable"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "betradarStream"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "exists"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "isAvailable"
                        }
                    }]
                }
            }]
        }
    }]
};
var Y = (l => (l.unauthenticated = "unauthenticated", l.playing = "playing", l))(Y || {});
const H = {
    available: q._("Live Streaming Available"),
    register: q._("Register"),
    finished: q._("Live Streaming Finished"),
    notStarted: q._("This stream will commence before the start of the event."),
    regionBlocked: q._("This stream is not available in your region."),
    unexpectedError: q._("An unexpected error occurred while loading the stream. Please try again later."),
    unavailable: q._("This stream is currently unavailable"),
    unauthenticated: q._("Please log in to view this stream."),
    login: q._("Sign In")
};

function ye(l) {
    let e, i;
    return e = new Ye({
        props: {
            $$slots: {
                default: [St]
            },
            $$scope: {
                ctx: l
            }
        }
    }), {
        c() {
            k(e.$$.fragment)
        },
        l(t) {
            w(e.$$.fragment, t)
        },
        m(t, r) {
            $(e, t, r), i = !0
        },
        p(t, r) {
            const a = {};
            r & 11 && (a.$$scope = {
                dirty: r,
                ctx: t
            }), e.$set(a)
        },
        i(t) {
            i || (f(e.$$.fragment, t), i = !0)
        },
        o(t) {
            m(e.$$.fragment, t), i = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function St(l) {
    let e = l[1]._(l[0]) + "",
        i;
    return {
        c() {
            i = ae(e)
        },
        l(t) {
            i = le(t, e)
        },
        m(t, r) {
            p(t, i, r)
        },
        p(t, r) {
            r & 3 && e !== (e = t[1]._(t[0]) + "") && se(i, e)
        },
        d(t) {
            t && g(i)
        }
    }
}

function It(l) {
    let e, i, t, r = l[0] && ye(l);
    const a = l[2].default,
        n = Le(a, l, l[3], null);
    return {
        c() {
            e = S("div"), r && r.c(), i = M(), n && n.c(), this.h()
        },
        l(o) {
            e = I(o, "DIV", {
                class: !0
            });
            var s = N(e);
            r && r.l(s), i = O(s), n && n.l(s), s.forEach(g), this.h()
        },
        h() {
            _(e, "class", "wrapper svelte-nsm53g")
        },
        m(o, s) {
            p(o, e, s), r && r.m(e, null), V(e, i), n && n.m(e, null), t = !0
        },
        p(o, [s]) {
            o[0] ? r ? (r.p(o, s), s & 1 && f(r, 1)) : (r = ye(o), r.c(), f(r, 1), r.m(e, i)) : r && (U(), m(r, 1, 1, () => {
                r = null
            }), A()), n && n.p && (!t || s & 8) && Ue(n, a, o, o[3], t ? Pe(a, o[3], s, null) : Ae(o[3]), null)
        },
        i(o) {
            t || (f(r), f(n, o), t = !0)
        },
        o(o) {
            m(r), m(n, o), t = !1
        },
        d(o) {
            o && g(e), r && r.d(), n && n.d(o)
        }
    }
}

function Nt(l, e, i) {
    let t;
    W(l, Ce, o => i(1, t = o));
    let {
        $$slots: r = {},
        $$scope: a
    } = e, {
        message: n
    } = e;
    return l.$$set = o => {
        "message" in o && i(0, n = o.message), "$$scope" in o && i(3, a = o.$$scope)
    }, [n, t, r, a]
}
class Q extends T {
    constructor(e) {
        super(), F(this, e, Nt, It, E, {
            message: 0
        })
    }
}

function Et(l) {
    let e, i;
    return e = new Q({
        props: {
            message: H.finished
        }
    }), {
        c() {
            k(e.$$.fragment)
        },
        l(t) {
            w(e.$$.fragment, t)
        },
        m(t, r) {
            $(e, t, r), i = !0
        },
        p: R,
        i(t) {
            i || (f(e.$$.fragment, t), i = !0)
        },
        o(t) {
            m(e.$$.fragment, t), i = !1
        },
        d(t) {
            b(e, t)
        }
    }
}
class Tt extends T {
    constructor(e) {
        super(), F(this, e, null, Et, E, {})
    }
}

function Ft(l) {
    let e, i;
    return e = new Q({
        props: {
            message: H.notStarted
        }
    }), {
        c() {
            k(e.$$.fragment)
        },
        l(t) {
            w(e.$$.fragment, t)
        },
        m(t, r) {
            $(e, t, r), i = !0
        },
        p: R,
        i(t) {
            i || (f(e.$$.fragment, t), i = !0)
        },
        o(t) {
            m(e.$$.fragment, t), i = !1
        },
        d(t) {
            b(e, t)
        }
    }
}
class Dt extends T {
    constructor(e) {
        super(), F(this, e, null, Ft, E, {})
    }
}

function Lt(l) {
    let e, i;
    return e = new Q({
        props: {
            message: H.regionBlocked
        }
    }), {
        c() {
            k(e.$$.fragment)
        },
        l(t) {
            w(e.$$.fragment, t)
        },
        m(t, r) {
            $(e, t, r), i = !0
        },
        p: R,
        i(t) {
            i || (f(e.$$.fragment, t), i = !0)
        },
        o(t) {
            m(e.$$.fragment, t), i = !1
        },
        d(t) {
            b(e, t)
        }
    }
}
class Ut extends T {
    constructor(e) {
        super(), F(this, e, null, Lt, E, {})
    }
}

function At(l) {
    let e = l[0]._(H.login) + "",
        i;
    return {
        c() {
            i = ae(e)
        },
        l(t) {
            i = le(t, e)
        },
        m(t, r) {
            p(t, i, r)
        },
        p(t, r) {
            r & 1 && e !== (e = t[0]._(H.login) + "") && se(i, e)
        },
        d(t) {
            t && g(i)
        }
    }
}

function Pt(l) {
    let e = l[0]._(H.register) + "",
        i;
    return {
        c() {
            i = ae(e)
        },
        l(t) {
            i = le(t, e)
        },
        m(t, r) {
            p(t, i, r)
        },
        p(t, r) {
            r & 1 && e !== (e = t[0]._(H.register) + "") && se(i, e)
        },
        d(t) {
            t && g(i)
        }
    }
}

function Vt(l) {
    let e, i, t, r, a;
    return i = new _e({
        props: {
            variant: "link",
            "data-testid": "login-link",
            "data-test": "login-link",
            iconOnly: !0,
            $$slots: {
                default: [At]
            },
            $$scope: {
                ctx: l
            }
        }
    }), i.$on("click", l[1]), r = new _e({
        props: {
            "data-testid": "register-link",
            "data-test": "register-link",
            variant: "action",
            $$slots: {
                default: [Pt]
            },
            $$scope: {
                ctx: l
            }
        }
    }), r.$on("click", l[2]), {
        c() {
            e = S("div"), k(i.$$.fragment), t = M(), k(r.$$.fragment)
        },
        l(n) {
            e = I(n, "DIV", {});
            var o = N(e);
            w(i.$$.fragment, o), t = O(o), w(r.$$.fragment, o), o.forEach(g)
        },
        m(n, o) {
            p(n, e, o), $(i, e, null), V(e, t), $(r, e, null), a = !0
        },
        p(n, o) {
            const s = {};
            o & 9 && (s.$$scope = {
                dirty: o,
                ctx: n
            }), i.$set(s);
            const u = {};
            o & 9 && (u.$$scope = {
                dirty: o,
                ctx: n
            }), r.$set(u)
        },
        i(n) {
            a || (f(i.$$.fragment, n), f(r.$$.fragment, n), a = !0)
        },
        o(n) {
            m(i.$$.fragment, n), m(r.$$.fragment, n), a = !1
        },
        d(n) {
            n && g(e), b(i), b(r)
        }
    }
}

function Ct(l) {
    let e, i;
    return e = new Q({
        props: {
            message: H.unauthenticated,
            $$slots: {
                default: [Vt]
            },
            $$scope: {
                ctx: l
            }
        }
    }), {
        c() {
            k(e.$$.fragment)
        },
        l(t) {
            w(e.$$.fragment, t)
        },
        m(t, r) {
            $(e, t, r), i = !0
        },
        p(t, [r]) {
            const a = {};
            r & 9 && (a.$$scope = {
                dirty: r,
                ctx: t
            }), e.$set(a)
        },
        i(t) {
            i || (f(e.$$.fragment, t), i = !0)
        },
        o(t) {
            m(e.$$.fragment, t), i = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function Bt(l, e, i) {
    let t;
    return W(l, Ce, n => i(0, t = n)), [t, () => ge.auth.open({
        tab: "login"
    }), () => ge.auth.open({
        tab: "register"
    })]
}
class Me extends T {
    constructor(e) {
        super(), F(this, e, Bt, Ct, E, {})
    }
}

function Rt(l) {
    let e, i;
    return e = new Q({
        props: {
            message: H.unexpectedError
        }
    }), {
        c() {
            k(e.$$.fragment)
        },
        l(t) {
            w(e.$$.fragment, t)
        },
        m(t, r) {
            $(e, t, r), i = !0
        },
        p: R,
        i(t) {
            i || (f(e.$$.fragment, t), i = !0)
        },
        o(t) {
            m(e.$$.fragment, t), i = !1
        },
        d(t) {
            b(e, t)
        }
    }
}
class Mt extends T {
    constructor(e) {
        super(), F(this, e, null, Rt, E, {})
    }
}

function Se(l) {
    let e, i;
    return {
        c() {
            e = S("iframe"), this.h()
        },
        l(t) {
            e = I(t, "IFRAME", {
                title: !0,
                class: !0,
                scrolling: !0,
                src: !0
            }), N(e).forEach(g), this.h()
        },
        h() {
            _(e, "title", "esport-livestream"), _(e, "class", "iframe svelte-oqhw7e"), _(e, "scrolling", "no"), e.allowFullscreen = !0, G(e.src, i = l[0]) || _(e, "src", i)
        },
        m(t, r) {
            p(t, e, r)
        },
        p(t, r) {
            r & 1 && !G(e.src, i = t[0]) && _(e, "src", i)
        },
        d(t) {
            t && g(e)
        }
    }
}

function Ot(l) {
    let e, i = l[0] && Se(l);
    return {
        c() {
            i && i.c(), e = L()
        },
        l(t) {
            i && i.l(t), e = L()
        },
        m(t, r) {
            i && i.m(t, r), p(t, e, r)
        },
        p(t, [r]) {
            t[0] ? i ? i.p(t, r) : (i = Se(t), i.c(), i.m(e.parentNode, e)) : i && (i.d(1), i = null)
        },
        i: R,
        o: R,
        d(t) {
            t && g(e), i && i.d(t)
        }
    }
}

function zt(l, e, i) {
    let {
        src: t = null
    } = e;
    return l.$$set = r => {
        "src" in r && i(0, t = r.src)
    }, [t]
}
let jt = class extends T {
    constructor(e) {
        super(), F(this, e, zt, Ot, E, {
            src: 0
        })
    }
};

function qt(l) {
    let e, i, t, r, a;
    var n = l[1];

    function o(s, u) {
        return {
            props: {
                src: s[0]
            }
        }
    }
    return n && (r = Z(n, o(l))), {
        c() {
            e = S("div"), i = S("div"), t = S("div"), r && k(r.$$.fragment), this.h()
        },
        l(s) {
            e = I(s, "DIV", {
                class: !0
            });
            var u = N(e);
            i = I(u, "DIV", {
                class: !0
            });
            var c = N(i);
            t = I(c, "DIV", {
                class: !0
            });
            var d = N(t);
            r && w(r.$$.fragment, d), d.forEach(g), c.forEach(g), u.forEach(g), this.h()
        },
        h() {
            _(t, "class", "ratio-wrap svelte-1ox797y"), _(i, "class", "player-view svelte-1ox797y"), _(e, "class", "content svelte-1ox797y")
        },
        m(s, u) {
            p(s, e, u), V(e, i), V(i, t), r && $(r, t, null), a = !0
        },
        p(s, [u]) {
            if (u & 2 && n !== (n = s[1])) {
                if (r) {
                    U();
                    const c = r;
                    m(c.$$.fragment, 1, 0, () => {
                        b(c, 1)
                    }), A()
                }
                n ? (r = Z(n, o(s)), k(r.$$.fragment), f(r.$$.fragment, 1), $(r, t, null)) : r = null
            } else if (n) {
                const c = {};
                u & 1 && (c.src = s[0]), r.$set(c)
            }
        },
        i(s) {
            a || (r && f(r.$$.fragment, s), a = !0)
        },
        o(s) {
            r && m(r.$$.fragment, s), a = !1
        },
        d(s) {
            s && g(e), r && b(r)
        }
    }
}

function Ht(l, e, i) {
    let t;
    W(l, Be, s => i(2, t = s));
    let {
        liveStreamUrl: r
    } = e;
    const a = {
        playing: jt,
        unauthenticated: Me
    };
    let n = a[Y.unauthenticated];
    const o = s => {
        if (!s) {
            i(1, n = a[Y.unauthenticated]);
            return
        }
        i(1, n = a[Y.playing])
    };
    return l.$$set = s => {
        "liveStreamUrl" in s && i(0, r = s.liveStreamUrl)
    }, l.$$.update = () => {
        l.$$.dirty & 4 && o(t.isAuthenticated)
    }, [r, n, t]
}
class Wt extends T {
    constructor(e) {
        super(), F(this, e, Ht, qt, E, {
            liveStreamUrl: 0
        })
    }
}
const Gt = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "mutation",
            name: {
                kind: "Name",
                value: "RequestBetradarLivestream"
            },
            variableDefinitions: [{
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "fixtureId"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "String"
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "streamType"
                    }
                },
                type: {
                    kind: "NamedType",
                    name: {
                        kind: "Name",
                        value: "SportBetradarTypeEnum"
                    }
                }
            }],
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "requestBetradarLivestream"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "fixtureId"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "fixtureId"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "streamType"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "streamType"
                            }
                        }
                    }],
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "url"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "endTime"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "startTime"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "streamType"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "isAvailable"
                            }
                        }]
                    }
                }]
            }
        }]
    },
    Oe = window.MediaSource || "WebKitMediaSource" in window;

function xt() {
    return Oe ? me.dash : me.hls
}
var C = (l => (l.loading = "loading", l.notStarted = "notStarted", l.regionBlocked = "regionBlocked", l.playing = "playing", l.finished = "finished", l.unexpectedError = "unexpectedError", l.unauthenticated = "unauthenticated", l))(C || {});
const Kt = navigator && (["iPad Simulator", "iPhone Simulator", "iPod Simulator", "iPad", "iPhone", "iPod"].includes(navigator.platform) || navigator.userAgent.includes("Mac") && "ontouchend" in document),
    Xt = async ({
        fixtureId: l,
        streamType: e
    }) => {
        var i;
        try {
            const r = await xe().mutation(Gt, {
                    fixtureId: l,
                    streamType: e
                }).toPromise(),
                a = (i = r == null ? void 0 : r.data) == null ? void 0 : i.requestBetradarLivestream;
            return a ? !(a != null && a.isAvailable) || !(a != null && a.url) ? {
                streamError: "regionBlocked"
            } : {
                url: a.url,
                endTime: a.endTime ? ? void 0,
                startTime: a.startTime ? ? void 0,
                streamType: e,
                livestreamType: X.betradar
            } : {
                streamError: "notStarted"
            }
        } catch {
            return {
                streamError: "regionBlocked"
            }
        }
    },
    Jt = async (l, e) => {
        if (!l) return {
            streamError: "loading"
        };
        const i = Re(l);
        if (i === null) return {
            streamError: "loading"
        };
        if (i === X.betradar) {
            const {
                id: t
            } = l || {};
            try {
                const r = Oe ? K.dash : K.hls;
                return { ...await Xt({
                        fixtureId: t,
                        streamType: r
                    }),
                    livestreamType: i
                }
            } catch {
                return {
                    streamError: "unexpectedError"
                }
            }
        }
        if (i === X.imgarena) {
            const {
                imgArenaStream: t
            } = l || {};
            if (!e) return {
                streamError: "unauthenticated"
            };
            if (!(t != null && t.url)) return {
                streamError: "regionBlocked"
            };
            try {
                const a = await (await fetch(t.url)).json(),
                    n = (a == null ? void 0 : a.hlsUrl) ? ? null;
                return n ? {
                    url: n,
                    endTime: void 0,
                    startTime: void 0,
                    streamType: K.hls,
                    livestreamType: i
                } : {
                    streamError: "notStarted"
                }
            } catch {
                return {
                    streamError: "unexpectedError"
                }
            }
        }
        if (i === X.genius) {
            const {
                geniussportsStream: t
            } = l || {}, r = t == null ? void 0 : t.data;
            return r ? {
                data: r,
                endTime: void 0,
                startTime: void 0,
                streamType: K.hls,
                livestreamType: i
            } : {
                streamError: "regionBlocked"
            }
        }
        return null
    };

function Ie(l) {
    let e, i;
    return e = new x({}), {
        c() {
            k(e.$$.fragment)
        },
        l(t) {
            w(e.$$.fragment, t)
        },
        m(t, r) {
            $(e, t, r), i = !0
        },
        i(t) {
            i || (f(e.$$.fragment, t), i = !0)
        },
        o(t) {
            m(e.$$.fragment, t), i = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function Qt(l) {
    let e, i, t, r, a, n = l[0] && Ie();
    return {
        c() {
            n && n.c(), e = M(), i = S("video"), t = S("track"), this.h()
        },
        l(o) {
            n && n.l(o), e = O(o), i = I(o, "VIDEO", {
                disablepictureinpicture: !0,
                controlslist: !0,
                style: !0,
                class: !0
            });
            var s = N(i);
            t = I(s, "TRACK", {
                kind: !0
            }), s.forEach(g), this.h()
        },
        h() {
            _(t, "kind", "captions"), i.autoplay = !0, i.controls = !0, i.playsInline = !0, _(i, "disablepictureinpicture", ""), _(i, "controlslist", "nodownload nofullscreen"), _(i, "style", r = l[0] ? "display: none" : void 0), _(i, "class", "svelte-1o9biee")
        },
        m(o, s) {
            n && n.m(o, s), p(o, e, s), p(o, i, s), V(i, t), l[3](i), a = !0
        },
        p(o, [s]) {
            o[0] ? n ? s & 1 && f(n, 1) : (n = Ie(), n.c(), f(n, 1), n.m(e.parentNode, e)) : n && (U(), m(n, 1, 1, () => {
                n = null
            }), A()), (!a || s & 1 && r !== (r = o[0] ? "display: none" : void 0)) && _(i, "style", r)
        },
        i(o) {
            a || (f(n), a = !0)
        },
        o(o) {
            m(n), a = !1
        },
        d(o) {
            o && (g(e), g(i)), n && n.d(o), l[3](null)
        }
    }
}

function Yt(l, e, i) {
    let {
        streamUrl: t
    } = e, r = !0, a;
    const n = () => {
            a.play()
        },
        o = () => {
            const c = new window.Hls;
            c.loadSource(t), c.attachMedia(a), c.on(window.Hls.Events.MANIFEST_PARSED, n)
        },
        s = () => {
            i(0, r = !1), o()
        };
    J(() => {
        const c = document.createElement("script");
        return c.src = "https://cdnjs.cloudflare.com/ajax/libs/hls.js/1.5.11/hls.min.js", c.onload = s, document.head.appendChild(c), () => {
            a && (a.pause(), a.removeAttribute("src"), a.load())
        }
    });

    function u(c) {
        ie[c ? "unshift" : "push"](() => {
            a = c, i(1, a)
        })
    }
    return l.$$set = c => {
        "streamUrl" in c && i(2, t = c.streamUrl)
    }, [r, a, t, u]
}
class Zt extends T {
    constructor(e) {
        super(), F(this, e, Yt, Qt, E, {
            streamUrl: 2
        })
    }
}

function Ne(l) {
    let e, i;
    return e = new x({}), {
        c() {
            k(e.$$.fragment)
        },
        l(t) {
            w(e.$$.fragment, t)
        },
        m(t, r) {
            $(e, t, r), i = !0
        },
        i(t) {
            i || (f(e.$$.fragment, t), i = !0)
        },
        o(t) {
            m(e.$$.fragment, t), i = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function ei(l) {
    let e, i, t, r, a, n = l[0] && Ne();
    return {
        c() {
            n && n.c(), e = M(), i = S("video"), t = S("track"), this.h()
        },
        l(o) {
            n && n.l(o), e = O(o), i = I(o, "VIDEO", {
                disablepictureinpicture: !0,
                controlslist: !0,
                style: !0,
                class: !0
            });
            var s = N(i);
            t = I(s, "TRACK", {
                kind: !0
            }), s.forEach(g), this.h()
        },
        h() {
            _(t, "kind", "captions"), i.autoplay = !0, i.controls = !0, i.playsInline = !0, _(i, "disablepictureinpicture", ""), _(i, "controlslist", "nodownload nofullscreen"), _(i, "style", r = l[0] ? "display: none" : void 0), _(i, "class", "svelte-sbxwoq")
        },
        m(o, s) {
            n && n.m(o, s), p(o, e, s), p(o, i, s), V(i, t), l[3](i), a = !0
        },
        p(o, [s]) {
            o[0] ? n ? s & 1 && f(n, 1) : (n = Ne(), n.c(), f(n, 1), n.m(e.parentNode, e)) : n && (U(), m(n, 1, 1, () => {
                n = null
            }), A()), (!a || s & 1 && r !== (r = o[0] ? "display: none" : void 0)) && _(i, "style", r)
        },
        i(o) {
            a || (f(n), a = !0)
        },
        o(o) {
            m(n), a = !1
        },
        d(o) {
            o && (g(e), g(i)), n && n.d(o), l[3](null)
        }
    }
}

function ti(l, e, i) {
    let {
        livestream: t
    } = e, r = !0, a, n = () => {
        t != null && t.url && (i(0, r = !1), a = window.dashjs.MediaPlayer().create(), a.initialize(o, t.url, !0))
    }, o;
    J(() => {
        const u = document.createElement("script");
        return u.src = "https://cdn.dashjs.org/v4.7.4/dash.all.min.js", u.onload = n, document.head.appendChild(u), () => {
            a && a.reset()
        }
    });

    function s(u) {
        ie[u ? "unshift" : "push"](() => {
            o = u, i(1, o)
        })
    }
    return l.$$set = u => {
        "livestream" in u && i(2, t = u.livestream)
    }, [r, o, t, s]
}
class ii extends T {
    constructor(e) {
        super(), F(this, e, ti, ei, E, {
            livestream: 2
        })
    }
}

function Ee(l) {
    let e, i;
    return e = new x({}), {
        c() {
            k(e.$$.fragment)
        },
        l(t) {
            w(e.$$.fragment, t)
        },
        m(t, r) {
            $(e, t, r), i = !0
        },
        i(t) {
            i || (f(e.$$.fragment, t), i = !0)
        },
        o(t) {
            m(e.$$.fragment, t), i = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function ri(l) {
    let e, i, t, r = l[0] && Ee();
    return {
        c() {
            r && r.c(), e = M(), i = S("div"), this.h()
        },
        l(a) {
            r && r.l(a), e = O(a), i = I(a, "DIV", {
                id: !0,
                class: !0
            }), N(i).forEach(g), this.h()
        },
        h() {
            _(i, "id", ze), _(i, "class", "ctainer svelte-z5euol")
        },
        m(a, n) {
            r && r.m(a, n), p(a, e, n), p(a, i, n), t = !0
        },
        p(a, [n]) {
            a[0] ? r ? n & 1 && f(r, 1) : (r = Ee(), r.c(), f(r, 1), r.m(e.parentNode, e)) : r && (U(), m(r, 1, 1, () => {
                r = null
            }), A())
        },
        i(a) {
            t || (f(r), t = !0)
        },
        o(a) {
            m(r), t = !1
        },
        d(a) {
            a && (g(e), g(i)), r && r.d(a)
        }
    }
}
const ze = "geniusLive";

function ni(l, e, i) {
    let {
        livestream: t
    } = e, r = !0;
    const a = t == null ? void 0 : t.data,
        n = s => {
            var u, c, d, v;
            ((u = s == null ? void 0 : s.detail) == null ? void 0 : u.type) === "player_ready" && ((v = (d = (c = window.GeniusLivePlayer) == null ? void 0 : c.player) == null ? void 0 : d.start) == null || v.call(d, a))
        },
        o = `https://genius-live-player-production.betstream.betgenius.com/widgetLoader?customerId=${a==null?void 0:a.customerId}&fixtureId=${a==null?void 0:a.fixtureId}&containerId=${ze}&width=824px&height=464px&controlsEnabled=true&audioEnabled=true&allowFullScreen=true&bufferLength=2&autoplayEnabled=false`;
    return J(() => {
        typeof window.GeniusLivePlayer < "u" && (window.removeEventListener("geniussportsmessagebus", n), window.GeniusLivePlayer.player.close());
        const s = document.createElement("script");
        s.setAttribute("src", o), s.onload = () => {
            i(0, r = !1)
        }, document.body.appendChild(s), window.addEventListener("geniussportsmessagebus", n)
    }), l.$$set = s => {
        "livestream" in s && i(1, t = s.livestream)
    }, [r, t]
}
class ai extends T {
    constructor(e) {
        super(), F(this, e, ni, ri, E, {
            livestream: 1
        })
    }
}

function Te(l) {
    let e, i;
    return e = new x({}), {
        c() {
            k(e.$$.fragment)
        },
        l(t) {
            w(e.$$.fragment, t)
        },
        m(t, r) {
            $(e, t, r), i = !0
        },
        i(t) {
            i || (f(e.$$.fragment, t), i = !0)
        },
        o(t) {
            m(e.$$.fragment, t), i = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function li(l) {
    let e, i, t, r, a, n = !l[0] && Te();
    return {
        c() {
            n && n.c(), e = M(), i = S("video"), t = S("track"), this.h()
        },
        l(o) {
            n && n.l(o), e = O(o), i = I(o, "VIDEO", {
                src: !0,
                disablepictureinpicture: !0,
                controlslist: !0,
                class: !0
            });
            var s = N(i);
            t = I(s, "TRACK", {
                kind: !0
            }), s.forEach(g), this.h()
        },
        h() {
            _(t, "kind", "captions"), i.autoplay = !0, i.controls = !0, i.playsInline = !0, G(i.src, r = l[0]) || _(i, "src", r), _(i, "disablepictureinpicture", ""), _(i, "controlslist", "nodownload nofullscreen"), _(i, "class", "svelte-sbxwoq")
        },
        m(o, s) {
            n && n.m(o, s), p(o, e, s), p(o, i, s), V(i, t), a = !0
        },
        p(o, [s]) {
            o[0] ? n && (U(), m(n, 1, 1, () => {
                n = null
            }), A()) : n ? s & 1 && f(n, 1) : (n = Te(), n.c(), f(n, 1), n.m(e.parentNode, e)), (!a || s & 1 && !G(i.src, r = o[0])) && _(i, "src", r)
        },
        i(o) {
            a || (f(n), a = !0)
        },
        o(o) {
            m(n), a = !1
        },
        d(o) {
            o && (g(e), g(i)), n && n.d(o)
        }
    }
}

function si(l, e, i) {
    let {
        streamUrl: t
    } = e;
    return l.$$set = r => {
        "streamUrl" in r && i(0, t = r.streamUrl)
    }, [t]
}
class oi extends T {
    constructor(e) {
        super(), F(this, e, si, li, E, {
            streamUrl: 0
        })
    }
}

function Fe(l) {
    let e, i, t, r;
    const a = [fi, di, ci, ui],
        n = [];

    function o(s, u) {
        return s[0].livestreamType === "genius" ? 0 : s[0].streamType === K.dash ? 1 : Kt ? 2 : 3
    }
    return e = o(l), i = n[e] = a[e](l), {
        c() {
            i.c(), t = L()
        },
        l(s) {
            i.l(s), t = L()
        },
        m(s, u) {
            n[e].m(s, u), p(s, t, u), r = !0
        },
        p(s, u) {
            let c = e;
            e = o(s), e === c ? n[e].p(s, u) : (U(), m(n[c], 1, 1, () => {
                n[c] = null
            }), A(), i = n[e], i ? i.p(s, u) : (i = n[e] = a[e](s), i.c()), f(i, 1), i.m(t.parentNode, t))
        },
        i(s) {
            r || (f(i), r = !0)
        },
        o(s) {
            m(i), r = !1
        },
        d(s) {
            s && g(t), n[e].d(s)
        }
    }
}

function ui(l) {
    let e, i;
    return e = new Zt({
        props: {
            streamUrl: l[0].url ? ? ""
        }
    }), {
        c() {
            k(e.$$.fragment)
        },
        l(t) {
            w(e.$$.fragment, t)
        },
        m(t, r) {
            $(e, t, r), i = !0
        },
        p(t, r) {
            const a = {};
            r & 1 && (a.streamUrl = t[0].url ? ? ""), e.$set(a)
        },
        i(t) {
            i || (f(e.$$.fragment, t), i = !0)
        },
        o(t) {
            m(e.$$.fragment, t), i = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function ci(l) {
    let e, i;
    return e = new oi({
        props: {
            streamUrl: l[0].url ? ? ""
        }
    }), {
        c() {
            k(e.$$.fragment)
        },
        l(t) {
            w(e.$$.fragment, t)
        },
        m(t, r) {
            $(e, t, r), i = !0
        },
        p(t, r) {
            const a = {};
            r & 1 && (a.streamUrl = t[0].url ? ? ""), e.$set(a)
        },
        i(t) {
            i || (f(e.$$.fragment, t), i = !0)
        },
        o(t) {
            m(e.$$.fragment, t), i = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function di(l) {
    let e, i;
    return e = new ii({
        props: {
            livestream: l[0]
        }
    }), {
        c() {
            k(e.$$.fragment)
        },
        l(t) {
            w(e.$$.fragment, t)
        },
        m(t, r) {
            $(e, t, r), i = !0
        },
        p(t, r) {
            const a = {};
            r & 1 && (a.livestream = t[0]), e.$set(a)
        },
        i(t) {
            i || (f(e.$$.fragment, t), i = !0)
        },
        o(t) {
            m(e.$$.fragment, t), i = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function fi(l) {
    var a, n;
    let e = (n = (a = l[0]) == null ? void 0 : a.data) == null ? void 0 : n.fixtureId,
        i, t, r = De(l);
    return {
        c() {
            r.c(), i = L()
        },
        l(o) {
            r.l(o), i = L()
        },
        m(o, s) {
            r.m(o, s), p(o, i, s), t = !0
        },
        p(o, s) {
            var u, c;
            s & 1 && E(e, e = (c = (u = o[0]) == null ? void 0 : u.data) == null ? void 0 : c.fixtureId) ? (U(), m(r, 1, 1, R), A(), r = De(o), r.c(), f(r, 1), r.m(i.parentNode, i)) : r.p(o, s)
        },
        i(o) {
            t || (f(r), t = !0)
        },
        o(o) {
            m(r), t = !1
        },
        d(o) {
            o && g(i), r.d(o)
        }
    }
}

function De(l) {
    let e, i;
    return e = new ai({
        props: {
            livestream: l[0]
        }
    }), {
        c() {
            k(e.$$.fragment)
        },
        l(t) {
            w(e.$$.fragment, t)
        },
        m(t, r) {
            $(e, t, r), i = !0
        },
        p(t, r) {
            const a = {};
            r & 1 && (a.livestream = t[0]), e.$set(a)
        },
        i(t) {
            i || (f(e.$$.fragment, t), i = !0)
        },
        o(t) {
            m(e.$$.fragment, t), i = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function mi(l) {
    let e, i, t = l[0] && Fe(l);
    return {
        c() {
            t && t.c(), e = L()
        },
        l(r) {
            t && t.l(r), e = L()
        },
        m(r, a) {
            t && t.m(r, a), p(r, e, a), i = !0
        },
        p(r, [a]) {
            r[0] ? t ? (t.p(r, a), a & 1 && f(t, 1)) : (t = Fe(r), t.c(), f(t, 1), t.m(e.parentNode, e)) : t && (U(), m(t, 1, 1, () => {
                t = null
            }), A())
        },
        i(r) {
            i || (f(t), i = !0)
        },
        o(r) {
            m(t), i = !1
        },
        d(r) {
            r && g(e), t && t.d(r)
        }
    }
}

function gi(l, e, i) {
    let {
        livestream: t
    } = e;
    return l.$$set = r => {
        "livestream" in r && i(0, t = r.livestream)
    }, [t]
}
class _i extends T {
    constructor(e) {
        super(), F(this, e, gi, mi, E, {
            livestream: 0
        })
    }
}

function pi(l) {
    let e, i, t;
    var r = l[0];

    function a(n, o) {
        return {
            props: {
                livestream: n[1]
            }
        }
    }
    return r && (e = Z(r, a(l))), {
        c() {
            e && k(e.$$.fragment), i = L()
        },
        l(n) {
            e && w(e.$$.fragment, n), i = L()
        },
        m(n, o) {
            e && $(e, n, o), p(n, i, o), t = !0
        },
        p(n, [o]) {
            if (o & 1 && r !== (r = n[0])) {
                if (e) {
                    U();
                    const s = e;
                    m(s.$$.fragment, 1, 0, () => {
                        b(s, 1)
                    }), A()
                }
                r ? (e = Z(r, a(n)), k(e.$$.fragment), f(e.$$.fragment, 1), $(e, i.parentNode, i)) : e = null
            } else if (r) {
                const s = {};
                o & 2 && (s.livestream = n[1]), e.$set(s)
            }
        },
        i(n) {
            t || (e && f(e.$$.fragment, n), t = !0)
        },
        o(n) {
            e && m(e.$$.fragment, n), t = !1
        },
        d(n) {
            n && g(i), e && b(e, n)
        }
    }
}

function hi(l, e, i) {
    let t;
    W(l, Be, d => i(3, t = d));
    let {
        livestreamFixture: r
    } = e;
    const a = {
        loading: x,
        notStarted: Dt,
        regionBlocked: Ut,
        unexpectedError: Mt,
        playing: _i,
        finished: Tt,
        unauthenticated: Me
    };
    let n = a[C.loading],
        o, s = C.loading;
    const u = (d, v, y) => {
            if (!d) return C.loading;
            if (!y) return C.unauthenticated;
            const {
                url: h,
                startTime: z,
                endTime: j,
                data: B
            } = d, {
                imgArenaStream: D,
                betradarStream: ee,
                geniussportsStream: te
            } = v || {};
            if (!h && B && (B != null && B.error)) return C.regionBlocked;
            if (z && new Date(z).getTime() > Date.now()) return C.notStarted;
            if (j && new Date(j).getTime() < Date.now()) return C.finished;
            const je = Re(r);
            return !h && je === X.genius && !B ? (D == null ? void 0 : D.isAvailable) || (ee == null ? void 0 : ee.isAvailable) || (te == null ? void 0 : te.isAvailable) ? C.notStarted : C.regionBlocked : C.playing
        },
        c = async (d, v) => {
            d && (i(1, o = await Jt(d, v)), o != null && o.streamError ? s = C[o.streamError] : s = u(o, d, v), i(0, n = a[s]))
        };
    return l.$$set = d => {
        "livestreamFixture" in d && i(2, r = d.livestreamFixture)
    }, l.$$.update = () => {
        l.$$.dirty & 12 && c(r, t.isAuthenticated)
    }, [n, o, r, t]
}
class vi extends T {
    constructor(e) {
        super(), F(this, e, hi, pi, E, {
            livestreamFixture: 2
        })
    }
}

function ki(l) {
    let e, i;
    return e = new vi({
        props: {
            livestreamFixture: l[1]
        }
    }), {
        c() {
            k(e.$$.fragment)
        },
        l(t) {
            w(e.$$.fragment, t)
        },
        m(t, r) {
            $(e, t, r), i = !0
        },
        p(t, r) {
            const a = {};
            r & 2 && (a.livestreamFixture = t[1]), e.$set(a)
        },
        i(t) {
            i || (f(e.$$.fragment, t), i = !0)
        },
        o(t) {
            m(e.$$.fragment, t), i = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function $i(l) {
    let e, i;
    return e = new Wt({
        props: {
            liveStreamUrl: l[2]
        }
    }), {
        c() {
            k(e.$$.fragment)
        },
        l(t) {
            w(e.$$.fragment, t)
        },
        m(t, r) {
            $(e, t, r), i = !0
        },
        p(t, r) {
            const a = {};
            r & 4 && (a.liveStreamUrl = t[2]), e.$set(a)
        },
        i(t) {
            i || (f(e.$$.fragment, t), i = !0)
        },
        o(t) {
            m(e.$$.fragment, t), i = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function bi(l) {
    let e, i, t, r;
    const a = [$i, ki],
        n = [];

    function o(s, u) {
        return s[0] && s[2] ? 0 : 1
    }
    return e = o(l), i = n[e] = a[e](l), {
        c() {
            i.c(), t = L()
        },
        l(s) {
            i.l(s), t = L()
        },
        m(s, u) {
            n[e].m(s, u), p(s, t, u), r = !0
        },
        p(s, [u]) {
            let c = e;
            e = o(s), e === c ? n[e].p(s, u) : (U(), m(n[c], 1, 1, () => {
                n[c] = null
            }), A(), i = n[e], i ? i.p(s, u) : (i = n[e] = a[e](s), i.c()), f(i, 1), i.m(t.parentNode, t))
        },
        i(s) {
            r || (f(i), r = !0)
        },
        o(s) {
            m(i), r = !1
        },
        d(s) {
            s && g(t), n[e].d(s)
        }
    }
}

function wi(l, e, i) {
    let t, r, a, {
            fixture: n
        } = e,
        o;
    const s = async u => {
        var d;
        const c = await Xe({
            load: {
                fetch
            },
            doc: yt,
            variables: {
                fixtureId: u,
                deliveryType: xt()
            }
        });
        c != null && c.sportFixture && (i(1, o = c.sportFixture), (d = window == null ? void 0 : window.dataLayer) == null || d.push({
            event: "stream_initiated",
            sport: n.tournament.category.sport.slug,
            category: n.tournament.category.slug,
            tournament: n.tournament.slug,
            fixture: n.slug
        }))
    };
    return l.$$set = u => {
        "fixture" in u && i(3, n = u.fixture)
    }, l.$$.update = () => {
        l.$$.dirty & 8 && i(2, t = Ze(n)), l.$$.dirty & 8 && i(4, r = n.id), l.$$.dirty & 8 && i(0, a = et(n.data)), l.$$.dirty & 17 && !a && Ke && s(r)
    }, [a, o, t, n, r]
}
class qi extends T {
    constructor(e) {
        super(), F(this, e, wi, bi, E, {
            fixture: 3
        })
    }
}
export {
    oi as D, zi as F, Zt as H, Kt as I, qi as L, Ut as R, Me as U
};