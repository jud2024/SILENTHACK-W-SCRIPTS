import {
    s as S,
    m as f,
    j as c,
    i as m,
    t as k,
    O as w,
    h as y,
    P as T,
    l as E,
    e as U,
    d as L,
    S as N,
    F as R,
    G as P
} from "./scheduler.DXu26z7T.js";
import {
    S as A,
    i as O,
    t as u,
    g as j,
    b as _,
    e as F,
    c as I,
    a as M,
    m as q,
    d as B
} from "./index.Dz_MmNB3.js";
import {
    T as G
} from "./index.D7nbRHfU.js";
import {
    a9 as H
} from "./index.B4-7gKq3.js";

function b(s) {
    let n, r;
    return n = new G({
        props: {
            variant: "highlighted",
            $$slots: {
                default: [$]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            I(n.$$.fragment)
        },
        l(t) {
            M(n.$$.fragment, t)
        },
        m(t, e) {
            q(n, t, e), r = !0
        },
        p(t, e) {
            const a = {};
            e & 69 && (a.$$scope = {
                dirty: e,
                ctx: t
            }), n.$set(a)
        },
        i(t) {
            r || (u(n.$$.fragment, t), r = !0)
        },
        o(t) {
            _(n.$$.fragment, t), r = !1
        },
        d(t) {
            B(n, t)
        }
    }
}

function d(s) {
    let n, r = "'";
    return {
        c() {
            n = U("span"), n.textContent = r, this.h()
        },
        l(t) {
            n = L(t, "SPAN", {
                class: !0,
                "data-svelte-h": !0
            }), N(n) !== "svelte-ymqxoj" && (n.textContent = r), this.h()
        },
        h() {
            R(n, "class", "blinking-dash svelte-15uh0ch")
        },
        m(t, e) {
            c(t, n, e)
        },
        d(t) {
            t && m(n)
        }
    }
}

function $(s) {
    let n, r, t, e = s[0] !== "nba2k" && d();
    return {
        c() {
            n = k(s[2]), r = w(), e && e.c(), t = f()
        },
        l(a) {
            n = y(a, s[2]), r = T(a), e && e.l(a), t = f()
        },
        m(a, o) {
            c(a, n, o), c(a, r, o), e && e.m(a, o), c(a, t, o)
        },
        p(a, o) {
            o & 4 && E(n, a[2]), a[0] !== "nba2k" ? e || (e = d(), e.c(), e.m(t.parentNode, t)) : e && (e.d(1), e = null)
        },
        d(a) {
            a && (m(n), m(r), m(t)), e && e.d(a)
        }
    }
}

function K(s) {
    let n, r, t = s[1] && b(s);
    return {
        c() {
            t && t.c(), n = f()
        },
        l(e) {
            t && t.l(e), n = f()
        },
        m(e, a) {
            t && t.m(e, a), c(e, n, a), r = !0
        },
        p(e, [a]) {
            e[1] ? t ? (t.p(e, a), a & 2 && u(t, 1)) : (t = b(e), t.c(), u(t, 1), t.m(n.parentNode, n)) : t && (j(), _(t, 1, 1, () => {
                t = null
            }), F())
        },
        i(e) {
            r || (u(t), r = !0)
        },
        o(e) {
            _(t), r = !1
        },
        d(e) {
            e && m(n), t && t.d(e)
        }
    }
}

function W(s, n, r) {
    let t, {
            sport: e
        } = n,
        {
            clock: a
        } = n;
    const o = ["nba2k"],
        i = ["american-football", "ice-hockey", "baseball", "basketball", "nba2k"];
    let p;
    return s.$$set = l => {
        "sport" in l && r(0, e = l.sport), "clock" in l && r(3, a = l.clock)
    }, s.$$.update = () => {
        if (s.$$.dirty & 9 && r(1, t = i.includes(e) ? a == null ? void 0 : a.remainingTime : a == null ? void 0 : a.matchTime), s.$$.dirty & 3)
            if (o.includes(e)) {
                const l = Math.floor(Number(t) / 60),
                    h = (Number(t) % 60).toString().padStart(2, "0");
                e === "nba2k" ? r(2, p = `${l}:${h}`) : r(2, p = l)
            } else r(2, p = t == null ? void 0 : t.toString().split(":")[0])
    }, [e, t, p, a]
}
class X extends A {
    constructor(n) {
        super(), O(this, n, W, K, S, {
            sport: 0,
            clock: 3
        })
    }
}
var Y = (s => (s.esport = "esports", s.imgarena = "imgarena", s.genius = "genius", s.betradar = "betradar", s))(Y || {});
const g = s => s && "tvChannels" in s ? (s == null ? void 0 : s.tvChannels) ? ? [] : [],
    v = s => g(s).length,
    Z = s => {
        const n = P(H),
            r = g(s.data),
            e = (r == null ? void 0 : r.find(i => (i == null ? void 0 : i.language) === n)) ? ? (r == null ? void 0 : r.find(i => (i == null ? void 0 : i.language) === "en")),
            a = e == null ? void 0 : e.streamUrl,
            o = e == null ? void 0 : e.name;
        return a ? o === "Twitch" ? "https://player.twitch.tv?channel=" + new URL(a).pathname.replace(/^\/+/, "") + "&parent=" + window.location.host : o === "Youtube" ? "https://www.youtube.com/embed/" + new URLSearchParams(a).get("v") : o === "Bilibili" ? "https://player.twitch.tv?channel=" + new URL(a).pathname.replace(/^\/+/, "") + "&parent=" + window.location.host : o === "Huya" || o === "Gjirafa" ? a : null : null
    },
    z = s => {
        var a, o, i;
        const n = (a = s == null ? void 0 : s.imgArenaStream) == null ? void 0 : a.exists,
            r = (o = s == null ? void 0 : s.geniussportsStream) == null ? void 0 : o.exists,
            t = (i = s == null ? void 0 : s.betradarStream) == null ? void 0 : i.exists;
        return v(s == null ? void 0 : s.data) ? "esports" : n ? "imgarena" : r ? "genius" : t ? "betradar" : null
    },
    C = s => {
        var e, a;
        const n = (a = (e = g(s == null ? void 0 : s.data)) == null ? void 0 : e[0]) == null ? void 0 : a.streamUrl,
            r = typeof n == "string" ? n : null,
            t = z(s);
        return {
            twitchUrl: r,
            type: t,
            streamExists: t !== null,
            esportStreamExists: t === "esports"
        }
    };
export {
    X as F, Y as L, z as a, Z as b, v as c, C as g
};