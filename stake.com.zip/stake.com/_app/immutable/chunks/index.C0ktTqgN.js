import {
    s as r,
    a as u,
    e as f,
    d as _,
    f as c,
    i,
    F as d,
    j as m,
    u as p,
    g as h,
    b as $
} from "./scheduler.DXu26z7T.js";
import {
    S as v,
    i as b,
    t as g,
    b as w
} from "./index.Dz_MmNB3.js";
import {
    d as B
} from "./index.B81orGJm.js";

function C(n) {
    let e, a;
    const o = n[1].default,
        s = u(o, n, n[0], null);
    return {
        c() {
            e = f("div"), s && s.c(), this.h()
        },
        l(t) {
            e = _(t, "DIV", {
                class: !0
            });
            var l = c(e);
            s && s.l(l), l.forEach(i), this.h()
        },
        h() {
            d(e, "class", "buttons " + B + " svelte-1ttsl9w")
        },
        m(t, l) {
            m(t, e, l), s && s.m(e, null), a = !0
        },
        p(t, [l]) {
            s && s.p && (!a || l & 1) && p(s, o, t, t[0], a ? $(o, t[0], l, null) : h(t[0]), null)
        },
        i(t) {
            a || (g(s, t), a = !0)
        },
        o(t) {
            w(s, t), a = !1
        },
        d(t) {
            t && i(e), s && s.d(t)
        }
    }
}

function D(n, e, a) {
    let {
        $$slots: o = {},
        $$scope: s
    } = e;
    return n.$$set = t => {
        "$$scope" in t && a(0, s = t.$$scope)
    }, [s, o]
}
class S extends v {
    constructor(e) {
        super(), b(this, e, D, C, r, {})
    }
}
export {
    S as B
};