import {
    w as e
} from "./index.C2-CG2CN.js";
import {
    C as o
} from "./CurrentAnnouncements.generated.Cniolakq.js";
import {
    l as r,
    f as c
} from "./index.B4-7gKq3.js";
const f = r("@closedAnnouncements", []),
    i = { ...e([]),
        fetch: async t => {
            try {
                const n = await c({
                    doc: o,
                    variables: {},
                    load: t
                });
                return (n == null ? void 0 : n.currentAnnouncements) || []
            } catch {
                return null
            }
        }
    };
export {
    i as a, f as c
};