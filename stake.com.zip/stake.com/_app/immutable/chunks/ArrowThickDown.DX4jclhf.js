import {
    s as m,
    C as f,
    H as h,
    D as u,
    f as v,
    E as _,
    i as c,
    F as r,
    j as g,
    n as o
} from "./scheduler.DXu26z7T.js";
import {
    S as H,
    i as y
} from "./index.Dz_MmNB3.js";

function w(n) {
    let t, l, a = ` <title>${n[1]||""}</title> <path d="m0 31.199 32 32 32-32H47.78V.8H16.234v30.398H0Z"></path>`,
        i;
    return {
        c() {
            t = f("svg"), l = new h(!0), this.h()
        },
        l(s) {
            t = u(s, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var e = v(t);
            l = _(e, !0), e.forEach(c), this.h()
        },
        h() {
            l.a = null, r(t, "fill", "currentColor"), r(t, "viewBox", "0 0 64 64"), r(t, "class", i = "svg-icon " + n[2]), r(t, "style", n[0])
        },
        m(s, e) {
            g(s, t, e), l.m(a, t)
        },
        p(s, [e]) {
            e & 2 && a !== (a = ` <title>${s[1]||""}</title> <path d="m0 31.199 32 32 32-32H47.78V.8H16.234v30.398H0Z"></path>`) && l.p(a), e & 4 && i !== (i = "svg-icon " + s[2]) && r(t, "class", i), e & 1 && r(t, "style", s[0])
        },
        i: o,
        o,
        d(s) {
            s && c(t)
        }
    }
}

function d(n, t, l) {
    let {
        style: a = ""
    } = t, {
        alt: i = ""
    } = t, {
        class: s = ""
    } = t;
    return n.$$set = e => {
        "style" in e && l(0, a = e.style), "alt" in e && l(1, i = e.alt), "class" in e && l(2, s = e.class)
    }, [a, i, s]
}
class B extends H {
    constructor(t) {
        super(), y(this, t, d, w, m, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    B as A
};