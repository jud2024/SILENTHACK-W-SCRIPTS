import {
    s as $,
    m as f,
    j as b,
    n as w,
    i as k,
    c as A,
    w as H,
    t as K,
    h as P,
    l as Y
} from "./scheduler.DXu26z7T.js";
import {
    S as M,
    i as R,
    t as g,
    b as T,
    c as E,
    a as N,
    m as O,
    d as U
} from "./index.Dz_MmNB3.js";
import {
    a9 as z,
    _ as I,
    ar as B,
    T as G,
    ai as J,
    an as L,
    as as D
} from "./index.B4-7gKq3.js";
import {
    F as Q
} from "./index.Drh4nwD9.js";

function F(r) {
    let n = r[2].format(r[1], r[0]) + "",
        t;
    return {
        c() {
            t = K(n)
        },
        l(e) {
            t = P(e, n)
        },
        m(e, a) {
            b(e, t, a)
        },
        p(e, a) {
            a & 7 && n !== (n = e[2].format(e[1], e[0]) + "") && Y(t, n)
        },
        d(e) {
            e && k(t)
        }
    }
}

function X(r) {
    let n, t = r[1] && F(r);
    return {
        c() {
            t && t.c(), n = f()
        },
        l(e) {
            t && t.l(e), n = f()
        },
        m(e, a) {
            t && t.m(e, a), b(e, n, a)
        },
        p(e, [a]) {
            e[1] ? t ? t.p(e, a) : (t = F(e), t.c(), t.m(n.parentNode, n)) : t && (t.d(1), t = null)
        },
        i: w,
        o: w,
        d(e) {
            e && k(n), t && t.d(e)
        }
    }
}

function Z(r, n, t) {
    let e, a, i, c, u;
    A(r, z, l => t(6, u = l));
    let {
        value: o
    } = n;
    const s = {
        seconds: B,
        minutes: G,
        hours: J,
        day: L,
        week: D
    };

    function V(l) {
        var h;
        const d = ["week", D * 8],
            p = I.toPairs(s).map(y => y[0] === "week" ? d : y),
            v = I.last(p);
        return ((h = p.find((y, j) => {
            const [, q] = p[j + 1] || v;
            return Number(q) > l
        })) == null ? void 0 : h[0]) || v && v[0]
    }

    function S(l, d) {
        return Math.ceil(d / s[l])
    }
    let C = new Date(o).getTime(),
        m = new Date().getTime(),
        _;

    function W(l) {
        clearInterval(_), _ = setInterval(() => {
            t(4, m = new Date().getTime())
        }, s[l])
    }
    return H(() => {
        clearInterval(_)
    }), r.$$set = l => {
        "value" in l && t(3, o = l.value)
    }, r.$$.update = () => {
        r.$$.dirty & 64 && t(2, e = new Intl.RelativeTimeFormat(u, {
            style: "long"
        })), r.$$.dirty & 16 && t(5, a = C - m), r.$$.dirty & 32 && t(0, i = V(Math.abs(a))), r.$$.dirty & 33 && t(1, c = S(i, a)), r.$$.dirty & 1 && W(i)
    }, [i, c, e, o, m, a, u]
}
class x extends M {
    constructor(n) {
        super(), R(this, n, Z, X, $, {
            value: 3
        })
    }
}

function ee(r) {
    let n, t;
    return n = new Q({
        props: {
            value: r[0]
        }
    }), {
        c() {
            E(n.$$.fragment)
        },
        l(e) {
            N(n.$$.fragment, e)
        },
        m(e, a) {
            O(n, e, a), t = !0
        },
        p(e, a) {
            const i = {};
            a & 1 && (i.value = e[0]), n.$set(i)
        },
        i(e) {
            t || (g(n.$$.fragment, e), t = !0)
        },
        o(e) {
            T(n.$$.fragment, e), t = !1
        },
        d(e) {
            U(n, e)
        }
    }
}

function te(r) {
    let n, t;
    return n = new x({
        props: {
            value: r[0]
        }
    }), {
        c() {
            E(n.$$.fragment)
        },
        l(e) {
            N(n.$$.fragment, e)
        },
        m(e, a) {
            O(n, e, a), t = !0
        },
        p(e, a) {
            const i = {};
            a & 1 && (i.value = e[0]), n.$set(i)
        },
        i(e) {
            t || (g(n.$$.fragment, e), t = !0)
        },
        o(e) {
            T(n.$$.fragment, e), t = !1
        },
        d(e) {
            U(n, e)
        }
    }
}

function ne(r) {
    let n, t, e, a;
    const i = [te, ee],
        c = [];

    function u(o, s) {
        return o[1] ? 0 : 1
    }
    return n = u(r), t = c[n] = i[n](r), {
        c() {
            t.c(), e = f()
        },
        l(o) {
            t.l(o), e = f()
        },
        m(o, s) {
            c[n].m(o, s), b(o, e, s), a = !0
        },
        p(o, [s]) {
            t.p(o, s)
        },
        i(o) {
            a || (g(t), a = !0)
        },
        o(o) {
            T(t), a = !1
        },
        d(o) {
            o && k(e), c[n].d(o)
        }
    }
}

function ae(r, n, t) {
    let {
        value: e
    } = n, a = typeof Intl < "u" && typeof Intl.RelativeTimeFormat < "u";
    return r.$$set = i => {
        "value" in i && t(0, e = i.value)
    }, [e, a]
}
class ce extends M {
    constructor(n) {
        super(), R(this, n, ae, ne, $, {
            value: 0
        })
    }
}
export {
    ce as F
};