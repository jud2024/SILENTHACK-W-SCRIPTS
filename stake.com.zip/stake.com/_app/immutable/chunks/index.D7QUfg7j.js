import {
    s as r,
    a as u,
    e as f,
    d as c,
    f as _,
    i as o,
    F as m,
    j as d,
    u as p,
    g as h,
    b as $
} from "./scheduler.DXu26z7T.js";
import {
    S as g,
    i as v,
    t as b,
    b as I
} from "./index.Dz_MmNB3.js";

function F(i) {
    let t, a;
    const n = i[1].default,
        e = u(n, i, i[0], null);
    return {
        c() {
            t = f("div"), e && e.c(), this.h()
        },
        l(s) {
            t = c(s, "DIV", {
                class: !0
            });
            var l = _(t);
            e && e.l(l), l.forEach(o), this.h()
        },
        h() {
            m(t, "class", "image-focus svelte-1bax0ph")
        },
        m(s, l) {
            d(s, t, l), e && e.m(t, null), a = !0
        },
        p(s, [l]) {
            e && e.p && (!a || l & 1) && p(e, n, s, s[0], a ? $(n, s[0], l, null) : h(s[0]), null)
        },
        i(s) {
            a || (b(e, s), a = !0)
        },
        o(s) {
            I(e, s), a = !1
        },
        d(s) {
            s && o(t), e && e.d(s)
        }
    }
}

function S(i, t, a) {
    let {
        $$slots: n = {},
        $$scope: e
    } = t;
    return i.$$set = s => {
        "$$scope" in s && a(0, e = s.$$scope)
    }, [e, n]
}
class y extends g {
    constructor(t) {
        super(), v(this, t, S, F, r, {})
    }
}
export {
    y as I
};