import {
    i as v
} from "./innerFrom.BRHulYBS.js";
import {
    o as l,
    c as a
} from "./dateTimestampProvider.DBRuHdww.js";

function b(f, e) {
    return l(function(p, r) {
        var n = null,
            s = 0,
            o = !1,
            t = function() {
                return o && !n && r.complete()
            };
        p.subscribe(a(r, function(i) {
            n == null || n.unsubscribe();
            var m = 0,
                u = s++;
            v(f(i, u)).subscribe(n = a(r, function(c) {
                return r.next(e ? e(i, c, u, m++) : c)
            }, function() {
                n = null, t()
            }))
        }, function() {
            o = !0, t()
        }))
    })
}
export {
    b as s
};