import {
    s as c,
    C as o,
    H as m,
    D as u,
    f,
    E as _,
    i as r,
    F as n,
    j as d,
    n as v
} from "./scheduler.DXu26z7T.js";
import {
    S as g,
    i as Z
} from "./index.Dz_MmNB3.js";

function y(i) {
    let l, s, a = ` <title>${i[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M9.095 0h7v38h9l-12.5 26-12.5-26h9V0Zm35.25 23.31h9.5l1 3.09h9.06L54.095 0h-10l-9.76 26.4h9.06l.95-3.09Zm4.75-15.47 2.61 8.5h-5.22l2.61-8.5Zm10.17 36.06v-6.3h-20.62v6.97h10.05l-10.05 13.1V64h20.9v-6.97h-10.37l10.09-13.13Z"></path>`,
        h;
    return {
        c() {
            l = o("svg"), s = new m(!0), this.h()
        },
        l(t) {
            l = u(t, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var e = f(l);
            s = _(e, !0), e.forEach(r), this.h()
        },
        h() {
            s.a = null, n(l, "fill", "currentColor"), n(l, "viewBox", "0 0 64 64"), n(l, "class", h = "svg-icon " + i[2]), n(l, "style", i[0])
        },
        m(t, e) {
            d(t, l, e), s.m(a, l)
        },
        p(t, [e]) {
            e & 2 && a !== (a = ` <title>${t[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M9.095 0h7v38h9l-12.5 26-12.5-26h9V0Zm35.25 23.31h9.5l1 3.09h9.06L54.095 0h-10l-9.76 26.4h9.06l.95-3.09Zm4.75-15.47 2.61 8.5h-5.22l2.61-8.5Zm10.17 36.06v-6.3h-20.62v6.97h10.05l-10.05 13.1V64h20.9v-6.97h-10.37l10.09-13.13Z"></path>`) && s.p(a), e & 4 && h !== (h = "svg-icon " + t[2]) && n(l, "class", h), e & 1 && n(l, "style", t[0])
        },
        i: v,
        o: v,
        d(t) {
            t && r(l)
        }
    }
}

function w(i, l, s) {
    let {
        style: a = ""
    } = l, {
        alt: h = ""
    } = l, {
        class: t = ""
    } = l;
    return i.$$set = e => {
        "style" in e && s(0, a = e.style), "alt" in e && s(1, h = e.alt), "class" in e && s(2, t = e.class)
    }, [a, h, t]
}
class C extends g {
    constructor(l) {
        super(), Z(this, l, w, y, c, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    C as S
};