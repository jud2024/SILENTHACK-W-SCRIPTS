import {
    L as h,
    F as u,
    g as m,
    i as s,
    a as g
} from "./variables.CIGccMR5.js";
import {
    r as p,
    d as i
} from "./index.C2-CG2CN.js";
import {
    s as f
} from "./index.1CTKaDY2.js";
const c = () => ({
        width: window.innerWidth,
        height: window.innerHeight
    }),
    r = p(c(), e => {
        const t = () => e(c());
        return window.addEventListener("resize", t), () => {
            window.removeEventListener("resize", t)
        }
    }),
    d = () => window && "screen" in window && "orientation" in window.screen,
    w = () => window && "orientation" in window,
    L = () => d() ? window.screen.orientation.type : w() && (window.orientation === 90 || window.orientation === -90) ? "landscape-primary" : "portrait-primary",
    S = p(L(), e => {
        let t = () => {};
        const n = a => {
                if (!d() || !a.target || typeof a.target.type != "string") return;
                const l = a.target.type;
                e(l)
            },
            o = () => {
                w() && (window.orientation === 90 || window.orientation === -90 ? e("landscape-primary") : e("portrait-primary"))
            };
        return d() ? (window.screen.orientation.addEventListener("change", n), t = () => {
            window.screen.orientation.removeEventListener("change", n)
        }) : w() && (window.addEventListener("orientationchange", o), t = () => {
            window.removeEventListener("orientationchange", o)
        }), () => {
            t()
        }
    }),
    z = i(r, e => {
        const t = e.width < h;
        return e.width < u ? "fullsize" : t ? "small" : "normal"
    }),
    b = i(r, e => m(e.width));
i([b, f], ([e, t]) => e.name === "mobile" ? t === "hidden" : !0);
const F = i(r, e => s(e.width)),
    _ = i([S, r], ([e, t]) => (t.width < t.height ? s(t.width) : s(t.height) && !g(t.width)) && (e === "landscape-primary" || e === "landscape-secondary"));
export {
    F as a, z as l, _ as m, b as r, r as w
};