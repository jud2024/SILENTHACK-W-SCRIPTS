import {
    ah as A,
    z as f,
    ai as S
} from "./index.B4-7gKq3.js";
import {
    D as O
} from "./index.B81orGJm.js";
const T = "tdrhge4k",
    $ = O,
    d = "v2023-03-26",
    E = `https://${T}.apicdn.sanity.io/${d}/data/query/${$}`,
    j = ({
        query: c,
        params: l = {},
        options: p = {}
    }) => {
        const t = new URLSearchParams,
            {
                tag: n,
                ...e
            } = p;
        n && t.set("tag", n), t.set("query", c);
        for (const [o, s] of Object.entries(l)) t.set(`$${o}`, JSON.stringify(s));
        for (const [o, s] of Object.entries(e)) s && t.set(o, `${s}`);
        return `?${t.toString()}`
    },
    h = new Map;

function I(c) {
    const l = Array(c).join("");
    return async function(t, n) {
        let e = null;
        const s = new AbortController().signal;
        try {
            const u = await A(t),
                m = j({
                    query: l,
                    params: {
                        lang: u.locale ? ? "en",
                        ...n
                    }
                }),
                a = `${E}${m}`,
                g = Date.now();
            if (f && h.has(a)) {
                const y = h.get(a);
                if (y && y.invalidateAt > g) return y.result
            }
            const r = await t.fetch(a, {
                    method: "GET",
                    headers: {
                        "Access-Control-Allow-Origin": "*",
                        "Content-Type": "application/json",
                        "x-sanity-operation": "sanity"
                    },
                    signal: s
                }),
                i = await r.json();
            if ("error" in i) throw console.error("sanity: error", i), Error("sanity: error found in json");
            if (r.status !== 200) throw console.log("sanity: response status is ", r.status), Error("sanity: response status is " + r.status);
            if (!("result" in i)) throw console.log("sanity: response is empty", r.status), Error("sanity: no result json in");
            const w = i.result;
            return f && h.set(a, {
                result: w,
                invalidateAt: g + S
            }), w
        } catch (u) {
            return console.error(JSON.stringify({
                errorType: "sanity fetch error",
                error: u
            })), null
        } finally {
            e && clearTimeout(e)
        }
    }
}
export {
    I as c
};