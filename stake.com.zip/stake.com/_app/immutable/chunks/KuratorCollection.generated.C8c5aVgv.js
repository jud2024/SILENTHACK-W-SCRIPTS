const e = {
    kind: "Document",
    definitions: [{
        kind: "OperationDefinition",
        operation: "query",
        name: {
            kind: "Name",
            value: "KuratorCollection"
        },
        variableDefinitions: [{
            kind: "VariableDefinition",
            variable: {
                kind: "Variable",
                name: {
                    kind: "Name",
                    value: "type"
                }
            },
            type: {
                kind: "NonNullType",
                type: {
                    kind: "NamedType",
                    name: {
                        kind: "Name",
                        value: "GameKuratorCollectionEnum"
                    }
                }
            }
        }, {
            kind: "VariableDefinition",
            variable: {
                kind: "Variable",
                name: {
                    kind: "Name",
                    value: "offset"
                }
            },
            type: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "Int"
                }
            }
        }, {
            kind: "VariableDefinition",
            variable: {
                kind: "Variable",
                name: {
                    kind: "Name",
                    value: "limit"
                }
            },
            type: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "Int"
                }
            }
        }, {
            kind: "VariableDefinition",
            variable: {
                kind: "Variable",
                name: {
                    kind: "Name",
                    value: "showGames"
                }
            },
            type: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "Boolean"
                }
            },
            defaultValue: {
                kind: "BooleanValue",
                value: !1
            }
        }, {
            kind: "VariableDefinition",
            variable: {
                kind: "Variable",
                name: {
                    kind: "Name",
                    value: "isMobile"
                }
            },
            type: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "Boolean"
                }
            }
        }, {
            kind: "VariableDefinition",
            variable: {
                kind: "Variable",
                name: {
                    kind: "Name",
                    value: "isActivePlayersFeatureFlagOn"
                }
            },
            type: {
                kind: "NonNullType",
                type: {
                    kind: "NamedType",
                    name: {
                        kind: "Name",
                        value: "Boolean"
                    }
                }
            }
        }, {
            kind: "VariableDefinition",
            variable: {
                kind: "Variable",
                name: {
                    kind: "Name",
                    value: "language"
                }
            },
            type: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "LanguageEnum"
                }
            },
            defaultValue: {
                kind: "EnumValue",
                value: "en"
            }
        }],
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "kuratorCollection"
                },
                arguments: [{
                    kind: "Argument",
                    name: {
                        kind: "Name",
                        value: "type"
                    },
                    value: {
                        kind: "Variable",
                        name: {
                            kind: "Name",
                            value: "type"
                        }
                    }
                }],
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "id"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "group"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "id"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "translation"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "slug"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "icon"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "thumbnailUrl"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "gameCount"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "groupGamesList"
                                },
                                arguments: [{
                                    kind: "Argument",
                                    name: {
                                        kind: "Name",
                                        value: "offset"
                                    },
                                    value: {
                                        kind: "Variable",
                                        name: {
                                            kind: "Name",
                                            value: "offset"
                                        }
                                    }
                                }, {
                                    kind: "Argument",
                                    name: {
                                        kind: "Name",
                                        value: "limit"
                                    },
                                    value: {
                                        kind: "Variable",
                                        name: {
                                            kind: "Name",
                                            value: "limit"
                                        }
                                    }
                                }, {
                                    kind: "Argument",
                                    name: {
                                        kind: "Name",
                                        value: "isMobile"
                                    },
                                    value: {
                                        kind: "Variable",
                                        name: {
                                            kind: "Name",
                                            value: "isMobile"
                                        }
                                    }
                                }, {
                                    kind: "Argument",
                                    name: {
                                        kind: "Name",
                                        value: "language"
                                    },
                                    value: {
                                        kind: "Variable",
                                        name: {
                                            kind: "Name",
                                            value: "language"
                                        }
                                    }
                                }],
                                directives: [{
                                    kind: "Directive",
                                    name: {
                                        kind: "Name",
                                        value: "include"
                                    },
                                    arguments: [{
                                        kind: "Argument",
                                        name: {
                                            kind: "Name",
                                            value: "if"
                                        },
                                        value: {
                                            kind: "Variable",
                                            name: {
                                                kind: "Name",
                                                value: "showGames"
                                            }
                                        }
                                    }]
                                }],
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "id"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "game"
                                        },
                                        selectionSet: {
                                            kind: "SelectionSet",
                                            selections: [{
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "id"
                                                }
                                            }, {
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "name"
                                                }
                                            }, {
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "slug"
                                                }
                                            }, {
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "isBlocked"
                                                }
                                            }, {
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "thumbnailUrl"
                                                }
                                            }, {
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "playerCount"
                                                },
                                                directives: [{
                                                    kind: "Directive",
                                                    name: {
                                                        kind: "Name",
                                                        value: "include"
                                                    },
                                                    arguments: [{
                                                        kind: "Argument",
                                                        name: {
                                                            kind: "Name",
                                                            value: "if"
                                                        },
                                                        value: {
                                                            kind: "Variable",
                                                            name: {
                                                                kind: "Name",
                                                                value: "isActivePlayersFeatureFlagOn"
                                                            }
                                                        }
                                                    }]
                                                }]
                                            }, {
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "groupGames"
                                                },
                                                selectionSet: {
                                                    kind: "SelectionSet",
                                                    selections: [{
                                                        kind: "Field",
                                                        name: {
                                                            kind: "Name",
                                                            value: "group"
                                                        },
                                                        selectionSet: {
                                                            kind: "SelectionSet",
                                                            selections: [{
                                                                kind: "Field",
                                                                name: {
                                                                    kind: "Name",
                                                                    value: "translation"
                                                                }
                                                            }, {
                                                                kind: "Field",
                                                                name: {
                                                                    kind: "Name",
                                                                    value: "type"
                                                                }
                                                            }, {
                                                                kind: "Field",
                                                                name: {
                                                                    kind: "Name",
                                                                    value: "id"
                                                                }
                                                            }, {
                                                                kind: "Field",
                                                                name: {
                                                                    kind: "Name",
                                                                    value: "slug"
                                                                }
                                                            }]
                                                        }
                                                    }]
                                                }
                                            }]
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }]
};
export {
    e as K
};