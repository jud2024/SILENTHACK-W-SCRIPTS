import {
    x as U,
    v as X,
    s as Y,
    m as O,
    j as b,
    i as o,
    L as R,
    K as c,
    M as Z,
    a as S,
    e as k,
    d as z,
    f as H,
    Q as h,
    V as _,
    u as E,
    g as T,
    b as I
} from "./scheduler.DXu26z7T.js";
import {
    S as M,
    i as p,
    g as w,
    b as d,
    e as $,
    t as v
} from "./index.Dz_MmNB3.js";
import {
    g as W
} from "./spread.CgU5AtxT.js";
const ce = u => X("truncate", u),
    x = () => U("truncate");

function ee(u) {
    let l, i;
    const a = u[18].default,
        s = S(a, u, u[17], null);
    let f = [{
            id: u[1]
        }, {
            style: u[2]
        }, {
            class: u[3]
        }, u[4]],
        n = {};
    for (let e = 0; e < f.length; e += 1) n = c(n, f[e]);
    return {
        c() {
            l = k("h6"), s && s.c(), this.h()
        },
        l(e) {
            l = z(e, "H6", {
                id: !0,
                style: !0,
                class: !0
            });
            var t = H(l);
            s && s.l(t), t.forEach(o), this.h()
        },
        h() {
            h(l, n), _(l, "svelte-17v69ua", !0)
        },
        m(e, t) {
            b(e, l, t), s && s.m(l, null), i = !0
        },
        p(e, t) {
            s && s.p && (!i || t & 131072) && E(s, a, e, e[17], i ? I(a, e[17], t, null) : T(e[17]), null), h(l, n = W(f, [(!i || t & 2) && {
                id: e[1]
            }, (!i || t & 4) && {
                style: e[2]
            }, (!i || t & 8) && {
                class: e[3]
            }, t & 16 && e[4]])), _(l, "svelte-17v69ua", !0)
        },
        i(e) {
            i || (v(s, e), i = !0)
        },
        o(e) {
            d(s, e), i = !1
        },
        d(e) {
            e && o(l), s && s.d(e)
        }
    }
}

function le(u) {
    let l, i;
    const a = u[18].default,
        s = S(a, u, u[17], null);
    let f = [{
            id: u[1]
        }, {
            style: u[2]
        }, {
            class: u[3]
        }, u[4]],
        n = {};
    for (let e = 0; e < f.length; e += 1) n = c(n, f[e]);
    return {
        c() {
            l = k("h5"), s && s.c(), this.h()
        },
        l(e) {
            l = z(e, "H5", {
                id: !0,
                style: !0,
                class: !0
            });
            var t = H(l);
            s && s.l(t), t.forEach(o), this.h()
        },
        h() {
            h(l, n), _(l, "svelte-17v69ua", !0)
        },
        m(e, t) {
            b(e, l, t), s && s.m(l, null), i = !0
        },
        p(e, t) {
            s && s.p && (!i || t & 131072) && E(s, a, e, e[17], i ? I(a, e[17], t, null) : T(e[17]), null), h(l, n = W(f, [(!i || t & 2) && {
                id: e[1]
            }, (!i || t & 4) && {
                style: e[2]
            }, (!i || t & 8) && {
                class: e[3]
            }, t & 16 && e[4]])), _(l, "svelte-17v69ua", !0)
        },
        i(e) {
            i || (v(s, e), i = !0)
        },
        o(e) {
            d(s, e), i = !1
        },
        d(e) {
            e && o(l), s && s.d(e)
        }
    }
}

function te(u) {
    let l, i;
    const a = u[18].default,
        s = S(a, u, u[17], null);
    let f = [{
            id: u[1]
        }, {
            style: u[2]
        }, {
            class: u[3]
        }, u[4]],
        n = {};
    for (let e = 0; e < f.length; e += 1) n = c(n, f[e]);
    return {
        c() {
            l = k("h4"), s && s.c(), this.h()
        },
        l(e) {
            l = z(e, "H4", {
                id: !0,
                style: !0,
                class: !0
            });
            var t = H(l);
            s && s.l(t), t.forEach(o), this.h()
        },
        h() {
            h(l, n), _(l, "svelte-17v69ua", !0)
        },
        m(e, t) {
            b(e, l, t), s && s.m(l, null), i = !0
        },
        p(e, t) {
            s && s.p && (!i || t & 131072) && E(s, a, e, e[17], i ? I(a, e[17], t, null) : T(e[17]), null), h(l, n = W(f, [(!i || t & 2) && {
                id: e[1]
            }, (!i || t & 4) && {
                style: e[2]
            }, (!i || t & 8) && {
                class: e[3]
            }, t & 16 && e[4]])), _(l, "svelte-17v69ua", !0)
        },
        i(e) {
            i || (v(s, e), i = !0)
        },
        o(e) {
            d(s, e), i = !1
        },
        d(e) {
            e && o(l), s && s.d(e)
        }
    }
}

function se(u) {
    let l, i;
    const a = u[18].default,
        s = S(a, u, u[17], null);
    let f = [{
            id: u[1]
        }, {
            style: u[2]
        }, {
            class: u[3]
        }, u[4]],
        n = {};
    for (let e = 0; e < f.length; e += 1) n = c(n, f[e]);
    return {
        c() {
            l = k("h3"), s && s.c(), this.h()
        },
        l(e) {
            l = z(e, "H3", {
                id: !0,
                style: !0,
                class: !0
            });
            var t = H(l);
            s && s.l(t), t.forEach(o), this.h()
        },
        h() {
            h(l, n), _(l, "svelte-17v69ua", !0)
        },
        m(e, t) {
            b(e, l, t), s && s.m(l, null), i = !0
        },
        p(e, t) {
            s && s.p && (!i || t & 131072) && E(s, a, e, e[17], i ? I(a, e[17], t, null) : T(e[17]), null), h(l, n = W(f, [(!i || t & 2) && {
                id: e[1]
            }, (!i || t & 4) && {
                style: e[2]
            }, (!i || t & 8) && {
                class: e[3]
            }, t & 16 && e[4]])), _(l, "svelte-17v69ua", !0)
        },
        i(e) {
            i || (v(s, e), i = !0)
        },
        o(e) {
            d(s, e), i = !1
        },
        d(e) {
            e && o(l), s && s.d(e)
        }
    }
}

function ie(u) {
    let l, i;
    const a = u[18].default,
        s = S(a, u, u[17], null);
    let f = [{
            id: u[1]
        }, {
            style: u[2]
        }, {
            class: u[3]
        }, u[4]],
        n = {};
    for (let e = 0; e < f.length; e += 1) n = c(n, f[e]);
    return {
        c() {
            l = k("h2"), s && s.c(), this.h()
        },
        l(e) {
            l = z(e, "H2", {
                id: !0,
                style: !0,
                class: !0
            });
            var t = H(l);
            s && s.l(t), t.forEach(o), this.h()
        },
        h() {
            h(l, n), _(l, "svelte-17v69ua", !0)
        },
        m(e, t) {
            b(e, l, t), s && s.m(l, null), i = !0
        },
        p(e, t) {
            s && s.p && (!i || t & 131072) && E(s, a, e, e[17], i ? I(a, e[17], t, null) : T(e[17]), null), h(l, n = W(f, [(!i || t & 2) && {
                id: e[1]
            }, (!i || t & 4) && {
                style: e[2]
            }, (!i || t & 8) && {
                class: e[3]
            }, t & 16 && e[4]])), _(l, "svelte-17v69ua", !0)
        },
        i(e) {
            i || (v(s, e), i = !0)
        },
        o(e) {
            d(s, e), i = !1
        },
        d(e) {
            e && o(l), s && s.d(e)
        }
    }
}

function ue(u) {
    let l, i;
    const a = u[18].default,
        s = S(a, u, u[17], null);
    let f = [{
            id: u[1]
        }, {
            style: u[2]
        }, {
            class: u[3]
        }, u[4]],
        n = {};
    for (let e = 0; e < f.length; e += 1) n = c(n, f[e]);
    return {
        c() {
            l = k("h1"), s && s.c(), this.h()
        },
        l(e) {
            l = z(e, "H1", {
                id: !0,
                style: !0,
                class: !0
            });
            var t = H(l);
            s && s.l(t), t.forEach(o), this.h()
        },
        h() {
            h(l, n), _(l, "svelte-17v69ua", !0)
        },
        m(e, t) {
            b(e, l, t), s && s.m(l, null), i = !0
        },
        p(e, t) {
            s && s.p && (!i || t & 131072) && E(s, a, e, e[17], i ? I(a, e[17], t, null) : T(e[17]), null), h(l, n = W(f, [(!i || t & 2) && {
                id: e[1]
            }, (!i || t & 4) && {
                style: e[2]
            }, (!i || t & 8) && {
                class: e[3]
            }, t & 16 && e[4]])), _(l, "svelte-17v69ua", !0)
        },
        i(e) {
            i || (v(s, e), i = !0)
        },
        o(e) {
            d(s, e), i = !1
        },
        d(e) {
            e && o(l), s && s.d(e)
        }
    }
}

function ne(u) {
    let l, i;
    const a = u[18].default,
        s = S(a, u, u[17], null);
    let f = [{
            id: u[1]
        }, {
            style: u[2]
        }, {
            class: u[3]
        }, u[4]],
        n = {};
    for (let e = 0; e < f.length; e += 1) n = c(n, f[e]);
    return {
        c() {
            l = k("em"), s && s.c(), this.h()
        },
        l(e) {
            l = z(e, "EM", {
                id: !0,
                style: !0,
                class: !0
            });
            var t = H(l);
            s && s.l(t), t.forEach(o), this.h()
        },
        h() {
            h(l, n), _(l, "svelte-17v69ua", !0)
        },
        m(e, t) {
            b(e, l, t), s && s.m(l, null), i = !0
        },
        p(e, t) {
            s && s.p && (!i || t & 131072) && E(s, a, e, e[17], i ? I(a, e[17], t, null) : T(e[17]), null), h(l, n = W(f, [(!i || t & 2) && {
                id: e[1]
            }, (!i || t & 4) && {
                style: e[2]
            }, (!i || t & 8) && {
                class: e[3]
            }, t & 16 && e[4]])), _(l, "svelte-17v69ua", !0)
        },
        i(e) {
            i || (v(s, e), i = !0)
        },
        o(e) {
            d(s, e), i = !1
        },
        d(e) {
            e && o(l), s && s.d(e)
        }
    }
}

function ae(u) {
    let l, i;
    const a = u[18].default,
        s = S(a, u, u[17], null);
    let f = [{
            id: u[1]
        }, {
            style: u[2]
        }, {
            class: u[3]
        }, u[4]],
        n = {};
    for (let e = 0; e < f.length; e += 1) n = c(n, f[e]);
    return {
        c() {
            l = k("p"), s && s.c(), this.h()
        },
        l(e) {
            l = z(e, "P", {
                id: !0,
                style: !0,
                class: !0
            });
            var t = H(l);
            s && s.l(t), t.forEach(o), this.h()
        },
        h() {
            h(l, n), _(l, "svelte-17v69ua", !0)
        },
        m(e, t) {
            b(e, l, t), s && s.m(l, null), i = !0
        },
        p(e, t) {
            s && s.p && (!i || t & 131072) && E(s, a, e, e[17], i ? I(a, e[17], t, null) : T(e[17]), null), h(l, n = W(f, [(!i || t & 2) && {
                id: e[1]
            }, (!i || t & 4) && {
                style: e[2]
            }, (!i || t & 8) && {
                class: e[3]
            }, t & 16 && e[4]])), _(l, "svelte-17v69ua", !0)
        },
        i(e) {
            i || (v(s, e), i = !0)
        },
        o(e) {
            d(s, e), i = !1
        },
        d(e) {
            e && o(l), s && s.d(e)
        }
    }
}

function fe(u) {
    let l, i;
    const a = u[18].default,
        s = S(a, u, u[17], null);
    let f = [{
            id: u[1]
        }, {
            style: u[2]
        }, {
            class: u[3]
        }, u[4]],
        n = {};
    for (let e = 0; e < f.length; e += 1) n = c(n, f[e]);
    return {
        c() {
            l = k("span"), s && s.c(), this.h()
        },
        l(e) {
            l = z(e, "SPAN", {
                id: !0,
                style: !0,
                class: !0
            });
            var t = H(l);
            s && s.l(t), t.forEach(o), this.h()
        },
        h() {
            h(l, n), _(l, "svelte-17v69ua", !0)
        },
        m(e, t) {
            b(e, l, t), s && s.m(l, null), i = !0
        },
        p(e, t) {
            s && s.p && (!i || t & 131072) && E(s, a, e, e[17], i ? I(a, e[17], t, null) : T(e[17]), null), h(l, n = W(f, [(!i || t & 2) && {
                id: e[1]
            }, (!i || t & 4) && {
                style: e[2]
            }, (!i || t & 8) && {
                class: e[3]
            }, t & 16 && e[4]])), _(l, "svelte-17v69ua", !0)
        },
        i(e) {
            i || (v(s, e), i = !0)
        },
        o(e) {
            d(s, e), i = !1
        },
        d(e) {
            e && o(l), s && s.d(e)
        }
    }
}

function re(u) {
    let l, i, a, s;
    const f = [fe, ae, ne, ue, ie, se, te, le, ee],
        n = [];

    function e(t, m) {
        return t[0] === "span" ? 0 : t[0] === "p" ? 1 : t[0] === "em" ? 2 : t[0] === "h1" ? 3 : t[0] === "h2" ? 4 : t[0] === "h3" ? 5 : t[0] === "h4" ? 6 : t[0] === "h5" ? 7 : t[0] === "h6" ? 8 : -1
    }
    return ~(l = e(u)) && (i = n[l] = f[l](u)), {
        c() {
            i && i.c(), a = O()
        },
        l(t) {
            i && i.l(t), a = O()
        },
        m(t, m) {
            ~l && n[l].m(t, m), b(t, a, m), s = !0
        },
        p(t, [m]) {
            let g = l;
            l = e(t), l === g ? ~l && n[l].p(t, m) : (i && (w(), d(n[g], 1, 1, () => {
                n[g] = null
            }), $()), ~l ? (i = n[l], i ? i.p(t, m) : (i = n[l] = f[l](t), i.c()), v(i, 1), i.m(a.parentNode, a)) : i = null)
        },
        i(t) {
            s || (v(i), s = !0)
        },
        o(t) {
            d(i), s = !1
        },
        d(t) {
            t && o(a), ~l && n[l].d(t)
        }
    }
}

function oe(u, l, i) {
    var G, J;
    let a, s;
    const f = ["tag", "align", "responsiveTypeScale", "lineHeight", "size", "iconSpace", "variant", "numeric", "fixWidth", "weight", "id", "contentStyle", "chromaticIgnore", "inline"];
    let n = R(l, f),
        {
            $$slots: e = {},
            $$scope: t
        } = l;
    const m = {
        h1: {
            size: "lg",
            weight: "semibold"
        },
        h2: {
            size: "base",
            weight: "semibold"
        },
        h3: {
            size: "default",
            weight: "semibold"
        }
    };
    let {
        tag: g = "span"
    } = l, {
        align: j = "left"
    } = l, {
        responsiveTypeScale: C = !1
    } = l, {
        lineHeight: q = C ? "responsive" : "default"
    } = l, {
        size: P = g && ((G = m == null ? void 0 : m[g]) == null ? void 0 : G.size) || "default"
    } = l, {
        iconSpace: y = !0
    } = l, {
        variant: A = "subtle"
    } = l, {
        numeric: K = !1
    } = l, {
        fixWidth: N = void 0
    } = l, {
        weight: L = g && ((J = m == null ? void 0 : m[g]) == null ? void 0 : J.weight) || "normal"
    } = l, {
        id: F = void 0
    } = l, {
        contentStyle: Q = ""
    } = l, {
        chromaticIgnore: V = void 0
    } = l, {
        inline: B = !1
    } = l;
    const D = x();
    return u.$$set = r => {
        l = c(c({}, l), Z(r)), i(4, n = R(l, f)), "tag" in r && i(0, g = r.tag), "align" in r && i(5, j = r.align), "responsiveTypeScale" in r && i(6, C = r.responsiveTypeScale), "lineHeight" in r && i(7, q = r.lineHeight), "size" in r && i(8, P = r.size), "iconSpace" in r && i(9, y = r.iconSpace), "variant" in r && i(10, A = r.variant), "numeric" in r && i(11, K = r.numeric), "fixWidth" in r && i(12, N = r.fixWidth), "weight" in r && i(13, L = r.weight), "id" in r && i(1, F = r.id), "contentStyle" in r && i(14, Q = r.contentStyle), "chromaticIgnore" in r && i(15, V = r.chromaticIgnore), "inline" in r && i(16, B = r.inline), "$$scope" in r && i(17, t = r.$$scope)
    }, u.$$.update = () => {
        u.$$.dirty & 110560 && i(3, a = `weight-${L} line-height-${q} ${B?"is-inline ":""}align-${j} size-${P} text-size-${P} ${C?"responsive-type-scale":""} variant-${A} ${K?"numeric":""} ${y?"with-icon-space":""} ${D?"is-truncate":""} ${V?"chromatic-ignore":""}`), u.$$.dirty & 20480 && i(2, s = `${N?`width: ${N}`:""}${D?`max-width: ${D};`:""}${Q}`)
    }, [g, F, s, a, n, j, C, q, P, y, A, K, N, L, Q, V, B, t, e]
}
class de extends M {
    constructor(l) {
        super(), p(this, l, oe, re, Y, {
            tag: 0,
            align: 5,
            responsiveTypeScale: 6,
            lineHeight: 7,
            size: 8,
            iconSpace: 9,
            variant: 10,
            numeric: 11,
            fixWidth: 12,
            weight: 13,
            id: 1,
            contentStyle: 14,
            chromaticIgnore: 15,
            inline: 16
        })
    }
}
export {
    de as T, x as g, ce as s
};