import {
    ab as ut,
    o as dt
} from "./scheduler.DXu26z7T.js";
import {
    w as we
} from "./index.C2-CG2CN.js";
import {
    H as ae,
    S as ve,
    R as qe
} from "./control.CYgJF_JY.js";
new URL("sveltekit-internal://");

function ht(e, n) {
    return e === "/" || n === "ignore" ? e : n === "never" ? e.endsWith("/") ? e.slice(0, -1) : e : n === "always" && !e.endsWith("/") ? e + "/" : e
}

function pt(e) {
    return e.split("%25").map(decodeURI).join("%25")
}

function gt(e) {
    for (const n in e) e[n] = decodeURIComponent(e[n]);
    return e
}

function de({
    href: e
}) {
    return e.split("#")[0]
}
const mt = ["href", "pathname", "search", "toString", "toJSON"];

function _t(e, n, t) {
    const a = new URL(e);
    Object.defineProperty(a, "searchParams", {
        value: new Proxy(a.searchParams, {
            get(r, o) {
                if (o === "get" || o === "getAll" || o === "has") return i => (t(i), r[o](i));
                n();
                const s = Reflect.get(r, o);
                return typeof s == "function" ? s.bind(r) : s
            }
        }),
        enumerable: !0,
        configurable: !0
    });
    for (const r of mt) Object.defineProperty(a, r, {
        get() {
            return n(), e[r]
        },
        enumerable: !0,
        configurable: !0
    });
    return a
}
const yt = "/__data.json",
    wt = ".html__data.json";

function vt(e) {
    return e.endsWith(".html") ? e.replace(/\.html$/, wt) : e.replace(/\/$/, "") + yt
}

function bt(...e) {
    let n = 5381;
    for (const t of e)
        if (typeof t == "string") {
            let a = t.length;
            for (; a;) n = n * 33 ^ t.charCodeAt(--a)
        } else if (ArrayBuffer.isView(t)) {
        const a = new Uint8Array(t.buffer, t.byteOffset, t.byteLength);
        let r = a.length;
        for (; r;) n = n * 33 ^ a[--r]
    } else throw new TypeError("value must be a string or TypedArray");
    return (n >>> 0).toString(36)
}

function kt(e) {
    const n = atob(e),
        t = new Uint8Array(n.length);
    for (let a = 0; a < n.length; a++) t[a] = n.charCodeAt(a);
    return t.buffer
}
const Ge = window.fetch;
window.fetch = (e, n) => ((e instanceof Request ? e.method : (n == null ? void 0 : n.method) || "GET") !== "GET" && q.delete(be(e)), Ge(e, n));
const q = new Map;

function Et(e, n) {
    const t = be(e, n),
        a = document.querySelector(t);
    if (a != null && a.textContent) {
        let {
            body: r,
            ...o
        } = JSON.parse(a.textContent);
        const s = a.getAttribute("data-ttl");
        return s && q.set(t, {
            body: r,
            init: o,
            ttl: 1e3 * Number(s)
        }), a.getAttribute("data-b64") !== null && (r = kt(r)), Promise.resolve(new Response(r, o))
    }
    return window.fetch(e, n)
}

function At(e, n, t) {
    if (q.size > 0) {
        const a = be(e, t),
            r = q.get(a);
        if (r) {
            if (performance.now() < r.ttl && ["default", "force-cache", "only-if-cached", void 0].includes(t == null ? void 0 : t.cache)) return new Response(r.body, r.init);
            q.delete(a)
        }
    }
    return window.fetch(n, t)
}

function be(e, n) {
    let a = `script[data-sveltekit-fetched][data-url=${JSON.stringify(e instanceof Request?e.url:e)}]`;
    if (n != null && n.headers || n != null && n.body) {
        const r = [];
        n.headers && r.push([...new Headers(n.headers)].join(",")), n.body && (typeof n.body == "string" || ArrayBuffer.isView(n.body)) && r.push(n.body), a += `[data-hash="${bt(...r)}"]`
    }
    return a
}
const St = /^(\[)?(\.\.\.)?(\w+)(?:=(\w+))?(\])?$/;

function Rt(e) {
    const n = [];
    return {
        pattern: e === "/" ? /^\/$/ : new RegExp(`^${Lt(e).map(a=>{const r=/^\[\.\.\.(\w+)(?:=(\w+))?\]$/.exec(a);if(r)return n.push({name:r[1],matcher:r[2],optional:!1,rest:!0,chained:!0}),"(?:/(.*))?";const o=/^\[\[(\w+)(?:=(\w+))?\]\]$/.exec(a);if(o)return n.push({name:o[1],matcher:o[2],optional:!0,rest:!1,chained:!0}),"(?:/([^/]+))?";if(!a)return;const s=a.split(/\[(.+?)\](?!\])/);return"/"+s.map((c,f)=>{if(f%2){if(c.startsWith("x+"))return he(String.fromCharCode(parseInt(c.slice(2),16)));if(c.startsWith("u+"))return he(String.fromCharCode(...c.slice(2).split("-").map(l=>parseInt(l,16))));const u=St.exec(c),[,h,g,d,_]=u;return n.push({name:d,matcher:_,optional:!!h,rest:!!g,chained:g?f===1&&s[0]==="":!1}),g?"(.*?)":h?"([^/]*)?":"([^/]+?)"}return he(c)}).join("")}).join("")}/?$`),
        params: n
    }
}

function It(e) {
    return !/^\([^)]+\)$/.test(e)
}

function Lt(e) {
    return e.slice(1).split("/").filter(It)
}

function Pt(e, n, t) {
    const a = {},
        r = e.slice(1),
        o = r.filter(i => i !== void 0);
    let s = 0;
    for (let i = 0; i < n.length; i += 1) {
        const c = n[i];
        let f = r[i - s];
        if (c.chained && c.rest && s && (f = r.slice(i - s, i + 1).filter(u => u).join("/"), s = 0), f === void 0) {
            c.rest && (a[c.name] = "");
            continue
        }
        if (!c.matcher || t[c.matcher](f)) {
            a[c.name] = f;
            const u = n[i + 1],
                h = r[i + 1];
            u && !u.rest && u.optional && h && c.chained && (s = 0), !u && !h && Object.keys(a).length === o.length && (s = 0);
            continue
        }
        if (c.optional && c.chained) {
            s++;
            continue
        }
        return
    }
    if (!s) return a
}

function he(e) {
    return e.normalize().replace(/[[\]]/g, "\\$&").replace(/%/g, "%25").replace(/\//g, "%2[Ff]").replace(/\?/g, "%3[Ff]").replace(/#/g, "%23").replace(/[.*+?^${}()|\\]/g, "\\$&")
}

function Tt({
    nodes: e,
    server_loads: n,
    dictionary: t,
    matchers: a
}) {
    const r = new Set(n);
    return Object.entries(t).map(([i, [c, f, u]]) => {
        const {
            pattern: h,
            params: g
        } = Rt(i), d = {
            id: i,
            exec: _ => {
                const l = h.exec(_);
                if (l) return Pt(l, g, a)
            },
            errors: [1, ...u || []].map(_ => e[_]),
            layouts: [0, ...f || []].map(s),
            leaf: o(c)
        };
        return d.errors.length = d.layouts.length = Math.max(d.errors.length, d.layouts.length), d
    });

    function o(i) {
        const c = i < 0;
        return c && (i = ~i), [c, e[i]]
    }

    function s(i) {
        return i === void 0 ? i : [r.has(i), e[i]]
    }
}

function He(e, n = JSON.parse) {
    try {
        return n(sessionStorage[e])
    } catch {}
}

function xe(e, n, t = JSON.stringify) {
    const a = t(n);
    try {
        sessionStorage[e] = a
    } catch {}
}
var Fe;
const P = ((Fe = globalThis.__sveltekit_1xez8s5) == null ? void 0 : Fe.base) ? ? "";
var Me;
const Ut = ((Me = globalThis.__sveltekit_1xez8s5) == null ? void 0 : Me.assets) ? ? P,
    xt = "1722570739458",
    Be = "sveltekit:snapshot",
    Ke = "sveltekit:scroll",
    ze = "sveltekit:states",
    Nt = "sveltekit:pageurl",
    D = "sveltekit:history",
    H = "sveltekit:navigation",
    W = {
        tap: 1,
        hover: 2,
        viewport: 3,
        eager: 4,
        off: -1,
        false: -1
    },
    z = location.origin;

function Ye(e) {
    if (e instanceof URL) return e;
    let n = document.baseURI;
    if (!n) {
        const t = document.getElementsByTagName("base");
        n = t.length ? t[0].href : document.URL
    }
    return new URL(e, n)
}

function ke() {
    return {
        x: pageXOffset,
        y: pageYOffset
    }
}

function j(e, n) {
    return e.getAttribute(`data-sveltekit-${n}`)
}
const Ne = { ...W,
    "": W.hover
};

function We(e) {
    let n = e.assignedSlot ? ? e.parentNode;
    return (n == null ? void 0 : n.nodeType) === 11 && (n = n.host), n
}

function Je(e, n) {
    for (; e && e !== n;) {
        if (e.nodeName.toUpperCase() === "A" && e.hasAttribute("href")) return e;
        e = We(e)
    }
}

function me(e, n) {
    let t;
    try {
        t = new URL(e instanceof SVGAElement ? e.href.baseVal : e.href, document.baseURI)
    } catch {}
    const a = e instanceof SVGAElement ? e.target.baseVal : e.target,
        r = !t || !!a || re(t, n) || (e.getAttribute("rel") || "").split(/\s+/).includes("external"),
        o = (t == null ? void 0 : t.origin) === z && e.hasAttribute("download");
    return {
        url: t,
        external: r,
        target: a,
        download: o
    }
}

function J(e) {
    let n = null,
        t = null,
        a = null,
        r = null,
        o = null,
        s = null,
        i = e;
    for (; i && i !== document.documentElement;) a === null && (a = j(i, "preload-code")), r === null && (r = j(i, "preload-data")), n === null && (n = j(i, "keepfocus")), t === null && (t = j(i, "noscroll")), o === null && (o = j(i, "reload")), s === null && (s = j(i, "replacestate")), i = We(i);

    function c(f) {
        switch (f) {
            case "":
            case "true":
                return !0;
            case "off":
            case "false":
                return !1;
            default:
                return
        }
    }
    return {
        preload_code: Ne[a ? ? "off"],
        preload_data: Ne[r ? ? "off"],
        keepfocus: c(n),
        noscroll: c(t),
        reload: c(o),
        replace_state: c(s)
    }
}

function Oe(e) {
    const n = we(e);
    let t = !0;

    function a() {
        t = !0, n.update(s => s)
    }

    function r(s) {
        t = !1, n.set(s)
    }

    function o(s) {
        let i;
        return n.subscribe(c => {
            (i === void 0 || t && c !== i) && s(i = c)
        })
    }
    return {
        notify: a,
        set: r,
        subscribe: o
    }
}

function Ot() {
    const {
        set: e,
        subscribe: n
    } = we(!1);
    let t;
    async function a() {
        clearTimeout(t);
        try {
            const r = await fetch(`${Ut}/_app/version.json`, {
                headers: {
                    pragma: "no-cache",
                    "cache-control": "no-cache"
                }
            });
            if (!r.ok) return !1;
            const s = (await r.json()).version !== xt;
            return s && (e(!0), clearTimeout(t)), s
        } catch {
            return !1
        }
    }
    return {
        subscribe: n,
        check: a
    }
}

function re(e, n) {
    return e.origin !== z || !e.pathname.startsWith(n)
}
const jt = -1,
    Dt = -2,
    $t = -3,
    Ct = -4,
    Vt = -5,
    Ft = -6;

function Mt(e, n) {
    if (typeof e == "number") return r(e, !0);
    if (!Array.isArray(e) || e.length === 0) throw new Error("Invalid input");
    const t = e,
        a = Array(t.length);

    function r(o, s = !1) {
        if (o === jt) return;
        if (o === $t) return NaN;
        if (o === Ct) return 1 / 0;
        if (o === Vt) return -1 / 0;
        if (o === Ft) return -0;
        if (s) throw new Error("Invalid input");
        if (o in a) return a[o];
        const i = t[o];
        if (!i || typeof i != "object") a[o] = i;
        else if (Array.isArray(i))
            if (typeof i[0] == "string") {
                const c = i[0],
                    f = n == null ? void 0 : n[c];
                if (f) return a[o] = f(r(i[1]));
                switch (c) {
                    case "Date":
                        a[o] = new Date(i[1]);
                        break;
                    case "Set":
                        const u = new Set;
                        a[o] = u;
                        for (let d = 1; d < i.length; d += 1) u.add(r(i[d]));
                        break;
                    case "Map":
                        const h = new Map;
                        a[o] = h;
                        for (let d = 1; d < i.length; d += 2) h.set(r(i[d]), r(i[d + 1]));
                        break;
                    case "RegExp":
                        a[o] = new RegExp(i[1], i[2]);
                        break;
                    case "Object":
                        a[o] = Object(i[1]);
                        break;
                    case "BigInt":
                        a[o] = BigInt(i[1]);
                        break;
                    case "null":
                        const g = Object.create(null);
                        a[o] = g;
                        for (let d = 1; d < i.length; d += 2) g[i[d]] = r(i[d + 1]);
                        break;
                    default:
                        throw new Error(`Unknown type ${c}`)
                }
            } else {
                const c = new Array(i.length);
                a[o] = c;
                for (let f = 0; f < i.length; f += 1) {
                    const u = i[f];
                    u !== Dt && (c[f] = r(u))
                }
            }
        else {
            const c = {};
            a[o] = c;
            for (const f in i) {
                const u = i[f];
                c[f] = r(u)
            }
        }
        return a[o]
    }
    return r(0)
}
const Xe = new Set(["load", "prerender", "csr", "ssr", "trailingSlash", "config"]);
[...Xe];
const qt = new Set([...Xe]);
[...qt];

function Gt(e) {
    return e.filter(n => n != null)
}
const Ht = "x-sveltekit-invalidated",
    Bt = "x-sveltekit-trailing-slash";

function X(e) {
    return e instanceof ae || e instanceof ve ? e.status : 500
}

function Kt(e) {
    return e instanceof ve ? e.text : "Internal Error"
}
const O = He(Ke) ? ? {},
    B = He(Be) ? ? {},
    U = {
        url: Oe({}),
        page: Oe({}),
        navigating: we(null),
        updated: Ot()
    };

function Ee(e) {
    O[e] = ke()
}

function zt(e, n) {
    let t = e + 1;
    for (; O[t];) delete O[t], t += 1;
    for (t = n + 1; B[t];) delete B[t], t += 1
}

function C(e) {
    return location.href = e.href, new Promise(() => {})
}

function je() {}
let oe, _e, Z, T, ye, F;
const Q = [],
    ee = [];
let R = null;
const Ae = [],
    Yt = [];
let N = [],
    y = {
        branch: [],
        error: null,
        url: null
    },
    Se = !1,
    te = !1,
    De = !0,
    K = !1,
    M = !1,
    Ze = !1,
    ie = !1,
    se, A, L, I, V;
const G = new Set;
let pe;
async function sn(e, n, t) {
    var r, o;
    document.URL !== location.href && (location.href = location.href), F = e, oe = Tt(e), T = document.documentElement, ye = n, _e = e.nodes[0], Z = e.nodes[1], _e(), Z(), A = (r = history.state) == null ? void 0 : r[D], L = (o = history.state) == null ? void 0 : o[H], A || (A = L = Date.now(), history.replaceState({ ...history.state,
        [D]: A,
        [H]: L
    }, ""));
    const a = O[A];
    a && (history.scrollRestoration = "manual", scrollTo(a.x, a.y)), t ? await tn(ye, t) : Qt(location.href, {
        replaceState: !0
    }), en()
}
async function Qe() {
    if (await (pe || (pe = Promise.resolve())), !pe) return;
    pe = null;
    const e = le(y.url, !0);
    R = null;
    const n = V = {},
        t = e && await Pe(e);
    if (!(!t || n !== V)) {
        if (t.type === "redirect") return Re(new URL(t.location, y.url).href, {}, 1, n);
        t.props.page && (I = t.props.page), y = t.state, et(), se.$set(t.props)
    }
}

function et() {
    Q.length = 0, ie = !1
}

function tt(e) {
    ee.some(n => n == null ? void 0 : n.snapshot) && (B[e] = ee.map(n => {
        var t;
        return (t = n == null ? void 0 : n.snapshot) == null ? void 0 : t.capture()
    }))
}

function nt(e) {
    var n;
    (n = B[e]) == null || n.forEach((t, a) => {
        var r, o;
        (o = (r = ee[a]) == null ? void 0 : r.snapshot) == null || o.restore(t)
    })
}

function $e() {
    Ee(A), xe(Ke, O), tt(L), xe(Be, B)
}
async function Re(e, n, t, a) {
    return Y({
        type: "goto",
        url: Ye(e),
        keepfocus: n.keepFocus,
        noscroll: n.noScroll,
        replace_state: n.replaceState,
        state: n.state,
        redirect_count: t,
        nav_token: a,
        accept: () => {
            n.invalidateAll && (ie = !0)
        }
    })
}
async function Wt(e) {
    if (e.id !== (R == null ? void 0 : R.id)) {
        const n = {};
        G.add(n), R = {
            id: e.id,
            token: n,
            promise: Pe({ ...e,
                preload: n
            }).then(t => (G.delete(n), t.type === "loaded" && t.state.error && (R = null), t))
        }
    }
    return R.promise
}
async function ge(e) {
    const n = oe.find(t => t.exec(rt(e)));
    n && await Promise.all([...n.layouts, n.leaf].map(t => t == null ? void 0 : t[1]()))
}

function at(e, n, t) {
    var o;
    y = e.state;
    const a = document.querySelector("style[data-sveltekit]");
    a && a.remove(), I = e.props.page, se = new F.root({
        target: n,
        props: { ...e.props,
            stores: U,
            components: ee
        },
        hydrate: t
    }), nt(L);
    const r = {
        from: null,
        to: {
            params: y.params,
            route: {
                id: ((o = y.route) == null ? void 0 : o.id) ? ? null
            },
            url: new URL(location.href)
        },
        willUnload: !1,
        type: "enter",
        complete: Promise.resolve()
    };
    N.forEach(s => s(r)), te = !0
}

function ne({
    url: e,
    params: n,
    branch: t,
    status: a,
    error: r,
    route: o,
    form: s
}) {
    let i = "never";
    if (P && (e.pathname === P || e.pathname === P + "/")) i = "always";
    else
        for (const d of t)(d == null ? void 0 : d.slash) !== void 0 && (i = d.slash);
    e.pathname = ht(e.pathname, i), e.search = e.search;
    const c = {
        type: "loaded",
        state: {
            url: e,
            params: n,
            branch: t,
            error: r,
            route: o
        },
        props: {
            constructors: Gt(t).map(d => d.node.component),
            page: I
        }
    };
    s !== void 0 && (c.props.form = s);
    let f = {},
        u = !I,
        h = 0;
    for (let d = 0; d < Math.max(t.length, y.branch.length); d += 1) {
        const _ = t[d],
            l = y.branch[d];
        (_ == null ? void 0 : _.data) !== (l == null ? void 0 : l.data) && (u = !0), _ && (f = { ...f,
            ..._.data
        }, u && (c.props[`data_${h}`] = f), h += 1)
    }
    return (!y.url || e.href !== y.url.href || y.error !== r || s !== void 0 && s !== I.form || u) && (c.props.page = {
        error: r,
        params: n,
        route: {
            id: (o == null ? void 0 : o.id) ? ? null
        },
        state: {},
        status: a,
        url: new URL(e),
        form: s ? ? null,
        data: u ? f : I.data
    }), c
}
async function Ie({
    loader: e,
    parent: n,
    url: t,
    params: a,
    route: r,
    server_data_node: o
}) {
    var u, h, g;
    let s = null,
        i = !0;
    const c = {
            dependencies: new Set,
            params: new Set,
            parent: !1,
            route: !1,
            url: !1,
            search_params: new Set
        },
        f = await e();
    if ((u = f.universal) != null && u.load) {
        let d = function(...l) {
            for (const m of l) {
                const {
                    href: b
                } = new URL(m, t);
                c.dependencies.add(b)
            }
        };
        const _ = {
            route: new Proxy(r, {
                get: (l, m) => (i && (c.route = !0), l[m])
            }),
            params: new Proxy(a, {
                get: (l, m) => (i && c.params.add(m), l[m])
            }),
            data: (o == null ? void 0 : o.data) ? ? null,
            url: _t(t, () => {
                i && (c.url = !0)
            }, l => {
                i && c.search_params.add(l)
            }),
            async fetch(l, m) {
                let b;
                l instanceof Request ? (b = l.url, m = {
                    body: l.method === "GET" || l.method === "HEAD" ? void 0 : await l.blob(),
                    cache: l.cache,
                    credentials: l.credentials,
                    headers: l.headers,
                    integrity: l.integrity,
                    keepalive: l.keepalive,
                    method: l.method,
                    mode: l.mode,
                    redirect: l.redirect,
                    referrer: l.referrer,
                    referrerPolicy: l.referrerPolicy,
                    signal: l.signal,
                    ...m
                }) : b = l;
                const S = new URL(b, t);
                return i && d(S.href), S.origin === t.origin && (b = S.href.slice(t.origin.length)), te ? At(b, S.href, m) : Et(b, m)
            },
            setHeaders: () => {},
            depends: d,
            parent() {
                return i && (c.parent = !0), n()
            },
            untrack(l) {
                i = !1;
                try {
                    return l()
                } finally {
                    i = !0
                }
            }
        };
        s = await f.universal.load.call(null, _) ? ? null
    }
    return {
        node: f,
        loader: e,
        server: o,
        universal: (h = f.universal) != null && h.load ? {
            type: "data",
            data: s,
            uses: c
        } : null,
        data: s ? ? (o == null ? void 0 : o.data) ? ? null,
        slash: ((g = f.universal) == null ? void 0 : g.trailingSlash) ? ? (o == null ? void 0 : o.slash)
    }
}

function Ce(e, n, t, a, r, o) {
    if (ie) return !0;
    if (!r) return !1;
    if (r.parent && e || r.route && n || r.url && t) return !0;
    for (const s of r.search_params)
        if (a.has(s)) return !0;
    for (const s of r.params)
        if (o[s] !== y.params[s]) return !0;
    for (const s of r.dependencies)
        if (Q.some(i => i(new URL(s)))) return !0;
    return !1
}

function Le(e, n) {
    return (e == null ? void 0 : e.type) === "data" ? e : (e == null ? void 0 : e.type) === "skip" ? n ? ? null : null
}

function Jt(e, n) {
    if (!e) return new Set(n.searchParams.keys());
    const t = new Set([...e.searchParams.keys(), ...n.searchParams.keys()]);
    for (const a of t) {
        const r = e.searchParams.getAll(a),
            o = n.searchParams.getAll(a);
        r.every(s => o.includes(s)) && o.every(s => r.includes(s)) && t.delete(a)
    }
    return t
}

function Ve({
    error: e,
    url: n,
    route: t,
    params: a
}) {
    return {
        type: "loaded",
        state: {
            error: e,
            url: n,
            route: t,
            params: a,
            branch: []
        },
        props: {
            page: I,
            constructors: []
        }
    }
}
async function Pe({
    id: e,
    invalidating: n,
    url: t,
    params: a,
    route: r,
    preload: o
}) {
    if ((R == null ? void 0 : R.id) === e) return G.delete(R.token), R.promise;
    const {
        errors: s,
        layouts: i,
        leaf: c
    } = r, f = [...i, c];
    s.forEach(p => p == null ? void 0 : p().catch(() => {})), f.forEach(p => p == null ? void 0 : p[1]().catch(() => {}));
    let u = null;
    const h = y.url ? e !== y.url.pathname + y.url.search : !1,
        g = y.route ? r.id !== y.route.id : !1,
        d = Jt(y.url, t);
    let _ = !1;
    const l = f.map((p, v) => {
        var x;
        const k = y.branch[v],
            E = !!(p != null && p[0]) && ((k == null ? void 0 : k.loader) !== p[1] || Ce(_, g, h, d, (x = k.server) == null ? void 0 : x.uses, a));
        return E && (_ = !0), E
    });
    if (l.some(Boolean)) {
        try {
            u = await ct(t, l)
        } catch (p) {
            const v = await $(p, {
                url: t,
                params: a,
                route: {
                    id: e
                }
            });
            return G.has(o) ? Ve({
                error: v,
                url: t,
                params: a,
                route: r
            }) : ce({
                status: X(p),
                error: v,
                url: t,
                route: r
            })
        }
        if (u.type === "redirect") return u
    }
    const m = u == null ? void 0 : u.nodes;
    let b = !1;
    const S = f.map(async (p, v) => {
        var fe;
        if (!p) return;
        const k = y.branch[v],
            E = m == null ? void 0 : m[v];
        if ((!E || E.type === "skip") && p[1] === (k == null ? void 0 : k.loader) && !Ce(b, g, h, d, (fe = k.universal) == null ? void 0 : fe.uses, a)) return k;
        if (b = !0, (E == null ? void 0 : E.type) === "error") throw E;
        return Ie({
            loader: p[1],
            url: t,
            params: a,
            route: r,
            parent: async () => {
                var Ue;
                const Te = {};
                for (let ue = 0; ue < v; ue += 1) Object.assign(Te, (Ue = await S[ue]) == null ? void 0 : Ue.data);
                return Te
            },
            server_data_node: Le(E === void 0 && p[0] ? {
                type: "skip"
            } : E ? ? null, p[0] ? k == null ? void 0 : k.server : void 0)
        })
    });
    for (const p of S) p.catch(() => {});
    const w = [];
    for (let p = 0; p < f.length; p += 1)
        if (f[p]) try {
            w.push(await S[p])
        } catch (v) {
            if (v instanceof qe) return {
                type: "redirect",
                location: v.location
            };
            if (G.has(o)) return Ve({
                error: await $(v, {
                    params: a,
                    url: t,
                    route: {
                        id: r.id
                    }
                }),
                url: t,
                params: a,
                route: r
            });
            let k = X(v),
                E;
            if (m != null && m.includes(v)) k = v.status ? ? k, E = v.error;
            else if (v instanceof ae) E = v.body;
            else {
                if (await U.updated.check()) return await C(t);
                E = await $(v, {
                    params: a,
                    url: t,
                    route: {
                        id: r.id
                    }
                })
            }
            const x = await Xt(p, w, s);
            return x ? ne({
                url: t,
                params: a,
                branch: w.slice(0, x.idx).concat(x.node),
                status: k,
                error: E,
                route: r
            }) : await it(t, {
                id: r.id
            }, E, k)
        } else w.push(void 0);
    return ne({
        url: t,
        params: a,
        branch: w,
        status: 200,
        error: null,
        route: r,
        form: n ? void 0 : null
    })
}
async function Xt(e, n, t) {
    for (; e--;)
        if (t[e]) {
            let a = e;
            for (; !n[a];) a -= 1;
            try {
                return {
                    idx: a + 1,
                    node: {
                        node: await t[e](),
                        loader: t[e],
                        data: {},
                        server: null,
                        universal: null
                    }
                }
            } catch {
                continue
            }
        }
}
async function ce({
    status: e,
    error: n,
    url: t,
    route: a
}) {
    const r = {};
    let o = null;
    if (F.server_loads[0] === 0) try {
        const f = await ct(t, [!0]);
        if (f.type !== "data" || f.nodes[0] && f.nodes[0].type !== "data") throw 0;
        o = f.nodes[0] ? ? null
    } catch {
        (t.origin !== z || t.pathname !== location.pathname || Se) && await C(t)
    }
    const i = await Ie({
            loader: _e,
            url: t,
            params: r,
            route: a,
            parent: () => Promise.resolve({}),
            server_data_node: Le(o)
        }),
        c = {
            node: await Z(),
            loader: Z,
            universal: null,
            server: null,
            data: null
        };
    return ne({
        url: t,
        params: r,
        branch: [i, c],
        status: e,
        error: n,
        route: null
    })
}

function le(e, n) {
    if (!e || re(e, P)) return;
    let t;
    try {
        t = F.hooks.reroute({
            url: new URL(e)
        }) ? ? e.pathname
    } catch {
        return
    }
    const a = rt(t);
    for (const r of oe) {
        const o = r.exec(a);
        if (o) return {
            id: e.pathname + e.search,
            invalidating: n,
            route: r,
            params: gt(o),
            url: e
        }
    }
}

function rt(e) {
    return pt(e.slice(P.length) || "/")
}

function ot({
    url: e,
    type: n,
    intent: t,
    delta: a
}) {
    let r = !1;
    const o = ft(y, t, e, n);
    a !== void 0 && (o.navigation.delta = a);
    const s = { ...o.navigation,
        cancel: () => {
            r = !0, o.reject(new Error("navigation cancelled"))
        }
    };
    return K || Ae.forEach(i => i(s)), r ? null : o
}
async function Y({
    type: e,
    url: n,
    popped: t,
    keepfocus: a,
    noscroll: r,
    replace_state: o,
    state: s = {},
    redirect_count: i = 0,
    nav_token: c = {},
    accept: f = je,
    block: u = je
}) {
    const h = le(n, !1),
        g = ot({
            url: n,
            type: e,
            delta: t == null ? void 0 : t.delta,
            intent: h
        });
    if (!g) {
        u();
        return
    }
    const d = A,
        _ = L;
    f(), K = !0, te && U.navigating.set(g.navigation), V = c;
    let l = h && await Pe(h);
    if (!l) {
        if (re(n, P)) return await C(n);
        l = await it(n, {
            id: null
        }, await $(new ve(404, "Not Found", `Not found: ${n.pathname}`), {
            url: n,
            params: {},
            route: {
                id: null
            }
        }), 404)
    }
    if (n = (h == null ? void 0 : h.url) || n, V !== c) return g.reject(new Error("navigation aborted")), !1;
    if (l.type === "redirect")
        if (i >= 20) l = await ce({
            status: 500,
            error: await $(new Error("Redirect loop"), {
                url: n,
                params: {},
                route: {
                    id: null
                }
            }),
            url: n,
            route: {
                id: null
            }
        });
        else return Re(new URL(l.location, n).href, {}, i + 1, c), !1;
    else l.props.page.status >= 400 && await U.updated.check() && await C(n);
    if (et(), Ee(d), tt(_), l.props.page.url.pathname !== n.pathname && (n.pathname = l.props.page.url.pathname), s = t ? t.state : s, !t) {
        const w = o ? 0 : 1,
            p = {
                [D]: A += w,
                [H]: L += w,
                [ze]: s
            };
        (o ? history.replaceState : history.pushState).call(history, p, "", n), o || zt(A, L)
    }
    if (R = null, l.props.page.state = s, te) {
        y = l.state, l.props.page && (l.props.page.url = n);
        const w = (await Promise.all(Yt.map(p => p(g.navigation)))).filter(p => typeof p == "function");
        if (w.length > 0) {
            let p = function() {
                N = N.filter(v => !w.includes(v))
            };
            w.push(p), N.push(...w)
        }
        se.$set(l.props), Ze = !0
    } else at(l, ye, !1);
    const {
        activeElement: m
    } = document;
    await ut();
    const b = t ? t.scroll : r ? ke() : null;
    if (De) {
        const w = n.hash && document.getElementById(decodeURIComponent(n.hash.slice(1)));
        b ? scrollTo(b.x, b.y) : w ? w.scrollIntoView() : scrollTo(0, 0)
    }
    const S = document.activeElement !== m && document.activeElement !== document.body;
    !a && !S && nn(), De = !0, l.props.page && (I = l.props.page), K = !1, e === "popstate" && nt(L), g.fulfil(void 0), N.forEach(w => w(g.navigation)), U.navigating.set(null)
}
async function it(e, n, t, a) {
    return e.origin === z && e.pathname === location.pathname && !Se ? await ce({
        status: a,
        error: t,
        url: e,
        route: n
    }) : await C(e)
}

function Zt() {
    let e;
    T.addEventListener("mousemove", o => {
        const s = o.target;
        clearTimeout(e), e = setTimeout(() => {
            a(s, 2)
        }, 20)
    });

    function n(o) {
        a(o.composedPath()[0], 1)
    }
    T.addEventListener("mousedown", n), T.addEventListener("touchstart", n, {
        passive: !0
    });
    const t = new IntersectionObserver(o => {
        for (const s of o) s.isIntersecting && (ge(s.target.href), t.unobserve(s.target))
    }, {
        threshold: 0
    });

    function a(o, s) {
        const i = Je(o, T);
        if (!i) return;
        const {
            url: c,
            external: f,
            download: u
        } = me(i, P);
        if (f || u) return;
        const h = J(i);
        if (!h.reload)
            if (s <= h.preload_data) {
                const g = le(c, !1);
                g && Wt(g)
            } else s <= h.preload_code && ge(c.pathname)
    }

    function r() {
        t.disconnect();
        for (const o of T.querySelectorAll("a")) {
            const {
                url: s,
                external: i,
                download: c
            } = me(o, P);
            if (i || c) continue;
            const f = J(o);
            f.reload || (f.preload_code === W.viewport && t.observe(o), f.preload_code === W.eager && ge(s.pathname))
        }
    }
    N.push(r), r()
}

function $(e, n) {
    if (e instanceof ae) return e.body;
    const t = X(e),
        a = Kt(e);
    return F.hooks.handleError({
        error: e,
        event: n,
        status: t,
        message: a
    }) ? ? {
        message: a
    }
}

function st(e, n) {
    dt(() => (e.push(n), () => {
        const t = e.indexOf(n);
        e.splice(t, 1)
    }))
}

function cn(e) {
    st(N, e)
}

function ln(e) {
    st(Ae, e)
}

function Qt(e, n = {}) {
    return e = Ye(e), e.origin !== z ? Promise.reject(new Error("goto: invalid URL")) : Re(e, n, 0)
}

function fn(e) {
    if (typeof e == "function") Q.push(e);
    else {
        const {
            href: n
        } = new URL(e, location.href);
        Q.push(t => t.href === n)
    }
    return Qe()
}

function un() {
    return ie = !0, Qe()
}

function en() {
    var n;
    history.scrollRestoration = "manual", addEventListener("beforeunload", t => {
        let a = !1;
        if ($e(), !K) {
            const r = ft(y, void 0, null, "leave"),
                o = { ...r.navigation,
                    cancel: () => {
                        a = !0, r.reject(new Error("navigation cancelled"))
                    }
                };
            Ae.forEach(s => s(o))
        }
        a ? (t.preventDefault(), t.returnValue = "") : history.scrollRestoration = "auto"
    }), addEventListener("visibilitychange", () => {
        document.visibilityState === "hidden" && $e()
    }), (n = navigator.connection) != null && n.saveData || Zt(), T.addEventListener("click", async t => {
        var g;
        if (t.button || t.which !== 1 || t.metaKey || t.ctrlKey || t.shiftKey || t.altKey || t.defaultPrevented) return;
        const a = Je(t.composedPath()[0], T);
        if (!a) return;
        const {
            url: r,
            external: o,
            target: s,
            download: i
        } = me(a, P);
        if (!r) return;
        if (s === "_parent" || s === "_top") {
            if (window.parent !== window) return
        } else if (s && s !== "_self") return;
        const c = J(a);
        if (!(a instanceof SVGAElement) && r.protocol !== location.protocol && !(r.protocol === "https:" || r.protocol === "http:") || i) return;
        if (o || c.reload) {
            ot({
                url: r,
                type: "link"
            }) ? K = !0 : t.preventDefault();
            return
        }
        const [u, h] = r.href.split("#");
        if (h !== void 0 && u === de(location)) {
            const [, d] = y.url.href.split("#");
            if (d === h) {
                t.preventDefault(), h === "" || h === "top" && a.ownerDocument.getElementById("top") === null ? window.scrollTo({
                    top: 0
                }) : (g = a.ownerDocument.getElementById(h)) == null || g.scrollIntoView();
                return
            }
            if (M = !0, Ee(A), e(r), !c.replace_state) return;
            M = !1
        }
        t.preventDefault(), await new Promise(d => {
            requestAnimationFrame(() => {
                setTimeout(d, 0)
            }), setTimeout(d, 100)
        }), Y({
            type: "link",
            url: r,
            keepfocus: c.keepfocus,
            noscroll: c.noscroll,
            replace_state: c.replace_state ? ? r.href === location.href
        })
    }), T.addEventListener("submit", t => {
        if (t.defaultPrevented) return;
        const a = HTMLFormElement.prototype.cloneNode.call(t.target),
            r = t.submitter;
        if (((r == null ? void 0 : r.formMethod) || a.method) !== "get") return;
        const s = new URL((r == null ? void 0 : r.hasAttribute("formaction")) && (r == null ? void 0 : r.formAction) || a.action);
        if (re(s, P)) return;
        const i = t.target,
            c = J(i);
        if (c.reload) return;
        t.preventDefault(), t.stopPropagation();
        const f = new FormData(i),
            u = r == null ? void 0 : r.getAttribute("name");
        u && f.append(u, (r == null ? void 0 : r.getAttribute("value")) ? ? ""), s.search = new URLSearchParams(f).toString(), Y({
            type: "form",
            url: s,
            keepfocus: c.keepfocus,
            noscroll: c.noscroll,
            replace_state: c.replace_state ? ? s.href === location.href
        })
    }), addEventListener("popstate", async t => {
        var a;
        if ((a = t.state) != null && a[D]) {
            const r = t.state[D];
            if (V = {}, r === A) return;
            const o = O[r],
                s = t.state[ze] ? ? {},
                i = new URL(t.state[Nt] ? ? location.href),
                c = t.state[H],
                f = de(location) === de(y.url);
            if (c === L && (Ze || f)) {
                e(i), O[A] = ke(), o && scrollTo(o.x, o.y), s !== I.state && (I = { ...I,
                    state: s
                }, se.$set({
                    page: I
                })), A = r;
                return
            }
            const h = r - A;
            await Y({
                type: "popstate",
                url: i,
                popped: {
                    state: s,
                    scroll: o,
                    delta: h
                },
                accept: () => {
                    A = r, L = c
                },
                block: () => {
                    history.go(-h)
                },
                nav_token: V
            })
        } else if (!M) {
            const r = new URL(location.href);
            e(r)
        }
    }), addEventListener("hashchange", () => {
        M && (M = !1, history.replaceState({ ...history.state,
            [D]: ++A,
            [H]: L
        }, "", location.href))
    });
    for (const t of document.querySelectorAll("link")) t.rel === "icon" && (t.href = t.href);
    addEventListener("pageshow", t => {
        t.persisted && U.navigating.set(null)
    });

    function e(t) {
        y.url = t, U.page.set({ ...I,
            url: t
        }), U.page.notify()
    }
}
async function tn(e, {
    status: n = 200,
    error: t,
    node_ids: a,
    params: r,
    route: o,
    data: s,
    form: i
}) {
    Se = !0;
    const c = new URL(location.href);
    ({
        params: r = {},
        route: o = {
            id: null
        }
    } = le(c, !1) || {});
    let f;
    try {
        const u = a.map(async (d, _) => {
                const l = s[_];
                return l != null && l.uses && (l.uses = lt(l.uses)), Ie({
                    loader: F.nodes[d],
                    url: c,
                    params: r,
                    route: o,
                    parent: async () => {
                        const m = {};
                        for (let b = 0; b < _; b += 1) Object.assign(m, (await u[b]).data);
                        return m
                    },
                    server_data_node: Le(l)
                })
            }),
            h = await Promise.all(u),
            g = oe.find(({
                id: d
            }) => d === o.id);
        if (g) {
            const d = g.layouts;
            for (let _ = 0; _ < d.length; _++) d[_] || h.splice(_, 0, void 0)
        }
        f = ne({
            url: c,
            params: r,
            branch: h,
            status: n,
            error: t,
            form: i,
            route: g ? ? null
        })
    } catch (u) {
        if (u instanceof qe) {
            await C(new URL(u.location, location.href));
            return
        }
        f = await ce({
            status: X(u),
            error: await $(u, {
                url: c,
                params: r,
                route: o
            }),
            url: c,
            route: o
        })
    }
    f.props.page && (f.props.page.state = {}), at(f, e, !0)
}
async function ct(e, n) {
    var r;
    const t = new URL(e);
    t.pathname = vt(e.pathname), e.pathname.endsWith("/") && t.searchParams.append(Bt, "1"), t.searchParams.append(Ht, n.map(o => o ? "1" : "0").join(""));
    const a = await Ge(t.href);
    if (!a.ok) {
        let o;
        throw (r = a.headers.get("content-type")) != null && r.includes("application/json") ? o = await a.json() : a.status === 404 ? o = "Not Found" : a.status === 500 && (o = "Internal Error"), new ae(a.status, o)
    }
    return new Promise(async o => {
        var h;
        const s = new Map,
            i = a.body.getReader(),
            c = new TextDecoder;

        function f(g) {
            return Mt(g, {
                Promise: d => new Promise((_, l) => {
                    s.set(d, {
                        fulfil: _,
                        reject: l
                    })
                })
            })
        }
        let u = "";
        for (;;) {
            const {
                done: g,
                value: d
            } = await i.read();
            if (g && !u) break;
            for (u += !d && u ? `
` : c.decode(d, {
                    stream: !0
                });;) {
                const _ = u.indexOf(`
`);
                if (_ === -1) break;
                const l = JSON.parse(u.slice(0, _));
                if (u = u.slice(_ + 1), l.type === "redirect") return o(l);
                if (l.type === "data")(h = l.nodes) == null || h.forEach(m => {
                    (m == null ? void 0 : m.type) === "data" && (m.uses = lt(m.uses), m.data = f(m.data))
                }), o(l);
                else if (l.type === "chunk") {
                    const {
                        id: m,
                        data: b,
                        error: S
                    } = l, w = s.get(m);
                    s.delete(m), S ? w.reject(f(S)) : w.fulfil(f(b))
                }
            }
        }
    })
}

function lt(e) {
    return {
        dependencies: new Set((e == null ? void 0 : e.dependencies) ? ? []),
        params: new Set((e == null ? void 0 : e.params) ? ? []),
        parent: !!(e != null && e.parent),
        route: !!(e != null && e.route),
        url: !!(e != null && e.url),
        search_params: new Set((e == null ? void 0 : e.search_params) ? ? [])
    }
}

function nn() {
    const e = document.querySelector("[autofocus]");
    if (e) e.focus();
    else {
        const n = document.body,
            t = n.getAttribute("tabindex");
        n.tabIndex = -1, n.focus({
            preventScroll: !0,
            focusVisible: !1
        }), t !== null ? n.setAttribute("tabindex", t) : n.removeAttribute("tabindex");
        const a = getSelection();
        if (a && a.type !== "None") {
            const r = [];
            for (let o = 0; o < a.rangeCount; o += 1) r.push(a.getRangeAt(o));
            setTimeout(() => {
                if (a.rangeCount === r.length) {
                    for (let o = 0; o < a.rangeCount; o += 1) {
                        const s = r[o],
                            i = a.getRangeAt(o);
                        if (s.commonAncestorContainer !== i.commonAncestorContainer || s.startContainer !== i.startContainer || s.endContainer !== i.endContainer || s.startOffset !== i.startOffset || s.endOffset !== i.endOffset) return
                    }
                    a.removeAllRanges()
                }
            })
        }
    }
}

function ft(e, n, t, a) {
    var c, f;
    let r, o;
    const s = new Promise((u, h) => {
        r = u, o = h
    });
    return s.catch(() => {}), {
        navigation: {
            from: {
                params: e.params,
                route: {
                    id: ((c = e.route) == null ? void 0 : c.id) ? ? null
                },
                url: e.url
            },
            to: t && {
                params: (n == null ? void 0 : n.params) ? ? null,
                route: {
                    id: ((f = n == null ? void 0 : n.route) == null ? void 0 : f.id) ? ? null
                },
                url: t
            },
            willUnload: !n,
            type: a,
            complete: s
        },
        fulfil: r,
        reject: o
    }
}
export {
    cn as a, ln as b, un as c, sn as d, Qt as g, fn as i, U as s, xt as v
};