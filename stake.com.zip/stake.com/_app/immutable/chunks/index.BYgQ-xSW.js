import {
    s as se,
    K,
    L as v,
    c as J,
    X as ke,
    M as Me,
    n as ue,
    p as Ee,
    T as Ne,
    m as C,
    j as k,
    i as M,
    a as ae,
    u as le,
    g as ce,
    b as ie,
    O as Te,
    P as qe,
    t as Ae,
    h as We,
    l as Ie
} from "./scheduler.DXu26z7T.js";
import {
    S as Se,
    i as Pe,
    c as W,
    a as I,
    m as S,
    t as _,
    b as g,
    d as P,
    g as fe,
    e as me
} from "./index.Dz_MmNB3.js";
import {
    g as je,
    a as Be
} from "./spread.CgU5AtxT.js";
import "./index.B3dW9TVs.js";
import {
    a as Fe
} from "./index.Dx3GbCCc.js";
import {
    C as Ve
} from "./index.DYe64iMk.js";
import {
    C as ze
} from "./index.Na6KaqFL.js";
import {
    h as De,
    R as w,
    G as Ge,
    i as Je,
    Q as x,
    J as $,
    P as h,
    au as Ke
} from "./index.B4-7gKq3.js";
import {
    B as Le
} from "./button.BwmFDw8u.js";
const ee = {
        max: De._("Max")
    },
    Oe = s => ({}),
    te = s => ({}),
    Qe = s => ({}),
    re = s => ({});

function Re(s) {
    let t, r;
    return t = new ze({
        props: {
            currency: s[9] !== "crypto" ? s[9] : s[1]
        }
    }), {
        c() {
            W(t.$$.fragment)
        },
        l(e) {
            I(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const o = {};
            n[0] & 514 && (o.currency = e[9] !== "crypto" ? e[9] : e[1]), t.$set(o)
        },
        i(e) {
            r || (_(t.$$.fragment, e), r = !0)
        },
        o(e) {
            g(t.$$.fragment, e), r = !1
        },
        d(e) {
            P(t, e)
        }
    }
}

function Xe(s) {
    let t, r, e = Re(s);
    return {
        c() {
            e && e.c(), t = C()
        },
        l(n) {
            e && e.l(n), t = C()
        },
        m(n, o) {
            e && e.m(n, o), k(n, t, o), r = !0
        },
        p(n, o) {
            e.p(n, o)
        },
        i(n) {
            r || (_(e), r = !0)
        },
        o(n) {
            g(e), r = !1
        },
        d(n) {
            n && M(t), e && e.d(n)
        }
    }
}

function He(s) {
    let t;
    const r = s[23].label,
        e = ae(r, s, s[28], te);
    return {
        c() {
            e && e.c()
        },
        l(n) {
            e && e.l(n)
        },
        m(n, o) {
            e && e.m(n, o), t = !0
        },
        p(n, o) {
            e && e.p && (!t || o[0] & 268435456) && le(e, r, n, n[28], t ? ie(r, n[28], o, Oe) : ce(n[28]), te)
        },
        i(n) {
            t || (_(e, n), t = !0)
        },
        o(n) {
            g(e, n), t = !1
        },
        d(n) {
            e && e.d(n)
        }
    }
}

function Ue(s) {
    let t = `${s[13]}_${s[1]}`,
        r, e, n = ne(s);
    return {
        c() {
            n.c(), r = C()
        },
        l(o) {
            n.l(o), r = C()
        },
        m(o, a) {
            n.m(o, a), k(o, r, a), e = !0
        },
        p(o, a) {
            a[0] & 8194 && se(t, t = `${o[13]}_${o[1]}`) ? (fe(), g(n, 1, 1, ue), me(), n = ne(o), n.c(), _(n, 1), n.m(r.parentNode, r)) : n.p(o, a)
        },
        i(o) {
            e || (_(n), e = !0)
        },
        o(o) {
            g(n), e = !1
        },
        d(o) {
            o && M(r), n.d(o)
        }
    }
}

function ne(s) {
    let t, r;
    return t = new Ve({
        props: {
            amount: Number(s[13]),
            truncateMaxWidth: s[8],
            currency: s[1],
            roundingType: s[7],
            "data-dd-privacy": s[17]["data-dd-privacy"] ? ? void 0
        }
    }), {
        c() {
            W(t.$$.fragment)
        },
        l(e) {
            I(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const o = {};
            n[0] & 8192 && (o.amount = Number(e[13])), n[0] & 256 && (o.truncateMaxWidth = e[8]), n[0] & 2 && (o.currency = e[1]), n[0] & 128 && (o.roundingType = e[7]), n[0] & 131072 && (o["data-dd-privacy"] = e[17]["data-dd-privacy"] ? ? void 0), t.$set(o)
        },
        i(e) {
            r || (_(t.$$.fragment, e), r = !0)
        },
        o(e) {
            g(t.$$.fragment, e), r = !1
        },
        d(e) {
            P(t, e)
        }
    }
}

function Ye(s) {
    let t, r, e = Ue(s);
    return {
        c() {
            e && e.c(), t = C()
        },
        l(n) {
            e && e.l(n), t = C()
        },
        m(n, o) {
            e && e.m(n, o), k(n, t, o), r = !0
        },
        p(n, o) {
            e.p(n, o)
        },
        i(n) {
            r || (_(e), r = !0)
        },
        o(n) {
            g(e), r = !1
        },
        d(n) {
            n && M(t), e && e.d(n)
        }
    }
}

function oe(s) {
    let t, r;
    return t = new Le({
        props: {
            type: "button",
            variant: "neutral",
            size: "sm",
            class: "shadow-none",
            disabled: s[4],
            $$slots: {
                default: [Ze]
            },
            $$scope: {
                ctx: s
            }
        }
    }), t.$on("click", s[24]), {
        c() {
            W(t.$$.fragment)
        },
        l(e) {
            I(t.$$.fragment, e)
        },
        m(e, n) {
            S(t, e, n), r = !0
        },
        p(e, n) {
            const o = {};
            n[0] & 16 && (o.disabled = e[4]), n[0] & 268451840 && (o.$$scope = {
                dirty: n,
                ctx: e
            }), t.$set(o)
        },
        i(e) {
            r || (_(t.$$.fragment, e), r = !0)
        },
        o(e) {
            g(t.$$.fragment, e), r = !1
        },
        d(e) {
            P(t, e)
        }
    }
}

function Ze(s) {
    let t = s[14]._(ee.max) + "",
        r;
    return {
        c() {
            r = Ae(t)
        },
        l(e) {
            r = We(e, t)
        },
        m(e, n) {
            k(e, r, n)
        },
        p(e, n) {
            n[0] & 16384 && t !== (t = e[14]._(ee.max) + "") && Ie(r, t)
        },
        d(e) {
            e && M(r)
        }
    }
}

function ve(s) {
    let t, r, e;
    const n = s[23].buttons,
        o = ae(n, s, s[28], re);
    let a = s[3] && oe(s);
    return {
        c() {
            o && o.c(), t = Te(), a && a.c(), r = C()
        },
        l(l) {
            o && o.l(l), t = qe(l), a && a.l(l), r = C()
        },
        m(l, f) {
            o && o.m(l, f), k(l, t, f), a && a.m(l, f), k(l, r, f), e = !0
        },
        p(l, f) {
            o && o.p && (!e || f[0] & 268435456) && le(o, n, l, l[28], e ? ie(n, l[28], f, Qe) : ce(l[28]), re), l[3] ? a ? (a.p(l, f), f[0] & 8 && _(a, 1)) : (a = oe(l), a.c(), _(a, 1), a.m(r.parentNode, r)) : a && (fe(), g(a, 1, 1, () => {
                a = null
            }), me())
        },
        i(l) {
            e || (_(o, l), _(a), e = !0)
        },
        o(l) {
            g(o, l), g(a), e = !1
        },
        d(l) {
            l && (M(t), M(r)), o && o.d(l), a && a.d(l)
        }
    }
}

function we(s) {
    let t, r;
    const e = [s[17], {
        required: s[5]
    }, {
        tooltipError: s[6]
    }, {
        type: "number"
    }, {
        value: s[10]
    }, {
        disabled: s[4]
    }, {
        errorMessage: s[2]
    }, {
        step: s[12]
    }];
    let n = {
        $$slots: {
            buttons: [ve],
            "label-right": [Ye],
            label: [He],
            iconAfter: [Xe]
        },
        $$scope: {
            ctx: s
        }
    };
    for (let o = 0; o < e.length; o += 1) n = K(n, e[o]);
    return t = new Fe({
        props: n
    }), t.$on("focus", s[25]), t.$on("blur", s[26]), t.$on("input", s[27]), {
        c() {
            W(t.$$.fragment)
        },
        l(o) {
            I(t.$$.fragment, o)
        },
        m(o, a) {
            S(t, o, a), r = !0
        },
        p(o, a) {
            const l = a[0] & 136308 ? je(e, [a[0] & 131072 && Be(o[17]), a[0] & 32 && {
                required: o[5]
            }, a[0] & 64 && {
                tooltipError: o[6]
            }, e[3], a[0] & 1024 && {
                value: o[10]
            }, a[0] & 16 && {
                disabled: o[4]
            }, a[0] & 4 && {
                errorMessage: o[2]
            }, a[0] & 4096 && {
                step: o[12]
            }]) : {};
            a[0] & 268592026 && (l.$$scope = {
                dirty: a,
                ctx: o
            }), t.$set(l)
        },
        i(o) {
            r || (_(t.$$.fragment, o), r = !0)
        },
        o(o) {
            g(t.$$.fragment, o), r = !1
        },
        d(o) {
            P(t, o)
        }
    }
}

function xe(s, t, r) {
    let e, n;
    const o = ["amount", "currency", "errorMessage", "maxEnabled", "disabled", "allowCurrencyChange", "required", "max", "tooltipError", "roundingType", "conversionMaxWidth"];
    let a = v(t, o),
        l, f = ue,
        L = () => (f(), f = Ee(y, u => r(13, l = u)), y),
        j, T, O;
    J(s, w, u => r(30, j = u)), J(s, Ge, u => r(22, T = u)), J(s, Je, u => r(14, O = u)), s.$$.on_destroy.push(() => f());
    let {
        $$slots: _e = {},
        $$scope: Q
    } = t, {
        amount: y
    } = t;
    L();
    let {
        currency: i
    } = t, {
        errorMessage: R
    } = t, {
        maxEnabled: X
    } = t, {
        disabled: B
    } = t, {
        allowCurrencyChange: F = !0
    } = t, {
        required: H = !1
    } = t, {
        max: E
    } = t, {
        tooltipError: U = !0
    } = t, {
        roundingType: d = "round"
    } = t, {
        conversionMaxWidth: Y = void 0
    } = t;
    const V = (u, p) => u !== "crypto" ? h(Number(l) * p, u, d) : h(Number(l), i, d),
        q = ke(),
        be = u => {
            var p, N;
            r(20, b = (N = (p = j.rates) == null ? void 0 : p[i]) == null ? void 0 : N[u]), r(10, m = V(u, b))
        };
    let c = x(T, i);
    const z = () => {
        var u, p;
        return c !== "crypto" ? (p = (u = j.rates) == null ? void 0 : u[i]) == null ? void 0 : p[c] : 1
    };
    let b = z();
    const Z = u => Math.round(Number(h(Number(u) * b, i, d)) * 100) / 100;
    let m = V(c, b),
        A = !1;
    $(w, ({
        current: u
    }) => {
        var p;
        if (c !== "crypto" && u.rates) {
            r(20, b = (p = u.rates) == null ? void 0 : p[i][c]);
            const N = h(Number(l) * b, c, d);
            N !== m && r(10, m = N)
        }
    });
    const ge = () => {
        r(20, b = z()), e = Z(E), Ne(y, l = h(0, i, d), l), r(10, m = h(0, c !== "crypto" ? c : i, d))
    };
    $(y, ({
        current: u
    }) => {
        A || r(10, m = c !== "crypto" ? h(Number(u) * b, c, d) : u)
    });
    let D = () => {
            c === "crypto" ? y.set(m) : e === Number(m) ? y.set(String(E)) : y.set(h(Number(m) / b, i, d))
        },
        G = i,
        de = () => F;
    const pe = () => q("max"),
        ye = u => {
            r(11, A = !0), q("focus", u.detail)
        },
        he = u => {
            r(11, A = !1), r(10, m = h(Number(m), c !== "crypto" ? c : i, d)), D(), q("blur", u.detail)
        },
        Ce = u => {
            r(10, m = u.detail.currentTarget.value), D()
        };
    return s.$$set = u => {
        t = K(K({}, t), Me(u)), r(17, a = v(t, o)), "amount" in u && L(r(0, y = u.amount)), "currency" in u && r(1, i = u.currency), "errorMessage" in u && r(2, R = u.errorMessage), "maxEnabled" in u && r(3, X = u.maxEnabled), "disabled" in u && r(4, B = u.disabled), "allowCurrencyChange" in u && r(18, F = u.allowCurrencyChange), "required" in u && r(5, H = u.required), "max" in u && r(19, E = u.max), "tooltipError" in u && r(6, U = u.tooltipError), "roundingType" in u && r(7, d = u.roundingType), "conversionMaxWidth" in u && r(8, Y = u.conversionMaxWidth), "$$scope" in u && r(28, Q = u.$$scope)
    }, s.$$.update = () => {
        s.$$.dirty[0] & 4194306 && r(9, c = x(T, i)), s.$$.dirty[0] & 512 && be(c), s.$$.dirty[0] & 524288 && (e = Z(E)), s.$$.dirty[0] & 3146258 && i !== G && (r(21, G = i), r(20, b = z()), B ? r(10, m = V(c, b)) : de() && ge()), s.$$.dirty[0] & 514 && r(12, n = Ke(c, i))
    }, [y, i, R, X, B, H, U, d, Y, c, m, A, n, l, O, q, D, a, F, E, b, G, T, _e, pe, ye, he, Ce, Q]
}
class lt extends Se {
    constructor(t) {
        super(), Pe(this, t, xe, we, se, {
            amount: 0,
            currency: 1,
            errorMessage: 2,
            maxEnabled: 3,
            disabled: 4,
            allowCurrencyChange: 18,
            required: 5,
            max: 19,
            tooltipError: 6,
            roundingType: 7,
            conversionMaxWidth: 8
        }, null, [-1, -1])
    }
}
export {
    lt as A
};