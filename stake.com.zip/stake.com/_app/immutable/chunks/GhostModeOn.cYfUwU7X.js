import {
    s as h,
    C as u,
    H as v,
    D as f,
    f as m,
    E as d,
    i as r,
    F as n,
    j as _,
    n as o
} from "./scheduler.DXu26z7T.js";
import {
    S as g,
    i as H
} from "./index.Dz_MmNB3.js";

function y(c) {
    let l, s, a = ` <title>${c[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M42.05 8.613c2.815 0 5.192 1.879 5.955 4.494l3.64 12.792H12.253l3.64-12.792.01-.044a6.197 6.197 0 0 1 5.944-4.45H42.05ZM61.488 30.77H2.461a2.461 2.461 0 0 0 0 4.921c8.873 1.271 19.12 1.997 29.539 1.997s20.664-.726 30.696-2.131l-.598.068a2.461 2.461 0 0 0-.56-4.858l-.05.003ZM33.484 43.074h-3.05c-6.335-1.515-13.677-1.22-21.547 0v2.501l3.05.58s0 9.233 9.233 9.233c6.223 0 8.247-5.583 8.908-9.233h3.721c.661 3.65 2.685 9.233 8.908 9.233 9.233 0 9.233-9.233 9.233-9.233l3.05-.58v-2.501c-7.718-1.24-15.008-1.485-21.506 0Z"></path>`,
        i;
    return {
        c() {
            l = u("svg"), s = new v(!0), this.h()
        },
        l(t) {
            l = f(t, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var e = m(l);
            s = d(e, !0), e.forEach(r), this.h()
        },
        h() {
            s.a = null, n(l, "fill", "currentColor"), n(l, "viewBox", "0 0 64 64"), n(l, "class", i = "svg-icon " + c[2]), n(l, "style", c[0])
        },
        m(t, e) {
            _(t, l, e), s.m(a, l)
        },
        p(t, [e]) {
            e & 2 && a !== (a = ` <title>${t[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M42.05 8.613c2.815 0 5.192 1.879 5.955 4.494l3.64 12.792H12.253l3.64-12.792.01-.044a6.197 6.197 0 0 1 5.944-4.45H42.05ZM61.488 30.77H2.461a2.461 2.461 0 0 0 0 4.921c8.873 1.271 19.12 1.997 29.539 1.997s20.664-.726 30.696-2.131l-.598.068a2.461 2.461 0 0 0-.56-4.858l-.05.003ZM33.484 43.074h-3.05c-6.335-1.515-13.677-1.22-21.547 0v2.501l3.05.58s0 9.233 9.233 9.233c6.223 0 8.247-5.583 8.908-9.233h3.721c.661 3.65 2.685 9.233 8.908 9.233 9.233 0 9.233-9.233 9.233-9.233l3.05-.58v-2.501c-7.718-1.24-15.008-1.485-21.506 0Z"></path>`) && s.p(a), e & 4 && i !== (i = "svg-icon " + t[2]) && n(l, "class", i), e & 1 && n(l, "style", t[0])
        },
        i: o,
        o,
        d(t) {
            t && r(l)
        }
    }
}

function M(c, l, s) {
    let {
        style: a = ""
    } = l, {
        alt: i = ""
    } = l, {
        class: t = ""
    } = l;
    return c.$$set = e => {
        "style" in e && s(0, a = e.style), "alt" in e && s(1, i = e.alt), "class" in e && s(2, t = e.class)
    }, [a, i, t]
}
class C extends g {
    constructor(l) {
        super(), H(this, l, M, y, h, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    C as G
};