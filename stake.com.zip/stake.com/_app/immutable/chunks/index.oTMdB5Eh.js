import {
    v as Q,
    x as X,
    s as Y,
    a as z,
    K as S,
    e as P,
    O as A,
    d as y,
    f as D,
    P as B,
    i as _,
    Q as I,
    V as d,
    F as T,
    j as M,
    k,
    u as O,
    g as C,
    b as L,
    L as R,
    c as G,
    M as J
} from "./scheduler.DXu26z7T.js";
import {
    S as U,
    i as W,
    t as h,
    g as Z,
    b as E,
    e as w,
    c as x,
    a as $,
    m as ee,
    d as te
} from "./index.Dz_MmNB3.js";
import {
    g as se
} from "./spread.CgU5AtxT.js";
import {
    w as ae
} from "./index.C2-CG2CN.js";
import {
    M as ne
} from "./index.CVJ30NdW.js";
const N = "@table_row",
    be = () => {
        X(N).flip()
    },
    oe = () => {
        const n = ae("odd"),
            t = { ...n,
                flip: () => n.update(e => e === "even" ? "odd" : "even")
            };
        return Q(N, t), t
    },
    le = n => ({}),
    j = n => ({}),
    ie = n => ({}),
    q = n => ({}),
    fe = n => ({}),
    F = n => ({});

function de(n) {
    let t, e;
    const m = n[11].head,
        o = z(m, n, n[10], q);
    return {
        c() {
            t = P("thead"), o && o.c()
        },
        l(i) {
            t = y(i, "THEAD", {});
            var l = D(t);
            o && o.l(l), l.forEach(_)
        },
        m(i, l) {
            M(i, t, l), o && o.m(t, null), e = !0
        },
        p(i, l) {
            o && o.p && (!e || l & 1024) && O(o, m, i, i[10], e ? L(m, i[10], l, ie) : C(i[10]), q)
        },
        i(i) {
            e || (h(o, i), e = !0)
        },
        o(i) {
            E(o, i), e = !1
        },
        d(i) {
            i && _(t), o && o.d(i)
        }
    }
}

function K(n) {
    let t, e, m;
    return e = new ne({}), {
        c() {
            t = P("div"), x(e.$$.fragment), this.h()
        },
        l(o) {
            t = y(o, "DIV", {
                class: !0
            });
            var i = D(t);
            $(e.$$.fragment, i), i.forEach(_), this.h()
        },
        h() {
            T(t, "class", "overlay-loader svelte-1lzsrn5")
        },
        m(o, i) {
            M(o, t, i), ee(e, t, null), m = !0
        },
        i(o) {
            m || (h(e.$$.fragment, o), m = !0)
        },
        o(o) {
            E(e.$$.fragment, o), m = !1
        },
        d(o) {
            o && _(t), te(e)
        }
    }
}

function re(n) {
    let t, e, m, o, i, l;
    const b = n[11].thead,
        g = z(b, n, n[10], F),
        r = g || de(n),
        v = n[11].body,
        c = z(v, n, n[10], j);
    let p = [n[9]],
        u = {};
    for (let a = 0; a < p.length; a += 1) u = S(u, p[a]);
    let f = n[6] && K();
    return {
        c() {
            t = P("div"), e = P("table"), r && r.c(), m = A(), o = P("tbody"), c && c.c(), i = A(), f && f.c(), this.h()
        },
        l(a) {
            t = y(a, "DIV", {
                class: !0
            });
            var s = D(t);
            e = y(s, "TABLE", {
                class: !0
            });
            var H = D(e);
            r && r.l(H), m = B(H), o = y(H, "TBODY", {});
            var V = D(o);
            c && c.l(V), V.forEach(_), H.forEach(_), i = B(s), f && f.l(s), s.forEach(_), this.h()
        },
        h() {
            I(o, u), d(o, "svelte-1lzsrn5", !0), T(e, "class", "table-content svelte-1lzsrn5"), d(e, "is-fixed", n[1]), d(e, "noHeadingPadding", n[4]), d(e, "slim", n[0]), d(e, "stripey", n[2]), d(e, "animate", n[3]), d(e, "slideDownEven", n[7] === "even"), d(e, "slideDownOdd", n[7] === "odd"), d(e, "compact", n[5] === "compact"), T(t, "class", "table-wrapper scrollX svelte-1lzsrn5"), d(t, "loading", n[6])
        },
        m(a, s) {
            M(a, t, s), k(t, e), r && r.m(e, null), k(e, m), k(e, o), c && c.m(o, null), k(t, i), f && f.m(t, null), l = !0
        },
        p(a, [s]) {
            g ? g.p && (!l || s & 1024) && O(g, b, a, a[10], l ? L(b, a[10], s, fe) : C(a[10]), F) : r && r.p && (!l || s & 1024) && r.p(a, l ? s : -1), c && c.p && (!l || s & 1024) && O(c, v, a, a[10], l ? L(v, a[10], s, le) : C(a[10]), j), I(o, u = se(p, [s & 512 && a[9]])), d(o, "svelte-1lzsrn5", !0), (!l || s & 2) && d(e, "is-fixed", a[1]), (!l || s & 16) && d(e, "noHeadingPadding", a[4]), (!l || s & 1) && d(e, "slim", a[0]), (!l || s & 4) && d(e, "stripey", a[2]), (!l || s & 8) && d(e, "animate", a[3]), (!l || s & 128) && d(e, "slideDownEven", a[7] === "even"), (!l || s & 128) && d(e, "slideDownOdd", a[7] === "odd"), (!l || s & 32) && d(e, "compact", a[5] === "compact"), a[6] ? f ? s & 64 && h(f, 1) : (f = K(), f.c(), h(f, 1), f.m(t, null)) : f && (Z(), E(f, 1, 1, () => {
                f = null
            }), w()), (!l || s & 64) && d(t, "loading", a[6])
        },
        i(a) {
            l || (h(r, a), h(c, a), h(f), l = !0)
        },
        o(a) {
            E(r, a), E(c, a), E(f), l = !1
        },
        d(a) {
            a && _(t), r && r.d(a), c && c.d(a), f && f.d()
        }
    }
}

function ce(n, t, e) {
    const m = ["slim", "fixed", "stripey", "animate", "noHeadingPadding", "spacing", "loading"];
    let o = R(t, m),
        i, {
            $$slots: l = {},
            $$scope: b
        } = t,
        {
            slim: g = !1
        } = t,
        {
            fixed: r = !1
        } = t,
        {
            stripey: v = !0
        } = t,
        {
            animate: c = !0
        } = t,
        {
            noHeadingPadding: p = !1
        } = t,
        {
            spacing: u = "normal"
        } = t,
        {
            loading: f = !1
        } = t;
    const a = oe();
    return G(n, a, s => e(7, i = s)), n.$$set = s => {
        t = S(S({}, t), J(s)), e(9, o = R(t, m)), "slim" in s && e(0, g = s.slim), "fixed" in s && e(1, r = s.fixed), "stripey" in s && e(2, v = s.stripey), "animate" in s && e(3, c = s.animate), "noHeadingPadding" in s && e(4, p = s.noHeadingPadding), "spacing" in s && e(5, u = s.spacing), "loading" in s && e(6, f = s.loading), "$$scope" in s && e(10, b = s.$$scope)
    }, [g, r, v, c, p, u, f, i, a, o, b, l]
}
class ve extends U {
    constructor(t) {
        super(), W(this, t, ce, re, Y, {
            slim: 0,
            fixed: 1,
            stripey: 2,
            animate: 3,
            noHeadingPadding: 4,
            spacing: 5,
            loading: 6
        })
    }
}
export {
    ve as T, be as r
};