import {
    c as y,
    d,
    e as i,
    f as h,
    g as w,
    h as I
} from "./tslib.es6.CYhxggkG.js";
import {
    a as u,
    e as v,
    O as l,
    r as S
} from "./dateTimestampProvider.DBRuHdww.js";
var g = function(e) {
    return e && typeof e.length == "number" && typeof e != "function"
};

function A(e) {
    return u(e == null ? void 0 : e.then)
}

function k(e) {
    return u(e[v])
}

function x(e) {
    return Symbol.asyncIterator && u(e == null ? void 0 : e[Symbol.asyncIterator])
}

function L(e) {
    return new TypeError("You provided " + (e !== null && typeof e == "object" ? "an invalid object" : "'" + e + "'") + " where a stream was expected. You can provide an Observable, Promise, ReadableStream, Array, AsyncIterable, or Iterable.")
}

function p() {
    return typeof Symbol != "function" || !Symbol.iterator ? "@@iterator" : Symbol.iterator
}
var O = p();

function b(e) {
    return u(e == null ? void 0 : e[O])
}

function R(e) {
    return y(this, arguments, function() {
        var r, a, o, s;
        return d(this, function(t) {
            switch (t.label) {
                case 0:
                    r = e.getReader(), t.label = 1;
                case 1:
                    t.trys.push([1, , 9, 10]), t.label = 2;
                case 2:
                    return [4, i(r.read())];
                case 3:
                    return a = t.sent(), o = a.value, s = a.done, s ? [4, i(void 0)] : [3, 5];
                case 4:
                    return [2, t.sent()];
                case 5:
                    return [4, i(o)];
                case 6:
                    return [4, t.sent()];
                case 7:
                    return t.sent(), [3, 2];
                case 8:
                    return [3, 10];
                case 9:
                    return r.releaseLock(), [7];
                case 10:
                    return [2]
            }
        })
    })
}

function T(e) {
    return u(e == null ? void 0 : e.getReader)
}

function z(e) {
    if (e instanceof l) return e;
    if (e != null) {
        if (k(e)) return E(e);
        if (g(e)) return P(e);
        if (A(e)) return G(e);
        if (x(e)) return m(e);
        if (b(e)) return F(e);
        if (T(e)) return Y(e)
    }
    throw L(e)
}

function E(e) {
    return new l(function(n) {
        var r = e[v]();
        if (u(r.subscribe)) return r.subscribe(n);
        throw new TypeError("Provided object does not correctly implement Symbol.observable")
    })
}

function P(e) {
    return new l(function(n) {
        for (var r = 0; r < e.length && !n.closed; r++) n.next(e[r]);
        n.complete()
    })
}

function G(e) {
    return new l(function(n) {
        e.then(function(r) {
            n.closed || (n.next(r), n.complete())
        }, function(r) {
            return n.error(r)
        }).then(null, S)
    })
}

function F(e) {
    return new l(function(n) {
        var r, a;
        try {
            for (var o = h(e), s = o.next(); !s.done; s = o.next()) {
                var t = s.value;
                if (n.next(t), n.closed) return
            }
        } catch (f) {
            r = {
                error: f
            }
        } finally {
            try {
                s && !s.done && (a = o.return) && a.call(o)
            } finally {
                if (r) throw r.error
            }
        }
        n.complete()
    })
}

function m(e) {
    return new l(function(n) {
        U(e, n).catch(function(r) {
            return n.error(r)
        })
    })
}

function Y(e) {
    return m(R(e))
}

function U(e, n) {
    var r, a, o, s;
    return w(this, void 0, void 0, function() {
        var t, f;
        return d(this, function(c) {
            switch (c.label) {
                case 0:
                    c.trys.push([0, 5, 6, 11]), r = I(e), c.label = 1;
                case 1:
                    return [4, r.next()];
                case 2:
                    if (a = c.sent(), !!a.done) return [3, 4];
                    if (t = a.value, n.next(t), n.closed) return [2];
                    c.label = 3;
                case 3:
                    return [3, 1];
                case 4:
                    return [3, 11];
                case 5:
                    return f = c.sent(), o = {
                        error: f
                    }, [3, 11];
                case 6:
                    return c.trys.push([6, , 9, 10]), a && !a.done && (s = r.return) ? [4, s.call(r)] : [3, 8];
                case 7:
                    c.sent(), c.label = 8;
                case 8:
                    return [3, 10];
                case 9:
                    if (o) throw o.error;
                    return [7];
                case 10:
                    return [7];
                case 11:
                    return n.complete(), [2]
            }
        })
    })
}
export {
    O as a, k as b, g as c, A as d, x as e, b as f, T as g, L as h, z as i, R as r
};