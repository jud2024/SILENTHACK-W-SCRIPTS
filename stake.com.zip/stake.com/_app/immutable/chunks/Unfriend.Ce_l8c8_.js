import {
    s as u,
    C as v,
    H as f,
    D as h,
    f as m,
    E as d,
    i as r,
    F as c,
    j as _,
    n as o
} from "./scheduler.DXu26z7T.js";
import {
    S as g,
    i as y
} from "./index.Dz_MmNB3.js";

function H(n) {
    let e, s, a = ` <title>${n[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M37.8 19.5c0 7.788-6.312 14.1-14.1 14.1-7.788 0-14.1-6.312-14.1-14.1 0-7.788 6.312-14.1 14.1-14.1 7.788 0 14.1 6.312 14.1 14.1ZM24.2 48.7c0-3.6.8-7.2 2.4-10.4-1-.1-2-.2-3-.2-11.9 0-22 8.8-23.6 20.5h26.4c-1.4-3.1-2.2-6.5-2.2-9.9ZM64 45.2H31.3v6.9H64v-6.9Z"></path>`,
        i;
    return {
        c() {
            e = v("svg"), s = new f(!0), this.h()
        },
        l(l) {
            e = h(l, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var t = m(e);
            s = d(t, !0), t.forEach(r), this.h()
        },
        h() {
            s.a = null, c(e, "fill", "currentColor"), c(e, "viewBox", "0 0 64 64"), c(e, "class", i = "svg-icon " + n[2]), c(e, "style", n[0])
        },
        m(l, t) {
            _(l, e, t), s.m(a, e)
        },
        p(l, [t]) {
            t & 2 && a !== (a = ` <title>${l[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M37.8 19.5c0 7.788-6.312 14.1-14.1 14.1-7.788 0-14.1-6.312-14.1-14.1 0-7.788 6.312-14.1 14.1-14.1 7.788 0 14.1 6.312 14.1 14.1ZM24.2 48.7c0-3.6.8-7.2 2.4-10.4-1-.1-2-.2-3-.2-11.9 0-22 8.8-23.6 20.5h26.4c-1.4-3.1-2.2-6.5-2.2-9.9ZM64 45.2H31.3v6.9H64v-6.9Z"></path>`) && s.p(a), t & 4 && i !== (i = "svg-icon " + l[2]) && c(e, "class", i), t & 1 && c(e, "style", l[0])
        },
        i: o,
        o,
        d(l) {
            l && r(e)
        }
    }
}

function M(n, e, s) {
    let {
        style: a = ""
    } = e, {
        alt: i = ""
    } = e, {
        class: l = ""
    } = e;
    return n.$$set = t => {
        "style" in t && s(0, a = t.style), "alt" in t && s(1, i = t.alt), "class" in t && s(2, l = t.class)
    }, [a, i, l]
}
class C extends g {
    constructor(e) {
        super(), y(this, e, M, H, u, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    C as U
};