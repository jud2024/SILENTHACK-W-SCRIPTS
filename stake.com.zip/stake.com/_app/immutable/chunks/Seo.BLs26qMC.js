import {
    s as ve,
    m as A,
    e as E,
    a2 as we,
    d as v,
    i as k,
    F as a,
    k as U,
    n as j,
    c as D,
    j as b,
    H as ge,
    E as Ae,
    O as M,
    P as y,
    a1 as P
} from "./scheduler.DXu26z7T.js";
import {
    e as J
} from "./each.DvgCmocI.js";
import {
    S as Me,
    i as ye
} from "./index.Dz_MmNB3.js";
import {
    p as Se,
    i as Ge,
    ac as I,
    ax as O,
    ay as Le
} from "./index.B4-7gKq3.js";
import {
    A as z
} from "./index.B81orGJm.js";
var Ee = (n => (n.en = "en", n.ar = "ar", n.de = "de", n.es = "es", n.fr = "fr", n.id = "id", n.ja = "ja-jp", n.ko = "ko-kr", n.pl = "pl-pl", n.hi = "hi", n.pt = "pt", n.ru = "ru", n.tr = "tr-tr", n.vi = "vi-vn", n.zh = "zh", n.fi = "fi", n))(Ee || {});

function K(n, t, l) {
    const e = n.slice();
    return e[14] = t[l], e
}

function R(n, t, l) {
    const e = n.slice();
    return e[17] = t[l], e
}

function F(n, t, l) {
    const e = n.slice();
    return e[20] = t[l], e
}

function q(n, t, l) {
    const e = n.slice();
    return e[26] = t[l], e
}

function W(n, t, l) {
    const e = n.slice();
    return e[23] = t[l], e
}

function X(n) {
    let t;
    return {
        c() {
            t = E("link"), this.h()
        },
        l(l) {
            t = v(l, "LINK", {
                rel: !0,
                href: !0
            }), this.h()
        },
        h() {
            a(t, "rel", "canonical"), a(t, "href", n[11])
        },
        m(l, e) {
            b(l, t, e)
        },
        p(l, e) {
            e & 2048 && a(t, "href", l[11])
        },
        d(l) {
            l && k(t)
        }
    }
}

function Je(n) {
    let t, l, e, i = J(I.SUPPORTED_LANGUAGES),
        r = [];
    for (let f = 0; f < i.length; f += 1) r[f] = B(q(n, i, f));
    return {
        c() {
            t = E("link"), l = M();
            for (let f = 0; f < r.length; f += 1) r[f].c();
            e = A(), this.h()
        },
        l(f) {
            t = v(f, "LINK", {
                rel: !0,
                hreflang: !0,
                href: !0
            }), l = y(f);
            for (let _ = 0; _ < r.length; _ += 1) r[_].l(f);
            e = A(), this.h()
        },
        h() {
            a(t, "rel", "alternate"), a(t, "hreflang", "x-default"), a(t, "href", n[10])
        },
        m(f, _) {
            b(f, t, _), b(f, l, _);
            for (let c = 0; c < r.length; c += 1) r[c] && r[c].m(f, _);
            b(f, e, _)
        },
        p(f, _) {
            if (_ & 1024 && a(t, "href", f[10]), _ & 1024) {
                i = J(I.SUPPORTED_LANGUAGES);
                let c;
                for (c = 0; c < i.length; c += 1) {
                    const s = q(f, i, c);
                    r[c] ? r[c].p(s, _) : (r[c] = B(s), r[c].c(), r[c].m(e.parentNode, e))
                }
                for (; c < r.length; c += 1) r[c].d(1);
                r.length = i.length
            }
        },
        d(f) {
            f && (k(t), k(l), k(e)), P(r, f)
        }
    }
}

function Ue(n) {
    let t, l = J(n[6]),
        e = [];
    for (let i = 0; i < l.length; i += 1) e[i] = Q(W(n, l, i));
    return {
        c() {
            for (let i = 0; i < e.length; i += 1) e[i].c();
            t = A()
        },
        l(i) {
            for (let r = 0; r < e.length; r += 1) e[r].l(i);
            t = A()
        },
        m(i, r) {
            for (let f = 0; f < e.length; f += 1) e[f] && e[f].m(i, r);
            b(i, t, r)
        },
        p(i, r) {
            if (r & 64) {
                l = J(i[6]);
                let f;
                for (f = 0; f < l.length; f += 1) {
                    const _ = W(i, l, f);
                    e[f] ? e[f].p(_, r) : (e[f] = Q(_), e[f].c(), e[f].m(t.parentNode, t))
                }
                for (; f < e.length; f += 1) e[f].d(1);
                e.length = l.length
            }
        },
        d(i) {
            i && k(t), P(e, i)
        }
    }
}

function B(n) {
    let t, l;
    return {
        c() {
            t = E("link"), this.h()
        },
        l(e) {
            t = v(e, "LINK", {
                rel: !0,
                hreflang: !0,
                href: !0
            }), this.h()
        },
        h() {
            a(t, "rel", "alternate"), a(t, "hreflang", Ee[n[26]]), a(t, "href", l = O(n[10], n[26]))
        },
        m(e, i) {
            b(e, t, i)
        },
        p(e, i) {
            i & 1024 && l !== (l = O(e[10], e[26])) && a(t, "href", l)
        },
        d(e) {
            e && k(t)
        }
    }
}

function Q(n) {
    let t, l, e;
    return {
        c() {
            t = E("link"), this.h()
        },
        l(i) {
            t = v(i, "LINK", {
                rel: !0,
                hreflang: !0,
                href: !0
            }), this.h()
        },
        h() {
            var i, r;
            a(t, "rel", "alternate"), a(t, "hreflang", l = (i = n[23]) == null ? void 0 : i.hreflangName), a(t, "href", e = (r = n[23]) == null ? void 0 : r.href)
        },
        m(i, r) {
            b(i, t, r)
        },
        p(i, r) {
            var f, _;
            r & 64 && l !== (l = (f = i[23]) == null ? void 0 : f.hreflangName) && a(t, "hreflang", l), r & 64 && e !== (e = (_ = i[23]) == null ? void 0 : _.href) && a(t, "href", e)
        },
        d(i) {
            i && k(t)
        }
    }
}

function V(n) {
    let t, l;
    return {
        c() {
            t = new ge(!1), l = A(), this.h()
        },
        l(e) {
            t = Ae(e, !1), l = A(), this.h()
        },
        h() {
            t.a = l
        },
        m(e, i) {
            t.m(n[8], e, i), b(e, l, i)
        },
        p(e, i) {
            i & 256 && t.p(e[8])
        },
        d(e) {
            e && (k(l), t.d())
        }
    }
}

function Y(n) {
    let t, l;
    return {
        c() {
            t = new ge(!1), l = A(), this.h()
        },
        l(e) {
            t = Ae(e, !1), l = A(), this.h()
        },
        h() {
            t.a = l
        },
        m(e, i) {
            t.m(n[7], e, i), b(e, l, i)
        },
        p(e, i) {
            i & 128 && t.p(e[7])
        },
        d(e) {
            e && (k(l), t.d())
        }
    }
}

function Z(n) {
    let t, l;
    return {
        c() {
            t = E("meta"), this.h()
        },
        l(e) {
            t = v(e, "META", {
                name: !0,
                content: !0
            }), this.h()
        },
        h() {
            a(t, "name", "description"), a(t, "content", l = n[12]._(n[1]))
        },
        m(e, i) {
            b(e, t, i)
        },
        p(e, i) {
            i & 4098 && l !== (l = e[12]._(e[1])) && a(t, "content", l)
        },
        d(e) {
            e && k(t)
        }
    }
}

function H(n) {
    let t, l, e, i, r, f, _ = n[4].title && $(n);

    function c(h, N) {
        if (h[4].description) return ze;
        if (h[1]) return Pe
    }
    let s = c(n),
        m = s && s(n),
        u = (n[4].url || n[9]) && x(n),
        p = n[4].type && ee(n),
        o = n[4].article && te(n),
        d = n[4].images && n[4].images.length && ae(n);
    return {
        c() {
            _ && _.c(), t = M(), m && m.c(), l = M(), u && u.c(), e = M(), p && p.c(), i = M(), o && o.c(), r = M(), d && d.c(), f = A()
        },
        l(h) {
            _ && _.l(h), t = y(h), m && m.l(h), l = y(h), u && u.l(h), e = y(h), p && p.l(h), i = y(h), o && o.l(h), r = y(h), d && d.l(h), f = A()
        },
        m(h, N) {
            _ && _.m(h, N), b(h, t, N), m && m.m(h, N), b(h, l, N), u && u.m(h, N), b(h, e, N), p && p.m(h, N), b(h, i, N), o && o.m(h, N), b(h, r, N), d && d.m(h, N), b(h, f, N)
        },
        p(h, N) {
            h[4].title ? _ ? _.p(h, N) : (_ = $(h), _.c(), _.m(t.parentNode, t)) : _ && (_.d(1), _ = null), s === (s = c(h)) && m ? m.p(h, N) : (m && m.d(1), m = s && s(h), m && (m.c(), m.m(l.parentNode, l))), h[4].url || h[9] ? u ? u.p(h, N) : (u = x(h), u.c(), u.m(e.parentNode, e)) : u && (u.d(1), u = null), h[4].type ? p ? p.p(h, N) : (p = ee(h), p.c(), p.m(i.parentNode, i)) : p && (p.d(1), p = null), h[4].article ? o ? o.p(h, N) : (o = te(h), o.c(), o.m(r.parentNode, r)) : o && (o.d(1), o = null), h[4].images && h[4].images.length ? d ? d.p(h, N) : (d = ae(h), d.c(), d.m(f.parentNode, f)) : d && (d.d(1), d = null)
        },
        d(h) {
            h && (k(t), k(l), k(e), k(i), k(r), k(f)), _ && _.d(h), m && m.d(h), u && u.d(h), p && p.d(h), o && o.d(h), d && d.d(h)
        }
    }
}

function $(n) {
    let t, l;
    return {
        c() {
            t = E("meta"), this.h()
        },
        l(e) {
            t = v(e, "META", {
                property: !0,
                content: !0
            }), this.h()
        },
        h() {
            a(t, "property", "og:title"), a(t, "content", l = n[12]._(n[4].title))
        },
        m(e, i) {
            b(e, t, i)
        },
        p(e, i) {
            i & 4112 && l !== (l = e[12]._(e[4].title)) && a(t, "content", l)
        },
        d(e) {
            e && k(t)
        }
    }
}

function Pe(n) {
    let t, l;
    return {
        c() {
            t = E("meta"), this.h()
        },
        l(e) {
            t = v(e, "META", {
                property: !0,
                content: !0
            }), this.h()
        },
        h() {
            a(t, "property", "og:description"), a(t, "content", l = n[12]._(n[1]))
        },
        m(e, i) {
            b(e, t, i)
        },
        p(e, i) {
            i & 4098 && l !== (l = e[12]._(e[1])) && a(t, "content", l)
        },
        d(e) {
            e && k(t)
        }
    }
}

function ze(n) {
    let t, l;
    return {
        c() {
            t = E("meta"), this.h()
        },
        l(e) {
            t = v(e, "META", {
                property: !0,
                content: !0
            }), this.h()
        },
        h() {
            a(t, "property", "og:description"), a(t, "content", l = n[12]._(n[4].description))
        },
        m(e, i) {
            b(e, t, i)
        },
        p(e, i) {
            i & 4112 && l !== (l = e[12]._(e[4].description)) && a(t, "content", l)
        },
        d(e) {
            e && k(t)
        }
    }
}

function x(n) {
    let t, l;
    return {
        c() {
            t = E("meta"), this.h()
        },
        l(e) {
            t = v(e, "META", {
                property: !0,
                content: !0
            }), this.h()
        },
        h() {
            a(t, "property", "og:url"), a(t, "content", l = n[4].url || n[9])
        },
        m(e, i) {
            b(e, t, i)
        },
        p(e, i) {
            i & 528 && l !== (l = e[4].url || e[9]) && a(t, "content", l)
        },
        d(e) {
            e && k(t)
        }
    }
}

function ee(n) {
    let t, l;
    return {
        c() {
            t = E("meta"), this.h()
        },
        l(e) {
            t = v(e, "META", {
                property: !0,
                content: !0
            }), this.h()
        },
        h() {
            a(t, "property", "og:type"), a(t, "content", l = n[4].type.toLowerCase())
        },
        m(e, i) {
            b(e, t, i)
        },
        p(e, i) {
            i & 16 && l !== (l = e[4].type.toLowerCase()) && a(t, "content", l)
        },
        d(e) {
            e && k(t)
        }
    }
}

function te(n) {
    let t, l, e, i, r, f, _ = n[4].article.publishedTime && ie(n),
        c = n[4].article.modifiedTime && le(n),
        s = n[4].article.expirationTime && ne(n),
        m = n[4].article.section && fe(n),
        u = n[4].article.authors && n[4].article.authors.length && oe(n),
        p = n[4].article.tags && n[4].article.tags.length && _e(n);
    return {
        c() {
            _ && _.c(), t = M(), c && c.c(), l = M(), s && s.c(), e = M(), m && m.c(), i = M(), u && u.c(), r = M(), p && p.c(), f = A()
        },
        l(o) {
            _ && _.l(o), t = y(o), c && c.l(o), l = y(o), s && s.l(o), e = y(o), m && m.l(o), i = y(o), u && u.l(o), r = y(o), p && p.l(o), f = A()
        },
        m(o, d) {
            _ && _.m(o, d), b(o, t, d), c && c.m(o, d), b(o, l, d), s && s.m(o, d), b(o, e, d), m && m.m(o, d), b(o, i, d), u && u.m(o, d), b(o, r, d), p && p.m(o, d), b(o, f, d)
        },
        p(o, d) {
            o[4].article.publishedTime ? _ ? _.p(o, d) : (_ = ie(o), _.c(), _.m(t.parentNode, t)) : _ && (_.d(1), _ = null), o[4].article.modifiedTime ? c ? c.p(o, d) : (c = le(o), c.c(), c.m(l.parentNode, l)) : c && (c.d(1), c = null), o[4].article.expirationTime ? s ? s.p(o, d) : (s = ne(o), s.c(), s.m(e.parentNode, e)) : s && (s.d(1), s = null), o[4].article.section ? m ? m.p(o, d) : (m = fe(o), m.c(), m.m(i.parentNode, i)) : m && (m.d(1), m = null), o[4].article.authors && o[4].article.authors.length ? u ? u.p(o, d) : (u = oe(o), u.c(), u.m(r.parentNode, r)) : u && (u.d(1), u = null), o[4].article.tags && o[4].article.tags.length ? p ? p.p(o, d) : (p = _e(o), p.c(), p.m(f.parentNode, f)) : p && (p.d(1), p = null)
        },
        d(o) {
            o && (k(t), k(l), k(e), k(i), k(r), k(f)), _ && _.d(o), c && c.d(o), s && s.d(o), m && m.d(o), u && u.d(o), p && p.d(o)
        }
    }
}

function ie(n) {
    let t, l;
    return {
        c() {
            t = E("meta"), this.h()
        },
        l(e) {
            t = v(e, "META", {
                property: !0,
                content: !0
            }), this.h()
        },
        h() {
            a(t, "property", "article:published_time"), a(t, "content", l = n[4].article.publishedTime)
        },
        m(e, i) {
            b(e, t, i)
        },
        p(e, i) {
            i & 16 && l !== (l = e[4].article.publishedTime) && a(t, "content", l)
        },
        d(e) {
            e && k(t)
        }
    }
}

function le(n) {
    let t, l;
    return {
        c() {
            t = E("meta"), this.h()
        },
        l(e) {
            t = v(e, "META", {
                property: !0,
                content: !0
            }), this.h()
        },
        h() {
            a(t, "property", "article:modified_time"), a(t, "content", l = n[4].article.modifiedTime)
        },
        m(e, i) {
            b(e, t, i)
        },
        p(e, i) {
            i & 16 && l !== (l = e[4].article.modifiedTime) && a(t, "content", l)
        },
        d(e) {
            e && k(t)
        }
    }
}

function ne(n) {
    let t, l;
    return {
        c() {
            t = E("meta"), this.h()
        },
        l(e) {
            t = v(e, "META", {
                property: !0,
                content: !0
            }), this.h()
        },
        h() {
            a(t, "property", "article:expiration_time"), a(t, "content", l = n[4].article.expirationTime)
        },
        m(e, i) {
            b(e, t, i)
        },
        p(e, i) {
            i & 16 && l !== (l = e[4].article.expirationTime) && a(t, "content", l)
        },
        d(e) {
            e && k(t)
        }
    }
}

function fe(n) {
    let t, l;
    return {
        c() {
            t = E("meta"), this.h()
        },
        l(e) {
            t = v(e, "META", {
                property: !0,
                content: !0
            }), this.h()
        },
        h() {
            a(t, "property", "article:section"), a(t, "content", l = n[4].article.section)
        },
        m(e, i) {
            b(e, t, i)
        },
        p(e, i) {
            i & 16 && l !== (l = e[4].article.section) && a(t, "content", l)
        },
        d(e) {
            e && k(t)
        }
    }
}

function oe(n) {
    let t, l = J(n[4].article.authors),
        e = [];
    for (let i = 0; i < l.length; i += 1) e[i] = re(F(n, l, i));
    return {
        c() {
            for (let i = 0; i < e.length; i += 1) e[i].c();
            t = A()
        },
        l(i) {
            for (let r = 0; r < e.length; r += 1) e[r].l(i);
            t = A()
        },
        m(i, r) {
            for (let f = 0; f < e.length; f += 1) e[f] && e[f].m(i, r);
            b(i, t, r)
        },
        p(i, r) {
            if (r & 16) {
                l = J(i[4].article.authors);
                let f;
                for (f = 0; f < l.length; f += 1) {
                    const _ = F(i, l, f);
                    e[f] ? e[f].p(_, r) : (e[f] = re(_), e[f].c(), e[f].m(t.parentNode, t))
                }
                for (; f < e.length; f += 1) e[f].d(1);
                e.length = l.length
            }
        },
        d(i) {
            i && k(t), P(e, i)
        }
    }
}

function re(n) {
    let t, l;
    return {
        c() {
            t = E("meta"), this.h()
        },
        l(e) {
            t = v(e, "META", {
                property: !0,
                content: !0
            }), this.h()
        },
        h() {
            a(t, "property", "article:author"), a(t, "content", l = n[20])
        },
        m(e, i) {
            b(e, t, i)
        },
        p(e, i) {
            i & 16 && l !== (l = e[20]) && a(t, "content", l)
        },
        d(e) {
            e && k(t)
        }
    }
}

function _e(n) {
    let t, l = J(n[4].article.tags),
        e = [];
    for (let i = 0; i < l.length; i += 1) e[i] = me(R(n, l, i));
    return {
        c() {
            for (let i = 0; i < e.length; i += 1) e[i].c();
            t = A()
        },
        l(i) {
            for (let r = 0; r < e.length; r += 1) e[r].l(i);
            t = A()
        },
        m(i, r) {
            for (let f = 0; f < e.length; f += 1) e[f] && e[f].m(i, r);
            b(i, t, r)
        },
        p(i, r) {
            if (r & 16) {
                l = J(i[4].article.tags);
                let f;
                for (f = 0; f < l.length; f += 1) {
                    const _ = R(i, l, f);
                    e[f] ? e[f].p(_, r) : (e[f] = me(_), e[f].c(), e[f].m(t.parentNode, t))
                }
                for (; f < e.length; f += 1) e[f].d(1);
                e.length = l.length
            }
        },
        d(i) {
            i && k(t), P(e, i)
        }
    }
}

function me(n) {
    let t, l;
    return {
        c() {
            t = E("meta"), this.h()
        },
        l(e) {
            t = v(e, "META", {
                property: !0,
                content: !0
            }), this.h()
        },
        h() {
            a(t, "property", "article:tag"), a(t, "content", l = n[17])
        },
        m(e, i) {
            b(e, t, i)
        },
        p(e, i) {
            i & 16 && l !== (l = e[17]) && a(t, "content", l)
        },
        d(e) {
            e && k(t)
        }
    }
}

function ae(n) {
    let t, l = J(n[4].images),
        e = [];
    for (let i = 0; i < l.length; i += 1) e[i] = se(K(n, l, i));
    return {
        c() {
            for (let i = 0; i < e.length; i += 1) e[i].c();
            t = A()
        },
        l(i) {
            for (let r = 0; r < e.length; r += 1) e[r].l(i);
            t = A()
        },
        m(i, r) {
            for (let f = 0; f < e.length; f += 1) e[f] && e[f].m(i, r);
            b(i, t, r)
        },
        p(i, r) {
            if (r & 16) {
                l = J(i[4].images);
                let f;
                for (f = 0; f < l.length; f += 1) {
                    const _ = K(i, l, f);
                    e[f] ? e[f].p(_, r) : (e[f] = se(_), e[f].c(), e[f].m(t.parentNode, t))
                }
                for (; f < e.length; f += 1) e[f].d(1);
                e.length = l.length
            }
        },
        d(i) {
            i && k(t), P(e, i)
        }
    }
}

function ce(n) {
    let t, l;
    return {
        c() {
            t = E("meta"), this.h()
        },
        l(e) {
            t = v(e, "META", {
                property: !0,
                content: !0
            }), this.h()
        },
        h() {
            a(t, "property", "og:image:alt"), a(t, "content", l = n[14].alt)
        },
        m(e, i) {
            b(e, t, i)
        },
        p(e, i) {
            i & 16 && l !== (l = e[14].alt) && a(t, "content", l)
        },
        d(e) {
            e && k(t)
        }
    }
}

function he(n) {
    let t, l;
    return {
        c() {
            t = E("meta"), this.h()
        },
        l(e) {
            t = v(e, "META", {
                property: !0,
                content: !0
            }), this.h()
        },
        h() {
            a(t, "property", "og:image:width"), a(t, "content", l = n[14].width.toString())
        },
        m(e, i) {
            b(e, t, i)
        },
        p(e, i) {
            i & 16 && l !== (l = e[14].width.toString()) && a(t, "content", l)
        },
        d(e) {
            e && k(t)
        }
    }
}

function ue(n) {
    let t, l;
    return {
        c() {
            t = E("meta"), this.h()
        },
        l(e) {
            t = v(e, "META", {
                property: !0,
                content: !0
            }), this.h()
        },
        h() {
            a(t, "property", "og:image:height"), a(t, "content", l = n[14].height.toString())
        },
        m(e, i) {
            b(e, t, i)
        },
        p(e, i) {
            i & 16 && l !== (l = e[14].height.toString()) && a(t, "content", l)
        },
        d(e) {
            e && k(t)
        }
    }
}

function se(n) {
    let t, l, e, i, r, f, _ = n[14].alt && ce(n),
        c = n[14].width && he(n),
        s = n[14].height && ue(n);
    return {
        c() {
            t = E("meta"), e = M(), _ && _.c(), i = M(), c && c.c(), r = M(), s && s.c(), f = A(), this.h()
        },
        l(m) {
            t = v(m, "META", {
                property: !0,
                content: !0
            }), e = y(m), _ && _.l(m), i = y(m), c && c.l(m), r = y(m), s && s.l(m), f = A(), this.h()
        },
        h() {
            a(t, "property", "og:image"), a(t, "content", l = n[14].url)
        },
        m(m, u) {
            b(m, t, u), b(m, e, u), _ && _.m(m, u), b(m, i, u), c && c.m(m, u), b(m, r, u), s && s.m(m, u), b(m, f, u)
        },
        p(m, u) {
            u & 16 && l !== (l = m[14].url) && a(t, "content", l), m[14].alt ? _ ? _.p(m, u) : (_ = ce(m), _.c(), _.m(i.parentNode, i)) : _ && (_.d(1), _ = null), m[14].width ? c ? c.p(m, u) : (c = he(m), c.c(), c.m(r.parentNode, r)) : c && (c.d(1), c = null), m[14].height ? s ? s.p(m, u) : (s = ue(m), s.c(), s.m(f.parentNode, f)) : s && (s.d(1), s = null)
        },
        d(m) {
            m && (k(t), k(e), k(i), k(r), k(f)), _ && _.d(m), c && c.d(m), s && s.d(m)
        }
    }
}

function pe(n) {
    let t, l, e, i, r, f, _, c = n[5].site && de(n),
        s = n[5].title && ke(n),
        m = n[5].description && be(n),
        u = n[5].image && Ne(n),
        p = n[5].imageAlt && Te(n);
    return {
        c() {
            t = E("meta"), l = M(), c && c.c(), e = M(), s && s.c(), i = M(), m && m.c(), r = M(), u && u.c(), f = M(), p && p.c(), _ = A(), this.h()
        },
        l(o) {
            t = v(o, "META", {
                name: !0,
                content: !0
            }), l = y(o), c && c.l(o), e = y(o), s && s.l(o), i = y(o), m && m.l(o), r = y(o), u && u.l(o), f = y(o), p && p.l(o), _ = A(), this.h()
        },
        h() {
            a(t, "name", "twitter:card"), a(t, "content", "summary_large_image")
        },
        m(o, d) {
            b(o, t, d), b(o, l, d), c && c.m(o, d), b(o, e, d), s && s.m(o, d), b(o, i, d), m && m.m(o, d), b(o, r, d), u && u.m(o, d), b(o, f, d), p && p.m(o, d), b(o, _, d)
        },
        p(o, d) {
            o[5].site ? c ? c.p(o, d) : (c = de(o), c.c(), c.m(e.parentNode, e)) : c && (c.d(1), c = null), o[5].title ? s ? s.p(o, d) : (s = ke(o), s.c(), s.m(i.parentNode, i)) : s && (s.d(1), s = null), o[5].description ? m ? m.p(o, d) : (m = be(o), m.c(), m.m(r.parentNode, r)) : m && (m.d(1), m = null), o[5].image ? u ? u.p(o, d) : (u = Ne(o), u.c(), u.m(f.parentNode, f)) : u && (u.d(1), u = null), o[5].imageAlt ? p ? p.p(o, d) : (p = Te(o), p.c(), p.m(_.parentNode, _)) : p && (p.d(1), p = null)
        },
        d(o) {
            o && (k(t), k(l), k(e), k(i), k(r), k(f), k(_)), c && c.d(o), s && s.d(o), m && m.d(o), u && u.d(o), p && p.d(o)
        }
    }
}

function de(n) {
    let t, l;
    return {
        c() {
            t = E("meta"), this.h()
        },
        l(e) {
            t = v(e, "META", {
                name: !0,
                content: !0
            }), this.h()
        },
        h() {
            a(t, "name", "twitter:site"), a(t, "content", l = n[5].site)
        },
        m(e, i) {
            b(e, t, i)
        },
        p(e, i) {
            i & 32 && l !== (l = e[5].site) && a(t, "content", l)
        },
        d(e) {
            e && k(t)
        }
    }
}

function ke(n) {
    let t, l;
    return {
        c() {
            t = E("meta"), this.h()
        },
        l(e) {
            t = v(e, "META", {
                name: !0,
                content: !0
            }), this.h()
        },
        h() {
            a(t, "name", "twitter:title"), a(t, "content", l = n[5].title)
        },
        m(e, i) {
            b(e, t, i)
        },
        p(e, i) {
            i & 32 && l !== (l = e[5].title) && a(t, "content", l)
        },
        d(e) {
            e && k(t)
        }
    }
}

function be(n) {
    let t, l;
    return {
        c() {
            t = E("meta"), this.h()
        },
        l(e) {
            t = v(e, "META", {
                name: !0,
                content: !0
            }), this.h()
        },
        h() {
            a(t, "name", "twitter:description"), a(t, "content", l = n[5].description)
        },
        m(e, i) {
            b(e, t, i)
        },
        p(e, i) {
            i & 32 && l !== (l = e[5].description) && a(t, "content", l)
        },
        d(e) {
            e && k(t)
        }
    }
}

function Ne(n) {
    let t, l;
    return {
        c() {
            t = E("meta"), this.h()
        },
        l(e) {
            t = v(e, "META", {
                name: !0,
                content: !0
            }), this.h()
        },
        h() {
            a(t, "name", "twitter:image"), a(t, "content", l = n[5].image)
        },
        m(e, i) {
            b(e, t, i)
        },
        p(e, i) {
            i & 32 && l !== (l = e[5].image) && a(t, "content", l)
        },
        d(e) {
            e && k(t)
        }
    }
}

function Te(n) {
    let t, l;
    return {
        c() {
            t = E("meta"), this.h()
        },
        l(e) {
            t = v(e, "META", {
                name: !0,
                content: !0
            }), this.h()
        },
        h() {
            a(t, "name", "twitter:image:alt"), a(t, "content", l = n[5].imageAlt)
        },
        m(e, i) {
            b(e, t, i)
        },
        p(e, i) {
            i & 32 && l !== (l = e[5].imageAlt) && a(t, "content", l)
        },
        d(e) {
            e && k(t)
        }
    }
}

function Ie(n) {
    let t, l, e, i, r, f, _, c, s, m, u;
    document.title = t = n[12]._(n[0]);
    let p = n[11] && X(n);

    function o(g, w) {
        var C;
        if ((C = g[6]) != null && C.length) return Ue;
        if (g[10] && I.SUPPORTED_LANGUAGES.length > 1) return Je
    }
    let d = o(n),
        h = d && d(n),
        N = n[8] && V(n),
        T = n[7] && Y(n),
        S = n[1] && Z(n),
        G = n[4] && H(n),
        L = n[5] && pe(n);
    return {
        c() {
            p && p.c(), l = A(), h && h.c(), e = A(), N && N.c(), i = A(), T && T.c(), r = E("meta"), _ = E("meta"), S && S.c(), s = A(), G && G.c(), m = A(), L && L.c(), u = A(), this.h()
        },
        l(g) {
            const w = we("svelte-1hecytt", document.head);
            p && p.l(w), l = A(), h && h.l(w), e = A(), N && N.l(w), i = A(), T && T.l(w), r = v(w, "META", {
                name: !0,
                content: !0
            }), _ = v(w, "META", {
                name: !0,
                content: !0
            }), S && S.l(w), s = A(), G && G.l(w), m = A(), L && L.l(w), u = A(), w.forEach(k), this.h()
        },
        h() {
            a(r, "name", "robots"), a(r, "content", f = `${n[2]||!z?"noindex":"index"},${n[3]?"nofollow":"follow"}`), a(_, "name", "googlebot"), a(_, "content", c = `${n[2]||!z?"noindex":"index"},${n[3]?"nofollow":"follow"}`)
        },
        m(g, w) {
            p && p.m(document.head, null), U(document.head, l), h && h.m(document.head, null), U(document.head, e), N && N.m(document.head, null), U(document.head, i), T && T.m(document.head, null), U(document.head, r), U(document.head, _), S && S.m(document.head, null), U(document.head, s), G && G.m(document.head, null), U(document.head, m), L && L.m(document.head, null), U(document.head, u)
        },
        p(g, [w]) {
            w & 4097 && t !== (t = g[12]._(g[0])) && (document.title = t), g[11] ? p ? p.p(g, w) : (p = X(g), p.c(), p.m(l.parentNode, l)) : p && (p.d(1), p = null), d === (d = o(g)) && h ? h.p(g, w) : (h && h.d(1), h = d && d(g), h && (h.c(), h.m(e.parentNode, e))), g[8] ? N ? N.p(g, w) : (N = V(g), N.c(), N.m(i.parentNode, i)) : N && (N.d(1), N = null), g[7] ? T ? T.p(g, w) : (T = Y(g), T.c(), T.m(r.parentNode, r)) : T && (T.d(1), T = null), w & 12 && f !== (f = `${g[2]||!z?"noindex":"index"},${g[3]?"nofollow":"follow"}`) && a(r, "content", f), w & 12 && c !== (c = `${g[2]||!z?"noindex":"index"},${g[3]?"nofollow":"follow"}`) && a(_, "content", c), g[1] ? S ? S.p(g, w) : (S = Z(g), S.c(), S.m(s.parentNode, s)) : S && (S.d(1), S = null), g[4] ? G ? G.p(g, w) : (G = H(g), G.c(), G.m(m.parentNode, m)) : G && (G.d(1), G = null), g[5] ? L ? L.p(g, w) : (L = pe(g), L.c(), L.m(u.parentNode, u)) : L && (L.d(1), L = null)
        },
        i: j,
        o: j,
        d(g) {
            p && p.d(g), k(l), h && h.d(g), k(e), N && N.d(g), k(i), T && T.d(g), k(r), k(_), S && S.d(g), k(s), G && G.d(g), k(m), L && L.d(g), k(u)
        }
    }
}

function Oe(n, t, l) {
    let e, i, r, f;
    D(n, Se, T => l(13, r = T)), D(n, Ge, T => l(12, f = T));
    let {
        title: _ = ""
    } = t, {
        description: c = ""
    } = t, {
        noindex: s = !1
    } = t, {
        nofollow: m = !1
    } = t, {
        openGraph: u = {
            title: _,
            description: c
        }
    } = t, {
        twitter: p = void 0
    } = t, {
        hreflangList: o = []
    } = t, {
        sanitizedJsonLd: d = void 0
    } = t, {
        generatedJsonLd: h = void 0
    } = t, {
        canonical: N = `${I.HOST.slice(0,-1)}${r.url.pathname}`
    } = t;
    return n.$$set = T => {
        "title" in T && l(0, _ = T.title), "description" in T && l(1, c = T.description), "noindex" in T && l(2, s = T.noindex), "nofollow" in T && l(3, m = T.nofollow), "openGraph" in T && l(4, u = T.openGraph), "twitter" in T && l(5, p = T.twitter), "hreflangList" in T && l(6, o = T.hreflangList), "sanitizedJsonLd" in T && l(7, d = T.sanitizedJsonLd), "generatedJsonLd" in T && l(8, h = T.generatedJsonLd), "canonical" in T && l(9, N = T.canonical)
    }, n.$$.update = () => {
        n.$$.dirty & 8704 && l(11, e = N ? O(N, r.params.lang) : void 0), n.$$.dirty & 512 && l(10, i = N ? Le(N) : void 0)
    }, [_, c, s, m, u, p, o, d, h, N, i, e, f, r]
}
class Fe extends Me {
    constructor(t) {
        super(), ye(this, t, Oe, Ie, ve, {
            title: 0,
            description: 1,
            noindex: 2,
            nofollow: 3,
            openGraph: 4,
            twitter: 5,
            hreflangList: 6,
            sanitizedJsonLd: 7,
            generatedJsonLd: 8,
            canonical: 9
        })
    }
}
export {
    Fe as S
};