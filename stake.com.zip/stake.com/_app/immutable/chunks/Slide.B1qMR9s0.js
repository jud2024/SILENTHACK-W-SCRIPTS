import {
    v as ve,
    x as Se,
    s as D,
    a as j,
    K as X,
    e as F,
    O as re,
    d as V,
    f as k,
    P as fe,
    i as _,
    F as S,
    V as C,
    Q as ee,
    j as y,
    k as W,
    W as ue,
    u as J,
    g as K,
    b as Q,
    L as te,
    Y as we,
    o as Te,
    M as Fe,
    J as Ve,
    t as ke,
    h as ye,
    l as Ce,
    q as se,
    n as de,
    c as Ae
} from "./scheduler.DXu26z7T.js";
import {
    S as M,
    i as q,
    t as v,
    g as Ne,
    b as w,
    e as Ie,
    c as N,
    a as I,
    m as L,
    d as E
} from "./index.Dz_MmNB3.js";
import {
    g as Le
} from "./spread.CgU5AtxT.js";
import {
    w as Ee
} from "./index.C2-CG2CN.js";
import {
    C as Pe
} from "./index.D-7TT9-T.js";
import "./index.ByMdEFI5.js";
import "./index.B3dW9TVs.js";
import {
    B as le
} from "./button.BwmFDw8u.js";
import {
    A as pe
} from "./ArrowTailBackward.Dg3YmG2n.js";
import {
    A as De
} from "./ArrowTailForward.B3djnWLZ.js";
const ce = "@@slider",
    ie = ({
        index: s,
        currentIndex: e,
        slidesToShow: l,
        mobileView: n,
        slideCount: t
    }) => {
        if (n) return !1;
        const i = s + 1,
            o = e + l;
        return Math.round(o) >= t ? !1 : i > o
    },
    Me = s => ve(ce, s),
    qe = () => Se(ce),
    Be = s => ({}),
    ne = s => ({
        getFaded: s[9]
    }),
    Oe = s => ({
        disablePrevious: s & 32,
        disableNext: s & 16
    }),
    oe = s => ({
        previous: s[8],
        next: s[7],
        disablePrevious: s[5],
        disableNext: s[4]
    });

function ae(s) {
    let e, l;
    const n = s[20].header,
        t = j(n, s, s[19], oe);
    return {
        c() {
            e = F("div"), t && t.c(), this.h()
        },
        l(i) {
            e = V(i, "DIV", {
                class: !0
            });
            var o = k(e);
            t && t.l(o), o.forEach(_), this.h()
        },
        h() {
            S(e, "class", "header svelte-ys5147")
        },
        m(i, o) {
            y(i, e, o), t && t.m(e, null), l = !0
        },
        p(i, o) {
            t && t.p && (!l || o & 524336) && J(t, n, i, i[19], l ? Q(n, i[19], o, Oe) : K(i[19]), oe)
        },
        i(i) {
            l || (v(t, i), l = !0)
        },
        o(i) {
            w(t, i), l = !1
        },
        d(i) {
            i && _(e), t && t.d(i)
        }
    }
}

function Re(s) {
    let e, l, n, t, i, o, a, r = s[11].header && ae(s);
    const c = s[20].default,
        m = j(c, s, s[19], ne);
    let T = [{
            class: "slider"
        }, s[10]],
        g = {};
    for (let f = 0; f < T.length; f += 1) g = X(g, T[f]);
    return {
        c() {
            e = F("div"), r && r.c(), l = re(), n = F("div"), m && m.c(), this.h()
        },
        l(f) {
            e = V(f, "DIV", {
                class: !0
            });
            var h = k(e);
            r && r.l(h), l = fe(h), n = V(h, "DIV", {
                class: !0,
                style: !0
            });
            var b = k(n);
            m && m.l(b), b.forEach(_), h.forEach(_), this.h()
        },
        h() {
            S(n, "class", "gallery scrollX hide-scrollbar svelte-ys5147"), S(n, "style", t = `grid-auto-columns: ${(100/s[2]).toFixed(2)}%; margin-left: ${-(s[1]+1)/2}px; margin-right: ${-(s[1]+1)/2}px;`), C(n, "mobileView", s[0]), ee(e, g), C(e, "svelte-ys5147", !0)
        },
        m(f, h) {
            y(f, e, h), r && r.m(e, null), W(e, l), W(e, n), m && m.m(n, null), s[21](n), i = !0, o || (a = ue(n, "scroll", s[6]), o = !0)
        },
        p(f, [h]) {
            f[11].header ? r ? (r.p(f, h), h & 2048 && v(r, 1)) : (r = ae(f), r.c(), v(r, 1), r.m(e, l)) : r && (Ne(), w(r, 1, 1, () => {
                r = null
            }), Ie()), m && m.p && (!i || h & 524288) && J(m, c, f, f[19], i ? Q(c, f[19], h, Be) : K(f[19]), ne), (!i || h & 6 && t !== (t = `grid-auto-columns: ${(100/f[2]).toFixed(2)}%; margin-left: ${-(f[1]+1)/2}px; margin-right: ${-(f[1]+1)/2}px;`)) && S(n, "style", t), (!i || h & 1) && C(n, "mobileView", f[0]), ee(e, g = Le(T, [{
                class: "slider"
            }, h & 1024 && f[10]])), C(e, "svelte-ys5147", !0)
        },
        i(f) {
            i || (v(r), v(m, f), i = !0)
        },
        o(f) {
            w(r), w(m, f), i = !1
        },
        d(f) {
            f && _(e), r && r.d(), m && m.d(f), s[21](null), o = !1, a()
        }
    }
}

function Xe(s, e, l) {
    let n, t;
    const i = ["mobileView", "width", "gap", "slidesToShow", "slidesToScroll", "slideCount", "calcFade"];
    let o = te(e, i),
        {
            $$slots: a = {},
            $$scope: r
        } = e;
    const c = we(a);
    let {
        mobileView: m = !1
    } = e, {
        width: T
    } = e, {
        gap: g
    } = e, {
        slidesToShow: f
    } = e, {
        slidesToScroll: h
    } = e, {
        slideCount: b
    } = e, {
        calcFade: B = ie
    } = e, d, Y = b <= f, O = !1, z = !0, A = 0, G = 0;

    function R() {
        l(16, A = Number((((d == null ? void 0 : d.scrollLeft) + 10) / n).toFixed(0))), G = f % 1 !== 0 ? Number(Math.ceil(((d == null ? void 0 : d.scrollLeft) + 10) / n).toFixed(0)) : Number((((d == null ? void 0 : d.scrollLeft) + 10) / n).toFixed(0))
    }

    function H() {
        l(5, z = !(d != null && d.scrollLeft))
    }

    function U() {
        l(4, Y = G + h >= b)
    }
    const me = () => {
            O || (window.requestAnimationFrame(function() {
                R(), H(), U(), O = !1
            }), O = !0)
        },
        Z = () => {
            const u = h * n,
                p = d.scrollLeft + u;
            d.scrollTo({
                left: p,
                behavior: "smooth"
            })
        },
        he = () => {
            const u = h * n,
                p = Math.max(0, d.scrollLeft - u);
            d.scrollTo({
                left: p,
                behavior: "smooth"
            })
        },
        ge = ({
            index: u
        }) => ie({
            index: u,
            currentIndex: A,
            mobileView: m,
            slidesToShow: f,
            slideCount: b
        });
    let P = Array.from({
        length: b
    });

    function x(u) {
        return u.slideArray.map((p, be) => B({
            index: be,
            currentIndex: u.currentIndex,
            mobileView: u.mobileView,
            slidesToShow: u.slidesToShow,
            slideCount: u.slideCount
        }))
    }
    let $ = Ee(x({
        mobileView: m,
        currentIndex: A,
        slideArray: P,
        slidesToShow: f,
        slideCount: b
    }));
    Me({
        fadedSlides: $,
        next: Z
    }), Te(() => {
        d.scrollLeft !== 0 && l(3, d.scrollLeft = 0, d)
    });

    function _e(u) {
        Ve[u ? "unshift" : "push"](() => {
            d = u, l(3, d)
        })
    }
    return s.$$set = u => {
        e = X(X({}, e), Fe(u)), l(10, o = te(e, i)), "mobileView" in u && l(0, m = u.mobileView), "width" in u && l(12, T = u.width), "gap" in u && l(1, g = u.gap), "slidesToShow" in u && l(2, f = u.slidesToShow), "slidesToScroll" in u && l(13, h = u.slidesToScroll), "slideCount" in u && l(14, b = u.slideCount), "calcFade" in u && l(15, B = u.calcFade), "$$scope" in u && l(19, r = u.$$scope)
    }, s.$$.update = () => {
        s.$$.dirty & 4100 && (n = Math.floor(T / f)), s.$$.dirty & 16384 && l(17, P = Array.from({
            length: b
        })), s.$$.dirty & 212997 && l(18, t = x({
            mobileView: m,
            currentIndex: A,
            slideArray: P,
            slidesToShow: f,
            slideCount: b
        })), s.$$.dirty & 262144 && $.set(t), s.$$.dirty & 8 && d && R(), s.$$.dirty & 12 && d && f && (R(), H(), U())
    }, [m, g, f, d, Y, z, me, Z, he, ge, o, c, T, h, b, B, A, P, t, r, a, _e]
}
class ot extends M {
    constructor(e) {
        super(), q(this, e, Xe, Re, D, {
            mobileView: 0,
            width: 12,
            gap: 1,
            slidesToShow: 2,
            slidesToScroll: 13,
            slideCount: 14,
            calcFade: 15
        })
    }
}

function We(s) {
    var n;
    let e = ((n = s[1]) == null ? void 0 : n.translation) + "",
        l;
    return {
        c() {
            l = ke(e)
        },
        l(t) {
            l = ye(t, e)
        },
        m(t, i) {
            y(t, l, i)
        },
        p(t, i) {
            var o;
            i & 2 && e !== (e = ((o = t[1]) == null ? void 0 : o.translation) + "") && Ce(l, e)
        },
        d(t) {
            t && _(l)
        }
    }
}

function je(s) {
    var n;
    let e, l;
    return e = new Pe({
        props: {
            icon: (n = s[1]) == null ? void 0 : n.icon,
            to: s[2],
            loading: s[0],
            $$slots: {
                default: [We]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            N(e.$$.fragment)
        },
        l(t) {
            I(e.$$.fragment, t)
        },
        m(t, i) {
            L(e, t, i), l = !0
        },
        p(t, [i]) {
            var a;
            const o = {};
            i & 2 && (o.icon = (a = t[1]) == null ? void 0 : a.icon), i & 4 && (o.to = t[2]), i & 1 && (o.loading = t[0]), i & 10 && (o.$$scope = {
                dirty: i,
                ctx: t
            }), e.$set(o)
        },
        i(t) {
            l || (v(e.$$.fragment, t), l = !0)
        },
        o(t) {
            w(e.$$.fragment, t), l = !1
        },
        d(t) {
            E(e, t)
        }
    }
}

function Je(s, e, l) {
    let n, {
            loading: t = !1
        } = e,
        {
            group: i
        } = e;
    return s.$$set = o => {
        "loading" in o && l(0, t = o.loading), "group" in o && l(1, i = o.group)
    }, s.$$.update = () => {
        s.$$.dirty & 2 && l(2, n = (i == null ? void 0 : i.to) || (i == null ? void 0 : i.slug) && `/casino/group/${i==null?void 0:i.slug}` || null)
    }, [t, i, n]
}
class at extends M {
    constructor(e) {
        super(), q(this, e, Je, je, D, {
            loading: 0,
            group: 1
        })
    }
}

function Ke(s) {
    let e, l, n;
    return l = new pe({}), {
        c() {
            e = F("div"), N(l.$$.fragment), this.h()
        },
        l(t) {
            e = V(t, "DIV", {
                class: !0
            });
            var i = k(e);
            I(l.$$.fragment, i), i.forEach(_), this.h()
        },
        h() {
            S(e, "class", "arrow-inner")
        },
        m(t, i) {
            y(t, e, i), L(l, e, null), n = !0
        },
        p: de,
        i(t) {
            n || (v(l.$$.fragment, t), n = !0)
        },
        o(t) {
            w(l.$$.fragment, t), n = !1
        },
        d(t) {
            t && _(e), E(l)
        }
    }
}

function Qe(s) {
    let e, l, n;
    return l = new De({}), {
        c() {
            e = F("div"), N(l.$$.fragment), this.h()
        },
        l(t) {
            e = V(t, "DIV", {
                class: !0
            });
            var i = k(e);
            I(l.$$.fragment, i), i.forEach(_), this.h()
        },
        h() {
            S(e, "class", "arrow-inner")
        },
        m(t, i) {
            y(t, e, i), L(l, e, null), n = !0
        },
        p: de,
        i(t) {
            n || (v(l.$$.fragment, t), n = !0)
        },
        o(t) {
            w(l.$$.fragment, t), n = !1
        },
        d(t) {
            t && _(e), E(l)
        }
    }
}

function Ye(s) {
    let e, l, n, t, i;
    return l = new le({
        props: {
            type: "button",
            class: "backward",
            disabled: s[2],
            $$slots: {
                default: [Ke]
            },
            $$scope: {
                ctx: s
            }
        }
    }), l.$on("click", function() {
        se(s[0]) && s[0].apply(this, arguments)
    }), t = new le({
        props: {
            type: "button",
            class: "forward",
            disabled: s[3],
            $$slots: {
                default: [Qe]
            },
            $$scope: {
                ctx: s
            }
        }
    }), t.$on("click", function() {
        se(s[1]) && s[1].apply(this, arguments)
    }), {
        c() {
            e = F("div"), N(l.$$.fragment), n = re(), N(t.$$.fragment), this.h()
        },
        l(o) {
            e = V(o, "DIV", {
                class: !0
            });
            var a = k(e);
            I(l.$$.fragment, a), n = fe(a), I(t.$$.fragment, a), a.forEach(_), this.h()
        },
        h() {
            S(e, "class", "arrows")
        },
        m(o, a) {
            y(o, e, a), L(l, e, null), W(e, n), L(t, e, null), i = !0
        },
        p(o, [a]) {
            s = o;
            const r = {};
            a & 4 && (r.disabled = s[2]), a & 16 && (r.$$scope = {
                dirty: a,
                ctx: s
            }), l.$set(r);
            const c = {};
            a & 8 && (c.disabled = s[3]), a & 16 && (c.$$scope = {
                dirty: a,
                ctx: s
            }), t.$set(c)
        },
        i(o) {
            i || (v(l.$$.fragment, o), v(t.$$.fragment, o), i = !0)
        },
        o(o) {
            w(l.$$.fragment, o), w(t.$$.fragment, o), i = !1
        },
        d(o) {
            o && _(e), E(l), E(t)
        }
    }
}

function ze(s, e, l) {
    let {
        previous: n
    } = e, {
        next: t
    } = e, {
        disablePrevious: i
    } = e, {
        disableNext: o
    } = e;
    return s.$$set = a => {
        "previous" in a && l(0, n = a.previous), "next" in a && l(1, t = a.next), "disablePrevious" in a && l(2, i = a.disablePrevious), "disableNext" in a && l(3, o = a.disableNext)
    }, [n, t, i, o]
}
class rt extends M {
    constructor(e) {
        super(), q(this, e, ze, Ye, D, {
            previous: 0,
            next: 1,
            disablePrevious: 2,
            disableNext: 3
        })
    }
}

function Ge(s) {
    let e, l, n, t, i;
    const o = s[7].default,
        a = j(o, s, s[6], null);
    return {
        c() {
            e = F("div"), a && a.c(), this.h()
        },
        l(r) {
            e = V(r, "DIV", {
                class: !0,
                style: !0
            });
            var c = k(e);
            a && a.l(c), c.forEach(_), this.h()
        },
        h() {
            S(e, "class", "slide svelte-kquvmi"), S(e, "style", l = `padding: 0 ${s[0]===0?0:(s[0]+1)/2}px`), C(e, "faded", s[1])
        },
        m(r, c) {
            y(r, e, c), a && a.m(e, null), n = !0, t || (i = ue(e, "click", s[8]), t = !0)
        },
        p(r, [c]) {
            a && a.p && (!n || c & 64) && J(a, o, r, r[6], n ? Q(o, r[6], c, null) : K(r[6]), null), (!n || c & 1 && l !== (l = `padding: 0 ${r[0]===0?0:(r[0]+1)/2}px`)) && S(e, "style", l), (!n || c & 2) && C(e, "faded", r[1])
        },
        i(r) {
            n || (v(a, r), n = !0)
        },
        o(r) {
            w(a, r), n = !1
        },
        d(r) {
            r && _(e), a && a.d(r), t = !1, i()
        }
    }
}

function He(s, e, l) {
    let n, t, {
            $$slots: i = {},
            $$scope: o
        } = e,
        {
            index: a
        } = e,
        {
            gap: r
        } = e;
    const {
        fadedSlides: c,
        next: m
    } = qe();
    Ae(s, c, g => l(5, t = g));
    const T = () => {
        n && m()
    };
    return s.$$set = g => {
        "index" in g && l(4, a = g.index), "gap" in g && l(0, r = g.gap), "$$scope" in g && l(6, o = g.$$scope)
    }, s.$$.update = () => {
        s.$$.dirty & 48 && l(1, n = t[a])
    }, [r, n, c, m, a, t, o, i, T]
}
class ft extends M {
    constructor(e) {
        super(), q(this, e, He, Ge, D, {
            index: 4,
            gap: 0
        })
    }
}
export {
    rt as A, ot as R, ft as S, at as T
};