import {
    s as o,
    C as u,
    H as h,
    D as f,
    f as m,
    E as _,
    i as v,
    F as r,
    j as d,
    n as c
} from "./scheduler.DXu26z7T.js";
import {
    S as g,
    i as y
} from "./index.Dz_MmNB3.js";

function H(n) {
    let e, s, a = ` <title>${n[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M0 49.36V0h64v49.36H0ZM23.013 9.893v29.574l23.68-14.8-23.68-14.774ZM10.667 56h42.666v8H10.667v-8Z"></path>`,
        i;
    return {
        c() {
            e = u("svg"), s = new h(!0), this.h()
        },
        l(l) {
            e = f(l, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var t = m(e);
            s = _(t, !0), t.forEach(v), this.h()
        },
        h() {
            s.a = null, r(e, "fill", "currentColor"), r(e, "viewBox", "0 0 64 64"), r(e, "class", i = "svg-icon " + n[2]), r(e, "style", n[0])
        },
        m(l, t) {
            d(l, e, t), s.m(a, e)
        },
        p(l, [t]) {
            t & 2 && a !== (a = ` <title>${l[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M0 49.36V0h64v49.36H0ZM23.013 9.893v29.574l23.68-14.8-23.68-14.774ZM10.667 56h42.666v8H10.667v-8Z"></path>`) && s.p(a), t & 4 && i !== (i = "svg-icon " + l[2]) && r(e, "class", i), t & 1 && r(e, "style", l[0])
        },
        i: c,
        o: c,
        d(l) {
            l && v(e)
        }
    }
}

function M(n, e, s) {
    let {
        style: a = ""
    } = e, {
        alt: i = ""
    } = e, {
        class: l = ""
    } = e;
    return n.$$set = t => {
        "style" in t && s(0, a = t.style), "alt" in t && s(1, i = t.alt), "class" in t && s(2, l = t.class)
    }, [a, i, l]
}
class C extends g {
    constructor(e) {
        super(), y(this, e, M, H, o, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    C as L
};