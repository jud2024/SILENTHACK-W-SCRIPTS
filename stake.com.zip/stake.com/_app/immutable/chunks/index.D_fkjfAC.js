import {
    s as u,
    K as i,
    L as l,
    c as _,
    M as p,
    t as f,
    h as g,
    j as d,
    l as $,
    i as b
} from "./scheduler.DXu26z7T.js";
import {
    S as h,
    i as L,
    c as v,
    a as x,
    m as j,
    t as k,
    b as B,
    d as S
} from "./index.Dz_MmNB3.js";
import {
    g as q,
    a as w
} from "./spread.CgU5AtxT.js";
import {
    h as z,
    i as C
} from "./index.B4-7gKq3.js";
import "./index.B3dW9TVs.js";
import {
    l as K
} from "./index.1CTKaDY2.js";
import {
    B as M
} from "./button.BwmFDw8u.js";
const m = {
    logout: z._("Log out")
};

function P(r) {
    let t = r[0]._(m.logout) + "",
        s;
    return {
        c() {
            s = f(t)
        },
        l(o) {
            s = g(o, t)
        },
        m(o, n) {
            d(o, s, n)
        },
        p(o, n) {
            n & 1 && t !== (t = o[0]._(m.logout) + "") && $(s, t)
        },
        d(o) {
            o && b(s)
        }
    }
}

function y(r) {
    let t, s;
    const o = [{
        variant: "danger"
    }, {
        size: "lg"
    }, {
        "data-test": "logout-link"
    }, r[1]];
    let n = {
        $$slots: {
            default: [P]
        },
        $$scope: {
            ctx: r
        }
    };
    for (let e = 0; e < o.length; e += 1) n = i(n, o[e]);
    return t = new M({
        props: n
    }), t.$on("click", K), {
        c() {
            v(t.$$.fragment)
        },
        l(e) {
            x(t.$$.fragment, e)
        },
        m(e, a) {
            j(t, e, a), s = !0
        },
        p(e, [a]) {
            const c = a & 2 ? q(o, [o[0], o[1], o[2], w(e[1])]) : {};
            a & 5 && (c.$$scope = {
                dirty: a,
                ctx: e
            }), t.$set(c)
        },
        i(e) {
            s || (k(t.$$.fragment, e), s = !0)
        },
        o(e) {
            B(t.$$.fragment, e), s = !1
        },
        d(e) {
            S(t, e)
        }
    }
}

function A(r, t, s) {
    const o = [];
    let n = l(t, o),
        e;
    return _(r, C, a => s(0, e = a)), r.$$set = a => {
        t = i(i({}, t), p(a)), s(1, n = l(t, o))
    }, [e, n]
}
class N extends h {
    constructor(t) {
        super(), L(this, t, A, y, u, {})
    }
}
export {
    N as L
};