import {
    s as Y,
    m as J,
    j as k,
    n as p,
    i as y,
    c as w,
    t as W,
    h as E,
    l as M,
    e as P,
    O as H,
    d as q,
    f as B,
    P as O,
    k as C,
    F as V,
    W as ce,
    r as ze,
    L as se,
    K,
    M as Re,
    J as Ce
} from "./scheduler.DXu26z7T.js";
import {
    S as Z,
    i as x,
    t as b,
    g as S,
    b as d,
    e as T,
    c as F,
    a as v,
    m as D,
    d as N
} from "./index.Dz_MmNB3.js";
import {
    g as ve,
    a as De
} from "./spread.CgU5AtxT.js";
import {
    i as Ne,
    P as me,
    R as Ve,
    bl as We,
    aq as Ee,
    F as L,
    z as _e,
    G as Me,
    bm as G,
    bn as Pe,
    q as ge
} from "./index.B4-7gKq3.js";
import {
    C as $
} from "./index.Na6KaqFL.js";
import {
    c as qe
} from "./shared.G3i0PjK-.js";
import {
    s as Be,
    T as ee
} from "./index.D7nbRHfU.js";
import {
    T as je
} from "./index.CYsK4uyl.js";
import {
    f as Ie
} from "./fiatNumberFormat.CcHMsn0U.js";

function He(l) {
    let e = me(l[0], l[1]) + "",
        n;
    return {
        c() {
            n = W(e)
        },
        l(t) {
            n = E(t, e)
        },
        m(t, i) {
            k(t, n, i)
        },
        p(t, i) {
            i & 3 && e !== (e = me(t[0], t[1]) + "") && M(n, e)
        },
        d(t) {
            t && y(n)
        }
    }
}

function Oe(l) {
    let e;

    function n(r, u) {
        return He
    }
    let i = n()(l);
    return {
        c() {
            i.c(), e = J()
        },
        l(r) {
            i.l(r), e = J()
        },
        m(r, u) {
            i.m(r, u), k(r, e, u)
        },
        p(r, [u]) {
            i.p(r, u)
        },
        i: p,
        o: p,
        d(r) {
            r && y(e), i.d(r)
        }
    }
}

function Ue(l, e, n) {
    let t;
    w(l, Ne, u => n(2, t = u));
    let {
        value: i
    } = e, {
        currency: r
    } = e;
    return l.$$set = u => {
        "value" in u && n(0, i = u.value), "currency" in u && n(1, r = u.currency)
    }, [i, r, t]
}
class pe extends Z {
    constructor(e) {
        super(), x(this, e, Ue, Oe, Y, {
            value: 0,
            currency: 1
        })
    }
}

function he(l) {
    let e;
    return {
        c() {
            e = W(l[5])
        },
        l(n) {
            e = E(n, l[5])
        },
        m(n, t) {
            k(n, e, t)
        },
        p(n, t) {
            t & 32 && M(e, n[5])
        },
        d(n) {
            n && y(e)
        }
    }
}

function be(l) {
    let e, n;
    return e = new je({
        props: {
            parentNode: l[3],
            $$slots: {
                default: [Ke]
            },
            $$scope: {
                ctx: l
            }
        }
    }), {
        c() {
            F(e.$$.fragment)
        },
        l(t) {
            v(e.$$.fragment, t)
        },
        m(t, i) {
            D(e, t, i), n = !0
        },
        p(t, i) {
            const r = {};
            i & 8 && (r.parentNode = t[3]), i & 65571 && (r.$$scope = {
                dirty: i,
                ctx: t
            }), e.$set(r)
        },
        i(t) {
            n || (b(e.$$.fragment, t), n = !0)
        },
        o(t) {
            d(e.$$.fragment, t), n = !1
        },
        d(t) {
            N(e, t)
        }
    }
}

function Ge(l) {
    let e, n, t;
    return n = new pe({
        props: {
            currency: l[0],
            value: l[1]
        }
    }), {
        c() {
            e = P("span"), F(n.$$.fragment)
        },
        l(i) {
            e = q(i, "SPAN", {});
            var r = B(e);
            v(n.$$.fragment, r), r.forEach(y)
        },
        m(i, r) {
            k(i, e, r), D(n, e, null), t = !0
        },
        p(i, r) {
            const u = {};
            r & 1 && (u.currency = i[0]), r & 2 && (u.value = i[1]), n.$set(u)
        },
        i(i) {
            t || (b(n.$$.fragment, i), t = !0)
        },
        o(i) {
            d(n.$$.fragment, i), t = !1
        },
        d(i) {
            i && y(e), N(n)
        }
    }
}

function Je(l) {
    let e, n;
    return {
        c() {
            e = P("span"), n = W(l[5])
        },
        l(t) {
            e = q(t, "SPAN", {});
            var i = B(e);
            n = E(i, l[5]), i.forEach(y)
        },
        m(t, i) {
            k(t, e, i), C(e, n)
        },
        p(t, i) {
            i & 32 && M(n, t[5])
        },
        i: p,
        o: p,
        d(t) {
            t && y(e)
        }
    }
}

function Ke(l) {
    let e, n, t, i, r, u;
    const f = [Je, Ge],
        o = [];

    function a(c, s) {
        return c[0] in L ? 0 : 1
    }
    return n = a(l), t = o[n] = f[n](l), r = new $({
        props: {
            currency: l[0]
        }
    }), {
        c() {
            e = P("div"), t.c(), i = H(), F(r.$$.fragment), this.h()
        },
        l(c) {
            e = q(c, "DIV", {
                class: !0
            });
            var s = B(e);
            t.l(s), i = O(s), v(r.$$.fragment, s), s.forEach(y), this.h()
        },
        h() {
            V(e, "class", "fiat-wrapper svelte-amtc4z")
        },
        m(c, s) {
            k(c, e, s), o[n].m(e, null), C(e, i), D(r, e, null), u = !0
        },
        p(c, s) {
            let _ = n;
            n = a(c), n === _ ? o[n].p(c, s) : (S(), d(o[_], 1, 1, () => {
                o[_] = null
            }), T(), t = o[n], t ? t.p(c, s) : (t = o[n] = f[n](c), t.c()), b(t, 1), t.m(e, i));
            const g = {};
            s & 1 && (g.currency = c[0]), r.$set(g)
        },
        i(c) {
            u || (b(t), b(r.$$.fragment, c), u = !0)
        },
        o(c) {
            d(t), d(r.$$.fragment, c), u = !1
        },
        d(c) {
            c && y(e), o[n].d(), N(r)
        }
    }
}

function Le(l) {
    let e, n, t, i = typeof l[4] == "number" && he(l),
        r = l[2] && l[3] && be(l);
    return {
        c() {
            e = P("span"), i && i.c(), n = H(), r && r.c()
        },
        l(u) {
            e = q(u, "SPAN", {});
            var f = B(e);
            i && i.l(f), n = O(f), r && r.l(f), f.forEach(y)
        },
        m(u, f) {
            k(u, e, f), i && i.m(e, null), C(e, n), r && r.m(e, null), t = !0
        },
        p(u, [f]) {
            typeof u[4] == "number" ? i ? i.p(u, f) : (i = he(u), i.c(), i.m(e, n)) : i && (i.d(1), i = null), u[2] && u[3] ? r ? (r.p(u, f), f & 12 && b(r, 1)) : (r = be(u), r.c(), b(r, 1), r.m(e, null)) : r && (S(), d(r, 1, 1, () => {
                r = null
            }), T())
        },
        i(u) {
            t || (b(r), t = !0)
        },
        o(u) {
            d(r), t = !1
        },
        d(u) {
            u && y(e), i && i.d(), r && r.d()
        }
    }
}
const Qe = "currency";

function Xe(l, e, n) {
    let t, i, r, u, f, o, a;
    w(l, Ie, h => n(13, o = h)), w(l, Ve, h => n(14, a = h));
    let {
        currency: c
    } = e, {
        value: s
    } = e, {
        showTooltip: _
    } = e, {
        view: g
    } = e, {
        currencyNode: j = void 0
    } = e, {
        minimumFractionDigits: A = 2
    } = e, {
        maximumFractionDigits: z = 2
    } = e, {
        fiatRounding: R = "round"
    } = e;
    const U = (h, I) => h in L ? h : I == "crypto" ? L.usd : I;
    return l.$$set = h => {
        "currency" in h && n(0, c = h.currency), "value" in h && n(1, s = h.value), "showTooltip" in h && n(2, _ = h.showTooltip), "view" in h && n(6, g = h.view), "currencyNode" in h && n(3, j = h.currencyNode), "minimumFractionDigits" in h && n(7, A = h.minimumFractionDigits), "maximumFractionDigits" in h && n(8, z = h.maximumFractionDigits), "fiatRounding" in h && n(9, R = h.fiatRounding)
    }, l.$$.update = () => {
        var h;
        l.$$.dirty & 65 && n(12, t = U(c, g)), l.$$.dirty & 20483 && n(11, i = (h = a == null ? void 0 : a.rates) != null && h[c] ? a.rates[c][t] * s : s), l.$$.dirty & 4480 && n(10, r = {
            minimumFractionDigits: A,
            maximumFractionDigits: z,
            currency: t,
            style: Qe
        }), l.$$.dirty & 2560 && n(4, u = We(i, R)), l.$$.dirty & 9232 && n(5, f = Ee(u, o, r))
    }, [c, s, _, j, u, f, g, A, z, R, r, i, t, o, a]
}
class Ye extends Z {
    constructor(e) {
        super(), x(this, e, Xe, Le, Y, {
            currency: 0,
            value: 1,
            showTooltip: 2,
            view: 6,
            currencyNode: 3,
            minimumFractionDigits: 7,
            maximumFractionDigits: 8,
            fiatRounding: 9
        })
    }
}

function de(l) {
    let e, n;
    return e = new $({
        props: {
            currency: l[1]
        }
    }), {
        c() {
            F(e.$$.fragment)
        },
        l(t) {
            v(e.$$.fragment, t)
        },
        m(t, i) {
            D(e, t, i), n = !0
        },
        p(t, i) {
            const r = {};
            i[0] & 2 && (r.currency = t[1]), e.$set(r)
        },
        i(t) {
            n || (b(e.$$.fragment, t), n = !0)
        },
        o(t) {
            d(e.$$.fragment, t), n = !1
        },
        d(t) {
            N(e, t)
        }
    }
}

function ye(l) {
    let e, n, t, i;
    const r = [{
        size: l[8]
    }, {
        weight: l[7]
    }, {
        variant: l[6]
    }, {
        contentStyle: l[9]
    }, {
        numeric: !0
    }, l[25]];
    let u = {
        $$slots: {
            default: [tt]
        },
        $$scope: {
            ctx: l
        }
    };
    for (let f = 0; f < r.length; f += 1) u = K(u, r[f]);
    return n = new ee({
        props: u
    }), {
        c() {
            e = P("span"), F(n.$$.fragment), this.h()
        },
        l(f) {
            e = q(f, "SPAN", {
                class: !0,
                style: !0
            });
            var o = B(e);
            v(n.$$.fragment, o), o.forEach(y), this.h()
        },
        h() {
            V(e, "class", "content svelte-141qgpc"), V(e, "style", t = l[5] ? `width: ${l[10]}` : "")
        },
        m(f, o) {
            k(f, e, o), D(n, e, null), i = !0
        },
        p(f, o) {
            const a = o[0] & 33555392 ? ve(r, [o[0] & 256 && {
                size: f[8]
            }, o[0] & 128 && {
                weight: f[7]
            }, o[0] & 64 && {
                variant: f[6]
            }, o[0] & 512 && {
                contentStyle: f[9]
            }, r[4], o[0] & 33554432 && De(f[25])]) : {};
            o[0] & 2095107 | o[1] & 1 && (a.$$scope = {
                dirty: o,
                ctx: f
            }), n.$set(a), (!i || o[0] & 1056 && t !== (t = f[5] ? `width: ${f[10]}` : "")) && V(e, "style", t)
        },
        i(f) {
            i || (b(n.$$.fragment, f), i = !0)
        },
        o(f) {
            d(n.$$.fragment, f), i = !1
        },
        d(f) {
            f && y(e), N(n)
        }
    }
}

function Ze(l) {
    let e, n;
    return e = new pe({
        props: {
            currency: l[1],
            value: Number(l[0])
        }
    }), {
        c() {
            F(e.$$.fragment)
        },
        l(t) {
            v(e.$$.fragment, t)
        },
        m(t, i) {
            D(e, t, i), n = !0
        },
        p(t, i) {
            const r = {};
            i[0] & 2 && (r.currency = t[1]), i[0] & 1 && (r.value = Number(t[0])), e.$set(r)
        },
        i(t) {
            n || (b(e.$$.fragment, t), n = !0)
        },
        o(t) {
            d(e.$$.fragment, t), n = !1
        },
        d(t) {
            N(e, t)
        }
    }
}

function xe(l) {
    let e = l[20].number(Number(l[0]), {
            minimumFractionDigits: l[13],
            maximumFractionDigits: 2
        }) + "",
        n;
    return {
        c() {
            n = W(e)
        },
        l(t) {
            n = E(t, e)
        },
        m(t, i) {
            k(t, n, i)
        },
        p(t, i) {
            i[0] & 1056769 && e !== (e = t[20].number(Number(t[0]), {
                minimumFractionDigits: t[13],
                maximumFractionDigits: 2
            }) + "") && M(n, e)
        },
        i: p,
        o: p,
        d(t) {
            t && y(n)
        }
    }
}

function $e(l) {
    let e, n;
    return e = new Ye({
        props: {
            fiatRounding: l[12],
            currencyNode: l[16],
            currency: ge[l[1]],
            showTooltip: l[11] && l[18] && l[19],
            value: Number(l[0]),
            view: l[15],
            maximumFractionDigits: l[14],
            minimumFractionDigits: l[13]
        }
    }), {
        c() {
            F(e.$$.fragment)
        },
        l(t) {
            v(e.$$.fragment, t)
        },
        m(t, i) {
            D(e, t, i), n = !0
        },
        p(t, i) {
            const r = {};
            i[0] & 4096 && (r.fiatRounding = t[12]), i[0] & 65536 && (r.currencyNode = t[16]), i[0] & 2 && (r.currency = ge[t[1]]), i[0] & 788480 && (r.showTooltip = t[11] && t[18] && t[19]), i[0] & 1 && (r.value = Number(t[0])), i[0] & 32768 && (r.view = t[15]), i[0] & 16384 && (r.maximumFractionDigits = t[14]), i[0] & 8192 && (r.minimumFractionDigits = t[13]), e.$set(r)
        },
        i(t) {
            n || (b(e.$$.fragment, t), n = !0)
        },
        o(t) {
            d(e.$$.fragment, t), n = !1
        },
        d(t) {
            N(e, t)
        }
    }
}

function et(l) {
    let e;
    return {
        c() {
            e = W(l[0])
        },
        l(n) {
            e = E(n, l[0])
        },
        m(n, t) {
            k(n, e, t)
        },
        p(n, t) {
            t[0] & 1 && M(e, n[0])
        },
        i: p,
        o: p,
        d(n) {
            n && y(e)
        }
    }
}

function tt(l) {
    let e, n, t, i, r;
    const u = [et, $e, xe, Ze],
        f = [];

    function o(a, c) {
        return c[0] & 1 && (e = null), e == null && (e = !!Number.isNaN(Number(a[0]))), e ? 0 : a[17] === "fiat" ? 1 : a[1] in Pe ? 2 : 3
    }
    return n = o(l, [-1, -1]), t = f[n] = u[n](l), {
        c() {
            t.c(), i = J()
        },
        l(a) {
            t.l(a), i = J()
        },
        m(a, c) {
            f[n].m(a, c), k(a, i, c), r = !0
        },
        p(a, c) {
            let s = n;
            n = o(a, c), n === s ? f[n].p(a, c) : (S(), d(f[s], 1, 1, () => {
                f[s] = null
            }), T(), t = f[n], t ? t.p(a, c) : (t = f[n] = u[n](a), t.c()), b(t, 1), t.m(i.parentNode, i))
        },
        i(a) {
            r || (b(t), r = !0)
        },
        o(a) {
            d(t), r = !1
        },
        d(a) {
            a && y(i), f[n].d(a)
        }
    }
}

function ke(l) {
    let e, n;
    return e = new ee({
        props: {
            title: l[1],
            iconSpace: !1,
            size: l[8],
            $$slots: {
                default: [nt]
            },
            $$scope: {
                ctx: l
            }
        }
    }), {
        c() {
            F(e.$$.fragment)
        },
        l(t) {
            v(e.$$.fragment, t)
        },
        m(t, i) {
            D(e, t, i), n = !0
        },
        p(t, i) {
            const r = {};
            i[0] & 2 && (r.title = t[1]), i[0] & 256 && (r.size = t[8]), i[0] & 2 | i[1] & 1 && (r.$$scope = {
                dirty: i,
                ctx: t
            }), e.$set(r)
        },
        i(t) {
            n || (b(e.$$.fragment, t), n = !0)
        },
        o(t) {
            d(e.$$.fragment, t), n = !1
        },
        d(t) {
            N(e, t)
        }
    }
}

function nt(l) {
    let e, n;
    return e = new $({
        props: {
            currency: l[1]
        }
    }), {
        c() {
            F(e.$$.fragment)
        },
        l(t) {
            v(e.$$.fragment, t)
        },
        m(t, i) {
            D(e, t, i), n = !0
        },
        p(t, i) {
            const r = {};
            i[0] & 2 && (r.currency = t[1]), e.$set(r)
        },
        i(t) {
            n || (b(e.$$.fragment, t), n = !0)
        },
        o(t) {
            d(e.$$.fragment, t), n = !1
        },
        d(t) {
            N(e, t)
        }
    }
}

function Fe(l) {
    let e, n;
    const t = [{
        contentStyle: l[9]
    }, {
        size: l[8]
    }, {
        weight: l[7]
    }, {
        variant: l[6]
    }, l[25]];
    let i = {
        $$slots: {
            default: [it]
        },
        $$scope: {
            ctx: l
        }
    };
    for (let r = 0; r < t.length; r += 1) i = K(i, t[r]);
    return e = new ee({
        props: i
    }), {
        c() {
            F(e.$$.fragment)
        },
        l(r) {
            v(e.$$.fragment, r)
        },
        m(r, u) {
            D(e, r, u), n = !0
        },
        p(r, u) {
            const f = u[0] & 33555392 ? ve(t, [u[0] & 512 && {
                contentStyle: r[9]
            }, u[0] & 256 && {
                size: r[8]
            }, u[0] & 128 && {
                weight: r[7]
            }, u[0] & 64 && {
                variant: r[6]
            }, u[0] & 33554432 && De(r[25])]) : {};
            u[0] & 2 | u[1] & 1 && (f.$$scope = {
                dirty: u,
                ctx: r
            }), e.$set(f)
        },
        i(r) {
            n || (b(e.$$.fragment, r), n = !0)
        },
        o(r) {
            d(e.$$.fragment, r), n = !1
        },
        d(r) {
            N(e, r)
        }
    }
}

function it(l) {
    let e = (l[1] in G ? G[l[1]] : l[1].toUpperCase()) + "",
        n;
    return {
        c() {
            n = W(e)
        },
        l(t) {
            n = E(t, e)
        },
        m(t, i) {
            k(t, n, i)
        },
        p(t, i) {
            i[0] & 2 && e !== (e = (t[1] in G ? G[t[1]] : t[1].toUpperCase()) + "") && M(n, e)
        },
        d(t) {
            t && y(n)
        }
    }
}

function rt(l) {
    let e, n, t, i, r, u, f, o = l[2] && de(l),
        a = l[0] !== void 0 && ye(l),
        c = l[3] && _e && ke(l),
        s = l[4] && l[1] && Fe(l);
    return {
        c() {
            e = P("div"), o && o.c(), n = H(), a && a.c(), t = H(), c && c.c(), i = H(), s && s.c(), this.h()
        },
        l(_) {
            e = q(_, "DIV", {
                class: !0,
                role: !0
            });
            var g = B(e);
            o && o.l(g), n = O(g), a && a.l(g), t = O(g), c && c.l(g), i = O(g), s && s.l(g), g.forEach(y), this.h()
        },
        h() {
            V(e, "class", "currency svelte-141qgpc"), V(e, "role", "presentation")
        },
        m(_, g) {
            k(_, e, g), o && o.m(e, null), C(e, n), a && a.m(e, null), C(e, t), c && c.m(e, null), C(e, i), s && s.m(e, null), l[26](e), r = !0, u || (f = [ce(e, "mouseenter", l[27]), ce(e, "mouseleave", l[28])], u = !0)
        },
        p(_, g) {
            _[2] ? o ? (o.p(_, g), g[0] & 4 && b(o, 1)) : (o = de(_), o.c(), b(o, 1), o.m(e, n)) : o && (S(), d(o, 1, 1, () => {
                o = null
            }), T()), _[0] !== void 0 ? a ? (a.p(_, g), g[0] & 1 && b(a, 1)) : (a = ye(_), a.c(), b(a, 1), a.m(e, t)) : a && (S(), d(a, 1, 1, () => {
                a = null
            }), T()), _[3] && _e ? c ? (c.p(_, g), g[0] & 8 && b(c, 1)) : (c = ke(_), c.c(), b(c, 1), c.m(e, i)) : c && (S(), d(c, 1, 1, () => {
                c = null
            }), T()), _[4] && _[1] ? s ? (s.p(_, g), g[0] & 18 && b(s, 1)) : (s = Fe(_), s.c(), b(s, 1), s.m(e, null)) : s && (S(), d(s, 1, 1, () => {
                s = null
            }), T())
        },
        i(_) {
            r || (b(o), b(a), b(c), b(s), r = !0)
        },
        o(_) {
            d(o), d(a), d(c), d(s), r = !1
        },
        d(_) {
            _ && y(e), o && o.d(), a && a.d(), c && c.d(), s && s.d(), l[26](null), u = !1, ze(f)
        }
    }
}

function lt(l, e, n) {
    let t;
    const i = ["value", "currency", "iconBefore", "iconAfter", "symbolAfter", "fixWidth", "variant", "weight", "size", "contentStyle", "truncateMaxWidth", "showTooltip", "fiatRounding", "minimumFractionDigits", "maximumFractionDigits"];
    let r = se(e, i),
        u, f, o, a;
    w(l, Me, m => n(15, u = m)), w(l, Ne, m => n(20, a = m));
    const s = {
        crypto: "crypto",
        ...Object.keys(L).reduce((m, Ae) => ({ ...m,
            [Ae]: "fiat"
        }), {})
    };
    let {
        value: _ = void 0
    } = e, {
        currency: g
    } = e, {
        iconBefore: j = !1
    } = e, {
        iconAfter: A = !0
    } = e, {
        symbolAfter: z = !1
    } = e, {
        fixWidth: R = !1
    } = e, {
        variant: U = "subtle"
    } = e, {
        weight: h = "normal"
    } = e, {
        size: I = "default"
    } = e, {
        contentStyle: te = void 0
    } = e, {
        truncateMaxWidth: Q = "12ch"
    } = e, {
        showTooltip: ne = !0
    } = e, {
        fiatRounding: ie = "round"
    } = e, X;
    const {
        enter: re,
        leave: le,
        hovering: ue,
        sharedHovering: fe
    } = qe();
    w(l, ue, m => n(18, f = m)), w(l, fe, m => n(19, o = m)), Be(Q);
    let {
        minimumFractionDigits: oe = 2
    } = e, {
        maximumFractionDigits: ae = 2
    } = e;

    function we(m) {
        Ce[m ? "unshift" : "push"](() => {
            X = m, n(16, X)
        })
    }
    const Se = () => {
            re()
        },
        Te = () => {
            le()
        };
    return l.$$set = m => {
        e = K(K({}, e), Re(m)), n(25, r = se(e, i)), "value" in m && n(0, _ = m.value), "currency" in m && n(1, g = m.currency), "iconBefore" in m && n(2, j = m.iconBefore), "iconAfter" in m && n(3, A = m.iconAfter), "symbolAfter" in m && n(4, z = m.symbolAfter), "fixWidth" in m && n(5, R = m.fixWidth), "variant" in m && n(6, U = m.variant), "weight" in m && n(7, h = m.weight), "size" in m && n(8, I = m.size), "contentStyle" in m && n(9, te = m.contentStyle), "truncateMaxWidth" in m && n(10, Q = m.truncateMaxWidth), "showTooltip" in m && n(11, ne = m.showTooltip), "fiatRounding" in m && n(12, ie = m.fiatRounding), "minimumFractionDigits" in m && n(13, oe = m.minimumFractionDigits), "maximumFractionDigits" in m && n(14, ae = m.maximumFractionDigits)
    }, l.$$.update = () => {
        l.$$.dirty[0] & 32770 && n(17, t = g in s ? String(s[g]) : s[u])
    }, [_, g, j, A, z, R, U, h, I, te, Q, ne, ie, oe, ae, u, X, t, f, o, a, re, le, ue, fe, r, we, Se, Te]
}
class ht extends Z {
    constructor(e) {
        super(), x(this, e, lt, rt, Y, {
            value: 0,
            currency: 1,
            iconBefore: 2,
            iconAfter: 3,
            symbolAfter: 4,
            fixWidth: 5,
            variant: 6,
            weight: 7,
            size: 8,
            contentStyle: 9,
            truncateMaxWidth: 10,
            showTooltip: 11,
            fiatRounding: 12,
            minimumFractionDigits: 13,
            maximumFractionDigits: 14
        }, null, [-1, -1])
    }
}
export {
    ht as C, Ye as F, pe as a
};