let a = "useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict",
    n = (t = 21) => {
        let e = "",
            l = t;
        for (; l--;) e += a[Math.random() * 64 | 0];
        return e
    };
export {
    n
};