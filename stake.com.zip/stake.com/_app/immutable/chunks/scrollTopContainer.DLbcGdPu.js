const t = l => {
        {
            const o = l ? ? document.getElementById("scrollable");
            o && o.scrollTo({
                top: 0
            })
        }
    },
    e = t;
export {
    e as r, t as s
};