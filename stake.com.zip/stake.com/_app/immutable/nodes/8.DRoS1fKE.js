import {
    f as _t,
    P as $t
} from "../chunks/index.CSm15PGW.js";
import {
    S as vt
} from "../chunks/SlugKuratorGroup.generated.kooJgGwY.js";
import {
    s as _e
} from "../chunks/pageSeo.DmcsyA6w.js";
import {
    f as ht
} from "../chunks/sanity.Cu4Or4Eg.js";
import {
    f as Nt
} from "../chunks/jsonld.voBq1lCv.js";
import {
    r as bt
} from "../chunks/index.BljstGtu.js";
import {
    aa as Be,
    f as Ie,
    bt as Ft,
    h as q,
    i as ue,
    cb as St,
    _ as wt,
    J as yt,
    p as Ct,
    n as Tt,
    r as Gt,
    ag as Et
} from "../chunks/index.B4-7gKq3.js";
import {
    r as Dt
} from "../chunks/index.g5YcAAdQ.js";
import {
    s as oe,
    a as at,
    e as D,
    d as B,
    f as I,
    i as p,
    F as R,
    V as x,
    j as T,
    k as b,
    a3 as it,
    u as lt,
    g as rt,
    b as ot,
    q as st,
    c as te,
    m as Y,
    t as H,
    O as P,
    h as U,
    P as z,
    l as j,
    a1 as pe,
    a6 as Bt,
    n as It
} from "../chunks/scheduler.DXu26z7T.js";
import {
    S as se,
    i as de,
    t as k,
    b as _,
    g as J,
    e as Q,
    c as F,
    a as S,
    m as w,
    d as y,
    f as Mt
} from "../chunks/index.Dz_MmNB3.js";
import "../chunks/index.ByMdEFI5.js";
import {
    t as dt
} from "../chunks/index.CgjaLSob.js";
import {
    r as mt
} from "../chunks/resizeObserver.A9wvMie0.js";
import {
    c as Lt,
    g as Vt
} from "../chunks/context.UnLgwODO.js";
import {
    i as At
} from "../chunks/variables.CIGccMR5.js";
import {
    s as Pt
} from "../chunks/context.BYnTbg5S.js";
import {
    C as zt
} from "../chunks/index.C154VRnh.js";
import {
    g as Kt
} from "../chunks/globals.D0QH3NT1.js";
import {
    e as ie,
    u as qt,
    o as Ht
} from "../chunks/each.DvgCmocI.js";
import {
    t as $e
} from "../chunks/index.Cq_eNUyU.js";
import {
    V as Ut,
    a as Ot
} from "../chunks/index.B81orGJm.js";
import {
    a as Rt
} from "../chunks/index.Bhhzp5qA.js";
import {
    g as Wt
} from "../chunks/index.Ci34scWy.js";
import {
    L as he
} from "../chunks/index.DJurAkTj.js";
import "../chunks/index.B3dW9TVs.js";
import {
    T as jt
} from "../chunks/index.CTIl3dBv.js";
import {
    T as Jt
} from "../chunks/index.BavbWpNs.js";
import {
    B as Ne
} from "../chunks/index.DlOe5U6J.js";
import {
    T as ut
} from "../chunks/index.oTMdB5Eh.js";
import {
    C as ve
} from "../chunks/index.CAbJJJ2j.js";
import {
    E as ft
} from "../chunks/index.CJLuklPK.js";
import {
    P as fe
} from "../chunks/index.B1KDSkU5.js";
import {
    U as be
} from "../chunks/index.B1J2NdFH.js";
import {
    C as Qt
} from "../chunks/index.D8v0bbn8.js";
import {
    T as ne
} from "../chunks/index.D7nbRHfU.js";
import {
    C as Yt
} from "../chunks/index.KTkwomZm.js";
import {
    F as Xt
} from "../chunks/index.CIBDG73T.js";
import {
    S as Zt
} from "../chunks/index.QCc5oEI0.js";
import {
    I as xt
} from "../chunks/index.BmTk3-ns.js";
import {
    g as ce
} from "../chunks/generatePath.DsXei5FM.js";
import {
    p as ke
} from "../chunks/paths.RTtAVJV7.js";
import {
    F as en
} from "../chunks/index.DCTjP2Ha.js";
import {
    L as tn
} from "../chunks/index.CMsSFPoz.js";
import {
    F as ct
} from "../chunks/index.BzMmusTo.js";
import {
    B as nn
} from "../chunks/BadgesCup1.Cjg1aoxr.js";
import {
    S as an
} from "../chunks/constants.CW0Xv01T.js";
import {
    B as kt
} from "../chunks/button.BwmFDw8u.js";
import {
    C as ln
} from "../chunks/ChevronDown.D-lyczpB.js";
import {
    C as rn
} from "../chunks/index.BBttw9M_.js";
import {
    g as on
} from "../chunks/getGameInfo.BICU5vNg.js";
import {
    L as sn
} from "../chunks/index.CzcN9_ET.js";
import {
    g as dn
} from "../chunks/index.Dnj7AXzX.js";
import {
    S as mn
} from "../chunks/index.B0J1dtPX.js";
import {
    a as un
} from "../chunks/index.CY6-K88d.js";
import {
    s as fn
} from "../chunks/context.DiMDyEjg.js";
import {
    r as cn
} from "../chunks/scrollTopContainer.DLbcGdPu.js";
import {
    E as gt
} from "../chunks/Error.DAkWdr3O.js";
const kn = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "query",
            name: {
                kind: "Name",
                value: "SlugKuratorGameIndex"
            },
            variableDefinitions: [{
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "slug"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "String"
                        }
                    }
                }
            }],
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "slugKuratorGame"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "slug"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "slug"
                            }
                        }
                    }],
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "GameKuratorGame"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "multiplierLeaderboard"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "payoutMultiplier"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "updatedAt"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "bet"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "FragmentSpread",
                                            name: {
                                                kind: "Name",
                                                value: "CasinoBetFragment"
                                            }
                                        }]
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "position"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "profitLeaderboard"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "profitValue"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "updatedAt"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "bet"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "FragmentSpread",
                                            name: {
                                                kind: "Name",
                                                value: "CasinoBetFragment"
                                            }
                                        }]
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "position"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "groupGames"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "group"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "FragmentSpread",
                                            name: {
                                                kind: "Name",
                                                value: "GameKuratorGroup"
                                            }
                                        }]
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "challengeList"
                            },
                            arguments: [{
                                kind: "Argument",
                                name: {
                                    kind: "Name",
                                    value: "limit"
                                },
                                value: {
                                    kind: "IntValue",
                                    value: "5"
                                }
                            }, {
                                kind: "Argument",
                                name: {
                                    kind: "Name",
                                    value: "offset"
                                },
                                value: {
                                    kind: "IntValue",
                                    value: "0"
                                }
                            }],
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "ChallengeTable"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SoftswissProvider"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SoftswissProvider"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SoftswissGame"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SoftswissGame"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "edge"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "extId"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "availableCurrencies"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "provider"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "SoftswissProvider"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "EvolutionGame"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "EvolutionGame"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "category"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "edge"
                    }
                }, {
                    kind: "Field",
                    alias: {
                        kind: "Name",
                        value: "currencies"
                    },
                    name: {
                        kind: "Name",
                        value: "availableCurrencies"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "GameKuratorThirdPartyGame"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "GameKuratorThirdPartyGame"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "edge"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "extId"
                    }
                }, {
                    kind: "Field",
                    alias: {
                        kind: "Name",
                        value: "thirdPartyGameAvailableCurrencies"
                    },
                    name: {
                        kind: "Name",
                        value: "availableCurrencies"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "provider"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "CasinoBet"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "CasinoBet"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payoutMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "amountMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "amount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payout"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "updatedAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "game"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "EvolutionBet"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "EvolutionBet"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "amount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payout"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payoutMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    alias: {
                        kind: "Name",
                        value: "softswissGame"
                    },
                    name: {
                        kind: "Name",
                        value: "game"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "edge"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "MultiplayerCrashBet"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "MultiplayerCrashBet"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "preferenceHideBets"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payoutMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "gameId"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "amount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payout"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "result"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "updatedAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "cashoutAt"
                    }
                }, {
                    kind: "Field",
                    alias: {
                        kind: "Name",
                        value: "btcAmount"
                    },
                    name: {
                        kind: "Name",
                        value: "amount"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "currency"
                        },
                        value: {
                            kind: "EnumValue",
                            value: "btc"
                        }
                    }]
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "MultiplayerSlideBet"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "MultiplayerSlideBet"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "preferenceHideBets"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payoutMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "gameId"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "amount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payout"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                }, {
                    kind: "Field",
                    alias: {
                        kind: "Name",
                        value: "slideResult"
                    },
                    name: {
                        kind: "Name",
                        value: "result"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "updatedAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "cashoutAt"
                    }
                }, {
                    kind: "Field",
                    alias: {
                        kind: "Name",
                        value: "btcAmount"
                    },
                    name: {
                        kind: "Name",
                        value: "amount"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "currency"
                        },
                        value: {
                            kind: "EnumValue",
                            value: "btc"
                        }
                    }]
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SoftswissBet"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SoftswissBet"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "amount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "updatedAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payout"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payoutMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    alias: {
                        kind: "Name",
                        value: "softswissGame"
                    },
                    name: {
                        kind: "Name",
                        value: "game"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "edge"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "extId"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "provider"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "ThirdPartyBet"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "ThirdPartyBet"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "amount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "updatedAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payout"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payoutMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "betReplay"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    alias: {
                        kind: "Name",
                        value: "thirdPartyGame"
                    },
                    name: {
                        kind: "Name",
                        value: "game"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "edge"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "extId"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "provider"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "GameKuratorGame"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "GameKuratorGame"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "slug"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "type"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "thumbnailUrl"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "edge"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "description"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "icon"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "isFavourite"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "showMultiplierLeaderboard"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "showProfitLeaderboard"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "isDemoEnabled"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "data"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "__typename"
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "SoftswissGame"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "SoftswissGame"
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "EvolutionGame"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "EvolutionGame"
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "GameKuratorThirdPartyGame"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "GameKuratorThirdPartyGame"
                                    }
                                }]
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "groupGames"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "group"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "translation"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "type"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "slug"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "CasinoBetFragment"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "Bet"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "iid"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "type"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "scope"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "game"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "icon"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "slug"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "bet"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "CasinoBet"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "CasinoBet"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "user"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "id"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "name"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "preferenceHideBets"
                                            }
                                        }]
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "EvolutionBet"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "EvolutionBet"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "user"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "id"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "name"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "preferenceHideBets"
                                            }
                                        }]
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "MultiplayerCrashBet"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "MultiplayerCrashBet"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "user"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "id"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "name"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "preferenceHideBets"
                                            }
                                        }]
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "MultiplayerSlideBet"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "MultiplayerSlideBet"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "user"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "id"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "name"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "preferenceHideBets"
                                            }
                                        }]
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "SoftswissBet"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "SoftswissBet"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "user"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "id"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "name"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "preferenceHideBets"
                                            }
                                        }]
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "ThirdPartyBet"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "ThirdPartyBet"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "GameKuratorGroup"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "GameKuratorGroup"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "slug"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "translation"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "icon"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "type"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "ChallengeTable"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "Challenge"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "award"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "minBetUsd"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "betCurrency"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "targetMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "creatorUser"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "game"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "slug"
                            }
                        }]
                    }
                }]
            }
        }]
    },
    Fe = 30,
    gn = async l => {
        var n, t, a, i;
        const {
            lang: e
        } = l.params;
        try {
            const r = ((n = l.params) == null ? void 0 : n.game) || l.url.pathname.replace(Be("/casino/games/", e), "");
            r || Dt(301, Be("/casino/games", e));
            const [s, o, d, u] = await bt([_t(l), Ie({
                load: l,
                doc: vt,
                variables: {
                    slug: "recommended-slots",
                    limit: Fe,
                    sort: Ft.popular,
                    showGames: !0,
                    offset: 0
                },
                cache: {
                    name: "/casino/games/[game]-recommended-slots-group"
                }
            }), Ie({
                load: l,
                doc: kn,
                variables: {
                    slug: r
                },
                cache: {
                    name: `/casino/games/${r}`
                }
            }), ht(l, l.url.pathname)]), c = d == null ? void 0 : d.slugKuratorGame;
            if (((a = (t = u == null ? void 0 : u.openGraph) == null ? void 0 : t.images) == null ? void 0 : a.length) === 0 && c) {
                const g = _e["/casino/games/[game]"](c);
                u.openGraph.images = (i = g == null ? void 0 : g.openGraph) == null ? void 0 : i.images
            }
            let m;
            return c && (m = u || _e["/casino/games/[game]"](c), m.generatedJsonLd = Nt(m, l.url.pathname, c, e)), {
                kuratorCollection: (s == null ? void 0 : s.kuratorCollection) || [],
                recommendedSlotsGroup: o == null ? void 0 : o.slugKuratorGroup,
                slugKuratorGame: c,
                seo: m || c && _e["/casino/games/[game]"](c)
            }
        } catch (r) {
            return console.error("/casino/games/+layout.svelte", r), {
                seo: void 0
            }
        }
    },
    Pi = Object.freeze(Object.defineProperty({
        __proto__: null,
        _LIMIT: Fe,
        load: gn
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    pn = l => ({
        mobile: l & 1
    }),
    Me = l => ({
        mobile: l[0]
    });

function _n(l) {
    let e, n, t, a, i, r;
    const s = l[5].default,
        o = at(s, l, l[4], Me);
    return {
        c() {
            e = D("div"), n = D("div"), o && o.c(), this.h()
        },
        l(d) {
            e = B(d, "DIV", {
                class: !0
            });
            var u = I(e);
            n = B(u, "DIV", {
                class: !0
            });
            var c = I(n);
            o && o.l(c), c.forEach(p), u.forEach(p), this.h()
        },
        h() {
            R(n, "class", "ctainer svelte-1ydxan2"), R(e, "class", "parent svelte-1ydxan2"), x(e, "theatre", l[1])
        },
        m(d, u) {
            T(d, e, u), b(e, n), o && o.m(n, null), a = !0, i || (r = it(t = mt.call(null, n, l[6])), i = !0)
        },
        p(d, [u]) {
            o && o.p && (!a || u & 17) && lt(o, s, d, d[4], a ? ot(s, d[4], u, pn) : rt(d[4]), Me), t && st(t.update) && u & 1 && t.update.call(null, d[6]), (!a || u & 2) && x(e, "theatre", d[1])
        },
        i(d) {
            a || (k(o, d), a = !0)
        },
        o(d) {
            _(o, d), a = !1
        },
        d(d) {
            d && p(e), o && o.d(d), i = !1, r()
        }
    }
}

function $n(l, e, n) {
    let t;
    te(l, dt, u => n(1, t = u));
    let {
        $$slots: a = {},
        $$scope: i
    } = e, r = Lt(), s = Pt(), o = !1;
    const d = u => {
        r.set(u.width), s.set(u.width), n(0, o = At(u.width))
    };
    return l.$$set = u => {
        "$$scope" in u && n(4, i = u.$$scope)
    }, [o, t, r, s, i, a, d]
}
class vn extends se {
    constructor(e) {
        super(), de(this, e, $n, _n, oe, {})
    }
}
const ae = {
    challenge: q._("Challenge"),
    createdBy: q._("Created By"),
    prize: q._("Prize"),
    game: q._("Game"),
    noChallenges: q._("We are unable to find any challenges"),
    noGameChallenges: l => ({
        id: "{game} has no active challenges",
        values: l
    }),
    noUserChallenges: l => ({
        id: "{user} has no completed challenges",
        values: l
    }),
    regionBlock: q._("They may not be available to your region")
};

function Le(l, e, n) {
    const t = l.slice();
    return t[12] = e[n], t
}

function Ve(l, e, n) {
    const t = l.slice();
    return t[9] = e[n], t
}

function hn(l) {
    let e, n;
    return e = new ut({
        props: {
            noHeadingPadding: !0,
            $$slots: {
                body: [yn],
                head: [bn]
            },
            $$scope: {
                ctx: l
            }
        }
    }), {
        c() {
            F(e.$$.fragment)
        },
        l(t) {
            S(e.$$.fragment, t)
        },
        m(t, a) {
            w(e, t, a), n = !0
        },
        p(t, a) {
            const i = {};
            a & 32931 && (i.$$scope = {
                dirty: a,
                ctx: t
            }), e.$set(i)
        },
        i(t) {
            n || (k(e.$$.fragment, t), n = !0)
        },
        o(t) {
            _(e.$$.fragment, t), n = !1
        },
        d(t) {
            y(e, t)
        }
    }
}

function Nn(l) {
    let e, n, t, a;
    const i = [Tn, Cn],
        r = [];

    function s(o, d) {
        return o[2] === "game" && o[4] ? 0 : o[2] === "statistics" && o[3] ? 1 : -1
    }
    return ~(e = s(l)) && (n = r[e] = i[e](l)), {
        c() {
            n && n.c(), t = Y()
        },
        l(o) {
            n && n.l(o), t = Y()
        },
        m(o, d) {
            ~e && r[e].m(o, d), T(o, t, d), a = !0
        },
        p(o, d) {
            let u = e;
            e = s(o), e === u ? ~e && r[e].p(o, d) : (n && (J(), _(r[u], 1, 1, () => {
                r[u] = null
            }), Q()), ~e ? (n = r[e], n ? n.p(o, d) : (n = r[e] = i[e](o), n.c()), k(n, 1), n.m(t.parentNode, t)) : n = null)
        },
        i(o) {
            a || (k(n), a = !0)
        },
        o(o) {
            _(n), a = !1
        },
        d(o) {
            o && p(t), ~e && r[e].d(o)
        }
    }
}

function Ae(l) {
    let e, n = l[7]._(ae.game) + "",
        t;
    return {
        c() {
            e = D("th"), t = H(n)
        },
        l(a) {
            e = B(a, "TH", {});
            var i = I(e);
            t = U(i, n), i.forEach(p)
        },
        m(a, i) {
            T(a, e, i), b(e, t)
        },
        p(a, i) {
            i & 128 && n !== (n = a[7]._(ae.game) + "") && j(t, n)
        },
        d(a) {
            a && p(e)
        }
    }
}

function bn(l) {
    let e, n, t = l[7]._(ae.challenge) + "",
        a, i, r, s, o = l[7]._(ae.createdBy) + "",
        d, u, c, m = l[7]._(ae.prize) + "",
        g, f = l[5] && Ae(l);
    return {
        c() {
            e = D("tr"), n = D("th"), a = H(t), i = P(), f && f.c(), r = P(), s = D("th"), d = H(o), u = P(), c = D("th"), g = H(m)
        },
        l($) {
            e = B($, "TR", {});
            var N = I(e);
            n = B(N, "TH", {});
            var A = I(n);
            a = U(A, t), A.forEach(p), i = z(N), f && f.l(N), r = z(N), s = B(N, "TH", {});
            var v = I(s);
            d = U(v, o), v.forEach(p), u = z(N), c = B(N, "TH", {});
            var M = I(c);
            g = U(M, m), M.forEach(p), N.forEach(p)
        },
        m($, N) {
            T($, e, N), b(e, n), b(n, a), b(e, i), f && f.m(e, null), b(e, r), b(e, s), b(s, d), b(e, u), b(e, c), b(c, g)
        },
        p($, N) {
            N & 128 && t !== (t = $[7]._(ae.challenge) + "") && j(a, t), $[5] ? f ? f.p($, N) : (f = Ae($), f.c(), f.m(e, r)) : f && (f.d(1), f = null), N & 128 && o !== (o = $[7]._(ae.createdBy) + "") && j(d, o), N & 128 && m !== (m = $[7]._(ae.prize) + "") && j(g, m)
        },
        d($) {
            $ && p(e), f && f.d()
        }
    }
}

function Fn(l) {
    let e = [],
        n = new Map,
        t, a, i = ie(l[0]);
    const r = s => s[12].id;
    for (let s = 0; s < i.length; s += 1) {
        let o = Le(l, i, s),
            d = r(o);
        n.set(d, e[s] = ze(d, o))
    }
    return {
        c() {
            for (let s = 0; s < e.length; s += 1) e[s].c();
            t = Y()
        },
        l(s) {
            for (let o = 0; o < e.length; o += 1) e[o].l(s);
            t = Y()
        },
        m(s, o) {
            for (let d = 0; d < e.length; d += 1) e[d] && e[d].m(s, o);
            T(s, t, o), a = !0
        },
        p(s, o) {
            o & 33 && (i = ie(s[0]), J(), e = qt(e, o, r, 1, s, i, n, t.parentNode, Ht, ze, t, Le), Q())
        },
        i(s) {
            if (!a) {
                for (let o = 0; o < i.length; o += 1) k(e[o]);
                a = !0
            }
        },
        o(s) {
            for (let o = 0; o < e.length; o += 1) _(e[o]);
            a = !1
        },
        d(s) {
            s && p(t);
            for (let o = 0; o < e.length; o += 1) e[o].d(s)
        }
    }
}

function Sn(l) {
    let e, n, t = ie(l[8]),
        a = [];
    for (let r = 0; r < t.length; r += 1) a[r] = qe(Ve(l, t, r));
    const i = r => _(a[r], 1, 1, () => {
        a[r] = null
    });
    return {
        c() {
            for (let r = 0; r < a.length; r += 1) a[r].c();
            e = Y()
        },
        l(r) {
            for (let s = 0; s < a.length; s += 1) a[s].l(r);
            e = Y()
        },
        m(r, s) {
            for (let o = 0; o < a.length; o += 1) a[o] && a[o].m(r, s);
            T(r, e, s), n = !0
        },
        p(r, s) {
            if (s & 32) {
                t = ie(r[8]);
                let o;
                for (o = 0; o < t.length; o += 1) {
                    const d = Ve(r, t, o);
                    a[o] ? (a[o].p(d, s), k(a[o], 1)) : (a[o] = qe(d), a[o].c(), k(a[o], 1), a[o].m(e.parentNode, e))
                }
                for (J(), o = t.length; o < a.length; o += 1) i(o);
                Q()
            }
        },
        i(r) {
            if (!n) {
                for (let s = 0; s < t.length; s += 1) k(a[s]);
                n = !0
            }
        },
        o(r) {
            a = a.filter(Boolean);
            for (let s = 0; s < a.length; s += 1) _(a[s]);
            n = !1
        },
        d(r) {
            r && p(e), pe(a, r)
        }
    }
}

function Pe(l) {
    let e, n, t;
    return n = new he({
        props: {
            to: "/casino/games/" + l[12].game.slug,
            $$slots: {
                default: [wn]
            },
            $$scope: {
                ctx: l
            }
        }
    }), {
        c() {
            e = D("td"), F(n.$$.fragment)
        },
        l(a) {
            e = B(a, "TD", {});
            var i = I(e);
            S(n.$$.fragment, i), i.forEach(p)
        },
        m(a, i) {
            T(a, e, i), w(n, e, null), t = !0
        },
        p(a, i) {
            const r = {};
            i & 1 && (r.to = "/casino/games/" + a[12].game.slug), i & 32769 && (r.$$scope = {
                dirty: i,
                ctx: a
            }), n.$set(r)
        },
        i(a) {
            t || (k(n.$$.fragment, a), t = !0)
        },
        o(a) {
            _(n.$$.fragment, a), t = !1
        },
        d(a) {
            a && p(e), y(n)
        }
    }
}

function wn(l) {
    let e = l[12].game.name + "",
        n;
    return {
        c() {
            n = H(e)
        },
        l(t) {
            n = U(t, e)
        },
        m(t, a) {
            T(t, n, a)
        },
        p(t, a) {
            a & 1 && e !== (e = t[12].game.name + "") && j(n, e)
        },
        d(t) {
            t && p(n)
        }
    }
}

function ze(l, e) {
    let n, t, a, i, r, s, o, d, u, c, m, g;
    a = new Qt({
        props: {
            minBetUsd: e[12].minBetUsd,
            betCurrency: e[12].betCurrency,
            targetMultiplier: e[12].targetMultiplier
        }
    });
    let f = e[5] && e[12].game && Pe(e);
    return o = new be({
        props: {
            user: e[12].creatorUser
        }
    }), c = new ve({
        props: {
            value: e[12].award,
            currency: e[12].currency
        }
    }), {
        key: l,
        first: null,
        c() {
            n = D("tr"), t = D("td"), F(a.$$.fragment), i = P(), f && f.c(), r = P(), s = D("td"), F(o.$$.fragment), d = P(), u = D("td"), F(c.$$.fragment), m = P(), this.h()
        },
        l($) {
            n = B($, "TR", {});
            var N = I(n);
            t = B(N, "TD", {});
            var A = I(t);
            S(a.$$.fragment, A), A.forEach(p), i = z(N), f && f.l(N), r = z(N), s = B(N, "TD", {});
            var v = I(s);
            S(o.$$.fragment, v), v.forEach(p), d = z(N), u = B(N, "TD", {});
            var M = I(u);
            S(c.$$.fragment, M), M.forEach(p), m = z(N), N.forEach(p), this.h()
        },
        h() {
            this.first = n
        },
        m($, N) {
            T($, n, N), b(n, t), w(a, t, null), b(n, i), f && f.m(n, null), b(n, r), b(n, s), w(o, s, null), b(n, d), b(n, u), w(c, u, null), b(n, m), g = !0
        },
        p($, N) {
            e = $;
            const A = {};
            N & 1 && (A.minBetUsd = e[12].minBetUsd), N & 1 && (A.betCurrency = e[12].betCurrency), N & 1 && (A.targetMultiplier = e[12].targetMultiplier), a.$set(A), e[5] && e[12].game ? f ? (f.p(e, N), N & 33 && k(f, 1)) : (f = Pe(e), f.c(), k(f, 1), f.m(n, r)) : f && (J(), _(f, 1, 1, () => {
                f = null
            }), Q());
            const v = {};
            N & 1 && (v.user = e[12].creatorUser), o.$set(v);
            const M = {};
            N & 1 && (M.value = e[12].award), N & 1 && (M.currency = e[12].currency), c.$set(M)
        },
        i($) {
            g || (k(a.$$.fragment, $), k(f), k(o.$$.fragment, $), k(c.$$.fragment, $), g = !0)
        },
        o($) {
            _(a.$$.fragment, $), _(f), _(o.$$.fragment, $), _(c.$$.fragment, $), g = !1
        },
        d($) {
            $ && p(n), y(a), f && f.d(), y(o), y(c)
        }
    }
}

function Ke(l) {
    let e, n, t;
    return n = new fe({
        props: {
            style: "line-height: 1.3",
            width: "10ch"
        }
    }), {
        c() {
            e = D("td"), F(n.$$.fragment)
        },
        l(a) {
            e = B(a, "TD", {});
            var i = I(e);
            S(n.$$.fragment, i), i.forEach(p)
        },
        m(a, i) {
            T(a, e, i), w(n, e, null), t = !0
        },
        i(a) {
            t || (k(n.$$.fragment, a), t = !0)
        },
        o(a) {
            _(n.$$.fragment, a), t = !1
        },
        d(a) {
            a && p(e), y(n)
        }
    }
}

function qe(l) {
    let e, n, t, a, i, r, s, o, d, u, c, m;
    t = new fe({
        props: {
            style: "line-height: 1.3",
            width: "20ch"
        }
    });
    let g = l[5] && Ke();
    return s = new fe({
        props: {
            style: "line-height: 1.3",
            width: "6ch"
        }
    }), u = new fe({
        props: {
            style: "line-height: 1.3",
            width: "10ch"
        }
    }), {
        c() {
            e = D("tr"), n = D("td"), F(t.$$.fragment), a = P(), g && g.c(), i = P(), r = D("td"), F(s.$$.fragment), o = P(), d = D("td"), F(u.$$.fragment), c = P()
        },
        l(f) {
            e = B(f, "TR", {});
            var $ = I(e);
            n = B($, "TD", {});
            var N = I(n);
            S(t.$$.fragment, N), N.forEach(p), a = z($), g && g.l($), i = z($), r = B($, "TD", {});
            var A = I(r);
            S(s.$$.fragment, A), A.forEach(p), o = z($), d = B($, "TD", {});
            var v = I(d);
            S(u.$$.fragment, v), v.forEach(p), c = z($), $.forEach(p)
        },
        m(f, $) {
            T(f, e, $), b(e, n), w(t, n, null), b(e, a), g && g.m(e, null), b(e, i), b(e, r), w(s, r, null), b(e, o), b(e, d), w(u, d, null), b(e, c), m = !0
        },
        p(f, $) {
            f[5] ? g ? $ & 32 && k(g, 1) : (g = Ke(), g.c(), k(g, 1), g.m(e, i)) : g && (J(), _(g, 1, 1, () => {
                g = null
            }), Q())
        },
        i(f) {
            m || (k(t.$$.fragment, f), k(g), k(s.$$.fragment, f), k(u.$$.fragment, f), m = !0)
        },
        o(f) {
            _(t.$$.fragment, f), _(g), _(s.$$.fragment, f), _(u.$$.fragment, f), m = !1
        },
        d(f) {
            f && p(e), y(t), g && g.d(), y(s), y(u)
        }
    }
}

function yn(l) {
    let e, n, t, a;
    const i = [Sn, Fn],
        r = [];

    function s(o, d) {
        return o[1] ? 0 : 1
    }
    return e = s(l), n = r[e] = i[e](l), {
        c() {
            n.c(), t = Y()
        },
        l(o) {
            n.l(o), t = Y()
        },
        m(o, d) {
            r[e].m(o, d), T(o, t, d), a = !0
        },
        p(o, d) {
            let u = e;
            e = s(o), e === u ? r[e].p(o, d) : (J(), _(r[u], 1, 1, () => {
                r[u] = null
            }), Q(), n = r[e], n ? n.p(o, d) : (n = r[e] = i[e](o), n.c()), k(n, 1), n.m(t.parentNode, t))
        },
        i(o) {
            a || (k(n), a = !0)
        },
        o(o) {
            _(n), a = !1
        },
        d(o) {
            o && p(t), r[e].d(o)
        }
    }
}

function Cn(l) {
    let e, n;
    return e = new ft({
        props: {
            icon: "no-stats",
            $$slots: {
                default: [Gn]
            },
            $$scope: {
                ctx: l
            }
        }
    }), {
        c() {
            F(e.$$.fragment)
        },
        l(t) {
            S(e.$$.fragment, t)
        },
        m(t, a) {
            w(e, t, a), n = !0
        },
        p(t, a) {
            const i = {};
            a & 32904 && (i.$$scope = {
                dirty: a,
                ctx: t
            }), e.$set(i)
        },
        i(t) {
            n || (k(e.$$.fragment, t), n = !0)
        },
        o(t) {
            _(e.$$.fragment, t), n = !1
        },
        d(t) {
            y(e, t)
        }
    }
}

function Tn(l) {
    let e, n;
    return e = new ft({
        props: {
            icon: "no-stats",
            $$slots: {
                default: [En]
            },
            $$scope: {
                ctx: l
            }
        }
    }), {
        c() {
            F(e.$$.fragment)
        },
        l(t) {
            S(e.$$.fragment, t)
        },
        m(t, a) {
            w(e, t, a), n = !0
        },
        p(t, a) {
            const i = {};
            a & 32912 && (i.$$scope = {
                dirty: a,
                ctx: t
            }), e.$set(i)
        },
        i(t) {
            n || (k(e.$$.fragment, t), n = !0)
        },
        o(t) {
            _(e.$$.fragment, t), n = !1
        },
        d(t) {
            y(e, t)
        }
    }
}

function Gn(l) {
    let e = l[7]._(ae.noUserChallenges({
            user: l[3]
        })) + "",
        n;
    return {
        c() {
            n = H(e)
        },
        l(t) {
            n = U(t, e)
        },
        m(t, a) {
            T(t, n, a)
        },
        p(t, a) {
            a & 136 && e !== (e = t[7]._(ae.noUserChallenges({
                user: t[3]
            })) + "") && j(n, e)
        },
        d(t) {
            t && p(n)
        }
    }
}

function En(l) {
    let e = l[7]._(ae.noGameChallenges({
            game: $e(l[4] ? ? "")
        })) + "",
        n;
    return {
        c() {
            n = H(e)
        },
        l(t) {
            n = U(t, e)
        },
        m(t, a) {
            T(t, n, a)
        },
        p(t, a) {
            a & 144 && e !== (e = t[7]._(ae.noGameChallenges({
                game: $e(t[4] ? ? "")
            })) + "") && j(n, e)
        },
        d(t) {
            t && p(n)
        }
    }
}

function Dn(l) {
    let e, n, t, a;
    const i = [Nn, hn],
        r = [];

    function s(o, d) {
        return o[6] ? 0 : 1
    }
    return e = s(l), n = r[e] = i[e](l), {
        c() {
            n.c(), t = Y()
        },
        l(o) {
            n.l(o), t = Y()
        },
        m(o, d) {
            r[e].m(o, d), T(o, t, d), a = !0
        },
        p(o, [d]) {
            let u = e;
            e = s(o), e === u ? r[e].p(o, d) : (J(), _(r[u], 1, 1, () => {
                r[u] = null
            }), Q(), n = r[e], n ? n.p(o, d) : (n = r[e] = i[e](o), n.c()), k(n, 1), n.m(t.parentNode, t))
        },
        i(o) {
            a || (k(n), a = !0)
        },
        o(o) {
            _(n), a = !1
        },
        d(o) {
            o && p(t), r[e].d(o)
        }
    }
}

function Bn(l, e, n) {
    let t, a, i;
    te(l, ue, m => n(7, i = m));
    let {
        challengeList: r
    } = e, {
        loading: s = !1
    } = e, {
        view: o = "statistics"
    } = e, {
        user: d = void 0
    } = e, {
        game: u = void 0
    } = e, c = Array.from({
        length: 3
    });
    return l.$$set = m => {
        "challengeList" in m && n(0, r = m.challengeList), "loading" in m && n(1, s = m.loading), "view" in m && n(2, o = m.view), "user" in m && n(3, d = m.user), "game" in m && n(4, u = m.game)
    }, l.$$.update = () => {
        l.$$.dirty & 3 && n(6, t = r.length === 0 && s === !1), l.$$.dirty & 4 && n(5, a = o !== "game")
    }, [r, s, o, d, u, a, t, i, c]
}
class In extends se {
    constructor(e) {
        super(), de(this, e, Bn, Dn, oe, {
            challengeList: 0,
            loading: 1,
            view: 2,
            user: 3,
            game: 4
        })
    }
}
const Se = {
        profit: q._("Big Wins"),
        multiplier: q._("Lucky Wins"),
        description: q._("Description"),
        challenges: q._("Challenges"),
        position: q._("Position"),
        rank: q._("Rank"),
        user: q._("User"),
        date: q._("Date"),
        bet: q._("Bet"),
        edge: q._("Edge"),
        leaderBoardMultiplier: q._("Multiplier"),
        payout: q._("Payout"),
        empty: q._("There are currently no bets to show."),
        na: q._("N/A")
    },
    Mn = { ...Se,
        bet: q._("Amount"),
        payout: q._("Winnings"),
        empty: q._("There are currently no games to show.")
    },
    Ln = {
        stake: Se,
        sweeps: Mn
    },
    Z = Ln[Ut] || Se;

function He(l, e, n) {
    const t = l.slice();
    return t[6] = e[n].user, t[7] = e[n].updatedAt, t[8] = e[n].amount, t[9] = e[n].payoutMultiplier, t[10] = e[n].payout, t[11] = e[n].position, t[12] = e[n].currency, t
}

function Vn(l) {
    let e = l[1]._(Z.rank) + "",
        n;
    return {
        c() {
            n = H(e)
        },
        l(t) {
            n = U(t, e)
        },
        m(t, a) {
            T(t, n, a)
        },
        p(t, a) {
            a & 2 && e !== (e = t[1]._(Z.rank) + "") && j(n, e)
        },
        d(t) {
            t && p(n)
        }
    }
}

function An(l) {
    let e = l[1]._(Z.user) + "",
        n;
    return {
        c() {
            n = H(e)
        },
        l(t) {
            n = U(t, e)
        },
        m(t, a) {
            T(t, n, a)
        },
        p(t, a) {
            a & 2 && e !== (e = t[1]._(Z.user) + "") && j(n, e)
        },
        d(t) {
            t && p(n)
        }
    }
}

function Pn(l) {
    let e = l[1]._(Z.date) + "",
        n;
    return {
        c() {
            n = H(e)
        },
        l(t) {
            n = U(t, e)
        },
        m(t, a) {
            T(t, n, a)
        },
        p(t, a) {
            a & 2 && e !== (e = t[1]._(Z.date) + "") && j(n, e)
        },
        d(t) {
            t && p(n)
        }
    }
}

function zn(l) {
    let e = l[1]._(Z.bet) + "",
        n;
    return {
        c() {
            n = H(e)
        },
        l(t) {
            n = U(t, e)
        },
        m(t, a) {
            T(t, n, a)
        },
        p(t, a) {
            a & 2 && e !== (e = t[1]._(Z.bet) + "") && j(n, e)
        },
        d(t) {
            t && p(n)
        }
    }
}

function Kn(l) {
    let e = l[1]._(Z.leaderBoardMultiplier) + "",
        n;
    return {
        c() {
            n = H(e)
        },
        l(t) {
            n = U(t, e)
        },
        m(t, a) {
            T(t, n, a)
        },
        p(t, a) {
            a & 2 && e !== (e = t[1]._(Z.leaderBoardMultiplier) + "") && j(n, e)
        },
        d(t) {
            t && p(n)
        }
    }
}

function qn(l) {
    let e = l[1]._(Z.payout) + "",
        n;
    return {
        c() {
            n = H(e)
        },
        l(t) {
            n = U(t, e)
        },
        m(t, a) {
            T(t, n, a)
        },
        p(t, a) {
            a & 2 && e !== (e = t[1]._(Z.payout) + "") && j(n, e)
        },
        d(t) {
            t && p(n)
        }
    }
}

function Hn(l) {
    let e, n, t, a, i, r, s, o, d, u, c, m, g, f, $, N, A, v, M;
    return t = new ne({
        props: {
            weight: "bold",
            $$slots: {
                default: [Vn]
            },
            $$scope: {
                ctx: l
            }
        }
    }), r = new ne({
        props: {
            weight: "bold",
            $$slots: {
                default: [An]
            },
            $$scope: {
                ctx: l
            }
        }
    }), d = new ne({
        props: {
            weight: "bold",
            $$slots: {
                default: [Pn]
            },
            $$scope: {
                ctx: l
            }
        }
    }), m = new ne({
        props: {
            weight: "bold",
            $$slots: {
                default: [zn]
            },
            $$scope: {
                ctx: l
            }
        }
    }), $ = new ne({
        props: {
            weight: "bold",
            $$slots: {
                default: [Kn]
            },
            $$scope: {
                ctx: l
            }
        }
    }), v = new ne({
        props: {
            weight: "bold",
            $$slots: {
                default: [qn]
            },
            $$scope: {
                ctx: l
            }
        }
    }), {
        c() {
            e = D("tr"), n = D("th"), F(t.$$.fragment), a = P(), i = D("th"), F(r.$$.fragment), s = P(), o = D("th"), F(d.$$.fragment), u = P(), c = D("th"), F(m.$$.fragment), g = P(), f = D("th"), F($.$$.fragment), N = P(), A = D("th"), F(v.$$.fragment)
        },
        l(E) {
            e = B(E, "TR", {});
            var h = I(e);
            n = B(h, "TH", {});
            var C = I(n);
            S(t.$$.fragment, C), C.forEach(p), a = z(h), i = B(h, "TH", {});
            var K = I(i);
            S(r.$$.fragment, K), K.forEach(p), s = z(h), o = B(h, "TH", {});
            var O = I(o);
            S(d.$$.fragment, O), O.forEach(p), u = z(h), c = B(h, "TH", {});
            var L = I(c);
            S(m.$$.fragment, L), L.forEach(p), g = z(h), f = B(h, "TH", {});
            var W = I(f);
            S($.$$.fragment, W), W.forEach(p), N = z(h), A = B(h, "TH", {});
            var G = I(A);
            S(v.$$.fragment, G), G.forEach(p), h.forEach(p)
        },
        m(E, h) {
            T(E, e, h), b(e, n), w(t, n, null), b(e, a), b(e, i), w(r, i, null), b(e, s), b(e, o), w(d, o, null), b(e, u), b(e, c), w(m, c, null), b(e, g), b(e, f), w($, f, null), b(e, N), b(e, A), w(v, A, null), M = !0
        },
        p(E, h) {
            const C = {};
            h & 32770 && (C.$$scope = {
                dirty: h,
                ctx: E
            }), t.$set(C);
            const K = {};
            h & 32770 && (K.$$scope = {
                dirty: h,
                ctx: E
            }), r.$set(K);
            const O = {};
            h & 32770 && (O.$$scope = {
                dirty: h,
                ctx: E
            }), d.$set(O);
            const L = {};
            h & 32770 && (L.$$scope = {
                dirty: h,
                ctx: E
            }), m.$set(L);
            const W = {};
            h & 32770 && (W.$$scope = {
                dirty: h,
                ctx: E
            }), $.$set(W);
            const G = {};
            h & 32770 && (G.$$scope = {
                dirty: h,
                ctx: E
            }), v.$set(G)
        },
        i(E) {
            M || (k(t.$$.fragment, E), k(r.$$.fragment, E), k(d.$$.fragment, E), k(m.$$.fragment, E), k($.$$.fragment, E), k(v.$$.fragment, E), M = !0)
        },
        o(E) {
            _(t.$$.fragment, E), _(r.$$.fragment, E), _(d.$$.fragment, E), _(m.$$.fragment, E), _($.$$.fragment, E), _(v.$$.fragment, E), M = !1
        },
        d(E) {
            E && p(e), y(t), y(r), y(d), y(m), y($), y(v)
        }
    }
}

function Ue(l) {
    let e, n, t, a, i, r, s, o, d, u, c, m, g, f, $, N, A, v, M, E;
    return t = new tn({
        props: {
            position: l[11]
        }
    }), r = new be({
        props: {
            user: l[6],
            showGhostPreference: !0
        }
    }), d = new en({
        props: {
            value: l[7]
        }
    }), m = new ve({
        props: {
            value: l[8],
            currency: l[12],
            align: "center"
        }
    }), $ = new ct({
        props: {
            value: l[9]
        }
    }), v = new ve({
        props: {
            value: l[10],
            currency: l[12],
            align: "center"
        }
    }), {
        c() {
            e = D("tr"), n = D("td"), F(t.$$.fragment), a = P(), i = D("td"), F(r.$$.fragment), s = P(), o = D("td"), F(d.$$.fragment), u = P(), c = D("td"), F(m.$$.fragment), g = P(), f = D("td"), F($.$$.fragment), N = P(), A = D("td"), F(v.$$.fragment), M = P()
        },
        l(h) {
            e = B(h, "TR", {});
            var C = I(e);
            n = B(C, "TD", {});
            var K = I(n);
            S(t.$$.fragment, K), K.forEach(p), a = z(C), i = B(C, "TD", {});
            var O = I(i);
            S(r.$$.fragment, O), O.forEach(p), s = z(C), o = B(C, "TD", {});
            var L = I(o);
            S(d.$$.fragment, L), L.forEach(p), u = z(C), c = B(C, "TD", {});
            var W = I(c);
            S(m.$$.fragment, W), W.forEach(p), g = z(C), f = B(C, "TD", {});
            var G = I(f);
            S($.$$.fragment, G), G.forEach(p), N = z(C), A = B(C, "TD", {});
            var V = I(A);
            S(v.$$.fragment, V), V.forEach(p), M = z(C), C.forEach(p)
        },
        m(h, C) {
            T(h, e, C), b(e, n), w(t, n, null), b(e, a), b(e, i), w(r, i, null), b(e, s), b(e, o), w(d, o, null), b(e, u), b(e, c), w(m, c, null), b(e, g), b(e, f), w($, f, null), b(e, N), b(e, A), w(v, A, null), b(e, M), E = !0
        },
        p(h, C) {
            const K = {};
            C & 1 && (K.position = h[11]), t.$set(K);
            const O = {};
            C & 1 && (O.user = h[6]), r.$set(O);
            const L = {};
            C & 1 && (L.value = h[7]), d.$set(L);
            const W = {};
            C & 1 && (W.value = h[8]), C & 1 && (W.currency = h[12]), m.$set(W);
            const G = {};
            C & 1 && (G.value = h[9]), $.$set(G);
            const V = {};
            C & 1 && (V.value = h[10]), C & 1 && (V.currency = h[12]), v.$set(V)
        },
        i(h) {
            E || (k(t.$$.fragment, h), k(r.$$.fragment, h), k(d.$$.fragment, h), k(m.$$.fragment, h), k($.$$.fragment, h), k(v.$$.fragment, h), E = !0)
        },
        o(h) {
            _(t.$$.fragment, h), _(r.$$.fragment, h), _(d.$$.fragment, h), _(m.$$.fragment, h), _($.$$.fragment, h), _(v.$$.fragment, h), E = !1
        },
        d(h) {
            h && p(e), y(t), y(r), y(d), y(m), y($), y(v)
        }
    }
}

function Un(l) {
    let e, n, t = ie(l[0]),
        a = [];
    for (let r = 0; r < t.length; r += 1) a[r] = Ue(He(l, t, r));
    const i = r => _(a[r], 1, 1, () => {
        a[r] = null
    });
    return {
        c() {
            for (let r = 0; r < a.length; r += 1) a[r].c();
            e = Y()
        },
        l(r) {
            for (let s = 0; s < a.length; s += 1) a[s].l(r);
            e = Y()
        },
        m(r, s) {
            for (let o = 0; o < a.length; o += 1) a[o] && a[o].m(r, s);
            T(r, e, s), n = !0
        },
        p(r, s) {
            if (s & 1) {
                t = ie(r[0]);
                let o;
                for (o = 0; o < t.length; o += 1) {
                    const d = He(r, t, o);
                    a[o] ? (a[o].p(d, s), k(a[o], 1)) : (a[o] = Ue(d), a[o].c(), k(a[o], 1), a[o].m(e.parentNode, e))
                }
                for (J(), o = t.length; o < a.length; o += 1) i(o);
                Q()
            }
        },
        i(r) {
            if (!n) {
                for (let s = 0; s < t.length; s += 1) k(a[s]);
                n = !0
            }
        },
        o(r) {
            a = a.filter(Boolean);
            for (let s = 0; s < a.length; s += 1) _(a[s]);
            n = !1
        },
        d(r) {
            r && p(e), pe(a, r)
        }
    }
}

function On(l) {
    let e, n, t;
    return n = new ut({
        props: {
            $$slots: {
                body: [Un],
                thead: [Hn]
            },
            $$scope: {
                ctx: l
            }
        }
    }), {
        c() {
            e = D("div"), F(n.$$.fragment), this.h()
        },
        l(a) {
            e = B(a, "DIV", {
                class: !0
            });
            var i = I(e);
            S(n.$$.fragment, i), i.forEach(p), this.h()
        },
        h() {
            R(e, "class", "leader-board svelte-1fe5vlw")
        },
        m(a, i) {
            T(a, e, i), w(n, e, null), t = !0
        },
        p(a, [i]) {
            const r = {};
            i & 32771 && (r.$$scope = {
                dirty: i,
                ctx: a
            }), n.$set(r)
        },
        i(a) {
            t || (k(n.$$.fragment, a), t = !0)
        },
        o(a) {
            _(n.$$.fragment, a), t = !1
        },
        d(a) {
            a && p(e), y(n)
        }
    }
}

function Rn(l, e, n) {
    let t, a, i;
    te(l, ue, d => n(1, i = d));
    let {
        type: r
    } = e, {
        kuratorGame: s
    } = e;
    const o = d => d.map(u => ({ ...u.bet.bet,
        position: u.position,
        iid: u.bet.iid,
        updatedAt: u.updatedAt
    }));
    return l.$$set = d => {
        "type" in d && n(2, r = d.type), "kuratorGame" in d && n(3, s = d.kuratorGame)
    }, l.$$.update = () => {
        l.$$.dirty & 12 && n(4, t = r === "multiplier" ? s == null ? void 0 : s.multiplierLeaderboard : r === "profit" ? s == null ? void 0 : s.profitLeaderboard : !1), l.$$.dirty & 16 && n(0, a = t ? o(t) : [])
    }, [a, i, r, s, t]
}
class Wn extends se {
    constructor(e) {
        super(), de(this, e, Rn, On, oe, {
            type: 2,
            kuratorGame: 3
        })
    }
}

function jn(l) {
    var o, d, u, c;
    let e, n, t, a, i, r, s;
    return n = new nn({}), a = new ct({
        props: {
            size: "sm",
            value: (o = l[0]) == null ? void 0 : o.payoutMultiplier,
            weight: "semibold",
            config: "none",
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }
    }), r = new be({
        props: {
            size: "sm",
            user: (c = (u = (d = l[0]) == null ? void 0 : d.bet) == null ? void 0 : u.bet) == null ? void 0 : c.user,
            showGhostPreference: !0
        }
    }), {
        c() {
            e = D("div"), F(n.$$.fragment), t = H(`
   
  `), F(a.$$.fragment), i = H(`
   
  `), F(r.$$.fragment), this.h()
        },
        l(m) {
            e = B(m, "DIV", {
                class: !0
            });
            var g = I(e);
            S(n.$$.fragment, g), t = U(g, `
   
  `), S(a.$$.fragment, g), i = U(g, `
   
  `), S(r.$$.fragment, g), g.forEach(p), this.h()
        },
        h() {
            R(e, "class", "luckiest-win-wrap svelte-tyy7gg")
        },
        m(m, g) {
            T(m, e, g), w(n, e, null), b(e, t), w(a, e, null), b(e, i), w(r, e, null), s = !0
        },
        p(m, [g]) {
            var N, A, v, M;
            const f = {};
            g & 1 && (f.value = (N = m[0]) == null ? void 0 : N.payoutMultiplier), a.$set(f);
            const $ = {};
            g & 1 && ($.user = (M = (v = (A = m[0]) == null ? void 0 : A.bet) == null ? void 0 : v.bet) == null ? void 0 : M.user), r.$set($)
        },
        i(m) {
            s || (k(n.$$.fragment, m), k(a.$$.fragment, m), k(r.$$.fragment, m), s = !0)
        },
        o(m) {
            _(n.$$.fragment, m), _(a.$$.fragment, m), _(r.$$.fragment, m), s = !1
        },
        d(m) {
            m && p(e), y(n), y(a), y(r)
        }
    }
}

function Jn(l, e, n) {
    let t, {
        kuratorGame: a
    } = e;
    return l.$$set = i => {
        "kuratorGame" in i && n(1, a = i.kuratorGame)
    }, l.$$.update = () => {
        var i;
        l.$$.dirty & 2 && n(0, t = (i = a == null ? void 0 : a.multiplierLeaderboard) == null ? void 0 : i[0])
    }, [t, a]
}
class Qn extends se {
    constructor(e) {
        super(), de(this, e, Jn, jn, oe, {
            kuratorGame: 1
        })
    }
}
const {
    Boolean: pt
} = Kt;

function Oe(l, e, n) {
    const t = l.slice();
    return t[19] = e[n].group, t
}

function Re(l, e, n) {
    const t = l.slice();
    return t[22] = e[n], t
}

function Yn(l) {
    let e;
    return {
        c() {
            e = H(l[5])
        },
        l(n) {
            e = U(n, l[5])
        },
        m(n, t) {
            T(n, e, t)
        },
        p(n, t) {
            t & 32 && j(e, n[5])
        },
        d(n) {
            n && p(e)
        }
    }
}

function Xn(l) {
    let e, n;
    return e = new ne({
        props: {
            tag: "h1",
            variant: "highlighted",
            size: "base",
            weight: "semibold",
            contentStyle: "display: inline",
            $$slots: {
                default: [Yn]
            },
            $$scope: {
                ctx: l
            }
        }
    }), {
        c() {
            F(e.$$.fragment)
        },
        l(t) {
            S(e.$$.fragment, t)
        },
        m(t, a) {
            w(e, t, a), n = !0
        },
        p(t, a) {
            const i = {};
            a & 33554464 && (i.$$scope = {
                dirty: a,
                ctx: t
            }), e.$set(i)
        },
        i(t) {
            n || (k(e.$$.fragment, t), n = !0)
        },
        o(t) {
            _(e.$$.fragment, t), n = !1
        },
        d(t) {
            y(e, t)
        }
    }
}

function We(l) {
    var t, a;
    let e, n;
    return e = new he({
        props: {
            variant: "subtle-link",
            size: "lg",
            disabled: !l[11],
            to: l[11] && ce(ke.casinoGroup, {
                groupSlug: (a = (t = l[11]) == null ? void 0 : t.group) == null ? void 0 : a.slug
            }),
            $$slots: {
                default: [Zn]
            },
            $$scope: {
                ctx: l
            }
        }
    }), {
        c() {
            F(e.$$.fragment)
        },
        l(i) {
            S(e.$$.fragment, i)
        },
        m(i, r) {
            w(e, i, r), n = !0
        },
        p(i, r) {
            var o, d;
            const s = {};
            r & 2048 && (s.disabled = !i[11]), r & 2048 && (s.to = i[11] && ce(ke.casinoGroup, {
                groupSlug: (d = (o = i[11]) == null ? void 0 : o.group) == null ? void 0 : d.slug
            })), r & 33556480 && (s.$$scope = {
                dirty: r,
                ctx: i
            }), e.$set(s)
        },
        i(i) {
            n || (k(e.$$.fragment, i), n = !0)
        },
        o(i) {
            _(e.$$.fragment, i), n = !1
        },
        d(i) {
            y(e, i)
        }
    }
}

function Zn(l) {
    var t, a;
    let e = ((a = (t = l[11]) == null ? void 0 : t.group) == null ? void 0 : a.translation) + "",
        n;
    return {
        c() {
            n = H(e)
        },
        l(i) {
            n = U(i, e)
        },
        m(i, r) {
            T(i, n, r)
        },
        p(i, r) {
            var s, o;
            r & 2048 && e !== (e = ((o = (s = i[11]) == null ? void 0 : s.group) == null ? void 0 : o.translation) + "") && j(n, e)
        },
        d(i) {
            i && p(n)
        }
    }
}

function je(l) {
    let e, n;
    return e = new Ne({
        props: {
            rounded: !0,
            $$slots: {
                default: [xn]
            },
            $$scope: {
                ctx: l
            }
        }
    }), {
        c() {
            F(e.$$.fragment)
        },
        l(t) {
            S(e.$$.fragment, t)
        },
        m(t, a) {
            w(e, t, a), n = !0
        },
        p(t, a) {
            const i = {};
            a & 33554433 && (i.$$scope = {
                dirty: a,
                ctx: t
            }), e.$set(i)
        },
        i(t) {
            n || (k(e.$$.fragment, t), n = !0)
        },
        o(t) {
            _(e.$$.fragment, t), n = !1
        },
        d(t) {
            y(e, t)
        }
    }
}

function xn(l) {
    let e, n;
    return e = new Qn({
        props: {
            kuratorGame: l[0]
        }
    }), {
        c() {
            F(e.$$.fragment)
        },
        l(t) {
            S(e.$$.fragment, t)
        },
        m(t, a) {
            w(e, t, a), n = !0
        },
        p(t, a) {
            const i = {};
            a & 1 && (i.kuratorGame = t[0]), e.$set(i)
        },
        i(t) {
            n || (k(e.$$.fragment, t), n = !0)
        },
        o(t) {
            _(e.$$.fragment, t), n = !1
        },
        d(t) {
            y(e, t)
        }
    }
}

function ea(l) {
    let e, n, t;
    return n = new ln({
        props: {
            style: "transform: scale(1.25);"
        }
    }), {
        c() {
            e = D("div"), F(n.$$.fragment), this.h()
        },
        l(a) {
            e = B(a, "DIV", {
                class: !0
            });
            var i = I(e);
            S(n.$$.fragment, i), i.forEach(p), this.h()
        },
        h() {
            R(e, "class", "arrow svelte-1wq7z2y"), x(e, "isCollapsed", l[3])
        },
        m(a, i) {
            T(a, e, i), w(n, e, null), t = !0
        },
        p(a, i) {
            (!t || i & 8) && x(e, "isCollapsed", a[3])
        },
        i(a) {
            t || (k(n.$$.fragment, a), t = !0)
        },
        o(a) {
            _(n.$$.fragment, a), t = !1
        },
        d(a) {
            a && p(e), y(n)
        }
    }
}

function Je(l) {
    let e, n, t, a, i, r, s;
    n = new Jt({
        props: {
            variant: "light",
            $$slots: {
                default: [na]
            },
            $$scope: {
                ctx: l
            }
        }
    });
    const o = [la, ia, aa],
        d = [];

    function u(c, m) {
        return c[4] === "description" ? 0 : c[4] === "challenges" ? 1 : 2
    }
    return a = u(l), i = d[a] = o[a](l), {
        c() {
            e = D("div"), F(n.$$.fragment), t = P(), i.c(), this.h()
        },
        l(c) {
            e = B(c, "DIV", {
                class: !0
            });
            var m = I(e);
            S(n.$$.fragment, m), t = z(m), i.l(m), m.forEach(p), this.h()
        },
        h() {
            R(e, "class", "game-meta-content svelte-1wq7z2y")
        },
        m(c, m) {
            T(c, e, m), w(n, e, null), b(e, t), d[a].m(e, null), s = !0
        },
        p(c, m) {
            const g = {};
            m & 33562896 && (g.$$scope = {
                dirty: m,
                ctx: c
            }), n.$set(g);
            let f = a;
            a = u(c), a === f ? d[a].p(c, m) : (J(), _(d[f], 1, 1, () => {
                d[f] = null
            }), Q(), i = d[a], i ? i.p(c, m) : (i = d[a] = o[a](c), i.c()), k(i, 1), i.m(e, null))
        },
        i(c) {
            s || (k(n.$$.fragment, c), k(i), c && (r || Bt(() => {
                r = Mt(e, Rt, {
                    y: -10,
                    opacity: 0,
                    delay: 50,
                    duration: 300
                }), r.start()
            })), s = !0)
        },
        o(c) {
            _(n.$$.fragment, c), _(i), s = !1
        },
        d(c) {
            c && p(e), y(n), d[a].d()
        }
    }
}

function ta(l) {
    let e = l[13]._(Z[l[22]]) + "",
        n, t;
    return {
        c() {
            n = H(e), t = P()
        },
        l(a) {
            n = U(a, e), t = z(a)
        },
        m(a, i) {
            T(a, n, i), T(a, t, i)
        },
        p(a, i) {
            i & 8448 && e !== (e = a[13]._(Z[a[22]]) + "") && j(n, e)
        },
        d(a) {
            a && (p(n), p(t))
        }
    }
}

function Qe(l) {
    let e, n;

    function t() {
        return l[17](l[22])
    }
    return e = new kt({
        props: {
            active: l[4] === l[22],
            $$slots: {
                default: [ta]
            },
            $$scope: {
                ctx: l
            }
        }
    }), e.$on("click", t), {
        c() {
            F(e.$$.fragment)
        },
        l(a) {
            S(e.$$.fragment, a)
        },
        m(a, i) {
            w(e, a, i), n = !0
        },
        p(a, i) {
            l = a;
            const r = {};
            i & 272 && (r.active = l[4] === l[22]), i & 33562880 && (r.$$scope = {
                dirty: i,
                ctx: l
            }), e.$set(r)
        },
        i(a) {
            n || (k(e.$$.fragment, a), n = !0)
        },
        o(a) {
            _(e.$$.fragment, a), n = !1
        },
        d(a) {
            y(e, a)
        }
    }
}

function na(l) {
    let e, n, t = ie(l[8]),
        a = [];
    for (let r = 0; r < t.length; r += 1) a[r] = Qe(Re(l, t, r));
    const i = r => _(a[r], 1, 1, () => {
        a[r] = null
    });
    return {
        c() {
            for (let r = 0; r < a.length; r += 1) a[r].c();
            e = Y()
        },
        l(r) {
            for (let s = 0; s < a.length; s += 1) a[s].l(r);
            e = Y()
        },
        m(r, s) {
            for (let o = 0; o < a.length; o += 1) a[o] && a[o].m(r, s);
            T(r, e, s), n = !0
        },
        p(r, s) {
            if (s & 8464) {
                t = ie(r[8]);
                let o;
                for (o = 0; o < t.length; o += 1) {
                    const d = Re(r, t, o);
                    a[o] ? (a[o].p(d, s), k(a[o], 1)) : (a[o] = Qe(d), a[o].c(), k(a[o], 1), a[o].m(e.parentNode, e))
                }
                for (J(), o = t.length; o < a.length; o += 1) i(o);
                Q()
            }
        },
        i(r) {
            if (!n) {
                for (let s = 0; s < t.length; s += 1) k(a[s]);
                n = !0
            }
        },
        o(r) {
            a = a.filter(pt);
            for (let s = 0; s < a.length; s += 1) _(a[s]);
            n = !1
        },
        d(r) {
            r && p(e), pe(a, r)
        }
    }
}

function aa(l) {
    let e, n;
    return e = new Wn({
        props: {
            kuratorGame: l[0],
            width: l[2],
            type: l[4]
        }
    }), {
        c() {
            F(e.$$.fragment)
        },
        l(t) {
            S(e.$$.fragment, t)
        },
        m(t, a) {
            w(e, t, a), n = !0
        },
        p(t, a) {
            const i = {};
            a & 1 && (i.kuratorGame = t[0]), a & 4 && (i.width = t[2]), a & 16 && (i.type = t[4]), e.$set(i)
        },
        i(t) {
            n || (k(e.$$.fragment, t), n = !0)
        },
        o(t) {
            _(e.$$.fragment, t), n = !1
        },
        d(t) {
            y(e, t)
        }
    }
}

function ia(l) {
    var t;
    let e, n;
    return e = new In({
        props: {
            game: (t = l[0]) == null ? void 0 : t.name,
            view: "game",
            challengeList: l[9]
        }
    }), {
        c() {
            F(e.$$.fragment)
        },
        l(a) {
            S(e.$$.fragment, a)
        },
        m(a, i) {
            w(e, a, i), n = !0
        },
        p(a, i) {
            var s;
            const r = {};
            i & 1 && (r.game = (s = a[0]) == null ? void 0 : s.name), i & 512 && (r.challengeList = a[9]), e.$set(r)
        },
        i(a) {
            n || (k(e.$$.fragment, a), n = !0)
        },
        o(a) {
            _(e.$$.fragment, a), n = !1
        },
        d(a) {
            y(e, a)
        }
    }
}

function la(l) {
    var E, h, C, K, O, L, W;
    let e, n, t, a, i, r, s, o, d, u, c, m, g;
    t = new xt({
        props: {
            id: `game-feature-image-${(E=l[0])==null?void 0:E.name}`,
            src: ((K = (C = (h = l[1]) == null ? void 0 : h.thumbnail) == null ? void 0 : C.asset) == null ? void 0 : K.url) || ((O = l[0]) == null ? void 0 : O.thumbnailUrl),
            width: 200,
            imgixParams: {
                q: 50
            },
            alt: ((L = l[1]) == null ? void 0 : L.thumbnailAlt) || ((W = l[0]) == null ? void 0 : W.name),
            draggable: !1
        }
    }), r = new Ne({
        props: {
            rounded: !0,
            variant: "default",
            $$slots: {
                default: [ua]
            },
            $$scope: {
                ctx: l
            }
        }
    });
    let f = ie(l[10]),
        $ = [];
    for (let G = 0; G < f.length; G += 1) $[G] = Ye(Oe(l, f, G));
    const N = G => _($[G], 1, 1, () => {
            $[G] = null
        }),
        A = [ga, ka],
        v = [];

    function M(G, V) {
        var X, re, le;
        return V & 1 && (u = null), (X = G[1]) != null && X.content ? 0 : (u == null && (u = !((le = (re = G[0]) == null ? void 0 : re.description) != null && le.includes("_"))), u ? 1 : -1)
    }
    return ~(c = M(l, -1)) && (m = v[c] = A[c](l)), {
        c() {
            e = D("div"), n = D("div"), F(t.$$.fragment), a = P(), i = D("div"), F(r.$$.fragment), s = P(), o = D("div");
            for (let G = 0; G < $.length; G += 1) $[G].c();
            d = P(), m && m.c(), this.h()
        },
        l(G) {
            e = B(G, "DIV", {
                class: !0
            });
            var V = I(e);
            n = B(V, "DIV", {
                class: !0
            });
            var X = I(n);
            S(t.$$.fragment, X), X.forEach(p), a = z(V), i = B(V, "DIV", {
                class: !0
            });
            var re = I(i);
            S(r.$$.fragment, re), re.forEach(p), s = z(V), o = B(V, "DIV", {
                class: !0
            });
            var le = I(o);
            for (let me = 0; me < $.length; me += 1) $[me].l(le);
            le.forEach(p), d = z(V), m && m.l(V), V.forEach(p), this.h()
        },
        h() {
            R(n, "class", "thumbnail-wrapper svelte-1wq7z2y"), x(n, "stacked", l[6]), R(i, "class", "edge-wrapper svelte-1wq7z2y"), R(o, "class", "game-meta-tags svelte-1wq7z2y"), x(o, "stacked", l[6]), R(e, "class", "desc-wrapper svelte-1wq7z2y"), x(e, "stacked", l[6])
        },
        m(G, V) {
            T(G, e, V), b(e, n), w(t, n, null), b(e, a), b(e, i), w(r, i, null), b(e, s), b(e, o);
            for (let X = 0; X < $.length; X += 1) $[X] && $[X].m(o, null);
            b(e, d), ~c && v[c].m(e, null), g = !0
        },
        p(G, V) {
            var me, we, ye, Ce, Te, Ge, Ee;
            const X = {};
            V & 1 && (X.id = `game-feature-image-${(me=G[0])==null?void 0:me.name}`), V & 3 && (X.src = ((Ce = (ye = (we = G[1]) == null ? void 0 : we.thumbnail) == null ? void 0 : ye.asset) == null ? void 0 : Ce.url) || ((Te = G[0]) == null ? void 0 : Te.thumbnailUrl)), V & 3 && (X.alt = ((Ge = G[1]) == null ? void 0 : Ge.thumbnailAlt) || ((Ee = G[0]) == null ? void 0 : Ee.name)), t.$set(X), (!g || V & 64) && x(n, "stacked", G[6]);
            const re = {};
            if (V & 33566720 && (re.$$scope = {
                    dirty: V,
                    ctx: G
                }), r.$set(re), V & 1024) {
                f = ie(G[10]);
                let ee;
                for (ee = 0; ee < f.length; ee += 1) {
                    const De = Oe(G, f, ee);
                    $[ee] ? ($[ee].p(De, V), k($[ee], 1)) : ($[ee] = Ye(De), $[ee].c(), k($[ee], 1), $[ee].m(o, null))
                }
                for (J(), ee = f.length; ee < $.length; ee += 1) N(ee);
                Q()
            }(!g || V & 64) && x(o, "stacked", G[6]);
            let le = c;
            c = M(G, V), c === le ? ~c && v[c].p(G, V) : (m && (J(), _(v[le], 1, 1, () => {
                v[le] = null
            }), Q()), ~c ? (m = v[c], m ? m.p(G, V) : (m = v[c] = A[c](G), m.c()), k(m, 1), m.m(e, null)) : m = null), (!g || V & 64) && x(e, "stacked", G[6])
        },
        i(G) {
            if (!g) {
                k(t.$$.fragment, G), k(r.$$.fragment, G);
                for (let V = 0; V < f.length; V += 1) k($[V]);
                k(m), g = !0
            }
        },
        o(G) {
            _(t.$$.fragment, G), _(r.$$.fragment, G), $ = $.filter(pt);
            for (let V = 0; V < $.length; V += 1) _($[V]);
            _(m), g = !1
        },
        d(G) {
            G && p(e), y(t), y(r), pe($, G), ~c && v[c].d()
        }
    }
}

function ra(l) {
    let e = l[13]._(Z.edge) + "",
        n, t;
    return {
        c() {
            n = H(e), t = H(": ")
        },
        l(a) {
            n = U(a, e), t = U(a, ": ")
        },
        m(a, i) {
            T(a, n, i), T(a, t, i)
        },
        p(a, i) {
            i & 8192 && e !== (e = a[13]._(Z.edge) + "") && j(n, e)
        },
        d(a) {
            a && (p(n), p(t))
        }
    }
}

function oa(l) {
    let e, n;
    return e = new ne({
        props: {
            size: "sm",
            variant: "highlighted",
            weight: "semibold",
            $$slots: {
                default: [da]
            },
            $$scope: {
                ctx: l
            }
        }
    }), {
        c() {
            F(e.$$.fragment)
        },
        l(t) {
            S(e.$$.fragment, t)
        },
        m(t, a) {
            w(e, t, a), n = !0
        },
        p(t, a) {
            const i = {};
            a & 33558528 && (i.$$scope = {
                dirty: a,
                ctx: t
            }), e.$set(i)
        },
        i(t) {
            n || (k(e.$$.fragment, t), n = !0)
        },
        o(t) {
            _(e.$$.fragment, t), n = !1
        },
        d(t) {
            y(e, t)
        }
    }
}

function sa(l) {
    let e, n;
    return e = new ne({
        props: {
            size: "sm",
            variant: "highlighted",
            $$slots: {
                default: [ma]
            },
            $$scope: {
                ctx: l
            }
        }
    }), {
        c() {
            F(e.$$.fragment)
        },
        l(t) {
            S(e.$$.fragment, t)
        },
        m(t, a) {
            w(e, t, a), n = !0
        },
        p(t, a) {
            const i = {};
            a & 33562624 && (i.$$scope = {
                dirty: a,
                ctx: t
            }), e.$set(i)
        },
        i(t) {
            n || (k(e.$$.fragment, t), n = !0)
        },
        o(t) {
            _(e.$$.fragment, t), n = !1
        },
        d(t) {
            y(e, t)
        }
    }
}

function da(l) {
    let e, n, t;
    return e = new Xt({
        props: {
            size: "sm",
            variant: "highlighted",
            weight: "semibold",
            maximumFractionDigits: 2,
            minimumFractionDigits: 2,
            value: l[12] * 100
        }
    }), {
        c() {
            F(e.$$.fragment), n = H("%")
        },
        l(a) {
            S(e.$$.fragment, a), n = U(a, "%")
        },
        m(a, i) {
            w(e, a, i), T(a, n, i), t = !0
        },
        p(a, i) {
            const r = {};
            i & 4096 && (r.value = a[12] * 100), e.$set(r)
        },
        i(a) {
            t || (k(e.$$.fragment, a), t = !0)
        },
        o(a) {
            _(e.$$.fragment, a), t = !1
        },
        d(a) {
            a && p(n), y(e, a)
        }
    }
}

function ma(l) {
    let e = l[13]._(Z.na) + "",
        n;
    return {
        c() {
            n = H(e)
        },
        l(t) {
            n = U(t, e)
        },
        m(t, a) {
            T(t, n, a)
        },
        p(t, a) {
            a & 8192 && e !== (e = t[13]._(Z.na) + "") && j(n, e)
        },
        d(t) {
            t && p(n)
        }
    }
}

function ua(l) {
    let e, n, t, a, i, r;
    e = new ne({
        props: {
            weight: "semibold",
            size: "sm",
            $$slots: {
                default: [ra]
            },
            $$scope: {
                ctx: l
            }
        }
    });
    const s = [sa, oa],
        o = [];

    function d(u, c) {
        return u[12] === 0 ? 0 : 1
    }
    return t = d(l), a = o[t] = s[t](l), {
        c() {
            F(e.$$.fragment), n = P(), a.c(), i = Y()
        },
        l(u) {
            S(e.$$.fragment, u), n = z(u), a.l(u), i = Y()
        },
        m(u, c) {
            w(e, u, c), T(u, n, c), o[t].m(u, c), T(u, i, c), r = !0
        },
        p(u, c) {
            const m = {};
            c & 33562624 && (m.$$scope = {
                dirty: c,
                ctx: u
            }), e.$set(m);
            let g = t;
            t = d(u), t === g ? o[t].p(u, c) : (J(), _(o[g], 1, 1, () => {
                o[g] = null
            }), Q(), a = o[t], a ? a.p(u, c) : (a = o[t] = s[t](u), a.c()), k(a, 1), a.m(i.parentNode, i))
        },
        i(u) {
            r || (k(e.$$.fragment, u), k(a), r = !0)
        },
        o(u) {
            _(e.$$.fragment, u), _(a), r = !1
        },
        d(u) {
            u && (p(n), p(i)), y(e, u), o[t].d(u)
        }
    }
}

function fa(l) {
    let e = l[19].translation + "",
        n;
    return {
        c() {
            n = H(e)
        },
        l(t) {
            n = U(t, e)
        },
        m(t, a) {
            T(t, n, a)
        },
        p(t, a) {
            a & 1024 && e !== (e = t[19].translation + "") && j(n, e)
        },
        d(t) {
            t && p(n)
        }
    }
}

function ca(l) {
    let e, n, t;
    return e = new he({
        props: {
            variant: "subtle-link",
            to: ce(ke.casinoGroup, {
                groupSlug: l[19].slug
            }),
            $$slots: {
                default: [fa]
            },
            $$scope: {
                ctx: l
            }
        }
    }), {
        c() {
            F(e.$$.fragment), n = P()
        },
        l(a) {
            S(e.$$.fragment, a), n = z(a)
        },
        m(a, i) {
            w(e, a, i), T(a, n, i), t = !0
        },
        p(a, i) {
            const r = {};
            i & 1024 && (r.to = ce(ke.casinoGroup, {
                groupSlug: a[19].slug
            })), i & 33555456 && (r.$$scope = {
                dirty: i,
                ctx: a
            }), e.$set(r)
        },
        i(a) {
            t || (k(e.$$.fragment, a), t = !0)
        },
        o(a) {
            _(e.$$.fragment, a), t = !1
        },
        d(a) {
            a && p(n), y(e, a)
        }
    }
}

function Ye(l) {
    let e, n;
    return e = new Ne({
        props: {
            rounded: !0,
            variant: "default",
            $$slots: {
                default: [ca]
            },
            $$scope: {
                ctx: l
            }
        }
    }), {
        c() {
            F(e.$$.fragment)
        },
        l(t) {
            S(e.$$.fragment, t)
        },
        m(t, a) {
            w(e, t, a), n = !0
        },
        p(t, a) {
            const i = {};
            a & 33555456 && (i.$$scope = {
                dirty: a,
                ctx: t
            }), e.$set(i)
        },
        i(t) {
            n || (k(e.$$.fragment, t), n = !0)
        },
        o(t) {
            _(e.$$.fragment, t), n = !1
        },
        d(t) {
            y(e, t)
        }
    }
}

function ka(l) {
    let e, n;
    return e = new ne({
        props: {
            tag: "p",
            $$slots: {
                default: [pa]
            },
            $$scope: {
                ctx: l
            }
        }
    }), {
        c() {
            F(e.$$.fragment)
        },
        l(t) {
            S(e.$$.fragment, t)
        },
        m(t, a) {
            w(e, t, a), n = !0
        },
        p(t, a) {
            const i = {};
            a & 33554433 && (i.$$scope = {
                dirty: a,
                ctx: t
            }), e.$set(i)
        },
        i(t) {
            n || (k(e.$$.fragment, t), n = !0)
        },
        o(t) {
            _(e.$$.fragment, t), n = !1
        },
        d(t) {
            y(e, t)
        }
    }
}

function ga(l) {
    let e, n;
    return e = new Zt({
        props: {
            blocks: l[1].content
        }
    }), {
        c() {
            F(e.$$.fragment)
        },
        l(t) {
            S(e.$$.fragment, t)
        },
        m(t, a) {
            w(e, t, a), n = !0
        },
        p(t, a) {
            const i = {};
            a & 2 && (i.blocks = t[1].content), e.$set(i)
        },
        i(t) {
            n || (k(e.$$.fragment, t), n = !0)
        },
        o(t) {
            _(e.$$.fragment, t), n = !1
        },
        d(t) {
            y(e, t)
        }
    }
}

function pa(l) {
    var t;
    let e = ((t = l[0]) == null ? void 0 : t.description) + "",
        n;
    return {
        c() {
            n = H(e)
        },
        l(a) {
            n = U(a, e)
        },
        m(a, i) {
            T(a, n, i)
        },
        p(a, i) {
            var r;
            i & 1 && e !== (e = ((r = a[0]) == null ? void 0 : r.description) + "") && j(n, e)
        },
        d(a) {
            a && p(n)
        }
    }
}

function _a(l) {
    var $, N, A;
    let e, n, t, a, i, r, s, o, d, u, c;
    a = new jt({
        props: {
            maxWidth: "100%",
            $$slots: {
                default: [Xn]
            },
            $$scope: {
                ctx: l
            }
        }
    });
    let m = ((N = ($ = l[11]) == null ? void 0 : $.group) == null ? void 0 : N.translation) && We(l),
        g = l[7] && ((A = l[0]) == null ? void 0 : A.showMultiplierLeaderboard) && je(l);
    d = new kt({
        props: {
            $$slots: {
                default: [ea]
            },
            $$scope: {
                ctx: l
            }
        }
    }), d.$on("click", l[16]);
    let f = !l[3] && Je(l);
    return {
        c() {
            e = D("div"), n = D("div"), t = D("div"), F(a.$$.fragment), i = P(), m && m.c(), r = P(), s = D("div"), g && g.c(), o = P(), F(d.$$.fragment), u = P(), f && f.c(), this.h()
        },
        l(v) {
            e = B(v, "DIV", {
                class: !0
            });
            var M = I(e);
            n = B(M, "DIV", {
                class: !0
            });
            var E = I(n);
            t = B(E, "DIV", {
                class: !0
            });
            var h = I(t);
            S(a.$$.fragment, h), i = z(h), m && m.l(h), h.forEach(p), r = z(E), s = B(E, "DIV", {
                class: !0
            });
            var C = I(s);
            g && g.l(C), o = z(C), S(d.$$.fragment, C), C.forEach(p), E.forEach(p), u = z(M), f && f.l(M), M.forEach(p), this.h()
        },
        h() {
            R(t, "class", "title-wrap svelte-1wq7z2y"), R(s, "class", "badge-wrap svelte-1wq7z2y"), R(n, "class", "inner-wrap svelte-1wq7z2y"), R(e, "class", "card-wrapper svelte-1wq7z2y")
        },
        m(v, M) {
            T(v, e, M), b(e, n), b(n, t), w(a, t, null), b(t, i), m && m.m(t, null), b(n, r), b(n, s), g && g.m(s, null), b(s, o), w(d, s, null), b(e, u), f && f.m(e, null), c = !0
        },
        p(v, M) {
            var C, K, O;
            const E = {};
            M & 33554464 && (E.$$scope = {
                dirty: M,
                ctx: v
            }), a.$set(E), (K = (C = v[11]) == null ? void 0 : C.group) != null && K.translation ? m ? (m.p(v, M), M & 2048 && k(m, 1)) : (m = We(v), m.c(), k(m, 1), m.m(t, null)) : m && (J(), _(m, 1, 1, () => {
                m = null
            }), Q()), v[7] && ((O = v[0]) != null && O.showMultiplierLeaderboard) ? g ? (g.p(v, M), M & 129 && k(g, 1)) : (g = je(v), g.c(), k(g, 1), g.m(s, o)) : g && (J(), _(g, 1, 1, () => {
                g = null
            }), Q());
            const h = {};
            M & 33554440 && (h.$$scope = {
                dirty: M,
                ctx: v
            }), d.$set(h), v[3] ? f && (J(), _(f, 1, 1, () => {
                f = null
            }), Q()) : f ? (f.p(v, M), M & 8 && k(f, 1)) : (f = Je(v), f.c(), k(f, 1), f.m(e, null))
        },
        i(v) {
            c || (k(a.$$.fragment, v), k(m), k(g), k(d.$$.fragment, v), k(f), c = !0)
        },
        o(v) {
            _(a.$$.fragment, v), _(m), _(g), _(d.$$.fragment, v), _(f), c = !1
        },
        d(v) {
            v && p(e), y(a), m && m.d(), g && g.d(), y(d), f && f.d()
        }
    }
}

function $a(l) {
    let e, n, t;
    return n = new Yt({
        props: {
            style: "width: 100%",
            $$slots: {
                default: [_a]
            },
            $$scope: {
                ctx: l
            }
        }
    }), {
        c() {
            e = D("div"), F(n.$$.fragment), this.h()
        },
        l(a) {
            e = B(a, "DIV", {
                class: !0,
                "data-content": !0
            });
            var i = I(e);
            S(n.$$.fragment, i), i.forEach(p), this.h()
        },
        h() {
            R(e, "class", "game-meta svelte-1wq7z2y"), R(e, "data-content", an)
        },
        m(a, i) {
            T(a, e, i), w(n, e, null), t = !0
        },
        p(a, [i]) {
            const r = {};
            i & 33570815 && (r.$$scope = {
                dirty: i,
                ctx: a
            }), n.$set(r)
        },
        i(a) {
            t || (k(n.$$.fragment, a), t = !0)
        },
        o(a) {
            _(n.$$.fragment, a), t = !1
        },
        d(a) {
            a && p(e), y(n)
        }
    }
}

function va(l, e, n) {
    let t, a, i, r, s, o, d, u, c, m, g;
    te(l, ue, C => n(13, g = C));
    let {
        kuratorGame: f
    } = e, {
        seo: $ = void 0
    } = e;
    const N = Vt();
    te(l, N, C => n(2, c = C));
    const {
        meta: A
    } = Wt();
    te(l, A, C => n(18, m = C));
    let v = !(Ot || !m.isAuthenticated),
        M = m.isAuthenticated && (f == null ? void 0 : f.showProfitLeaderboard) && "profit" || "description";
    const E = () => n(3, v = !v),
        h = C => n(4, M = C);
    return l.$$set = C => {
        "kuratorGame" in C && n(0, f = C.kuratorGame), "seo" in C && n(1, $ = C.seo)
    }, l.$$.update = () => {
        var C;
        l.$$.dirty & 1 && n(12, t = (f == null ? void 0 : f.edge) || 0), l.$$.dirty & 1 && n(11, a = (C = f == null ? void 0 : f.groupGames) == null ? void 0 : C.find(K => {
            var O;
            return ((O = K == null ? void 0 : K.group) == null ? void 0 : O.type) === St.provider
        })), l.$$.dirty & 1 && n(10, i = wt.uniqWith((f == null ? void 0 : f.groupGames) || [], (K, O) => K.group.translation === O.group.translation)), l.$$.dirty & 1 && n(9, r = (f == null ? void 0 : f.challengeList) || []), l.$$.dirty & 1 && n(8, s = [(f == null ? void 0 : f.showProfitLeaderboard) && "profit", (f == null ? void 0 : f.showMultiplierLeaderboard) && "multiplier", "challenges", "description"].filter(Boolean)), l.$$.dirty & 4 && n(7, o = c && c > 600), l.$$.dirty & 4 && n(6, d = c < 450), l.$$.dirty & 3 && n(5, u = f ? $e((f == null ? void 0 : f.name) ? ? "") : $ == null ? void 0 : $.title)
    }, [f, $, c, v, M, u, d, o, s, r, i, a, t, g, N, A, E, h]
}
class ha extends se {
    constructor(e) {
        super(), de(this, e, va, $a, oe, {
            kuratorGame: 0,
            seo: 1
        })
    }
}
const Xe = {
    recommendedGames: q._("Recommended")
};

function Na(l) {
    var a, i;
    let e, n, t;
    return n = new rn({
        props: {
            group: {
                slug: (a = l[3]) == null ? void 0 : a.slug,
                translation: l[6]._(Xe.recommendedGames),
                icon: "popular-games",
                gameCount: (i = l[3]) == null ? void 0 : i.gameCount
            },
            width: l[0],
            cards: l[2] ? l[7] : l[5],
            loading: l[2],
            mobileView: l[1],
            limit: l[4]
        }
    }), {
        c() {
            e = D("div"), F(n.$$.fragment), this.h()
        },
        l(r) {
            e = B(r, "DIV", {
                class: !0
            });
            var s = I(e);
            S(n.$$.fragment, s), s.forEach(p), this.h()
        },
        h() {
            R(e, "class", "wrap svelte-f2bi6q")
        },
        m(r, s) {
            T(r, e, s), w(n, e, null), t = !0
        },
        p(r, [s]) {
            var d, u;
            const o = {};
            s & 72 && (o.group = {
                slug: (d = r[3]) == null ? void 0 : d.slug,
                translation: r[6]._(Xe.recommendedGames),
                icon: "popular-games",
                gameCount: (u = r[3]) == null ? void 0 : u.gameCount
            }), s & 1 && (o.width = r[0]), s & 36 && (o.cards = r[2] ? r[7] : r[5]), s & 4 && (o.loading = r[2]), s & 2 && (o.mobileView = r[1]), s & 16 && (o.limit = r[4]), n.$set(o)
        },
        i(r) {
            t || (k(n.$$.fragment, r), t = !0)
        },
        o(r) {
            _(n.$$.fragment, r), t = !1
        },
        d(r) {
            r && p(e), y(n)
        }
    }
}

function ba(l, e, n) {
    let t, a;
    te(l, ue, c => n(6, a = c));
    let {
        width: i
    } = e, {
        mobileView: r
    } = e, {
        loading: s
    } = e, {
        slugKuratorGroup: o
    } = e, {
        limit: d
    } = e;
    const u = [{
        id: 1
    }, {
        id: 2
    }, {
        id: 3
    }, {
        id: 4
    }, {
        id: 5
    }, {
        id: 6
    }, {
        id: 7
    }];
    return l.$$set = c => {
        "width" in c && n(0, i = c.width), "mobileView" in c && n(1, r = c.mobileView), "loading" in c && n(2, s = c.loading), "slugKuratorGroup" in c && n(3, o = c.slugKuratorGroup), "limit" in c && n(4, d = c.limit)
    }, l.$$.update = () => {
        var c;
        l.$$.dirty & 8 && n(5, t = ((c = o == null ? void 0 : o.groupGamesList) == null ? void 0 : c.map(m => on(m))) || [])
    }, [i, r, s, o, d, t, a, u]
}
class Fa extends se {
    constructor(e) {
        super(), de(this, e, ba, Na, oe, {
            width: 0,
            mobileView: 1,
            loading: 2,
            slugKuratorGroup: 3,
            limit: 4
        })
    }
}
const ge = {
        notFound: q._("Game not found"),
        notActive: q._("Game is disabled")
    },
    Sa = l => ({
        slugKuratorGame: l & 1
    }),
    Ze = l => ({
        slugKuratorGame: l[0]
    });

function xe(l) {
    let e = l[0].name,
        n, t, a = et(l);
    return {
        c() {
            a.c(), n = Y()
        },
        l(i) {
            a.l(i), n = Y()
        },
        m(i, r) {
            a.m(i, r), T(i, n, r), t = !0
        },
        p(i, r) {
            r & 1 && oe(e, e = i[0].name) ? (J(), _(a, 1, 1, It), Q(), a = et(i), a.c(), k(a, 1), a.m(n.parentNode, n)) : a.p(i, r)
        },
        i(i) {
            t || (k(a), t = !0)
        },
        o(i) {
            _(a), t = !1
        },
        d(i) {
            i && p(n), a.d(i)
        }
    }
}

function et(l) {
    let e, n;
    return e = new mn({
        props: {
            seo: l[5]
        }
    }), {
        c() {
            F(e.$$.fragment)
        },
        l(t) {
            S(e.$$.fragment, t)
        },
        m(t, a) {
            w(e, t, a), n = !0
        },
        p(t, a) {
            const i = {};
            a & 32 && (i.seo = t[5]), e.$set(i)
        },
        i(t) {
            n || (k(e.$$.fragment, t), n = !0)
        },
        o(t) {
            _(e.$$.fragment, t), n = !1
        },
        d(t) {
            y(e, t)
        }
    }
}

function wa(l) {
    let e, n, t;
    return n = new ne({
        props: {
            weight: "semibold",
            size: "lg",
            $$slots: {
                default: [Ta]
            },
            $$scope: {
                ctx: l
            }
        }
    }), {
        c() {
            e = D("div"), F(n.$$.fragment), this.h()
        },
        l(a) {
            e = B(a, "DIV", {
                class: !0,
                "data-test": !0
            });
            var i = I(e);
            S(n.$$.fragment, i), i.forEach(p), this.h()
        },
        h() {
            R(e, "class", "not-found-wrapper svelte-8eostq"), R(e, "data-test", "game-not-found")
        },
        m(a, i) {
            T(a, e, i), w(n, e, null), t = !0
        },
        p(a, i) {
            const r = {};
            i & 1052672 && (r.$$scope = {
                dirty: i,
                ctx: a
            }), n.$set(r)
        },
        i(a) {
            t || (k(n.$$.fragment, a), t = !0)
        },
        o(a) {
            _(n.$$.fragment, a), t = !1
        },
        d(a) {
            a && p(e), y(n)
        }
    }
}

function ya(l) {
    let e, n, t;
    return n = new ne({
        props: {
            weight: "semibold",
            size: "lg",
            $$slots: {
                default: [Ga]
            },
            $$scope: {
                ctx: l
            }
        }
    }), {
        c() {
            e = D("div"), F(n.$$.fragment), this.h()
        },
        l(a) {
            e = B(a, "DIV", {
                class: !0,
                "data-test": !0
            });
            var i = I(e);
            S(n.$$.fragment, i), i.forEach(p), this.h()
        },
        h() {
            R(e, "class", "not-found-wrapper svelte-8eostq"), R(e, "data-test", "game-not-active")
        },
        m(a, i) {
            T(a, e, i), w(n, e, null), t = !0
        },
        p(a, i) {
            const r = {};
            i & 1052672 && (r.$$scope = {
                dirty: i,
                ctx: a
            }), n.$set(r)
        },
        i(a) {
            t || (k(n.$$.fragment, a), t = !0)
        },
        o(a) {
            _(n.$$.fragment, a), t = !1
        },
        d(a) {
            a && p(e), y(n)
        }
    }
}

function Ca(l) {
    let e;
    const n = l[18].default,
        t = at(n, l, l[20], Ze);
    return {
        c() {
            t && t.c()
        },
        l(a) {
            t && t.l(a)
        },
        m(a, i) {
            t && t.m(a, i), e = !0
        },
        p(a, i) {
            t && t.p && (!e || i & 1048577) && lt(t, n, a, a[20], e ? ot(n, a[20], i, Sa) : rt(a[20]), Ze)
        },
        i(a) {
            e || (k(t, a), e = !0)
        },
        o(a) {
            _(t, a), e = !1
        },
        d(a) {
            t && t.d(a)
        }
    }
}

function Ta(l) {
    let e, n, t, a = l[12]._(ge.notFound) + "",
        i, r;
    return e = new gt({}), {
        c() {
            F(e.$$.fragment), n = P(), t = D("span"), i = H(a)
        },
        l(s) {
            S(e.$$.fragment, s), n = z(s), t = B(s, "SPAN", {});
            var o = I(t);
            i = U(o, a), o.forEach(p)
        },
        m(s, o) {
            w(e, s, o), T(s, n, o), T(s, t, o), b(t, i), r = !0
        },
        p(s, o) {
            (!r || o & 4096) && a !== (a = s[12]._(ge.notFound) + "") && j(i, a)
        },
        i(s) {
            r || (k(e.$$.fragment, s), r = !0)
        },
        o(s) {
            _(e.$$.fragment, s), r = !1
        },
        d(s) {
            s && (p(n), p(t)), y(e, s)
        }
    }
}

function Ga(l) {
    let e, n, t, a = l[12]._(ge.notActive) + "",
        i, r;
    return e = new gt({}), {
        c() {
            F(e.$$.fragment), n = P(), t = D("span"), i = H(a)
        },
        l(s) {
            S(e.$$.fragment, s), n = z(s), t = B(s, "SPAN", {});
            var o = I(t);
            i = U(o, a), o.forEach(p)
        },
        m(s, o) {
            w(e, s, o), T(s, n, o), T(s, t, o), b(t, i), r = !0
        },
        p(s, o) {
            (!r || o & 4096) && a !== (a = s[12]._(ge.notActive) + "") && j(i, a)
        },
        i(s) {
            r || (k(e.$$.fragment, s), r = !0)
        },
        o(s) {
            _(e.$$.fragment, s), r = !1
        },
        d(s) {
            s && (p(n), p(t)), y(e, s)
        }
    }
}

function Ea(l) {
    let e, n, t, a;
    const i = [Ca, ya, wa],
        r = [];

    function s(o, d) {
        var u, c;
        return o[11] && ((u = o[11]) != null && u.active) ? 0 : ((c = o[11]) == null ? void 0 : c.active) === !1 ? 1 : 2
    }
    return e = s(l), n = r[e] = i[e](l), {
        c() {
            n.c(), t = Y()
        },
        l(o) {
            n.l(o), t = Y()
        },
        m(o, d) {
            r[e].m(o, d), T(o, t, d), a = !0
        },
        p(o, d) {
            let u = e;
            e = s(o), e === u ? r[e].p(o, d) : (J(), _(r[u], 1, 1, () => {
                r[u] = null
            }), Q(), n = r[e], n ? n.p(o, d) : (n = r[e] = i[e](o), n.c()), k(n, 1), n.m(t.parentNode, t))
        },
        i(o) {
            a || (k(n), a = !0)
        },
        o(o) {
            _(n), a = !1
        },
        d(o) {
            o && p(t), r[e].d(o)
        }
    }
}

function Da(l) {
    let e, n, t;
    return n = new zt({
        props: {
            loading: l[7],
            $$slots: {
                default: [Ea]
            },
            $$scope: {
                ctx: l
            }
        }
    }), {
        c() {
            e = D("div"), F(n.$$.fragment), this.h()
        },
        l(a) {
            e = B(a, "DIV", {
                class: !0
            });
            var i = I(e);
            S(n.$$.fragment, i), i.forEach(p), this.h()
        },
        h() {
            R(e, "class", "game-wrapper svelte-8eostq"), x(e, "responsive", l[8]), x(e, "enabled", l[10])
        },
        m(a, i) {
            T(a, e, i), w(n, e, null), t = !0
        },
        p(a, i) {
            const r = {};
            i & 128 && (r.loading = a[7]), i & 1054721 && (r.$$scope = {
                dirty: i,
                ctx: a
            }), n.$set(r), (!t || i & 256) && x(e, "responsive", a[8]), (!t || i & 1024) && x(e, "enabled", a[10])
        },
        i(a) {
            t || (k(n.$$.fragment, a), t = !0)
        },
        o(a) {
            _(n.$$.fragment, a), t = !1
        },
        d(a) {
            a && p(e), y(n)
        }
    }
}

function tt(l) {
    let e, n;
    return e = new sn({
        props: {
            $$slots: {
                default: [Ba]
            },
            $$scope: {
                ctx: l
            }
        }
    }), {
        c() {
            F(e.$$.fragment)
        },
        l(t) {
            S(e.$$.fragment, t)
        },
        m(t, a) {
            w(e, t, a), n = !0
        },
        p(t, a) {
            const i = {};
            a & 1049151 && (i.$$scope = {
                dirty: a,
                ctx: t
            }), e.$set(i)
        },
        i(t) {
            n || (k(e.$$.fragment, t), n = !0)
        },
        o(t) {
            _(e.$$.fragment, t), n = !1
        },
        d(t) {
            y(e, t)
        }
    }
}

function nt(l) {
    let e, n, t, a;
    return e = new Fa({
        props: {
            width: l[1],
            mobileView: l[2],
            loading: !1,
            slugKuratorGroup: l[4],
            limit: Fe
        }
    }), t = new $t({
        props: {
            kuratorCollection: l[3],
            slidey: !0,
            width: l[1],
            mobileView: l[2]
        }
    }), {
        c() {
            F(e.$$.fragment), n = P(), F(t.$$.fragment)
        },
        l(i) {
            S(e.$$.fragment, i), n = z(i), S(t.$$.fragment, i)
        },
        m(i, r) {
            w(e, i, r), T(i, n, r), w(t, i, r), a = !0
        },
        p(i, r) {
            const s = {};
            r & 2 && (s.width = i[1]), r & 4 && (s.mobileView = i[2]), r & 16 && (s.slugKuratorGroup = i[4]), e.$set(s);
            const o = {};
            r & 8 && (o.kuratorCollection = i[3]), r & 2 && (o.width = i[1]), r & 4 && (o.mobileView = i[2]), t.$set(o)
        },
        i(i) {
            a || (k(e.$$.fragment, i), k(t.$$.fragment, i), a = !0)
        },
        o(i) {
            _(e.$$.fragment, i), _(t.$$.fragment, i), a = !1
        },
        d(i) {
            i && p(n), y(e, i), y(t, i)
        }
    }
}

function Ba(l) {
    let e, n, t, a;
    n = new ha({
        props: {
            kuratorGame: l[0],
            seo: l[5]
        }
    });
    let i = l[9] === !1 && nt(l);
    return {
        c() {
            e = D("div"), F(n.$$.fragment), t = P(), i && i.c(), this.h()
        },
        l(r) {
            e = B(r, "DIV", {
                class: !0
            });
            var s = I(e);
            S(n.$$.fragment, s), t = z(s), i && i.l(s), s.forEach(p), this.h()
        },
        h() {
            R(e, "class", "top-spacing svelte-8eostq")
        },
        m(r, s) {
            T(r, e, s), w(n, e, null), b(e, t), i && i.m(e, null), a = !0
        },
        p(r, s) {
            const o = {};
            s & 1 && (o.kuratorGame = r[0]), s & 32 && (o.seo = r[5]), n.$set(o), r[9] === !1 ? i ? (i.p(r, s), s & 512 && k(i, 1)) : (i = nt(r), i.c(), k(i, 1), i.m(e, null)) : i && (J(), _(i, 1, 1, () => {
                i = null
            }), Q())
        },
        i(r) {
            a || (k(n.$$.fragment, r), k(i), a = !0)
        },
        o(r) {
            _(n.$$.fragment, r), _(i), a = !1
        },
        d(r) {
            r && p(e), y(n), i && i.d()
        }
    }
}

function Ia(l) {
    var c;
    let e, n, t, a, i, r, s, o, d = ((c = l[0]) == null ? void 0 : c.active) && xe(l);
    t = new vn({
        props: {
            $$slots: {
                default: [Da]
            },
            $$scope: {
                ctx: l
            }
        }
    });
    let u = !l[6] && tt(l);
    return {
        c() {
            d && d.c(), e = P(), n = D("div"), F(t.$$.fragment), a = P(), u && u.c(), this.h()
        },
        l(m) {
            d && d.l(m), e = z(m), n = B(m, "DIV", {
                class: !0
            });
            var g = I(n);
            S(t.$$.fragment, g), a = z(g), u && u.l(g), g.forEach(p), this.h()
        },
        h() {
            R(n, "class", "game-layout svelte-8eostq"), x(n, "hide-meta", l[6])
        },
        m(m, g) {
            d && d.m(m, g), T(m, e, g), T(m, n, g), w(t, n, null), b(n, a), u && u.m(n, null), r = !0, s || (o = it(i = mt.call(null, n, l[19])), s = !0)
        },
        p(m, [g]) {
            var $;
            ($ = m[0]) != null && $.active ? d ? (d.p(m, g), g & 1 && k(d, 1)) : (d = xe(m), d.c(), k(d, 1), d.m(e.parentNode, e)) : d && (J(), _(d, 1, 1, () => {
                d = null
            }), Q());
            const f = {};
            g & 1056129 && (f.$$scope = {
                dirty: g,
                ctx: m
            }), t.$set(f), m[6] ? u && (J(), _(u, 1, 1, () => {
                u = null
            }), Q()) : u ? (u.p(m, g), g & 64 && k(u, 1)) : (u = tt(m), u.c(), k(u, 1), u.m(n, null)), i && st(i.update) && g & 2 && i.update.call(null, m[19]), (!r || g & 64) && x(n, "hide-meta", m[6])
        },
        i(m) {
            r || (k(d), k(t.$$.fragment, m), k(u), r = !0)
        },
        o(m) {
            _(d), _(t.$$.fragment, m), _(u), r = !1
        },
        d(m) {
            m && (p(e), p(n)), d && d.d(m), y(t), u && u.d(), s = !1, o()
        }
    }
}

function Ma(l, e, n) {
    let t, a, i, r, s, o, d, u, c, m, g;
    te(l, un, L => n(2, s = L)), te(l, Ct, L => n(15, o = L)), te(l, Tt, L => n(16, d = L)), te(l, Gt, L => n(17, u = L)), te(l, dt, L => n(10, c = L)), te(l, ue, L => n(12, g = L));
    let {
        $$slots: f = {},
        $$scope: $
    } = e, {
        data: N
    } = e;
    const A = fn();
    te(l, A, L => n(11, m = L));
    let {
        kuratorCollection: v,
        recommendedSlotsGroup: M,
        slugKuratorGame: E,
        seo: h
    } = N;
    N.slugKuratorGame && A.set(N.slugKuratorGame);
    const C = L => L ? Et(L, o.params.lang).split("/")[3] : !1;
    let K = 1e3;
    yt(A, ({
        previous: L,
        current: W
    }) => {
        (L == null ? void 0 : L.name) !== (W == null ? void 0 : W.name) && cn()
    });
    const O = L => n(1, K = L.width);
    return l.$$set = L => {
        "data" in L && n(14, N = L.data), "$$scope" in L && n(20, $ = L.$$scope)
    }, l.$$.update = () => {
        var L, W, G, V, X;
        l.$$.dirty & 16384 && n(3, {
            kuratorCollection: v,
            recommendedSlotsGroup: M,
            slugKuratorGame: E,
            seo: h
        } = N, v, (n(4, M), n(14, N)), (n(0, E), n(14, N)), (n(5, h), n(14, N))), l.$$.dirty & 32768 && n(9, t = !o.params.game), l.$$.dirty & 2 && n(8, a = K <= 930), l.$$.dirty & 1 && A.set(E), l.$$.dirty & 1 && E && dn.set({
            loading: !1,
            isFavourite: E.isFavourite || null,
            gameId: E.id || null
        }), l.$$.dirty & 196608 && n(7, i = !!(d && ((L = d == null ? void 0 : d.to) != null && L.url.pathname.startsWith(u("/casino/games/"))) && C((G = (W = d == null ? void 0 : d.to) == null ? void 0 : W.url) == null ? void 0 : G.pathname) !== C((X = (V = d == null ? void 0 : d.from) == null ? void 0 : V.url) == null ? void 0 : X.pathname))), l.$$.dirty & 32772 && n(6, r = o.url.pathname.endsWith("/play") && s)
    }, [E, K, s, v, M, h, r, i, a, t, c, m, g, A, N, o, d, u, f, O, $]
}
class zi extends se {
    constructor(e) {
        super(), de(this, e, Ma, Ia, oe, {
            data: 14
        })
    }
}
export {
    zi as component, Pi as universal
};