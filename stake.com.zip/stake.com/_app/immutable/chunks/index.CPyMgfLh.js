import {
    b8 as p,
    b9 as f,
    A as y,
    h as d
} from "./index.B4-7gKq3.js";
import {
    r as m
} from "./index.B81orGJm.js";
import {
    G as h
} from "./scheduler.DXu26z7T.js";
import "./index.ByMdEFI5.js";
import {
    E as k
} from "./Error.DAkWdr3O.js";
const u = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "query",
            name: {
                kind: "Name",
                value: "UserHasDeposits"
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "depositList"
                            },
                            arguments: [{
                                kind: "Argument",
                                name: {
                                    kind: "Name",
                                    value: "limit"
                                },
                                value: {
                                    kind: "IntValue",
                                    value: "2"
                                }
                            }],
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }]
    },
    S = () => {
        m && !(window != null && window.dataLayer) && function(s, e, n, i, a) {
            s[i] = s[i] || [], s[i].push({
                "gtm.start": new Date().getTime(),
                event: "gtm.js"
            });
            const o = e.getElementsByTagName(n)[0],
                t = e.createElement(n),
                l = "";
            t.async = !0, t.src = "https://www.googletagmanager.com/gtm.js?id=" + a + l, o.parentNode.insertBefore(t, o)
        }(window, document, "script", "dataLayer", m)
    },
    b = () => {
        const {
            subscribeToGlobalEventEmitter: s
        } = p();
        return s({
            initialize: () => {
                S(), c({
                    event: "initialize"
                })
            },
            firstUserResponse: ({
                user: e,
                code: n
            }) => {
                var i, a;
                c({
                    userId: e.id,
                    code: n,
                    isAuthenticated: !0,
                    flags: (i = e == null ? void 0 : e.flags) == null ? void 0 : i.map(({
                        flag: o
                    }) => o),
                    hash: e == null ? void 0 : e.intercomHash,
                    email: e == null ? void 0 : e.email,
                    username: e == null ? void 0 : e.name,
                    fitToPlay: (a = e == null ? void 0 : e.currentPlaySession) == null ? void 0 : a.fitToPlay
                })
            },
            authenticate: e => {
                var n, i, a, o; {
                    const {
                        user: t
                    } = e.userAuthenticatedSession.session;
                    c({
                        event: e.subtype,
                        userId: t.id,
                        signupCode: (i = (n = t == null ? void 0 : t.signupCode) == null ? void 0 : n.code) == null ? void 0 : i.code,
                        code: e == null ? void 0 : e.code,
                        isAuthenticated: !0,
                        flags: (a = t == null ? void 0 : t.flags) == null ? void 0 : a.map(({
                            flag: l
                        }) => l),
                        hash: t == null ? void 0 : t.intercomHash,
                        email: t == null ? void 0 : t.email,
                        username: t == null ? void 0 : t.name,
                        fitToPlay: (o = t == null ? void 0 : t.currentPlaySession) == null ? void 0 : o.fitToPlay
                    })
                }
            },
            deposit: async ({
                id: e,
                amount: n,
                currency: i
            }) => {
                var a, o; {
                    const t = y(),
                        {
                            data: l
                        } = await t.query(u).toPromise(),
                        r = h(f),
                        g = ((o = (a = l == null ? void 0 : l.user) == null ? void 0 : a.depositList) == null ? void 0 : o.length) === 1;
                    c({
                        event: "deposit",
                        id: e,
                        amount: n,
                        currency: i,
                        value: r * n,
                        ftd: g
                    })
                }
            },
            logout: () => {
                c({
                    event: "logout"
                })
            }
        })
    };

function c(s) {
    var e;
    (e = window == null ? void 0 : window.dataLayer) == null || e.push(s)
}
const N = () => ({
    body: d._("An error occurred while claiming the bonus. Please try again."),
    title: d._("Error"),
    icon: k,
    type: "negative"
});
export {
    N as c, c as p, b as u
};