import {
    l as E,
    f as M,
    aI as s,
    ap as F,
    z as R
} from "./index.B4-7gKq3.js";
import {
    w as D
} from "./index.C2-CG2CN.js";
import {
    w as V
} from "./scheduler.DXu26z7T.js";
const r = D(!1),
    d = E("geocomplyVerified", !1),
    J = D(0);
var u, p, y;
const K = (y = (p = (u = window == null ? void 0 : window.navigator) == null ? void 0 : u.userAgent) == null ? void 0 : p.toLowerCase()) == null ? void 0 : y.includes("android");
var w, g, k, v, f, G, L, S, b;
const X = ((k = (g = (w = window == null ? void 0 : window.navigator) == null ? void 0 : w.userAgent) == null ? void 0 : g.toLowerCase()) == null ? void 0 : k.includes("mobile")) && (((G = (f = (v = window == null ? void 0 : window.navigator) == null ? void 0 : v.userAgent) == null ? void 0 : f.toLowerCase()) == null ? void 0 : G.includes("iphone")) || ((b = (S = (L = window == null ? void 0 : window.navigator) == null ? void 0 : L.userAgent) == null ? void 0 : S.toLowerCase()) == null ? void 0 : b.includes("ipad")));
var I, h, C;
const Y = (C = (h = (I = window == null ? void 0 : window.navigator) == null ? void 0 : I.userAgent) == null ? void 0 : h.toLowerCase()) == null ? void 0 : C.includes("mac");
var x, N, A;
const Z = (A = (N = (x = window == null ? void 0 : window.navigator) == null ? void 0 : x.userAgent) == null ? void 0 : N.toLowerCase()) == null ? void 0 : A.includes("windows"),
    q = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "query",
            name: {
                kind: "Name",
                value: "GetGeoComplyLicense"
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "getGeoComplyLicense"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }]
                    }
                }]
            }
        }]
    },
    T = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "query",
            name: {
                kind: "Name",
                value: "CheckGeoLocation"
            },
            variableDefinitions: [{
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "geoPacket"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "String"
                        }
                    }
                }
            }],
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "checkGeoLocation"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "geoPacket"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "geoPacket"
                            }
                        }
                    }],
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "geolocateIn"
                            }
                        }]
                    }
                }]
            }
        }]
    };
let l, m = !0,
    a;
const j = async t => {
        var o;
        try {
            const e = await M({
                load: {
                    fetch
                },
                doc: T,
                variables: {
                    geoPacket: t
                }
            });
            clearInterval(l), (o = e == null ? void 0 : e.checkGeoLocation) != null && o.geolocateIn ? (l = setInterval(() => {
                P()
            }, e.checkGeoLocation.geolocateIn * 1e3), F.next({
                type: "geocomply",
                subtype: "success"
            }), d.set(!0)) : (d.set(!1), c("txtReason", "Location failure"), s.next({
                type: "geocomply",
                error: {
                    code: ""
                }
            }), r.set(!1))
        } catch {}
    },
    B = () => new Promise((t, o) => {
        const e = document.createElement("script");
        document.head.append(e), e.onload = t, e.onerror = o, e.async = !0, e.src = "https://stg-cdn.geocomply.com/190/gc-html5.js", e.type = "text/javascript"
    }),
    H = t => {
        var o;
        return (o = document.getElementById(t)) == null ? void 0 : o.checked
    },
    O = t => {
        var o;
        (o = window == null ? void 0 : window.GcHtml5) == null || o.startMyIpService({
            license: t,
            resumable: H("cbxResumable")
        })
    },
    U = () => {
        var t;
        (t = window == null ? void 0 : window.GcHtml5) == null || t.stopMyIpService()
    },
    c = (t, o) => {
        const e = document.getElementById(t);
        e && e instanceof HTMLInputElement && e && (e.value = o ? ? "")
    },
    P = async () => {
        var t, o;
        try {
            const e = await M({
                load: {
                    fetch
                },
                doc: q,
                variables: {}
            });
            e != null && e.getGeoComplyLicense && (a = await ((t = window == null ? void 0 : window.GcHtml5) == null ? void 0 : t.createClient()), a.events.on("abort", () => {
                a.abort()
            }).on("engine.success", i => {
                var n;
                m || (j(i), O(e.getGeoComplyLicense), c("txtLicense", e.getGeoComplyLicense), c("txtUserSessionId", (n = e == null ? void 0 : e.user) == null ? void 0 : n.id), c("txtReason", "user login"))
            }).on("*.failed", i => {
                r.set(!1), c("txtReason", "failed at browser"), s.next({
                    type: "geocomply",
                    error: {
                        code: i
                    }
                })
            }).on("browser.success", () => {
                m = !1
            }), a.setLicense(e.getGeoComplyLicense), a.setUserId(((o = e == null ? void 0 : e.user) == null ? void 0 : o.id) ? ? ""), a.request(), window.GcHtml5.onMyIpSuccess = async () => {
                var n;
                H("cbxAckMyIPSuccess") && ((n = window == null ? void 0 : window.GcHtml5) == null || n.ackMyIPSuccess())
            }, window.GcHtml5.onMyIpFailure = (i, n) => {
                r.set(!1), c("txtReason", "Ip failure"), s.next({
                    type: "geocomply",
                    error: {
                        code: i,
                        message: n
                    }
                }), U()
            }, V(() => {
                clearInterval(l)
            }))
        } catch {}
    },
    _ = async () => {
        try {
            R && !("GcHtml5" in window) && await B(), "GcHtml5" in window && await P()
        } catch {
            s.next({
                type: "geocomply",
                error: {
                    code: "600"
                }
            })
        }
    };
export {
    r as a, P as b, X as c, Y as d, Z as e, _ as f, J as g, d as h, K as i
};