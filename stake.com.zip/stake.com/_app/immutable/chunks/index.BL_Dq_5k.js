import {
    s as g,
    a as k,
    K as r,
    e as b,
    d as P,
    f as L,
    i as c,
    Q as _,
    V as u,
    j as W,
    u as q,
    g as v,
    b as E,
    L as h,
    M as S
} from "./scheduler.DXu26z7T.js";
import {
    S as z,
    i as A,
    t as C,
    b as j
} from "./index.Dz_MmNB3.js";
import {
    g as B
} from "./spread.CgU5AtxT.js";

function K(n) {
    let t, a;
    const f = n[3].default,
        l = k(f, n, n[2], null);
    let o = [n[1]],
        i = {};
    for (let e = 0; e < o.length; e += 1) i = r(i, o[e]);
    return {
        c() {
            t = b("label"), l && l.c(), this.h()
        },
        l(e) {
            t = P(e, "LABEL", {});
            var s = L(t);
            l && l.l(s), s.forEach(c), this.h()
        },
        h() {
            _(t, i), u(t, "stacked", n[0]), u(t, "svelte-1wzq4lo", !0)
        },
        m(e, s) {
            W(e, t, s), l && l.m(t, null), a = !0
        },
        p(e, [s]) {
            l && l.p && (!a || s & 4) && q(l, f, e, e[2], a ? E(f, e[2], s, null) : v(e[2]), null), _(t, i = B(o, [s & 2 && e[1]])), u(t, "stacked", e[0]), u(t, "svelte-1wzq4lo", !0)
        },
        i(e) {
            a || (C(l, e), a = !0)
        },
        o(e) {
            j(l, e), a = !1
        },
        d(e) {
            e && c(t), l && l.d(e)
        }
    }
}

function M(n, t, a) {
    const f = ["stacked"];
    let l = h(t, f),
        {
            $$slots: o = {},
            $$scope: i
        } = t,
        {
            stacked: e = !0
        } = t;
    return n.$$set = s => {
        t = r(r({}, t), S(s)), a(1, l = h(t, f)), "stacked" in s && a(0, e = s.stacked), "$$scope" in s && a(2, i = s.$$scope)
    }, [e, l, i, o]
}
class G extends z {
    constructor(t) {
        super(), A(this, t, M, K, g, {
            stacked: 0
        })
    }
}

function N(n) {
    let t, a;
    const f = n[5].default,
        l = k(f, n, n[4], null);
    let o = [{
            class: "label-content"
        }, n[3]],
        i = {};
    for (let e = 0; e < o.length; e += 1) i = r(i, o[e]);
    return {
        c() {
            t = b("span"), l && l.c(), this.h()
        },
        l(e) {
            t = P(e, "SPAN", {
                class: !0
            });
            var s = L(t);
            l && l.l(s), s.forEach(c), this.h()
        },
        h() {
            _(t, i), u(t, "stacked", n[0]), u(t, "full-width", n[1]), u(t, "no-padding", n[2]), u(t, "svelte-1k9rtf3", !0)
        },
        m(e, s) {
            W(e, t, s), l && l.m(t, null), a = !0
        },
        p(e, [s]) {
            l && l.p && (!a || s & 16) && q(l, f, e, e[4], a ? E(f, e[4], s, null) : v(e[4]), null), _(t, i = B(o, [{
                class: "label-content"
            }, s & 8 && e[3]])), u(t, "stacked", e[0]), u(t, "full-width", e[1]), u(t, "no-padding", e[2]), u(t, "svelte-1k9rtf3", !0)
        },
        i(e) {
            a || (C(l, e), a = !0)
        },
        o(e) {
            j(l, e), a = !1
        },
        d(e) {
            e && c(t), l && l.d(e)
        }
    }
}

function Q(n, t, a) {
    const f = ["stacked", "fullWidth", "noPadding"];
    let l = h(t, f),
        {
            $$slots: o = {},
            $$scope: i
        } = t,
        {
            stacked: e = !1
        } = t,
        {
            fullWidth: s = !1
        } = t,
        {
            noPadding: m = !1
        } = t;
    return n.$$set = d => {
        t = r(r({}, t), S(d)), a(3, l = h(t, f)), "stacked" in d && a(0, e = d.stacked), "fullWidth" in d && a(1, s = d.fullWidth), "noPadding" in d && a(2, m = d.noPadding), "$$scope" in d && a(4, i = d.$$scope)
    }, [e, s, m, l, i, o]
}
class H extends z {
    constructor(t) {
        super(), A(this, t, Q, N, g, {
            stacked: 0,
            fullWidth: 1,
            noPadding: 2
        })
    }
}
export {
    G as L, H as a
};