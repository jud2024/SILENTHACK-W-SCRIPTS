import {
    P as u,
    a4 as q,
    a5 as z,
    a6 as g,
    R as F,
    O as J,
    i as L,
    a7 as B,
    H as M,
    _ as w
} from "./index.B4-7gKq3.js";
import {
    b as T
} from "./index.BxooaYHE.js";
import {
    w as m,
    d as i
} from "./index.C2-CG2CN.js";
import {
    b as Q
} from "./index.DvfdZexJ.js";
import {
    c as N
} from "./helpers.BdroHKF4.js";
import {
    h as U
} from "./index.CgjaLSob.js";
import {
    m as n
} from "./utils.Csgj0yys.js";
import {
    G as a
} from "./scheduler.DXu26z7T.js";

function ot({
    initialChips: H = {}
}) {
    const v = m(null),
        b = m(""),
        o = m(a(M)),
        V = m("hidden"),
        k = t => !(n("betTab.idle", t) || n("autobetTab.idle", t) || n("advancedTab.idle", t)),
        E = i(b, t => k(t)),
        S = i(b, t => n("betTab.fetching", t) || n("autobetTab.fetching", t) || n("advancedTab.fetching", t)),
        f = (() => {
            const t = m(u(0));
            return { ...t,
                change: ({
                    amount: e
                }) => {
                    t.set(u(e))
                },
                halve: () => {
                    t.update(e => u(q({
                        amount: Number(e),
                        currency: a(o)
                    }), a(o)))
                },
                double: () => {
                    const e = a(o),
                        c = a(T)[e];
                    t.update(l => u(z({
                        amount: Number(l),
                        balance: c.available,
                        currency: e
                    }), e))
                },
                max: () => {
                    const e = a(o),
                        c = a(T)[e];
                    t.set(String(g(c.available)))
                },
                reset: () => {
                    t.set(u(0, a(o)))
                },
                format: () => {
                    t.update(e => u(Number(e)))
                }
            }
        })(),
        _ = i(b, t => n("advancedTab", t) ? "advanced" : n("autobetTab", t) ? "automated" : "manual"),
        D = i([F, o, J], ([t, e, c]) => {
            var l, h;
            return ((h = (l = t == null ? void 0 : t.rates) == null ? void 0 : l[e]) == null ? void 0 : h[c]) || 1
        }),
        y = i([o, T], ([t, e]) => e[t].available),
        A = i(b, t => !(n("betTab.idle", t) || n("autobetTab.idle", t) || n("advancedTab.idle", t))),
        P = i([o, f, y, A, L], ([t, e, c, l, h], C) => {
            async function s() {
                const r = await Q(Number(e), {
                    min: 0,
                    balance: g(c, t)
                }, h);
                C(r)
            }
            l === !1 ? s() : C(null)
        }),
        d = (() => {
            const t = B(H),
                e = B([]);
            return { ...t,
                set: s => {
                    t.set(s), e.reset()
                },
                setChip: s => {
                    const r = a(t),
                        p = Number(a(f)),
                        I = a(y),
                        K = N(a(t)) + p;
                    if (I > K) {
                        const O = r[s] || 0,
                            W = { ...r,
                                [s]: O + p
                            };
                        t.set(W), v.set(null);
                        const j = [...a(e), r];
                        e.set(j)
                    }
                },
                undo: () => {
                    const s = a(e),
                        r = w.last(s),
                        p = w.initial(s);
                    r && d && (d.set(r), e.set(p))
                },
                clear: () => {
                    t.reset(), e.reset()
                },
                history: e
            }
        })(),
        R = i([d], ([t]) => N(t)),
        G = (() => {
            const t = m({});
            return { ...t,
                set: (e = {}) => {
                    t.set({
                        gameState: e,
                        amount: Number(a(f)),
                        chips: a(d)
                    })
                }
            }
        })();
    return {
        currency: o,
        lastBet: v,
        amount: f,
        tab: _,
        xstate: b,
        conversion: D,
        amountValidationError: P,
        disabled: E,
        fetching: S,
        hotkeysEnabled: U,
        modal: V,
        inPlay: A,
        balance: y,
        chips: d,
        totalChipsBetAmount: R,
        initialState: G
    }
}
export {
    ot as c
};