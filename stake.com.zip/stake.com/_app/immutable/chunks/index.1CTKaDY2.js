import {
    B as r,
    k as d,
    p as A,
    ba as h,
    bb as T,
    G as _,
    bc as C,
    r as B,
    aQ as E
} from "./index.B4-7gKq3.js";
import {
    G as c
} from "./scheduler.DXu26z7T.js";
import {
    L as I,
    b as u
} from "./variables.CIGccMR5.js";
import {
    d as L,
    w as n
} from "./index.C2-CG2CN.js";
import {
    s as k,
    T as M
} from "./sessionInfo.6qRo2rSN.js";
import {
    F as N
} from "./fiatNumberFormat.CcHMsn0U.js";
const g = "cookie_consent",
    J = r(g, !1),
    R = {
        label: "Paroli",
        isDefault: !0,
        blocks: [{
            id: "paroli1",
            type: "bets",
            on: {
                type: "every",
                value: 1,
                betType: "win",
                profitType: "balance"
            },
            do: {
                type: "increaseByPercentage",
                value: 100
            }
        }, {
            id: "paroli2",
            type: "bets",
            on: {
                type: "streakGreaterThan",
                value: 3,
                betType: "win",
                profitType: "balance"
            },
            do: {
                type: "resetAmount",
                value: 0
            }
        }, {
            id: "paroli3",
            type: "bets",
            on: {
                type: "every",
                value: 1,
                betType: "lose",
                profitType: "balance"
            },
            do: {
                type: "resetAmount",
                value: 0
            }
        }]
    },
    D = {
        label: "D 'Alembert",
        isDefault: !0,
        blocks: [{
            id: "Alembert1",
            type: "bets",
            on: {
                type: "every",
                value: 1,
                betType: "win",
                profitType: "balance"
            },
            do: {
                type: "addToAmount",
                value: 1e-8
            }
        }, {
            id: "Alembert2",
            type: "bets",
            on: {
                type: "every",
                value: 1,
                betType: "lose",
                profitType: "balance"
            },
            do: {
                type: "subtractFromAmount",
                value: 1e-8
            }
        }]
    },
    F = {
        label: "Martingale",
        isDefault: !0,
        blocks: [{
            id: "mart1",
            type: "bets",
            on: {
                type: "every",
                value: 1,
                betType: "lose",
                profitType: "balance"
            },
            do: {
                type: "increaseByPercentage",
                value: 100
            }
        }, {
            id: "mart2",
            type: "bets",
            on: {
                type: "every",
                value: 1,
                betType: "win"
            },
            do: {
                type: "resetAmount",
                value: 0
            }
        }]
    },
    O = {
        label: "Delayed Martingale",
        isDefault: !0,
        blocks: [{
            id: "delay1",
            type: "bets",
            on: {
                type: "streakGreaterThan",
                value: 3,
                betType: "lose",
                profitType: "balance"
            },
            do: {
                type: "increaseByPercentage",
                value: 100
            }
        }, {
            id: "delay2",
            type: "bets",
            on: {
                type: "firstStreakOf",
                value: 3,
                betType: "lose",
                profitType: "balance"
            },
            do: {
                type: "increaseByPercentage",
                value: 100
            }
        }, {
            id: "delay3",
            type: "bets",
            on: {
                type: "every",
                value: 1,
                betType: "win",
                profitType: "balance"
            },
            do: {
                type: "resetAmount",
                value: 0
            }
        }]
    },
    S = "strategies",
    m = "saved",
    y = `${S}_${m}`,
    P = [F, O, R, D],
    V = d(S),
    X = (() => {
        const e = V(m, [...P]);
        return { ...e,
            delete: t => {
                e.update(a => a.filter(o => o.label !== t))
            },
            save: t => {
                const a = c(e),
                    o = Array.isArray(a) ? a : [];
                if (o.some(i => i.label === t.label)) {
                    const i = o.map(b => b.label === t.label ? t : b);
                    e.set(i)
                } else {
                    const i = [...o, t];
                    e.set(i)
                }
            }
        }
    })(),
    W = d("app"),
    q = n("highRollers"),
    ee = n({
        accordion: null
    }),
    te = n("home"),
    v = {
        minimized: "expanded",
        expanded: "minimized"
    },
    ae = L([A], ([e]) => e.data.infoRoles || null),
    f = (() => {
        let e = "expanded";
        window.innerWidth < I && (e = "minimized");
        const t = r("leftSidebarView_v2", e);
        return { ...t,
            toggle: () => t.update(a => v[a])
        }
    })(),
    z = () => "hidden",
    l = { ...r("sidebarView", z())
    },
    K = (() => {
        const e = n(!1);
        return { ...e,
            close: () => e.set(!1)
        }
    })(),
    oe = W("betsBoardCount", 10),
    s = e => {
        e.type === "sidebar" ? (l.update(t => t === e.value ? "hidden" : e.value), window.innerWidth < u.sidebarFullWidth && f.set("minimized")) : e.type === "leftSidebar" ? (f.update(t => v[t]), window.innerWidth < u.sidebarFullWidth && l.set("hidden")) : e.type === "widget" ? K.update(t => !t) : l.set("hidden")
    },
    se = {
        toggleChatSidebar: () => {
            s({
                type: "sidebar",
                value: "chat"
            })
        },
        toggleMobileMenu: () => {
            s({
                type: "leftSidebar"
            })
        },
        toggleBetsListBoard: () => {
            s({
                type: "sidebar",
                value: "betsListBoard"
            })
        },
        toggleBetslipSidebar: () => {
            s({
                type: "sidebar",
                value: "betslip"
            })
        },
        toggleSearchSidebar: () => {
            s({
                type: "sidebar",
                value: "search"
            })
        },
        toggleAcpSearchSidebar: () => {
            s({
                type: "sidebar",
                value: "acpSearch"
            })
        },
        toggleNotificationsSidebar: () => {
            s({
                type: "widget",
                value: "notifications"
            })
        },
        toggleNotificationsWidget: () => {
            s({
                type: "widget",
                value: "notifications"
            })
        }
    },
    G = e => E(M, e);
async function ie() {
    const e = c(k);
    e != null && e.id && await G({
        sessionId: e.id
    }), h([g, T.namespace, _.namespace, C, N]);
    const t = window.localStorage.getItem(y);
    window.localStorage.clear(), window.localStorage.setItem(y, t || "");
    const a = c(B);
    window.location.replace(a("/"))
}

function w(e) {
    return { ...e,
        save: t => {
            t.length !== 0 && e.update(a => {
                const o = Array.isArray(a) ? a : [];
                return [t, ...o.filter(p => t.startsWith(p) === !1)].slice(0, 5)
            })
        },
        remove: t => {
            e.update(a => a.filter(o => o !== t))
        },
        removeAll: () => {
            e.update(() => [])
        }
    }
}
const x = ["Monopoly", "Crazy Time", "Sweet Bonanza", "Money Train", "Reactoonz"],
    Y = ["Liverpool FC", "Kansas City Chiefs", "Los Angeles Lakers", "FC Barcelona", "FC Bayern Munich"],
    re = w(r("casinoSearch", x)),
    ne = w(r("sportsSearch", Y)),
    le = d("app")("unsichtbar", !1);
export {
    f as a, q as b, X as c, re as d, ne as e, oe as f, se as g, te as h, ae as i, J as j, ie as l, F as m, K as n, ee as o, l as s, le as u
};