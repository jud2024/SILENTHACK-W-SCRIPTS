import {
    s as h,
    C as o,
    H as u,
    D as f,
    f as m,
    E as _,
    i as r,
    F as n,
    j as d,
    n as v
} from "./scheduler.DXu26z7T.js";
import {
    S as g,
    i as y
} from "./index.Dz_MmNB3.js";

function w(c) {
    let l, a, s = ` <title>${c[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M30.907 55.396.457 24.946v.002A1.554 1.554 0 0 1 0 23.843c0-.432.174-.82.458-1.104l14.13-14.13a1.554 1.554 0 0 1 1.104-.458c.432 0 .821.175 1.104.458l14.111 14.13c.272.272.645.443 1.058.453l.1-.013h.004a1.551 1.551 0 0 0 1.045-.452l14.09-14.09a1.554 1.554 0 0 1 1.104-.457c.432 0 .82.174 1.104.457l14.13 14.121a1.557 1.557 0 0 1 0 2.209L33.114 55.396v-.002c-.27.268-.637.438-1.046.452v.001h.003a.712.712 0 0 1-.04.002h-.029c-.427 0-.815-.173-1.095-.453Z"></path>`,
        i;
    return {
        c() {
            l = o("svg"), a = new u(!0), this.h()
        },
        l(t) {
            l = f(t, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var e = m(l);
            a = _(e, !0), e.forEach(r), this.h()
        },
        h() {
            a.a = null, n(l, "fill", "currentColor"), n(l, "viewBox", "0 0 64 64"), n(l, "class", i = "svg-icon " + c[2]), n(l, "style", c[0])
        },
        m(t, e) {
            d(t, l, e), a.m(s, l)
        },
        p(t, [e]) {
            e & 2 && s !== (s = ` <title>${t[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M30.907 55.396.457 24.946v.002A1.554 1.554 0 0 1 0 23.843c0-.432.174-.82.458-1.104l14.13-14.13a1.554 1.554 0 0 1 1.104-.458c.432 0 .821.175 1.104.458l14.111 14.13c.272.272.645.443 1.058.453l.1-.013h.004a1.551 1.551 0 0 0 1.045-.452l14.09-14.09a1.554 1.554 0 0 1 1.104-.457c.432 0 .82.174 1.104.457l14.13 14.121a1.557 1.557 0 0 1 0 2.209L33.114 55.396v-.002c-.27.268-.637.438-1.046.452v.001h.003a.712.712 0 0 1-.04.002h-.029c-.427 0-.815-.173-1.095-.453Z"></path>`) && a.p(s), e & 4 && i !== (i = "svg-icon " + t[2]) && n(l, "class", i), e & 1 && n(l, "style", t[0])
        },
        i: v,
        o: v,
        d(t) {
            t && r(l)
        }
    }
}

function H(c, l, a) {
    let {
        style: s = ""
    } = l, {
        alt: i = ""
    } = l, {
        class: t = ""
    } = l;
    return c.$$set = e => {
        "style" in e && a(0, s = e.style), "alt" in e && a(1, i = e.alt), "class" in e && a(2, t = e.class)
    }, [s, i, t]
}
class A extends g {
    constructor(l) {
        super(), y(this, l, H, w, h, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    A as S
};