const e = {
    kind: "Document",
    definitions: [{
        kind: "OperationDefinition",
        operation: "query",
        name: {
            kind: "Name",
            value: "MyBetList"
        },
        variableDefinitions: [{
            kind: "VariableDefinition",
            variable: {
                kind: "Variable",
                name: {
                    kind: "Name",
                    value: "offset"
                }
            },
            type: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "Int"
                }
            },
            defaultValue: {
                kind: "IntValue",
                value: "0"
            }
        }, {
            kind: "VariableDefinition",
            variable: {
                kind: "Variable",
                name: {
                    kind: "Name",
                    value: "limit"
                }
            },
            type: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "Int"
                }
            },
            defaultValue: {
                kind: "IntValue",
                value: "10"
            }
        }, {
            kind: "VariableDefinition",
            variable: {
                kind: "Variable",
                name: {
                    kind: "Name",
                    value: "game"
                }
            },
            type: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "BetHouseEnum"
                }
            }
        }, {
            kind: "VariableDefinition",
            variable: {
                kind: "Variable",
                name: {
                    kind: "Name",
                    value: "name"
                }
            },
            type: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "String"
                }
            }
        }],
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "user"
                },
                arguments: [{
                    kind: "Argument",
                    name: {
                        kind: "Name",
                        value: "name"
                    },
                    value: {
                        kind: "Variable",
                        name: {
                            kind: "Name",
                            value: "name"
                        }
                    }
                }],
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "id"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "houseBetList"
                        },
                        arguments: [{
                            kind: "Argument",
                            name: {
                                kind: "Name",
                                value: "offset"
                            },
                            value: {
                                kind: "Variable",
                                name: {
                                    kind: "Name",
                                    value: "offset"
                                }
                            }
                        }, {
                            kind: "Argument",
                            name: {
                                kind: "Name",
                                value: "limit"
                            },
                            value: {
                                kind: "Variable",
                                name: {
                                    kind: "Name",
                                    value: "limit"
                                }
                            }
                        }, {
                            kind: "Argument",
                            name: {
                                kind: "Name",
                                value: "game"
                            },
                            value: {
                                kind: "Variable",
                                name: {
                                    kind: "Name",
                                    value: "game"
                                }
                            }
                        }],
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "FragmentSpread",
                                name: {
                                    kind: "Name",
                                    value: "CasinoBetFragment"
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "CasinoBet"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "CasinoBet"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "active"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "payoutMultiplier"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "amountMultiplier"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "amount"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "payout"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "updatedAt"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "currency"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "game"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "user"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "id"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "name"
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "EvolutionBet"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "EvolutionBet"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "amount"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "currency"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "createdAt"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "payout"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "payoutMultiplier"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "user"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "id"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "name"
                        }
                    }]
                }
            }, {
                kind: "Field",
                alias: {
                    kind: "Name",
                    value: "softswissGame"
                },
                name: {
                    kind: "Name",
                    value: "game"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "id"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "name"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "edge"
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "MultiplayerCrashBet"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "MultiplayerCrashBet"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "user"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "id"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "name"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "preferenceHideBets"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "payoutMultiplier"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "gameId"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "amount"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "payout"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "currency"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "result"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "updatedAt"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "cashoutAt"
                }
            }, {
                kind: "Field",
                alias: {
                    kind: "Name",
                    value: "btcAmount"
                },
                name: {
                    kind: "Name",
                    value: "amount"
                },
                arguments: [{
                    kind: "Argument",
                    name: {
                        kind: "Name",
                        value: "currency"
                    },
                    value: {
                        kind: "EnumValue",
                        value: "btc"
                    }
                }]
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "MultiplayerSlideBet"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "MultiplayerSlideBet"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "user"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "id"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "name"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "preferenceHideBets"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "payoutMultiplier"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "gameId"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "amount"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "payout"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "currency"
                }
            }, {
                kind: "Field",
                alias: {
                    kind: "Name",
                    value: "slideResult"
                },
                name: {
                    kind: "Name",
                    value: "result"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "updatedAt"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "cashoutAt"
                }
            }, {
                kind: "Field",
                alias: {
                    kind: "Name",
                    value: "btcAmount"
                },
                name: {
                    kind: "Name",
                    value: "amount"
                },
                arguments: [{
                    kind: "Argument",
                    name: {
                        kind: "Name",
                        value: "currency"
                    },
                    value: {
                        kind: "EnumValue",
                        value: "btc"
                    }
                }]
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "active"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "createdAt"
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "SoftswissBet"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SoftswissBet"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "amount"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "currency"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "updatedAt"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "payout"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "payoutMultiplier"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "user"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "id"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "name"
                        }
                    }]
                }
            }, {
                kind: "Field",
                alias: {
                    kind: "Name",
                    value: "softswissGame"
                },
                name: {
                    kind: "Name",
                    value: "game"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "id"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "name"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "edge"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "extId"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "provider"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "id"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "name"
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "ThirdPartyBet"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "ThirdPartyBet"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "amount"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "currency"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "updatedAt"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "payout"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "payoutMultiplier"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "betReplay"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "user"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "id"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "name"
                        }
                    }]
                }
            }, {
                kind: "Field",
                alias: {
                    kind: "Name",
                    value: "thirdPartyGame"
                },
                name: {
                    kind: "Name",
                    value: "game"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "id"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "name"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "edge"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "extId"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "provider"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "id"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "name"
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "CasinoBetFragment"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "Bet"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "iid"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "type"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "scope"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "game"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "name"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "icon"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "slug"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "bet"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "CasinoBet"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "FragmentSpread",
                                name: {
                                    kind: "Name",
                                    value: "CasinoBet"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "user"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "id"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "preferenceHideBets"
                                        }
                                    }]
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "EvolutionBet"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "FragmentSpread",
                                name: {
                                    kind: "Name",
                                    value: "EvolutionBet"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "user"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "id"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "preferenceHideBets"
                                        }
                                    }]
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "MultiplayerCrashBet"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "FragmentSpread",
                                name: {
                                    kind: "Name",
                                    value: "MultiplayerCrashBet"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "user"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "id"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "preferenceHideBets"
                                        }
                                    }]
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "MultiplayerSlideBet"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "FragmentSpread",
                                name: {
                                    kind: "Name",
                                    value: "MultiplayerSlideBet"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "user"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "id"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "preferenceHideBets"
                                        }
                                    }]
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SoftswissBet"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "FragmentSpread",
                                name: {
                                    kind: "Name",
                                    value: "SoftswissBet"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "user"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "id"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "preferenceHideBets"
                                        }
                                    }]
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "ThirdPartyBet"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "FragmentSpread",
                                name: {
                                    kind: "Name",
                                    value: "ThirdPartyBet"
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }]
};
export {
    e as M
};