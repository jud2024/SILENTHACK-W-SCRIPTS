function e(t) {
    return Object.prototype.toString.call(t) === "[object Date]"
}
export {
    e as i
};