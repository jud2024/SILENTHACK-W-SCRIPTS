import {
    aU as n
} from "./index.B4-7gKq3.js";
import {
    c as d
} from "./helpers.ByXtmvj6.js";
const t = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "subscription",
            name: {
                kind: "Name",
                value: "RaceStatus"
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "raceStatus"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "RaceFragment"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "RaceFragment"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "Race"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "description"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "type"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "startTime"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "endTime"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "status"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "scope"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "promotionPeriod"
                    }
                }]
            }
        }]
    },
    m = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "query",
            name: {
                kind: "Name",
                value: "ActiveRaces"
            },
            variableDefinitions: [{
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "limit"
                    }
                },
                type: {
                    kind: "NamedType",
                    name: {
                        kind: "Name",
                        value: "Int"
                    }
                },
                defaultValue: {
                    kind: "IntValue",
                    value: "10"
                }
            }],
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "activeRaces"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "RaceFragment"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "leaderboard"
                            },
                            arguments: [{
                                kind: "Argument",
                                name: {
                                    kind: "Name",
                                    value: "limit"
                                },
                                value: {
                                    kind: "Variable",
                                    name: {
                                        kind: "Name",
                                        value: "limit"
                                    }
                                }
                            }],
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "RacePosition"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "userPosition"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "RacePosition"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "RaceFragment"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "Race"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "description"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "type"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "startTime"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "endTime"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "status"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "scope"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "promotionPeriod"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "RacePosition"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "RacePosition"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "position"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "preferenceHideBets"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "wageredAmount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payoutAmount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "percentage"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                }]
            }
        }]
    },
    a = (e, i) => new Date(e.startTime).getTime() - new Date(i.endTime).getTime(),
    o = e => [...e.filter(i => i.status === n.scheduled).sort(a), ...e.filter(i => i.status === n.started).sort(a), ...e.filter(i => i.status === n.completed).sort(a)],
    s = d({
        queryDocument: m,
        queryVariables: {},
        subscriptionDocument: t,
        getQueryPath: e => (e == null ? void 0 : e.activeRaces) || [],
        getSubscriptionPath: e => e != null && e.raceStatus ? { ...e == null ? void 0 : e.raceStatus,
            leaderboard: []
        } : void 0
    });
export {
    m as A, t as R, s as a, o as s
};