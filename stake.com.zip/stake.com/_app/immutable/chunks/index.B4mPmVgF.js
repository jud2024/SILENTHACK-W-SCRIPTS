import {
    s as Y,
    e as D,
    O as C,
    d as O,
    f as I,
    i as p,
    P as F,
    F as S,
    I as he,
    V as re,
    j as $,
    k as U,
    c as ce,
    n as G,
    m as y,
    L as ne,
    X as ke,
    K as Q,
    M as be,
    t as V,
    h as j,
    l as q
} from "./scheduler.DXu26z7T.js";
import {
    S as Z,
    i as x,
    c as h,
    a as k,
    m as b,
    t as _,
    b as d,
    d as v,
    g as P,
    e as w
} from "./index.Dz_MmNB3.js";
import {
    e as z,
    u as me,
    o as _e
} from "./each.DvgCmocI.js";
import {
    g as ve,
    a as Le
} from "./spread.CgU5AtxT.js";
import {
    S as Me
} from "./index.DmsScLg1.js";
import {
    C as ye
} from "./contentOrLoader.Ol9dNjON.js";
import {
    A as Te
} from "./AccordionHeader.MRxqKRwW.js";
import {
    P as X
} from "./index.B1KDSkU5.js";
import {
    S as ee
} from "./index.DChG_RHX.js";
import {
    T as te
} from "./index.D7nbRHfU.js";
import {
    F as Be,
    L as Ee
} from "./index.BRT09uIB.js";
import {
    h as W,
    i as Ne,
    bp as De,
    _ as ie
} from "./index.B4-7gKq3.js";
import "./index.B3dW9TVs.js";
import {
    L as de
} from "./index.DJurAkTj.js";
import {
    g as Oe
} from "./context.BYnTbg5S.js";
import {
    S as Se
} from "./index.DCSb0LMW.js";
import {
    B as Ae
} from "./button.BwmFDw8u.js";

function Ce(s) {
    let e, l, t, r, n, o, a, i, f, c;
    return t = new X({
        props: {
            width: "5ch"
        }
    }), o = new X({
        props: {
            width: "10ch"
        }
    }), f = new X({
        props: {
            width: "2ch"
        }
    }), {
        c() {
            e = D("div"), l = D("span"), h(t.$$.fragment), r = C(), n = D("div"), h(o.$$.fragment), a = C(), i = D("span"), h(f.$$.fragment), this.h()
        },
        l(g) {
            e = O(g, "DIV", {
                class: !0
            });
            var M = I(e);
            l = O(M, "SPAN", {
                class: !0,
                style: !0
            });
            var E = I(l);
            k(t.$$.fragment, E), E.forEach(p), r = F(M), n = O(M, "DIV", {
                class: !0
            });
            var T = I(n);
            k(o.$$.fragment, T), T.forEach(p), a = F(M), i = O(M, "SPAN", {
                class: !0
            });
            var N = I(i);
            k(f.$$.fragment, N), N.forEach(p), M.forEach(p), this.h()
        },
        h() {
            S(l, "class", "name svelte-6rcll6"), he(l, "margin-bottom", "var(--space-1)"), S(n, "class", "breadcrumb svelte-6rcll6"), S(i, "class", "market-count svelte-6rcll6"), S(e, "class", "outright-preview svelte-6rcll6"), re(e, "stacked", s[0])
        },
        m(g, M) {
            $(g, e, M), U(e, l), b(t, l, null), U(e, r), U(e, n), b(o, n, null), U(e, a), U(e, i), b(f, i, null), c = !0
        },
        p(g, [M]) {
            (!c || M & 1) && re(e, "stacked", g[0])
        },
        i(g) {
            c || (_(t.$$.fragment, g), _(o.$$.fragment, g), _(f.$$.fragment, g), c = !0)
        },
        o(g) {
            d(t.$$.fragment, g), d(o.$$.fragment, g), d(f.$$.fragment, g), c = !1
        },
        d(g) {
            g && p(e), v(t), v(o), v(f)
        }
    }
}

function Fe(s, e, l) {
    let t, r = Oe();
    return ce(s, r, n => l(0, t = n)), [t, r]
}
class Pe extends Z {
    constructor(e) {
        super(), x(this, e, Fe, Ce, Y, {})
    }
}

function we(s) {
    let e;
    return {
        c() {
            e = D("hr"), this.h()
        },
        l(l) {
            e = O(l, "HR", {
                class: !0
            }), this.h()
        },
        h() {
            S(e, "class", "svelte-33ihxp")
        },
        m(l, t) {
            $(l, e, t)
        },
        p: G,
        i: G,
        o: G,
        d(l) {
            l && p(e)
        }
    }
}
class ge extends Z {
    constructor(e) {
        super(), x(this, e, null, we, Y, {})
    }
}
const A = {
    loadMore: W._("Load More"),
    noOutrights: W._("No outrights available"),
    noFixtures: W._("No fixtures available"),
    showAll: W._("Show All")
};

function ae(s, e, l) {
    const t = s.slice();
    return t[25] = e[l], t
}

function se(s, e, l) {
    const t = s.slice();
    return t[22] = e[l], t[24] = l, t
}

function Ie(s) {
    let e, l;
    const t = [s[19], {
        isOpenByDefault: s[6]
    }, {
        level: s[9]
    }];
    let r = {
        $$slots: {
            header: [at],
            default: [Ze]
        },
        $$scope: {
            ctx: s
        }
    };
    for (let n = 0; n < t.length; n += 1) r = Q(r, t[n]);
    return e = new Me({
        props: r
    }), e.$on("click", s[21]), {
        c() {
            h(e.$$.fragment)
        },
        l(n) {
            k(e.$$.fragment, n)
        },
        m(n, o) {
            b(e, n, o), l = !0
        },
        p(n, o) {
            const a = o & 524864 ? ve(t, [o & 524288 && Le(n[19]), o & 64 && {
                isOpenByDefault: n[6]
            }, o & 512 && {
                level: n[9]
            }]) : {};
            o & 268694975 && (a.$$scope = {
                dirty: o,
                ctx: n
            }), e.$set(a)
        },
        i(n) {
            l || (_(e.$$.fragment, n), l = !0)
        },
        o(n) {
            d(e.$$.fragment, n), l = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Ve(s) {
    let e, l;
    return e = new Se({
        props: {
            $$slots: {
                default: [st]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            h(e.$$.fragment)
        },
        l(t) {
            k(e.$$.fragment, t)
        },
        m(t, r) {
            b(e, t, r), l = !0
        },
        p(t, r) {
            const n = {};
            r & 268568576 && (n.$$scope = {
                dirty: r,
                ctx: t
            }), e.$set(n)
        },
        i(t) {
            l || (_(e.$$.fragment, t), l = !0)
        },
        o(t) {
            d(e.$$.fragment, t), l = !1
        },
        d(t) {
            v(e, t)
        }
    }
}

function je(s) {
    let e, l, t;
    return l = new te({
        props: {
            align: "center",
            $$slots: {
                default: [Re]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            e = D("div"), h(l.$$.fragment), this.h()
        },
        l(r) {
            e = O(r, "DIV", {
                class: !0
            });
            var n = I(e);
            k(l.$$.fragment, n), n.forEach(p), this.h()
        },
        h() {
            S(e, "class", "empty-list svelte-1u22cis")
        },
        m(r, n) {
            $(r, e, n), b(l, e, null), t = !0
        },
        p(r, n) {
            const o = {};
            n & 268566536 && (o.$$scope = {
                dirty: n,
                ctx: r
            }), l.$set(o)
        },
        i(r) {
            t || (_(l.$$.fragment, r), t = !0)
        },
        o(r) {
            d(l.$$.fragment, r), t = !1
        },
        d(r) {
            r && p(e), v(l)
        }
    }
}

function He(s) {
    let e = [],
        l = new Map,
        t, r, n = z(ie.range(0, s[8] ? s[8] - (s[12] ? s[1].length : 0) : 3));
    const o = a => a[25];
    for (let a = 0; a < n.length; a += 1) {
        let i = ae(s, n, a),
            f = o(i);
        l.set(f, e[a] = oe(f, i))
    }
    return {
        c() {
            for (let a = 0; a < e.length; a += 1) e[a].c();
            t = y()
        },
        l(a) {
            for (let i = 0; i < e.length; i += 1) e[i].l(a);
            t = y()
        },
        m(a, i) {
            for (let f = 0; f < e.length; f += 1) e[f] && e[f].m(a, i);
            $(a, t, i), r = !0
        },
        p(a, i) {
            i & 69898 && (n = z(ie.range(0, a[8] ? a[8] - (a[12] ? a[1].length : 0) : 3)), P(), e = me(e, i, o, 1, a, n, l, t.parentNode, _e, oe, t, ae), w())
        },
        i(a) {
            if (!r) {
                for (let i = 0; i < n.length; i += 1) _(e[i]);
                r = !0
            }
        },
        o(a) {
            for (let i = 0; i < e.length; i += 1) d(e[i]);
            r = !1
        },
        d(a) {
            a && p(t);
            for (let i = 0; i < e.length; i += 1) e[i].d(a)
        }
    }
}

function Re(s) {
    let e = s[17]._(s[3] ? A.noOutrights : A.noFixtures) + "",
        l;
    return {
        c() {
            l = V(e)
        },
        l(t) {
            l = j(t, e)
        },
        m(t, r) {
            $(t, l, r)
        },
        p(t, r) {
            r & 131080 && e !== (e = t[17]._(t[3] ? A.noOutrights : A.noFixtures) + "") && q(l, e)
        },
        d(t) {
            t && p(l)
        }
    }
}

function Ue(s) {
    let e, l;
    return e = new Ee({
        props: {
            isMulti: !!s[16],
            variant: "transparent"
        }
    }), {
        c() {
            h(e.$$.fragment)
        },
        l(t) {
            k(e.$$.fragment, t)
        },
        m(t, r) {
            b(e, t, r), l = !0
        },
        p(t, r) {
            const n = {};
            r & 65536 && (n.isMulti = !!t[16]), e.$set(n)
        },
        i(t) {
            l || (_(e.$$.fragment, t), l = !0)
        },
        o(t) {
            d(e.$$.fragment, t), l = !1
        },
        d(t) {
            v(e, t)
        }
    }
}

function qe(s) {
    let e, l;
    return e = new Pe({}), {
        c() {
            h(e.$$.fragment)
        },
        l(t) {
            k(e.$$.fragment, t)
        },
        m(t, r) {
            b(e, t, r), l = !0
        },
        p: G,
        i(t) {
            l || (_(e.$$.fragment, t), l = !0)
        },
        o(t) {
            d(e.$$.fragment, t), l = !1
        },
        d(t) {
            v(e, t)
        }
    }
}

function oe(s, e) {
    let l, t, r, n, o;
    const a = [qe, Ue],
        i = [];

    function f(c, g) {
        return c[3] ? 0 : 1
    }
    return t = f(e), r = i[t] = a[t](e), {
        key: s,
        first: null,
        c() {
            l = y(), r.c(), n = y(), this.h()
        },
        l(c) {
            l = y(), r.l(c), n = y(), this.h()
        },
        h() {
            this.first = l
        },
        m(c, g) {
            $(c, l, g), i[t].m(c, g), $(c, n, g), o = !0
        },
        p(c, g) {
            e = c;
            let M = t;
            t = f(e), t === M ? i[t].p(e, g) : (P(), d(i[M], 1, 1, () => {
                i[M] = null
            }), w(), r = i[t], r ? r.p(e, g) : (r = i[t] = a[t](e), r.c()), _(r, 1), r.m(n.parentNode, n))
        },
        i(c) {
            o || (_(r), o = !0)
        },
        o(c) {
            d(r), o = !1
        },
        d(c) {
            c && (p(l), p(n)), i[t].d(c)
        }
    }
}

function Ge(s) {
    let e, l, t, r;
    return e = new ge({}), t = new ee({
        props: {
            x: "flex-start",
            paddingLeft: "large",
            paddingTop: "medium",
            paddingBottom: "smaller",
            $$slots: {
                default: [Xe]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            h(e.$$.fragment), l = C(), h(t.$$.fragment)
        },
        l(n) {
            k(e.$$.fragment, n), l = F(n), k(t.$$.fragment, n)
        },
        m(n, o) {
            b(e, n, o), $(n, l, o), b(t, n, o), r = !0
        },
        p(n, o) {
            const a = {};
            o & 268574720 && (a.$$scope = {
                dirty: o,
                ctx: n
            }), t.$set(a)
        },
        i(n) {
            r || (_(e.$$.fragment, n), _(t.$$.fragment, n), r = !0)
        },
        o(n) {
            d(e.$$.fragment, n), d(t.$$.fragment, n), r = !1
        },
        d(n) {
            n && p(l), v(e, n), v(t, n)
        }
    }
}

function Ke(s) {
    let e, l, t, r;
    return e = new ge({}), t = new ee({
        props: {
            x: "flex-start",
            paddingLeft: "large",
            paddingTop: "medium",
            paddingBottom: "smaller",
            $$slots: {
                default: [Qe]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            h(e.$$.fragment), l = C(), h(t.$$.fragment)
        },
        l(n) {
            k(e.$$.fragment, n), l = F(n), k(t.$$.fragment, n)
        },
        m(n, o) {
            b(e, n, o), $(n, l, o), b(t, n, o), r = !0
        },
        p(n, o) {
            const a = {};
            o & 268570624 && (a.$$scope = {
                dirty: o,
                ctx: n
            }), t.$set(a)
        },
        i(n) {
            r || (_(e.$$.fragment, n), _(t.$$.fragment, n), r = !0)
        },
        o(n) {
            d(e.$$.fragment, n), d(t.$$.fragment, n), r = !1
        },
        d(n) {
            n && p(l), v(e, n), v(t, n)
        }
    }
}

function We(s) {
    let e = s[17]._(A.showAll) + "",
        l;
    return {
        c() {
            l = V(e)
        },
        l(t) {
            l = j(t, e)
        },
        m(t, r) {
            $(t, l, r)
        },
        p(t, r) {
            r & 131072 && e !== (e = t[17]._(A.showAll) + "") && q(l, e)
        },
        d(t) {
            t && p(l)
        }
    }
}

function Xe(s) {
    let e, l;
    return e = new de({
        props: {
            class: "w-full",
            variant: "subtle-link",
            to: s[13],
            $$slots: {
                default: [We]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            h(e.$$.fragment)
        },
        l(t) {
            k(e.$$.fragment, t)
        },
        m(t, r) {
            b(e, t, r), l = !0
        },
        p(t, r) {
            const n = {};
            r & 8192 && (n.to = t[13]), r & 268566528 && (n.$$scope = {
                dirty: r,
                ctx: t
            }), e.$set(n)
        },
        i(t) {
            l || (_(e.$$.fragment, t), l = !0)
        },
        o(t) {
            d(e.$$.fragment, t), l = !1
        },
        d(t) {
            v(e, t)
        }
    }
}

function ze(s) {
    let e = s[17]._(A.loadMore) + "",
        l;
    return {
        c() {
            l = V(e)
        },
        l(t) {
            l = j(t, e)
        },
        m(t, r) {
            $(t, l, r)
        },
        p(t, r) {
            r & 131072 && e !== (e = t[17]._(A.loadMore) + "") && q(l, e)
        },
        d(t) {
            t && p(l)
        }
    }
}

function Je(s) {
    let e, l;
    return e = new ye({
        props: {
            loading: !!s[12],
            $$slots: {
                default: [ze]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            h(e.$$.fragment)
        },
        l(t) {
            k(e.$$.fragment, t)
        },
        m(t, r) {
            b(e, t, r), l = !0
        },
        p(t, r) {
            const n = {};
            r & 4096 && (n.loading = !!t[12]), r & 268566528 && (n.$$scope = {
                dirty: r,
                ctx: t
            }), e.$set(n)
        },
        i(t) {
            l || (_(e.$$.fragment, t), l = !0)
        },
        o(t) {
            d(e.$$.fragment, t), l = !1
        },
        d(t) {
            v(e, t)
        }
    }
}

function Qe(s) {
    let e, l;
    return e = new Ae({
        props: {
            disabled: s[12],
            class: "w-full justify-start",
            variant: "subtle-link",
            $$slots: {
                default: [Je]
            },
            $$scope: {
                ctx: s
            }
        }
    }), e.$on("click", s[20]), {
        c() {
            h(e.$$.fragment)
        },
        l(t) {
            k(e.$$.fragment, t)
        },
        m(t, r) {
            b(e, t, r), l = !0
        },
        p(t, r) {
            const n = {};
            r & 4096 && (n.disabled = t[12]), r & 268570624 && (n.$$scope = {
                dirty: r,
                ctx: t
            }), e.$set(n)
        },
        i(t) {
            l || (_(e.$$.fragment, t), l = !0)
        },
        o(t) {
            d(e.$$.fragment, t), l = !1
        },
        d(t) {
            v(e, t)
        }
    }
}

function Ye(s) {
    let e, l, t, r, n, o, a, i, f;
    e = new Be({
        props: {
            group: s[14],
            sortedTemplates: s[0],
            addTimeElements: s[4],
            fixtureList: s[1],
            displayBreadcrumb: s[10]
        }
    });
    const c = [He, je],
        g = [];

    function M(u, L) {
        return u[5] ? 0 : u[1].length === 0 && u[8] === 0 ? 1 : -1
    }~(t = M(s)) && (r = g[t] = c[t](s));
    const E = [Ke, Ge],
        T = [];

    function N(u, L) {
        return u[7] && u[1].length !== 0 && (u[8] || 0) > u[1].length ? 0 : u[13] ? 1 : -1
    }
    return ~(o = N(s)) && (a = T[o] = E[o](s)), {
        c() {
            h(e.$$.fragment), l = C(), r && r.c(), n = C(), a && a.c(), i = y()
        },
        l(u) {
            k(e.$$.fragment, u), l = F(u), r && r.l(u), n = F(u), a && a.l(u), i = y()
        },
        m(u, L) {
            b(e, u, L), $(u, l, L), ~t && g[t].m(u, L), $(u, n, L), ~o && T[o].m(u, L), $(u, i, L), f = !0
        },
        p(u, L) {
            const B = {};
            L & 16384 && (B.group = u[14]), L & 1 && (B.sortedTemplates = u[0]), L & 16 && (B.addTimeElements = u[4]), L & 2 && (B.fixtureList = u[1]), L & 1024 && (B.displayBreadcrumb = u[10]), e.$set(B);
            let H = t;
            t = M(u), t === H ? ~t && g[t].p(u, L) : (r && (P(), d(g[H], 1, 1, () => {
                g[H] = null
            }), w()), ~t ? (r = g[t], r ? r.p(u, L) : (r = g[t] = c[t](u), r.c()), _(r, 1), r.m(n.parentNode, n)) : r = null);
            let R = o;
            o = N(u), o === R ? ~o && T[o].p(u, L) : (a && (P(), d(T[R], 1, 1, () => {
                T[R] = null
            }), w()), ~o ? (a = T[o], a ? a.p(u, L) : (a = T[o] = E[o](u), a.c()), _(a, 1), a.m(i.parentNode, i)) : a = null)
        },
        i(u) {
            f || (_(e.$$.fragment, u), _(r), _(a), f = !0)
        },
        o(u) {
            d(e.$$.fragment, u), d(r), d(a), f = !1
        },
        d(u) {
            u && (p(l), p(n), p(i)), v(e, u), ~t && g[t].d(u), ~o && T[o].d(u)
        }
    }
}

function Ze(s) {
    let e, l;
    return e = new ee({
        props: {
            stretch: !0,
            gap: "none",
            paddingTop: s[4] ? "none" : "small",
            paddingBottom: "small",
            $$slots: {
                default: [Ye]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            h(e.$$.fragment)
        },
        l(t) {
            k(e.$$.fragment, t)
        },
        m(t, r) {
            b(e, t, r), l = !0
        },
        p(t, r) {
            const n = {};
            r & 16 && (n.paddingTop = t[4] ? "none" : "small"), r & 268662203 && (n.$$scope = {
                dirty: r,
                ctx: t
            }), e.$set(n)
        },
        i(t) {
            l || (_(e.$$.fragment, t), l = !0)
        },
        o(t) {
            d(e.$$.fragment, t), l = !1
        },
        d(t) {
            v(e, t)
        }
    }
}

function xe(s) {
    let e, l;
    return e = new X({
        props: {
            width: "8ch",
            height: "1.3em"
        }
    }), {
        c() {
            h(e.$$.fragment)
        },
        l(t) {
            k(e.$$.fragment, t)
        },
        m(t, r) {
            b(e, t, r), l = !0
        },
        p: G,
        i(t) {
            l || (_(e.$$.fragment, t), l = !0)
        },
        o(t) {
            d(e.$$.fragment, t), l = !1
        },
        d(t) {
            v(e, t)
        }
    }
}

function et(s) {
    let e, l;
    return e = new te({
        props: {
            weight: "semibold",
            variant: "inherit",
            $$slots: {
                default: [lt]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            h(e.$$.fragment)
        },
        l(t) {
            k(e.$$.fragment, t)
        },
        m(t, r) {
            b(e, t, r), l = !0
        },
        p(t, r) {
            const n = {};
            r & 268435460 && (n.$$scope = {
                dirty: r,
                ctx: t
            }), e.$set(n)
        },
        i(t) {
            l || (_(e.$$.fragment, t), l = !0)
        },
        o(t) {
            d(e.$$.fragment, t), l = !1
        },
        d(t) {
            v(e, t)
        }
    }
}

function tt(s) {
    let e, l = [],
        t = new Map,
        r, n = z(s[15]);
    const o = a => a[22].url;
    for (let a = 0; a < n.length; a += 1) {
        let i = se(s, n, a),
            f = o(i);
        t.set(f, l[a] = ue(f, i))
    }
    return {
        c() {
            e = D("div");
            for (let a = 0; a < l.length; a += 1) l[a].c();
            this.h()
        },
        l(a) {
            e = O(a, "DIV", {
                class: !0
            });
            var i = I(e);
            for (let f = 0; f < l.length; f += 1) l[f].l(i);
            i.forEach(p), this.h()
        },
        h() {
            S(e, "class", "navigation-map")
        },
        m(a, i) {
            $(a, e, i);
            for (let f = 0; f < l.length; f += 1) l[f] && l[f].m(e, null);
            r = !0
        },
        p(a, i) {
            i & 32768 && (n = z(a[15]), P(), l = me(l, i, o, 1, a, n, t, e, _e, ue, null, se), w())
        },
        i(a) {
            if (!r) {
                for (let i = 0; i < n.length; i += 1) _(l[i]);
                r = !0
            }
        },
        o(a) {
            for (let i = 0; i < l.length; i += 1) d(l[i]);
            r = !1
        },
        d(a) {
            a && p(e);
            for (let i = 0; i < l.length; i += 1) l[i].d()
        }
    }
}

function lt(s) {
    let e;
    return {
        c() {
            e = V(s[2])
        },
        l(l) {
            e = j(l, s[2])
        },
        m(l, t) {
            $(l, e, t)
        },
        p(l, t) {
            t & 4 && q(e, l[2])
        },
        d(l) {
            l && p(e)
        }
    }
}

function rt(s) {
    let e = s[22].name + "",
        l;
    return {
        c() {
            l = V(e)
        },
        l(t) {
            l = j(t, e)
        },
        m(t, r) {
            $(t, l, r)
        },
        p(t, r) {
            r & 32768 && e !== (e = t[22].name + "") && q(l, e)
        },
        d(t) {
            t && p(l)
        }
    }
}

function fe(s) {
    let e, l, t, r;
    return l = new te({
        props: {
            weight: "semibold",
            variant: "subtle",
            $$slots: {
                default: [nt]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            e = D("span"), h(l.$$.fragment), t = C(), this.h()
        },
        l(n) {
            e = O(n, "SPAN", {
                class: !0
            });
            var o = I(e);
            k(l.$$.fragment, o), t = F(o), o.forEach(p), this.h()
        },
        h() {
            S(e, "class", "separator svelte-1u22cis")
        },
        m(n, o) {
            $(n, e, o), b(l, e, null), U(e, t), r = !0
        },
        i(n) {
            r || (_(l.$$.fragment, n), r = !0)
        },
        o(n) {
            d(l.$$.fragment, n), r = !1
        },
        d(n) {
            n && p(e), v(l)
        }
    }
}

function nt(s) {
    let e;
    return {
        c() {
            e = V("/")
        },
        l(l) {
            e = j(l, "/")
        },
        m(l, t) {
            $(l, e, t)
        },
        d(l) {
            l && p(e)
        }
    }
}

function ue(s, e) {
    let l, t, r, n, o;
    t = new de({
        props: {
            variant: "subtle-link",
            to: e[22].url,
            $$slots: {
                default: [rt]
            },
            $$scope: {
                ctx: e
            }
        }
    });
    let a = e[24] < e[15].length - 1 && fe(e);
    return {
        key: s,
        first: null,
        c() {
            l = y(), h(t.$$.fragment), r = C(), a && a.c(), n = y(), this.h()
        },
        l(i) {
            l = y(), k(t.$$.fragment, i), r = F(i), a && a.l(i), n = y(), this.h()
        },
        h() {
            this.first = l
        },
        m(i, f) {
            $(i, l, f), b(t, i, f), $(i, r, f), a && a.m(i, f), $(i, n, f), o = !0
        },
        p(i, f) {
            e = i;
            const c = {};
            f & 32768 && (c.to = e[22].url), f & 268468224 && (c.$$scope = {
                dirty: f,
                ctx: e
            }), t.$set(c), e[24] < e[15].length - 1 ? a ? f & 32768 && _(a, 1) : (a = fe(e), a.c(), _(a, 1), a.m(n.parentNode, n)) : a && (P(), d(a, 1, 1, () => {
                a = null
            }), w())
        },
        i(i) {
            o || (_(t.$$.fragment, i), _(a), o = !0)
        },
        o(i) {
            d(t.$$.fragment, i), d(a), o = !1
        },
        d(i) {
            i && (p(l), p(r), p(n)), v(t, i), a && a.d(i)
        }
    }
}

function it(s) {
    let e, l, t, r;
    const n = [tt, et, xe],
        o = [];

    function a(i, f) {
        return i[15].length >= 1 ? 0 : i[2] ? 1 : i[5] ? 2 : -1
    }
    return ~(e = a(s)) && (l = o[e] = n[e](s)), {
        c() {
            l && l.c(), t = y()
        },
        l(i) {
            l && l.l(i), t = y()
        },
        m(i, f) {
            ~e && o[e].m(i, f), $(i, t, f), r = !0
        },
        p(i, f) {
            let c = e;
            e = a(i), e === c ? ~e && o[e].p(i, f) : (l && (P(), d(o[c], 1, 1, () => {
                o[c] = null
            }), w()), ~e ? (l = o[e], l ? l.p(i, f) : (l = o[e] = n[e](i), l.c()), _(l, 1), l.m(t.parentNode, t)) : l = null)
        },
        i(i) {
            r || (_(l), r = !0)
        },
        o(i) {
            d(l), r = !1
        },
        d(i) {
            i && p(t), ~e && o[e].d(i)
        }
    }
}

function at(s) {
    let e, l;
    return e = new Te({
        props: {
            count: s[8],
            $$slots: {
                default: [it]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            h(e.$$.fragment)
        },
        l(t) {
            k(e.$$.fragment, t)
        },
        m(t, r) {
            b(e, t, r), l = !0
        },
        p(t, r) {
            const n = {};
            r & 256 && (n.count = t[8]), r & 268468260 && (n.$$scope = {
                dirty: r,
                ctx: t
            }), e.$set(n)
        },
        i(t) {
            l || (_(e.$$.fragment, t), l = !0)
        },
        o(t) {
            d(e.$$.fragment, t), l = !1
        },
        d(t) {
            v(e, t)
        }
    }
}

function st(s) {
    let e = s[17]._(s[11]) + "",
        l;
    return {
        c() {
            l = V(e)
        },
        l(t) {
            l = j(t, e)
        },
        m(t, r) {
            $(t, l, r)
        },
        p(t, r) {
            r & 133120 && e !== (e = t[17]._(t[11]) + "") && q(l, e)
        },
        d(t) {
            t && p(l)
        }
    }
}

function ot(s) {
    let e, l, t, r;
    const n = [Ve, Ie],
        o = [];

    function a(i, f) {
        return i[1].length === 0 && i[11] ? 0 : 1
    }
    return e = a(s), l = o[e] = n[e](s), {
        c() {
            l.c(), t = y()
        },
        l(i) {
            l.l(i), t = y()
        },
        m(i, f) {
            o[e].m(i, f), $(i, t, f), r = !0
        },
        p(i, [f]) {
            let c = e;
            e = a(i), e === c ? o[e].p(i, f) : (P(), d(o[c], 1, 1, () => {
                o[c] = null
            }), w(), l = o[e], l ? l.p(i, f) : (l = o[e] = n[e](i), l.c()), _(l, 1), l.m(t.parentNode, t))
        },
        i(i) {
            r || (_(l), r = !0)
        },
        o(i) {
            d(l), r = !1
        },
        d(i) {
            i && p(t), o[e].d(i)
        }
    }
}

function ft(s, e, l) {
    let t;
    const r = ["sortedTemplates", "fixtureList", "name", "outrights", "addTimeElements", "loading", "isOpenByDefault", "canLoadMore", "fixtureCount", "level", "displayBreadcrumb", "emptyMessage", "loadMoreLoading", "upcomingLink", "group", "titleNavigationMap"];
    let n = ne(e, r),
        o;
    ce(s, Ne, m => l(17, o = m));
    let {
        sortedTemplates: a = []
    } = e, {
        fixtureList: i = []
    } = e, {
        name: f = void 0
    } = e, {
        outrights: c = !1
    } = e, {
        addTimeElements: g = !1
    } = e, {
        loading: M = !1
    } = e, {
        isOpenByDefault: E = !1
    } = e, {
        canLoadMore: T = !1
    } = e, {
        fixtureCount: N = void 0
    } = e, {
        level: u = void 0
    } = e, {
        displayBreadcrumb: L = !1
    } = e, {
        emptyMessage: B = void 0
    } = e, {
        loadMoreLoading: H = !1
    } = e, {
        upcomingLink: R = void 0
    } = e, {
        group: K = void 0
    } = e, {
        titleNavigationMap: le = []
    } = e, J = ke();
    const pe = () => J("loadMore"),
        $e = m => {
            J("click", m.detail)
        };
    return s.$$set = m => {
        e = Q(Q({}, e), be(m)), l(19, n = ne(e, r)), "sortedTemplates" in m && l(0, a = m.sortedTemplates), "fixtureList" in m && l(1, i = m.fixtureList), "name" in m && l(2, f = m.name), "outrights" in m && l(3, c = m.outrights), "addTimeElements" in m && l(4, g = m.addTimeElements), "loading" in m && l(5, M = m.loading), "isOpenByDefault" in m && l(6, E = m.isOpenByDefault), "canLoadMore" in m && l(7, T = m.canLoadMore), "fixtureCount" in m && l(8, N = m.fixtureCount), "level" in m && l(9, u = m.level), "displayBreadcrumb" in m && l(10, L = m.displayBreadcrumb), "emptyMessage" in m && l(11, B = m.emptyMessage), "loadMoreLoading" in m && l(12, H = m.loadMoreLoading), "upcomingLink" in m && l(13, R = m.upcomingLink), "group" in m && l(14, K = m.group), "titleNavigationMap" in m && l(15, le = m.titleNavigationMap)
    }, s.$$.update = () => {
        s.$$.dirty & 16394 && l(16, t = i.length > 0 && K && !c && De.includes(K))
    }, [a, i, f, c, g, M, E, T, N, u, L, B, H, R, K, le, t, o, J, n, pe, $e]
}
class Et extends Z {
    constructor(e) {
        super(), x(this, e, ft, ot, Y, {
            sortedTemplates: 0,
            fixtureList: 1,
            name: 2,
            outrights: 3,
            addTimeElements: 4,
            loading: 5,
            isOpenByDefault: 6,
            canLoadMore: 7,
            fixtureCount: 8,
            level: 9,
            displayBreadcrumb: 10,
            emptyMessage: 11,
            loadMoreLoading: 12,
            upcomingLink: 13,
            group: 14,
            titleNavigationMap: 15
        })
    }
}
export {
    Et as F
};