import {
    s as u,
    t as g,
    h as c,
    j as h,
    l as v,
    i as _
} from "./scheduler.DXu26z7T.js";
import {
    S,
    i as d,
    c as w,
    a as b,
    m as z,
    t as H,
    b as T,
    d as F
} from "./index.Dz_MmNB3.js";
import {
    F as N
} from "./index.CIBDG73T.js";
import {
    g as m
} from "./helpers.CobRd3cj.js";

function O(a) {
    let t = m(a[0]) + "",
        i;
    return {
        c() {
            i = g(t)
        },
        l(e) {
            i = c(e, t)
        },
        m(e, n) {
            h(e, i, n)
        },
        p(e, n) {
            n & 1 && t !== (t = m(e[0]) + "") && v(i, t)
        },
        d(e) {
            e && _(i)
        }
    }
}

function j(a) {
    let t, i;
    return t = new N({
        props: {
            value: a[0],
            variant: a[1],
            size: a[2],
            lineHeight: a[4],
            responsiveTypeScale: a[3],
            weight: a[5],
            $$slots: {
                default: [O]
            },
            $$scope: {
                ctx: a
            }
        }
    }), {
        c() {
            w(t.$$.fragment)
        },
        l(e) {
            b(t.$$.fragment, e)
        },
        m(e, n) {
            z(t, e, n), i = !0
        },
        p(e, [n]) {
            const l = {};
            n & 1 && (l.value = e[0]), n & 2 && (l.variant = e[1]), n & 4 && (l.size = e[2]), n & 16 && (l.lineHeight = e[4]), n & 8 && (l.responsiveTypeScale = e[3]), n & 32 && (l.weight = e[5]), n & 65 && (l.$$scope = {
                dirty: n,
                ctx: e
            }), t.$set(l)
        },
        i(e) {
            i || (H(t.$$.fragment, e), i = !0)
        },
        o(e) {
            T(t.$$.fragment, e), i = !1
        },
        d(e) {
            F(t, e)
        }
    }
}

function q(a, t, i) {
    let {
        value: e
    } = t, {
        variant: n = void 0
    } = t, {
        size: l = void 0
    } = t, {
        responsiveTypeScale: r = !1
    } = t, {
        lineHeight: f = r ? "responsive" : "default"
    } = t, {
        weight: o = "normal"
    } = t;
    return a.$$set = s => {
        "value" in s && i(0, e = s.value), "variant" in s && i(1, n = s.variant), "size" in s && i(2, l = s.size), "responsiveTypeScale" in s && i(3, r = s.responsiveTypeScale), "lineHeight" in s && i(4, f = s.lineHeight), "weight" in s && i(5, o = s.weight)
    }, [e, n, l, r, f, o]
}
class A extends S {
    constructor(t) {
        super(), d(this, t, q, j, u, {
            value: 0,
            variant: 1,
            size: 2,
            responsiveTypeScale: 3,
            lineHeight: 4,
            weight: 5
        })
    }
}
export {
    A as F
};