import {
    s as j,
    e as G,
    O as A,
    d as y,
    f as S,
    P as F,
    i as b,
    F as M,
    I as w,
    j as C,
    k as B,
    a3 as N,
    q as W,
    c as H,
    t as J,
    h as Q,
    l as U,
    m as q
} from "./scheduler.DXu26z7T.js";
import {
    S as X,
    i as Y,
    t as k,
    g as z,
    b as v,
    e as O,
    c as D,
    a as K,
    m as T,
    d as V
} from "./index.Dz_MmNB3.js";
import {
    e as E,
    u as Z,
    o as R
} from "./each.DvgCmocI.js";
import {
    G as $
} from "./index.DVWgQdxd.js";
import {
    C as x
} from "./index.D-7TT9-T.js";
import {
    g as ee
} from "./context.UnLgwODO.js";
import {
    g as te
} from "./helpers.DrdznBvg.js";
import {
    r as ae
} from "./resizeObserver.A9wvMie0.js";

function I(r, e, s) {
    const i = r.slice();
    return i[13] = e[s], i
}

function L(r) {
    var i, n;
    let e, s;
    return e = new x({
        props: {
            icon: (i = r[0]) == null ? void 0 : i.icon,
            to: "/casino/group/" + ((n = r[0]) == null ? void 0 : n.slug),
            loading: r[1],
            $$slots: {
                default: [se]
            },
            $$scope: {
                ctx: r
            }
        }
    }), {
        c() {
            D(e.$$.fragment)
        },
        l(o) {
            K(e.$$.fragment, o)
        },
        m(o, f) {
            T(e, o, f), s = !0
        },
        p(o, f) {
            var p, c;
            const m = {};
            f & 1 && (m.icon = (p = o[0]) == null ? void 0 : p.icon), f & 1 && (m.to = "/casino/group/" + ((c = o[0]) == null ? void 0 : c.slug)), f & 2 && (m.loading = o[1]), f & 65537 && (m.$$scope = {
                dirty: f,
                ctx: o
            }), e.$set(m)
        },
        i(o) {
            s || (k(e.$$.fragment, o), s = !0)
        },
        o(o) {
            v(e.$$.fragment, o), s = !1
        },
        d(o) {
            V(e, o)
        }
    }
}

function se(r) {
    var n;
    let e, s = ((n = r[0]) == null ? void 0 : n.translation) + "",
        i;
    return {
        c() {
            e = G("span"), i = J(s)
        },
        l(o) {
            e = y(o, "SPAN", {});
            var f = S(e);
            i = Q(f, s), f.forEach(b)
        },
        m(o, f) {
            C(o, e, f), B(e, i)
        },
        p(o, f) {
            var m;
            f & 1 && s !== (s = ((m = o[0]) == null ? void 0 : m.translation) + "") && U(i, s)
        },
        d(o) {
            o && b(e)
        }
    }
}

function P(r, e) {
    var o, f, m, p, c;
    let s, i, n;
    return i = new $({
        props: {
            width: e[6],
            loading: e[1],
            card: e[13].game || e[13],
            groupGames: ((o = e[13].game) == null ? void 0 : o.groupGames) || ((f = e[13]) == null ? void 0 : f.groupGames) || [],
            isMobile: e[8],
            isBlocked: ((p = (m = e[13]) == null ? void 0 : m.game) == null ? void 0 : p.isBlocked) || ((c = e[13]) == null ? void 0 : c.isBlocked)
        }
    }), {
        key: r,
        first: null,
        c() {
            s = q(), D(i.$$.fragment), this.h()
        },
        l(a) {
            s = q(), K(i.$$.fragment, a), this.h()
        },
        h() {
            this.first = s
        },
        m(a, g) {
            C(a, s, g), T(i, a, g), n = !0
        },
        p(a, g) {
            var _, t, l, u, h;
            e = a;
            const d = {};
            g & 64 && (d.width = e[6]), g & 2 && (d.loading = e[1]), g & 4 && (d.card = e[13].game || e[13]), g & 4 && (d.groupGames = ((_ = e[13].game) == null ? void 0 : _.groupGames) || ((t = e[13]) == null ? void 0 : t.groupGames) || []), g & 256 && (d.isMobile = e[8]), g & 4 && (d.isBlocked = ((u = (l = e[13]) == null ? void 0 : l.game) == null ? void 0 : u.isBlocked) || ((h = e[13]) == null ? void 0 : h.isBlocked)), i.$set(d)
        },
        i(a) {
            n || (k(i.$$.fragment, a), n = !0)
        },
        o(a) {
            v(i.$$.fragment, a), n = !1
        },
        d(a) {
            a && b(s), V(i, a)
        }
    }
}

function ie(r) {
    var _;
    let e, s, i, n = [],
        o = new Map,
        f, m, p, c, a = r[0] && ((_ = r[2]) == null ? void 0 : _.length) && L(r),
        g = E(r[2]);
    const d = t => t[13].id;
    for (let t = 0; t < g.length; t += 1) {
        let l = I(r, g, t),
            u = d(l);
        o.set(u, n[t] = P(u, l))
    }
    return {
        c() {
            e = G("div"), a && a.c(), s = A(), i = G("div");
            for (let t = 0; t < n.length; t += 1) n[t].c();
            this.h()
        },
        l(t) {
            e = y(t, "DIV", {
                class: !0
            });
            var l = S(e);
            a && a.l(l), s = F(l), i = y(l, "DIV", {
                class: !0,
                style: !0
            });
            var u = S(i);
            for (let h = 0; h < n.length; h += 1) n[h].l(u);
            u.forEach(b), l.forEach(b), this.h()
        },
        h() {
            M(i, "class", "card-list svelte-1sqfm40"), w(i, "grid-template-columns", "repeat(" + r[5] + ",1fr)"), w(i, "grid-gap", r[7] + "px " + r[4] + "px"), M(e, "class", "wrapper svelte-1sqfm40")
        },
        m(t, l) {
            C(t, e, l), a && a.m(e, null), B(e, s), B(e, i);
            for (let u = 0; u < n.length; u += 1) n[u] && n[u].m(i, null);
            m = !0, p || (c = N(f = ae.call(null, e, r[12])), p = !0)
        },
        p(t, [l]) {
            var u;
            t[0] && ((u = t[2]) != null && u.length) ? a ? (a.p(t, l), l & 5 && k(a, 1)) : (a = L(t), a.c(), k(a, 1), a.m(e, s)) : a && (z(), v(a, 1, 1, () => {
                a = null
            }), O()), l & 326 && (g = E(t[2]), z(), n = Z(n, l, d, 1, t, g, o, i, R, P, null, I), O()), (!m || l & 32) && w(i, "grid-template-columns", "repeat(" + t[5] + ",1fr)"), (!m || l & 144) && w(i, "grid-gap", t[7] + "px " + t[4] + "px"), f && W(f.update) && l & 8 && f.update.call(null, t[12])
        },
        i(t) {
            if (!m) {
                k(a);
                for (let l = 0; l < g.length; l += 1) k(n[l]);
                m = !0
            }
        },
        o(t) {
            v(a);
            for (let l = 0; l < n.length; l += 1) v(n[l]);
            m = !1
        },
        d(t) {
            t && b(e), a && a.d();
            for (let l = 0; l < n.length; l += 1) n[l].d();
            p = !1, c()
        }
    }
}

function le(r, e, s) {
    let i, n, o, f, m, p, c, {
            group: a = void 0
        } = e,
        {
            loading: g = void 0
        } = e,
        {
            list: d = []
        } = e;
    const _ = ee();
    H(r, _, u => s(11, c = u));
    let t;
    const l = u => s(3, t = u);
    return r.$$set = u => {
        "group" in u && s(0, a = u.group), "loading" in u && s(1, g = u.loading), "list" in u && s(2, d = u.list)
    }, r.$$.update = () => {
        r.$$.dirty & 2048 && s(8, i = c && c < 700), r.$$.dirty & 8 && s(10, n = te(t == null ? void 0 : t.width)), r.$$.dirty & 1024 && s(5, o = Math.ceil(n.slidesToShow)), r.$$.dirty & 1024 && s(4, f = n.gap), r.$$.dirty & 16 && s(7, m = f * 2), r.$$.dirty & 56 && s(6, p = (t == null ? void 0 : t.width) / o - f)
    }, [a, g, d, t, f, o, p, m, i, _, n, c, l]
}
class de extends X {
    constructor(e) {
        super(), Y(this, e, le, ie, j, {
            group: 0,
            loading: 1,
            list: 2
        })
    }
}
export {
    de as K
};