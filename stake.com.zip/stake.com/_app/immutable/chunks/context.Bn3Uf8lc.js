import {
    x as n,
    v as a
} from "./scheduler.DXu26z7T.js";
const e = "@@game",
    s = () => n(e),
    c = t => a(e, t),
    o = {
        game: "expanded"
    },
    g = () => {
        const t = s();
        return o[t] || "expanded"
    };
export {
    g,
    c as s
};