import {
    s as h,
    C as f,
    H as u,
    D as m,
    f as v,
    E as _,
    i as c,
    F as r,
    j as g,
    n as o
} from "./scheduler.DXu26z7T.js";
import {
    S as y,
    i as d
} from "./index.Dz_MmNB3.js";

function w(n) {
    let t, l, a = ` <title>${n[1]||""}</title> <path d="M32.271 49.763 9.201 26.692l6.928-6.93 16.145 16.145 16.144-16.144 6.93 6.929-23.072 23.07h-.005Z"></path>`,
        i;
    return {
        c() {
            t = f("svg"), l = new u(!0), this.h()
        },
        l(s) {
            t = m(s, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var e = v(t);
            l = _(e, !0), e.forEach(c), this.h()
        },
        h() {
            l.a = null, r(t, "fill", "currentColor"), r(t, "viewBox", "0 0 64 64"), r(t, "class", i = "svg-icon " + n[2]), r(t, "style", n[0])
        },
        m(s, e) {
            g(s, t, e), l.m(a, t)
        },
        p(s, [e]) {
            e & 2 && a !== (a = ` <title>${s[1]||""}</title> <path d="M32.271 49.763 9.201 26.692l6.928-6.93 16.145 16.145 16.144-16.144 6.93 6.929-23.072 23.07h-.005Z"></path>`) && l.p(a), e & 4 && i !== (i = "svg-icon " + s[2]) && r(t, "class", i), e & 1 && r(t, "style", s[0])
        },
        i: o,
        o,
        d(s) {
            s && c(t)
        }
    }
}

function C(n, t, l) {
    let {
        style: a = ""
    } = t, {
        alt: i = ""
    } = t, {
        class: s = ""
    } = t;
    return n.$$set = e => {
        "style" in e && l(0, a = e.style), "alt" in e && l(1, i = e.alt), "class" in e && l(2, s = e.class)
    }, [a, i, s]
}
class D extends y {
    constructor(t) {
        super(), d(this, t, C, w, h, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    D as C
};