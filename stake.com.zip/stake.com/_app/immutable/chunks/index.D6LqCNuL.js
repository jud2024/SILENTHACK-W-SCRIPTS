import {
    s as M,
    e as y,
    d as w,
    f as p,
    i as f,
    F as m,
    V as v,
    j as z
} from "./scheduler.DXu26z7T.js";
import {
    S as U,
    i as k,
    c as u,
    a as c,
    m as g,
    t as h,
    b as d,
    d as _
} from "./index.Dz_MmNB3.js";
import {
    g as G
} from "./generatePath.DsXei5FM.js";
import {
    p as P
} from "./paths.RTtAVJV7.js";
import {
    L as S
} from "./index.DJurAkTj.js";
import {
    I as V
} from "./index.BmTk3-ns.js";
import {
    C as q
} from "./index.kKx-JfF0.js";

function D(i) {
    let e, s, a, n;
    return s = new V({
        props: {
            src: i[1],
            width: 200,
            imgixParams: {
                q: 50
            },
            alt: i[0],
            draggable: !1
        }
    }), {
        c() {
            e = y("div"), u(s.$$.fragment), this.h()
        },
        l(t) {
            e = w(t, "DIV", {
                class: !0
            });
            var l = p(e);
            c(s.$$.fragment, l), l.forEach(f), this.h()
        },
        h() {
            m(e, "class", a = "img-wrap " + i[6][i[2]] + " svelte-1xdyar1")
        },
        m(t, l) {
            z(t, e, l), g(s, e, null), n = !0
        },
        p(t, l) {
            const o = {};
            l & 2 && (o.src = t[1]), l & 1 && (o.alt = t[0]), s.$set(o), (!n || l & 4 && a !== (a = "img-wrap " + t[6][t[2]] + " svelte-1xdyar1")) && m(e, "class", a)
        },
        i(t) {
            n || (h(s.$$.fragment, t), n = !0)
        },
        o(t) {
            d(s.$$.fragment, t), n = !1
        },
        d(t) {
            t && f(e), _(s)
        }
    }
}

function E(i) {
    let e, s, a;
    return s = new S({
        props: {
            prefetch: "tap",
            to: i[5],
            $$slots: {
                default: [D]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            e = y("div"), u(s.$$.fragment), this.h()
        },
        l(n) {
            e = w(n, "DIV", {
                class: !0,
                style: !0
            });
            var t = p(e);
            c(s.$$.fragment, t), t.forEach(f), this.h()
        },
        h() {
            m(e, "class", "wrap svelte-1xdyar1"), m(e, "style", i[3]), v(e, "is-mobile", i[4])
        },
        m(n, t) {
            z(n, e, t), g(s, e, null), a = !0
        },
        p(n, t) {
            const l = {};
            t & 263 && (l.$$scope = {
                dirty: t,
                ctx: n
            }), s.$set(l), (!a || t & 8) && m(e, "style", n[3]), (!a || t & 16) && v(e, "is-mobile", n[4])
        },
        i(n) {
            a || (h(s.$$.fragment, n), a = !0)
        },
        o(n) {
            d(s.$$.fragment, n), a = !1
        },
        d(n) {
            n && f(e), _(s)
        }
    }
}

function F(i) {
    let e, s;
    return e = new q({
        props: {
            $$slots: {
                default: [E]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            u(e.$$.fragment)
        },
        l(a) {
            c(e.$$.fragment, a)
        },
        m(a, n) {
            g(e, a, n), s = !0
        },
        p(a, [n]) {
            const t = {};
            n & 287 && (t.$$scope = {
                dirty: n,
                ctx: a
            }), e.$set(t)
        },
        i(a) {
            s || (h(e.$$.fragment, a), s = !0)
        },
        o(a) {
            d(e.$$.fragment, a), s = !1
        },
        d(a) {
            _(e, a)
        }
    }
}

function L(i, e, s) {
    let {
        slug: a = void 0
    } = e, {
        name: n = void 0
    } = e, {
        thumbnailUrl: t
    } = e, {
        size: l = "1/1"
    } = e, {
        style: o = void 0
    } = e, {
        isMobile: b = !1
    } = e;
    const C = a && G(P.casinoGroup, {
            groupSlug: a
        }) || "",
        I = {
            "5/2": "five-by-two",
            "1/1": "one-by-one",
            "27/17": "twenty-seven-by-seventeen"
        };
    return i.$$set = r => {
        "slug" in r && s(7, a = r.slug), "name" in r && s(0, n = r.name), "thumbnailUrl" in r && s(1, t = r.thumbnailUrl), "size" in r && s(2, l = r.size), "style" in r && s(3, o = r.style), "isMobile" in r && s(4, b = r.isMobile)
    }, [n, t, l, o, b, C, I, a]
}
class O extends U {
    constructor(e) {
        super(), k(this, e, L, F, M, {
            slug: 7,
            name: 0,
            thumbnailUrl: 1,
            size: 2,
            style: 3,
            isMobile: 4
        })
    }
}
export {
    O as G
};