import {
    s as r,
    C as u,
    H as f,
    D as m,
    f as o,
    E as g,
    i as c,
    F as n,
    j as _,
    n as v
} from "./scheduler.DXu26z7T.js";
import {
    S as Z,
    i as H
} from "./index.Dz_MmNB3.js";

function y(i) {
    let t, s, a = ` <title>${i[1]||""}</title> <path d="M54.727 15.006h3.12V8.37H34.654V2.61H27.99v5.758H4.746v6.637h4.505L0 37.452c0 7.037 5.704 12.741 12.741 12.741 7.038 0 12.741-5.704 12.741-12.741l-9.25-22.446h11.73v39.745h-9.303v6.638h25.165V54.75h-9.171V15.006h13.115l-9.25 22.446c0 7.037 5.703 12.741 12.74 12.741C58.297 50.193 64 44.489 64 37.452l-9.273-22.446ZM5.334 37.452l7.411-17.887 7.357 17.887H5.334Zm38.492 0 7.357-17.887 7.463 17.887h-14.82Z"></path>`,
        h;
    return {
        c() {
            t = u("svg"), s = new f(!0), this.h()
        },
        l(e) {
            t = m(e, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var l = o(t);
            s = g(l, !0), l.forEach(c), this.h()
        },
        h() {
            s.a = null, n(t, "fill", "currentColor"), n(t, "viewBox", "0 0 64 64"), n(t, "class", h = "svg-icon " + i[2]), n(t, "style", i[0])
        },
        m(e, l) {
            _(e, t, l), s.m(a, t)
        },
        p(e, [l]) {
            l & 2 && a !== (a = ` <title>${e[1]||""}</title> <path d="M54.727 15.006h3.12V8.37H34.654V2.61H27.99v5.758H4.746v6.637h4.505L0 37.452c0 7.037 5.704 12.741 12.741 12.741 7.038 0 12.741-5.704 12.741-12.741l-9.25-22.446h11.73v39.745h-9.303v6.638h25.165V54.75h-9.171V15.006h13.115l-9.25 22.446c0 7.037 5.703 12.741 12.74 12.741C58.297 50.193 64 44.489 64 37.452l-9.273-22.446ZM5.334 37.452l7.411-17.887 7.357 17.887H5.334Zm38.492 0 7.357-17.887 7.463 17.887h-14.82Z"></path>`) && s.p(a), l & 4 && h !== (h = "svg-icon " + e[2]) && n(t, "class", h), l & 1 && n(t, "style", e[0])
        },
        i: v,
        o: v,
        d(e) {
            e && c(t)
        }
    }
}

function V(i, t, s) {
    let {
        style: a = ""
    } = t, {
        alt: h = ""
    } = t, {
        class: e = ""
    } = t;
    return i.$$set = l => {
        "style" in l && s(0, a = l.style), "alt" in l && s(1, h = l.alt), "class" in l && s(2, e = l.class)
    }, [a, h, e]
}
class C extends Z {
    constructor(t) {
        super(), H(this, t, V, y, r, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}

function w(i) {
    let t, s, a = ` <title>${i[1]||""}</title> <path d="M59.732 0H4.266A4.266 4.266 0 0 0 0 4.266V60c0 2.21 1.79 4 4 4h56c2.21 0 4-1.79 4-4V4.266A4.266 4.266 0 0 0 59.734 0h-.002ZM17.998 50.24l-8-8 4.266-4.266 3.866 3.894 9.734-9.866 4.266 4.266L17.998 50.24Zm0-20-8-8 4.134-4.374 3.866 3.894 9.866-9.894 4.266 4.266L17.998 30.24Zm36 14.774h-14v-6.026h14v6.026Zm0-20h-14v-6.026h14v6.026Z"></path>`,
        h;
    return {
        c() {
            t = u("svg"), s = new f(!0), this.h()
        },
        l(e) {
            t = m(e, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var l = o(t);
            s = g(l, !0), l.forEach(c), this.h()
        },
        h() {
            s.a = null, n(t, "fill", "currentColor"), n(t, "viewBox", "0 0 64 64"), n(t, "class", h = "svg-icon " + i[2]), n(t, "style", i[0])
        },
        m(e, l) {
            _(e, t, l), s.m(a, t)
        },
        p(e, [l]) {
            l & 2 && a !== (a = ` <title>${e[1]||""}</title> <path d="M59.732 0H4.266A4.266 4.266 0 0 0 0 4.266V60c0 2.21 1.79 4 4 4h56c2.21 0 4-1.79 4-4V4.266A4.266 4.266 0 0 0 59.734 0h-.002ZM17.998 50.24l-8-8 4.266-4.266 3.866 3.894 9.734-9.866 4.266 4.266L17.998 50.24Zm0-20-8-8 4.134-4.374 3.866 3.894 9.866-9.894 4.266 4.266L17.998 30.24Zm36 14.774h-14v-6.026h14v6.026Zm0-20h-14v-6.026h14v6.026Z"></path>`) && s.p(a), l & 4 && h !== (h = "svg-icon " + e[2]) && n(t, "class", h), l & 1 && n(t, "style", e[0])
        },
        i: v,
        o: v,
        d(e) {
            e && c(t)
        }
    }
}

function L(i, t, s) {
    let {
        style: a = ""
    } = t, {
        alt: h = ""
    } = t, {
        class: e = ""
    } = t;
    return i.$$set = l => {
        "style" in l && s(0, a = l.style), "alt" in l && s(1, h = l.alt), "class" in l && s(2, e = l.class)
    }, [a, h, e]
}
class A extends Z {
    constructor(t) {
        super(), H(this, t, L, w, r, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    C as F, A as L
};