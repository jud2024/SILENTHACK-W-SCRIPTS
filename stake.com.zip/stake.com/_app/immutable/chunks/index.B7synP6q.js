const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["_app/immutable/chunks/index.C6oSeDGg.js", "_app/immutable/chunks/scheduler.DXu26z7T.js", "_app/immutable/chunks/index.Dz_MmNB3.js", "_app/immutable/chunks/index.D7QUfg7j.js", "_app/immutable/assets/index.C3HhUlCF.css", "_app/immutable/assets/index.rPa838Tf.css", "_app/immutable/chunks/index.D6_BTN2S.js", "_app/immutable/assets/index.PdIcYc3p.css"]))) => i.map(i => d[i]);
import {
    s as Y,
    C as nl,
    H as tl,
    D as il,
    f as B,
    E as ll,
    i as f,
    F as H,
    j as k,
    n as A,
    m as h,
    c as j,
    e as T,
    d as I,
    a1 as te,
    t as P,
    h as D,
    l as O,
    k as z,
    O as V,
    P as M,
    I as be,
    U as an,
    a as pe,
    K as ae,
    Q as we,
    u as ge,
    g as $e,
    b as ve,
    L as Ce,
    X as ri,
    o as He,
    M as Ge,
    J as Je,
    a6 as oi,
    T as al,
    V as re,
    W as Ee,
    r as si,
    R as _e,
    N as ui,
    a3 as ci,
    q as rl
} from "./scheduler.DXu26z7T.js";
import {
    S as q,
    i as K,
    t as d,
    g as y,
    b as m,
    e as w,
    c as g,
    a as N,
    m as $,
    d as v,
    f as di,
    k as ol
} from "./index.Dz_MmNB3.js";
import {
    T as le
} from "./index.D7nbRHfU.js";
import {
    i as x,
    h as p,
    dc as kn,
    H as rn,
    R as sl,
    b9 as ul,
    aq as _n,
    r as Ae,
    ac as on,
    dd as Ze,
    aQ as cl,
    aF as dl,
    a0 as ml,
    f as fl,
    p as kl,
    cm as _l,
    X as pn
} from "./index.B4-7gKq3.js";
import {
    f as pl
} from "./fiatNumberFormat.CcHMsn0U.js";
import {
    S as Pe
} from "./index.DChG_RHX.js";
import {
    I as Re
} from "./index.D7QUfg7j.js";
import {
    L as mi
} from "./index.BiZyFJca.js";
import {
    g as je
} from "./generatePath.DsXei5FM.js";
import {
    p as ke
} from "./paths.RTtAVJV7.js";
import {
    _ as gn
} from "./preload-helper.BqjOJQfC.js";
import {
    h as $n
} from "./await_block.D0Ps1QAT.js";
import {
    L as gl
} from "./index.CrLalDOl.js";
import {
    M as fi
} from "./index.CVJ30NdW.js";
import {
    C as $l
} from "./index.DQKPSbi-.js";
import {
    L as Fe
} from "./index.DJurAkTj.js";
import {
    V as Te,
    k as vl,
    d as ki,
    a as Nl,
    p as hl
} from "./index.B81orGJm.js";
import "./index.ByMdEFI5.js";
import "./index.B3dW9TVs.js";
import {
    C as Sl
} from "./index.DnZItWfM.js";
import {
    B as bl,
    o as Fl
} from "./index.BAVnyi_8.js";
import {
    S as yl
} from "./index.CWC-_s_7.js";
import {
    D as _i,
    a as pi,
    b as gi
} from "./DropdownContent.DaecMGoH.js";
import {
    H as wl
} from "./index.u8ZD9oiA.js";
import {
    n as sn,
    g as ze,
    s as vn,
    a as Cl
} from "./index.1CTKaDY2.js";
import {
    R as Al,
    m as me,
    N as $i,
    V as Tl,
    L as Il
} from "./utils.92_vUFxq.js";
import {
    B as se
} from "./button.BwmFDw8u.js";
import {
    C as Bl
} from "./Cross.DFKMr_Np.js";
import {
    g as de,
    a as fe
} from "./spread.CgU5AtxT.js";
import {
    M as El
} from "./Mail.DzYKlkWd.js";
import {
    e as Z,
    u as Pl,
    o as Dl
} from "./each.DvgCmocI.js";
import {
    C as ie
} from "./index.CAbJJJ2j.js";
import {
    W as oe
} from "./Wallet.B4hgSvlS.js";
import {
    t as Rl
} from "./index.Cq_eNUyU.js";
import {
    C as Vl
} from "./index.D8v0bbn8.js";
import {
    S as Ml
} from "./SportsArchery.xCgY6FbW.js";
import {
    g as Ol
} from "./helpers.CobRd3cj.js";
import {
    T as vi
} from "./Trophy4.CNL_sHmf.js";
import {
    M as Ni
} from "./MicrophoneOff.BHVz4t8f.js";
import {
    F as hi
} from "./index.DUHuGv4r.js";
import {
    U as Si
} from "./UserFromName.BJUA46NY.js";
import {
    A as Ye
} from "./Account.Dy1oZprP.js";
import {
    g as Ll,
    c as Ul
} from "./vip.rsPZMLqI.js";
import {
    s as Wl,
    r as zl,
    q as Gl,
    p as jl,
    o as Hl,
    n as Yl,
    m as ql,
    l as Kl,
    k as Zl,
    j as Xl,
    i as Ql,
    h as Jl,
    g as xl,
    f as ea,
    e as na,
    d as ta,
    c as ia,
    b as la,
    a as aa,
    V as ra
} from "./VIPSilver.CnTTpkRN.js";
import {
    g as oa
} from "./fixture.DfNw968C.js";
import {
    g as sa
} from "./index.CFqKvIvj.js";
import {
    a as bi,
    s as ua,
    b as ca
} from "./index.Bhhzp5qA.js";
import {
    E as Fi
} from "./index.CJLuklPK.js";
import {
    h as xe
} from "./index.DGKYLdH2.js";
import {
    a as da
} from "./index.Drh4nwD9.js";
import {
    B as yi
} from "./index.zmvGeK6M.js";
import {
    P as ye
} from "./index.B1KDSkU5.js";
import {
    c as ma
} from "./clickOutside.B3QPj_Ml.js";
import {
    a as qe,
    l as fa,
    m as ka
} from "./index.CY6-K88d.js";
import {
    z as en
} from "./variables.CIGccMR5.js";
import {
    g as _a
} from "./index.Ci34scWy.js";
import {
    r as pa
} from "./resizeObserver.A9wvMie0.js";
import {
    f as ga
} from "./index.Nhx66bSE.js";
import {
    s as $a,
    g as va
} from "./stores.C1s9-Gyh.js";
import {
    t as Na
} from "./helpers.B45fO6x6.js";
import {
    S as wi
} from "./constants.CW0Xv01T.js";
import {
    S as ha
} from "./Search.Dsf-x3-k.js";
import {
    C as Ci
} from "./Chat.DCseWHnE.js";
import {
    A as Sa
} from "./Affiliate.6_vwcHfp.js";
import {
    G as ba
} from "./Graph.5H4YYOLp.js";
import {
    L as Fa
} from "./List.DAtnvj0J.js";
import {
    B as Ai
} from "./Betslip.C7x1Ve5J.js";
import {
    S as ya
} from "./Settings.B9OSzQXJ.js";
import {
    S as wa
} from "./Security.BSO6XeQU.js";
import {
    S as Ca
} from "./Support.CEAFJiR2.js";

function Aa(o) {
    let e, i, n = ` <title>${o[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M2.998.025h38.97a2.998 2.998 0 0 1 2.997 2.998v32.974a2.998 2.998 0 0 1-2.998 2.998H20.484L3.997 49.986V38.995h-1A2.998 2.998 0 0 1 0 35.997V3.023A2.998 2.998 0 0 1 2.998.025ZM51.96 8.02h8.993A2.998 2.998 0 0 1 64 11.017v52.958h-4.996a5.885 5.885 0 0 0-5.535-4.996 5.886 5.886 0 0 0-5.506 4.996h-7.994a5.886 5.886 0 0 0-5.485-4.996 5.896 5.896 0 0 0-5.506 4.996h-4.996V45.99h20.254a7.724 7.724 0 0 0 7.724-7.723V8.019Z"></path>`,
        t;
    return {
        c() {
            e = nl("svg"), i = new tl(!0), this.h()
        },
        l(r) {
            e = il(r, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var a = B(e);
            i = ll(a, !0), a.forEach(f), this.h()
        },
        h() {
            i.a = null, H(e, "fill", "currentColor"), H(e, "viewBox", "0 0 64 64"), H(e, "class", t = "svg-icon " + o[2]), H(e, "style", o[0])
        },
        m(r, a) {
            k(r, e, a), i.m(n, e)
        },
        p(r, [a]) {
            a & 2 && n !== (n = ` <title>${r[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M2.998.025h38.97a2.998 2.998 0 0 1 2.997 2.998v32.974a2.998 2.998 0 0 1-2.998 2.998H20.484L3.997 49.986V38.995h-1A2.998 2.998 0 0 1 0 35.997V3.023A2.998 2.998 0 0 1 2.998.025ZM51.96 8.02h8.993A2.998 2.998 0 0 1 64 11.017v52.958h-4.996a5.885 5.885 0 0 0-5.535-4.996 5.886 5.886 0 0 0-5.506 4.996h-7.994a5.886 5.886 0 0 0-5.485-4.996 5.896 5.896 0 0 0-5.506 4.996h-4.996V45.99h20.254a7.724 7.724 0 0 0 7.724-7.723V8.019Z"></path>`) && i.p(n), a & 4 && t !== (t = "svg-icon " + r[2]) && H(e, "class", t), a & 1 && H(e, "style", r[0])
        },
        i: A,
        o: A,
        d(r) {
            r && f(e)
        }
    }
}

function Ta(o, e, i) {
    let {
        style: n = ""
    } = e, {
        alt: t = ""
    } = e, {
        class: r = ""
    } = e;
    return o.$$set = a => {
        "style" in a && i(0, n = a.style), "alt" in a && i(1, t = a.alt), "class" in a && i(2, r = a.class)
    }, [n, t, r]
}
class Ia extends q {
    constructor(e) {
        super(), K(this, e, Ta, Aa, Y, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
const Ba = {
    content: {
        id: "You received {amount} from {name}!"
    }
};

function Nn(o, e, i) {
    const n = o.slice();
    return n[5] = e[i], n
}

function hn(o) {
    let e, i, n = Z(o[3]),
        t = [];
    for (let a = 0; a < n.length; a += 1) t[a] = Sn(Nn(o, n, a));
    const r = a => m(t[a], 1, 1, () => {
        t[a] = null
    });
    return {
        c() {
            e = T("span");
            for (let a = 0; a < t.length; a += 1) t[a].c()
        },
        l(a) {
            e = I(a, "SPAN", {});
            var s = B(e);
            for (let l = 0; l < t.length; l += 1) t[l].l(s);
            s.forEach(f)
        },
        m(a, s) {
            k(a, e, s);
            for (let l = 0; l < t.length; l += 1) t[l] && t[l].m(e, null);
            i = !0
        },
        p(a, s) {
            if (s & 15) {
                n = Z(a[3]);
                let l;
                for (l = 0; l < n.length; l += 1) {
                    const u = Nn(a, n, l);
                    t[l] ? (t[l].p(u, s), d(t[l], 1)) : (t[l] = Sn(u), t[l].c(), d(t[l], 1), t[l].m(e, null))
                }
                for (y(), l = n.length; l < t.length; l += 1) r(l);
                w()
            }
        },
        i(a) {
            if (!i) {
                for (let s = 0; s < n.length; s += 1) d(t[s]);
                i = !0
            }
        },
        o(a) {
            t = t.filter(Boolean);
            for (let s = 0; s < t.length; s += 1) m(t[s]);
            i = !1
        },
        d(a) {
            a && f(e), te(t, a)
        }
    }
}

function Ea(o) {
    let e, i;
    return e = new Si({
        props: {
            name: o[0]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 1 && (r.name = n[0]), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Pa(o) {
    let e, i;
    return e = new ie({
        props: {
            value: o[1],
            currency: o[2]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 2 && (r.value = n[1]), t & 4 && (r.currency = n[2]), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Da(o) {
    let e = o[5] + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 8 && e !== (e = n[5] + "") && O(i, e)
        },
        i: A,
        o: A,
        d(n) {
            n && f(i)
        }
    }
}

function Sn(o) {
    let e, i, n, t;
    const r = [Da, Pa, Ea],
        a = [];

    function s(l, u) {
        return typeof l[5] == "string" ? 0 : l[5][0] === "amount" ? 1 : l[5][0] === "name" ? 2 : -1
    }
    return ~(e = s(o)) && (i = a[e] = r[e](o)), {
        c() {
            i && i.c(), n = h()
        },
        l(l) {
            i && i.l(l), n = h()
        },
        m(l, u) {
            ~e && a[e].m(l, u), k(l, n, u), t = !0
        },
        p(l, u) {
            let c = e;
            e = s(l), e === c ? ~e && a[e].p(l, u) : (i && (y(), m(a[c], 1, 1, () => {
                a[c] = null
            }), w()), ~e ? (i = a[e], i ? i.p(l, u) : (i = a[e] = r[e](l), i.c()), d(i, 1), i.m(n.parentNode, n)) : i = null)
        },
        i(l) {
            t || (d(i), t = !0)
        },
        o(l) {
            m(i), t = !1
        },
        d(l) {
            l && f(n), ~e && a[e].d(l)
        }
    }
}

function Ra(o) {
    let e, i, n = o[3] && hn(o);
    return {
        c() {
            n && n.c(), e = h()
        },
        l(t) {
            n && n.l(t), e = h()
        },
        m(t, r) {
            n && n.m(t, r), k(t, e, r), i = !0
        },
        p(t, [r]) {
            t[3] ? n ? (n.p(t, r), r & 8 && d(n, 1)) : (n = hn(t), n.c(), d(n, 1), n.m(e.parentNode, e)) : n && (y(), m(n, 1, 1, () => {
                n = null
            }), w())
        },
        i(t) {
            i || (d(n), i = !0)
        },
        o(t) {
            m(n), i = !1
        },
        d(t) {
            t && f(e), n && n.d(t)
        }
    }
}

function Va(o, e, i) {
    let n, t;
    j(o, x, l => i(4, t = l));
    let {
        name: r
    } = e, {
        amount: a
    } = e, {
        currency: s
    } = e;
    return o.$$set = l => {
        "name" in l && i(0, r = l.name), "amount" in l && i(1, a = l.amount), "currency" in l && i(2, s = l.currency)
    }, o.$$.update = () => {
        o.$$.dirty & 16 && i(3, n = t.message(Ba.content.id))
    }, [r, a, s, n, t]
}
let Ma = class extends q {
    constructor(e) {
        super(), K(this, e, Va, Ra, Y, {
            name: 0,
            amount: 1,
            currency: 2
        })
    }
};
const Oa = o => ({
        title: p._("Rain Received"),
        body: Ma,
        props: o,
        icon: Al,
        sound: "money",
        type: "rain"
    }),
    La = {
        "vip-none": Wl,
        "vip-bronze": zl,
        "vip-silver": Gl,
        "vip-gold": jl,
        "vip-platinum-1": Hl,
        "vip-platinum-2": Yl,
        "vip-platinum-3": ql,
        "vip-platinum-4": Kl,
        "vip-platinum-5": Zl,
        "vip-platinum-6": Xl,
        "vip-diamond-1": Ql,
        "vip-diamond-2": Jl,
        "vip-diamond-3": xl,
        "vip-diamond-4": ea,
        "vip-diamond-5": na,
        "vip-obsidian-1": ta,
        "vip-obsidian-2": ia,
        "vip-opal-1": la,
        "vip-opal-2": aa,
        "vip-plutonium-1": ra
    },
    Ua = o => ({
        title: p._("VIP Achievement"),
        body: {
            id: "Congratulations {flag} VIP unlocked. One of our VIP managers will contact you about your new benefits!",
            values: {
                flag: o.flagMessage
            }
        },
        props: o,
        icon: La[Ll(o.flag)],
        type: "positive"
    }),
    bn = {
        bonusAvailable: {
            id: "You received {amount} to your available balance."
        },
        bonusVault: {
            id: "You received {amount} to your vault balance."
        }
    };

function Fn(o, e, i) {
    const n = o.slice();
    return n[6] = e[i], n
}

function yn(o) {
    let e, i, n = Z(o[3]),
        t = [];
    for (let a = 0; a < n.length; a += 1) t[a] = wn(Fn(o, n, a));
    const r = a => m(t[a], 1, 1, () => {
        t[a] = null
    });
    return {
        c() {
            e = T("span");
            for (let a = 0; a < t.length; a += 1) t[a].c()
        },
        l(a) {
            e = I(a, "SPAN", {});
            var s = B(e);
            for (let l = 0; l < t.length; l += 1) t[l].l(s);
            s.forEach(f)
        },
        m(a, s) {
            k(a, e, s);
            for (let l = 0; l < t.length; l += 1) t[l] && t[l].m(e, null);
            i = !0
        },
        p(a, s) {
            if (s & 15) {
                n = Z(a[3]);
                let l;
                for (l = 0; l < n.length; l += 1) {
                    const u = Fn(a, n, l);
                    t[l] ? (t[l].p(u, s), d(t[l], 1)) : (t[l] = wn(u), t[l].c(), d(t[l], 1), t[l].m(e, null))
                }
                for (y(), l = n.length; l < t.length; l += 1) r(l);
                w()
            }
        },
        i(a) {
            if (!i) {
                for (let s = 0; s < n.length; s += 1) d(t[s]);
                i = !0
            }
        },
        o(a) {
            t = t.filter(Boolean);
            for (let s = 0; s < t.length; s += 1) m(t[s]);
            i = !1
        },
        d(a) {
            a && f(e), te(t, a)
        }
    }
}

function Wa(o) {
    let e, i;
    return {
        c() {
            e = T("span"), i = P(o[2])
        },
        l(n) {
            e = I(n, "SPAN", {});
            var t = B(e);
            i = D(t, o[2]), t.forEach(f)
        },
        m(n, t) {
            k(n, e, t), z(e, i)
        },
        p(n, t) {
            t & 4 && O(i, n[2])
        },
        i: A,
        o: A,
        d(n) {
            n && f(e)
        }
    }
}

function za(o) {
    let e, i;
    return e = new ie({
        props: {
            value: o[0],
            currency: o[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 1 && (r.value = n[0]), t & 2 && (r.currency = n[1]), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Ga(o) {
    let e = o[6] + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 8 && e !== (e = n[6] + "") && O(i, e)
        },
        i: A,
        o: A,
        d(n) {
            n && f(i)
        }
    }
}

function wn(o) {
    let e, i, n, t;
    const r = [Ga, za, Wa],
        a = [];

    function s(l, u) {
        return typeof l[6] == "string" ? 0 : l[6][0] === "amount" ? 1 : l[6][0] === "credit" ? 2 : -1
    }
    return ~(e = s(o)) && (i = a[e] = r[e](o)), {
        c() {
            i && i.c(), n = h()
        },
        l(l) {
            i && i.l(l), n = h()
        },
        m(l, u) {
            ~e && a[e].m(l, u), k(l, n, u), t = !0
        },
        p(l, u) {
            let c = e;
            e = s(l), e === c ? ~e && a[e].p(l, u) : (i && (y(), m(a[c], 1, 1, () => {
                a[c] = null
            }), w()), ~e ? (i = a[e], i ? i.p(l, u) : (i = a[e] = r[e](l), i.c()), d(i, 1), i.m(n.parentNode, n)) : i = null)
        },
        i(l) {
            t || (d(i), t = !0)
        },
        o(l) {
            m(i), t = !1
        },
        d(l) {
            l && f(n), ~e && a[e].d(l)
        }
    }
}

function ja(o) {
    let e, i, n = o[3] && yn(o);
    return {
        c() {
            n && n.c(), e = h()
        },
        l(t) {
            n && n.l(t), e = h()
        },
        m(t, r) {
            n && n.m(t, r), k(t, e, r), i = !0
        },
        p(t, [r]) {
            t[3] ? n ? (n.p(t, r), r & 8 && d(n, 1)) : (n = yn(t), n.c(), d(n, 1), n.m(e.parentNode, e)) : n && (y(), m(n, 1, 1, () => {
                n = null
            }), w())
        },
        i(t) {
            i || (d(n), i = !0)
        },
        o(t) {
            m(n), i = !1
        },
        d(t) {
            t && f(e), n && n.d(t)
        }
    }
}

function Ha(o, e, i) {
    let n, t;
    j(o, x, u => i(4, t = u));
    let {
        amount: r
    } = e, {
        currency: a
    } = e, {
        credit: s
    } = e;
    const l = {
        [kn.available]: t.message(bn.bonusAvailable.id),
        [kn.vault]: t.message(bn.bonusVault.id)
    };
    return o.$$set = u => {
        "amount" in u && i(0, r = u.amount), "currency" in u && i(1, a = u.currency), "credit" in u && i(2, s = u.credit)
    }, o.$$.update = () => {
        o.$$.dirty & 4 && i(3, n = s in l && l[s])
    }, [r, a, s, n]
}
let Ya = class extends q {
    constructor(e) {
        super(), K(this, e, Ha, ja, Y, {
            amount: 0,
            currency: 1,
            credit: 2
        })
    }
};
const qa = o => ({
    title: p._("Bonus Received"),
    body: Ya,
    props: o,
    icon: oe,
    sound: "money",
    type: "positive"
});

function Ka(o) {
    let e, i;
    return e = new ie({
        props: {
            value: o[0],
            currency: o[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, [t]) {
            const r = {};
            t & 1 && (r.value = n[0]), t & 2 && (r.currency = n[1]), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Za(o, e, i) {
    let {
        amount: n
    } = e, {
        currency: t
    } = e;
    return o.$$set = r => {
        "amount" in r && i(0, n = r.amount), "currency" in r && i(1, t = r.currency)
    }, [n, t]
}
let Xa = class extends q {
    constructor(e) {
        super(), K(this, e, Za, Ka, Y, {
            amount: 0,
            currency: 1
        })
    }
};
const Qa = o => ({
        title: p._("Balance Updated"),
        body: Xa,
        props: o,
        icon: oe,
        sound: "money",
        type: "positive"
    }),
    un = {
        title: p._("Tip Received"),
        content: {
            id: "You received {value} from {user}"
        }
    },
    Ja = { ...un,
        title: p._("Gift Received")
    },
    xa = {
        stake: un,
        sweeps: Ja
    },
    Ti = xa[Te] || un;

function Cn(o, e, i) {
    const n = o.slice();
    return n[5] = e[i], n
}

function An(o) {
    let e, i, n = Z(o[3]),
        t = [];
    for (let a = 0; a < n.length; a += 1) t[a] = Tn(Cn(o, n, a));
    const r = a => m(t[a], 1, 1, () => {
        t[a] = null
    });
    return {
        c() {
            e = T("span");
            for (let a = 0; a < t.length; a += 1) t[a].c()
        },
        l(a) {
            e = I(a, "SPAN", {});
            var s = B(e);
            for (let l = 0; l < t.length; l += 1) t[l].l(s);
            s.forEach(f)
        },
        m(a, s) {
            k(a, e, s);
            for (let l = 0; l < t.length; l += 1) t[l] && t[l].m(e, null);
            i = !0
        },
        p(a, s) {
            if (s & 15) {
                n = Z(a[3]);
                let l;
                for (l = 0; l < n.length; l += 1) {
                    const u = Cn(a, n, l);
                    t[l] ? (t[l].p(u, s), d(t[l], 1)) : (t[l] = Tn(u), t[l].c(), d(t[l], 1), t[l].m(e, null))
                }
                for (y(), l = n.length; l < t.length; l += 1) r(l);
                w()
            }
        },
        i(a) {
            if (!i) {
                for (let s = 0; s < n.length; s += 1) d(t[s]);
                i = !0
            }
        },
        o(a) {
            t = t.filter(Boolean);
            for (let s = 0; s < t.length; s += 1) m(t[s]);
            i = !1
        },
        d(a) {
            a && f(e), te(t, a)
        }
    }
}

function er(o) {
    let e, i;
    return e = new Si({
        props: {
            name: o[0]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 1 && (r.name = n[0]), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function nr(o) {
    let e, i;
    return e = new ie({
        props: {
            value: o[1],
            currency: o[2]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 2 && (r.value = n[1]), t & 4 && (r.currency = n[2]), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function tr(o) {
    let e = o[5] + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 8 && e !== (e = n[5] + "") && O(i, e)
        },
        i: A,
        o: A,
        d(n) {
            n && f(i)
        }
    }
}

function Tn(o) {
    let e, i, n, t;
    const r = [tr, nr, er],
        a = [];

    function s(l, u) {
        return typeof l[5] == "string" ? 0 : l[5][0] === "value" ? 1 : l[5][0] === "user" ? 2 : -1
    }
    return ~(e = s(o)) && (i = a[e] = r[e](o)), {
        c() {
            i && i.c(), n = h()
        },
        l(l) {
            i && i.l(l), n = h()
        },
        m(l, u) {
            ~e && a[e].m(l, u), k(l, n, u), t = !0
        },
        p(l, u) {
            let c = e;
            e = s(l), e === c ? ~e && a[e].p(l, u) : (i && (y(), m(a[c], 1, 1, () => {
                a[c] = null
            }), w()), ~e ? (i = a[e], i ? i.p(l, u) : (i = a[e] = r[e](l), i.c()), d(i, 1), i.m(n.parentNode, n)) : i = null)
        },
        i(l) {
            t || (d(i), t = !0)
        },
        o(l) {
            m(i), t = !1
        },
        d(l) {
            l && f(n), ~e && a[e].d(l)
        }
    }
}

function ir(o) {
    let e, i, n = o[3] && An(o);
    return {
        c() {
            n && n.c(), e = h()
        },
        l(t) {
            n && n.l(t), e = h()
        },
        m(t, r) {
            n && n.m(t, r), k(t, e, r), i = !0
        },
        p(t, [r]) {
            t[3] ? n ? (n.p(t, r), r & 8 && d(n, 1)) : (n = An(t), n.c(), d(n, 1), n.m(e.parentNode, e)) : n && (y(), m(n, 1, 1, () => {
                n = null
            }), w())
        },
        i(t) {
            i || (d(n), i = !0)
        },
        o(t) {
            m(n), i = !1
        },
        d(t) {
            t && f(e), n && n.d(t)
        }
    }
}

function lr(o, e, i) {
    let n, t;
    j(o, x, l => i(4, t = l));
    let {
        name: r
    } = e, {
        amount: a
    } = e, {
        currency: s
    } = e;
    return o.$$set = l => {
        "name" in l && i(0, r = l.name), "amount" in l && i(1, a = l.amount), "currency" in l && i(2, s = l.currency)
    }, o.$$.update = () => {
        o.$$.dirty & 16 && i(3, n = t.message(Ti.content.id))
    }, [r, a, s, n, t]
}
let ar = class extends q {
    constructor(e) {
        super(), K(this, e, lr, ir, Y, {
            name: 0,
            amount: 1,
            currency: 2
        })
    }
};
const rr = o => ({
        title: Ti.title,
        body: ar,
        props: o,
        icon: oe,
        type: "positive",
        sound: "money"
    }),
    Ii = {
        title: p._("Reload Bonus Now Available"),
        body: {
            id: "Claim your reload bonus of {amount}"
        }
    };

function In(o, e, i) {
    const n = o.slice();
    return n[6] = e[i], n
}

function Bn(o) {
    let e, i, n = Z(o[2]),
        t = [];
    for (let a = 0; a < n.length; a += 1) t[a] = En(In(o, n, a));
    const r = a => m(t[a], 1, 1, () => {
        t[a] = null
    });
    return {
        c() {
            e = T("span");
            for (let a = 0; a < t.length; a += 1) t[a].c()
        },
        l(a) {
            e = I(a, "SPAN", {});
            var s = B(e);
            for (let l = 0; l < t.length; l += 1) t[l].l(s);
            s.forEach(f)
        },
        m(a, s) {
            k(a, e, s);
            for (let l = 0; l < t.length; l += 1) t[l] && t[l].m(e, null);
            i = !0
        },
        p(a, s) {
            if (s & 15) {
                n = Z(a[2]);
                let l;
                for (l = 0; l < n.length; l += 1) {
                    const u = In(a, n, l);
                    t[l] ? (t[l].p(u, s), d(t[l], 1)) : (t[l] = En(u), t[l].c(), d(t[l], 1), t[l].m(e, null))
                }
                for (y(), l = n.length; l < t.length; l += 1) r(l);
                w()
            }
        },
        i(a) {
            if (!i) {
                for (let s = 0; s < n.length; s += 1) d(t[s]);
                i = !0
            }
        },
        o(a) {
            t = t.filter(Boolean);
            for (let s = 0; s < t.length; s += 1) m(t[s]);
            i = !1
        },
        d(a) {
            a && f(e), te(t, a)
        }
    }
}

function or(o) {
    let e, i;
    return e = new ie({
        props: {
            value: o[0] / o[3],
            currency: o[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 9 && (r.value = n[0] / n[3]), t & 2 && (r.currency = n[1]), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function sr(o) {
    let e = o[6] + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 4 && e !== (e = n[6] + "") && O(i, e)
        },
        i: A,
        o: A,
        d(n) {
            n && f(i)
        }
    }
}

function En(o) {
    let e, i, n, t;
    const r = [sr, or],
        a = [];

    function s(l, u) {
        return typeof l[6] == "string" ? 0 : l[6][0] === "amount" && l[3] ? 1 : -1
    }
    return ~(e = s(o)) && (i = a[e] = r[e](o)), {
        c() {
            i && i.c(), n = h()
        },
        l(l) {
            i && i.l(l), n = h()
        },
        m(l, u) {
            ~e && a[e].m(l, u), k(l, n, u), t = !0
        },
        p(l, u) {
            let c = e;
            e = s(l), e === c ? ~e && a[e].p(l, u) : (i && (y(), m(a[c], 1, 1, () => {
                a[c] = null
            }), w()), ~e ? (i = a[e], i ? i.p(l, u) : (i = a[e] = r[e](l), i.c()), d(i, 1), i.m(n.parentNode, n)) : i = null)
        },
        i(l) {
            t || (d(i), t = !0)
        },
        o(l) {
            m(i), t = !1
        },
        d(l) {
            l && f(n), ~e && a[e].d(l)
        }
    }
}

function ur(o) {
    let e, i, n = o[2] && Bn(o);
    return {
        c() {
            n && n.c(), e = h()
        },
        l(t) {
            n && n.l(t), e = h()
        },
        m(t, r) {
            n && n.m(t, r), k(t, e, r), i = !0
        },
        p(t, [r]) {
            t[2] ? n ? (n.p(t, r), r & 4 && d(n, 1)) : (n = Bn(t), n.c(), d(n, 1), n.m(e.parentNode, e)) : n && (y(), m(n, 1, 1, () => {
                n = null
            }), w())
        },
        i(t) {
            i || (d(n), i = !0)
        },
        o(t) {
            m(n), i = !1
        },
        d(t) {
            t && f(e), n && n.d(t)
        }
    }
}

function cr(o, e, i) {
    let n, t, r, a, s;
    j(o, x, u => i(4, r = u)), j(o, rn, u => i(1, a = u)), j(o, sl, u => i(5, s = u));
    let {
        value: l
    } = e;
    return o.$$set = u => {
        "value" in u && i(0, l = u.value)
    }, o.$$.update = () => {
        var u, c;
        o.$$.dirty & 34 && i(3, n = ((c = (u = s == null ? void 0 : s.rates) == null ? void 0 : u[a]) == null ? void 0 : c.usd) || void 0), o.$$.dirty & 16 && i(2, t = r.message(Ii.body.id))
    }, [l, a, t, n, r, s]
}
let dr = class extends q {
    constructor(e) {
        super(), K(this, e, cr, ur, Y, {
            value: 0
        })
    }
};
const mr = o => ({
        title: Ii.title,
        body: dr,
        type: "positive",
        props: o,
        icon: oe,
        click: () => me.vip.open({
            tab: "reload"
        })
    }),
    cn = {
        title: {
            id: "Deposit Confirmed"
        },
        content: {
            id: "Your deposit of {amount} has been successfully processed."
        }
    },
    fr = { ...cn,
        title: {
            id: "Purchase Confirmed"
        },
        content: {
            id: "Your bundle purchase of {tokensReceived} has been successfully processed."
        }
    },
    kr = {
        stake: cn,
        sweeps: fr
    },
    Bi = kr[Te] || cn;

function Pn(o, e, i) {
    const n = o.slice();
    return n[5] = e[i], n
}

function Dn(o, e, i) {
    const n = o.slice();
    return n[8] = e[i], n[10] = i, n
}

function Rn(o) {
    let e, i, n = Z(o[3]),
        t = [];
    for (let a = 0; a < n.length; a += 1) t[a] = Ln(Pn(o, n, a));
    const r = a => m(t[a], 1, 1, () => {
        t[a] = null
    });
    return {
        c() {
            e = T("span");
            for (let a = 0; a < t.length; a += 1) t[a].c()
        },
        l(a) {
            e = I(a, "SPAN", {});
            var s = B(e);
            for (let l = 0; l < t.length; l += 1) t[l].l(s);
            s.forEach(f)
        },
        m(a, s) {
            k(a, e, s);
            for (let l = 0; l < t.length; l += 1) t[l] && t[l].m(e, null);
            i = !0
        },
        p(a, s) {
            if (s & 15) {
                n = Z(a[3]);
                let l;
                for (l = 0; l < n.length; l += 1) {
                    const u = Pn(a, n, l);
                    t[l] ? (t[l].p(u, s), d(t[l], 1)) : (t[l] = Ln(u), t[l].c(), d(t[l], 1), t[l].m(e, null))
                }
                for (y(), l = n.length; l < t.length; l += 1) r(l);
                w()
            }
        },
        i(a) {
            if (!i) {
                for (let s = 0; s < n.length; s += 1) d(t[s]);
                i = !0
            }
        },
        o(a) {
            t = t.filter(Boolean);
            for (let s = 0; s < t.length; s += 1) m(t[s]);
            i = !1
        },
        d(a) {
            a && f(e), te(t, a)
        }
    }
}

function _r(o) {
    let e, i, n = Z(o[2]),
        t = [];
    for (let a = 0; a < n.length; a += 1) t[a] = On(Dn(o, n, a));
    const r = a => m(t[a], 1, 1, () => {
        t[a] = null
    });
    return {
        c() {
            for (let a = 0; a < t.length; a += 1) t[a].c();
            e = h()
        },
        l(a) {
            for (let s = 0; s < t.length; s += 1) t[s].l(a);
            e = h()
        },
        m(a, s) {
            for (let l = 0; l < t.length; l += 1) t[l] && t[l].m(a, s);
            k(a, e, s), i = !0
        },
        p(a, s) {
            if (s & 4) {
                n = Z(a[2]);
                let l;
                for (l = 0; l < n.length; l += 1) {
                    const u = Dn(a, n, l);
                    t[l] ? (t[l].p(u, s), d(t[l], 1)) : (t[l] = On(u), t[l].c(), d(t[l], 1), t[l].m(e.parentNode, e))
                }
                for (y(), l = n.length; l < t.length; l += 1) r(l);
                w()
            }
        },
        i(a) {
            if (!i) {
                for (let s = 0; s < n.length; s += 1) d(t[s]);
                i = !0
            }
        },
        o(a) {
            t = t.filter(Boolean);
            for (let s = 0; s < t.length; s += 1) m(t[s]);
            i = !1
        },
        d(a) {
            a && f(e), te(t, a)
        }
    }
}

function pr(o) {
    let e, i;
    return e = new ie({
        props: {
            value: o[0],
            currency: o[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 1 && (r.value = n[0]), t & 2 && (r.currency = n[1]), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function gr(o) {
    let e = o[5] + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 8 && e !== (e = n[5] + "") && O(i, e)
        },
        i: A,
        o: A,
        d(n) {
            n && f(i)
        }
    }
}

function Vn(o) {
    var a;
    let e, i, n, t;
    e = new ie({
        props: {
            value: o[8].amount,
            currency: o[8].currency
        }
    });
    let r = o[10] === 0 && ((a = o[2]) == null ? void 0 : a.length) > 1 && Mn();
    return {
        c() {
            g(e.$$.fragment), i = V(), r && r.c(), n = h()
        },
        l(s) {
            N(e.$$.fragment, s), i = M(s), r && r.l(s), n = h()
        },
        m(s, l) {
            $(e, s, l), k(s, i, l), r && r.m(s, l), k(s, n, l), t = !0
        },
        p(s, l) {
            var c;
            const u = {};
            l & 4 && (u.value = s[8].amount), l & 4 && (u.currency = s[8].currency), e.$set(u), s[10] === 0 && ((c = s[2]) == null ? void 0 : c.length) > 1 ? r || (r = Mn(), r.c(), r.m(n.parentNode, n)) : r && (r.d(1), r = null)
        },
        i(s) {
            t || (d(e.$$.fragment, s), t = !0)
        },
        o(s) {
            m(e.$$.fragment, s), t = !1
        },
        d(s) {
            s && (f(i), f(n)), v(e, s), r && r.d(s)
        }
    }
}

function Mn(o) {
    let e;
    return {
        c() {
            e = P("+ ")
        },
        l(i) {
            e = D(i, "+ ")
        },
        m(i, n) {
            k(i, e, n)
        },
        d(i) {
            i && f(e)
        }
    }
}

function On(o) {
    let e, i, n = o[8] && Vn(o);
    return {
        c() {
            n && n.c(), e = h()
        },
        l(t) {
            n && n.l(t), e = h()
        },
        m(t, r) {
            n && n.m(t, r), k(t, e, r), i = !0
        },
        p(t, r) {
            t[8] ? n ? (n.p(t, r), r & 4 && d(n, 1)) : (n = Vn(t), n.c(), d(n, 1), n.m(e.parentNode, e)) : n && (y(), m(n, 1, 1, () => {
                n = null
            }), w())
        },
        i(t) {
            i || (d(n), i = !0)
        },
        o(t) {
            m(n), i = !1
        },
        d(t) {
            t && f(e), n && n.d(t)
        }
    }
}

function Ln(o) {
    let e, i, n, t;
    const r = [gr, pr, _r],
        a = [];

    function s(l, u) {
        return typeof l[5] == "string" ? 0 : l[5][0] === "amount" && l[1] ? 1 : l[5][0] === "tokensReceived" && l[2] ? 2 : -1
    }
    return ~(e = s(o)) && (i = a[e] = r[e](o)), {
        c() {
            i && i.c(), n = h()
        },
        l(l) {
            i && i.l(l), n = h()
        },
        m(l, u) {
            ~e && a[e].m(l, u), k(l, n, u), t = !0
        },
        p(l, u) {
            let c = e;
            e = s(l), e === c ? ~e && a[e].p(l, u) : (i && (y(), m(a[c], 1, 1, () => {
                a[c] = null
            }), w()), ~e ? (i = a[e], i ? i.p(l, u) : (i = a[e] = r[e](l), i.c()), d(i, 1), i.m(n.parentNode, n)) : i = null)
        },
        i(l) {
            t || (d(i), t = !0)
        },
        o(l) {
            m(i), t = !1
        },
        d(l) {
            l && f(n), ~e && a[e].d(l)
        }
    }
}

function $r(o) {
    let e, i, n = o[3] && Rn(o);
    return {
        c() {
            n && n.c(), e = h()
        },
        l(t) {
            n && n.l(t), e = h()
        },
        m(t, r) {
            n && n.m(t, r), k(t, e, r), i = !0
        },
        p(t, [r]) {
            t[3] ? n ? (n.p(t, r), r & 8 && d(n, 1)) : (n = Rn(t), n.c(), d(n, 1), n.m(e.parentNode, e)) : n && (y(), m(n, 1, 1, () => {
                n = null
            }), w())
        },
        i(t) {
            i || (d(n), i = !0)
        },
        o(t) {
            m(n), i = !1
        },
        d(t) {
            t && f(e), n && n.d(t)
        }
    }
}

function vr(o, e, i) {
    let n, t;
    j(o, x, l => i(4, t = l));
    let {
        amount: r
    } = e, {
        currency: a
    } = e, {
        tokensReceived: s
    } = e;
    return o.$$set = l => {
        "amount" in l && i(0, r = l.amount), "currency" in l && i(1, a = l.currency), "tokensReceived" in l && i(2, s = l.tokensReceived)
    }, o.$$.update = () => {
        o.$$.dirty & 16 && i(3, n = t.message(Bi.content.id))
    }, [r, a, s, n, t]
}
let Nr = class extends q {
    constructor(e) {
        super(), K(this, e, vr, $r, Y, {
            amount: 0,
            currency: 1,
            tokensReceived: 2
        })
    }
};
const Un = o => ({
        title: Bi.title.id,
        body: Nr,
        props: o,
        icon: oe,
        sound: "money",
        type: "positive"
    }),
    dn = {
        content: {
            id: "Your {amount} multi bet has been refunded."
        }
    },
    hr = { ...dn,
        content: {
            id: "Your {amount} parlay has been refunded."
        }
    },
    Sr = {
        stake: dn,
        canada: hr
    },
    br = Sr[Te] || dn;

function Wn(o, e, i) {
    const n = o.slice();
    return n[4] = e[i], n
}

function zn(o) {
    let e, i, n = Z(o[2]),
        t = [];
    for (let a = 0; a < n.length; a += 1) t[a] = Gn(Wn(o, n, a));
    const r = a => m(t[a], 1, 1, () => {
        t[a] = null
    });
    return {
        c() {
            e = T("span");
            for (let a = 0; a < t.length; a += 1) t[a].c()
        },
        l(a) {
            e = I(a, "SPAN", {});
            var s = B(e);
            for (let l = 0; l < t.length; l += 1) t[l].l(s);
            s.forEach(f)
        },
        m(a, s) {
            k(a, e, s);
            for (let l = 0; l < t.length; l += 1) t[l] && t[l].m(e, null);
            i = !0
        },
        p(a, s) {
            if (s & 7) {
                n = Z(a[2]);
                let l;
                for (l = 0; l < n.length; l += 1) {
                    const u = Wn(a, n, l);
                    t[l] ? (t[l].p(u, s), d(t[l], 1)) : (t[l] = Gn(u), t[l].c(), d(t[l], 1), t[l].m(e, null))
                }
                for (y(), l = n.length; l < t.length; l += 1) r(l);
                w()
            }
        },
        i(a) {
            if (!i) {
                for (let s = 0; s < n.length; s += 1) d(t[s]);
                i = !0
            }
        },
        o(a) {
            t = t.filter(Boolean);
            for (let s = 0; s < t.length; s += 1) m(t[s]);
            i = !1
        },
        d(a) {
            a && f(e), te(t, a)
        }
    }
}

function Fr(o) {
    let e, i;
    return e = new ie({
        props: {
            value: o[0],
            currency: o[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 1 && (r.value = n[0]), t & 2 && (r.currency = n[1]), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function yr(o) {
    let e = o[4] + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 4 && e !== (e = n[4] + "") && O(i, e)
        },
        i: A,
        o: A,
        d(n) {
            n && f(i)
        }
    }
}

function Gn(o) {
    let e, i, n, t;
    const r = [yr, Fr],
        a = [];

    function s(l, u) {
        return typeof l[4] == "string" ? 0 : l[4][0] === "amount" ? 1 : -1
    }
    return ~(e = s(o)) && (i = a[e] = r[e](o)), {
        c() {
            i && i.c(), n = h()
        },
        l(l) {
            i && i.l(l), n = h()
        },
        m(l, u) {
            ~e && a[e].m(l, u), k(l, n, u), t = !0
        },
        p(l, u) {
            let c = e;
            e = s(l), e === c ? ~e && a[e].p(l, u) : (i && (y(), m(a[c], 1, 1, () => {
                a[c] = null
            }), w()), ~e ? (i = a[e], i ? i.p(l, u) : (i = a[e] = r[e](l), i.c()), d(i, 1), i.m(n.parentNode, n)) : i = null)
        },
        i(l) {
            t || (d(i), t = !0)
        },
        o(l) {
            m(i), t = !1
        },
        d(l) {
            l && f(n), ~e && a[e].d(l)
        }
    }
}

function wr(o) {
    let e, i, n = o[2] && zn(o);
    return {
        c() {
            n && n.c(), e = h()
        },
        l(t) {
            n && n.l(t), e = h()
        },
        m(t, r) {
            n && n.m(t, r), k(t, e, r), i = !0
        },
        p(t, [r]) {
            t[2] ? n ? (n.p(t, r), r & 4 && d(n, 1)) : (n = zn(t), n.c(), d(n, 1), n.m(e.parentNode, e)) : n && (y(), m(n, 1, 1, () => {
                n = null
            }), w())
        },
        i(t) {
            i || (d(n), i = !0)
        },
        o(t) {
            m(n), i = !1
        },
        d(t) {
            t && f(e), n && n.d(t)
        }
    }
}

function Cr(o, e, i) {
    let n, t;
    j(o, x, s => i(3, t = s));
    let {
        amount: r
    } = e, {
        currency: a
    } = e;
    return o.$$set = s => {
        "amount" in s && i(0, r = s.amount), "currency" in s && i(1, a = s.currency)
    }, o.$$.update = () => {
        o.$$.dirty & 8 && i(2, n = t.message(br.content.id))
    }, [r, a, n, t]
}
let Ar = class extends q {
    constructor(e) {
        super(), K(this, e, Cr, wr, Y, {
            amount: 0,
            currency: 1
        })
    }
};
const Tr = o => ({
        title: p._("Multi Bet Refunded"),
        body: Ar,
        props: o,
        icon: oe,
        sound: "money",
        type: "positive"
    }),
    Ei = {
        title: p._("Muted"),
        muted: {
            id: "You have been muted for {message}. Expires {expireAt}"
        }
    };

function jn(o, e, i) {
    const n = o.slice();
    return n[4] = e[i], n
}

function Hn(o) {
    let e, i, n = Z(o[2]),
        t = [];
    for (let a = 0; a < n.length; a += 1) t[a] = Yn(jn(o, n, a));
    const r = a => m(t[a], 1, 1, () => {
        t[a] = null
    });
    return {
        c() {
            e = T("span");
            for (let a = 0; a < t.length; a += 1) t[a].c()
        },
        l(a) {
            e = I(a, "SPAN", {});
            var s = B(e);
            for (let l = 0; l < t.length; l += 1) t[l].l(s);
            s.forEach(f)
        },
        m(a, s) {
            k(a, e, s);
            for (let l = 0; l < t.length; l += 1) t[l] && t[l].m(e, null);
            i = !0
        },
        p(a, s) {
            if (s & 7) {
                n = Z(a[2]);
                let l;
                for (l = 0; l < n.length; l += 1) {
                    const u = jn(a, n, l);
                    t[l] ? (t[l].p(u, s), d(t[l], 1)) : (t[l] = Yn(u), t[l].c(), d(t[l], 1), t[l].m(e, null))
                }
                for (y(), l = n.length; l < t.length; l += 1) r(l);
                w()
            }
        },
        i(a) {
            if (!i) {
                for (let s = 0; s < n.length; s += 1) d(t[s]);
                i = !0
            }
        },
        o(a) {
            t = t.filter(Boolean);
            for (let s = 0; s < t.length; s += 1) m(t[s]);
            i = !1
        },
        d(a) {
            a && f(e), te(t, a)
        }
    }
}

function Ir(o) {
    let e, i;
    return e = new hi({
        props: {
            value: new Date(o[1])
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 2 && (r.value = new Date(n[1])), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Br(o) {
    let e;
    return {
        c() {
            e = P(o[0])
        },
        l(i) {
            e = D(i, o[0])
        },
        m(i, n) {
            k(i, e, n)
        },
        p(i, n) {
            n & 1 && O(e, i[0])
        },
        i: A,
        o: A,
        d(i) {
            i && f(e)
        }
    }
}

function Er(o) {
    let e = o[4] + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 4 && e !== (e = n[4] + "") && O(i, e)
        },
        i: A,
        o: A,
        d(n) {
            n && f(i)
        }
    }
}

function Yn(o) {
    let e, i, n, t;
    const r = [Er, Br, Ir],
        a = [];

    function s(l, u) {
        return typeof l[4] == "string" ? 0 : l[4][0] === "message" ? 1 : l[4][0] === "expireAt" ? 2 : -1
    }
    return ~(e = s(o)) && (i = a[e] = r[e](o)), {
        c() {
            i && i.c(), n = h()
        },
        l(l) {
            i && i.l(l), n = h()
        },
        m(l, u) {
            ~e && a[e].m(l, u), k(l, n, u), t = !0
        },
        p(l, u) {
            let c = e;
            e = s(l), e === c ? ~e && a[e].p(l, u) : (i && (y(), m(a[c], 1, 1, () => {
                a[c] = null
            }), w()), ~e ? (i = a[e], i ? i.p(l, u) : (i = a[e] = r[e](l), i.c()), d(i, 1), i.m(n.parentNode, n)) : i = null)
        },
        i(l) {
            t || (d(i), t = !0)
        },
        o(l) {
            m(i), t = !1
        },
        d(l) {
            l && f(n), ~e && a[e].d(l)
        }
    }
}

function Pr(o) {
    let e, i, n = o[2] && Hn(o);
    return {
        c() {
            n && n.c(), e = h()
        },
        l(t) {
            n && n.l(t), e = h()
        },
        m(t, r) {
            n && n.m(t, r), k(t, e, r), i = !0
        },
        p(t, [r]) {
            t[2] ? n ? (n.p(t, r), r & 4 && d(n, 1)) : (n = Hn(t), n.c(), d(n, 1), n.m(e.parentNode, e)) : n && (y(), m(n, 1, 1, () => {
                n = null
            }), w())
        },
        i(t) {
            i || (d(n), i = !0)
        },
        o(t) {
            m(n), i = !1
        },
        d(t) {
            t && f(e), n && n.d(t)
        }
    }
}

function Dr(o, e, i) {
    let n, t;
    j(o, x, s => i(3, t = s));
    let {
        message: r
    } = e, {
        expireAt: a
    } = e;
    return o.$$set = s => {
        "message" in s && i(0, r = s.message), "expireAt" in s && i(1, a = s.expireAt)
    }, o.$$.update = () => {
        o.$$.dirty & 8 && i(2, n = t.message(Ei.muted.id))
    }, [r, a, n, t]
}
let Rr = class extends q {
    constructor(e) {
        super(), K(this, e, Dr, Pr, Y, {
            message: 0,
            expireAt: 1
        })
    }
};
const Vr = o => ({
        title: Ei.title,
        body: Rr,
        props: o,
        icon: Ni,
        type: "negative"
    }),
    nn = {
        won: {
            id: "Your bet on {fixture} won {value}"
        },
        lost: o => ({
            id: "Your bet on {fixture} lost.",
            values: {
                fixture: o
            }
        })
    };

function qn(o, e, i) {
    const n = o.slice();
    return n[5] = e[i], n
}

function Mr(o) {
    let e, i, n = Z(o[4]),
        t = [];
    for (let a = 0; a < n.length; a += 1) t[a] = Kn(qn(o, n, a));
    const r = a => m(t[a], 1, 1, () => {
        t[a] = null
    });
    return {
        c() {
            e = T("span");
            for (let a = 0; a < t.length; a += 1) t[a].c()
        },
        l(a) {
            e = I(a, "SPAN", {});
            var s = B(e);
            for (let l = 0; l < t.length; l += 1) t[l].l(s);
            s.forEach(f)
        },
        m(a, s) {
            k(a, e, s);
            for (let l = 0; l < t.length; l += 1) t[l] && t[l].m(e, null);
            i = !0
        },
        p(a, s) {
            if (s & 23) {
                n = Z(a[4]);
                let l;
                for (l = 0; l < n.length; l += 1) {
                    const u = qn(a, n, l);
                    t[l] ? (t[l].p(u, s), d(t[l], 1)) : (t[l] = Kn(u), t[l].c(), d(t[l], 1), t[l].m(e, null))
                }
                for (y(), l = n.length; l < t.length; l += 1) r(l);
                w()
            }
        },
        i(a) {
            if (!i) {
                for (let s = 0; s < n.length; s += 1) d(t[s]);
                i = !0
            }
        },
        o(a) {
            t = t.filter(Boolean);
            for (let s = 0; s < t.length; s += 1) m(t[s]);
            i = !1
        },
        d(a) {
            a && f(e), te(t, a)
        }
    }
}

function Or(o) {
    let e, i = o[3]._(nn.lost(o[2])) + "",
        n;
    return {
        c() {
            e = T("span"), n = P(i)
        },
        l(t) {
            e = I(t, "SPAN", {});
            var r = B(e);
            n = D(r, i), r.forEach(f)
        },
        m(t, r) {
            k(t, e, r), z(e, n)
        },
        p(t, r) {
            r & 12 && i !== (i = t[3]._(nn.lost(t[2])) + "") && O(n, i)
        },
        i: A,
        o: A,
        d(t) {
            t && f(e)
        }
    }
}

function Lr(o) {
    let e;
    return {
        c() {
            e = P(o[2])
        },
        l(i) {
            e = D(i, o[2])
        },
        m(i, n) {
            k(i, e, n)
        },
        p(i, n) {
            n & 4 && O(e, i[2])
        },
        i: A,
        o: A,
        d(i) {
            i && f(e)
        }
    }
}

function Ur(o) {
    let e, i;
    return e = new ie({
        props: {
            value: o[0],
            currency: o[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 1 && (r.value = n[0]), t & 2 && (r.currency = n[1]), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Wr(o) {
    let e = o[5] + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 16 && e !== (e = n[5] + "") && O(i, e)
        },
        i: A,
        o: A,
        d(n) {
            n && f(i)
        }
    }
}

function Kn(o) {
    let e, i, n, t;
    const r = [Wr, Ur, Lr],
        a = [];

    function s(l, u) {
        return typeof l[5] == "string" ? 0 : l[5][0] === "value" ? 1 : l[5][0] === "fixture" ? 2 : -1
    }
    return ~(e = s(o)) && (i = a[e] = r[e](o)), {
        c() {
            i && i.c(), n = h()
        },
        l(l) {
            i && i.l(l), n = h()
        },
        m(l, u) {
            ~e && a[e].m(l, u), k(l, n, u), t = !0
        },
        p(l, u) {
            let c = e;
            e = s(l), e === c ? ~e && a[e].p(l, u) : (i && (y(), m(a[c], 1, 1, () => {
                a[c] = null
            }), w()), ~e ? (i = a[e], i ? i.p(l, u) : (i = a[e] = r[e](l), i.c()), d(i, 1), i.m(n.parentNode, n)) : i = null)
        },
        i(l) {
            t || (d(i), t = !0)
        },
        o(l) {
            m(i), t = !1
        },
        d(l) {
            l && f(n), ~e && a[e].d(l)
        }
    }
}

function zr(o) {
    let e, i, n, t;
    const r = [Or, Mr],
        a = [];

    function s(l, u) {
        return l[0] === 0 ? 0 : l[4] ? 1 : -1
    }
    return ~(e = s(o)) && (i = a[e] = r[e](o)), {
        c() {
            i && i.c(), n = h()
        },
        l(l) {
            i && i.l(l), n = h()
        },
        m(l, u) {
            ~e && a[e].m(l, u), k(l, n, u), t = !0
        },
        p(l, [u]) {
            let c = e;
            e = s(l), e === c ? ~e && a[e].p(l, u) : (i && (y(), m(a[c], 1, 1, () => {
                a[c] = null
            }), w()), ~e ? (i = a[e], i ? i.p(l, u) : (i = a[e] = r[e](l), i.c()), d(i, 1), i.m(n.parentNode, n)) : i = null)
        },
        i(l) {
            t || (d(i), t = !0)
        },
        o(l) {
            m(i), t = !1
        },
        d(l) {
            l && f(n), ~e && a[e].d(l)
        }
    }
}

function Gr(o, e, i) {
    let n, t;
    j(o, x, l => i(3, t = l));
    let {
        amount: r
    } = e, {
        currency: a
    } = e, {
        fixture: s
    } = e;
    return o.$$set = l => {
        "amount" in l && i(0, r = l.amount), "currency" in l && i(1, a = l.currency), "fixture" in l && i(2, s = l.fixture)
    }, o.$$.update = () => {
        o.$$.dirty & 8 && i(4, n = t.message(nn.won.id))
    }, [r, a, s, t, n]
}
let jr = class extends q {
    constructor(e) {
        super(), K(this, e, Gr, zr, Y, {
            amount: 0,
            currency: 1,
            fixture: 2
        })
    }
};
const Xe = o => ({
        title: p._("Single Bet Settled"),
        body: jr,
        props: o,
        icon: oe,
        sound: "money",
        type: "positive",
        click: () => {
            me.bet.open({
                betId: o == null ? void 0 : o.betId
            })
        }
    }),
    mn = {
        betLost: p._("Your multi bet lost."),
        betWon: {
            id: "Your multi bet with {legs} legs won {value}"
        }
    },
    Hr = { ...mn,
        betLost: p._("Your parlay bet lost."),
        betWon: {
            id: "Your parlay with {legs} legs won {value}"
        }
    },
    Yr = {
        stake: mn,
        canada: Hr
    },
    tn = Yr[Te] || mn;

function Zn(o, e, i) {
    const n = o.slice();
    return n[5] = e[i], n
}

function qr(o) {
    let e, i, n = Z(o[4]),
        t = [];
    for (let a = 0; a < n.length; a += 1) t[a] = Xn(Zn(o, n, a));
    const r = a => m(t[a], 1, 1, () => {
        t[a] = null
    });
    return {
        c() {
            e = T("span");
            for (let a = 0; a < t.length; a += 1) t[a].c()
        },
        l(a) {
            e = I(a, "SPAN", {});
            var s = B(e);
            for (let l = 0; l < t.length; l += 1) t[l].l(s);
            s.forEach(f)
        },
        m(a, s) {
            k(a, e, s);
            for (let l = 0; l < t.length; l += 1) t[l] && t[l].m(e, null);
            i = !0
        },
        p(a, s) {
            if (s & 23) {
                n = Z(a[4]);
                let l;
                for (l = 0; l < n.length; l += 1) {
                    const u = Zn(a, n, l);
                    t[l] ? (t[l].p(u, s), d(t[l], 1)) : (t[l] = Xn(u), t[l].c(), d(t[l], 1), t[l].m(e, null))
                }
                for (y(), l = n.length; l < t.length; l += 1) r(l);
                w()
            }
        },
        i(a) {
            if (!i) {
                for (let s = 0; s < n.length; s += 1) d(t[s]);
                i = !0
            }
        },
        o(a) {
            t = t.filter(Boolean);
            for (let s = 0; s < t.length; s += 1) m(t[s]);
            i = !1
        },
        d(a) {
            a && f(e), te(t, a)
        }
    }
}

function Kr(o) {
    let e, i = o[3]._(tn.betLost) + "",
        n;
    return {
        c() {
            e = T("span"), n = P(i)
        },
        l(t) {
            e = I(t, "SPAN", {});
            var r = B(e);
            n = D(r, i), r.forEach(f)
        },
        m(t, r) {
            k(t, e, r), z(e, n)
        },
        p(t, r) {
            r & 8 && i !== (i = t[3]._(tn.betLost) + "") && O(n, i)
        },
        i: A,
        o: A,
        d(t) {
            t && f(e)
        }
    }
}

function Zr(o) {
    let e;
    return {
        c() {
            e = P(o[0])
        },
        l(i) {
            e = D(i, o[0])
        },
        m(i, n) {
            k(i, e, n)
        },
        p(i, n) {
            n & 1 && O(e, i[0])
        },
        i: A,
        o: A,
        d(i) {
            i && f(e)
        }
    }
}

function Xr(o) {
    let e, i;
    return e = new ie({
        props: {
            value: o[1],
            currency: o[2]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 2 && (r.value = n[1]), t & 4 && (r.currency = n[2]), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Qr(o) {
    let e = o[5] + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 16 && e !== (e = n[5] + "") && O(i, e)
        },
        i: A,
        o: A,
        d(n) {
            n && f(i)
        }
    }
}

function Xn(o) {
    let e, i, n, t;
    const r = [Qr, Xr, Zr],
        a = [];

    function s(l, u) {
        return typeof l[5] == "string" ? 0 : l[5][0] === "value" ? 1 : l[5][0] === "legs" ? 2 : -1
    }
    return ~(e = s(o)) && (i = a[e] = r[e](o)), {
        c() {
            i && i.c(), n = h()
        },
        l(l) {
            i && i.l(l), n = h()
        },
        m(l, u) {
            ~e && a[e].m(l, u), k(l, n, u), t = !0
        },
        p(l, u) {
            let c = e;
            e = s(l), e === c ? ~e && a[e].p(l, u) : (i && (y(), m(a[c], 1, 1, () => {
                a[c] = null
            }), w()), ~e ? (i = a[e], i ? i.p(l, u) : (i = a[e] = r[e](l), i.c()), d(i, 1), i.m(n.parentNode, n)) : i = null)
        },
        i(l) {
            t || (d(i), t = !0)
        },
        o(l) {
            m(i), t = !1
        },
        d(l) {
            l && f(n), ~e && a[e].d(l)
        }
    }
}

function Jr(o) {
    let e, i, n, t;
    const r = [Kr, qr],
        a = [];

    function s(l, u) {
        return l[1] === 0 ? 0 : l[4] ? 1 : -1
    }
    return ~(e = s(o)) && (i = a[e] = r[e](o)), {
        c() {
            i && i.c(), n = h()
        },
        l(l) {
            i && i.l(l), n = h()
        },
        m(l, u) {
            ~e && a[e].m(l, u), k(l, n, u), t = !0
        },
        p(l, [u]) {
            let c = e;
            e = s(l), e === c ? ~e && a[e].p(l, u) : (i && (y(), m(a[c], 1, 1, () => {
                a[c] = null
            }), w()), ~e ? (i = a[e], i ? i.p(l, u) : (i = a[e] = r[e](l), i.c()), d(i, 1), i.m(n.parentNode, n)) : i = null)
        },
        i(l) {
            t || (d(i), t = !0)
        },
        o(l) {
            m(i), t = !1
        },
        d(l) {
            l && f(n), ~e && a[e].d(l)
        }
    }
}

function xr(o, e, i) {
    let n, t;
    j(o, x, l => i(3, t = l));
    let {
        legs: r
    } = e, {
        amount: a
    } = e, {
        currency: s
    } = e;
    return o.$$set = l => {
        "legs" in l && i(0, r = l.legs), "amount" in l && i(1, a = l.amount), "currency" in l && i(2, s = l.currency)
    }, o.$$.update = () => {
        o.$$.dirty & 8 && i(4, n = t.message(tn.betWon.id))
    }, [r, a, s, t, n]
}
let eo = class extends q {
    constructor(e) {
        super(), K(this, e, xr, Jr, Y, {
            legs: 0,
            amount: 1,
            currency: 2
        })
    }
};
const Qe = o => ({
        title: p._("Multi Bet Settled"),
        body: eo,
        props: o,
        icon: oe,
        sound: "money",
        type: "positive",
        click: () => {
            me.bet.open({
                betId: o == null ? void 0 : o.betId
            })
        }
    }),
    no = {
        content: {
            id: "Your single bet worth {amount} has been refunded."
        }
    };

function Qn(o, e, i) {
    const n = o.slice();
    return n[4] = e[i], n
}

function Jn(o) {
    let e, i, n = Z(o[2]),
        t = [];
    for (let a = 0; a < n.length; a += 1) t[a] = xn(Qn(o, n, a));
    const r = a => m(t[a], 1, 1, () => {
        t[a] = null
    });
    return {
        c() {
            e = T("span");
            for (let a = 0; a < t.length; a += 1) t[a].c()
        },
        l(a) {
            e = I(a, "SPAN", {});
            var s = B(e);
            for (let l = 0; l < t.length; l += 1) t[l].l(s);
            s.forEach(f)
        },
        m(a, s) {
            k(a, e, s);
            for (let l = 0; l < t.length; l += 1) t[l] && t[l].m(e, null);
            i = !0
        },
        p(a, s) {
            if (s & 7) {
                n = Z(a[2]);
                let l;
                for (l = 0; l < n.length; l += 1) {
                    const u = Qn(a, n, l);
                    t[l] ? (t[l].p(u, s), d(t[l], 1)) : (t[l] = xn(u), t[l].c(), d(t[l], 1), t[l].m(e, null))
                }
                for (y(), l = n.length; l < t.length; l += 1) r(l);
                w()
            }
        },
        i(a) {
            if (!i) {
                for (let s = 0; s < n.length; s += 1) d(t[s]);
                i = !0
            }
        },
        o(a) {
            t = t.filter(Boolean);
            for (let s = 0; s < t.length; s += 1) m(t[s]);
            i = !1
        },
        d(a) {
            a && f(e), te(t, a)
        }
    }
}

function to(o) {
    let e, i;
    return e = new ie({
        props: {
            value: o[0],
            currency: o[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 1 && (r.value = n[0]), t & 2 && (r.currency = n[1]), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function io(o) {
    let e = o[4] + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 4 && e !== (e = n[4] + "") && O(i, e)
        },
        i: A,
        o: A,
        d(n) {
            n && f(i)
        }
    }
}

function xn(o) {
    let e, i, n, t;
    const r = [io, to],
        a = [];

    function s(l, u) {
        return typeof l[4] == "string" ? 0 : l[4][0] === "amount" ? 1 : -1
    }
    return ~(e = s(o)) && (i = a[e] = r[e](o)), {
        c() {
            i && i.c(), n = h()
        },
        l(l) {
            i && i.l(l), n = h()
        },
        m(l, u) {
            ~e && a[e].m(l, u), k(l, n, u), t = !0
        },
        p(l, u) {
            let c = e;
            e = s(l), e === c ? ~e && a[e].p(l, u) : (i && (y(), m(a[c], 1, 1, () => {
                a[c] = null
            }), w()), ~e ? (i = a[e], i ? i.p(l, u) : (i = a[e] = r[e](l), i.c()), d(i, 1), i.m(n.parentNode, n)) : i = null)
        },
        i(l) {
            t || (d(i), t = !0)
        },
        o(l) {
            m(i), t = !1
        },
        d(l) {
            l && f(n), ~e && a[e].d(l)
        }
    }
}

function lo(o) {
    let e, i, n = o[2] && Jn(o);
    return {
        c() {
            n && n.c(), e = h()
        },
        l(t) {
            n && n.l(t), e = h()
        },
        m(t, r) {
            n && n.m(t, r), k(t, e, r), i = !0
        },
        p(t, [r]) {
            t[2] ? n ? (n.p(t, r), r & 4 && d(n, 1)) : (n = Jn(t), n.c(), d(n, 1), n.m(e.parentNode, e)) : n && (y(), m(n, 1, 1, () => {
                n = null
            }), w())
        },
        i(t) {
            i || (d(n), i = !0)
        },
        o(t) {
            m(n), i = !1
        },
        d(t) {
            t && f(e), n && n.d(t)
        }
    }
}

function ao(o, e, i) {
    let n, t;
    j(o, x, s => i(3, t = s));
    let {
        amount: r
    } = e, {
        currency: a
    } = e;
    return o.$$set = s => {
        "amount" in s && i(0, r = s.amount), "currency" in s && i(1, a = s.currency)
    }, o.$$.update = () => {
        o.$$.dirty & 8 && i(2, n = t.message(no.content.id))
    }, [r, a, n, t]
}
let ro = class extends q {
    constructor(e) {
        super(), K(this, e, ao, lo, Y, {
            amount: 0,
            currency: 1
        })
    }
};
const oo = o => ({
        title: p._("Single Bet Refunded"),
        body: ro,
        props: o,
        icon: oe,
        sound: "money",
        type: "positive"
    }),
    fn = {
        title: {
            id: "Deposit Pending"
        },
        content: {
            id: "Your deposit using {amount} is registered and awaiting confirmation."
        }
    },
    so = { ...fn,
        title: {
            id: "Purchase Pending"
        },
        content: {
            id: "Your bundle purchase using {amount} is registered and awaiting confirmation."
        }
    },
    uo = {
        stake: fn,
        sweeps: so
    },
    Pi = uo[Te] || fn;

function et(o, e, i) {
    const n = o.slice();
    return n[4] = e[i], n
}

function nt(o) {
    let e, i, n = Z(o[2]),
        t = [];
    for (let a = 0; a < n.length; a += 1) t[a] = tt(et(o, n, a));
    const r = a => m(t[a], 1, 1, () => {
        t[a] = null
    });
    return {
        c() {
            e = T("span");
            for (let a = 0; a < t.length; a += 1) t[a].c()
        },
        l(a) {
            e = I(a, "SPAN", {});
            var s = B(e);
            for (let l = 0; l < t.length; l += 1) t[l].l(s);
            s.forEach(f)
        },
        m(a, s) {
            k(a, e, s);
            for (let l = 0; l < t.length; l += 1) t[l] && t[l].m(e, null);
            i = !0
        },
        p(a, s) {
            if (s & 7) {
                n = Z(a[2]);
                let l;
                for (l = 0; l < n.length; l += 1) {
                    const u = et(a, n, l);
                    t[l] ? (t[l].p(u, s), d(t[l], 1)) : (t[l] = tt(u), t[l].c(), d(t[l], 1), t[l].m(e, null))
                }
                for (y(), l = n.length; l < t.length; l += 1) r(l);
                w()
            }
        },
        i(a) {
            if (!i) {
                for (let s = 0; s < n.length; s += 1) d(t[s]);
                i = !0
            }
        },
        o(a) {
            t = t.filter(Boolean);
            for (let s = 0; s < t.length; s += 1) m(t[s]);
            i = !1
        },
        d(a) {
            a && f(e), te(t, a)
        }
    }
}

function co(o) {
    let e, i;
    return e = new ie({
        props: {
            value: o[0],
            currency: o[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 1 && (r.value = n[0]), t & 2 && (r.currency = n[1]), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function mo(o) {
    let e = o[4] + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 4 && e !== (e = n[4] + "") && O(i, e)
        },
        i: A,
        o: A,
        d(n) {
            n && f(i)
        }
    }
}

function tt(o) {
    let e, i, n, t;
    const r = [mo, co],
        a = [];

    function s(l, u) {
        return typeof l[4] == "string" ? 0 : l[4][0] === "amount" ? 1 : -1
    }
    return ~(e = s(o)) && (i = a[e] = r[e](o)), {
        c() {
            i && i.c(), n = h()
        },
        l(l) {
            i && i.l(l), n = h()
        },
        m(l, u) {
            ~e && a[e].m(l, u), k(l, n, u), t = !0
        },
        p(l, u) {
            let c = e;
            e = s(l), e === c ? ~e && a[e].p(l, u) : (i && (y(), m(a[c], 1, 1, () => {
                a[c] = null
            }), w()), ~e ? (i = a[e], i ? i.p(l, u) : (i = a[e] = r[e](l), i.c()), d(i, 1), i.m(n.parentNode, n)) : i = null)
        },
        i(l) {
            t || (d(i), t = !0)
        },
        o(l) {
            m(i), t = !1
        },
        d(l) {
            l && f(n), ~e && a[e].d(l)
        }
    }
}

function fo(o) {
    let e, i, n = o[2] && nt(o);
    return {
        c() {
            n && n.c(), e = h()
        },
        l(t) {
            n && n.l(t), e = h()
        },
        m(t, r) {
            n && n.m(t, r), k(t, e, r), i = !0
        },
        p(t, [r]) {
            t[2] ? n ? (n.p(t, r), r & 4 && d(n, 1)) : (n = nt(t), n.c(), d(n, 1), n.m(e.parentNode, e)) : n && (y(), m(n, 1, 1, () => {
                n = null
            }), w())
        },
        i(t) {
            i || (d(n), i = !0)
        },
        o(t) {
            m(n), i = !1
        },
        d(t) {
            t && f(e), n && n.d(t)
        }
    }
}

function ko(o, e, i) {
    let n, t;
    j(o, x, s => i(3, t = s));
    let {
        amount: r
    } = e, {
        currency: a
    } = e;
    return o.$$set = s => {
        "amount" in s && i(0, r = s.amount), "currency" in s && i(1, a = s.currency)
    }, o.$$.update = () => {
        o.$$.dirty & 8 && i(2, n = t.message(Pi.content.id))
    }, [r, a, n, t]
}
let _o = class extends q {
    constructor(e) {
        super(), K(this, e, ko, fo, Y, {
            amount: 0,
            currency: 1
        })
    }
};
const po = o => ({
        title: Pi.title,
        body: _o,
        props: o,
        icon: oe,
        sound: "money",
        type: "positive"
    }),
    Di = {
        title: p._("Deposit Process Initiated"),
        content: {
            id: "Your deposit of {amount} has been initiated."
        }
    };

function it(o, e, i) {
    const n = o.slice();
    return n[4] = e[i], n
}

function lt(o) {
    let e, i, n = Z(o[2]),
        t = [];
    for (let a = 0; a < n.length; a += 1) t[a] = at(it(o, n, a));
    const r = a => m(t[a], 1, 1, () => {
        t[a] = null
    });
    return {
        c() {
            e = T("span");
            for (let a = 0; a < t.length; a += 1) t[a].c()
        },
        l(a) {
            e = I(a, "SPAN", {});
            var s = B(e);
            for (let l = 0; l < t.length; l += 1) t[l].l(s);
            s.forEach(f)
        },
        m(a, s) {
            k(a, e, s);
            for (let l = 0; l < t.length; l += 1) t[l] && t[l].m(e, null);
            i = !0
        },
        p(a, s) {
            if (s & 7) {
                n = Z(a[2]);
                let l;
                for (l = 0; l < n.length; l += 1) {
                    const u = it(a, n, l);
                    t[l] ? (t[l].p(u, s), d(t[l], 1)) : (t[l] = at(u), t[l].c(), d(t[l], 1), t[l].m(e, null))
                }
                for (y(), l = n.length; l < t.length; l += 1) r(l);
                w()
            }
        },
        i(a) {
            if (!i) {
                for (let s = 0; s < n.length; s += 1) d(t[s]);
                i = !0
            }
        },
        o(a) {
            t = t.filter(Boolean);
            for (let s = 0; s < t.length; s += 1) m(t[s]);
            i = !1
        },
        d(a) {
            a && f(e), te(t, a)
        }
    }
}

function go(o) {
    let e, i;
    return e = new ie({
        props: {
            value: o[0],
            currency: o[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 1 && (r.value = n[0]), t & 2 && (r.currency = n[1]), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function $o(o) {
    let e = o[4] + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 4 && e !== (e = n[4] + "") && O(i, e)
        },
        i: A,
        o: A,
        d(n) {
            n && f(i)
        }
    }
}

function at(o) {
    let e, i, n, t;
    const r = [$o, go],
        a = [];

    function s(l, u) {
        return typeof l[4] == "string" ? 0 : l[4][0] === "amount" ? 1 : -1
    }
    return ~(e = s(o)) && (i = a[e] = r[e](o)), {
        c() {
            i && i.c(), n = h()
        },
        l(l) {
            i && i.l(l), n = h()
        },
        m(l, u) {
            ~e && a[e].m(l, u), k(l, n, u), t = !0
        },
        p(l, u) {
            let c = e;
            e = s(l), e === c ? ~e && a[e].p(l, u) : (i && (y(), m(a[c], 1, 1, () => {
                a[c] = null
            }), w()), ~e ? (i = a[e], i ? i.p(l, u) : (i = a[e] = r[e](l), i.c()), d(i, 1), i.m(n.parentNode, n)) : i = null)
        },
        i(l) {
            t || (d(i), t = !0)
        },
        o(l) {
            m(i), t = !1
        },
        d(l) {
            l && f(n), ~e && a[e].d(l)
        }
    }
}

function vo(o) {
    let e, i, n = o[2] && lt(o);
    return {
        c() {
            n && n.c(), e = h()
        },
        l(t) {
            n && n.l(t), e = h()
        },
        m(t, r) {
            n && n.m(t, r), k(t, e, r), i = !0
        },
        p(t, [r]) {
            t[2] ? n ? (n.p(t, r), r & 4 && d(n, 1)) : (n = lt(t), n.c(), d(n, 1), n.m(e.parentNode, e)) : n && (y(), m(n, 1, 1, () => {
                n = null
            }), w())
        },
        i(t) {
            i || (d(n), i = !0)
        },
        o(t) {
            m(n), i = !1
        },
        d(t) {
            t && f(e), n && n.d(t)
        }
    }
}

function No(o, e, i) {
    let n, t;
    j(o, x, s => i(3, t = s));
    let {
        amount: r
    } = e, {
        currency: a
    } = e;
    return o.$$set = s => {
        "amount" in s && i(0, r = s.amount), "currency" in s && i(1, a = s.currency)
    }, o.$$.update = () => {
        o.$$.dirty & 8 && i(2, n = t.message(Di.content.id))
    }, [r, a, n, t]
}
let ho = class extends q {
    constructor(e) {
        super(), K(this, e, No, vo, Y, {
            amount: 0,
            currency: 1
        })
    }
};
const So = o => ({
        title: Di.title,
        body: ho,
        props: o,
        icon: oe,
        sound: "money",
        type: "positive"
    }),
    Ri = {
        title: p._("Deposit Confirmed"),
        content: {
            id: "Your deposit of {amount} has been successfully processed."
        }
    };

function rt(o, e, i) {
    const n = o.slice();
    return n[4] = e[i], n
}

function ot(o) {
    let e, i, n = Z(o[2]),
        t = [];
    for (let a = 0; a < n.length; a += 1) t[a] = st(rt(o, n, a));
    const r = a => m(t[a], 1, 1, () => {
        t[a] = null
    });
    return {
        c() {
            e = T("span");
            for (let a = 0; a < t.length; a += 1) t[a].c()
        },
        l(a) {
            e = I(a, "SPAN", {});
            var s = B(e);
            for (let l = 0; l < t.length; l += 1) t[l].l(s);
            s.forEach(f)
        },
        m(a, s) {
            k(a, e, s);
            for (let l = 0; l < t.length; l += 1) t[l] && t[l].m(e, null);
            i = !0
        },
        p(a, s) {
            if (s & 7) {
                n = Z(a[2]);
                let l;
                for (l = 0; l < n.length; l += 1) {
                    const u = rt(a, n, l);
                    t[l] ? (t[l].p(u, s), d(t[l], 1)) : (t[l] = st(u), t[l].c(), d(t[l], 1), t[l].m(e, null))
                }
                for (y(), l = n.length; l < t.length; l += 1) r(l);
                w()
            }
        },
        i(a) {
            if (!i) {
                for (let s = 0; s < n.length; s += 1) d(t[s]);
                i = !0
            }
        },
        o(a) {
            t = t.filter(Boolean);
            for (let s = 0; s < t.length; s += 1) m(t[s]);
            i = !1
        },
        d(a) {
            a && f(e), te(t, a)
        }
    }
}

function bo(o) {
    let e, i;
    return e = new ie({
        props: {
            value: o[0],
            currency: o[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 1 && (r.value = n[0]), t & 2 && (r.currency = n[1]), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Fo(o) {
    let e = o[4] + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 4 && e !== (e = n[4] + "") && O(i, e)
        },
        i: A,
        o: A,
        d(n) {
            n && f(i)
        }
    }
}

function st(o) {
    let e, i, n, t;
    const r = [Fo, bo],
        a = [];

    function s(l, u) {
        return typeof l[4] == "string" ? 0 : l[4][0] === "amount" && l[1] ? 1 : -1
    }
    return ~(e = s(o)) && (i = a[e] = r[e](o)), {
        c() {
            i && i.c(), n = h()
        },
        l(l) {
            i && i.l(l), n = h()
        },
        m(l, u) {
            ~e && a[e].m(l, u), k(l, n, u), t = !0
        },
        p(l, u) {
            let c = e;
            e = s(l), e === c ? ~e && a[e].p(l, u) : (i && (y(), m(a[c], 1, 1, () => {
                a[c] = null
            }), w()), ~e ? (i = a[e], i ? i.p(l, u) : (i = a[e] = r[e](l), i.c()), d(i, 1), i.m(n.parentNode, n)) : i = null)
        },
        i(l) {
            t || (d(i), t = !0)
        },
        o(l) {
            m(i), t = !1
        },
        d(l) {
            l && f(n), ~e && a[e].d(l)
        }
    }
}

function yo(o) {
    let e, i, n = o[2] && ot(o);
    return {
        c() {
            n && n.c(), e = h()
        },
        l(t) {
            n && n.l(t), e = h()
        },
        m(t, r) {
            n && n.m(t, r), k(t, e, r), i = !0
        },
        p(t, [r]) {
            t[2] ? n ? (n.p(t, r), r & 4 && d(n, 1)) : (n = ot(t), n.c(), d(n, 1), n.m(e.parentNode, e)) : n && (y(), m(n, 1, 1, () => {
                n = null
            }), w())
        },
        i(t) {
            i || (d(n), i = !0)
        },
        o(t) {
            m(n), i = !1
        },
        d(t) {
            t && f(e), n && n.d(t)
        }
    }
}

function wo(o, e, i) {
    let n, t;
    j(o, x, s => i(3, t = s));
    let {
        amount: r
    } = e, {
        currency: a
    } = e;
    return o.$$set = s => {
        "amount" in s && i(0, r = s.amount), "currency" in s && i(1, a = s.currency)
    }, o.$$.update = () => {
        o.$$.dirty & 8 && i(2, n = t.message(Ri.content.id))
    }, [r, a, n, t]
}
let Co = class extends q {
    constructor(e) {
        super(), K(this, e, wo, yo, Y, {
            amount: 0,
            currency: 1
        })
    }
};
const Ao = o => ({
        title: Ri.title,
        body: Co,
        props: o,
        icon: oe,
        sound: "money",
        type: "positive"
    }),
    Vi = {
        title: p._("Withdrawal Process Initiated"),
        content: {
            id: "Your withdrawal of {amount} has been initiated."
        }
    };

function ut(o, e, i) {
    const n = o.slice();
    return n[4] = e[i], n
}

function ct(o) {
    let e, i, n = Z(o[2]),
        t = [];
    for (let a = 0; a < n.length; a += 1) t[a] = dt(ut(o, n, a));
    const r = a => m(t[a], 1, 1, () => {
        t[a] = null
    });
    return {
        c() {
            e = T("span");
            for (let a = 0; a < t.length; a += 1) t[a].c()
        },
        l(a) {
            e = I(a, "SPAN", {});
            var s = B(e);
            for (let l = 0; l < t.length; l += 1) t[l].l(s);
            s.forEach(f)
        },
        m(a, s) {
            k(a, e, s);
            for (let l = 0; l < t.length; l += 1) t[l] && t[l].m(e, null);
            i = !0
        },
        p(a, s) {
            if (s & 7) {
                n = Z(a[2]);
                let l;
                for (l = 0; l < n.length; l += 1) {
                    const u = ut(a, n, l);
                    t[l] ? (t[l].p(u, s), d(t[l], 1)) : (t[l] = dt(u), t[l].c(), d(t[l], 1), t[l].m(e, null))
                }
                for (y(), l = n.length; l < t.length; l += 1) r(l);
                w()
            }
        },
        i(a) {
            if (!i) {
                for (let s = 0; s < n.length; s += 1) d(t[s]);
                i = !0
            }
        },
        o(a) {
            t = t.filter(Boolean);
            for (let s = 0; s < t.length; s += 1) m(t[s]);
            i = !1
        },
        d(a) {
            a && f(e), te(t, a)
        }
    }
}

function To(o) {
    let e, i;
    return e = new ie({
        props: {
            value: o[0],
            currency: o[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 1 && (r.value = n[0]), t & 2 && (r.currency = n[1]), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Io(o) {
    let e = o[4] + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 4 && e !== (e = n[4] + "") && O(i, e)
        },
        i: A,
        o: A,
        d(n) {
            n && f(i)
        }
    }
}

function dt(o) {
    let e, i, n, t;
    const r = [Io, To],
        a = [];

    function s(l, u) {
        return typeof l[4] == "string" ? 0 : l[4][0] === "amount" ? 1 : -1
    }
    return ~(e = s(o)) && (i = a[e] = r[e](o)), {
        c() {
            i && i.c(), n = h()
        },
        l(l) {
            i && i.l(l), n = h()
        },
        m(l, u) {
            ~e && a[e].m(l, u), k(l, n, u), t = !0
        },
        p(l, u) {
            let c = e;
            e = s(l), e === c ? ~e && a[e].p(l, u) : (i && (y(), m(a[c], 1, 1, () => {
                a[c] = null
            }), w()), ~e ? (i = a[e], i ? i.p(l, u) : (i = a[e] = r[e](l), i.c()), d(i, 1), i.m(n.parentNode, n)) : i = null)
        },
        i(l) {
            t || (d(i), t = !0)
        },
        o(l) {
            m(i), t = !1
        },
        d(l) {
            l && f(n), ~e && a[e].d(l)
        }
    }
}

function Bo(o) {
    let e, i, n = o[2] && ct(o);
    return {
        c() {
            n && n.c(), e = h()
        },
        l(t) {
            n && n.l(t), e = h()
        },
        m(t, r) {
            n && n.m(t, r), k(t, e, r), i = !0
        },
        p(t, [r]) {
            t[2] ? n ? (n.p(t, r), r & 4 && d(n, 1)) : (n = ct(t), n.c(), d(n, 1), n.m(e.parentNode, e)) : n && (y(), m(n, 1, 1, () => {
                n = null
            }), w())
        },
        i(t) {
            i || (d(n), i = !0)
        },
        o(t) {
            m(n), i = !1
        },
        d(t) {
            t && f(e), n && n.d(t)
        }
    }
}

function Eo(o, e, i) {
    let n, t;
    j(o, x, s => i(3, t = s));
    let {
        amount: r
    } = e, {
        currency: a
    } = e;
    return o.$$set = s => {
        "amount" in s && i(0, r = s.amount), "currency" in s && i(1, a = s.currency)
    }, o.$$.update = () => {
        o.$$.dirty & 8 && i(2, n = t.message(Vi.content.id))
    }, [r, a, n, t]
}
let Po = class extends q {
    constructor(e) {
        super(), K(this, e, Eo, Bo, Y, {
            amount: 0,
            currency: 1
        })
    }
};
const Do = o => ({
        title: Vi.title,
        body: Po,
        props: o,
        icon: oe,
        sound: "money",
        type: "positive"
    }),
    Mi = {
        title: p._("Withdrawal Confirmed"),
        content: {
            id: "Your withdrawal of {amount} has been successfully processed."
        }
    };

function mt(o, e, i) {
    const n = o.slice();
    return n[4] = e[i], n
}

function ft(o) {
    let e, i, n = Z(o[2]),
        t = [];
    for (let a = 0; a < n.length; a += 1) t[a] = kt(mt(o, n, a));
    const r = a => m(t[a], 1, 1, () => {
        t[a] = null
    });
    return {
        c() {
            e = T("span");
            for (let a = 0; a < t.length; a += 1) t[a].c()
        },
        l(a) {
            e = I(a, "SPAN", {});
            var s = B(e);
            for (let l = 0; l < t.length; l += 1) t[l].l(s);
            s.forEach(f)
        },
        m(a, s) {
            k(a, e, s);
            for (let l = 0; l < t.length; l += 1) t[l] && t[l].m(e, null);
            i = !0
        },
        p(a, s) {
            if (s & 7) {
                n = Z(a[2]);
                let l;
                for (l = 0; l < n.length; l += 1) {
                    const u = mt(a, n, l);
                    t[l] ? (t[l].p(u, s), d(t[l], 1)) : (t[l] = kt(u), t[l].c(), d(t[l], 1), t[l].m(e, null))
                }
                for (y(), l = n.length; l < t.length; l += 1) r(l);
                w()
            }
        },
        i(a) {
            if (!i) {
                for (let s = 0; s < n.length; s += 1) d(t[s]);
                i = !0
            }
        },
        o(a) {
            t = t.filter(Boolean);
            for (let s = 0; s < t.length; s += 1) m(t[s]);
            i = !1
        },
        d(a) {
            a && f(e), te(t, a)
        }
    }
}

function Ro(o) {
    let e, i;
    return e = new ie({
        props: {
            value: o[0],
            currency: o[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 1 && (r.value = n[0]), t & 2 && (r.currency = n[1]), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Vo(o) {
    let e = o[4] + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 4 && e !== (e = n[4] + "") && O(i, e)
        },
        i: A,
        o: A,
        d(n) {
            n && f(i)
        }
    }
}

function kt(o) {
    let e, i, n, t;
    const r = [Vo, Ro],
        a = [];

    function s(l, u) {
        return typeof l[4] == "string" ? 0 : l[4][0] === "amount" && l[1] ? 1 : -1
    }
    return ~(e = s(o)) && (i = a[e] = r[e](o)), {
        c() {
            i && i.c(), n = h()
        },
        l(l) {
            i && i.l(l), n = h()
        },
        m(l, u) {
            ~e && a[e].m(l, u), k(l, n, u), t = !0
        },
        p(l, u) {
            let c = e;
            e = s(l), e === c ? ~e && a[e].p(l, u) : (i && (y(), m(a[c], 1, 1, () => {
                a[c] = null
            }), w()), ~e ? (i = a[e], i ? i.p(l, u) : (i = a[e] = r[e](l), i.c()), d(i, 1), i.m(n.parentNode, n)) : i = null)
        },
        i(l) {
            t || (d(i), t = !0)
        },
        o(l) {
            m(i), t = !1
        },
        d(l) {
            l && f(n), ~e && a[e].d(l)
        }
    }
}

function Mo(o) {
    let e, i, n = o[2] && ft(o);
    return {
        c() {
            n && n.c(), e = h()
        },
        l(t) {
            n && n.l(t), e = h()
        },
        m(t, r) {
            n && n.m(t, r), k(t, e, r), i = !0
        },
        p(t, [r]) {
            t[2] ? n ? (n.p(t, r), r & 4 && d(n, 1)) : (n = ft(t), n.c(), d(n, 1), n.m(e.parentNode, e)) : n && (y(), m(n, 1, 1, () => {
                n = null
            }), w())
        },
        i(t) {
            i || (d(n), i = !0)
        },
        o(t) {
            m(n), i = !1
        },
        d(t) {
            t && f(e), n && n.d(t)
        }
    }
}

function Oo(o, e, i) {
    let n, t;
    j(o, x, s => i(3, t = s));
    let {
        amount: r
    } = e, {
        currency: a
    } = e;
    return o.$$set = s => {
        "amount" in s && i(0, r = s.amount), "currency" in s && i(1, a = s.currency)
    }, o.$$.update = () => {
        o.$$.dirty & 8 && i(2, n = t.message(Mi.content.id))
    }, [r, a, n, t]
}
let Lo = class extends q {
    constructor(e) {
        super(), K(this, e, Oo, Mo, Y, {
            amount: 0,
            currency: 1
        })
    }
};
const Uo = o => ({
        title: Mi.title,
        body: Lo,
        props: o,
        icon: oe,
        sound: "money",
        type: "positive"
    }),
    Wo = o => ({
        title: p._("Postcard Code"),
        body: {
            id: "The postcard code {code} has been claimed.",
            values: {
                code: o.code
            }
        },
        icon: El
    }),
    _t = {
        content: {
            id: 'You won {prize} from the challenge "{description}" of {game}'
        },
        casino: p._("Casino")
    };

function pt(o, e, i) {
    const n = o.slice();
    return n[4] = e[i], n
}

function gt(o) {
    let e, i, n = Z(o[2]),
        t = [];
    for (let a = 0; a < n.length; a += 1) t[a] = $t(pt(o, n, a));
    const r = a => m(t[a], 1, 1, () => {
        t[a] = null
    });
    return {
        c() {
            e = T("span");
            for (let a = 0; a < t.length; a += 1) t[a].c()
        },
        l(a) {
            e = I(a, "SPAN", {});
            var s = B(e);
            for (let l = 0; l < t.length; l += 1) t[l].l(s);
            s.forEach(f)
        },
        m(a, s) {
            k(a, e, s);
            for (let l = 0; l < t.length; l += 1) t[l] && t[l].m(e, null);
            i = !0
        },
        p(a, s) {
            if (s & 7) {
                n = Z(a[2]);
                let l;
                for (l = 0; l < n.length; l += 1) {
                    const u = pt(a, n, l);
                    t[l] ? (t[l].p(u, s), d(t[l], 1)) : (t[l] = $t(u), t[l].c(), d(t[l], 1), t[l].m(e, null))
                }
                for (y(), l = n.length; l < t.length; l += 1) r(l);
                w()
            }
        },
        i(a) {
            if (!i) {
                for (let s = 0; s < n.length; s += 1) d(t[s]);
                i = !0
            }
        },
        o(a) {
            t = t.filter(Boolean);
            for (let s = 0; s < t.length; s += 1) m(t[s]);
            i = !1
        },
        d(a) {
            a && f(e), te(t, a)
        }
    }
}

function zo(o) {
    let e, i;
    return e = new ie({
        props: {
            value: o[0].award,
            currency: o[0].currency
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 1 && (r.value = n[0].award), t & 1 && (r.currency = n[0].currency), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Go(o) {
    let e;
    return {
        c() {
            e = P(o[1])
        },
        l(i) {
            e = D(i, o[1])
        },
        m(i, n) {
            k(i, e, n)
        },
        p(i, n) {
            n & 2 && O(e, i[1])
        },
        i: A,
        o: A,
        d(i) {
            i && f(e)
        }
    }
}

function jo(o) {
    let e, i;
    return e = new Vl({
        props: {
            targetMultiplier: o[0].targetMultiplier,
            betCurrency: o[0].betCurrency,
            minBetUsd: o[0].minBetUsd
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 1 && (r.targetMultiplier = n[0].targetMultiplier), t & 1 && (r.betCurrency = n[0].betCurrency), t & 1 && (r.minBetUsd = n[0].minBetUsd), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Ho(o) {
    let e = o[4] + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 4 && e !== (e = n[4] + "") && O(i, e)
        },
        i: A,
        o: A,
        d(n) {
            n && f(i)
        }
    }
}

function $t(o) {
    let e, i, n, t;
    const r = [Ho, jo, Go, zo],
        a = [];

    function s(l, u) {
        return typeof l[4] == "string" ? 0 : l[4][0] === "description" ? 1 : l[4][0] === "game" ? 2 : l[4][0] === "prize" ? 3 : -1
    }
    return ~(e = s(o)) && (i = a[e] = r[e](o)), {
        c() {
            i && i.c(), n = h()
        },
        l(l) {
            i && i.l(l), n = h()
        },
        m(l, u) {
            ~e && a[e].m(l, u), k(l, n, u), t = !0
        },
        p(l, u) {
            let c = e;
            e = s(l), e === c ? ~e && a[e].p(l, u) : (i && (y(), m(a[c], 1, 1, () => {
                a[c] = null
            }), w()), ~e ? (i = a[e], i ? i.p(l, u) : (i = a[e] = r[e](l), i.c()), d(i, 1), i.m(n.parentNode, n)) : i = null)
        },
        i(l) {
            t || (d(i), t = !0)
        },
        o(l) {
            m(i), t = !1
        },
        d(l) {
            l && f(n), ~e && a[e].d(l)
        }
    }
}

function Yo(o) {
    let e, i, n = o[2] && gt(o);
    return {
        c() {
            n && n.c(), e = h()
        },
        l(t) {
            n && n.l(t), e = h()
        },
        m(t, r) {
            n && n.m(t, r), k(t, e, r), i = !0
        },
        p(t, [r]) {
            t[2] ? n ? (n.p(t, r), r & 4 && d(n, 1)) : (n = gt(t), n.c(), d(n, 1), n.m(e.parentNode, e)) : n && (y(), m(n, 1, 1, () => {
                n = null
            }), w())
        },
        i(t) {
            i || (d(n), i = !0)
        },
        o(t) {
            m(n), i = !1
        },
        d(t) {
            t && f(e), n && n.d(t)
        }
    }
}

function qo(o, e, i) {
    let n, t, r;
    j(o, x, s => i(3, r = s));
    let {
        challenge: a
    } = e;
    return o.$$set = s => {
        "challenge" in s && i(0, a = s.challenge)
    }, o.$$.update = () => {
        var s, l;
        o.$$.dirty & 8 && i(2, n = r.message(_t.content.id)), o.$$.dirty & 9 && i(1, t = (s = a.game) != null && s.name ? Rl(((l = a.game) == null ? void 0 : l.name) ? ? "") : r._(_t.casino))
    }, [a, t, n, r]
}
let Ko = class extends q {
    constructor(e) {
        super(), K(this, e, qo, Yo, Y, {
            challenge: 0
        })
    }
};
const vt = o => ({
        title: p._("Challenge Won"),
        body: Ko,
        props: {
            createdAt: o.challenge.createdAt,
            ...o
        },
        icon: Ml,
        sound: "money"
    }),
    ln = {
        disQualified: o => ({
            id: "Your bet did not qualify for a promotion {promotionName}.",
            values: {
                promotionName: o
            }
        }),
        qualified: {
            id: "Your {value} bet qualified for a promotion {promotionName}. {payout} has been credited into your account."
        }
    };

function Nt(o, e, i) {
    const n = o.slice();
    return n[6] = e[i], n
}

function Zo(o) {
    let e, i, n = Z(o[5]),
        t = [];
    for (let a = 0; a < n.length; a += 1) t[a] = ht(Nt(o, n, a));
    const r = a => m(t[a], 1, 1, () => {
        t[a] = null
    });
    return {
        c() {
            e = T("span");
            for (let a = 0; a < t.length; a += 1) t[a].c()
        },
        l(a) {
            e = I(a, "SPAN", {});
            var s = B(e);
            for (let l = 0; l < t.length; l += 1) t[l].l(s);
            s.forEach(f)
        },
        m(a, s) {
            k(a, e, s);
            for (let l = 0; l < t.length; l += 1) t[l] && t[l].m(e, null);
            i = !0
        },
        p(a, s) {
            if (s & 47) {
                n = Z(a[5]);
                let l;
                for (l = 0; l < n.length; l += 1) {
                    const u = Nt(a, n, l);
                    t[l] ? (t[l].p(u, s), d(t[l], 1)) : (t[l] = ht(u), t[l].c(), d(t[l], 1), t[l].m(e, null))
                }
                for (y(), l = n.length; l < t.length; l += 1) r(l);
                w()
            }
        },
        i(a) {
            if (!i) {
                for (let s = 0; s < n.length; s += 1) d(t[s]);
                i = !0
            }
        },
        o(a) {
            t = t.filter(Boolean);
            for (let s = 0; s < t.length; s += 1) m(t[s]);
            i = !1
        },
        d(a) {
            a && f(e), te(t, a)
        }
    }
}

function Xo(o) {
    let e, i = o[4]._(ln.disQualified(o[3])) + "",
        n;
    return {
        c() {
            e = T("span"), n = P(i)
        },
        l(t) {
            e = I(t, "SPAN", {});
            var r = B(e);
            n = D(r, i), r.forEach(f)
        },
        m(t, r) {
            k(t, e, r), z(e, n)
        },
        p(t, r) {
            r & 24 && i !== (i = t[4]._(ln.disQualified(t[3])) + "") && O(n, i)
        },
        i: A,
        o: A,
        d(t) {
            t && f(e)
        }
    }
}

function Qo(o) {
    let e;
    return {
        c() {
            e = P(o[3])
        },
        l(i) {
            e = D(i, o[3])
        },
        m(i, n) {
            k(i, e, n)
        },
        p(i, n) {
            n & 8 && O(e, i[3])
        },
        i: A,
        o: A,
        d(i) {
            i && f(e)
        }
    }
}

function Jo(o) {
    let e, i;
    return e = new ie({
        props: {
            value: o[2],
            currency: o[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 4 && (r.value = n[2]), t & 2 && (r.currency = n[1]), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function xo(o) {
    let e, i;
    return e = new ie({
        props: {
            value: o[0],
            currency: o[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 1 && (r.value = n[0]), t & 2 && (r.currency = n[1]), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function es(o) {
    let e = o[6] + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 32 && e !== (e = n[6] + "") && O(i, e)
        },
        i: A,
        o: A,
        d(n) {
            n && f(i)
        }
    }
}

function ht(o) {
    let e, i, n, t;
    const r = [es, xo, Jo, Qo],
        a = [];

    function s(l, u) {
        return typeof l[6] == "string" ? 0 : l[6][0] === "value" ? 1 : l[6][0] === "payout" ? 2 : l[6][0] === "promotionName" ? 3 : -1
    }
    return ~(e = s(o)) && (i = a[e] = r[e](o)), {
        c() {
            i && i.c(), n = h()
        },
        l(l) {
            i && i.l(l), n = h()
        },
        m(l, u) {
            ~e && a[e].m(l, u), k(l, n, u), t = !0
        },
        p(l, u) {
            let c = e;
            e = s(l), e === c ? ~e && a[e].p(l, u) : (i && (y(), m(a[c], 1, 1, () => {
                a[c] = null
            }), w()), ~e ? (i = a[e], i ? i.p(l, u) : (i = a[e] = r[e](l), i.c()), d(i, 1), i.m(n.parentNode, n)) : i = null)
        },
        i(l) {
            t || (d(i), t = !0)
        },
        o(l) {
            m(i), t = !1
        },
        d(l) {
            l && f(n), ~e && a[e].d(l)
        }
    }
}

function ns(o) {
    let e, i, n, t;
    const r = [Xo, Zo],
        a = [];

    function s(l, u) {
        return l[2] === 0 ? 0 : l[5] ? 1 : -1
    }
    return ~(e = s(o)) && (i = a[e] = r[e](o)), {
        c() {
            i && i.c(), n = h()
        },
        l(l) {
            i && i.l(l), n = h()
        },
        m(l, u) {
            ~e && a[e].m(l, u), k(l, n, u), t = !0
        },
        p(l, [u]) {
            let c = e;
            e = s(l), e === c ? ~e && a[e].p(l, u) : (i && (y(), m(a[c], 1, 1, () => {
                a[c] = null
            }), w()), ~e ? (i = a[e], i ? i.p(l, u) : (i = a[e] = r[e](l), i.c()), d(i, 1), i.m(n.parentNode, n)) : i = null)
        },
        i(l) {
            t || (d(i), t = !0)
        },
        o(l) {
            m(i), t = !1
        },
        d(l) {
            l && f(n), ~e && a[e].d(l)
        }
    }
}

function ts(o, e, i) {
    let n, t;
    j(o, x, u => i(4, t = u));
    let {
        betAmount: r
    } = e, {
        currency: a
    } = e, {
        payout: s
    } = e, {
        promotionName: l
    } = e;
    return o.$$set = u => {
        "betAmount" in u && i(0, r = u.betAmount), "currency" in u && i(1, a = u.currency), "payout" in u && i(2, s = u.payout), "promotionName" in u && i(3, l = u.promotionName)
    }, o.$$.update = () => {
        o.$$.dirty & 16 && i(5, n = t.message(ln.qualified.id))
    }, [r, a, s, l, t, n]
}
let is = class extends q {
    constructor(e) {
        super(), K(this, e, ts, ns, Y, {
            betAmount: 0,
            currency: 1,
            payout: 2,
            promotionName: 3
        })
    }
};
const ls = o => ({
        title: p._("Promotion Bet Settled"),
        body: is,
        props: o,
        icon: oe,
        sound: "money",
        type: (o == null ? void 0 : o.payout) === 0 ? "negative" : "positive",
        click: () => {
            me.bet.open({
                betId: o == null ? void 0 : o.betId
            })
        }
    }),
    as = {
        content: {
            id: "Your {value} bet is eligible for a promotion {promotionName}."
        }
    };

function St(o, e, i) {
    const n = o.slice();
    return n[5] = e[i], n
}

function bt(o) {
    let e, i, n = Z(o[3]),
        t = [];
    for (let a = 0; a < n.length; a += 1) t[a] = Ft(St(o, n, a));
    const r = a => m(t[a], 1, 1, () => {
        t[a] = null
    });
    return {
        c() {
            e = T("span");
            for (let a = 0; a < t.length; a += 1) t[a].c()
        },
        l(a) {
            e = I(a, "SPAN", {});
            var s = B(e);
            for (let l = 0; l < t.length; l += 1) t[l].l(s);
            s.forEach(f)
        },
        m(a, s) {
            k(a, e, s);
            for (let l = 0; l < t.length; l += 1) t[l] && t[l].m(e, null);
            i = !0
        },
        p(a, s) {
            if (s & 15) {
                n = Z(a[3]);
                let l;
                for (l = 0; l < n.length; l += 1) {
                    const u = St(a, n, l);
                    t[l] ? (t[l].p(u, s), d(t[l], 1)) : (t[l] = Ft(u), t[l].c(), d(t[l], 1), t[l].m(e, null))
                }
                for (y(), l = n.length; l < t.length; l += 1) r(l);
                w()
            }
        },
        i(a) {
            if (!i) {
                for (let s = 0; s < n.length; s += 1) d(t[s]);
                i = !0
            }
        },
        o(a) {
            t = t.filter(Boolean);
            for (let s = 0; s < t.length; s += 1) m(t[s]);
            i = !1
        },
        d(a) {
            a && f(e), te(t, a)
        }
    }
}

function rs(o) {
    let e;
    return {
        c() {
            e = P(o[2])
        },
        l(i) {
            e = D(i, o[2])
        },
        m(i, n) {
            k(i, e, n)
        },
        p(i, n) {
            n & 4 && O(e, i[2])
        },
        i: A,
        o: A,
        d(i) {
            i && f(e)
        }
    }
}

function os(o) {
    let e, i;
    return e = new ie({
        props: {
            value: o[0],
            currency: o[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 1 && (r.value = n[0]), t & 2 && (r.currency = n[1]), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function ss(o) {
    let e = o[5] + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 8 && e !== (e = n[5] + "") && O(i, e)
        },
        i: A,
        o: A,
        d(n) {
            n && f(i)
        }
    }
}

function Ft(o) {
    let e, i, n, t;
    const r = [ss, os, rs],
        a = [];

    function s(l, u) {
        return typeof l[5] == "string" ? 0 : l[5][0] === "value" ? 1 : l[5][0] === "promotionName" ? 2 : -1
    }
    return ~(e = s(o)) && (i = a[e] = r[e](o)), {
        c() {
            i && i.c(), n = h()
        },
        l(l) {
            i && i.l(l), n = h()
        },
        m(l, u) {
            ~e && a[e].m(l, u), k(l, n, u), t = !0
        },
        p(l, u) {
            let c = e;
            e = s(l), e === c ? ~e && a[e].p(l, u) : (i && (y(), m(a[c], 1, 1, () => {
                a[c] = null
            }), w()), ~e ? (i = a[e], i ? i.p(l, u) : (i = a[e] = r[e](l), i.c()), d(i, 1), i.m(n.parentNode, n)) : i = null)
        },
        i(l) {
            t || (d(i), t = !0)
        },
        o(l) {
            m(i), t = !1
        },
        d(l) {
            l && f(n), ~e && a[e].d(l)
        }
    }
}

function us(o) {
    let e, i, n = o[3] && bt(o);
    return {
        c() {
            n && n.c(), e = h()
        },
        l(t) {
            n && n.l(t), e = h()
        },
        m(t, r) {
            n && n.m(t, r), k(t, e, r), i = !0
        },
        p(t, [r]) {
            t[3] ? n ? (n.p(t, r), r & 8 && d(n, 1)) : (n = bt(t), n.c(), d(n, 1), n.m(e.parentNode, e)) : n && (y(), m(n, 1, 1, () => {
                n = null
            }), w())
        },
        i(t) {
            i || (d(n), i = !0)
        },
        o(t) {
            m(n), i = !1
        },
        d(t) {
            t && f(e), n && n.d(t)
        }
    }
}

function cs(o, e, i) {
    let n, t;
    j(o, x, l => i(4, t = l));
    let {
        betAmount: r
    } = e, {
        currency: a
    } = e, {
        promotionName: s
    } = e;
    return o.$$set = l => {
        "betAmount" in l && i(0, r = l.betAmount), "currency" in l && i(1, a = l.currency), "promotionName" in l && i(2, s = l.promotionName)
    }, o.$$.update = () => {
        o.$$.dirty & 16 && i(3, n = t.message(as.content.id))
    }, [r, a, s, n, t]
}
let ds = class extends q {
    constructor(e) {
        super(), K(this, e, cs, us, Y, {
            betAmount: 0,
            currency: 1,
            promotionName: 2
        })
    }
};
const ms = o => ({
        title: p._("Bet Eligible For a Promotion"),
        body: ds,
        props: o,
        icon: oe,
        sound: "money",
        type: "positive",
        click: () => {
            me.bet.open({
                betId: o == null ? void 0 : o.betId
            })
        }
    }),
    fs = {
        content: {
            id: "You placed {position} and won {amount}!"
        }
    };

function yt(o, e, i) {
    const n = o.slice();
    return n[5] = e[i], n
}

function wt(o) {
    let e, i, n = Z(o[3]),
        t = [];
    for (let a = 0; a < n.length; a += 1) t[a] = Ct(yt(o, n, a));
    const r = a => m(t[a], 1, 1, () => {
        t[a] = null
    });
    return {
        c() {
            e = T("span");
            for (let a = 0; a < t.length; a += 1) t[a].c()
        },
        l(a) {
            e = I(a, "SPAN", {});
            var s = B(e);
            for (let l = 0; l < t.length; l += 1) t[l].l(s);
            s.forEach(f)
        },
        m(a, s) {
            k(a, e, s);
            for (let l = 0; l < t.length; l += 1) t[l] && t[l].m(e, null);
            i = !0
        },
        p(a, s) {
            if (s & 15) {
                n = Z(a[3]);
                let l;
                for (l = 0; l < n.length; l += 1) {
                    const u = yt(a, n, l);
                    t[l] ? (t[l].p(u, s), d(t[l], 1)) : (t[l] = Ct(u), t[l].c(), d(t[l], 1), t[l].m(e, null))
                }
                for (y(), l = n.length; l < t.length; l += 1) r(l);
                w()
            }
        },
        i(a) {
            if (!i) {
                for (let s = 0; s < n.length; s += 1) d(t[s]);
                i = !0
            }
        },
        o(a) {
            t = t.filter(Boolean);
            for (let s = 0; s < t.length; s += 1) m(t[s]);
            i = !1
        },
        d(a) {
            a && f(e), te(t, a)
        }
    }
}

function ks(o) {
    let e;
    return {
        c() {
            e = P(o[0])
        },
        l(i) {
            e = D(i, o[0])
        },
        m(i, n) {
            k(i, e, n)
        },
        p(i, n) {
            n & 1 && O(e, i[0])
        },
        i: A,
        o: A,
        d(i) {
            i && f(e)
        }
    }
}

function _s(o) {
    let e, i;
    return e = new ie({
        props: {
            value: o[2],
            currency: o[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 4 && (r.value = n[2]), t & 2 && (r.currency = n[1]), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function ps(o) {
    let e = o[5] + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 8 && e !== (e = n[5] + "") && O(i, e)
        },
        i: A,
        o: A,
        d(n) {
            n && f(i)
        }
    }
}

function Ct(o) {
    let e, i, n, t;
    const r = [ps, _s, ks],
        a = [];

    function s(l, u) {
        return typeof l[5] == "string" ? 0 : l[5][0] === "amount" ? 1 : l[5][0] === "position" ? 2 : -1
    }
    return ~(e = s(o)) && (i = a[e] = r[e](o)), {
        c() {
            i && i.c(), n = h()
        },
        l(l) {
            i && i.l(l), n = h()
        },
        m(l, u) {
            ~e && a[e].m(l, u), k(l, n, u), t = !0
        },
        p(l, u) {
            let c = e;
            e = s(l), e === c ? ~e && a[e].p(l, u) : (i && (y(), m(a[c], 1, 1, () => {
                a[c] = null
            }), w()), ~e ? (i = a[e], i ? i.p(l, u) : (i = a[e] = r[e](l), i.c()), d(i, 1), i.m(n.parentNode, n)) : i = null)
        },
        i(l) {
            t || (d(i), t = !0)
        },
        o(l) {
            m(i), t = !1
        },
        d(l) {
            l && f(n), ~e && a[e].d(l)
        }
    }
}

function gs(o) {
    let e, i, n = o[3] && wt(o);
    return {
        c() {
            n && n.c(), e = h()
        },
        l(t) {
            n && n.l(t), e = h()
        },
        m(t, r) {
            n && n.m(t, r), k(t, e, r), i = !0
        },
        p(t, [r]) {
            t[3] ? n ? (n.p(t, r), r & 8 && d(n, 1)) : (n = wt(t), n.c(), d(n, 1), n.m(e.parentNode, e)) : n && (y(), m(n, 1, 1, () => {
                n = null
            }), w())
        },
        i(t) {
            i || (d(n), i = !0)
        },
        o(t) {
            m(n), i = !1
        },
        d(t) {
            t && f(e), n && n.d(t)
        }
    }
}

function $s(o, e, i) {
    let n, t;
    j(o, x, l => i(4, t = l));
    let {
        ordinalPosition: r
    } = e, {
        currency: a
    } = e, {
        amount: s
    } = e;
    return o.$$set = l => {
        "ordinalPosition" in l && i(0, r = l.ordinalPosition), "currency" in l && i(1, a = l.currency), "amount" in l && i(2, s = l.amount)
    }, o.$$.update = () => {
        o.$$.dirty & 16 && i(3, n = t.message(fs.content.id))
    }, [r, a, s, n, t]
}
let vs = class extends q {
    constructor(e) {
        super(), K(this, e, $s, gs, Y, {
            ordinalPosition: 0,
            currency: 1,
            amount: 2
        })
    }
};
const Ns = o => {
        const e = Ol(o.position);
        return {
            title: {
                id: "{name} race has finished!",
                values: {
                    name: o.name
                }
            },
            body: vs,
            props: { ...o,
                ordinalPosition: e
            },
            icon: vi,
            type: "positive",
            sound: "coins"
        }
    },
    hs = () => ({
        title: p._("Verification level two confirmed"),
        icon: Ye,
        type: "positive"
    }),
    Ss = () => ({
        title: p._("Verification level three confirmed"),
        icon: Ye,
        type: "positive"
    }),
    bs = () => ({
        title: p._("Verification level four confirmed"),
        icon: Ye,
        type: "positive"
    }),
    Fs = () => ({
        title: p._("Unmuted"),
        body: p._("You have been unmuted."),
        icon: Ni,
        type: "positive"
    }),
    Oi = {
        title: p._("Revenue Share Commission"),
        body: {
            id: "Your revshare of {currency} {amount} has been credited to your account."
        }
    };

function At(o, e, i) {
    const n = o.slice();
    return n[4] = e[i], n
}

function Tt(o) {
    let e, i, n = Z(o[2]),
        t = [];
    for (let a = 0; a < n.length; a += 1) t[a] = It(At(o, n, a));
    const r = a => m(t[a], 1, 1, () => {
        t[a] = null
    });
    return {
        c() {
            e = T("span");
            for (let a = 0; a < t.length; a += 1) t[a].c()
        },
        l(a) {
            e = I(a, "SPAN", {});
            var s = B(e);
            for (let l = 0; l < t.length; l += 1) t[l].l(s);
            s.forEach(f)
        },
        m(a, s) {
            k(a, e, s);
            for (let l = 0; l < t.length; l += 1) t[l] && t[l].m(e, null);
            i = !0
        },
        p(a, s) {
            if (s & 7) {
                n = Z(a[2]);
                let l;
                for (l = 0; l < n.length; l += 1) {
                    const u = At(a, n, l);
                    t[l] ? (t[l].p(u, s), d(t[l], 1)) : (t[l] = It(u), t[l].c(), d(t[l], 1), t[l].m(e, null))
                }
                for (y(), l = n.length; l < t.length; l += 1) r(l);
                w()
            }
        },
        i(a) {
            if (!i) {
                for (let s = 0; s < n.length; s += 1) d(t[s]);
                i = !0
            }
        },
        o(a) {
            t = t.filter(Boolean);
            for (let s = 0; s < t.length; s += 1) m(t[s]);
            i = !1
        },
        d(a) {
            a && f(e), te(t, a)
        }
    }
}

function ys(o) {
    let e, i;
    return e = new ie({
        props: {
            value: o[0],
            currency: o[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 1 && (r.value = n[0]), t & 2 && (r.currency = n[1]), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function ws(o) {
    let e = o[4] + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 4 && e !== (e = n[4] + "") && O(i, e)
        },
        i: A,
        o: A,
        d(n) {
            n && f(i)
        }
    }
}

function It(o) {
    let e, i, n, t;
    const r = [ws, ys],
        a = [];

    function s(l, u) {
        return typeof l[4] == "string" ? 0 : l[4][0] === "amount" ? 1 : -1
    }
    return ~(e = s(o)) && (i = a[e] = r[e](o)), {
        c() {
            i && i.c(), n = h()
        },
        l(l) {
            i && i.l(l), n = h()
        },
        m(l, u) {
            ~e && a[e].m(l, u), k(l, n, u), t = !0
        },
        p(l, u) {
            let c = e;
            e = s(l), e === c ? ~e && a[e].p(l, u) : (i && (y(), m(a[c], 1, 1, () => {
                a[c] = null
            }), w()), ~e ? (i = a[e], i ? i.p(l, u) : (i = a[e] = r[e](l), i.c()), d(i, 1), i.m(n.parentNode, n)) : i = null)
        },
        i(l) {
            t || (d(i), t = !0)
        },
        o(l) {
            m(i), t = !1
        },
        d(l) {
            l && f(n), ~e && a[e].d(l)
        }
    }
}

function Cs(o) {
    let e, i, n = o[2] && Tt(o);
    return {
        c() {
            n && n.c(), e = h()
        },
        l(t) {
            n && n.l(t), e = h()
        },
        m(t, r) {
            n && n.m(t, r), k(t, e, r), i = !0
        },
        p(t, [r]) {
            t[2] ? n ? (n.p(t, r), r & 4 && d(n, 1)) : (n = Tt(t), n.c(), d(n, 1), n.m(e.parentNode, e)) : n && (y(), m(n, 1, 1, () => {
                n = null
            }), w())
        },
        i(t) {
            i || (d(n), i = !0)
        },
        o(t) {
            m(n), i = !1
        },
        d(t) {
            t && f(e), n && n.d(t)
        }
    }
}

function As(o, e, i) {
    let n, t;
    j(o, x, s => i(3, t = s));
    let {
        amount: r
    } = e, {
        currency: a
    } = e;
    return o.$$set = s => {
        "amount" in s && i(0, r = s.amount), "currency" in s && i(1, a = s.currency)
    }, o.$$.update = () => {
        o.$$.dirty & 8 && i(2, n = t.message(Oi.body.id))
    }, [r, a, n, t]
}
class Ts extends q {
    constructor(e) {
        super(), K(this, e, As, Cs, Y, {
            amount: 0,
            currency: 1
        })
    }
}
const Is = o => ({
    title: Oi.title,
    body: Ts,
    type: "positive",
    props: o,
    icon: oe
});

function Bs(o) {
    let e, i = o[1].toUpperCase() + "",
        n, t, r = _n(Number(o[0]), o[2], {
            style: "currency",
            currency: "usd",
            minimumFractionDigits: 2
        }) + "",
        a;
    return {
        c() {
            e = P("1 "), n = P(i), t = P(" = "), a = P(r)
        },
        l(s) {
            e = D(s, "1 "), n = D(s, i), t = D(s, " = "), a = D(s, r)
        },
        m(s, l) {
            k(s, e, l), k(s, n, l), k(s, t, l), k(s, a, l)
        },
        p(s, l) {
            l & 2 && i !== (i = s[1].toUpperCase() + "") && O(n, i), l & 5 && r !== (r = _n(Number(s[0]), s[2], {
                style: "currency",
                currency: "usd",
                minimumFractionDigits: 2
            }) + "") && O(a, r)
        },
        d(s) {
            s && (f(e), f(n), f(t), f(a))
        }
    }
}

function Es(o) {
    let e, i;
    return e = new le({
        props: {
            tag: "p",
            align: "center",
            $$slots: {
                default: [Bs]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, [t]) {
            const r = {};
            t & 23 && (r.$$scope = {
                dirty: t,
                ctx: n
            }), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Ps(o, e, i) {
    let n, t, r, a;
    return j(o, ul, s => i(3, t = s)), j(o, rn, s => i(1, r = s)), j(o, pl, s => i(2, a = s)), o.$$.update = () => {
        o.$$.dirty & 8 && i(0, n = (t || 0).toFixed(8))
    }, [n, r, a, t]
}
class Ds extends q {
    constructor(e) {
        super(), K(this, e, Ps, Es, Y, {})
    }
}
const Ke = {
        helpCenter: p._("Help Center"),
        liveSupport: p._("Live Support"),
        aboutUs: p._("About Us"),
        socialCasino: p._("Social Casino"),
        affiliate: p._("Affiliate"),
        bitcointalk: p._("Bitcointalk"),
        blog: p._("Blog"),
        changeLog: p._("Change Log"),
        community: p._("Community"),
        design: p._("Design"),
        facebook: p._("Facebook"),
        youtube: p._("YouTube"),
        forum: p._("Forum"),
        gambleAware: p._("Gamble Aware"),
        guides: p._("Guides"),
        home: p._("Home"),
        language: p._("Language"),
        odds: p._("Odds"),
        view: p._("View"),
        vipClub: p._("VIP Club"),
        promotions: p._("Promotions"),
        primedice: p._("Primedice"),
        provablyFair: p._("Fairness"),
        support: p._("Support"),
        sportsbookRules: p._("Sports Betting Rules"),
        tos: p._("Terms of Service"),
        privacy: p._("Privacy Policy"),
        aml: p._("AML Policy"),
        selfExclusion: p._("Self Exclusion"),
        twitter: p._("Twitter"),
        instagram: p._("Instagram"),
        legal: p._("Legal"),
        partners: p._("Partners"),
        press: p._("Press"),
        igamingOn: p._("iGaming Ontario"),
        usintegrity: p._("U.S. Integrity"),
        complianceTextSweeps: p._(`Stake.us is owned and operated by Sweepsteaks Limited, registration number 
HE436222, registered address 28  Oktovriou, 313 Omrania BLD, Limassol, CY-3105, Cyprus. Contact us at support@stake.us.`),
        year: o => ({
            id: "© {year} {site} | All Rights Reserved.",
            values: {
                year: o,
                site: vl
            }
        }),
        complianceText: o => ({
            id: "Stake is owned and operated by {companyName}, registration number: {registrationNumber}, registered address: {registeredAddress}. Contact us at {emailAddress}.",
            values: o
        }),
        paymentAgent: o => ({
            id: "Payment agent company is {companyName} with address {registeredAddress} and Registration number: {registrationNumber}",
            values: o
        }),
        license: p._("Stake is authorized and regulated by the Government of Curacao and operates under License No. 8048/JAZ2021-027 issued to Antillephone. Stake has passed all compliance and is legally authorized to conduct gaming operations for all games of chance and wagering."),
        licenses: p._("Licenses"),
        sports: p._("Sports"),
        sportsbook: p._("Sportsbook"),
        casino: p._("Casino"),
        slots: p._("Slots"),
        liveCasino: p._("Live Casino"),
        pokerSweeps: p._("Poker"),
        scratchCards: p._("Scratch Cards"),
        roulette: p._("Roulette"),
        blackjack: p._("Blackjack"),
        games: p._("Casino Games"),
        providers: p._("Providers"),
        provablyFairness: p._("Provable Fairness"),
        howToGuides: p._("How to Guides"),
        localCurrencyGuide: p._("Local Currency Guide"),
        cryptoGuide: p._("Supported Crypto"),
        live: p._("Live"),
        liveSportsBetting: p._("Live Sports"),
        soccerBetting: p._("Soccer"),
        basketballBetting: p._("Basketball"),
        tennisBetting: p._("Tennis"),
        esportsBetting: p._("eSports"),
        sportsBetBonus: p._("Bet Bonuses"),
        upcoming: p._("Upcoming"),
        sportsRules: p._("Sports Rules"),
        racingRules: p._("Racing Rules"),
        help: p._("Live Support"),
        shop: p._("Shop"),
        altBitcoin: p._("Bitcoin logo"),
        altEthereum: p._("Ethereum logo"),
        altLitecoin: p._("Litecoin logo"),
        altRipple: p._("Ripple logo"),
        altTron: p._("Tron logo"),
        altEightTeenPlus: p._("18+ logo"),
        altBitcoinCash: p._("Bitcoin Cash logo"),
        altEos: p._("EOS logo"),
        altGambleSafe: p._("Gamble Safe"),
        altDoge: p._("Doge coin logo"),
        altInterac: p._("Interac logo"),
        altBnb: p._("BNB logo"),
        altTether: p._("Tether logo"),
        termsOfService: p._("terms of service"),
        sweepsStakes: {
            id: "NO PURCHASE NECESSARY to enter Sweepstakes. SWEEPSTAKES ARE VOID WHERE PROHIBITED BY LAW. For detailed rules, see {link}"
        },
        responsibleGambling: p._("Responsible Gambling"),
        responsiblePlay: p._("Responsible Play"),
        connexOntario: p._("Connex Ontario"),
        Agco: p._("Alcohol and Gaming Commission of Ontario (AGCO)"),
        iGamingOntario: p._("iGaming Ontario"),
        gamblingConsequences: p._("While many can enjoy gambling as a form of entertainment without experiencing harm, some may be more vulnerable to the negative consequences of excessive or problematic gambling. ConnexOntario provides service information for people experiencing problems with gambling, drugs, alcohol, or mental health. Helpful, supportive system navigation specialists answer all calls, emails or web chat requests 24/7 with over 170 languages available. Our referral service is free and confidential."),
        connexContact: p._("Visit http://www.ConnexOntario.ca  or call 1-866-531-2600"),
        complianceTextCanada: p._("Stake.ca is operated by Medium Well (Cyprus) Ltd, a company incorporated in Cyprus with the corporation number HE432635 with its registered address 313, 28th October Avenue, Omrania Centre, Limassol 3105, Cyprus. Medium Well (Cyprus) Ltd is licensed and regulated by the Alcohol and Gaming Commission of Ontario with registration number [XXXXX]."),
        hub88: p._("Hub88 Preferred Aggregator"),
        betblocker: p._("BetBlocker")
    },
    Rs = { ...Ke,
        casino: p._("Social Casino"),
        games: p._("Games"),
        liveCasino: p._("Live Dealer"),
        altEightTeenPlus: p._("21+ logo"),
        responsibleGambling: p._("Responsible Gaming"),
        gambleAware: p._("Addicted to Gaming?")
    },
    Vs = { ...Ke,
        altEightTeenPlus: p._("19+ logo"),
        responsibleGambling: p._("Stake Smart")
    },
    Ms = {
        stake: Ke,
        sweeps: Rs,
        canada: Vs
    },
    ce = Ms[Te] || Ke;

function Os(o) {
    let e, i, n, t;
    return i = new mi({}), {
        c() {
            e = T("a"), g(i.$$.fragment), this.h()
        },
        l(r) {
            e = I(r, "A", {
                href: !0,
                style: !0
            });
            var a = B(e);
            N(i.$$.fragment, a), a.forEach(f), this.h()
        },
        h() {
            H(e, "href", n = o[0](je(ke.root))), be(e, "text-align", "center")
        },
        m(r, a) {
            k(r, e, a), $(i, e, null), t = !0
        },
        p(r, a) {
            (!t || a & 1 && n !== (n = r[0](je(ke.root)))) && H(e, "href", n)
        },
        i(r) {
            t || (d(i.$$.fragment, r), t = !0)
        },
        o(r) {
            m(i.$$.fragment, r), t = !1
        },
        d(r) {
            r && f(e), v(i)
        }
    }
}

function Ls(o) {
    let e = o[1]._(ce.year(new Date().getFullYear().toString())) + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 2 && e !== (e = n[1]._(ce.year(new Date().getFullYear().toString())) + "") && O(i, e)
        },
        d(n) {
            n && f(i)
        }
    }
}

function Us(o) {
    let e, i;
    return e = new Ds({}), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Ws(o) {
    let e, i, n, t, r, a;
    e = new Re({
        props: {
            $$slots: {
                default: [Os]
            },
            $$scope: {
                ctx: o
            }
        }
    }), n = new le({
        props: {
            $$slots: {
                default: [Ls]
            },
            $$scope: {
                ctx: o
            }
        }
    });
    let s = Us();
    return {
        c() {
            g(e.$$.fragment), i = V(), g(n.$$.fragment), t = V(), s && s.c(), r = h()
        },
        l(l) {
            N(e.$$.fragment, l), i = M(l), N(n.$$.fragment, l), t = M(l), s && s.l(l), r = h()
        },
        m(l, u) {
            $(e, l, u), k(l, i, u), $(n, l, u), k(l, t, u), s && s.m(l, u), k(l, r, u), a = !0
        },
        p(l, u) {
            const c = {};
            u & 5 && (c.$$scope = {
                dirty: u,
                ctx: l
            }), e.$set(c);
            const _ = {};
            u & 6 && (_.$$scope = {
                dirty: u,
                ctx: l
            }), n.$set(_)
        },
        i(l) {
            a || (d(e.$$.fragment, l), d(n.$$.fragment, l), d(s), a = !0)
        },
        o(l) {
            m(e.$$.fragment, l), m(n.$$.fragment, l), m(s), a = !1
        },
        d(l) {
            l && (f(i), f(t), f(r)), v(e, l), v(n, l), s && s.d(l)
        }
    }
}

function zs(o) {
    let e, i;
    return e = new Pe({
        props: {
            padding: "none",
            x: "center",
            $$slots: {
                default: [Ws]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, [t]) {
            const r = {};
            t & 7 && (r.$$scope = {
                dirty: t,
                ctx: n
            }), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Gs(o, e, i) {
    let n, t;
    return j(o, Ae, r => i(0, n = r)), j(o, x, r => i(1, t = r)), [n, t]
}
class Kf extends q {
    constructor(e) {
        super(), K(this, e, Gs, zs, Y, {})
    }
}

function js(o) {
    o[1] = o[2].default
}

function Hs(o) {
    o[3] = o[4].default
}

function Bt(o) {
    let e, i, n, t = {
        ctx: o,
        current: null,
        token: null,
        hasCatch: !1,
        pending: Ks,
        then: qs,
        catch: Ys,
        value: 4,
        blocks: [, , , ]
    };
    $n(gn(() =>
        import ("./index.C6oSeDGg.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5])), t);
    let r = {
        ctx: o,
        current: null,
        token: null,
        hasCatch: !1,
        pending: Qs,
        then: Xs,
        catch: Zs,
        value: 2,
        blocks: [, , , ]
    };
    return $n(gn(() =>
        import ("./index.D6_BTN2S.js"), __vite__mapDeps([6, 1, 2, 3, 4, 7])), r), {
        c() {
            t.block.c(), e = V(), i = h(), r.block.c()
        },
        l(a) {
            t.block.l(a), e = M(a), i = h(), r.block.l(a)
        },
        m(a, s) {
            t.block.m(a, t.anchor = s), t.mount = () => e.parentNode, t.anchor = e, k(a, e, s), k(a, i, s), r.block.m(a, r.anchor = s), r.mount = () => i.parentNode, r.anchor = i, n = !0
        },
        p(a, s) {
            o = a
        },
        i(a) {
            n || (d(t.block), d(r.block), n = !0)
        },
        o(a) {
            for (let s = 0; s < 3; s += 1) {
                const l = t.blocks[s];
                m(l)
            }
            for (let s = 0; s < 3; s += 1) {
                const l = r.blocks[s];
                m(l)
            }
            n = !1
        },
        d(a) {
            a && (f(e), f(i)), t.block.d(a), t.token = null, t = null, r.block.d(a), r.token = null, r = null
        }
    }
}

function Ys(o) {
    return {
        c: A,
        l: A,
        m: A,
        i: A,
        o: A,
        d: A
    }
}

function qs(o) {
    Hs(o);
    let e, i;
    return e = new o[3]({}), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Ks(o) {
    let e, i;
    return e = new fi({}), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Zs(o) {
    return {
        c: A,
        l: A,
        m: A,
        i: A,
        o: A,
        d: A
    }
}

function Xs(o) {
    js(o);
    let e, i;
    return e = new o[1]({}), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Qs(o) {
    let e, i;
    return e = new fi({}), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Js(o) {
    let e, i, n = o[0] && Bt(o);
    return {
        c() {
            n && n.c(), e = h()
        },
        l(t) {
            n && n.l(t), e = h()
        },
        m(t, r) {
            n && n.m(t, r), k(t, e, r), i = !0
        },
        p(t, r) {
            t[0] ? n ? r & 1 && d(n, 1) : (n = Bt(t), n.c(), d(n, 1), n.m(e.parentNode, e)) : n && (y(), m(n, 1, 1, () => {
                n = null
            }), w())
        },
        i(t) {
            i || (d(n), i = !0)
        },
        o(t) {
            m(n), i = !1
        },
        d(t) {
            t && f(e), n && n.d(t)
        }
    }
}

function xs(o) {
    let e, i, n;
    return i = new gl({
        props: {
            $$slots: {
                default: [Js, ({
                    visible: t
                }) => ({
                    0: t
                }), ({
                    visible: t
                }) => t ? 1 : 0]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            e = T("div"), g(i.$$.fragment), this.h()
        },
        l(t) {
            e = I(t, "DIV", {
                class: !0
            });
            var r = B(e);
            N(i.$$.fragment, r), r.forEach(f), this.h()
        },
        h() {
            H(e, "class", "seals svelte-df9j3w")
        },
        m(t, r) {
            k(t, e, r), $(i, e, null), n = !0
        },
        p(t, [r]) {
            const a = {};
            r & 33 && (a.$$scope = {
                dirty: r,
                ctx: t
            }), i.$set(a)
        },
        i(t) {
            n || (d(i.$$.fragment, t), n = !0)
        },
        o(t) {
            m(i.$$.fragment, t), n = !1
        },
        d(t) {
            t && f(e), v(i)
        }
    }
}
class Zf extends q {
    constructor(e) {
        super(), K(this, e, null, xs, Y, {})
    }
}
const eu = "/_app/immutable/assets/everton-logo.DjZkLatD.svg",
    nu = {
        alt: p._("Everton main partner")
    };

function tu(o) {
    let e, i, n, t;
    return {
        c() {
            e = T("a"), i = T("img"), this.h()
        },
        l(r) {
            e = I(r, "A", {
                href: !0
            });
            var a = B(e);
            i = I(a, "IMG", {
                class: !0,
                src: !0,
                draggable: !0,
                alt: !0
            }), a.forEach(f), this.h()
        },
        h() {
            H(i, "class", "image svelte-hhdrmg"), an(i.src, n = eu) || H(i, "src", n), H(i, "draggable", !1), H(i, "alt", nu.alt), H(e, "href", t = o[0]("/sponsorships/everton"))
        },
        m(r, a) {
            k(r, e, a), z(e, i)
        },
        p(r, a) {
            a & 1 && t !== (t = r[0]("/sponsorships/everton")) && H(e, "href", t)
        },
        d(r) {
            r && f(e)
        }
    }
}

function iu(o) {
    let e, i;
    return e = new Re({
        props: {
            $$slots: {
                default: [tu]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, [t]) {
            const r = {};
            t & 3 && (r.$$scope = {
                dirty: t,
                ctx: n
            }), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function lu(o, e, i) {
    let n;
    return j(o, Ae, t => i(0, n = t)), [n]
}
class au extends q {
    constructor(e) {
        super(), K(this, e, lu, iu, Y, {})
    }
}
const ru = "/_app/immutable/assets/ufc-partner.C8Oj708g.svg",
    Et = {
        alt: p._("UFC logo")
    };

function ou(o) {
    let e, i, n, t, r;
    return {
        c() {
            e = T("a"), i = T("img"), this.h()
        },
        l(a) {
            e = I(a, "A", {
                href: !0
            });
            var s = B(e);
            i = I(s, "IMG", {
                class: !0,
                src: !0,
                draggable: !0,
                alt: !0
            }), s.forEach(f), this.h()
        },
        h() {
            H(i, "class", "image svelte-hhdrmg"), an(i.src, n = ru) || H(i, "src", n), H(i, "draggable", !1), H(i, "alt", t = o[1]._(Et.alt)), H(e, "href", r = o[0](je(ke.ufc)))
        },
        m(a, s) {
            k(a, e, s), z(e, i)
        },
        p(a, s) {
            s & 2 && t !== (t = a[1]._(Et.alt)) && H(i, "alt", t), s & 1 && r !== (r = a[0](je(ke.ufc))) && H(e, "href", r)
        },
        d(a) {
            a && f(e)
        }
    }
}

function su(o) {
    let e, i;
    return e = new Re({
        props: {
            $$slots: {
                default: [ou]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, [t]) {
            const r = {};
            t & 7 && (r.$$scope = {
                dirty: t,
                ctx: n
            }), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function uu(o, e, i) {
    let n, t;
    return j(o, Ae, r => i(0, n = r)), j(o, x, r => i(1, t = r)), [n, t]
}
class cu extends q {
    constructor(e) {
        super(), K(this, e, uu, su, Y, {})
    }
}
const du = "/_app/immutable/assets/f1-logo.C8neaUBw.svg",
    mu = {
        alt: p._("Official Co-Title Partner of the Alfa Romeo Formula 1")
    };

function fu(o) {
    let e, i, n, t;
    return {
        c() {
            e = T("a"), i = T("img"), this.h()
        },
        l(r) {
            e = I(r, "A", {
                href: !0
            });
            var a = B(e);
            i = I(a, "IMG", {
                class: !0,
                src: !0,
                draggable: !0,
                alt: !0
            }), a.forEach(f), this.h()
        },
        h() {
            H(i, "class", "image svelte-hhdrmg"), an(i.src, n = du) || H(i, "src", n), H(i, "draggable", !1), H(i, "alt", mu.alt), H(e, "href", t = o[0]("/sponsorships/stake-f1-team"))
        },
        m(r, a) {
            k(r, e, a), z(e, i)
        },
        p(r, a) {
            a & 1 && t !== (t = r[0]("/sponsorships/stake-f1-team")) && H(e, "href", t)
        },
        d(r) {
            r && f(e)
        }
    }
}

function ku(o) {
    let e, i;
    return e = new Re({
        props: {
            $$slots: {
                default: [fu]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, [t]) {
            const r = {};
            t & 3 && (r.$$scope = {
                dirty: t,
                ctx: n
            }), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function _u(o, e, i) {
    let n;
    return j(o, Ae, t => i(0, n = t)), [n]
}
class pu extends q {
    constructor(e) {
        super(), K(this, e, _u, ku, Y, {})
    }
}

function gu(o) {
    let e, i;
    return e = new $l({}), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function $u(o) {
    let e, i, n, t, r, a, s, l, u = gu();
    return n = new pu({}), r = new au({}), s = new cu({}), {
        c() {
            e = T("div"), u && u.c(), i = V(), g(n.$$.fragment), t = V(), g(r.$$.fragment), a = V(), g(s.$$.fragment), this.h()
        },
        l(c) {
            e = I(c, "DIV", {
                class: !0
            });
            var _ = B(e);
            u && u.l(_), i = M(_), N(n.$$.fragment, _), t = M(_), N(r.$$.fragment, _), a = M(_), N(s.$$.fragment, _), _.forEach(f), this.h()
        },
        h() {
            H(e, "class", "site-badges svelte-8jx1gh")
        },
        m(c, _) {
            k(c, e, _), u && u.m(e, null), z(e, i), $(n, e, null), z(e, t), $(r, e, null), z(e, a), $(s, e, null), l = !0
        },
        p: A,
        i(c) {
            l || (d(u), d(n.$$.fragment, c), d(r.$$.fragment, c), d(s.$$.fragment, c), l = !0)
        },
        o(c) {
            m(u), m(n.$$.fragment, c), m(r.$$.fragment, c), m(s.$$.fragment, c), l = !1
        },
        d(c) {
            c && f(e), u && u.d(), v(n), v(r), v(s)
        }
    }
}
class Xf extends q {
    constructor(e) {
        super(), K(this, e, null, $u, Y, {})
    }
}

function vu(o) {
    let e = o[0]._(ce.complianceText({
            companyName: "Medium Rare N.V.",
            registrationNumber: "145353",
            registeredAddress: "Korporaalweg 10, Willemstad, Curaçao",
            emailAddress: "support@stake.com"
        })) + "",
        i, n, t = o[0]._(ce.paymentAgent({
            companyName: "Medium Rare Limited",
            registrationNumber: "HE 410775",
            registeredAddress: "7-9 Riga Feraiou, LIZANTIA COURT, Office 310, Agioi Omologites, 1087 Nicosia, Cyprus"
        })) + "",
        r;
    return {
        c() {
            i = P(e), n = V(), r = P(t)
        },
        l(a) {
            i = D(a, e), n = M(a), r = D(a, t)
        },
        m(a, s) {
            k(a, i, s), k(a, n, s), k(a, r, s)
        },
        p(a, s) {
            s & 1 && e !== (e = a[0]._(ce.complianceText({
                companyName: "Medium Rare N.V.",
                registrationNumber: "145353",
                registeredAddress: "Korporaalweg 10, Willemstad, Curaçao",
                emailAddress: "support@stake.com"
            })) + "") && O(i, e), s & 1 && t !== (t = a[0]._(ce.paymentAgent({
                companyName: "Medium Rare Limited",
                registrationNumber: "HE 410775",
                registeredAddress: "7-9 Riga Feraiou, LIZANTIA COURT, Office 310, Agioi Omologites, 1087 Nicosia, Cyprus"
            })) + "") && O(r, t)
        },
        d(a) {
            a && (f(i), f(n), f(r))
        }
    }
}

function Nu(o) {
    let e, i, n, t = vu(o);
    return {
        c() {
            e = V(), t && t.c(), i = V(), n = h()
        },
        l(r) {
            e = M(r), t && t.l(r), i = M(r), n = h()
        },
        m(r, a) {
            k(r, e, a), t && t.m(r, a), k(r, i, a), k(r, n, a)
        },
        p(r, a) {
            t.p(r, a)
        },
        d(r) {
            r && (f(e), f(i), f(n)), t && t.d(r)
        }
    }
}

function hu(o) {
    let e, i, n, t;
    e = new le({
        props: {
            lineHeight: "150pct",
            tag: "p",
            size: "sm",
            align: "center",
            $$slots: {
                default: [Nu]
            },
            $$scope: {
                ctx: o
            }
        }
    });
    let r = ki === "sweeps";
    return {
        c() {
            g(e.$$.fragment), i = V(), n = h()
        },
        l(a) {
            N(e.$$.fragment, a), i = M(a), n = h()
        },
        m(a, s) {
            $(e, a, s), k(a, i, s), k(a, n, s), t = !0
        },
        p(a, [s]) {
            const l = {};
            s & 65 && (l.$$scope = {
                dirty: s,
                ctx: a
            }), e.$set(l)
        },
        i(a) {
            t || (d(e.$$.fragment, a), d(r), t = !0)
        },
        o(a) {
            m(e.$$.fragment, a), m(r), t = !1
        },
        d(a) {
            a && (f(i), f(n)), v(e, a)
        }
    }
}

function Su(o, e, i) {
    let n, t, r;
    return j(o, x, a => i(0, t = a)), j(o, Ae, a => i(2, r = a)), o.$$.update = () => {
        var a;
        o.$$.dirty & 1 && i(1, n = t.message((a = ce == null ? void 0 : ce.sweepsStakes) == null ? void 0 : a.id) || [])
    }, [t, n, r]
}
class Qf extends q {
    constructor(e) {
        super(), K(this, e, Su, hu, Y, {})
    }
}

function bu(o) {
    let e = o[0]._(ce.support) + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 1 && e !== (e = n[0]._(ce.support) + "") && O(i, e)
        },
        d(n) {
            n && f(i)
        }
    }
}

function Fu(o) {
    let e = on.emails.support + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p: A,
        d(n) {
            n && f(i)
        }
    }
}

function yu(o) {
    let e = o[0]._(ce.partners) + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 1 && e !== (e = n[0]._(ce.partners) + "") && O(i, e)
        },
        d(n) {
            n && f(i)
        }
    }
}

function wu(o) {
    let e = on.emails.partners + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p: A,
        d(n) {
            n && f(i)
        }
    }
}

function Cu(o) {
    let e = o[0]._(ce.press) + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 1 && e !== (e = n[0]._(ce.press) + "") && O(i, e)
        },
        d(n) {
            n && f(i)
        }
    }
}

function Au(o) {
    let e = on.emails.press + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p: A,
        d(n) {
            n && f(i)
        }
    }
}

function Tu(o) {
    let e, i, n, t, r, a, s, l, u, c, _, S, F, E, R, U;
    return n = new le({
        props: {
            size: "sm",
            $$slots: {
                default: [bu]
            },
            $$scope: {
                ctx: o
            }
        }
    }), r = new le({
        props: {
            size: "sm",
            variant: "highlighted",
            $$slots: {
                default: [Fu]
            },
            $$scope: {
                ctx: o
            }
        }
    }), l = new le({
        props: {
            size: "sm",
            $$slots: {
                default: [yu]
            },
            $$scope: {
                ctx: o
            }
        }
    }), c = new le({
        props: {
            size: "sm",
            variant: "highlighted",
            $$slots: {
                default: [wu]
            },
            $$scope: {
                ctx: o
            }
        }
    }), F = new le({
        props: {
            size: "sm",
            $$slots: {
                default: [Cu]
            },
            $$scope: {
                ctx: o
            }
        }
    }), R = new le({
        props: {
            size: "sm",
            variant: "highlighted",
            $$slots: {
                default: [Au]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            e = T("div"), i = T("span"), g(n.$$.fragment), t = V(), g(r.$$.fragment), a = P(`
  |
  `), s = T("span"), g(l.$$.fragment), u = V(), g(c.$$.fragment), _ = P(`
  |
  `), S = T("span"), g(F.$$.fragment), E = V(), g(R.$$.fragment), this.h()
        },
        l(C) {
            e = I(C, "DIV", {
                class: !0
            });
            var L = B(e);
            i = I(L, "SPAN", {});
            var J = B(i);
            N(n.$$.fragment, J), t = M(J), N(r.$$.fragment, J), J.forEach(f), a = D(L, `
  |
  `), s = I(L, "SPAN", {});
            var ee = B(s);
            N(l.$$.fragment, ee), u = M(ee), N(c.$$.fragment, ee), ee.forEach(f), _ = D(L, `
  |
  `), S = I(L, "SPAN", {});
            var ne = B(S);
            N(F.$$.fragment, ne), E = M(ne), N(R.$$.fragment, ne), ne.forEach(f), L.forEach(f), this.h()
        },
        h() {
            H(e, "class", "contact-emails svelte-1kv3nkx")
        },
        m(C, L) {
            k(C, e, L), z(e, i), $(n, i, null), z(i, t), $(r, i, null), z(e, a), z(e, s), $(l, s, null), z(s, u), $(c, s, null), z(e, _), z(e, S), $(F, S, null), z(S, E), $(R, S, null), U = !0
        },
        p(C, [L]) {
            const J = {};
            L & 3 && (J.$$scope = {
                dirty: L,
                ctx: C
            }), n.$set(J);
            const ee = {};
            L & 2 && (ee.$$scope = {
                dirty: L,
                ctx: C
            }), r.$set(ee);
            const ne = {};
            L & 3 && (ne.$$scope = {
                dirty: L,
                ctx: C
            }), l.$set(ne);
            const G = {};
            L & 2 && (G.$$scope = {
                dirty: L,
                ctx: C
            }), c.$set(G);
            const b = {};
            L & 3 && (b.$$scope = {
                dirty: L,
                ctx: C
            }), F.$set(b);
            const W = {};
            L & 2 && (W.$$scope = {
                dirty: L,
                ctx: C
            }), R.$set(W)
        },
        i(C) {
            U || (d(n.$$.fragment, C), d(r.$$.fragment, C), d(l.$$.fragment, C), d(c.$$.fragment, C), d(F.$$.fragment, C), d(R.$$.fragment, C), U = !0)
        },
        o(C) {
            m(n.$$.fragment, C), m(r.$$.fragment, C), m(l.$$.fragment, C), m(c.$$.fragment, C), m(F.$$.fragment, C), m(R.$$.fragment, C), U = !1
        },
        d(C) {
            C && f(e), v(n), v(r), v(l), v(c), v(F), v(R)
        }
    }
}

function Iu(o, e, i) {
    let n;
    return j(o, x, t => i(0, n = t)), [n]
}
class Jf extends q {
    constructor(e) {
        super(), K(this, e, Iu, Tu, Y, {})
    }
}
const ue = {
    title: p._("Notifications"),
    markAllAsRead: p._("Mark all as read"),
    reachedEnd: p._("That's all of your notifications"),
    new: p._("New"),
    earlier: p._("Earlier"),
    noNotifications: p._("No Notifications Available"),
    noNotificationsSubheading: p._("Your interactions will be visible here"),
    closeNotifications: p._("Close Notifications")
};

function Bu(o) {
    let e = o[0]._(ue.title) + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 1 && e !== (e = n[0]._(ue.title) + "") && O(i, e)
        },
        d(n) {
            n && f(i)
        }
    }
}

function Eu(o) {
    let e, i;
    return e = new Bl({}), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Pu(o) {
    let e, i;
    return e = new se({
        props: {
            variant: "link",
            iconOnly: !0,
            size: "lg",
            "aria-label": "Close Notification Widget",
            $$slots: {
                default: [Eu]
            },
            $$scope: {
                ctx: o
            }
        }
    }), e.$on("click", sn.close), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 2 && (r.$$scope = {
                dirty: t,
                ctx: n
            }), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Du(o) {
    let e, i = o[0]._(ue.closeNotifications) + "",
        n;
    return {
        c() {
            e = T("span"), n = P(i), this.h()
        },
        l(t) {
            e = I(t, "SPAN", {
                slot: !0
            });
            var r = B(e);
            n = D(r, i), r.forEach(f), this.h()
        },
        h() {
            H(e, "slot", "tooltip")
        },
        m(t, r) {
            k(t, e, r), z(e, n)
        },
        p(t, r) {
            r & 1 && i !== (i = t[0]._(ue.closeNotifications) + "") && O(n, i)
        },
        d(t) {
            t && f(e)
        }
    }
}

function Ru(o) {
    let e, i, n, t, r, a, s, l;
    return n = new $i({}), r = new le({
        props: {
            weight: "semibold",
            lineHeight: "120pct",
            variant: "highlighted",
            size: "base",
            $$slots: {
                default: [Bu]
            },
            $$scope: {
                ctx: o
            }
        }
    }), s = new wl({
        props: {
            $$slots: {
                tooltip: [Du],
                default: [Pu]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            e = T("div"), i = T("div"), g(n.$$.fragment), t = V(), g(r.$$.fragment), a = V(), g(s.$$.fragment), this.h()
        },
        l(u) {
            e = I(u, "DIV", {
                class: !0
            });
            var c = B(e);
            i = I(c, "DIV", {
                class: !0
            });
            var _ = B(i);
            N(n.$$.fragment, _), t = M(_), N(r.$$.fragment, _), _.forEach(f), a = M(c), N(s.$$.fragment, c), c.forEach(f), this.h()
        },
        h() {
            H(i, "class", "title svelte-12heyz0"), H(e, "class", "notifications-header svelte-12heyz0")
        },
        m(u, c) {
            k(u, e, c), z(e, i), $(n, i, null), z(i, t), $(r, i, null), z(e, a), $(s, e, null), l = !0
        },
        p(u, [c]) {
            const _ = {};
            c & 3 && (_.$$scope = {
                dirty: c,
                ctx: u
            }), r.$set(_);
            const S = {};
            c & 3 && (S.$$scope = {
                dirty: c,
                ctx: u
            }), s.$set(S)
        },
        i(u) {
            l || (d(n.$$.fragment, u), d(r.$$.fragment, u), d(s.$$.fragment, u), l = !0)
        },
        o(u) {
            m(n.$$.fragment, u), m(r.$$.fragment, u), m(s.$$.fragment, u), l = !1
        },
        d(u) {
            u && f(e), v(n), v(r), v(s)
        }
    }
}

function Vu(o, e, i) {
    let n;
    return j(o, x, t => i(0, n = t)), [n]
}
class Mu extends q {
    constructor(e) {
        super(), K(this, e, Vu, Ru, Y, {})
    }
}
const Ou = o => ({}),
    Pt = o => ({});

function Dt(o) {
    let e;
    const i = o[9].endMessage,
        n = pe(i, o, o[8], Pt);
    return {
        c() {
            n && n.c()
        },
        l(t) {
            n && n.l(t)
        },
        m(t, r) {
            n && n.m(t, r), e = !0
        },
        p(t, r) {
            n && n.p && (!e || r & 256) && ge(n, i, t, t[8], e ? ve(i, t[8], r, Ou) : $e(t[8]), Pt)
        },
        i(t) {
            e || (d(n, t), e = !0)
        },
        o(t) {
            m(n, t), e = !1
        },
        d(t) {
            n && n.d(t)
        }
    }
}

function Lu(o) {
    let e, i, n, t, r;
    const a = o[9].default,
        s = pe(a, o, o[8], null);
    let l = o[2] && Dt(o),
        u = [o[3], {
            class: t = `scrollY ${o[4].class}`
        }],
        c = {};
    for (let _ = 0; _ < u.length; _ += 1) c = ae(c, u[_]);
    return {
        c() {
            e = T("div"), s && s.c(), i = V(), n = T("div"), l && l.c(), this.h()
        },
        l(_) {
            e = I(_, "DIV", {
                class: !0
            });
            var S = B(e);
            s && s.l(S), i = M(S), n = I(S, "DIV", {});
            var F = B(n);
            l && l.l(F), F.forEach(f), S.forEach(f), this.h()
        },
        h() {
            we(e, c)
        },
        m(_, S) {
            k(_, e, S), s && s.m(e, null), z(e, i), z(e, n), l && l.m(n, null), o[10](n), o[11](e), r = !0
        },
        p(_, [S]) {
            s && s.p && (!r || S & 256) && ge(s, a, _, _[8], r ? ve(a, _[8], S, null) : $e(_[8]), null), _[2] ? l ? (l.p(_, S), S & 4 && d(l, 1)) : (l = Dt(_), l.c(), d(l, 1), l.m(n, null)) : l && (y(), m(l, 1, 1, () => {
                l = null
            }), w()), we(e, c = de(u, [S & 8 && _[3], (!r || S & 16 && t !== (t = `scrollY ${_[4].class}`)) && {
                class: t
            }]))
        },
        i(_) {
            r || (d(s, _), d(l), r = !0)
        },
        o(_) {
            m(s, _), m(l), r = !1
        },
        d(_) {
            _ && f(e), s && s.d(_), l && l.d(), o[10](null), o[11](null)
        }
    }
}

function Uu(o, e, i) {
    const n = ["threshold", "limit", "loading"];
    let t = Ce(e, n),
        {
            $$slots: r = {},
            $$scope: a
        } = e,
        s = ri(),
        {
            threshold: l = 100
        } = e,
        {
            limit: u = 10
        } = e,
        {
            loading: c = !1
        } = e,
        _, S, F = 0,
        E = !1;
    const R = () => {
        F++, s("load", {
            offset: F * u
        })
    };
    He(() => {
        function L() {
            if (!_) return;
            const ee = _.scrollHeight - _.clientHeight - _.scrollTop;
            c === !1 && ee < l && R()
        }
        _ && _.addEventListener("scroll", L);
        const J = new IntersectionObserver(ee => {
            i(2, E = ee[0].isIntersecting)
        });
        return J.observe(S), () => {
            _ && _.removeEventListener("scroll", L), J.disconnect()
        }
    });

    function U(L) {
        Je[L ? "unshift" : "push"](() => {
            S = L, i(1, S)
        })
    }

    function C(L) {
        Je[L ? "unshift" : "push"](() => {
            _ = L, i(0, _)
        })
    }
    return o.$$set = L => {
        i(4, e = ae(ae({}, e), Ge(L))), i(3, t = Ce(e, n)), "threshold" in L && i(5, l = L.threshold), "limit" in L && i(6, u = L.limit), "loading" in L && i(7, c = L.loading), "$$scope" in L && i(8, a = L.$$scope)
    }, e = Ge(e), [_, S, E, t, e, l, u, c, a, r, U, C]
}
class Wu extends q {
    constructor(e) {
        super(), K(this, e, Uu, Lu, Y, {
            threshold: 5,
            limit: 6,
            loading: 7
        })
    }
}
const zu = (o, e) => {
        const i = Li[o];
        return i(e)
    },
    Rt = o => {
        const e = o == null ? void 0 : o.data;
        if (!e || !e.__typename || !(e.__typename in Li)) return null;
        const i = zu(e.__typename, e);
        return i ? { ...i,
            id: o.id,
            acknowledged: o.acknowledged,
            notificationType: o.type,
            alert: !1
        } : null
    },
    Li = {
        UserFlag: o => Ua({
            flag: o.flag,
            flagMessage: Ul(o.flag),
            createdAt: o.createdAt
        }),
        NotificationKyc: o => o.kycStatus === Ze.extendedConfirmed ? hs() : o.kycStatus === Ze.fullConfirmed ? Ss() : o.kycStatus === Ze.ultimateConfirmed ? bs() : null,
        RacingBet: o => {
            var e;
            return ((e = o == null ? void 0 : o.outcomes) == null ? void 0 : e.length) > 1 ? Qe({
                betId: o == null ? void 0 : o.id,
                legs: o.outcomes.length,
                amount: o.payout,
                currency: o.currency
            }) : Xe({
                betId: o == null ? void 0 : o.id,
                amount: o.payout,
                currency: o.currency,
                fixture: o.outcomes[0] ? `R${o.outcomes[0].event.eventNumber} ${o.outcomes[0].event.meeting.venue.name}` : "N/A"
            })
        },
        SwishBet: o => {
            var e, i, n, t;
            return ((e = o == null ? void 0 : o.outcomes) == null ? void 0 : e.length) > 1 ? Qe({
                betId: o == null ? void 0 : o.id,
                legs: o.outcomes.length,
                amount: o.payout,
                currency: o.currency
            }) : Xe({
                betId: o == null ? void 0 : o.id,
                amount: o.payout,
                currency: o.currency,
                fixture: ((t = (n = (i = o == null ? void 0 : o.outcomes) == null ? void 0 : i[0]) == null ? void 0 : n.outcome) == null ? void 0 : t.competitor.name) || ""
            })
        },
        ChatRainUser: o => {
            const {
                amount: e,
                currency: i,
                rain: {
                    createdAt: n,
                    sendBy: {
                        name: t
                    }
                }
            } = o;
            return Oa({
                createdAt: n,
                amount: e,
                name: t,
                currency: i
            })
        },
        UserBonus: o => {
            const {
                amount: e,
                currency: i,
                credit: n,
                createdAt: t
            } = o;
            return qa({
                createdAt: t,
                amount: e,
                currency: i,
                credit: n
            })
        },
        CashAdvance: o => Qa({
            amount: o.advanceAmount,
            currency: o.currency,
            createdAt: o.createdAt
        }),
        ChatTip: o => {
            const {
                sendBy: {
                    name: e
                },
                amount: i,
                currency: n,
                createdAt: t
            } = o;
            return rr({
                name: e,
                amount: i,
                currency: n,
                createdAt: t
            })
        },
        SportBet: o => o.system > 1 ? o.payout === o.amount ? Tr({
            amount: o.amount,
            currency: o.currency
        }) : Qe({ ...o,
            betId: o == null ? void 0 : o.id,
            legs: o.outcomes.length,
            amount: o.payout,
            currency: o.currency
        }) : o.payout === o.amount ? oo({ ...o,
            amount: o.amount,
            currency: o.currency
        }) : Xe({ ...o,
            betId: o.id,
            amount: o.payout,
            currency: o.currency,
            fixture: oa(o.outcomes[0].fixture.data).name
        }),
        CommunityMute: o => {
            const {
                active: e,
                message: i,
                expireAt: n
            } = o;
            return e ? Vr({
                message: i || "",
                expireAt: n
            }) : Fs()
        },
        RacePosition: o => {
            const {
                race: {
                    name: e,
                    endTime: i
                },
                position: n,
                payoutAmount: t,
                currency: r
            } = o;
            return Ns({
                name: e,
                position: n,
                amount: t || 0,
                currency: r,
                createdAt: i
            })
        },
        WalletDeposit: o => {
            const {
                amount: e,
                currency: i,
                walletStatus: n,
                createdAt: t,
                tokensReceived: r
            } = o;
            return n === "pending" ? po({
                amount: e,
                currency: i,
                createdAt: t
            }) : Un({
                amount: e,
                currency: i,
                tokensReceived: r
            })
        },
        NotificationFiatDeposit: o => {
            const {
                amount: e,
                currency: i,
                fiatStatus: n,
                createdAt: t
            } = o;
            return n === "pending" || n === "auto_approved" ? So({
                amount: e,
                currency: i,
                createdAt: t
            }) : Ao({
                amount: e,
                currency: i
            })
        },
        NotificationFiatWithdrawal: o => {
            const {
                amount: e,
                currency: i,
                fiatStatus: n,
                createdAt: t
            } = o;
            return n === "pending" || n === "auto_approved" ? Do({
                amount: e,
                currency: i,
                createdAt: t
            }) : Uo({
                amount: e,
                currency: i
            })
        },
        ChallengeWin: o => vt({
            challenge: o.challenge
        }),
        Challenge: o => vt({
            challenge: o
        }),
        SportsbookPromotionBet: o => o.sportsbookPromotionBetStatus === "settled" ? ls({
            betAmount: o.betAmount,
            currency: o.currency,
            promotionName: o.promotion.name,
            payout: o.payout,
            betId: o.bet.id
        }) : ms({
            betAmount: o.betAmount,
            currency: o.currency,
            promotionName: o.promotion.name,
            betId: o.bet.id
        }),
        UserPostcardCode: o => Wo({
            code: o.postcardCode
        }),
        NotificationFaucetClaimAvailable: ({
            value: o
        }) => mr({
            value: o
        }),
        EnhancedBreezeOnRampPage: o => Un({
            tokensReceived: o.orderItems.map(e => ({
                amount: e.amount,
                currency: e.currency
            }))
        }),
        NotificationRevShare: ({
            amount: o,
            currency: e
        }) => Is({
            amount: o,
            currency: e
        })
    },
    Gu = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "query",
            name: {
                kind: "Name",
                value: "NotificationList"
            },
            variableDefinitions: [{
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "limit"
                    }
                },
                type: {
                    kind: "NamedType",
                    name: {
                        kind: "Name",
                        value: "Int"
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "offset"
                    }
                },
                type: {
                    kind: "NamedType",
                    name: {
                        kind: "Name",
                        value: "Int"
                    }
                }
            }],
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "notificationList"
                            },
                            arguments: [{
                                kind: "Argument",
                                name: {
                                    kind: "Name",
                                    value: "limit"
                                },
                                value: {
                                    kind: "Variable",
                                    name: {
                                        kind: "Name",
                                        value: "limit"
                                    }
                                }
                            }, {
                                kind: "Argument",
                                name: {
                                    kind: "Name",
                                    value: "offset"
                                },
                                value: {
                                    kind: "Variable",
                                    name: {
                                        kind: "Name",
                                        value: "offset"
                                    }
                                }
                            }],
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "Notification"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportMarket"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportMarket"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "status"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "extId"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "specifiers"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "customBetAvailable"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "provider"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "CategoryTree"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportCategory"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "slug"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "sport"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "slug"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "TournamentTree"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportTournament"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "slug"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "category"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "CategoryTree"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportFixtureCompetitor"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportFixtureCompetitor"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "extId"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "countryCode"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "abbreviation"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "iconPath"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportFixtureDataMatch"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportFixtureDataMatch"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "startTime"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "competitors"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "SportFixtureCompetitor"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "teams"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "qualifier"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "tvChannels"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "language"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "streamUrl"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportFixtureDataOutright"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportFixtureDataOutright"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "startTime"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "endTime"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportFixtureEventStatus"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportFixtureEventStatusData"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "homeScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "awayScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "matchStatus"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "clock"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "matchTime"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "remainingTime"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "periodScores"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "matchStatus"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currentTeamServing"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "homeGameScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "awayGameScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "statistic"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "yellowCards"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "away"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "home"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "redCards"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "away"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "home"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "corners"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "home"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "away"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "EsportFixtureEventStatus"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "EsportFixtureEventStatus"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "matchStatus"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "homeScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "awayScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "scoreboard"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeGold"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayGold"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "gameTime"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeDestroyedTowers"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayDestroyedTurrets"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currentRound"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currentCtTeam"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currentDefTeam"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "time"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "remainingGameTime"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "periodScores"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "type"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "number"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "matchStatus"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SwishMarketOutcomeFragment"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SwishMarketOutcome"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "line"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "over"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "under"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "gradeOver"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "gradeUnder"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "suspended"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "balanced"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "competitor"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "stats"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "dataConfirmed"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "played"
                                    }
                                }]
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "market"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "stat"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "value"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "game"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "fixture"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "id"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "extId"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "name"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "slug"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "status"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "provider"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "swishGame"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "swishSportId"
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "eventStatus"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "FragmentSpread",
                                                    name: {
                                                        kind: "Name",
                                                        value: "SportFixtureEventStatus"
                                                    }
                                                }, {
                                                    kind: "FragmentSpread",
                                                    name: {
                                                        kind: "Name",
                                                        value: "EsportFixtureEventStatus"
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "data"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "InlineFragment",
                                                    typeCondition: {
                                                        kind: "NamedType",
                                                        name: {
                                                            kind: "Name",
                                                            value: "SportFixtureDataMatch"
                                                        }
                                                    },
                                                    selectionSet: {
                                                        kind: "SelectionSet",
                                                        selections: [{
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "__typename"
                                                            }
                                                        }, {
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "startTime"
                                                            }
                                                        }, {
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "competitors"
                                                            },
                                                            selectionSet: {
                                                                kind: "SelectionSet",
                                                                selections: [{
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "name"
                                                                    }
                                                                }, {
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "extId"
                                                                    }
                                                                }, {
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "countryCode"
                                                                    }
                                                                }, {
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "abbreviation"
                                                                    }
                                                                }]
                                                            }
                                                        }]
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "tournament"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "id"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "slug"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "name"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "category"
                                                    },
                                                    selectionSet: {
                                                        kind: "SelectionSet",
                                                        selections: [{
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "id"
                                                            }
                                                        }, {
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "slug"
                                                            }
                                                        }, {
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "name"
                                                            }
                                                        }, {
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "sport"
                                                            },
                                                            selectionSet: {
                                                                kind: "SelectionSet",
                                                                selections: [{
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "id"
                                                                    }
                                                                }, {
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "name"
                                                                    }
                                                                }, {
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "slug"
                                                                    }
                                                                }]
                                                            }
                                                        }]
                                                    }
                                                }]
                                            }
                                        }]
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SwishBetFragment"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SwishBet"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "amount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "cashoutMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "potentialMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "customBet"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "odds"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payout"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "payoutMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "adjustments"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "payoutMultiplier"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "updatedAt"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "createdAt"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "updatedAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "status"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "preferenceHideBets"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "outcomes"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "__typename"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "odds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "lineType"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "outcome"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "SwishMarketOutcomeFragment"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "UserTags"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "User"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "isMuted"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "isRainproof"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "isIgnored"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "isHighroller"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "isSportHighroller"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "leaderboardDailyProfitRank"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "leaderboardDailyWageredRank"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "leaderboardWeeklyProfitRank"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "leaderboardWeeklyWageredRank"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "flags"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "flag"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "rank"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "createdAt"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "roles"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "expireAt"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "message"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "preferenceHideBets"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "Challenge"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "Challenge"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "type"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "adminCreated"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "completedAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "award"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "claimCount"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "claimMax"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "isRefunded"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "minBetUsd"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "betCurrency"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "startAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "expireAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "updatedAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "targetMultiplier"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "game"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "slug"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "thumbnailUrl"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "creatorUser"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "UserTags"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "affiliateUser"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "UserTags"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "wins"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "claimedBy"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "UserTags"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "Notification"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "Notification"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "type"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "acknowledged"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "data"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "__typename"
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "NotificationKyc"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    alias: {
                                        kind: "Name",
                                        value: "kycStatus"
                                    },
                                    name: {
                                        kind: "Name",
                                        value: "status"
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "UserFlag"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "createdAt"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "flag"
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "ChatTip"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "createdAt"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "currency"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "amount"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "sendBy"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "name"
                                            }
                                        }]
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "NotificationKycBanned"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    alias: {
                                        kind: "Name",
                                        value: "kycBannedMessage"
                                    },
                                    name: {
                                        kind: "Name",
                                        value: "message"
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "ChatRainUser"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "amount"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "currency"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "rain"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "createdAt"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "sendBy"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "name"
                                                    }
                                                }]
                                            }
                                        }]
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "CashAdvance"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "advanceAmount"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "currency"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "createdAt"
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "UserBonus"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "createdAt"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "currency"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "amount"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "credit"
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "SportBet"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "amount"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "active"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "currency"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "status"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "payoutMultiplier"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "payout"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "createdAt"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "system"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "potentialMultiplier"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "adjustments"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "id"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "payoutMultiplier"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "updatedAt"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "createdAt"
                                            }
                                        }]
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "user"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "id"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "name"
                                            }
                                        }]
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "outcomes"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "odds"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "status"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "outcome"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "id"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "name"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "active"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "odds"
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "market"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "FragmentSpread",
                                                    name: {
                                                        kind: "Name",
                                                        value: "SportMarket"
                                                    }
                                                }]
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "fixture"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "id"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "slug"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "provider"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "tournament"
                                                    },
                                                    selectionSet: {
                                                        kind: "SelectionSet",
                                                        selections: [{
                                                            kind: "FragmentSpread",
                                                            name: {
                                                                kind: "Name",
                                                                value: "TournamentTree"
                                                            }
                                                        }]
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "data"
                                                    },
                                                    selectionSet: {
                                                        kind: "SelectionSet",
                                                        selections: [{
                                                            kind: "FragmentSpread",
                                                            name: {
                                                                kind: "Name",
                                                                value: "SportFixtureDataMatch"
                                                            }
                                                        }, {
                                                            kind: "FragmentSpread",
                                                            name: {
                                                                kind: "Name",
                                                                value: "SportFixtureDataOutright"
                                                            }
                                                        }, {
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "__typename"
                                                            }
                                                        }]
                                                    }
                                                }]
                                            }
                                        }]
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "SwishBet"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "SwishBetFragment"
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "RacingBet"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "outcomes"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "id"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "event"
                                            },
                                            selectionSet: {
                                                kind: "SelectionSet",
                                                selections: [{
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "eventNumber"
                                                    }
                                                }, {
                                                    kind: "Field",
                                                    name: {
                                                        kind: "Name",
                                                        value: "meeting"
                                                    },
                                                    selectionSet: {
                                                        kind: "SelectionSet",
                                                        selections: [{
                                                            kind: "Field",
                                                            name: {
                                                                kind: "Name",
                                                                value: "venue"
                                                            },
                                                            selectionSet: {
                                                                kind: "SelectionSet",
                                                                selections: [{
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "name"
                                                                    }
                                                                }, {
                                                                    kind: "Field",
                                                                    name: {
                                                                        kind: "Name",
                                                                        value: "geoBlocked"
                                                                    }
                                                                }]
                                                            }
                                                        }]
                                                    }
                                                }]
                                            }
                                        }]
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "payout"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "currency"
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "WalletDeposit"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "createdAt"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "amount"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "currency"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "chain"
                                    }
                                }, {
                                    kind: "Field",
                                    alias: {
                                        kind: "Name",
                                        value: "walletStatus"
                                    },
                                    name: {
                                        kind: "Name",
                                        value: "status"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "tokensReceived"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "currency"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "amount"
                                            }
                                        }]
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "NotificationFiatDeposit"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "createdAt"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "amount"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "currency"
                                    }
                                }, {
                                    kind: "Field",
                                    alias: {
                                        kind: "Name",
                                        value: "fiatStatus"
                                    },
                                    name: {
                                        kind: "Name",
                                        value: "status"
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "NotificationFiatWithdrawal"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "createdAt"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "amount"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "currency"
                                    }
                                }, {
                                    kind: "Field",
                                    alias: {
                                        kind: "Name",
                                        value: "fiatStatus"
                                    },
                                    name: {
                                        kind: "Name",
                                        value: "status"
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "NotificationFiatReversal"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "createdAt"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "amount"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "currency"
                                    }
                                }, {
                                    kind: "Field",
                                    alias: {
                                        kind: "Name",
                                        value: "fiatStatus"
                                    },
                                    name: {
                                        kind: "Name",
                                        value: "status"
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "RacePosition"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "position"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "payoutAmount"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "currency"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "race"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "name"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "endTime"
                                            }
                                        }]
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "CommunityMute"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "active"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "message"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "expireAt"
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "ChallengeWin"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "challenge"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "FragmentSpread",
                                            name: {
                                                kind: "Name",
                                                value: "Challenge"
                                            }
                                        }]
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "Challenge"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "Challenge"
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "NotificationFiatError"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "code"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "limitType"
                                    }
                                }, {
                                    kind: "Field",
                                    alias: {
                                        kind: "Name",
                                        value: "fiatErrorAmount"
                                    },
                                    name: {
                                        kind: "Name",
                                        value: "amount"
                                    }
                                }, {
                                    kind: "Field",
                                    alias: {
                                        kind: "Name",
                                        value: "fiatErrorCurrency"
                                    },
                                    name: {
                                        kind: "Name",
                                        value: "currency"
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "VeriffUser"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    alias: {
                                        kind: "Name",
                                        value: "veriffStatus"
                                    },
                                    name: {
                                        kind: "Name",
                                        value: "status"
                                    }
                                }, {
                                    kind: "Field",
                                    alias: {
                                        kind: "Name",
                                        value: "veriffReason"
                                    },
                                    name: {
                                        kind: "Name",
                                        value: "reason"
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "SportsbookPromotionBet"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "bet"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "id"
                                            }
                                        }]
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "betAmount"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "value"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "currency"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "payout"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "payoutValue"
                                    }
                                }, {
                                    kind: "Field",
                                    alias: {
                                        kind: "Name",
                                        value: "sportsbookPromotionBetStatus"
                                    },
                                    name: {
                                        kind: "Name",
                                        value: "status"
                                    }
                                }, {
                                    kind: "Field",
                                    alias: {
                                        kind: "Name",
                                        value: "sportsbookPromotionBetUser"
                                    },
                                    name: {
                                        kind: "Name",
                                        value: "user"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "id"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "name"
                                            }
                                        }]
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "promotion"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "id"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "name"
                                            }
                                        }]
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "UserPostcardCode"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "claimedAt"
                                    }
                                }, {
                                    kind: "Field",
                                    alias: {
                                        kind: "Name",
                                        value: "postcardCode"
                                    },
                                    name: {
                                        kind: "Name",
                                        value: "code"
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "EnhancedBreezeOnRampPage"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "orderItems"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "amount"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "currency"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "value"
                                            }
                                        }]
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "page"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "createdAt"
                                            }
                                        }]
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "NotificationSessionExpiry"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    alias: {
                                        kind: "Name",
                                        value: "expiry"
                                    },
                                    name: {
                                        kind: "Name",
                                        value: "expireAt"
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "NotificationFaucetClaimAvailable"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "value"
                                    }
                                }]
                            }
                        }, {
                            kind: "InlineFragment",
                            typeCondition: {
                                kind: "NamedType",
                                name: {
                                    kind: "Name",
                                    value: "NotificationRevShare"
                                }
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "amount"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "currency"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }]
    };

function ju(o) {
    let e = o[0]._(ue.reachedEnd) + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 1 && e !== (e = n[0]._(ue.reachedEnd) + "") && O(i, e)
        },
        d(n) {
            n && f(i)
        }
    }
}

function Hu(o) {
    let e, i;
    return e = new le({
        props: {
            weight: "semibold",
            lineHeight: "120pct",
            align: "center",
            $$slots: {
                default: [ju]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 3 && (r.$$scope = {
                dirty: t,
                ctx: n
            }), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Yu(o) {
    let e, i, n, t;
    return i = new Fi({
        props: {
            icon: "empty-promotions",
            spacing: "compact",
            $$slots: {
                default: [Hu]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            e = T("div"), g(i.$$.fragment), this.h()
        },
        l(r) {
            e = I(r, "DIV", {
                class: !0
            });
            var a = B(e);
            N(i.$$.fragment, a), a.forEach(f), this.h()
        },
        h() {
            H(e, "class", "reached-end svelte-1sqgey8")
        },
        m(r, a) {
            k(r, e, a), $(i, e, null), t = !0
        },
        p(r, [a]) {
            const s = {};
            a & 3 && (s.$$scope = {
                dirty: a,
                ctx: r
            }), i.$set(s)
        },
        i(r) {
            t || (d(i.$$.fragment, r), n || oi(() => {
                n = di(e, bi, {
                    x: 0,
                    y: 50,
                    duration: 500,
                    opacity: 0
                }), n.start()
            }), t = !0)
        },
        o(r) {
            m(i.$$.fragment, r), t = !1
        },
        d(r) {
            r && f(e), v(i)
        }
    }
}

function qu(o, e, i) {
    let n;
    return j(o, x, t => i(0, n = t)), [n]
}
class Ku extends q {
    constructor(e) {
        super(), K(this, e, qu, Yu, Y, {})
    }
}
const Zu = {
    kind: "Document",
    definitions: [{
        kind: "OperationDefinition",
        operation: "mutation",
        name: {
            kind: "Name",
            value: "AcknowledgeAllNotifications"
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "acknowledgeAllNotifications"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "FragmentSpread",
                        name: {
                            kind: "Name",
                            value: "Notification"
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "SportMarket"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportMarket"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "name"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "status"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "extId"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "specifiers"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "customBetAvailable"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "provider"
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "CategoryTree"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportCategory"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "name"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "slug"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "sport"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "id"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "name"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "slug"
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "TournamentTree"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportTournament"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "name"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "slug"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "category"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "FragmentSpread",
                        name: {
                            kind: "Name",
                            value: "CategoryTree"
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "SportFixtureCompetitor"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixtureCompetitor"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "name"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "extId"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "countryCode"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "abbreviation"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "iconPath"
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "SportFixtureDataMatch"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixtureDataMatch"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "startTime"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "competitors"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "FragmentSpread",
                        name: {
                            kind: "Name",
                            value: "SportFixtureCompetitor"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "teams"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "name"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "qualifier"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "tvChannels"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "language"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "name"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "streamUrl"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "__typename"
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "SportFixtureDataOutright"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixtureDataOutright"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "name"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "startTime"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "endTime"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "__typename"
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "SportFixtureEventStatus"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixtureEventStatusData"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "__typename"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "homeScore"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "awayScore"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "matchStatus"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "clock"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "matchTime"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "remainingTime"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "periodScores"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "homeScore"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "awayScore"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "matchStatus"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "currentTeamServing"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "homeGameScore"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "awayGameScore"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "statistic"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "yellowCards"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "away"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "home"
                                }
                            }]
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "redCards"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "away"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "home"
                                }
                            }]
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "corners"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "home"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "away"
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "EsportFixtureEventStatus"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "EsportFixtureEventStatus"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "matchStatus"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "homeScore"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "awayScore"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "scoreboard"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "homeGold"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "awayGold"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "homeGoals"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "awayGoals"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "homeKills"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "awayKills"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "gameTime"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "homeDestroyedTowers"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "awayDestroyedTurrets"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "currentRound"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "currentCtTeam"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "currentDefTeam"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "time"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "awayWonRounds"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "homeWonRounds"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "remainingGameTime"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "periodScores"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "type"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "number"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "awayGoals"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "awayKills"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "awayScore"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "homeGoals"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "homeKills"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "homeScore"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "awayWonRounds"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "homeWonRounds"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "matchStatus"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "__typename"
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "SwishMarketOutcomeFragment"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SwishMarketOutcome"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "__typename"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "line"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "over"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "under"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "gradeOver"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "gradeUnder"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "suspended"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "balanced"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "name"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "competitor"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "id"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "name"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "stats"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "name"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "dataConfirmed"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "played"
                                }
                            }]
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "market"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "id"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "stat"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "name"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "value"
                                }
                            }]
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "game"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "id"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "fixture"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "id"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "extId"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "slug"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "status"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "provider"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "swishGame"
                                        },
                                        selectionSet: {
                                            kind: "SelectionSet",
                                            selections: [{
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "swishSportId"
                                                }
                                            }]
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "eventStatus"
                                        },
                                        selectionSet: {
                                            kind: "SelectionSet",
                                            selections: [{
                                                kind: "FragmentSpread",
                                                name: {
                                                    kind: "Name",
                                                    value: "SportFixtureEventStatus"
                                                }
                                            }, {
                                                kind: "FragmentSpread",
                                                name: {
                                                    kind: "Name",
                                                    value: "EsportFixtureEventStatus"
                                                }
                                            }]
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "data"
                                        },
                                        selectionSet: {
                                            kind: "SelectionSet",
                                            selections: [{
                                                kind: "InlineFragment",
                                                typeCondition: {
                                                    kind: "NamedType",
                                                    name: {
                                                        kind: "Name",
                                                        value: "SportFixtureDataMatch"
                                                    }
                                                },
                                                selectionSet: {
                                                    kind: "SelectionSet",
                                                    selections: [{
                                                        kind: "Field",
                                                        name: {
                                                            kind: "Name",
                                                            value: "__typename"
                                                        }
                                                    }, {
                                                        kind: "Field",
                                                        name: {
                                                            kind: "Name",
                                                            value: "startTime"
                                                        }
                                                    }, {
                                                        kind: "Field",
                                                        name: {
                                                            kind: "Name",
                                                            value: "competitors"
                                                        },
                                                        selectionSet: {
                                                            kind: "SelectionSet",
                                                            selections: [{
                                                                kind: "Field",
                                                                name: {
                                                                    kind: "Name",
                                                                    value: "name"
                                                                }
                                                            }, {
                                                                kind: "Field",
                                                                name: {
                                                                    kind: "Name",
                                                                    value: "extId"
                                                                }
                                                            }, {
                                                                kind: "Field",
                                                                name: {
                                                                    kind: "Name",
                                                                    value: "countryCode"
                                                                }
                                                            }, {
                                                                kind: "Field",
                                                                name: {
                                                                    kind: "Name",
                                                                    value: "abbreviation"
                                                                }
                                                            }]
                                                        }
                                                    }]
                                                }
                                            }]
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "tournament"
                                        },
                                        selectionSet: {
                                            kind: "SelectionSet",
                                            selections: [{
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "id"
                                                }
                                            }, {
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "slug"
                                                }
                                            }, {
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "name"
                                                }
                                            }, {
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "category"
                                                },
                                                selectionSet: {
                                                    kind: "SelectionSet",
                                                    selections: [{
                                                        kind: "Field",
                                                        name: {
                                                            kind: "Name",
                                                            value: "id"
                                                        }
                                                    }, {
                                                        kind: "Field",
                                                        name: {
                                                            kind: "Name",
                                                            value: "slug"
                                                        }
                                                    }, {
                                                        kind: "Field",
                                                        name: {
                                                            kind: "Name",
                                                            value: "name"
                                                        }
                                                    }, {
                                                        kind: "Field",
                                                        name: {
                                                            kind: "Name",
                                                            value: "sport"
                                                        },
                                                        selectionSet: {
                                                            kind: "SelectionSet",
                                                            selections: [{
                                                                kind: "Field",
                                                                name: {
                                                                    kind: "Name",
                                                                    value: "id"
                                                                }
                                                            }, {
                                                                kind: "Field",
                                                                name: {
                                                                    kind: "Name",
                                                                    value: "name"
                                                                }
                                                            }, {
                                                                kind: "Field",
                                                                name: {
                                                                    kind: "Name",
                                                                    value: "slug"
                                                                }
                                                            }]
                                                        }
                                                    }]
                                                }
                                            }]
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "SwishBetFragment"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SwishBet"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "__typename"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "active"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "amount"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "cashoutMultiplier"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "potentialMultiplier"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "createdAt"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "currency"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "customBet"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "odds"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "payout"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "payoutMultiplier"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "adjustments"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "id"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "payoutMultiplier"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "updatedAt"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "createdAt"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "updatedAt"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "status"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "user"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "id"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "name"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "preferenceHideBets"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "outcomes"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "__typename"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "id"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "odds"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "lineType"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "outcome"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "FragmentSpread",
                                name: {
                                    kind: "Name",
                                    value: "SwishMarketOutcomeFragment"
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "UserTags"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "User"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "name"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "isMuted"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "isRainproof"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "isIgnored"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "isHighroller"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "isSportHighroller"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "leaderboardDailyProfitRank"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "leaderboardDailyWageredRank"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "leaderboardWeeklyProfitRank"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "leaderboardWeeklyWageredRank"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "flags"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "flag"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "rank"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "createdAt"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "roles"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "name"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "expireAt"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "message"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "createdAt"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "preferenceHideBets"
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "Challenge"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "Challenge"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "type"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "active"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "adminCreated"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "completedAt"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "award"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "claimCount"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "claimMax"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "currency"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "isRefunded"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "minBetUsd"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "betCurrency"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "startAt"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "expireAt"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "updatedAt"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "createdAt"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "targetMultiplier"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "game"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "id"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "name"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "slug"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "thumbnailUrl"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "creatorUser"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "FragmentSpread",
                        name: {
                            kind: "Name",
                            value: "UserTags"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "affiliateUser"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "FragmentSpread",
                        name: {
                            kind: "Name",
                            value: "UserTags"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "wins"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "id"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "claimedBy"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "FragmentSpread",
                                name: {
                                    kind: "Name",
                                    value: "UserTags"
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "Notification"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "Notification"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "type"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "acknowledged"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "__typename"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "data"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "__typename"
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "NotificationKyc"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                alias: {
                                    kind: "Name",
                                    value: "kycStatus"
                                },
                                name: {
                                    kind: "Name",
                                    value: "status"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "UserFlag"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "createdAt"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "flag"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "ChatTip"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "createdAt"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "currency"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "amount"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "sendBy"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }]
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "NotificationKycBanned"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                alias: {
                                    kind: "Name",
                                    value: "kycBannedMessage"
                                },
                                name: {
                                    kind: "Name",
                                    value: "message"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "ChatRainUser"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "amount"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "currency"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "rain"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "createdAt"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "sendBy"
                                        },
                                        selectionSet: {
                                            kind: "SelectionSet",
                                            selections: [{
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "name"
                                                }
                                            }]
                                        }
                                    }]
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "CashAdvance"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "id"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "advanceAmount"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "currency"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "createdAt"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "UserBonus"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "createdAt"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "currency"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "amount"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "credit"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportBet"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "id"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "amount"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "active"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "currency"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "status"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "payoutMultiplier"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "payout"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "createdAt"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "system"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "potentialMultiplier"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "adjustments"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "id"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "payoutMultiplier"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "updatedAt"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "createdAt"
                                        }
                                    }]
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "user"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "id"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }]
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "outcomes"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "odds"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "status"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "outcome"
                                        },
                                        selectionSet: {
                                            kind: "SelectionSet",
                                            selections: [{
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "id"
                                                }
                                            }, {
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "name"
                                                }
                                            }, {
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "active"
                                                }
                                            }, {
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "odds"
                                                }
                                            }]
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "market"
                                        },
                                        selectionSet: {
                                            kind: "SelectionSet",
                                            selections: [{
                                                kind: "FragmentSpread",
                                                name: {
                                                    kind: "Name",
                                                    value: "SportMarket"
                                                }
                                            }]
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "fixture"
                                        },
                                        selectionSet: {
                                            kind: "SelectionSet",
                                            selections: [{
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "id"
                                                }
                                            }, {
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "slug"
                                                }
                                            }, {
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "provider"
                                                }
                                            }, {
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "tournament"
                                                },
                                                selectionSet: {
                                                    kind: "SelectionSet",
                                                    selections: [{
                                                        kind: "FragmentSpread",
                                                        name: {
                                                            kind: "Name",
                                                            value: "TournamentTree"
                                                        }
                                                    }]
                                                }
                                            }, {
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "data"
                                                },
                                                selectionSet: {
                                                    kind: "SelectionSet",
                                                    selections: [{
                                                        kind: "FragmentSpread",
                                                        name: {
                                                            kind: "Name",
                                                            value: "SportFixtureDataMatch"
                                                        }
                                                    }, {
                                                        kind: "FragmentSpread",
                                                        name: {
                                                            kind: "Name",
                                                            value: "SportFixtureDataOutright"
                                                        }
                                                    }, {
                                                        kind: "Field",
                                                        name: {
                                                            kind: "Name",
                                                            value: "__typename"
                                                        }
                                                    }]
                                                }
                                            }]
                                        }
                                    }]
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SwishBet"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "FragmentSpread",
                                name: {
                                    kind: "Name",
                                    value: "SwishBetFragment"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "RacingBet"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "id"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "outcomes"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "id"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "event"
                                        },
                                        selectionSet: {
                                            kind: "SelectionSet",
                                            selections: [{
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "eventNumber"
                                                }
                                            }, {
                                                kind: "Field",
                                                name: {
                                                    kind: "Name",
                                                    value: "meeting"
                                                },
                                                selectionSet: {
                                                    kind: "SelectionSet",
                                                    selections: [{
                                                        kind: "Field",
                                                        name: {
                                                            kind: "Name",
                                                            value: "venue"
                                                        },
                                                        selectionSet: {
                                                            kind: "SelectionSet",
                                                            selections: [{
                                                                kind: "Field",
                                                                name: {
                                                                    kind: "Name",
                                                                    value: "name"
                                                                }
                                                            }, {
                                                                kind: "Field",
                                                                name: {
                                                                    kind: "Name",
                                                                    value: "geoBlocked"
                                                                }
                                                            }]
                                                        }
                                                    }]
                                                }
                                            }]
                                        }
                                    }]
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "payout"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "currency"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "WalletDeposit"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "id"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "createdAt"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "amount"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "currency"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "chain"
                                }
                            }, {
                                kind: "Field",
                                alias: {
                                    kind: "Name",
                                    value: "walletStatus"
                                },
                                name: {
                                    kind: "Name",
                                    value: "status"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "tokensReceived"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "currency"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "amount"
                                        }
                                    }]
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "NotificationFiatDeposit"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "id"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "createdAt"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "amount"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "currency"
                                }
                            }, {
                                kind: "Field",
                                alias: {
                                    kind: "Name",
                                    value: "fiatStatus"
                                },
                                name: {
                                    kind: "Name",
                                    value: "status"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "NotificationFiatWithdrawal"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "id"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "createdAt"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "amount"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "currency"
                                }
                            }, {
                                kind: "Field",
                                alias: {
                                    kind: "Name",
                                    value: "fiatStatus"
                                },
                                name: {
                                    kind: "Name",
                                    value: "status"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "NotificationFiatReversal"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "id"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "createdAt"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "amount"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "currency"
                                }
                            }, {
                                kind: "Field",
                                alias: {
                                    kind: "Name",
                                    value: "fiatStatus"
                                },
                                name: {
                                    kind: "Name",
                                    value: "status"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "RacePosition"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "position"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "payoutAmount"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "currency"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "race"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "endTime"
                                        }
                                    }]
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "CommunityMute"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "active"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "message"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "expireAt"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "ChallengeWin"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "challenge"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "FragmentSpread",
                                        name: {
                                            kind: "Name",
                                            value: "Challenge"
                                        }
                                    }]
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "Challenge"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "FragmentSpread",
                                name: {
                                    kind: "Name",
                                    value: "Challenge"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "NotificationFiatError"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "code"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "limitType"
                                }
                            }, {
                                kind: "Field",
                                alias: {
                                    kind: "Name",
                                    value: "fiatErrorAmount"
                                },
                                name: {
                                    kind: "Name",
                                    value: "amount"
                                }
                            }, {
                                kind: "Field",
                                alias: {
                                    kind: "Name",
                                    value: "fiatErrorCurrency"
                                },
                                name: {
                                    kind: "Name",
                                    value: "currency"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "VeriffUser"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                alias: {
                                    kind: "Name",
                                    value: "veriffStatus"
                                },
                                name: {
                                    kind: "Name",
                                    value: "status"
                                }
                            }, {
                                kind: "Field",
                                alias: {
                                    kind: "Name",
                                    value: "veriffReason"
                                },
                                name: {
                                    kind: "Name",
                                    value: "reason"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportsbookPromotionBet"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "id"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "bet"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "id"
                                        }
                                    }]
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "betAmount"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "value"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "currency"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "payout"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "payoutValue"
                                }
                            }, {
                                kind: "Field",
                                alias: {
                                    kind: "Name",
                                    value: "sportsbookPromotionBetStatus"
                                },
                                name: {
                                    kind: "Name",
                                    value: "status"
                                }
                            }, {
                                kind: "Field",
                                alias: {
                                    kind: "Name",
                                    value: "sportsbookPromotionBetUser"
                                },
                                name: {
                                    kind: "Name",
                                    value: "user"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "id"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }]
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "promotion"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "id"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }]
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "UserPostcardCode"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "id"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "claimedAt"
                                }
                            }, {
                                kind: "Field",
                                alias: {
                                    kind: "Name",
                                    value: "postcardCode"
                                },
                                name: {
                                    kind: "Name",
                                    value: "code"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "EnhancedBreezeOnRampPage"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "orderItems"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "amount"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "currency"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "value"
                                        }
                                    }]
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "page"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "createdAt"
                                        }
                                    }]
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "NotificationSessionExpiry"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                alias: {
                                    kind: "Name",
                                    value: "expiry"
                                },
                                name: {
                                    kind: "Name",
                                    value: "expireAt"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "NotificationFaucetClaimAvailable"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "value"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "NotificationRevShare"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "amount"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "currency"
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }]
};

function Xu(o) {
    let e = o[2]._(ue.markAllAsRead) + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 4 && e !== (e = n[2]._(ue.markAllAsRead) + "") && O(i, e)
        },
        d(n) {
            n && f(i)
        }
    }
}

function Qu(o) {
    let e, i;
    return e = new se({
        props: {
            size: "xs",
            variant: "link",
            disabled: !o[1] || o[0],
            $$slots: {
                default: [Xu]
            },
            $$scope: {
                ctx: o
            }
        }
    }), e.$on("click", o[5]), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, [t]) {
            const r = {};
            t & 3 && (r.disabled = !n[1] || n[0]), t & 132 && (r.$$scope = {
                dirty: t,
                ctx: n
            }), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Ju(o, e, i) {
    let n, t;
    j(o, xe, c => i(1, n = c)), j(o, x, c => i(2, t = c));
    let {
        notifications: r = []
    } = e, {
        loading: a = !1
    } = e;
    const s = ri(),
        l = async () => {
            await cl(Zu, {}) && (i(4, r = r.map(_ => ({ ..._,
                acknowledged: !0
            }))), al(xe, n = !1, n), s("readAll", r))
        },
        u = () => l();
    return o.$$set = c => {
        "notifications" in c && i(4, r = c.notifications), "loading" in c && i(0, a = c.loading)
    }, [a, n, t, l, r, u]
}
class xu extends q {
    constructor(e) {
        super(), K(this, e, Ju, Qu, Y, {
            notifications: 4,
            loading: 0
        })
    }
}
const ec = o => ({}),
    Vt = o => ({}),
    nc = o => ({}),
    Mt = o => ({});

function Ot(o) {
    let e, i, n, t, r;
    var a = o[5];

    function s(c, _) {
        return {}
    }
    a && (i = _e(a, s()));
    let l = [{
            class: "notification-icon"
        }, o[9]],
        u = {};
    for (let c = 0; c < l.length; c += 1) u = ae(u, l[c]);
    return {
        c() {
            e = T("div"), i && g(i.$$.fragment), this.h()
        },
        l(c) {
            e = I(c, "DIV", {
                class: !0
            });
            var _ = B(e);
            i && N(i.$$.fragment, _), _.forEach(f), this.h()
        },
        h() {
            we(e, u), re(e, "svelte-tm583l", !0)
        },
        m(c, _) {
            k(c, e, _), i && $(i, e, null), n = !0, t || (r = [Ee(e, "click", o[11]), Ee(e, "keypress", o[11])], t = !0)
        },
        p(c, _) {
            if (_ & 32 && a !== (a = c[5])) {
                if (i) {
                    y();
                    const S = i;
                    m(S.$$.fragment, 1, 0, () => {
                        v(S, 1)
                    }), w()
                }
                a ? (i = _e(a, s()), g(i.$$.fragment), d(i.$$.fragment, 1), $(i, e, null)) : i = null
            }
            we(e, u = de(l, [{
                class: "notification-icon"
            }, _ & 512 && c[9]])), re(e, "svelte-tm583l", !0)
        },
        i(c) {
            n || (i && d(i.$$.fragment, c), n = !0)
        },
        o(c) {
            i && m(i.$$.fragment, c), n = !1
        },
        d(c) {
            c && f(e), i && v(i), t = !1, si(r)
        }
    }
}

function tc(o) {
    let e, i = o[10]._(o[2]) + "",
        n;
    return {
        c() {
            e = T("span"), n = P(i)
        },
        l(t) {
            e = I(t, "SPAN", {});
            var r = B(e);
            n = D(r, i), r.forEach(f)
        },
        m(t, r) {
            k(t, e, r), z(e, n)
        },
        p(t, r) {
            r & 1028 && i !== (i = t[10]._(t[2]) + "") && O(n, i)
        },
        i: A,
        o: A,
        d(t) {
            t && f(e)
        }
    }
}

function ic(o) {
    let e, i, n;
    const t = [o[4]];
    var r = o[2];

    function a(s, l) {
        let u = {};
        for (let c = 0; c < t.length; c += 1) u = ae(u, t[c]);
        return l !== void 0 && l & 16 && (u = ae(u, de(t, [fe(s[4])]))), {
            props: u
        }
    }
    return r && (e = _e(r, a(o))), {
        c() {
            e && g(e.$$.fragment), i = h()
        },
        l(s) {
            e && N(e.$$.fragment, s), i = h()
        },
        m(s, l) {
            e && $(e, s, l), k(s, i, l), n = !0
        },
        p(s, l) {
            if (l & 4 && r !== (r = s[2])) {
                if (e) {
                    y();
                    const u = e;
                    m(u.$$.fragment, 1, 0, () => {
                        v(u, 1)
                    }), w()
                }
                r ? (e = _e(r, a(s, l)), g(e.$$.fragment), d(e.$$.fragment, 1), $(e, i.parentNode, i)) : e = null
            } else if (r) {
                const u = l & 16 ? de(t, [fe(s[4])]) : {};
                e.$set(u)
            }
        },
        i(s) {
            n || (e && d(e.$$.fragment, s), n = !0)
        },
        o(s) {
            e && m(e.$$.fragment, s), n = !1
        },
        d(s) {
            s && f(i), e && v(e, s)
        }
    }
}

function lc(o) {
    let e, i, n, t;
    const r = [ic, tc],
        a = [];

    function s(l, u) {
        return typeof l[2] == "function" ? 0 : 1
    }
    return e = s(o), i = a[e] = r[e](o), {
        c() {
            i.c(), n = h()
        },
        l(l) {
            i.l(l), n = h()
        },
        m(l, u) {
            a[e].m(l, u), k(l, n, u), t = !0
        },
        p(l, u) {
            let c = e;
            e = s(l), e === c ? a[e].p(l, u) : (y(), m(a[c], 1, 1, () => {
                a[c] = null
            }), w(), i = a[e], i ? i.p(l, u) : (i = a[e] = r[e](l), i.c()), d(i, 1), i.m(n.parentNode, n))
        },
        i(l) {
            t || (d(i), t = !0)
        },
        o(l) {
            m(i), t = !1
        },
        d(l) {
            l && f(n), a[e].d(l)
        }
    }
}

function ac(o) {
    let e, i, n;
    return i = new le({
        props: {
            weight: "semibold",
            variant: "highlighted",
            $$slots: {
                default: [lc]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            e = T("div"), g(i.$$.fragment), this.h()
        },
        l(t) {
            e = I(t, "DIV", {
                class: !0
            });
            var r = B(e);
            N(i.$$.fragment, r), r.forEach(f), this.h()
        },
        h() {
            H(e, "class", "title svelte-tm583l")
        },
        m(t, r) {
            k(t, e, r), $(i, e, null), n = !0
        },
        p(t, r) {
            const a = {};
            r & 9236 && (a.$$scope = {
                dirty: r,
                ctx: t
            }), i.$set(a)
        },
        i(t) {
            n || (d(i.$$.fragment, t), n = !0)
        },
        o(t) {
            m(i.$$.fragment, t), n = !1
        },
        d(t) {
            t && f(e), v(i)
        }
    }
}

function Lt(o) {
    let e, i;
    return e = new le({
        props: {
            iconSpace: !1,
            $$slots: {
                default: [sc]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 9240 && (r.$$scope = {
                dirty: t,
                ctx: n
            }), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function rc(o) {
    let e, i = o[10]._(o[3]) + "",
        n;
    return {
        c() {
            e = T("span"), n = P(i)
        },
        l(t) {
            e = I(t, "SPAN", {});
            var r = B(e);
            n = D(r, i), r.forEach(f)
        },
        m(t, r) {
            k(t, e, r), z(e, n)
        },
        p(t, r) {
            r & 1032 && i !== (i = t[10]._(t[3]) + "") && O(n, i)
        },
        i: A,
        o: A,
        d(t) {
            t && f(e)
        }
    }
}

function oc(o) {
    let e, i, n;
    const t = [o[4]];
    var r = o[3];

    function a(s, l) {
        let u = {};
        for (let c = 0; c < t.length; c += 1) u = ae(u, t[c]);
        return l !== void 0 && l & 16 && (u = ae(u, de(t, [fe(s[4])]))), {
            props: u
        }
    }
    return r && (e = _e(r, a(o))), {
        c() {
            e && g(e.$$.fragment), i = h()
        },
        l(s) {
            e && N(e.$$.fragment, s), i = h()
        },
        m(s, l) {
            e && $(e, s, l), k(s, i, l), n = !0
        },
        p(s, l) {
            if (l & 8 && r !== (r = s[3])) {
                if (e) {
                    y();
                    const u = e;
                    m(u.$$.fragment, 1, 0, () => {
                        v(u, 1)
                    }), w()
                }
                r ? (e = _e(r, a(s, l)), g(e.$$.fragment), d(e.$$.fragment, 1), $(e, i.parentNode, i)) : e = null
            } else if (r) {
                const u = l & 16 ? de(t, [fe(s[4])]) : {};
                e.$set(u)
            }
        },
        i(s) {
            n || (e && d(e.$$.fragment, s), n = !0)
        },
        o(s) {
            e && m(e.$$.fragment, s), n = !1
        },
        d(s) {
            s && f(i), e && v(e, s)
        }
    }
}

function sc(o) {
    let e, i, n, t;
    const r = [oc, rc],
        a = [];

    function s(l, u) {
        return typeof l[3] == "function" ? 0 : 1
    }
    return e = s(o), i = a[e] = r[e](o), {
        c() {
            i.c(), n = h()
        },
        l(l) {
            i.l(l), n = h()
        },
        m(l, u) {
            a[e].m(l, u), k(l, n, u), t = !0
        },
        p(l, u) {
            let c = e;
            e = s(l), e === c ? a[e].p(l, u) : (y(), m(a[c], 1, 1, () => {
                a[c] = null
            }), w(), i = a[e], i ? i.p(l, u) : (i = a[e] = r[e](l), i.c()), d(i, 1), i.m(n.parentNode, n))
        },
        i(l) {
            t || (d(i), t = !0)
        },
        o(l) {
            m(i), t = !1
        },
        d(l) {
            l && f(n), a[e].d(l)
        }
    }
}

function uc(o) {
    let e, i, n = o[3] && Lt(o);
    return {
        c() {
            n && n.c(), e = h()
        },
        l(t) {
            n && n.l(t), e = h()
        },
        m(t, r) {
            n && n.m(t, r), k(t, e, r), i = !0
        },
        p(t, r) {
            t[3] ? n ? (n.p(t, r), r & 8 && d(n, 1)) : (n = Lt(t), n.c(), d(n, 1), n.m(e.parentNode, e)) : n && (y(), m(n, 1, 1, () => {
                n = null
            }), w())
        },
        i(t) {
            i || (d(n), i = !0)
        },
        o(t) {
            m(n), i = !1
        },
        d(t) {
            t && f(e), n && n.d(t)
        }
    }
}

function cc(o) {
    let e, i, n, t, r, a, s, l, u, c, _ = o[5] && Ot(o);
    const S = o[12].title,
        F = pe(S, o, o[13], Mt),
        E = F || ac(o),
        R = o[12].body,
        U = pe(R, o, o[13], Vt),
        C = U || uc(o);
    let L = [{
            class: "notification-body"
        }, o[9]],
        J = {};
    for (let G = 0; G < L.length; G += 1) J = ae(J, L[G]);
    const ee = o[12].default,
        ne = pe(ee, o, o[13], null);
    return {
        c() {
            e = T("div"), _ && _.c(), i = V(), n = T("div"), E && E.c(), t = V(), C && C.c(), r = V(), ne && ne.c(), this.h()
        },
        l(G) {
            e = I(G, "DIV", {
                "data-test": !0,
                "data-notification-name": !0,
                "data-dd-action-name": !0,
                class: !0
            });
            var b = B(e);
            _ && _.l(b), i = M(b), n = I(b, "DIV", {
                class: !0
            });
            var W = B(n);
            E && E.l(W), t = M(W), C && C.l(W), W.forEach(f), r = M(b), ne && ne.l(b), b.forEach(f), this.h()
        },
        h() {
            we(n, J), re(n, "svelte-tm583l", !0), H(e, "data-test", "notification"), H(e, "data-notification-name", o[0]), H(e, "data-dd-action-name", a = "notification-" + o[8]), H(e, "class", s = "notification " + (o[6] ? ? "default") + " " + o[1] + " svelte-tm583l"), re(e, "clickable", o[7] !== void 0)
        },
        m(G, b) {
            k(G, e, b), _ && _.m(e, null), z(e, i), z(e, n), E && E.m(n, null), z(n, t), C && C.m(n, null), z(e, r), ne && ne.m(e, null), l = !0, u || (c = [Ee(n, "click", o[11]), Ee(n, "keypress", o[11])], u = !0)
        },
        p(G, [b]) {
            G[5] ? _ ? (_.p(G, b), b & 32 && d(_, 1)) : (_ = Ot(G), _.c(), d(_, 1), _.m(e, i)) : _ && (y(), m(_, 1, 1, () => {
                _ = null
            }), w()), F ? F.p && (!l || b & 8192) && ge(F, S, G, G[13], l ? ve(S, G[13], b, nc) : $e(G[13]), Mt) : E && E.p && (!l || b & 1044) && E.p(G, l ? b : -1), U ? U.p && (!l || b & 8192) && ge(U, R, G, G[13], l ? ve(R, G[13], b, ec) : $e(G[13]), Vt) : C && C.p && (!l || b & 1048) && C.p(G, l ? b : -1), we(n, J = de(L, [{
                class: "notification-body"
            }, b & 512 && G[9]])), re(n, "svelte-tm583l", !0), ne && ne.p && (!l || b & 8192) && ge(ne, ee, G, G[13], l ? ve(ee, G[13], b, null) : $e(G[13]), null), (!l || b & 1) && H(e, "data-notification-name", G[0]), (!l || b & 256 && a !== (a = "notification-" + G[8])) && H(e, "data-dd-action-name", a), (!l || b & 66 && s !== (s = "notification " + (G[6] ? ? "default") + " " + G[1] + " svelte-tm583l")) && H(e, "class", s), (!l || b & 194) && re(e, "clickable", G[7] !== void 0)
        },
        i(G) {
            l || (d(_), d(E, G), d(C, G), d(ne, G), l = !0)
        },
        o(G) {
            m(_), m(E, G), m(C, G), m(ne, G), l = !1
        },
        d(G) {
            G && f(e), _ && _.d(), E && E.d(G), C && C.d(G), ne && ne.d(G), u = !1, si(c)
        }
    }
}

function dc(o, e, i) {
    let n, t;
    j(o, x, C => i(10, t = C));
    let {
        $$slots: r = {},
        $$scope: a
    } = e, {
        name: s = void 0
    } = e, {
        spacing: l = "normal"
    } = e, {
        title: u
    } = e, {
        body: c = void 0
    } = e, {
        props: _ = void 0
    } = e, {
        icon: S = void 0
    } = e, {
        type: F = void 0
    } = e, {
        click: E = void 0
    } = e, {
        notificationType: R = void 0
    } = e;
    const U = () => {
        E && E()
    };
    return o.$$set = C => {
        "name" in C && i(0, s = C.name), "spacing" in C && i(1, l = C.spacing), "title" in C && i(2, u = C.title), "body" in C && i(3, c = C.body), "props" in C && i(4, _ = C.props), "icon" in C && i(5, S = C.icon), "type" in C && i(6, F = C.type), "click" in C && i(7, E = C.click), "notificationType" in C && i(8, R = C.notificationType), "$$scope" in C && i(13, a = C.$$scope)
    }, o.$$.update = () => {
        o.$$.dirty & 128 && i(9, n = E ? {
            role: "button",
            tabindex: 0
        } : {})
    }, [s, l, u, c, _, S, F, E, R, n, t, U, r, a]
}
class mc extends q {
    constructor(e) {
        super(), K(this, e, dc, cc, Y, {
            name: 0,
            spacing: 1,
            title: 2,
            body: 3,
            props: 4,
            icon: 5,
            type: 6,
            click: 7,
            notificationType: 8
        })
    }
}

function Ut(o) {
    let e, i, n, t;
    return i = new yi({
        props: {
            relative: !0,
            style: "width: 5px; height: 5px"
        }
    }), {
        c() {
            e = T("div"), g(i.$$.fragment)
        },
        l(r) {
            e = I(r, "DIV", {});
            var a = B(e);
            N(i.$$.fragment, a), a.forEach(f)
        },
        m(r, a) {
            k(r, e, a), $(i, e, null), t = !0
        },
        i(r) {
            t || (d(i.$$.fragment, r), n && n.end(1), t = !0)
        },
        o(r) {
            m(i.$$.fragment, r), r && (n = ol(e, ua, {
                opacity: 0,
                start: .7,
                delay: 100
            })), t = !1
        },
        d(r) {
            r && f(e), v(i), r && n && n.end()
        }
    }
}

function Wt(o) {
    let e, i, n;
    return i = new le({
        props: {
            variant: "subtle",
            lineHeight: "120pct",
            size: "sm",
            $$slots: {
                default: [_c]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            e = T("div"), g(i.$$.fragment), this.h()
        },
        l(t) {
            e = I(t, "DIV", {
                class: !0
            });
            var r = B(e);
            N(i.$$.fragment, r), r.forEach(f), this.h()
        },
        h() {
            H(e, "class", "time-wrapper chromatic-ignore svelte-cispis")
        },
        m(t, r) {
            k(t, e, r), $(i, e, null), n = !0
        },
        p(t, r) {
            const a = {};
            r & 10 && (a.$$scope = {
                dirty: r,
                ctx: t
            }), i.$set(a)
        },
        i(t) {
            n || (d(i.$$.fragment, t), n = !0)
        },
        o(t) {
            m(i.$$.fragment, t), n = !1
        },
        d(t) {
            t && f(e), v(i)
        }
    }
}

function fc(o) {
    let e, i;
    return e = new hi({
        props: {
            value: o[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 2 && (r.value = n[1]), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function kc(o) {
    let e, i;
    return e = new da({
        props: {
            value: o[1]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 2 && (r.value = n[1]), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function _c(o) {
    let e, i, n, t, r;
    const a = [kc, fc],
        s = [];

    function l(u, c) {
        return c & 2 && (e = null), e == null && (e = !!u[2](new Date(u[1]))), e ? 0 : 1
    }
    return i = l(o, -1), n = s[i] = a[i](o), {
        c() {
            n.c(), t = h()
        },
        l(u) {
            n.l(u), t = h()
        },
        m(u, c) {
            s[i].m(u, c), k(u, t, c), r = !0
        },
        p(u, c) {
            let _ = i;
            i = l(u, c), i === _ ? s[i].p(u, c) : (y(), m(s[_], 1, 1, () => {
                s[_] = null
            }), w(), n = s[i], n ? n.p(u, c) : (n = s[i] = a[i](u), n.c()), d(n, 1), n.m(t.parentNode, t))
        },
        i(u) {
            r || (d(n), r = !0)
        },
        o(u) {
            m(n), r = !1
        },
        d(u) {
            u && f(t), s[i].d(u)
        }
    }
}

function pc(o) {
    let e, i, n, t = !o[0] && Ut(),
        r = o[1] && Wt(o);
    return {
        c() {
            e = T("div"), t && t.c(), i = V(), r && r.c(), this.h()
        },
        l(a) {
            e = I(a, "DIV", {
                class: !0
            });
            var s = B(e);
            t && t.l(s), i = M(s), r && r.l(s), s.forEach(f), this.h()
        },
        h() {
            H(e, "class", "title-meta svelte-cispis")
        },
        m(a, s) {
            k(a, e, s), t && t.m(e, null), z(e, i), r && r.m(e, null), n = !0
        },
        p(a, [s]) {
            a[0] ? t && (y(), m(t, 1, 1, () => {
                t = null
            }), w()) : t ? s & 1 && d(t, 1) : (t = Ut(), t.c(), d(t, 1), t.m(e, i)), a[1] ? r ? (r.p(a, s), s & 2 && d(r, 1)) : (r = Wt(a), r.c(), d(r, 1), r.m(e, null)) : r && (y(), m(r, 1, 1, () => {
                r = null
            }), w())
        },
        i(a) {
            n || (d(t), d(r), n = !0)
        },
        o(a) {
            m(t), m(r), n = !1
        },
        d(a) {
            a && f(e), t && t.d(), r && r.d()
        }
    }
}

function gc(o, e, i) {
    let {
        acknowledged: n = !1
    } = e, {
        createdAt: t = void 0
    } = e;
    const r = a => {
        const s = new Date;
        return s.getFullYear() === a.getFullYear() && s.getMonth() === a.getMonth() && s.getDate() === a.getDate()
    };
    return o.$$set = a => {
        "acknowledged" in a && i(0, n = a.acknowledged), "createdAt" in a && i(1, t = a.createdAt)
    }, [n, t, r]
}
class $c extends q {
    constructor(e) {
        super(), K(this, e, gc, pc, Y, {
            acknowledged: 0,
            createdAt: 1
        })
    }
}

function vc(o) {
    let e, i = o[6]._(o[5]) + "",
        n;
    return {
        c() {
            e = T("span"), n = P(i)
        },
        l(t) {
            e = I(t, "SPAN", {});
            var r = B(e);
            n = D(r, i), r.forEach(f)
        },
        m(t, r) {
            k(t, e, r), z(e, n)
        },
        p(t, r) {
            r & 96 && i !== (i = t[6]._(t[5]) + "") && O(n, i)
        },
        i: A,
        o: A,
        d(t) {
            t && f(e)
        }
    }
}

function Nc(o) {
    let e, i, n;
    const t = [o[3]];
    var r = o[5];

    function a(s, l) {
        let u = {};
        for (let c = 0; c < t.length; c += 1) u = ae(u, t[c]);
        return l !== void 0 && l & 8 && (u = ae(u, de(t, [fe(s[3])]))), {
            props: u
        }
    }
    return r && (e = _e(r, a(o))), {
        c() {
            e && g(e.$$.fragment), i = h()
        },
        l(s) {
            e && N(e.$$.fragment, s), i = h()
        },
        m(s, l) {
            e && $(e, s, l), k(s, i, l), n = !0
        },
        p(s, l) {
            if (l & 32 && r !== (r = s[5])) {
                if (e) {
                    y();
                    const u = e;
                    m(u.$$.fragment, 1, 0, () => {
                        v(u, 1)
                    }), w()
                }
                r ? (e = _e(r, a(s, l)), g(e.$$.fragment), d(e.$$.fragment, 1), $(e, i.parentNode, i)) : e = null
            } else if (r) {
                const u = l & 8 ? de(t, [fe(s[3])]) : {};
                e.$set(u)
            }
        },
        i(s) {
            n || (e && d(e.$$.fragment, s), n = !0)
        },
        o(s) {
            e && m(e.$$.fragment, s), n = !1
        },
        d(s) {
            s && f(i), e && v(e, s)
        }
    }
}

function hc(o) {
    let e, i, n, t;
    const r = [Nc, vc],
        a = [];

    function s(l, u) {
        return typeof l[5] == "function" ? 0 : 1
    }
    return e = s(o), i = a[e] = r[e](o), {
        c() {
            i.c(), n = h()
        },
        l(l) {
            i.l(l), n = h()
        },
        m(l, u) {
            a[e].m(l, u), k(l, n, u), t = !0
        },
        p(l, u) {
            let c = e;
            e = s(l), e === c ? a[e].p(l, u) : (y(), m(a[c], 1, 1, () => {
                a[c] = null
            }), w(), i = a[e], i ? i.p(l, u) : (i = a[e] = r[e](l), i.c()), d(i, 1), i.m(n.parentNode, n))
        },
        i(l) {
            t || (d(i), t = !0)
        },
        o(l) {
            m(i), t = !1
        },
        d(l) {
            l && f(n), a[e].d(l)
        }
    }
}

function Sc(o) {
    let e, i, n, t, r;
    return i = new le({
        props: {
            weight: "semibold",
            lineHeight: "120pct",
            variant: "highlighted",
            $$slots: {
                default: [hc]
            },
            $$scope: {
                ctx: o
            }
        }
    }), t = new $c({
        props: {
            acknowledged: o[2],
            createdAt: o[7](o[3]) ? o[3].createdAt : void 0
        }
    }), {
        c() {
            e = T("div"), g(i.$$.fragment), n = V(), g(t.$$.fragment), this.h()
        },
        l(a) {
            e = I(a, "DIV", {
                class: !0
            });
            var s = B(e);
            N(i.$$.fragment, s), n = M(s), N(t.$$.fragment, s), s.forEach(f), this.h()
        },
        h() {
            H(e, "class", "title svelte-6fneqx"), re(e, "with-body", !!o[4])
        },
        m(a, s) {
            k(a, e, s), $(i, e, null), z(e, n), $(t, e, null), r = !0
        },
        p(a, s) {
            const l = {};
            s & 360 && (l.$$scope = {
                dirty: s,
                ctx: a
            }), i.$set(l);
            const u = {};
            s & 4 && (u.acknowledged = a[2]), s & 8 && (u.createdAt = a[7](a[3]) ? a[3].createdAt : void 0), t.$set(u), (!r || s & 16) && re(e, "with-body", !!a[4])
        },
        i(a) {
            r || (d(i.$$.fragment, a), d(t.$$.fragment, a), r = !0)
        },
        o(a) {
            m(i.$$.fragment, a), m(t.$$.fragment, a), r = !1
        },
        d(a) {
            a && f(e), v(i), v(t)
        }
    }
}

function zt(o) {
    let e, i, n;
    return i = new le({
        props: {
            iconSpace: !1,
            weight: "normal",
            lineHeight: "120pct",
            $$slots: {
                default: [yc]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            e = T("span"), g(i.$$.fragment), this.h()
        },
        l(t) {
            e = I(t, "SPAN", {
                class: !0
            });
            var r = B(e);
            N(i.$$.fragment, r), r.forEach(f), this.h()
        },
        h() {
            H(e, "class", "override-child-weights svelte-6fneqx")
        },
        m(t, r) {
            k(t, e, r), $(i, e, null), n = !0
        },
        p(t, r) {
            const a = {};
            r & 344 && (a.$$scope = {
                dirty: r,
                ctx: t
            }), i.$set(a)
        },
        i(t) {
            n || (d(i.$$.fragment, t), n = !0)
        },
        o(t) {
            m(i.$$.fragment, t), n = !1
        },
        d(t) {
            t && f(e), v(i)
        }
    }
}

function bc(o) {
    let e, i = o[6]._(o[4]) + "",
        n;
    return {
        c() {
            e = T("span"), n = P(i)
        },
        l(t) {
            e = I(t, "SPAN", {});
            var r = B(e);
            n = D(r, i), r.forEach(f)
        },
        m(t, r) {
            k(t, e, r), z(e, n)
        },
        p(t, r) {
            r & 80 && i !== (i = t[6]._(t[4]) + "") && O(n, i)
        },
        i: A,
        o: A,
        d(t) {
            t && f(e)
        }
    }
}

function Fc(o) {
    let e, i, n;
    const t = [o[3]];
    var r = o[4];

    function a(s, l) {
        let u = {};
        for (let c = 0; c < t.length; c += 1) u = ae(u, t[c]);
        return l !== void 0 && l & 8 && (u = ae(u, de(t, [fe(s[3])]))), {
            props: u
        }
    }
    return r && (e = _e(r, a(o))), {
        c() {
            e && g(e.$$.fragment), i = h()
        },
        l(s) {
            e && N(e.$$.fragment, s), i = h()
        },
        m(s, l) {
            e && $(e, s, l), k(s, i, l), n = !0
        },
        p(s, l) {
            if (l & 16 && r !== (r = s[4])) {
                if (e) {
                    y();
                    const u = e;
                    m(u.$$.fragment, 1, 0, () => {
                        v(u, 1)
                    }), w()
                }
                r ? (e = _e(r, a(s, l)), g(e.$$.fragment), d(e.$$.fragment, 1), $(e, i.parentNode, i)) : e = null
            } else if (r) {
                const u = l & 8 ? de(t, [fe(s[3])]) : {};
                e.$set(u)
            }
        },
        i(s) {
            n || (e && d(e.$$.fragment, s), n = !0)
        },
        o(s) {
            e && m(e.$$.fragment, s), n = !1
        },
        d(s) {
            s && f(i), e && v(e, s)
        }
    }
}

function yc(o) {
    let e, i, n, t;
    const r = [Fc, bc],
        a = [];

    function s(l, u) {
        return typeof l[4] == "function" ? 0 : 1
    }
    return e = s(o), i = a[e] = r[e](o), {
        c() {
            i.c(), n = h()
        },
        l(l) {
            i.l(l), n = h()
        },
        m(l, u) {
            a[e].m(l, u), k(l, n, u), t = !0
        },
        p(l, u) {
            let c = e;
            e = s(l), e === c ? a[e].p(l, u) : (y(), m(a[c], 1, 1, () => {
                a[c] = null
            }), w(), i = a[e], i ? i.p(l, u) : (i = a[e] = r[e](l), i.c()), d(i, 1), i.m(n.parentNode, n))
        },
        i(l) {
            t || (d(i), t = !0)
        },
        o(l) {
            m(i), t = !1
        },
        d(l) {
            l && f(n), a[e].d(l)
        }
    }
}

function wc(o) {
    let e, i, n = o[4] && zt(o);
    return {
        c() {
            n && n.c(), e = h()
        },
        l(t) {
            n && n.l(t), e = h()
        },
        m(t, r) {
            n && n.m(t, r), k(t, e, r), i = !0
        },
        p(t, r) {
            t[4] ? n ? (n.p(t, r), r & 16 && d(n, 1)) : (n = zt(t), n.c(), d(n, 1), n.m(e.parentNode, e)) : n && (y(), m(n, 1, 1, () => {
                n = null
            }), w())
        },
        i(t) {
            i || (d(n), i = !0)
        },
        o(t) {
            m(n), i = !1
        },
        d(t) {
            t && f(e), n && n.d(t)
        }
    }
}

function Cc(o) {
    let e, i;
    const n = [o[0], {
        name: o[1]
    }, {
        spacing: "compact"
    }];
    let t = {
        $$slots: {
            body: [wc],
            title: [Sc]
        },
        $$scope: {
            ctx: o
        }
    };
    for (let r = 0; r < n.length; r += 1) t = ae(t, n[r]);
    return e = new mc({
        props: t
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(r) {
            N(e.$$.fragment, r)
        },
        m(r, a) {
            $(e, r, a), i = !0
        },
        p(r, [a]) {
            const s = a & 3 ? de(n, [a & 1 && fe(r[0]), a & 2 && {
                name: r[1]
            }, n[2]]) : {};
            a & 380 && (s.$$scope = {
                dirty: a,
                ctx: r
            }), e.$set(s)
        },
        i(r) {
            i || (d(e.$$.fragment, r), i = !0)
        },
        o(r) {
            m(e.$$.fragment, r), i = !1
        },
        d(r) {
            v(e, r)
        }
    }
}

function Ac(o, e, i) {
    let n, t, r, a, s;
    j(o, x, _ => i(6, s = _));
    let {
        notification: l
    } = e, {
        name: u = void 0
    } = e;
    const c = _ => !!(_ && "createdAt" in _);
    return o.$$set = _ => {
        "notification" in _ && i(0, l = _.notification), "name" in _ && i(1, u = _.name)
    }, o.$$.update = () => {
        o.$$.dirty & 1 && i(5, {
            title: n,
            body: t,
            props: r,
            acknowledged: a
        } = l, n, (i(4, t), i(0, l)), (i(3, r), i(0, l)), (i(2, a), i(0, l)))
    }, [l, u, a, r, t, n, s, c]
}
class Ui extends q {
    constructor(e) {
        super(), K(this, e, Ac, Cc, Y, {
            notification: 0,
            name: 1
        })
    }
}

function Tc(o) {
    let e, i, n, t, r, a, s, l, u, c, _;
    return n = new ye({
        props: {
            width: "1.25em",
            height: "1.25em",
            rounded: !0
        }
    }), a = new ye({
        props: {
            width: "8ch"
        }
    }), l = new ye({
        props: {
            width: "18ch"
        }
    }), c = new ye({
        props: {
            width: "14ch"
        }
    }), {
        c() {
            e = T("div"), i = T("div"), g(n.$$.fragment), t = V(), r = T("div"), g(a.$$.fragment), s = V(), g(l.$$.fragment), u = V(), g(c.$$.fragment), this.h()
        },
        l(S) {
            e = I(S, "DIV", {
                class: !0
            });
            var F = B(e);
            i = I(F, "DIV", {
                class: !0
            });
            var E = B(i);
            N(n.$$.fragment, E), E.forEach(f), t = M(F), r = I(F, "DIV", {
                class: !0
            });
            var R = B(r);
            N(a.$$.fragment, R), s = M(R), N(l.$$.fragment, R), u = M(R), N(c.$$.fragment, R), R.forEach(f), F.forEach(f), this.h()
        },
        h() {
            H(i, "class", "notification-icon svelte-13zcqyu"), H(r, "class", "notification-body svelte-13zcqyu"), H(e, "class", "notification svelte-13zcqyu")
        },
        m(S, F) {
            k(S, e, F), z(e, i), $(n, i, null), z(e, t), z(e, r), $(a, r, null), z(r, s), $(l, r, null), z(r, u), $(c, r, null), _ = !0
        },
        p: A,
        i(S) {
            _ || (d(n.$$.fragment, S), d(a.$$.fragment, S), d(l.$$.fragment, S), d(c.$$.fragment, S), _ = !0)
        },
        o(S) {
            m(n.$$.fragment, S), m(a.$$.fragment, S), m(l.$$.fragment, S), m(c.$$.fragment, S), _ = !1
        },
        d(S) {
            S && f(e), v(n), v(a), v(l), v(c)
        }
    }
}
class Wi extends q {
    constructor(e) {
        super(), K(this, e, null, Tc, Y, {})
    }
}

function Gt(o, e, i) {
    const n = o.slice();
    return n[8] = e[i], n[10] = i, n
}

function Ic(o, e, i) {
    const n = o.slice();
    return n[5] = e[i], n
}

function Bc(o) {
    let e = [],
        i = new Map,
        n, t, r, a = Z(o[1]);
    const s = u => u[8].id;
    for (let u = 0; u < a.length; u += 1) {
        let c = Gt(o, a, u),
            _ = s(c);
        i.set(_, e[u] = jt(_, c))
    }
    let l = o[0] && Ht();
    return {
        c() {
            for (let u = 0; u < e.length; u += 1) e[u].c();
            n = V(), l && l.c(), t = h()
        },
        l(u) {
            for (let c = 0; c < e.length; c += 1) e[c].l(u);
            n = M(u), l && l.l(u), t = h()
        },
        m(u, c) {
            for (let _ = 0; _ < e.length; _ += 1) e[_] && e[_].m(u, c);
            k(u, n, c), l && l.m(u, c), k(u, t, c), r = !0
        },
        p(u, c) {
            c & 6 && (a = Z(u[1]), y(), e = Pl(e, c, s, 1, u, a, i, n.parentNode, Dl, jt, n, Gt), w()), u[0] ? l ? c & 1 && d(l, 1) : (l = Ht(), l.c(), d(l, 1), l.m(t.parentNode, t)) : l && (y(), m(l, 1, 1, () => {
                l = null
            }), w())
        },
        i(u) {
            if (!r) {
                for (let c = 0; c < a.length; c += 1) d(e[c]);
                d(l), r = !0
            }
        },
        o(u) {
            for (let c = 0; c < e.length; c += 1) m(e[c]);
            m(l), r = !1
        },
        d(u) {
            u && (f(n), f(t));
            for (let c = 0; c < e.length; c += 1) e[c].d(u);
            l && l.d(u)
        }
    }
}

function Ec(o) {
    let e, i, n = Z(o[3]),
        t = [];
    for (let r = 0; r < n.length; r += 1) t[r] = Rc(Ic(o, n, r));
    return {
        c() {
            for (let r = 0; r < t.length; r += 1) t[r].c();
            e = h()
        },
        l(r) {
            for (let a = 0; a < t.length; a += 1) t[a].l(r);
            e = h()
        },
        m(r, a) {
            for (let s = 0; s < t.length; s += 1) t[s] && t[s].m(r, a);
            k(r, e, a), i = !0
        },
        p: A,
        i(r) {
            if (!i) {
                for (let a = 0; a < n.length; a += 1) d(t[a]);
                i = !0
            }
        },
        o(r) {
            t = t.filter(Boolean);
            for (let a = 0; a < t.length; a += 1) m(t[a]);
            i = !1
        },
        d(r) {
            r && f(e), te(t, r)
        }
    }
}

function Pc(o) {
    let e, i;
    return e = new Ui({
        props: {
            notification: o[8]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 2 && (r.notification = n[8]), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Dc(o) {
    let e, i, n, t;
    return i = new Ui({
        props: {
            notification: o[8]
        }
    }), {
        c() {
            e = T("div"), g(i.$$.fragment)
        },
        l(r) {
            e = I(r, "DIV", {});
            var a = B(e);
            N(i.$$.fragment, a), a.forEach(f)
        },
        m(r, a) {
            k(r, e, a), $(i, e, null), t = !0
        },
        p(r, a) {
            const s = {};
            a & 2 && (s.notification = r[8]), i.$set(s)
        },
        i(r) {
            t || (d(i.$$.fragment, r), n || oi(() => {
                n = di(e, bi, {
                    x: 200,
                    y: 0,
                    duration: 500,
                    opacity: 0,
                    easing: ca
                }), n.start()
            }), t = !0)
        },
        o(r) {
            m(i.$$.fragment, r), t = !1
        },
        d(r) {
            r && f(e), v(i)
        }
    }
}

function jt(o, e) {
    let i, n, t, r, a;
    const s = [Dc, Pc],
        l = [];

    function u(c, _) {
        return c[2] && c[10] === 0 ? 0 : 1
    }
    return n = u(e), t = l[n] = s[n](e), {
        key: o,
        first: null,
        c() {
            i = h(), t.c(), r = h(), this.h()
        },
        l(c) {
            i = h(), t.l(c), r = h(), this.h()
        },
        h() {
            this.first = i
        },
        m(c, _) {
            k(c, i, _), l[n].m(c, _), k(c, r, _), a = !0
        },
        p(c, _) {
            e = c;
            let S = n;
            n = u(e), n === S ? l[n].p(e, _) : (y(), m(l[S], 1, 1, () => {
                l[S] = null
            }), w(), t = l[n], t ? t.p(e, _) : (t = l[n] = s[n](e), t.c()), d(t, 1), t.m(r.parentNode, r))
        },
        i(c) {
            a || (d(t), a = !0)
        },
        o(c) {
            m(t), a = !1
        },
        d(c) {
            c && (f(i), f(r)), l[n].d(c)
        }
    }
}

function Ht(o) {
    let e, i;
    return e = new Wi({}), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Rc(o) {
    let e, i;
    return e = new Wi({}), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Vc(o) {
    let e, i, n, t;
    const r = [Ec, Bc],
        a = [];

    function s(l, u) {
        return l[0] && l[1].length === 0 ? 0 : 1
    }
    return e = s(o), i = a[e] = r[e](o), {
        c() {
            i.c(), n = h()
        },
        l(l) {
            i.l(l), n = h()
        },
        m(l, u) {
            a[e].m(l, u), k(l, n, u), t = !0
        },
        p(l, u) {
            let c = e;
            e = s(l), e === c ? a[e].p(l, u) : (y(), m(a[c], 1, 1, () => {
                a[c] = null
            }), w(), i = a[e], i ? i.p(l, u) : (i = a[e] = r[e](l), i.c()), d(i, 1), i.m(n.parentNode, n))
        },
        i(l) {
            t || (d(i), t = !0)
        },
        o(l) {
            m(i), t = !1
        },
        d(l) {
            l && f(n), a[e].d(l)
        }
    }
}

function Mc(o) {
    let e, i;
    return e = new Pe({
        props: {
            gap: "small",
            paddingTop: "small",
            $$slots: {
                default: [Vc]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, [t]) {
            const r = {};
            t & 2055 && (r.$$scope = {
                dirty: t,
                ctx: n
            }), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Oc(o, e, i) {
    let {
        loading: n = !1
    } = e, {
        notificationList: t = []
    } = e, {
        loadingCount: r = 5
    } = e, {
        flyIn: a = !1
    } = e;
    const s = Array(r).fill("");
    return o.$$set = l => {
        "loading" in l && i(0, n = l.loading), "notificationList" in l && i(1, t = l.notificationList), "loadingCount" in l && i(4, r = l.loadingCount), "flyIn" in l && i(2, a = l.flyIn)
    }, [n, t, a, s, r]
}
class zi extends q {
    constructor(e) {
        super(), K(this, e, Oc, Mc, Y, {
            loading: 0,
            notificationList: 1,
            loadingCount: 4,
            flyIn: 2
        })
    }
}

function Lc(o) {
    let e = o[3]._(ue.new) + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 8 && e !== (e = n[3]._(ue.new) + "") && O(i, e)
        },
        d(n) {
            n && f(i)
        }
    }
}

function Uc(o) {
    let e, i, n, t, r, a, s, l;
    return n = new le({
        props: {
            variant: "subtle",
            weight: "semibold",
            size: "sm",
            lineHeight: "120pct",
            $$slots: {
                default: [Lc]
            },
            $$scope: {
                ctx: o
            }
        }
    }), r = new xu({
        props: {
            notifications: o[1],
            loading: o[0]
        }
    }), r.$on("readAll", o[4]), s = new zi({
        props: {
            notificationList: o[1],
            flyIn: o[2]
        }
    }), {
        c() {
            e = T("div"), i = T("div"), g(n.$$.fragment), t = V(), g(r.$$.fragment), a = V(), g(s.$$.fragment), this.h()
        },
        l(u) {
            e = I(u, "DIV", {});
            var c = B(e);
            i = I(c, "DIV", {
                class: !0
            });
            var _ = B(i);
            N(n.$$.fragment, _), t = M(_), N(r.$$.fragment, _), _.forEach(f), a = M(c), N(s.$$.fragment, c), c.forEach(f), this.h()
        },
        h() {
            H(i, "class", "header svelte-esznyk")
        },
        m(u, c) {
            k(u, e, c), z(e, i), $(n, i, null), z(i, t), $(r, i, null), z(e, a), $(s, e, null), l = !0
        },
        p(u, [c]) {
            const _ = {};
            c & 40 && (_.$$scope = {
                dirty: c,
                ctx: u
            }), n.$set(_);
            const S = {};
            c & 2 && (S.notifications = u[1]), c & 1 && (S.loading = u[0]), r.$set(S);
            const F = {};
            c & 2 && (F.notificationList = u[1]), c & 4 && (F.flyIn = u[2]), s.$set(F)
        },
        i(u) {
            l || (d(n.$$.fragment, u), d(r.$$.fragment, u), d(s.$$.fragment, u), l = !0)
        },
        o(u) {
            m(n.$$.fragment, u), m(r.$$.fragment, u), m(s.$$.fragment, u), l = !1
        },
        d(u) {
            u && f(e), v(n), v(r), v(s)
        }
    }
}

function Wc(o, e, i) {
    let n;
    j(o, x, l => i(3, n = l));
    let {
        loading: t = !1
    } = e, {
        notifications: r = []
    } = e, {
        flyIn: a = !1
    } = e;

    function s(l) {
        ui.call(this, o, l)
    }
    return o.$$set = l => {
        "loading" in l && i(0, t = l.loading), "notifications" in l && i(1, r = l.notifications), "flyIn" in l && i(2, a = l.flyIn)
    }, [t, r, a, n, s]
}
class zc extends q {
    constructor(e) {
        super(), K(this, e, Wc, Uc, Y, {
            loading: 0,
            notifications: 1,
            flyIn: 2
        })
    }
}

function Gc(o) {
    let e, i;
    return e = new le({
        props: {
            variant: "subtle",
            weight: "semibold",
            size: "sm",
            lineHeight: "120pct",
            $$slots: {
                default: [Hc]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 24 && (r.$$scope = {
                dirty: t,
                ctx: n
            }), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function jc(o) {
    let e, i;
    return e = new ye({
        props: {
            width: "7ch",
            height: "0.75rem"
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p: A,
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Hc(o) {
    let e = o[3]._(ue.earlier) + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 8 && e !== (e = n[3]._(ue.earlier) + "") && O(i, e)
        },
        d(n) {
            n && f(i)
        }
    }
}

function Yc(o) {
    let e, i, n, t, r, a;
    const s = [jc, Gc],
        l = [];

    function u(c, _) {
        return c[0] && c[1].length === 0 ? 0 : 1
    }
    return i = u(o), n = l[i] = s[i](o), r = new zi({
        props: {
            loadingCount: o[2],
            notificationList: o[1],
            loading: o[0]
        }
    }), {
        c() {
            e = T("div"), n.c(), t = V(), g(r.$$.fragment)
        },
        l(c) {
            e = I(c, "DIV", {});
            var _ = B(e);
            n.l(_), t = M(_), N(r.$$.fragment, _), _.forEach(f)
        },
        m(c, _) {
            k(c, e, _), l[i].m(e, null), z(e, t), $(r, e, null), a = !0
        },
        p(c, [_]) {
            let S = i;
            i = u(c), i === S ? l[i].p(c, _) : (y(), m(l[S], 1, 1, () => {
                l[S] = null
            }), w(), n = l[i], n ? n.p(c, _) : (n = l[i] = s[i](c), n.c()), d(n, 1), n.m(e, t));
            const F = {};
            _ & 4 && (F.loadingCount = c[2]), _ & 2 && (F.notificationList = c[1]), _ & 1 && (F.loading = c[0]), r.$set(F)
        },
        i(c) {
            a || (d(n), d(r.$$.fragment, c), a = !0)
        },
        o(c) {
            m(n), m(r.$$.fragment, c), a = !1
        },
        d(c) {
            c && f(e), l[i].d(), v(r)
        }
    }
}

function qc(o, e, i) {
    let n;
    j(o, x, s => i(3, n = s));
    let {
        loading: t = !1
    } = e, {
        notifications: r = []
    } = e, {
        limit: a = 20
    } = e;
    return o.$$set = s => {
        "loading" in s && i(0, t = s.loading), "notifications" in s && i(1, r = s.notifications), "limit" in s && i(2, a = s.limit)
    }, [t, r, a, n]
}
class Kc extends q {
    constructor(e) {
        super(), K(this, e, qc, Yc, Y, {
            loading: 0,
            notifications: 1,
            limit: 2
        })
    }
}

function Zc(o) {
    let e = o[0]._(ue.noNotifications) + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 1 && e !== (e = n[0]._(ue.noNotifications) + "") && O(i, e)
        },
        d(n) {
            n && f(i)
        }
    }
}

function Xc(o) {
    let e = o[0]._(ue.noNotificationsSubheading) + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t & 1 && e !== (e = n[0]._(ue.noNotificationsSubheading) + "") && O(i, e)
        },
        d(n) {
            n && f(i)
        }
    }
}

function Qc(o) {
    let e, i, n, t;
    return e = new le({
        props: {
            weight: "semibold",
            variant: "highlighted",
            lineHeight: "120pct",
            $$slots: {
                default: [Zc]
            },
            $$scope: {
                ctx: o
            }
        }
    }), n = new le({
        props: {
            lineHeight: "120pct",
            $$slots: {
                default: [Xc]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            g(e.$$.fragment), i = V(), g(n.$$.fragment)
        },
        l(r) {
            N(e.$$.fragment, r), i = M(r), N(n.$$.fragment, r)
        },
        m(r, a) {
            $(e, r, a), k(r, i, a), $(n, r, a), t = !0
        },
        p(r, a) {
            const s = {};
            a & 3 && (s.$$scope = {
                dirty: a,
                ctx: r
            }), e.$set(s);
            const l = {};
            a & 3 && (l.$$scope = {
                dirty: a,
                ctx: r
            }), n.$set(l)
        },
        i(r) {
            t || (d(e.$$.fragment, r), d(n.$$.fragment, r), t = !0)
        },
        o(r) {
            m(e.$$.fragment, r), m(n.$$.fragment, r), t = !1
        },
        d(r) {
            r && f(i), v(e, r), v(n, r)
        }
    }
}

function Jc(o) {
    let e, i, n;
    return i = new Fi({
        props: {
            icon: "empty-promotions",
            spacing: "compact",
            $$slots: {
                default: [Qc]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            e = T("div"), g(i.$$.fragment), this.h()
        },
        l(t) {
            e = I(t, "DIV", {
                class: !0
            });
            var r = B(e);
            N(i.$$.fragment, r), r.forEach(f), this.h()
        },
        h() {
            H(e, "class", "empty-notifications svelte-w18c7z")
        },
        m(t, r) {
            k(t, e, r), $(i, e, null), n = !0
        },
        p(t, [r]) {
            const a = {};
            r & 3 && (a.$$scope = {
                dirty: r,
                ctx: t
            }), i.$set(a)
        },
        i(t) {
            n || (d(i.$$.fragment, t), n = !0)
        },
        o(t) {
            m(i.$$.fragment, t), n = !1
        },
        d(t) {
            t && f(e), v(i)
        }
    }
}

function xc(o, e, i) {
    let n;
    return j(o, x, t => i(0, n = t)), [n]
}
class ed extends q {
    constructor(e) {
        super(), K(this, e, xc, Jc, Y, {})
    }
}

function nd(o) {
    let e, i;
    return e = new Pe({
        props: {
            gap: "large",
            $$slots: {
                default: [id]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 8247 && (r.$$scope = {
                dirty: t,
                ctx: n
            }), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function td(o) {
    let e, i;
    return e = new ed({}), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p: A,
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Yt(o) {
    let e, i;
    return e = new zc({
        props: {
            loading: o[2].loading,
            notifications: o[1],
            flyIn: o[5]
        }
    }), e.$on("readAll", o[10]), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 4 && (r.loading = n[2].loading), t & 2 && (r.notifications = n[1]), t & 32 && (r.flyIn = n[5]), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function qt(o) {
    let e, i;
    return e = new Kc({
        props: {
            notifications: o[4],
            loading: o[2].loading,
            limit: o[2].loading ? 3 : De
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t & 16 && (r.notifications = n[4]), t & 4 && (r.loading = n[2].loading), t & 4 && (r.limit = n[2].loading ? 3 : De), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function id(o) {
    let e, i, n, t = o[1].length > 0 && Yt(o),
        r = (o[2].loading || o[4].length > 0) && qt(o);
    return {
        c() {
            t && t.c(), e = V(), r && r.c(), i = h()
        },
        l(a) {
            t && t.l(a), e = M(a), r && r.l(a), i = h()
        },
        m(a, s) {
            t && t.m(a, s), k(a, e, s), r && r.m(a, s), k(a, i, s), n = !0
        },
        p(a, s) {
            a[1].length > 0 ? t ? (t.p(a, s), s & 2 && d(t, 1)) : (t = Yt(a), t.c(), d(t, 1), t.m(e.parentNode, e)) : t && (y(), m(t, 1, 1, () => {
                t = null
            }), w()), a[2].loading || a[4].length > 0 ? r ? (r.p(a, s), s & 20 && d(r, 1)) : (r = qt(a), r.c(), d(r, 1), r.m(i.parentNode, i)) : r && (y(), m(r, 1, 1, () => {
                r = null
            }), w())
        },
        i(a) {
            n || (d(t), d(r), n = !0)
        },
        o(a) {
            m(t), m(r), n = !1
        },
        d(a) {
            a && (f(e), f(i)), t && t.d(a), r && r.d(a)
        }
    }
}

function Kt(o) {
    let e, i;
    return e = new Ku({}), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function ld(o) {
    let e, i, n, t, r;
    const a = [td, nd],
        s = [];

    function l(c, _) {
        return c[0].length === 0 && !c[2].loading ? 0 : 1
    }
    e = l(o), i = s[e] = a[e](o);
    let u = o[3] && Kt();
    return {
        c() {
            i.c(), n = V(), u && u.c(), t = h()
        },
        l(c) {
            i.l(c), n = M(c), u && u.l(c), t = h()
        },
        m(c, _) {
            s[e].m(c, _), k(c, n, _), u && u.m(c, _), k(c, t, _), r = !0
        },
        p(c, _) {
            let S = e;
            e = l(c), e === S ? s[e].p(c, _) : (y(), m(s[S], 1, 1, () => {
                s[S] = null
            }), w(), i = s[e], i ? i.p(c, _) : (i = s[e] = a[e](c), i.c()), d(i, 1), i.m(n.parentNode, n)), c[3] ? u ? _ & 8 && d(u, 1) : (u = Kt(), u.c(), d(u, 1), u.m(t.parentNode, t)) : u && (y(), m(u, 1, 1, () => {
                u = null
            }), w())
        },
        i(c) {
            r || (d(i), d(u), r = !0)
        },
        o(c) {
            m(i), m(u), r = !1
        },
        d(c) {
            c && (f(n), f(t)), s[e].d(c), u && u.d(c)
        }
    }
}

function ad(o) {
    let e, i, n, t, r, a, s;
    return i = new Mu({}), t = new Wu({
        props: {
            class: "notification-list-scroll",
            loading: o[2].loading,
            limit: De,
            threshold: 400,
            $$slots: {
                default: [ld]
            },
            $$scope: {
                ctx: o
            }
        }
    }), t.$on("load", o[11]), {
        c() {
            e = T("div"), g(i.$$.fragment), n = V(), g(t.$$.fragment), this.h()
        },
        l(l) {
            e = I(l, "DIV", {
                class: !0,
                style: !0
            });
            var u = B(e);
            N(i.$$.fragment, u), n = M(u), N(t.$$.fragment, u), u.forEach(f), this.h()
        },
        h() {
            H(e, "class", "notifications-widget svelte-6gfkw4"), be(e, "z-Index", en.sidebar + 1), re(e, "mobile", o[7])
        },
        m(l, u) {
            k(l, e, u), $(i, e, null), z(e, n), $(t, e, null), r = !0, a || (s = ci(ma.call(null, e, o[9])), a = !0)
        },
        p(l, [u]) {
            const c = {};
            u & 4 && (c.loading = l[2].loading), u & 8255 && (c.$$scope = {
                dirty: u,
                ctx: l
            }), t.$set(c), (!r || u & 128) && re(e, "mobile", l[7])
        },
        i(l) {
            r || (d(i.$$.fragment, l), d(t.$$.fragment, l), r = !0)
        },
        o(l) {
            m(i.$$.fragment, l), m(t.$$.fragment, l), r = !1
        },
        d(l) {
            l && f(e), v(i), v(t), a = !1, s()
        }
    }
}
const De = 20;

function rd(o, e, i) {
    let n, t;
    j(o, qe, U => i(7, n = U));
    let r = !1,
        a = [],
        s = [],
        l = [],
        u = !1,
        c = 0;
    const _ = dl({
        data: a,
        query: async () => {
            var C, L;
            return r ? null : (((L = (C = (await ml({
                doc: Gu,
                variables: {
                    limit: De,
                    offset: c
                }
            })).data) == null ? void 0 : C.user) == null ? void 0 : L.notificationList) ? ? []).map(J => Rt(J)).filter(J => !!(J && (J.title || J.body)))
        },
        normalize: (U, C) => C ? (C.length < De && U.length > 0 && i(3, r = !0), U.concat(C.filter(L => !U.find(J => J.id === L.id)))) : U
    });
    j(o, _, U => i(2, t = U)), _.loadMore();
    const S = sa();
    He(() => {
        let U = S.emitter.subscribe(C => {
            const L = Rt(C);
            L && (i(1, s = [L, ...s]), i(5, u = !0))
        });
        return () => {
            U()
        }
    });
    const F = U => {
            var J;
            const C = U.target,
                L = "notifications-nav-button";
            C.id === L || ((J = C.parentElement) == null ? void 0 : J.id) === L || n || sn.close()
        },
        E = U => {
            i(1, s = []), i(0, a = [...U.detail, ...l])
        },
        R = U => {
            i(6, c = U.detail.offset), _.loadMore()
        };
    return o.$$.update = () => {
        o.$$.dirty & 4 && t.data && i(0, a = t.data), o.$$.dirty & 3 && i(1, s = [...s, ...a.filter(U => !U.acknowledged && !s.find(C => C.id === U.id))]), o.$$.dirty & 1 && i(4, l = a.filter(U => U.acknowledged))
    }, [a, s, t, r, l, u, c, n, _, F, E, R]
}
class od extends q {
    constructor(e) {
        super(), K(this, e, rd, ad, Y, {})
    }
}
const Q = {
    search: p._("Search"),
    chat: p._("Chat"),
    betslip: p._("Bet Slip"),
    register: p._("Register"),
    login: p._("Sign In"),
    account: p._("Account"),
    wallet: p._("Wallet"),
    settings: p._("Settings"),
    vault: p._("Vault"),
    vip: p._("VIP"),
    notifications: p._("Notifications"),
    affiliate: p._("Affiliate"),
    statistics: p._("Statistics"),
    transactions: p._("Transactions"),
    sportBets: p._("Sport Bets"),
    myBets: p._("My Bets"),
    myGamePlay: p._("My Game Play"),
    liveSupport: p._("Live support"),
    logout: p._("Logout"),
    hi: o => ({
        id: "Hi, {name}",
        values: {
            name: o
        }
    }),
    stakeSmart: p._("Stake Smart"),
    selfExclusion: p._("Self Exclusion"),
    igamingOn: p._("igaming Ontario Logo"),
    onboardingBannerText: p._("To deposit & withdraw, please provide additional information."),
    onboardingButtonText: p._("Setup Wallet"),
    kycRejectedBannerText: p._("Your verification requires attention."),
    kycRejectedButtonText: p._("Submit verification")
};

function Zt(o) {
    let e, i;
    return e = new yi({
        props: {
            style: "right: 6px; border: 1.5px solid var(--grey-600);"
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function sd(o) {
    let e, i, n, t;
    e = new $i({});
    let r = o[0] && Zt();
    return {
        c() {
            g(e.$$.fragment), i = V(), r && r.c(), n = h()
        },
        l(a) {
            N(e.$$.fragment, a), i = M(a), r && r.l(a), n = h()
        },
        m(a, s) {
            $(e, a, s), k(a, i, s), r && r.m(a, s), k(a, n, s), t = !0
        },
        p(a, s) {
            a[0] ? r ? s & 1 && d(r, 1) : (r = Zt(), r.c(), d(r, 1), r.m(n.parentNode, n)) : r && (y(), m(r, 1, 1, () => {
                r = null
            }), w())
        },
        i(a) {
            t || (d(e.$$.fragment, a), d(r), t = !0)
        },
        o(a) {
            m(e.$$.fragment, a), m(r), t = !1
        },
        d(a) {
            a && (f(i), f(n)), v(e, a), r && r.d(a)
        }
    }
}

function ud(o) {
    let e, i;
    return e = new se({
        props: {
            id: "notifications-nav-button",
            "aria-label": "Toggle Notifications Widget",
            variant: "link",
            size: "sm",
            iconOnly: !0,
            class: "p-3",
            $$slots: {
                default: [sd]
            },
            $$scope: {
                ctx: o
            }
        }
    }), e.$on("click", ze.toggleNotificationsWidget), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, [t]) {
            const r = {};
            t & 3 && (r.$$scope = {
                dirty: t,
                ctx: n
            }), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function cd(o, e, i) {
    let n;
    return j(o, xe, t => i(0, n = t)), [n]
}
class dd extends q {
    constructor(e) {
        super(), K(this, e, cd, ud, Y, {})
    }
}
const md = {
    kind: "Document",
    definitions: [{
        kind: "OperationDefinition",
        operation: "query",
        name: {
            kind: "Name",
            value: "CurrentPlaySession"
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "user"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "id"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "currentPlaySession"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "id"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "createdAt"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "expireAt"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "updatedAt"
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }]
};

function Xt(o) {
    let e, i;
    return e = new ye({
        props: {
            height: "1em",
            width: "6ch"
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Qt(o) {
    let e = o[2].hours + "",
        i, n, t = o[2].minutes + "",
        r, a, s = o[2].seconds + "",
        l;
    return {
        c() {
            i = P(e), n = P(":"), r = P(t), a = P(":"), l = P(s)
        },
        l(u) {
            i = D(u, e), n = D(u, ":"), r = D(u, t), a = D(u, ":"), l = D(u, s)
        },
        m(u, c) {
            k(u, i, c), k(u, n, c), k(u, r, c), k(u, a, c), k(u, l, c)
        },
        p(u, c) {
            c & 4 && e !== (e = u[2].hours + "") && O(i, e), c & 4 && t !== (t = u[2].minutes + "") && O(r, t), c & 4 && s !== (s = u[2].seconds + "") && O(l, s)
        },
        d(u) {
            u && (f(i), f(n), f(r), f(a), f(l))
        }
    }
}

function fd(o) {
    var a, s, l;
    let e, i, n, t = o[1] && Xt(),
        r = ((l = (s = (a = o[0]) == null ? void 0 : a.user) == null ? void 0 : s.currentPlaySession) == null ? void 0 : l.createdAt) && Qt(o);
    return {
        c() {
            e = T("div"), t && t.c(), i = V(), r && r.c(), this.h()
        },
        l(u) {
            e = I(u, "DIV", {
                class: !0
            });
            var c = B(e);
            t && t.l(c), i = M(c), r && r.l(c), c.forEach(f), this.h()
        },
        h() {
            H(e, "class", "timer svelte-1tyx0bn")
        },
        m(u, c) {
            k(u, e, c), t && t.m(e, null), z(e, i), r && r.m(e, null), n = !0
        },
        p(u, [c]) {
            var _, S, F;
            u[1] ? t ? c & 2 && d(t, 1) : (t = Xt(), t.c(), d(t, 1), t.m(e, i)) : t && (y(), m(t, 1, 1, () => {
                t = null
            }), w()), (F = (S = (_ = u[0]) == null ? void 0 : _.user) == null ? void 0 : S.currentPlaySession) != null && F.createdAt ? r ? r.p(u, c) : (r = Qt(u), r.c(), r.m(e, null)) : r && (r.d(1), r = null)
        },
        i(u) {
            n || (d(t), n = !0)
        },
        o(u) {
            m(t), n = !1
        },
        d(u) {
            u && f(e), t && t.d(), r && r.d()
        }
    }
}

function kd(o, e, i) {
    let n, t = !1,
        r = new Date,
        a;
    (async () => {
        i(1, t = !0), i(0, a = await fl({
            doc: md,
            variables: {},
            load: {
                fetch
            },
            cache: {
                name: "playSession"
            }
        })), i(1, t = !1)
    })();
    const l = (u, c) => {
        const _ = C => C < 10 ? `0${C}` : String(C),
            S = new Date(u || c),
            F = Nl ? 15e4 : c.getTime() - S.getTime(),
            E = _(Math.floor(F % (1e3 * 60 * 60 * 24) / (1e3 * 60 * 60))),
            R = _(Math.floor(F % (1e3 * 60 * 60) / (1e3 * 60))),
            U = _(Math.floor(F % (1e3 * 60) / 1e3));
        return {
            hours: E,
            minutes: R,
            seconds: U
        }
    };
    return He(() => {
        const u = setInterval(() => {
            i(3, r = new Date)
        }, 1e3);
        return () => {
            clearInterval(u)
        }
    }), o.$$.update = () => {
        var u, c;
        o.$$.dirty & 9 && i(2, n = l((c = (u = a == null ? void 0 : a.user) == null ? void 0 : u.currentPlaySession) == null ? void 0 : c.createdAt, r))
    }, [a, t, n, r]
}
class _d extends q {
    constructor(e) {
        super(), K(this, e, kd, fd, Y, {})
    }
}

function pd(o) {
    let e, i;
    const n = o[1].default,
        t = pe(n, o, o[0], null);
    return {
        c() {
            e = T("div"), t && t.c(), this.h()
        },
        l(r) {
            e = I(r, "DIV", {
                class: !0
            });
            var a = B(e);
            t && t.l(a), a.forEach(f), this.h()
        },
        h() {
            H(e, "class", "banner svelte-16skev2")
        },
        m(r, a) {
            k(r, e, a), t && t.m(e, null), i = !0
        },
        p(r, [a]) {
            t && t.p && (!i || a & 1) && ge(t, n, r, r[0], i ? ve(n, r[0], a, null) : $e(r[0]), null)
        },
        i(r) {
            i || (d(t, r), i = !0)
        },
        o(r) {
            m(t, r), i = !1
        },
        d(r) {
            r && f(e), t && t.d(r)
        }
    }
}

function gd(o, e, i) {
    let {
        $$slots: n = {},
        $$scope: t
    } = e;
    return o.$$set = r => {
        "$$scope" in r && i(0, t = r.$$scope)
    }, [t, n]
}
class $d extends q {
    constructor(e) {
        super(), K(this, e, gd, pd, Y, {})
    }
}

function vd(o) {
    let e;
    const i = o[2].default,
        n = pe(i, o, o[4], null);
    return {
        c() {
            n && n.c()
        },
        l(t) {
            n && n.l(t)
        },
        m(t, r) {
            n && n.m(t, r), e = !0
        },
        p(t, r) {
            n && n.p && (!e || r & 16) && ge(n, i, t, t[4], e ? ve(i, t[4], r, null) : $e(t[4]), null)
        },
        i(t) {
            e || (d(n, t), e = !0)
        },
        o(t) {
            m(n, t), e = !1
        },
        d(t) {
            n && n.d(t)
        }
    }
}

function Nd(o) {
    let e, i;
    const n = [{
        variant: "action"
    }, {
        "data-test": "onboarding-banner-verification-submit"
    }, {
        "data-analytics": "onboarding-banner-verification-submit"
    }, {
        size: o[0] ? "xs" : "sm"
    }, o[1]];
    let t = {
        $$slots: {
            default: [vd]
        },
        $$scope: {
            ctx: o
        }
    };
    for (let r = 0; r < n.length; r += 1) t = ae(t, n[r]);
    return e = new se({
        props: t
    }), e.$on("click", o[3]), {
        c() {
            g(e.$$.fragment)
        },
        l(r) {
            N(e.$$.fragment, r)
        },
        m(r, a) {
            $(e, r, a), i = !0
        },
        p(r, [a]) {
            const s = a & 3 ? de(n, [n[0], n[1], n[2], a & 1 && {
                size: r[0] ? "xs" : "sm"
            }, a & 2 && fe(r[1])]) : {};
            a & 16 && (s.$$scope = {
                dirty: a,
                ctx: r
            }), e.$set(s)
        },
        i(r) {
            i || (d(e.$$.fragment, r), i = !0)
        },
        o(r) {
            m(e.$$.fragment, r), i = !1
        },
        d(r) {
            v(e, r)
        }
    }
}

function hd(o, e, i) {
    const n = [];
    let t = Ce(e, n),
        r;
    j(o, qe, u => i(0, r = u));
    let {
        $$slots: a = {},
        $$scope: s
    } = e;

    function l(u) {
        ui.call(this, o, u)
    }
    return o.$$set = u => {
        e = ae(ae({}, e), Ge(u)), i(1, t = Ce(e, n)), "$$scope" in u && i(4, s = u.$$scope)
    }, [r, t, a, l, s]
}
class Sd extends q {
    constructor(e) {
        super(), K(this, e, hd, Nd, Y, {})
    }
}

function bd(o) {
    let e;
    const i = o[2].default,
        n = pe(i, o, o[3], null);
    return {
        c() {
            n && n.c()
        },
        l(t) {
            n && n.l(t)
        },
        m(t, r) {
            n && n.m(t, r), e = !0
        },
        p(t, r) {
            n && n.p && (!e || r & 8) && ge(n, i, t, t[3], e ? ve(i, t[3], r, null) : $e(t[3]), null)
        },
        i(t) {
            e || (d(n, t), e = !0)
        },
        o(t) {
            m(n, t), e = !1
        },
        d(t) {
            n && n.d(t)
        }
    }
}

function Fd(o) {
    let e, i;
    const n = [{
        variant: "highlighted"
    }, {
        size: o[0] ? "sm" : "default"
    }, o[1]];
    let t = {
        $$slots: {
            default: [bd]
        },
        $$scope: {
            ctx: o
        }
    };
    for (let r = 0; r < n.length; r += 1) t = ae(t, n[r]);
    return e = new le({
        props: t
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(r) {
            N(e.$$.fragment, r)
        },
        m(r, a) {
            $(e, r, a), i = !0
        },
        p(r, [a]) {
            const s = a & 3 ? de(n, [n[0], a & 1 && {
                size: r[0] ? "sm" : "default"
            }, a & 2 && fe(r[1])]) : {};
            a & 8 && (s.$$scope = {
                dirty: a,
                ctx: r
            }), e.$set(s)
        },
        i(r) {
            i || (d(e.$$.fragment, r), i = !0)
        },
        o(r) {
            m(e.$$.fragment, r), i = !1
        },
        d(r) {
            v(e, r)
        }
    }
}

function yd(o, e, i) {
    const n = [];
    let t = Ce(e, n),
        r;
    j(o, qe, l => i(0, r = l));
    let {
        $$slots: a = {},
        $$scope: s
    } = e;
    return o.$$set = l => {
        e = ae(ae({}, e), Ge(l)), i(1, t = Ce(e, n)), "$$scope" in l && i(3, s = l.$$scope)
    }, [r, t, a, s]
}
class wd extends q {
    constructor(e) {
        super(), K(this, e, yd, Fd, Y, {})
    }
}

function Jt(o) {
    let e, i;
    return e = new od({}), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function xt(o) {
    let e, i, n;
    return i = new yl({
        props: {
            type: o[9],
            isGlobal: hl,
            focusOnMount: !0,
            showSearchOverlay: !0,
            containerNode: o[5]
        }
    }), i.$on("close", o[27]), {
        c() {
            e = T("div"), g(i.$$.fragment), this.h()
        },
        l(t) {
            e = I(t, "DIV", {
                class: !0
            });
            var r = B(e);
            N(i.$$.fragment, r), r.forEach(f), this.h()
        },
        h() {
            H(e, "class", "navigation-search-container svelte-1nt2705")
        },
        m(t, r) {
            k(t, e, r), $(i, e, null), n = !0
        },
        p(t, r) {
            const a = {};
            r[0] & 512 && (a.type = t[9]), r[0] & 32 && (a.containerNode = t[5]), i.$set(a)
        },
        i(t) {
            n || (d(i.$$.fragment, t), n = !0)
        },
        o(t) {
            m(i.$$.fragment, t), n = !1
        },
        d(t) {
            t && f(e), v(i)
        }
    }
}

function Cd(o) {
    let e, i;
    return e = new mi({
        props: {
            isCollapsed: o[14].isAuthenticated && o[11]
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t[0] & 18432 && (r.isCollapsed = n[14].isAuthenticated && n[11]), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Ad(o) {
    let e, i;
    return e = new Fe({
        props: {
            "data-test": "home-button",
            to: o[7],
            "aria-label": "Home",
            $$slots: {
                default: [Cd]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t[0] & 128 && (r.to = n[7]), t[0] & 18432 | t[1] & 16384 && (r.$$scope = {
                dirty: t,
                ctx: n
            }), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Td(o) {
    let e, i, n, t, r, a, s;
    i = new Re({
        props: {
            $$slots: {
                default: [Ad]
            },
            $$scope: {
                ctx: o
            }
        }
    });
    let l = ki === "canada";
    return {
        c() {
            e = T("div"), g(i.$$.fragment), n = V(), t = h(), this.h()
        },
        l(u) {
            e = I(u, "DIV", {});
            var c = B(e);
            N(i.$$.fragment, c), c.forEach(f), n = M(u), t = h(), this.h()
        },
        h() {
            re(e, "mobile", o[2])
        },
        m(u, c) {
            k(u, e, c), $(i, e, null), k(u, n, c), k(u, t, c), r = !0, a || (s = Ee(e, "click", o[23]), a = !0)
        },
        p(u, c) {
            const _ = {};
            c[0] & 18560 | c[1] & 16384 && (_.$$scope = {
                dirty: c,
                ctx: u
            }), i.$set(_), (!r || c[0] & 4) && re(e, "mobile", u[2])
        },
        i(u) {
            r || (d(i.$$.fragment, u), d(l), r = !0)
        },
        o(u) {
            m(i.$$.fragment, u), m(l), r = !1
        },
        d(u) {
            u && (f(e), f(n), f(t)), v(i), a = !1, s()
        }
    }
}

function ei(o) {
    let e, i;
    return e = new bl({
        props: {
            showText: o[10],
            truncateMaxWidth: "16ch"
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t[0] & 1024 && (r.showText = n[10]), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function ni(o) {
    let e, i;
    return e = new _d({}), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function ti(o) {
    let e, i;
    return e = new se({
        props: {
            iconOnly: !0,
            variant: "link",
            size: "sm",
            class: "w-full justify-start",
            $$slots: {
                default: [Id]
            },
            $$scope: {
                ctx: o
            }
        }
    }), e.$on("click", o[28]), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t[0] & 33792 | t[1] & 16384 && (r.$$scope = {
                dirty: t,
                ctx: n
            }), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function ii(o) {
    let e, i = o[15]._(Q.search) + "",
        n;
    return {
        c() {
            e = T("span"), n = P(i)
        },
        l(t) {
            e = I(t, "SPAN", {});
            var r = B(e);
            n = D(r, i), r.forEach(f)
        },
        m(t, r) {
            k(t, e, r), z(e, n)
        },
        p(t, r) {
            r[0] & 32768 && i !== (i = t[15]._(Q.search) + "") && O(n, i)
        },
        d(t) {
            t && f(e)
        }
    }
}

function Id(o) {
    let e, i, n, t;
    e = new ha({});
    let r = o[10] && ii(o);
    return {
        c() {
            g(e.$$.fragment), i = V(), r && r.c(), n = h()
        },
        l(a) {
            N(e.$$.fragment, a), i = M(a), r && r.l(a), n = h()
        },
        m(a, s) {
            $(e, a, s), k(a, i, s), r && r.m(a, s), k(a, n, s), t = !0
        },
        p(a, s) {
            a[10] ? r ? r.p(a, s) : (r = ii(a), r.c(), r.m(n.parentNode, n)) : r && (r.d(1), r = null)
        },
        i(a) {
            t || (d(e.$$.fragment, a), t = !0)
        },
        o(a) {
            m(e.$$.fragment, a), t = !1
        },
        d(a) {
            a && (f(i), f(n)), v(e, a), r && r.d(a)
        }
    }
}

function Bd(o) {
    let e, i, n, t;
    return e = new se({
        props: {
            variant: "link",
            "data-testid": "login-link",
            "data-test": "login-link",
            "data-analytics": "global-navbar-signin-button",
            iconOnly: !0,
            $$slots: {
                default: [Pd]
            },
            $$scope: {
                ctx: o
            }
        }
    }), e.$on("click", o[36]), n = new se({
        props: {
            variant: "action",
            "data-testid": "register-link",
            "data-test": "register-link",
            "data-analytics": "global-navbar-register-button",
            "data-content": wi,
            $$slots: {
                default: [Dd]
            },
            $$scope: {
                ctx: o
            }
        }
    }), n.$on("click", o[37]), {
        c() {
            g(e.$$.fragment), i = V(), g(n.$$.fragment)
        },
        l(r) {
            N(e.$$.fragment, r), i = M(r), N(n.$$.fragment, r)
        },
        m(r, a) {
            $(e, r, a), k(r, i, a), $(n, r, a), t = !0
        },
        p(r, a) {
            const s = {};
            a[0] & 32768 | a[1] & 16384 && (s.$$scope = {
                dirty: a,
                ctx: r
            }), e.$set(s);
            const l = {};
            a[0] & 32768 | a[1] & 16384 && (l.$$scope = {
                dirty: a,
                ctx: r
            }), n.$set(l)
        },
        i(r) {
            t || (d(e.$$.fragment, r), d(n.$$.fragment, r), t = !0)
        },
        o(r) {
            m(e.$$.fragment, r), m(n.$$.fragment, r), t = !1
        },
        d(r) {
            r && f(i), v(e, r), v(n, r)
        }
    }
}

function Ed(o) {
    let e, i, n, t, r, a;
    e = new _i({
        props: {
            transparent: !0,
            $$slots: {
                default: [Zd]
            },
            $$scope: {
                ctx: o
            }
        }
    }), n = new dd({});
    let s = o[4] !== "fullsize" && li(o);
    return {
        c() {
            g(e.$$.fragment), i = V(), g(n.$$.fragment), t = V(), s && s.c(), r = h()
        },
        l(l) {
            N(e.$$.fragment, l), i = M(l), N(n.$$.fragment, l), t = M(l), s && s.l(l), r = h()
        },
        m(l, u) {
            $(e, l, u), k(l, i, u), $(n, l, u), k(l, t, u), s && s.m(l, u), k(l, r, u), a = !0
        },
        p(l, u) {
            const c = {};
            u[0] & 180232 | u[1] & 16384 && (c.$$scope = {
                dirty: u,
                ctx: l
            }), e.$set(c), l[4] !== "fullsize" ? s ? (s.p(l, u), u[0] & 16 && d(s, 1)) : (s = li(l), s.c(), d(s, 1), s.m(r.parentNode, r)) : s && (y(), m(s, 1, 1, () => {
                s = null
            }), w())
        },
        i(l) {
            a || (d(e.$$.fragment, l), d(n.$$.fragment, l), d(s), a = !0)
        },
        o(l) {
            m(e.$$.fragment, l), m(n.$$.fragment, l), m(s), a = !1
        },
        d(l) {
            l && (f(i), f(t), f(r)), v(e, l), v(n, l), s && s.d(l)
        }
    }
}

function Pd(o) {
    let e = o[15]._(Q.login) + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t[0] & 32768 && e !== (e = n[15]._(Q.login) + "") && O(i, e)
        },
        d(n) {
            n && f(i)
        }
    }
}

function Dd(o) {
    let e = o[15]._(Q.register) + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t[0] & 32768 && e !== (e = n[15]._(Q.register) + "") && O(i, e)
        },
        d(n) {
            n && f(i)
        }
    }
}

function Rd(o) {
    let e, i;
    return e = new Ye({}), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Vd(o) {
    let e, i, n, t = o[15]._(Q.wallet) + "",
        r, a;
    return e = new oe({}), {
        c() {
            g(e.$$.fragment), i = V(), n = T("span"), r = P(t)
        },
        l(s) {
            N(e.$$.fragment, s), i = M(s), n = I(s, "SPAN", {});
            var l = B(n);
            r = D(l, t), l.forEach(f)
        },
        m(s, l) {
            $(e, s, l), k(s, i, l), k(s, n, l), z(n, r), a = !0
        },
        p(s, l) {
            (!a || l[0] & 32768) && t !== (t = s[15]._(Q.wallet) + "") && O(r, t)
        },
        i(s) {
            a || (d(e.$$.fragment, s), a = !0)
        },
        o(s) {
            m(e.$$.fragment, s), a = !1
        },
        d(s) {
            s && (f(i), f(n)), v(e, s)
        }
    }
}

function Md(o) {
    let e, i, n, t = o[15]._(Q.vault) + "",
        r, a;
    return e = new Tl({}), {
        c() {
            g(e.$$.fragment), i = V(), n = T("span"), r = P(t)
        },
        l(s) {
            N(e.$$.fragment, s), i = M(s), n = I(s, "SPAN", {});
            var l = B(n);
            r = D(l, t), l.forEach(f)
        },
        m(s, l) {
            $(e, s, l), k(s, i, l), k(s, n, l), z(n, r), a = !0
        },
        p(s, l) {
            (!a || l[0] & 32768) && t !== (t = s[15]._(Q.vault) + "") && O(r, t)
        },
        i(s) {
            a || (d(e.$$.fragment, s), a = !0)
        },
        o(s) {
            m(e.$$.fragment, s), a = !1
        },
        d(s) {
            s && (f(i), f(n)), v(e, s)
        }
    }
}

function Od(o) {
    let e, i, n, t = o[15]._(Q.vip) + "",
        r, a;
    return e = new vi({}), {
        c() {
            g(e.$$.fragment), i = V(), n = T("span"), r = P(t)
        },
        l(s) {
            N(e.$$.fragment, s), i = M(s), n = I(s, "SPAN", {});
            var l = B(n);
            r = D(l, t), l.forEach(f)
        },
        m(s, l) {
            $(e, s, l), k(s, i, l), k(s, n, l), z(n, r), a = !0
        },
        p(s, l) {
            (!a || l[0] & 32768) && t !== (t = s[15]._(Q.vip) + "") && O(r, t)
        },
        i(s) {
            a || (d(e.$$.fragment, s), a = !0)
        },
        o(s) {
            m(e.$$.fragment, s), a = !1
        },
        d(s) {
            s && (f(i), f(n)), v(e, s)
        }
    }
}

function Ld(o) {
    let e, i;
    return e = new Fe({
        props: {
            "data-analytics": "global-userMenu-affiliate-item",
            class: "justify-start",
            to: "/affiliate",
            $$slots: {
                default: [Ud]
            },
            $$scope: {
                ctx: o
            }
        }
    }), e.$on("click", o[23]), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t[0] & 32768 | t[1] & 16384 && (r.$$scope = {
                dirty: t,
                ctx: n
            }), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Ud(o) {
    let e, i, n, t = o[15]._(Q.affiliate) + "",
        r, a;
    return e = new Sa({}), {
        c() {
            g(e.$$.fragment), i = V(), n = T("span"), r = P(t)
        },
        l(s) {
            N(e.$$.fragment, s), i = M(s), n = I(s, "SPAN", {});
            var l = B(n);
            r = D(l, t), l.forEach(f)
        },
        m(s, l) {
            $(e, s, l), k(s, i, l), k(s, n, l), z(n, r), a = !0
        },
        p(s, l) {
            (!a || l[0] & 32768) && t !== (t = s[15]._(Q.affiliate) + "") && O(r, t)
        },
        i(s) {
            a || (d(e.$$.fragment, s), a = !0)
        },
        o(s) {
            m(e.$$.fragment, s), a = !1
        },
        d(s) {
            s && (f(i), f(n)), v(e, s)
        }
    }
}

function Wd(o) {
    let e, i, n, t = o[15]._(Q.statistics) + "",
        r, a;
    return e = new ba({}), {
        c() {
            g(e.$$.fragment), i = V(), n = T("span"), r = P(t)
        },
        l(s) {
            N(e.$$.fragment, s), i = M(s), n = I(s, "SPAN", {});
            var l = B(n);
            r = D(l, t), l.forEach(f)
        },
        m(s, l) {
            $(e, s, l), k(s, i, l), k(s, n, l), z(n, r), a = !0
        },
        p(s, l) {
            (!a || l[0] & 32768) && t !== (t = s[15]._(Q.statistics) + "") && O(r, t)
        },
        i(s) {
            a || (d(e.$$.fragment, s), a = !0)
        },
        o(s) {
            m(e.$$.fragment, s), a = !1
        },
        d(s) {
            s && (f(i), f(n)), v(e, s)
        }
    }
}

function zd(o) {
    let e, i, n, t = o[15]._(Q.transactions) + "",
        r, a;
    return e = new Fa({}), {
        c() {
            g(e.$$.fragment), i = V(), n = T("span"), r = P(t)
        },
        l(s) {
            N(e.$$.fragment, s), i = M(s), n = I(s, "SPAN", {});
            var l = B(n);
            r = D(l, t), l.forEach(f)
        },
        m(s, l) {
            $(e, s, l), k(s, i, l), k(s, n, l), z(n, r), a = !0
        },
        p(s, l) {
            (!a || l[0] & 32768) && t !== (t = s[15]._(Q.transactions) + "") && O(r, t)
        },
        i(s) {
            a || (d(e.$$.fragment, s), a = !0)
        },
        o(s) {
            m(e.$$.fragment, s), a = !1
        },
        d(s) {
            s && (f(i), f(n)), v(e, s)
        }
    }
}

function Gd(o) {
    let e, i, n, t = o[15]._(Q.myBets) + "",
        r, a;
    return e = new Ai({}), {
        c() {
            g(e.$$.fragment), i = V(), n = T("span"), r = P(t)
        },
        l(s) {
            N(e.$$.fragment, s), i = M(s), n = I(s, "SPAN", {});
            var l = B(n);
            r = D(l, t), l.forEach(f)
        },
        m(s, l) {
            $(e, s, l), k(s, i, l), k(s, n, l), z(n, r), a = !0
        },
        p(s, l) {
            (!a || l[0] & 32768) && t !== (t = s[15]._(Q.myBets) + "") && O(r, t)
        },
        i(s) {
            a || (d(e.$$.fragment, s), a = !0)
        },
        o(s) {
            m(e.$$.fragment, s), a = !1
        },
        d(s) {
            s && (f(i), f(n)), v(e, s)
        }
    }
}

function jd(o) {
    let e, i, n, t = o[15]._(Q.settings) + "",
        r, a;
    return e = new ya({}), {
        c() {
            g(e.$$.fragment), i = V(), n = T("span"), r = P(t)
        },
        l(s) {
            N(e.$$.fragment, s), i = M(s), n = I(s, "SPAN", {});
            var l = B(n);
            r = D(l, t), l.forEach(f)
        },
        m(s, l) {
            $(e, s, l), k(s, i, l), k(s, n, l), z(n, r), a = !0
        },
        p(s, l) {
            (!a || l[0] & 32768) && t !== (t = s[15]._(Q.settings) + "") && O(r, t)
        },
        i(s) {
            a || (d(e.$$.fragment, s), a = !0)
        },
        o(s) {
            m(e.$$.fragment, s), a = !1
        },
        d(s) {
            s && (f(i), f(n)), v(e, s)
        }
    }
}

function Hd(o) {
    let e, i, n, t = o[15]._(Q.stakeSmart) + "",
        r, a;
    return e = new wa({}), {
        c() {
            g(e.$$.fragment), i = V(), n = T("span"), r = P(t)
        },
        l(s) {
            N(e.$$.fragment, s), i = M(s), n = I(s, "SPAN", {});
            var l = B(n);
            r = D(l, t), l.forEach(f)
        },
        m(s, l) {
            $(e, s, l), k(s, i, l), k(s, n, l), z(n, r), a = !0
        },
        p(s, l) {
            (!a || l[0] & 32768) && t !== (t = s[15]._(Q.stakeSmart) + "") && O(r, t)
        },
        i(s) {
            a || (d(e.$$.fragment, s), a = !0)
        },
        o(s) {
            m(e.$$.fragment, s), a = !1
        },
        d(s) {
            s && (f(i), f(n)), v(e, s)
        }
    }
}

function Yd(o) {
    let e, i, n, t = o[15]._(Q.liveSupport) + "",
        r, a;
    return e = new Ca({}), {
        c() {
            g(e.$$.fragment), i = V(), n = T("span"), r = P(t)
        },
        l(s) {
            N(e.$$.fragment, s), i = M(s), n = I(s, "SPAN", {});
            var l = B(n);
            r = D(l, t), l.forEach(f)
        },
        m(s, l) {
            $(e, s, l), k(s, i, l), k(s, n, l), z(n, r), a = !0
        },
        p(s, l) {
            (!a || l[0] & 32768) && t !== (t = s[15]._(Q.liveSupport) + "") && O(r, t)
        },
        i(s) {
            a || (d(e.$$.fragment, s), a = !0)
        },
        o(s) {
            m(e.$$.fragment, s), a = !1
        },
        d(s) {
            s && (f(i), f(n)), v(e, s)
        }
    }
}

function qd(o) {
    let e, i, n, t = o[15]._(Q.logout) + "",
        r, a;
    return e = new Il({}), {
        c() {
            g(e.$$.fragment), i = V(), n = T("span"), r = P(t)
        },
        l(s) {
            N(e.$$.fragment, s), i = M(s), n = I(s, "SPAN", {});
            var l = B(n);
            r = D(l, t), l.forEach(f)
        },
        m(s, l) {
            $(e, s, l), k(s, i, l), k(s, n, l), z(n, r), a = !0
        },
        p(s, l) {
            (!a || l[0] & 32768) && t !== (t = s[15]._(Q.logout) + "") && O(r, t)
        },
        i(s) {
            a || (d(e.$$.fragment, s), a = !0)
        },
        o(s) {
            m(e.$$.fragment, s), a = !1
        },
        d(s) {
            s && (f(i), f(n)), v(e, s)
        }
    }
}

function Kd(o) {
    let e, i, n, t, r, a, s, l, u, c, _, S, F, E, R, U, C, L, J, ee, ne;
    e = new se({
        props: {
            class: "justify-start",
            "data-analytics": "global-userMenu-wallet-item",
            $$slots: {
                default: [Vd]
            },
            $$scope: {
                ctx: o
            }
        }
    }), e.$on("click", Fl), n = new se({
        props: {
            class: "justify-start",
            "data-analytics": "global-userMenu-vault-item",
            "data-testid": "user-dropdown-vault",
            "data-test": "user-dropdown-vault",
            $$slots: {
                default: [Md]
            },
            $$scope: {
                ctx: o
            }
        }
    }), n.$on("click", o[29]), r = new se({
        props: {
            class: "justify-start",
            "data-analytics": "global-userMenu-vip-item",
            $$slots: {
                default: [Od]
            },
            $$scope: {
                ctx: o
            }
        }
    }), r.$on("click", o[30]);
    let G = Ld(o);
    return l = new se({
        props: {
            class: "justify-start",
            "data-analytics": "global-userMenu-statistics-item",
            $$slots: {
                default: [Wd]
            },
            $$scope: {
                ctx: o
            }
        }
    }), l.$on("click", o[31]), c = new Fe({
        props: {
            "data-analytics": "global-userMenu-transactions-item",
            to: "/transactions",
            class: "justify-start",
            $$slots: {
                default: [zd]
            },
            $$scope: {
                ctx: o
            }
        }
    }), c.$on("click", o[23]), S = new Fe({
        props: {
            class: "justify-start",
            "data-analytics": "global-userMenu-mybets-item",
            to: o[3].url.pathname.startsWith(o[22]) ? ke.sportsMyBets : ke.mybets,
            $$slots: {
                default: [Gd]
            },
            $$scope: {
                ctx: o
            }
        }
    }), S.$on("click", o[23]), E = new Fe({
        props: {
            class: "justify-start",
            "data-analytics": "global-userMenu-settings-item",
            to: ke.settings,
            $$slots: {
                default: [jd]
            },
            $$scope: {
                ctx: o
            }
        }
    }), E.$on("click", o[23]), U = new Fe({
        props: {
            class: "justify-start",
            "data-analytics": "global-userMenu-responsibleGambling-item",
            to: ke.stakeSmart,
            $$slots: {
                default: [Hd]
            },
            $$scope: {
                ctx: o
            }
        }
    }), U.$on("click", o[23]), L = new se({
        props: {
            class: "justify-start intercom-a-go-go",
            "data-analytics": "global-userMenu-support-item",
            $$slots: {
                default: [Yd]
            },
            $$scope: {
                ctx: o
            }
        }
    }), ee = new se({
        props: {
            class: "justify-start",
            "data-analytics": "global-userMenu-logout-item",
            $$slots: {
                default: [qd]
            },
            $$scope: {
                ctx: o
            }
        }
    }), ee.$on("click", o[32]), {
        c() {
            g(e.$$.fragment), i = V(), g(n.$$.fragment), t = V(), g(r.$$.fragment), a = V(), G && G.c(), s = V(), g(l.$$.fragment), u = V(), g(c.$$.fragment), _ = V(), g(S.$$.fragment), F = V(), g(E.$$.fragment), R = V(), g(U.$$.fragment), C = V(), g(L.$$.fragment), J = V(), g(ee.$$.fragment)
        },
        l(b) {
            N(e.$$.fragment, b), i = M(b), N(n.$$.fragment, b), t = M(b), N(r.$$.fragment, b), a = M(b), G && G.l(b), s = M(b), N(l.$$.fragment, b), u = M(b), N(c.$$.fragment, b), _ = M(b), N(S.$$.fragment, b), F = M(b), N(E.$$.fragment, b), R = M(b), N(U.$$.fragment, b), C = M(b), N(L.$$.fragment, b), J = M(b), N(ee.$$.fragment, b)
        },
        m(b, W) {
            $(e, b, W), k(b, i, W), $(n, b, W), k(b, t, W), $(r, b, W), k(b, a, W), G && G.m(b, W), k(b, s, W), $(l, b, W), k(b, u, W), $(c, b, W), k(b, _, W), $(S, b, W), k(b, F, W), $(E, b, W), k(b, R, W), $(U, b, W), k(b, C, W), $(L, b, W), k(b, J, W), $(ee, b, W), ne = !0
        },
        p(b, W) {
            const Ie = {};
            W[0] & 32768 | W[1] & 16384 && (Ie.$$scope = {
                dirty: W,
                ctx: b
            }), e.$set(Ie);
            const Se = {};
            W[0] & 32768 | W[1] & 16384 && (Se.$$scope = {
                dirty: W,
                ctx: b
            }), n.$set(Se);
            const Ve = {};
            W[0] & 32768 | W[1] & 16384 && (Ve.$$scope = {
                dirty: W,
                ctx: b
            }), r.$set(Ve), G.p(b, W);
            const Me = {};
            W[0] & 32768 | W[1] & 16384 && (Me.$$scope = {
                dirty: W,
                ctx: b
            }), l.$set(Me);
            const Oe = {};
            W[0] & 32768 | W[1] & 16384 && (Oe.$$scope = {
                dirty: W,
                ctx: b
            }), c.$set(Oe);
            const Ne = {};
            W[0] & 8 && (Ne.to = b[3].url.pathname.startsWith(b[22]) ? ke.sportsMyBets : ke.mybets), W[0] & 32768 | W[1] & 16384 && (Ne.$$scope = {
                dirty: W,
                ctx: b
            }), S.$set(Ne);
            const Le = {};
            W[0] & 32768 | W[1] & 16384 && (Le.$$scope = {
                dirty: W,
                ctx: b
            }), E.$set(Le);
            const he = {};
            W[0] & 32768 | W[1] & 16384 && (he.$$scope = {
                dirty: W,
                ctx: b
            }), U.$set(he);
            const Ue = {};
            W[0] & 32768 | W[1] & 16384 && (Ue.$$scope = {
                dirty: W,
                ctx: b
            }), L.$set(Ue);
            const We = {};
            W[0] & 32768 | W[1] & 16384 && (We.$$scope = {
                dirty: W,
                ctx: b
            }), ee.$set(We)
        },
        i(b) {
            ne || (d(e.$$.fragment, b), d(n.$$.fragment, b), d(r.$$.fragment, b), d(G), d(l.$$.fragment, b), d(c.$$.fragment, b), d(S.$$.fragment, b), d(E.$$.fragment, b), d(U.$$.fragment, b), d(L.$$.fragment, b), d(ee.$$.fragment, b), ne = !0)
        },
        o(b) {
            m(e.$$.fragment, b), m(n.$$.fragment, b), m(r.$$.fragment, b), m(G), m(l.$$.fragment, b), m(c.$$.fragment, b), m(S.$$.fragment, b), m(E.$$.fragment, b), m(U.$$.fragment, b), m(L.$$.fragment, b), m(ee.$$.fragment, b), ne = !1
        },
        d(b) {
            b && (f(i), f(t), f(a), f(s), f(u), f(_), f(F), f(R), f(C), f(J)), v(e, b), v(n, b), v(r, b), G && G.d(b), v(l, b), v(c, b), v(S, b), v(E, b), v(U, b), v(L, b), v(ee, b)
        }
    }
}

function Zd(o) {
    let e, i, n, t;
    return e = new pi({
        props: {
            iconOnly: !0,
            "data-test": "user-dropdown-toggle",
            "data-analytics": "global-navbar-user-icon",
            variant: "link",
            "data-content": wi,
            size: "sm",
            $$slots: {
                default: [Rd]
            },
            $$scope: {
                ctx: o
            }
        }
    }), n = new gi({
        props: {
            $$slots: {
                default: [Kd]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            g(e.$$.fragment), i = V(), g(n.$$.fragment)
        },
        l(r) {
            N(e.$$.fragment, r), i = M(r), N(n.$$.fragment, r)
        },
        m(r, a) {
            $(e, r, a), k(r, i, a), $(n, r, a), t = !0
        },
        p(r, a) {
            const s = {};
            a[1] & 16384 && (s.$$scope = {
                dirty: a,
                ctx: r
            }), e.$set(s);
            const l = {};
            a[0] & 180232 | a[1] & 16384 && (l.$$scope = {
                dirty: a,
                ctx: r
            }), n.$set(l)
        },
        i(r) {
            t || (d(e.$$.fragment, r), d(n.$$.fragment, r), t = !0)
        },
        o(r) {
            m(e.$$.fragment, r), m(n.$$.fragment, r), t = !1
        },
        d(r) {
            r && f(i), v(e, r), v(n, r)
        }
    }
}

function li(o) {
    let e, i, n, t;
    const r = [Qd, Xd],
        a = [];

    function s(l, u) {
        return 0
    }
    return e = s(), i = a[e] = r[e](o), {
        c() {
            i.c(), n = h()
        },
        l(l) {
            i.l(l), n = h()
        },
        m(l, u) {
            a[e].m(l, u), k(l, n, u), t = !0
        },
        p(l, u) {
            i.p(l, u)
        },
        i(l) {
            t || (d(i), t = !0)
        },
        o(l) {
            m(i), t = !1
        },
        d(l) {
            l && f(n), a[e].d(l)
        }
    }
}

function Xd(o) {
    let e, i;
    return e = new se({
        props: {
            class: "w-full justify-start",
            variant: "link",
            size: "sm",
            iconOnly: !0,
            active: o[18] === "chat",
            "aria-label": "Toggle Chat",
            $$slots: {
                default: [Jd]
            },
            $$scope: {
                ctx: o
            }
        }
    }), e.$on("click", o[35]), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t[0] & 262144 && (r.active = n[18] === "chat"), t[1] & 16384 && (r.$$scope = {
                dirty: t,
                ctx: n
            }), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Qd(o) {
    let e, i;
    return e = new _i({
        props: {
            transparent: !0,
            $$slots: {
                default: [im, ({
                    state: n
                }) => ({
                    44: n
                }), ({
                    state: n
                }) => [0, n ? 8192 : 0]]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t[0] & 294912 | t[1] & 24576 && (r.$$scope = {
                dirty: t,
                ctx: n
            }), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function Jd(o) {
    let e, i;
    return e = new Ci({}), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function xd(o) {
    let e, i;
    return e = new Ia({}), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function em(o) {
    let e, i, n, t = o[15]._(Q.chat) + "",
        r, a;
    return e = new Ci({}), {
        c() {
            g(e.$$.fragment), i = V(), n = T("span"), r = P(t)
        },
        l(s) {
            N(e.$$.fragment, s), i = M(s), n = I(s, "SPAN", {});
            var l = B(n);
            r = D(l, t), l.forEach(f)
        },
        m(s, l) {
            $(e, s, l), k(s, i, l), k(s, n, l), z(n, r), a = !0
        },
        p(s, l) {
            (!a || l[0] & 32768) && t !== (t = s[15]._(Q.chat) + "") && O(r, t)
        },
        i(s) {
            a || (d(e.$$.fragment, s), a = !0)
        },
        o(s) {
            m(e.$$.fragment, s), a = !1
        },
        d(s) {
            s && (f(i), f(n)), v(e, s)
        }
    }
}

function nm(o) {
    let e, i, n, t = o[15]._(Q.betslip) + "",
        r, a;
    return e = new Ai({}), {
        c() {
            g(e.$$.fragment), i = V(), n = T("span"), r = P(t)
        },
        l(s) {
            N(e.$$.fragment, s), i = M(s), n = I(s, "SPAN", {});
            var l = B(n);
            r = D(l, t), l.forEach(f)
        },
        m(s, l) {
            $(e, s, l), k(s, i, l), k(s, n, l), z(n, r), a = !0
        },
        p(s, l) {
            (!a || l[0] & 32768) && t !== (t = s[15]._(Q.betslip) + "") && O(r, t)
        },
        i(s) {
            a || (d(e.$$.fragment, s), a = !0)
        },
        o(s) {
            m(e.$$.fragment, s), a = !1
        },
        d(s) {
            s && (f(i), f(n)), v(e, s)
        }
    }
}

function tm(o) {
    let e, i, n, t;

    function r() {
        return o[33](o[44])
    }
    e = new se({
        props: {
            class: "w-full justify-start",
            active: o[18] === "chat",
            "aria-label": "Toggle Chat",
            $$slots: {
                default: [em]
            },
            $$scope: {
                ctx: o
            }
        }
    }), e.$on("click", r);

    function a() {
        return o[34](o[44])
    }
    return n = new se({
        props: {
            class: "w-full justify-start",
            "aria-label": "Toggle Betslip",
            active: o[18] === "betslip",
            $$slots: {
                default: [nm]
            },
            $$scope: {
                ctx: o
            }
        }
    }), n.$on("click", a), {
        c() {
            g(e.$$.fragment), i = V(), g(n.$$.fragment)
        },
        l(s) {
            N(e.$$.fragment, s), i = M(s), N(n.$$.fragment, s)
        },
        m(s, l) {
            $(e, s, l), k(s, i, l), $(n, s, l), t = !0
        },
        p(s, l) {
            o = s;
            const u = {};
            l[0] & 262144 && (u.active = o[18] === "chat"), l[0] & 32768 | l[1] & 16384 && (u.$$scope = {
                dirty: l,
                ctx: o
            }), e.$set(u);
            const c = {};
            l[0] & 262144 && (c.active = o[18] === "betslip"), l[0] & 32768 | l[1] & 16384 && (c.$$scope = {
                dirty: l,
                ctx: o
            }), n.$set(c)
        },
        i(s) {
            t || (d(e.$$.fragment, s), d(n.$$.fragment, s), t = !0)
        },
        o(s) {
            m(e.$$.fragment, s), m(n.$$.fragment, s), t = !1
        },
        d(s) {
            s && f(i), v(e, s), v(n, s)
        }
    }
}

function im(o) {
    let e, i, n, t;
    return e = new pi({
        props: {
            variant: "link",
            iconOnly: !0,
            size: "sm",
            class: "p-3",
            $$slots: {
                default: [xd]
            },
            $$scope: {
                ctx: o
            }
        }
    }), n = new gi({
        props: {
            $$slots: {
                default: [tm]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            g(e.$$.fragment), i = V(), g(n.$$.fragment)
        },
        l(r) {
            N(e.$$.fragment, r), i = M(r), N(n.$$.fragment, r)
        },
        m(r, a) {
            $(e, r, a), k(r, i, a), $(n, r, a), t = !0
        },
        p(r, a) {
            const s = {};
            a[1] & 16384 && (s.$$scope = {
                dirty: a,
                ctx: r
            }), e.$set(s);
            const l = {};
            a[0] & 294912 | a[1] & 24576 && (l.$$scope = {
                dirty: a,
                ctx: r
            }), n.$set(l)
        },
        i(r) {
            t || (d(e.$$.fragment, r), d(n.$$.fragment, r), t = !0)
        },
        o(r) {
            m(e.$$.fragment, r), m(n.$$.fragment, r), t = !1
        },
        d(r) {
            r && f(i), v(e, r), v(n, r)
        }
    }
}

function lm(o) {
    var S, F, E;
    let e, i, n, t, r, a, s = ((E = (F = (S = o[16]) == null ? void 0 : S[pn.play_session_flag]) == null ? void 0 : F.config) == null ? void 0 : E.enabled) && o[14].isAuthenticated && ni(),
        l = !o[2] && o[14].isAuthenticated && ti(o);
    const u = [Ed, Bd],
        c = [];

    function _(R, U) {
        return R[14].isAuthenticated ? 0 : 1
    }
    return n = _(o), t = c[n] = u[n](o), {
        c() {
            s && s.c(), e = V(), l && l.c(), i = V(), t.c(), r = h()
        },
        l(R) {
            s && s.l(R), e = M(R), l && l.l(R), i = M(R), t.l(R), r = h()
        },
        m(R, U) {
            s && s.m(R, U), k(R, e, U), l && l.m(R, U), k(R, i, U), c[n].m(R, U), k(R, r, U), a = !0
        },
        p(R, U) {
            var L, J, ee;
            (ee = (J = (L = R[16]) == null ? void 0 : L[pn.play_session_flag]) == null ? void 0 : J.config) != null && ee.enabled && R[14].isAuthenticated ? s ? U[0] & 81920 && d(s, 1) : (s = ni(), s.c(), d(s, 1), s.m(e.parentNode, e)) : s && (y(), m(s, 1, 1, () => {
                s = null
            }), w()), !R[2] && R[14].isAuthenticated ? l ? (l.p(R, U), U[0] & 16388 && d(l, 1)) : (l = ti(R), l.c(), d(l, 1), l.m(i.parentNode, i)) : l && (y(), m(l, 1, 1, () => {
                l = null
            }), w());
            let C = n;
            n = _(R), n === C ? c[n].p(R, U) : (y(), m(c[C], 1, 1, () => {
                c[C] = null
            }), w(), t = c[n], t ? t.p(R, U) : (t = c[n] = u[n](R), t.c()), d(t, 1), t.m(r.parentNode, r))
        },
        i(R) {
            a || (d(s), d(l), d(t), a = !0)
        },
        o(R) {
            m(s), m(l), m(t), a = !1
        },
        d(R) {
            R && (f(e), f(i), f(r)), s && s.d(R), l && l.d(R), c[n].d(R)
        }
    }
}

function am(o) {
    let e, i, n, t, r, a, s, l, u, c = o[1] && Jt(),
        _ = o[6] && xt(o);
    t = new Pe({
        props: {
            x: "flex-start",
            y: "center",
            horizontal: !0,
            gap: "smaller",
            $$slots: {
                default: [Td]
            },
            $$scope: {
                ctx: o
            }
        }
    });
    let S = o[14].isAuthenticated && ei(o);
    return l = new Pe({
        props: {
            gap: "none",
            x: "flex-end",
            horizontal: !0,
            $$slots: {
                default: [lm]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            e = T("div"), c && c.c(), i = V(), _ && _.c(), n = V(), g(t.$$.fragment), r = V(), S && S.c(), a = V(), s = T("section"), g(l.$$.fragment), this.h()
        },
        l(F) {
            e = I(F, "DIV", {
                class: !0
            });
            var E = B(e);
            c && c.l(E), i = M(E), _ && _.l(E), n = M(E), N(t.$$.fragment, E), r = M(E), S && S.l(E), a = M(E), s = I(E, "SECTION", {});
            var R = B(s);
            N(l.$$.fragment, R), R.forEach(f), E.forEach(f), this.h()
        },
        h() {
            H(e, "class", "navigation-container svelte-1nt2705"), re(e, "authenticated", o[14].isAuthenticated)
        },
        m(F, E) {
            k(F, e, E), c && c.m(e, null), z(e, i), _ && _.m(e, null), z(e, n), $(t, e, null), z(e, r), S && S.m(e, null), z(e, a), z(e, s), $(l, s, null), u = !0
        },
        p(F, E) {
            F[1] ? c ? E[0] & 2 && d(c, 1) : (c = Jt(), c.c(), d(c, 1), c.m(e, i)) : c && (y(), m(c, 1, 1, () => {
                c = null
            }), w()), F[6] ? _ ? (_.p(F, E), E[0] & 64 && d(_, 1)) : (_ = xt(F), _.c(), d(_, 1), _.m(e, n)) : _ && (y(), m(_, 1, 1, () => {
                _ = null
            }), w());
            const R = {};
            E[0] & 51332 | E[1] & 16384 && (R.$$scope = {
                dirty: E,
                ctx: F
            }), t.$set(R), F[14].isAuthenticated ? S ? (S.p(F, E), E[0] & 16384 && d(S, 1)) : (S = ei(F), S.c(), d(S, 1), S.m(e, a)) : S && (y(), m(S, 1, 1, () => {
                S = null
            }), w());
            const U = {};
            E[0] & 509020 | E[1] & 16384 && (U.$$scope = {
                dirty: E,
                ctx: F
            }), l.$set(U), (!u || E[0] & 16384) && re(e, "authenticated", F[14].isAuthenticated)
        },
        i(F) {
            u || (d(c), d(_), d(t.$$.fragment, F), d(S), d(l.$$.fragment, F), u = !0)
        },
        o(F) {
            m(c), m(_), m(t.$$.fragment, F), m(S), m(l.$$.fragment, F), u = !1
        },
        d(F) {
            F && f(e), c && c.d(), _ && _.d(), v(t), S && S.d(), v(l)
        }
    }
}

function ai(o) {
    let e, i;
    return e = new $d({
        props: {
            $$slots: {
                default: [sm]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            g(e.$$.fragment)
        },
        l(n) {
            N(e.$$.fragment, n)
        },
        m(n, t) {
            $(e, n, t), i = !0
        },
        p(n, t) {
            const r = {};
            t[0] & 1081344 | t[1] & 16384 && (r.$$scope = {
                dirty: t,
                ctx: n
            }), e.$set(r)
        },
        i(n) {
            i || (d(e.$$.fragment, n), i = !0)
        },
        o(n) {
            m(e.$$.fragment, n), i = !1
        },
        d(n) {
            v(e, n)
        }
    }
}

function rm(o) {
    let e = o[15]._(o[20] ? Q.kycRejectedBannerText : Q.onboardingBannerText) + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t[0] & 1081344 && e !== (e = n[15]._(n[20] ? Q.kycRejectedBannerText : Q.onboardingBannerText) + "") && O(i, e)
        },
        d(n) {
            n && f(i)
        }
    }
}

function om(o) {
    let e = o[15]._(o[20] ? Q.kycRejectedButtonText : Q.onboardingButtonText) + "",
        i;
    return {
        c() {
            i = P(e)
        },
        l(n) {
            i = D(n, e)
        },
        m(n, t) {
            k(n, i, t)
        },
        p(n, t) {
            t[0] & 1081344 && e !== (e = n[15]._(n[20] ? Q.kycRejectedButtonText : Q.onboardingButtonText) + "") && O(i, e)
        },
        d(n) {
            n && f(i)
        }
    }
}

function sm(o) {
    let e, i, n, t;
    return e = new wd({
        props: {
            $$slots: {
                default: [rm]
            },
            $$scope: {
                ctx: o
            }
        }
    }), n = new Sd({
        props: {
            $$slots: {
                default: [om]
            },
            $$scope: {
                ctx: o
            }
        }
    }), n.$on("click", o[38]), {
        c() {
            g(e.$$.fragment), i = V(), g(n.$$.fragment)
        },
        l(r) {
            N(e.$$.fragment, r), i = M(r), N(n.$$.fragment, r)
        },
        m(r, a) {
            $(e, r, a), k(r, i, a), $(n, r, a), t = !0
        },
        p(r, a) {
            const s = {};
            a[0] & 1081344 | a[1] & 16384 && (s.$$scope = {
                dirty: a,
                ctx: r
            }), e.$set(s);
            const l = {};
            a[0] & 1081344 | a[1] & 16384 && (l.$$scope = {
                dirty: a,
                ctx: r
            }), n.$set(l)
        },
        i(r) {
            t || (d(e.$$.fragment, r), d(n.$$.fragment, r), t = !0)
        },
        o(r) {
            m(e.$$.fragment, r), m(n.$$.fragment, r), t = !1
        },
        d(r) {
            r && f(i), v(e, r), v(n, r)
        }
    }
}

function um(o) {
    let e, i, n, t, r, a, s, l, u, c;
    a = new Sl({
        props: {
            useGroup: !0,
            style: "height: 100%; justify-content:center; position:relative;",
            $$slots: {
                default: [am]
            },
            $$scope: {
                ctx: o
            }
        }
    });
    let _ = (o[19] || o[20]) && ai(o);
    return {
        c() {
            e = T("div"), i = T("div"), t = V(), r = T("div"), g(a.$$.fragment), s = V(), _ && _.c(), this.h()
        },
        l(S) {
            e = I(S, "DIV", {
                "data-layout": !0,
                class: !0
            });
            var F = B(e);
            i = I(F, "DIV", {
                class: !0
            }), B(i).forEach(f), F.forEach(f), t = M(S), r = I(S, "DIV", {
                "data-nosnippet": !0,
                "data-layout": !0,
                style: !0,
                class: !0
            });
            var E = B(r);
            N(a.$$.fragment, E), s = M(E), _ && _.l(E), E.forEach(f), this.h()
        },
        h() {
            H(i, "class", "sizer svelte-1nt2705"), H(e, "data-layout", ""), H(e, "class", "ctainer svelte-1nt2705"), H(r, "data-nosnippet", ""), H(r, "data-layout", ""), be(r, "--header-zIndex", o[8]), be(r, "padding-right", o[0] > 1280 ? "0" : "6px"), H(r, "class", "navigation svelte-1nt2705"), re(r, "mobile", o[2]), re(r, "hide-header", o[12] && o[13])
        },
        m(S, F) {
            k(S, e, F), z(e, i), k(S, t, F), k(S, r, F), $(a, r, null), z(r, s), _ && _.m(r, null), o[39](r), l = !0, u || (c = ci(n = pa.call(null, i, o[26])), u = !0)
        },
        p(S, F) {
            n && rl(n.update) && F[0] & 1 && n.update.call(null, S[26]);
            const E = {};
            F[0] & 511742 | F[1] & 16384 && (E.$$scope = {
                dirty: F,
                ctx: S
            }), a.$set(E), S[19] || S[20] ? _ ? (_.p(S, F), F[0] & 1572864 && d(_, 1)) : (_ = ai(S), _.c(), d(_, 1), _.m(r, null)) : _ && (y(), m(_, 1, 1, () => {
                _ = null
            }), w()), (!l || F[0] & 256) && be(r, "--header-zIndex", S[8]), (!l || F[0] & 1) && be(r, "padding-right", S[0] > 1280 ? "0" : "6px"), (!l || F[0] & 4) && re(r, "mobile", S[2]), (!l || F[0] & 12288) && re(r, "hide-header", S[12] && S[13])
        },
        i(S) {
            l || (d(a.$$.fragment, S), d(_), l = !0)
        },
        o(S) {
            m(a.$$.fragment, S), m(_), l = !1
        },
        d(S) {
            S && (f(e), f(t), f(r)), v(a), _ && _.d(), o[39](null), u = !1, c()
        }
    }
}

function cm(o, e, i) {
    let n, t, r, a, s, l, u, c, _, S, F, E, R, U, C, L, J, ee, ne;
    j(o, sn, X => i(1, l = X)), j(o, qe, X => i(2, u = X)), j(o, Ae, X => i(25, c = X)), j(o, kl, X => i(3, _ = X)), j(o, fa, X => i(4, S = X)), j(o, ka, X => i(12, F = X)), j(o, Na, X => i(13, E = X)), j(o, x, X => i(15, U = X)), j(o, ga, X => i(16, C = X)), j(o, rn, X => i(17, L = X)), j(o, vn, X => i(18, J = X)), j(o, $a, X => i(19, ee = X)), j(o, va, X => i(20, ne = X));
    const {
        meta: G
    } = _a();
    j(o, G, X => i(14, R = X));
    let b, W = !1;
    const Ie = c("/casino"),
        Se = c("/sports"),
        Ve = () => {
            u && (Cl.set("minimized"), vn.set("hidden"))
        };
    let Me = _.url.pathname.startsWith(Ie),
        Oe = _.url.pathname.startsWith(Se),
        Ne = c(Me ? "/casino/home" : Oe ? "/sports/home" : "/");
    const Le = _l();
    He(() => {
        let X = Le.page.subscribe(Be => {
            Be.url.pathname.startsWith(Ie) ? i(7, Ne = c("/casino/home")) : Be.url.pathname.startsWith(Se) && i(7, Ne = c("/sports/home"))
        });
        return () => {
            X()
        }
    });
    let he = 1e3;
    const Ue = X => i(0, he = X.width),
        We = () => i(6, W = !1),
        Gi = () => i(6, W = !W),
        ji = () => {
            me.vault.open({
                operation: "deposit",
                currency: L
            })
        },
        Hi = () => {
            me.vip.open({
                tab: "progress"
            })
        },
        Yi = () => {
            me.user.open({
                name: R.name,
                tab: "statistics"
            })
        },
        qi = () => {
            me.logout.open()
        },
        Ki = X => {
            ze.toggleChatSidebar(), X.closeDropdown()
        },
        Zi = X => {
            ze.toggleBetslipSidebar(), X.closeDropdown()
        },
        Xi = () => {
            ze.toggleChatSidebar()
        },
        Qi = () => me.auth.open({
            tab: "login"
        }),
        Ji = () => me.auth.open({
            tab: "register"
        }),
        xi = () => {
            var X, Be;
            return ne ? (X = me.kycRejected) == null ? void 0 : X.open() : (Be = me.continueSetup) == null ? void 0 : Be.open()
        };

    function el(X) {
        Je[X ? "unshift" : "push"](() => {
            b = X, i(5, b)
        })
    }
    return o.$$.update = () => {
        o.$$.dirty[0] & 16 && i(24, n = S === "fullsize" ? 400 : 600), o.$$.dirty[0] & 16777217 && i(11, t = he < n), o.$$.dirty[0] & 1 && i(10, r = he >= 850), o.$$.dirty[0] & 33554440 && i(9, a = _.url.pathname.startsWith(c("/sports")) ? "sports" : "casino"), o.$$.dirty[0] & 6 && i(8, s = u && l ? en.sidebar + 1 : en.header)
    }, [he, l, u, _, S, b, W, Ne, s, a, r, t, F, E, R, U, C, L, J, ee, ne, G, Se, Ve, n, c, Ue, We, Gi, ji, Hi, Yi, qi, Ki, Zi, Xi, Qi, Ji, xi, el]
}
class xf extends q {
    constructor(e) {
        super(), K(this, e, cm, um, Y, {}, null, [-1, -1])
    }
}
export {
    Wo as A, Kf as B, Qf as C, mr as D, Is as E, ce as F, mc as G, xf as N, Xf as S, Jf as a, Zf as b, So as c, Ao as d, Do as e, Uo as f, Ua as g, hs as h, Ss as i, bs as j, Oa as k, qa as l, Qa as m, rr as n, Qe as o, Xe as p, Tr as q, oo as r, Vr as s, Fs as t, Ns as u, po as v, Un as w, vt as x, ms as y, ls as z
};