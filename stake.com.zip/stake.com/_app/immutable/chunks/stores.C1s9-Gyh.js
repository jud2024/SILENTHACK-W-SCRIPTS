import {
    a0 as S,
    az as j,
    aR as b,
    aS as V,
    F as B
} from "./index.B4-7gKq3.js";
import {
    d as F,
    m as T,
    a as A,
    n as q
} from "./index.B81orGJm.js";
import {
    d as l,
    w as p
} from "./index.C2-CG2CN.js";
const R = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "query",
            name: {
                kind: "Name",
                value: "UserKycInfo"
            },
            variableDefinitions: [{
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "stakeKycEnabled"
                    }
                },
                type: {
                    kind: "NamedType",
                    name: {
                        kind: "Name",
                        value: "Boolean"
                    }
                },
                defaultValue: {
                    kind: "BooleanValue",
                    value: !1
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "veriffEnabled"
                    }
                },
                type: {
                    kind: "NamedType",
                    name: {
                        kind: "Name",
                        value: "Boolean"
                    }
                },
                defaultValue: {
                    kind: "BooleanValue",
                    value: !1
                }
            }],
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "isDiscontinuedBlocked"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "roles"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "name"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "kycStatus"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "dob"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "createdAt"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "hasEmailVerified"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "phoneNumber"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "phoneCountryCode"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "hasPhoneNumberVerified"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "email"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "registeredWithVpn"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "isBanned"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "isSuspended"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "isSuspendedSportsbook"
                            }
                        }, {
                            kind: "Field",
                            alias: {
                                kind: "Name",
                                value: "jpyAlternateName"
                            },
                            name: {
                                kind: "Name",
                                value: "cashierAlternateName"
                            },
                            arguments: [{
                                kind: "Argument",
                                name: {
                                    kind: "Name",
                                    value: "currency"
                                },
                                value: {
                                    kind: "EnumValue",
                                    value: "jpy"
                                }
                            }],
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "firstName"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "lastName"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "nationalId"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "nationalId"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "expireDate"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "issueDate"
                                    }
                                }]
                            }
                        }, {
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "StakeKyc"
                            },
                            directives: [{
                                kind: "Directive",
                                name: {
                                    kind: "Name",
                                    value: "include"
                                },
                                arguments: [{
                                    kind: "Argument",
                                    name: {
                                        kind: "Name",
                                        value: "if"
                                    },
                                    value: {
                                        kind: "Variable",
                                        name: {
                                            kind: "Name",
                                            value: "stakeKycEnabled"
                                        }
                                    }
                                }]
                            }]
                        }, {
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "Veriff"
                            },
                            directives: [{
                                kind: "Directive",
                                name: {
                                    kind: "Name",
                                    value: "include"
                                },
                                arguments: [{
                                    kind: "Argument",
                                    name: {
                                        kind: "Name",
                                        value: "if"
                                    },
                                    value: {
                                        kind: "Variable",
                                        name: {
                                            kind: "Name",
                                            value: "veriffEnabled"
                                        }
                                    }
                                }]
                            }]
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "UserKycBasic"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "UserKycBasic"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "address"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "birthday"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "city"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "country"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "firstName"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "lastName"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "phoneNumber"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "rejectedReason"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "status"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "updatedAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "zipCode"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "occupation"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "UserKycExtended"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "UserKycExtended"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "rejectedReason"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "status"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "UserKycFull"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "UserKycFull"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "rejectedReason"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "status"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "UserKycUltimate"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "UserKycUltimate"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "createdAt"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "rejectedReason"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "status"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "FiatTransactionEligibilityStateFragment"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "FiatTransactionEligibilityState"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "depositEnabled"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "withdrawalEnabled"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "CryptoTransactionEligibilityStateFragment"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "CryptoTransactionEligibilityState"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "depositEnabled"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "withdrawalEnabled"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "UserTransactionEligibilityStateFragment"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "UserTransactionEligibilityState"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "fiat"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "FiatTransactionEligibilityStateFragment"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "crypto"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "CryptoTransactionEligibilityStateFragment"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "useLegacyLogic"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "StakeKyc"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "User"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "isKycBasicRequired"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "isKycExtendedRequired"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "isKycFullRequired"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "isKycUltimateRequired"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "kycBasic"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "UserKycBasic"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "kycExtended"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "UserKycExtended"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "kycFull"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "UserKycFull"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "kycUltimate"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "UserKycUltimate"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "transactionEligibilityState"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "UserTransactionEligibilityStateFragment"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "Veriff"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "User"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "veriffStatus"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "veriffUser"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "reason"
                            }
                        }]
                    }
                }]
            }
        }]
    },
    h = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "query",
            name: {
                kind: "Name",
                value: "UserTransactionEligibility"
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "user"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "transactionEligibilityState"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "UserTransactionEligibilityStateFragment"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "FiatTransactionEligibilityStateFragment"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "FiatTransactionEligibilityState"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currency"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "depositEnabled"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "withdrawalEnabled"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "CryptoTransactionEligibilityStateFragment"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "CryptoTransactionEligibilityState"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "depositEnabled"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "withdrawalEnabled"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "UserTransactionEligibilityStateFragment"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "UserTransactionEligibilityState"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "fiat"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "FiatTransactionEligibilityStateFragment"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "crypto"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "CryptoTransactionEligibilityStateFragment"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "useLegacyLogic"
                    }
                }]
            }
        }]
    },
    m = (() => {
        const e = p({
            loading: !1,
            data: null
        });
        return { ...e,
            fetch: async () => {
                e.update(n => ({ ...n,
                    loading: !0
                }));
                const i = await S({
                    doc: R,
                    variables: {
                        stakeKycEnabled: F === "stake",
                        veriffEnabled: T
                    },
                    load: {
                        fetch
                    }
                });
                return e.set({ ...i,
                    loading: !1
                }), i == null ? void 0 : i.data
            }
        }
    })();
async function Y(e) {
    if (e.isAuthenticated) {
        const i = await S({
            doc: R,
            variables: {
                stakeKycEnabled: F === "stake",
                veriffEnabled: T
            },
            load: e
        });
        return i == null ? void 0 : i.data
    }
    return Promise.resolve(null)
}
const Z = (() => {
    const e = p({
        loading: !1,
        data: null
    });
    return { ...e,
        fetch: async () => {
            {
                e.update(n => ({ ...n,
                    loading: !0
                }));
                const i = await S({
                    doc: h,
                    variables: {},
                    load: {
                        fetch
                    }
                });
                return e.set({ ...i,
                    loading: !1
                }), i == null ? void 0 : i.data
            }
        }
    }
})();
async function U(e) {
    if (e.isAuthenticated && F === "stake") {
        const i = await S({
            doc: h,
            variables: {},
            load: e
        });
        return i == null ? void 0 : i.data
    }
    return Promise.resolve(null)
}
l([m], ([e]) => {
    var n;
    if (!e.data) return null;
    const i = e.data.user;
    return ((n = i == null ? void 0 : i.kycBasic) == null ? void 0 : n.birthday) || (i == null ? void 0 : i.dob)
});
const I = l([m], ([e]) => {
        var n, a;
        return e.data ? (a = (n = e == null ? void 0 : e.data) == null ? void 0 : n.user) == null ? void 0 : a.email : null
    }),
    $ = l([m], ([e]) => {
        var i, n;
        return (n = (i = e.data) == null ? void 0 : i.user) == null ? void 0 : n.isBanned
    }),
    ee = l([m], ([e]) => {
        var i, n, a;
        return !!((a = (n = (i = e.data) == null ? void 0 : i.user) == null ? void 0 : n.roles) != null && a.find(t => t.name === j.suspendedTipping))
    }),
    x = l([m], ([e]) => {
        var n, a, t;
        const i = (a = (n = e == null ? void 0 : e.data) == null ? void 0 : n.user) == null ? void 0 : a.kycBasic;
        return i && (i == null ? void 0 : i.country) in b ? (t = b[i == null ? void 0 : i.country]) == null ? void 0 : t.currency : null
    }),
    L = (e, i, n) => n && !i || (e === "withdraw" || e === "buy" || e === "deposit") && !i,
    O = ["deposit", "withdraw", "buy", "tip", "overview"],
    ie = ({
        tab: e,
        currency: i
    }) => l([m, c, _, W, z, P, x, o, H, i], ([n, a, t, d, r, k, v, N, w, y]) => {
        var g, f;
        if (O.includes(e)) {
            const s = (g = n == null ? void 0 : n.data) == null ? void 0 : g.user;
            if (!s) return "error";
            s.veriffStatus;
            const D = (f = n == null ? void 0 : n.data) == null ? void 0 : f.isDiscontinuedBlocked,
                C = s == null ? void 0 : s.kycBasic,
                K = s == null ? void 0 : s.kycExtended,
                E = y in B;
            if (!A && q && !a && (!C || !N && !K)) return "setupWallet";
            if (s.isBanned && e !== "overview") return "banned";
            if (s.isSuspendedSportsbook) return "suspendedSportsbook";
            if (s.isSuspended && e === "deposit") return "suspended";
            if (D && e === "deposit") return "discontinued";
            if (L(e, w, E)) return "emailVerification";
            if (E) {
                if (e === "deposit") {
                    if (s.roles.some(u => u.name === "fiatWithdrawOnly")) return "fiatWithdrawOnly";
                    if (s.roles.some(u => u.name === "fiatKycRequired")) return "fiatKycRequired";
                    if (s.roles.some(u => u.name === "fiatSuspended")) return "fiatSuspended"
                }
                if (e === "withdraw" && s.roles.some(u => u.name === "fiatSuspended")) return "fiatSuspended"; {
                    const u = e === "deposit" ? k : e === "withdraw" ? r : void 0;
                    if ((e === "withdraw" || e === "deposit") && v !== y) return "fiatCurrencyUnavailable";
                    if (u !== "enabled") return u
                }
            } else {
                const u = e === "deposit" ? t : e === "withdraw" ? d : void 0;
                if (u !== "enabled") return u
            }
        }
        return "completed"
    }),
    c = l([m], ([e]) => {
        var a, t;
        const i = (a = e == null ? void 0 : e.data) == null ? void 0 : a.user,
            n = (t = i == null ? void 0 : i.transactionEligibilityState) == null ? void 0 : t.useLegacyLogic;
        return n === void 0 ? !0 : n
    }),
    o = l([m], ([e]) => {
        var i, n, a;
        return ((a = (n = (i = e == null ? void 0 : e.data) == null ? void 0 : i.user) == null ? void 0 : n.kycBasic) == null ? void 0 : a.country) === V.IN
    }),
    _ = l([m, c, o], ([e, i, n]) => {
        var r;
        const a = (r = e == null ? void 0 : e.data) == null ? void 0 : r.user,
            t = a == null ? void 0 : a.kycBasic,
            d = a == null ? void 0 : a.kycExtended;
        if (i) {
            if ((t == null ? void 0 : t.status) === "rejected") return "kycRejected"
        } else {
            if (!t || !n && !d) return "kycRequired";
            if ((t == null ? void 0 : t.status) === "rejected" || !n && (d == null ? void 0 : d.status) === "rejected") return "kycRejected"
        }
        return "enabled"
    }),
    W = l([m, c, o], ([e, i, n]) => {
        var d;
        const a = (d = e == null ? void 0 : e.data) == null ? void 0 : d.user,
            t = a == null ? void 0 : a.kycExtended;
        return !i && !n && !t ? "kycRequired" : "enabled"
    }),
    P = l([m, o], ([e, i]) => {
        var d;
        const n = (d = e == null ? void 0 : e.data) == null ? void 0 : d.user,
            a = n == null ? void 0 : n.kycBasic,
            t = n == null ? void 0 : n.kycExtended;
        if (i)
            if (a) {
                if ((a == null ? void 0 : a.status) === "rejected") return "kycRejected"
            } else return "kycRequired";
        else {
            if (!a || !t) return "kycRequired";
            if ((a == null ? void 0 : a.status) === "rejected" || (t == null ? void 0 : t.status) === "rejected") return "kycRejected"
        }
        return "enabled"
    }),
    z = l([m, o], ([e, i]) => {
        var k, v, N;
        const n = (k = e == null ? void 0 : e.data) == null ? void 0 : k.user,
            a = n == null ? void 0 : n.kycBasic,
            t = n == null ? void 0 : n.kycExtended,
            d = (v = n == null ? void 0 : n.kycBasic) == null ? void 0 : v.status,
            r = (N = n == null ? void 0 : n.kycExtended) == null ? void 0 : N.status;
        if (i)
            if (a) {
                if (d === "rejected") return "kycRejected"
            } else return "kycRequired";
        else {
            if (!a || !t) return "kycRequired";
            if (r === "pending") return "extendedKycPending";
            if (d === "rejected" || r === "rejected") return "kycRejected"
        }
        return "enabled"
    }),
    ne = l([m, c, o], ([e, i, n]) => {
        var k;
        const a = (k = e == null ? void 0 : e.data) == null ? void 0 : k.user,
            t = a == null ? void 0 : a.kycBasic,
            d = a == null ? void 0 : a.kycExtended;
        return (i ? (t == null ? void 0 : t.status) === "rejected" : (t == null ? void 0 : t.status) === "rejected" || !n && (d == null ? void 0 : d.status) === "rejected") ? "kycRejected" : "enabled"
    }),
    ae = l([m, c, o], ([e, i, n]) => !1),
    te = l([m, c, o], ([e, i, n]) => !1),
    G = p(void 0),
    H = l([m, G], ([e, i]) => {
        var n, a;
        return !!(i ? ? ((a = (n = e == null ? void 0 : e.data) == null ? void 0 : n.user) == null ? void 0 : a.hasEmailVerified))
    });
export {
    I as a, U as b, $ as c, ie as d, Y as e, ee as f, te as g, H as h, o as i, x as j, m as k, ne as l, z as m, P as n, G as o, ae as s, Z as u
};