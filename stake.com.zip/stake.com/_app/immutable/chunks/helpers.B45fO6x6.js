import {
    o as e,
    F as l
} from "./index.B4-7gKq3.js";
import {
    w as a
} from "./index.C2-CG2CN.js";
const n = e.eur,
    s = [e.eur, e.usd],
    c = (t, r) => t === n ? -2 : s.includes(t) && s.includes(r) === !1 ? -1 : s.includes(t) && s.includes(r) ? 0 : 1,
    d = t => t.filter(r => Object.keys(l).includes(r)),
    C = ({
        currencies: t,
        defaultCurrency: r,
        defaultFiatCurrency: i,
        view: u
    }) => t.includes(r) ? r : t.includes(u) ? u : t.includes(i) ? i : t.includes(n) ? n : t[0],
    S = (t, r) => r,
    E = a(!1);
export {
    C as a, d as f, S as g, c as s, E as t
};