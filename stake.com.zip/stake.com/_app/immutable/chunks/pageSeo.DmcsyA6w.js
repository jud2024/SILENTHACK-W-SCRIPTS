import {
    h as i
} from "./index.B4-7gKq3.js";
import {
    t as v
} from "./index.Cq_eNUyU.js";
import {
    k as e,
    o as d,
    V as f
} from "./index.B81orGJm.js";
import {
    c as p
} from "./get.YfNxXJCS.js";
const y = "/_app/immutable/assets/og.DOAgpOrC.jpg",
    h = {
        sweeps: {
            id: "Stake provides an unrivalled online social casino experience. Fun & Free to Play. Main Partner Everton FC. UFC Official Partner."
        },
        stake: {
            id: "Experience unbeatable crypto casino & sports betting online with Stake. Bet in BTC & more. VIP features include reload, rakeback & monthly bonus!"
        }
    },
    r = h[f] || h.stake,
    u = {
        "/": t => {
            const o = {
                    id: "{site} -  Crypto Casino & Sports Betting - BTC Casino Online",
                    values: {
                        site: e
                    }
                },
                s = {
                    title: o,
                    description: r,
                    images: [{
                        url: `${t}${y}`,
                        alt: "OG thumbnail"
                    }]
                };
            return {
                title: o,
                description: r,
                openGraph: s
            }
        },
        "/casino/[group]": ({
            group: t
        }) => ({
            title: `${t} - ${e}`,
            description: i._("Stake is the ultimate betting experience. Instantly deposit and withdraw Bitcoin, Ethereum, Doge, VISA, & more. Over 2000 games. Main sponsor of Watford F.C. and UFC Official Betting Partner")
        }),
        "/casino/home": {
            title: {
                id: "Casino Games Online - Play Best Casino Games on Stake.com"
            },
            description: {
                id: "Play the best casino games online and win jackpots, including slots, live casino, roulette and more! Discover popular casino games online at Stake.com."
            }
        },
        "/casino/home/[group]": ({
            group: t
        }) => ({
            title: `${t} - ${e}`,
            description: {
                id: "Play the hottest {group} games and win big!",
                values: {
                    group: t
                }
            }
        }),
        "/casino/collection/[collection]": ({
            collection: t
        }) => ({
            title: `${t} - ${e}`
        }),
        "/casino/collection/provider": {
            title: {
                id: "Casino Game Providers - Best Creators of Gambling Games"
            },
            description: {
                id: "Check out our selection of the best casino game providers online here on Stake. With favourites such as Pragmatic Play, Evolution, Play'n Go and more."
            }
        },
        "/favourites": {
            title: {
                id: "Favourite Casino Games - {site}",
                values: {
                    site: e
                }
            },
            description: i._("All of your favourite casino games.")
        },
        "/casino/challenges": {
            title: {
                id: "Challenges - {site}",
                values: {
                    site: e
                }
            },
            description: i._("Challenges.")
        },
        "/casino/challenges/all-claimed": {
            title: {
                id: "All Claimed Challenges - {site}",
                values: {
                    site: e
                }
            },
            description: i._("All claimed challenges.")
        },
        "/casino/challenges/my-claimed": {
            title: {
                id: "My Claimed Challenges - {site}",
                values: {
                    site: e
                }
            },
            description: i._("My claimed challenges.")
        },
        "/casino/challenges/created": {
            title: {
                id: "Created Challenges - {site}",
                values: {
                    site: e
                }
            },
            description: i._("My created challenges.")
        },
        "/casino/games/baccarat": {
            title: {
                id: "Play Baccarat Online - Stake Originals on {site}",
                values: {
                    site: e
                }
            },
            description: {
                id: "Choose Player, Banker or a Tie in this casino favourite, exclusively here on {site}. One of the most authentic online Baccarat games at any online casino!",
                values: {
                    site: e
                }
            }
        },
        "/casino/games/blackjack": {
            title: {
                id: "Play Blackjack Online - Stake Originals on {site}",
                values: {
                    site: e
                }
            },
            description: {
                id: "Race to 21 with one of the most popular, fast paced card games to exist - Blackjack! With the lowest house edge out there, play the ultimate card showdown!"
            }
        },
        "/casino/group/[group]": ({
            group: t
        }) => {
            const o = e,
                s = i._("Casino Games"),
                a = s.toLowerCase();
            return {
                title: {
                    id: "Play {group} {gameType} Online - {site}",
                    values: {
                        group: t,
                        gameType: s,
                        site: o
                    }
                },
                description: {
                    id: "Experience the thrill of the best {group} {gameTypeLower} on Stake. From classics to innovative new titles, find the perfect game to play today!",
                    values: {
                        group: t,
                        gameTypeLower: a
                    }
                },
                generatedJsonLd: ""
            }
        },
        "/casino/my-bets": {
            title: {
                id: "My Bets - {site}",
                values: {
                    site: e
                }
            }
        },
        "/casino/recent": {
            title: {
                id: "Recently Played Casino Games - {site}",
                values: {
                    site: e
                }
            },
            description: i._("Your recently played casino games.")
        },
        "/casino/favourites": {
            title: {
                id: "Favourite Casino Games - {site}",
                values: {
                    site: e
                }
            }
        },
        "/sports/home": {
            title: {
                id: "Sports Betting - Online Sportsbook - Bet Online At {site}",
                values: {
                    site: e
                }
            },
            description: {
                id: "Bet online on the best online sportsbook and view the latest betting odds on your favourite sport! Bet on Football, NBA, MMA, MLB and more at {site}.",
                values: {
                    site: e
                }
            }
        },
        "/sports/home/my-bets": {
            title: {
                id: "My Bets - {site}",
                values: {
                    site: e
                }
            },
            description: i._("My sports bets.")
        },
        "/sports/my-bets": {
            title: {
                id: "My Bets - {site}",
                values: {
                    site: e
                }
            },
            description: i._("My sports bets.")
        },
        "/sports/favourites": {
            title: {
                id: "My Favourite Sports - {site}",
                values: {
                    site: e
                }
            }
        },
        "/sports/live": {
            title: {
                id: "Live Sports - {site}",
                values: {
                    site: e
                }
            }
        },
        "/sports/my-bets/settled": {
            title: {
                id: "My Settled Bets - {site}",
                values: {
                    site: e
                }
            }
        },
        "/sports/live/[sport]": ({
            sport: t
        }) => ({
            title: {
                id: "Live {sport} - {site}",
                values: {
                    sport: t,
                    site: e
                }
            }
        }),
        "/sports/upcoming": {
            title: {
                id: "Bet Upcoming Sports, Events & Tournaments on {site}",
                values: {
                    site: e
                }
            },
            description: {
                id: "Win big betting Upcoming Sports, Events & Tournaments online on Stake. Instantly deposit and withdraw BTC, ETH, Doge, & more. {site}",
                values: {
                    site: e
                }
            }
        },
        "/sports/upcoming/[sport]": ({
            sport: t
        }) => ({
            title: {
                id: "Starting Soon {sport} - {site}",
                values: {
                    sport: t,
                    site: e
                }
            }
        }),
        "/sports/[sport]/[category]/[tournament]": t => ({
            title: {
                id: "{tournament} Betting Online - Bet {sport} on Stake",
                values: t
            },
            description: {
                id: "Bet on {tournament} with the best {sport} {category} odds & betting tips online on Stake. Bet on live & upcoming {sport} fixtures & more.",
                values: t
            },
            generatedJsonLd: ""
        }),
        "/sports/outright/[sport]/[category]/[tournament]/[fixture]": t => ({
            title: {
                id: "Bet {fixture} Outright Winner - {category} {sport} - {site}",
                values: { ...t,
                    site: e
                }
            },
            description: {
                id: "Get the best odds selection and bet on {fixture} outright winner on Stake. Explore betting options for {category} {sport} on Stake's sportsbook.",
                values: t
            }
        }),
        "/sports/racing/[sport]/all/calendar/[date]": t => {
            const o = {
                    today: "Today's",
                    tomorrow: "Tomorrow's",
                    yesterday: "Yesterday's"
                },
                s = new Date(t.date),
                a = o[t.date] || new Intl.DateTimeFormat("en-US", {
                    month: "short",
                    day: "numeric",
                    year: "numeric"
                }).format(s);
            return {
                title: {
                    id: "{sport} - {formattedDate} Races & Betting Odds - {site}",
                    values: { ...t,
                        formattedDate: a,
                        site: e
                    }
                },
                description: {
                    id: "Explore {formattedDate} {sport} betting options and find the best odds for upcoming races on {site}. Browse our schedule, place your bets, and experience the thrill of {sport} betting online.",
                    values: { ...t,
                        formattedDate: a,
                        site: e
                    }
                }
            }
        },
        "/sports/racing/[sport]/[group]/calendar/[date]": t => {
            const o = {
                    today: "Today's",
                    tomorrow: "Tomorrow's",
                    yesterday: "Yesterday's"
                },
                s = new Date(t.date),
                a = o[t.date] || new Intl.DateTimeFormat("en-US", {
                    month: "short",
                    day: "numeric",
                    year: "numeric"
                }).format(s);
            return {
                title: {
                    id: "{sport} - {formattedDate} {group} Races & Betting Odds - {site}",
                    values: { ...t,
                        formattedDate: a,
                        site: e
                    }
                },
                description: {
                    id: "Explore {formattedDate} {group} {sport} betting options and find the best odds for upcoming races on {site}. Browse our schedule, place your bets, and experience the thrill of {sport} betting online.",
                    values: { ...t,
                        formattedDate: a,
                        site: e
                    }
                }
            }
        },
        "/sports/racing/[sport]/[group]/meeting/[meeting]": t => ({
            title: {
                id: "{meeting} {sport} - {group} Racing - {site}",
                values: { ...t,
                    site: e
                }
            },
            description: {
                id: "Discover the best odds and betting options for {meeting} races in {group} {sport}. Dive into the excitement of {sport} betting at {site} and place your bets on {meeting}{sport}.",
                values: { ...t,
                    site: e
                }
            }
        }),
        "/sports/racing/[sport]/[group]/meeting/[meeting]/[event]": t => ({
            title: {
                id: "R{raceNumber} {meeting} - {event} - {site}",
                values: { ...t,
                    site: e
                }
            },
            description: {
                id: "Get the best odds and place your bets on {event} on {site}. Experience the thrill of {meeting} {sport} and explore a wide range of betting options at {site}.",
                values: { ...t,
                    site: e
                }
            }
        }),
        "/sports/esports": {
            title: {
                id: "Esports - {site}",
                values: {
                    site: e
                }
            }
        },
        "/sports/esports/[sport]": ({
            sport: t
        }) => ({
            title: {
                id: "Starting Soon {sport} - {site}",
                values: {
                    sport: t,
                    site: e
                }
            }
        }),
        "/provably-fair/server-seed-unhash": {
            title: {
                id: "Unhash Server Seed - {site}",
                values: {
                    site: e
                }
            }
        },
        "/casino/games/[game]": t => {
            var m;
            const o = (m = t.groupGames) == null ? void 0 : m.find(S => S.group.type === "provider"),
                s = o ? o.group.translation : null,
                a = (t == null ? void 0 : t.name) && v(t.name);
            let n = i._("Casino Game");
            t.icon === "provider-slots" ? n = i._("Slot Game") : (t.icon === "provider-live-casino" || t.icon === "provider-live-dealers") && (n = i._("Live Casino Game"));
            const l = n.toLowerCase(),
                c = s ? {
                    id: "{game} {gameTypeDescriptor} by {providerName} - {site}",
                    values: {
                        game: a,
                        gameTypeDescriptor: n,
                        providerName: s,
                        site: e
                    }
                } : {
                    id: "{game} {gameTypeDescriptor} - {site}",
                    values: {
                        game: a,
                        gameTypeDescriptor: n,
                        site: e
                    }
                },
                g = s ? {
                    id: "Experience the thrill of playing {game}, a {gameTypeDescriptorLower} by {providerName}. World-class gameplay & unmatched excitement awaits at {site}!",
                    values: {
                        game: a,
                        gameTypeDescriptorLower: l,
                        providerName: s,
                        site: e
                    }
                } : {
                    id: "Discover the excitement of playing {game} {gameTypeDescriptorLower} at {site}. Immerse yourself in a world of top-tier gaming and thrilling experiences on {site}!",
                    values: {
                        game: a,
                        gameTypeDescriptorLower: l,
                        site: e
                    }
                },
                b = {
                    title: c,
                    description: g,
                    images: [{
                        url: `${t.thumbnailUrl}?q=85`,
                        alt: `${c} thumbnail`
                    }]
                };
            return {
                title: c,
                description: g,
                openGraph: b
            }
        },
        "/provably-fair/overview": {
            title: {
                id: "Provably Fair Overview - Learn More Online at {site}",
                values: {
                    site: e
                }
            },
            description: {
                id: "The concept of provable fairness is that players can prove and verify that their results are fair. Learn more about the commitment scheme at {site}.",
                values: {
                    site: e
                }
            }
        },
        "/provably-fair/implementation": {
            title: {
                id: "Provably Fair Implementation - {site}",
                values: {
                    site: e
                }
            }
        },
        "/provably-fair/game-events": {
            title: {
                id: "Provably Fair Game Events - {site}",
                values: {
                    site: e
                }
            }
        },
        "/provably-fair/conversions": {
            title: {
                id: "Provably Fair Conversions - {site}",
                values: {
                    site: e
                }
            }
        },
        "/provably-fair/calculation": {
            title: {
                id: "Provably Fair Calculator - Get Conversions Online at {site}",
                values: {
                    site: e
                }
            },
            description: {
                id: "Provably fair calculator is a tool used to verify the fairness for players when betting online. Calculate probably fair at Stake Casino & Sportsbook. "
            }
        },
        "/blog": {
            title: {
                id: "Stake News & Blog - Latest Sports & Casino News on Stake"
            },
            generatedJsonLd: "",
            description: {
                id: "Learn about the latest in sports, betting tips, new casino games & announcements on the Stake.com Blog. Get all the latest Stake News all in one place!"
            }
        },
        "/giveaways": {
            title: {
                id: "News - {site}",
                values: {
                    site: e
                }
            },
            description: {
                id: "The latest news and offers for {site}",
                values: {
                    site: e
                }
            }
        },
        "/promotions": {
            title: {
                id: "Casino Bonuses & Sports Betting Promotions - Win at {site}!",
                values: {
                    site: e
                }
            },
            description: {
                id: "Check out the latest casino bonuses, betting promotions, and offers available on {site}. Explore our monthly bonus, info on races, challenges and more!",
                values: {
                    site: e
                }
            }
        },
        "/registration": {
            title: {
                id: "Stake Registration - Sign Up & Log in to {site}",
                values: {
                    site: e
                }
            },
            description: {
                id: "Join one of the pioneers of the crypto space, with a community feel that puts you in a real-life casino from the comfort of your mobile or computer."
            }
        },
        "/settings": {
            title: {
                id: "Settings - {site}",
                values: {
                    site: e
                }
            }
        },
        "/settings/general": {
            title: {
                id: "General Settings - {site}",
                values: {
                    site: e
                }
            }
        },
        "/settings/api": {
            title: {
                id: "Settings API Tokens - {site}",
                values: {
                    site: e
                }
            }
        },
        "/settings/ignored-users": {
            title: {
                id: "Ignored Users - {site}",
                values: {
                    site: e
                }
            },
            description: i._("See all of your ignored users.")
        },
        "/settings/offers": {
            title: {
                id: "Offers - {site}",
                values: {
                    site: e
                }
            }
        },
        "/settings/preferences": {
            title: {
                id: "Preferences - {site}",
                values: {
                    site: e
                }
            }
        },
        "/settings/security": {
            title: {
                id: "Account Security - {site}",
                values: {
                    site: e
                }
            }
        },
        "/settings/sessions": {
            title: {
                id: "Account Sessions - {site}",
                values: {
                    site: e
                }
            }
        },
        "/settings/verify": {
            title: {
                id: "Verify Account - {site}",
                values: {
                    site: e
                }
            },
            description: i._("Customize your user preferences and security settings.")
        },
        "/transactions": {
            title: {
                id: "All Transactions - {site}",
                values: {
                    site: e
                }
            }
        },
        "/transactions/bets": {
            title: {
                id: "Bet Transactions - {site}",
                values: {
                    site: e
                }
            }
        },
        "/transactions/deposits": {
            title: {
                id: "Deposit Transactions - {site}",
                values: {
                    site: e
                }
            }
        },
        "/transactions/withdrawals": {
            title: {
                id: "Withdrawal Transactions - {site}",
                values: {
                    site: e
                }
            }
        },
        "/transactions/archive": {
            title: {
                id: "Transaction Archive - {site}",
                values: {
                    site: e
                }
            }
        },
        "/transactions/other": {
            title: {
                id: "Other Transactions - {site}",
                values: {
                    site: e
                }
            }
        },
        "/vip-club": {
            title: {
                id: "VIP Club - {site}",
                values: {
                    site: e
                }
            },
            description: i._("VIP benefits and rewards.")
        },
        "/sports/home/my-bets/settled": {
            title: {
                id: "My settled bets - {site}",
                values: {
                    site: e
                }
            },
            description: i._("View the outcomes of your settled sports bets.")
        },
        "/sports/home/favourites": {
            title: {
                id: "Favourite Sport Markets -{site}",
                values: {
                    site: e
                }
            },
            description: {
                id: "Your favourite sport markets on {site}",
                values: {
                    site: e
                }
            }
        },
        "/sports/home/live": {
            title: {
                id: "Live Sports - {site}",
                values: {
                    site: e
                }
            },
            description: i._("Bet now on live matches of Baseball, Basketball, NRL, UFC and more!")
        },
        "/sports/home/live/[sport]": ({
            sport: t
        }) => ({
            title: {
                id: "Live {sport} - {site}",
                values: {
                    sport: t,
                    site: e
                }
            },
            description: {
                id: "Find the best live markets for {sport} on {site}.",
                values: {
                    sport: t,
                    site: e
                }
            }
        }),
        "/sports/home/upcoming": {
            title: {
                id: "Starting soon - {site}",
                values: {
                    site: e
                }
            },
            description: i._("Browse and bet on the most competitive upcoming sport markets.")
        },
        "/sports/home/upcoming/[sport]": ({
            sport: t
        }) => ({
            title: {
                id: "{sport} Starting Soon - {site}",
                values: {
                    sport: t,
                    site: e
                }
            },
            description: {
                id: "Discover the best markets for {sport} matches starting soon.",
                values: {
                    sport: t,
                    site: e
                }
            }
        }),
        "/sports/[sport]": ({
            sport: t
        }) => ({
            title: {
                id: "{sport} Betting Online - Bet Sports on Stake Sportsbook",
                values: {
                    sport: t
                }
            },
            generatedJsonLd: "",
            description: {
                id: "Bet on {sport} with the best {sport} odds for live & upcoming fixtures online at Stake.com. Find the latest odds for {sport} betting online now!",
                values: {
                    sport: t
                }
            }
        }),
        "/sports/[sport]/all": ({
            sport: t,
            sportSlug: o
        }) => {
            const s = v(t.replace(/-/g, " ") ? ? "");
            return {
                canonical: `https://${d}/sports/${o}/all`,
                title: `${s} - ${e}`,
                description: {
                    id: "Find a wide range or competitive markets for {sport} on {site}.",
                    values: {
                        sport: s,
                        site: e
                    }
                }
            }
        },
        "/sports/[sport]/outrights": ({
            sport: t
        }) => ({
            title: {
                id: "Bet {sport} Outright Winner Odds - {site}",
                values: {
                    sport: t,
                    site: e
                }
            },
            description: {
                id: "Explore the best outright winner odds for {sport} at {site}. View our comprehensive selection of {sport} odds on our sportsbook.",
                values: {
                    sport: t,
                    site: e
                }
            }
        }),
        "/sports/[sport]/[category]": t => ({
            title: {
                id: "{category} {sport} Betting Online - Bet {sport} on Stake",
                values: { ...t
                }
            },
            description: {
                id: "Bet on {category} {sport} with the latest {sport} betting odds on upcoming matches online at Stake sportsbook. Place bets on {sport} fixtures today.",
                values: { ...t
                }
            },
            generatedJsonLd: ""
        }),
        "/sports/[sport]/[category]/all": t => ({
            canonical: `https://${d}/sports/${t.sport}/all`,
            title: `${t.sport} ${t.category} - ${e}`,
            description: {
                id: "{category} betting for {sport}.",
                values: t
            }
        }),
        "/sports/[sport]/[category]/[tournament]/outright": t => ({
            title: `${t.sport} ${t.category}, ${t.tournament} - ${e}`,
            description: {
                id: "{category} outright markets for {sport} in {tournament}.",
                values: t
            }
        }),
        "/sports/[sport]/[category]/[tournament]/all": t => ({
            canonical: `https://${d}/sports/${t.sport}/all`,
            title: {
                id: "{category} betting for {sport} - {site}",
                values: { ...t,
                    site: e
                }
            },
            description: {
                id: "{category} live and upcoming betting for {sport} in {tournament}.",
                values: t
            }
        }),
        "/sports/[sport]/[category]/outrights": t => ({
            title: {
                id: "Bet {sport} Outright Winners in {category} - {site}",
                values: { ...t,
                    site: e
                }
            },
            description: {
                id: "Win big and bet on outright winners for {sport} in {category} on Stake. Explore the ultimate betting experience & odds selection on Stake's sportsbook.",
                values: t
            }
        }),
        "/sports/[sport]/[category]/[tournament]/outrights": t => ({
            title: {
                id: "Bet {tournament} Outright Winner - {category} {sport} - {site}",
                values: { ...t,
                    site: e
                }
            },
            description: {
                id: "Get the best odds selection and bet on {tournament} outright winner on Stake. Explore betting options for {category} {sport} on Stake's sportsbook.",
                values: t
            }
        }),
        "/sports/[sport]/[category]/[tournament]/[fixture]": t => ({
            title: {
                id: "{homeTeam} VS {awayTeam} - {site}",
                values: { ...t,
                    site: e
                }
            },
            generatedJsonLd: "",
            description: {
                id: "Bet {homeTeam} VS {awayTeam} on {date} on {site}. Explore all {tournament} {sport} gambling in {category}.",
                values: { ...t,
                    site: e
                }
            }
        }),
        "affiliate/analytics": {
            title: {
                id: "Affiliate Analytics - {site}",
                values: {
                    site: e
                }
            }
        },
        "affiliate/campaigns": {
            title: {
                id: "Affiliate Campaigns - {site}",
                values: {
                    site: e
                }
            }
        },
        "affiliate/commission": {
            title: {
                id: "Affiliate Commission - {site}",
                values: {
                    site: e
                }
            }
        },
        "affiliate/funds": {
            title: {
                id: "Affiliate Funds - {site}",
                values: {
                    site: e
                }
            }
        },
        "affiliate/overview": {
            title: {
                id: "Affiliate Overview - {site}",
                values: {
                    site: e
                }
            }
        },
        "affiliate/referred-users": {
            title: {
                id: "Affiliate Referred Users - {site}",
                values: {
                    site: e
                }
            }
        },
        "affiliate/retention": {
            title: {
                id: "Affiliate Retention - {site}",
                values: {
                    site: e
                }
            }
        },
        "/licenses": {
            title: {
                id: "Licenses for /{VITE_DISPLAY_SITE_NAME}",
                values: {
                    site: e
                },
                values: {
                    VITE_DISPLAY_SITE_NAME: e
                }
            }
        },
        "/responsible-[slug]/stake-smart": t => ({
            title: {
                id: "Responsible Gambling - Stake Smart Casino Gambling Info"
            },
            description: {
                id: "{site} is committed to provide a safe and responsible gambling environment for all users. Learn how you can be Stake Smart on our casino and sportsbook.",
                values: { ...t,
                    site: e
                }
            }
        }),
        "/responsible-[slug]/exclusion": t => ({
            title: {
                id: "Self Exclusion - {site}",
                values: { ...t,
                    site: e
                }
            }
        }),
        "/responsible-[slug]/calculator": t => ({
            title: {
                id: "Budget Calculator - {site}",
                values: { ...t,
                    site: e
                }
            }
        })
    },
    w = { ...u,
        "/": t => {
            const o = {
                    id: "{site} - The Leading Social Casino",
                    values: {
                        site: e
                    }
                },
                s = {
                    title: o,
                    description: r,
                    images: [{
                        url: `${t}${y}`,
                        alt: "OG thumbnail"
                    }]
                };
            return {
                title: o,
                description: r,
                openGraph: s
            }
        },
        "/casino/my-bets": {
            title: {
                id: "My Game Play - {site}",
                values: {
                    site: e
                }
            }
        },
        "/transactions/bets": {
            title: {
                id: "Game Play Transactions - {site}",
                values: {
                    site: e
                }
            }
        },
        "/transactions/deposits": {
            title: {
                id: "Purchases - {site}",
                values: {
                    site: e
                }
            }
        },
        "/transactions/withdrawals": {
            title: {
                id: "Redemptions - {site}",
                values: {
                    site: e
                }
            }
        },
        "/transactions/archive": {
            title: {
                id: "Game Play Archive - {site}",
                values: {
                    site: e
                }
            }
        },
        "/transactions/other": {
            title: {
                id: "Other Transactions - {site}",
                values: {
                    site: e
                }
            }
        },
        "/join": {
            title: {
                id: "Sign Up and Join - {site}",
                values: {
                    site: e
                }
            }
        },
        "/responsible-[slug]/stake-smart": t => ({
            title: {
                id: "Responsible Gaming - Stake Smart Social Casino Info"
            },
            description: {
                id: "{site} is committed to provide a safe and responsible gaming environment for all users. Learn how you can be Stake Smart on our social casino.",
                values: { ...t,
                    site: e
                }
            }
        }),
        "/responsible-[slug]/exclusion": t => ({
            title: {
                id: "Self Exclusion - {site}",
                values: { ...t,
                    site: e
                }
            }
        }),
        "/responsible-[slug]/calculator": t => ({
            title: {
                id: "Budget Calculator - {site}",
                values: { ...t,
                    site: e
                }
            }
        })
    },
    k = {
        stake: u,
        sweeps: w,
        canada: null,
        mexico: null,
        primedice: null
    },
    x = k[f] || u,
    O = p(`
*[_type == "seo"
  && __i18n_lang == $lang
  && slug.current == $slug
][0]
  {
   ...,
   'thumbnail': {
      'asset': thumbnail.asset->{url}
    },
    "content": content[] { 
        ...,
        asset->{url, altText},
    },
    "hreflangList": select(
      __i18n_lang == "en" => hreflangList,
      __i18n_base->hreflangList
    )
  }
`),
    L = p(`
*[_type == "seo"
  && __i18n_lang == $lang
  && slug.current == $slug
][0]
  {
   description,
   title,
   content
  }
`);
p(`
*[_type == "seo"
  && __i18n_lang == $lang
  && slug.current == $slug
][0]
  {
   description,
   title,
  }
`);
export {
    O as a, L as g, x as s
};