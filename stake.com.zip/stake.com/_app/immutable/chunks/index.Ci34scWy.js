import {
    i as _
} from "./index.1CTKaDY2.js";
import {
    g as B
} from "./roles.CMi1bAOW.js";
import {
    ak as F
} from "./index.B4-7gKq3.js";
import {
    x as L,
    v as U,
    G as k
} from "./scheduler.DXu26z7T.js";
import {
    w as M
} from "./index.C2-CG2CN.js";
const T = ["frozen", "banned", "houseExcluded", "suspended", "abuser", "fiatTip", "frozenLevel2", "promotionAbuser", "suspendedLevel1", "suspendedLevel2", "suspendedLevel3", "fiatKycRequired", "fiatSuspended", "fiatWithdrawOnly", "frozen", "frozenLevel2", "hiddenBetStream", "hiddenSportBetStream", "kycBanned", "noCashout", "sportsbookFraudForceFlagged", "casinoFraudForceFlagged", "bonusAbuser", "suspendedSanctions", "suspendedTipping", "rainAbuser"],
    V = t => {
        const e = {
            isAuthenticated: !1,
            isReferred: !1,
            hasRole: !1,
            isMaxBetEnabled: !1,
            isSportsbookExcluded: !1,
            id: "",
            name: "",
            hasPassword: !1,
            hasEmailVerified: !1,
            roles: [],
            includedRoles: [],
            hasTfaEnabled: !1,
            hasOauth: !1,
            hasPhoneNumberVerified: !1
        };
        return (() => {
            const n = M({ ...e,
                isAuthenticated: F()
            });
            return { ...n,
                setUser: async s => {
                    var i, l;
                    const {
                        id: u,
                        name: f,
                        hasEmailVerified: m,
                        intercomHash: h,
                        isReferred: p,
                        hasTfaEnabled: b,
                        hasPassword: E,
                        hasOauth: S,
                        isMaxBetEnabled: R,
                        isSportsbookExcluded: g,
                        hasPhoneNumberVerified: x
                    } = s, d = s.roles.map(a => a.name), v = d.find(a => !T.includes(a)) !== void 0, w = (s == null ? void 0 : s.includedRoles) || B({
                        infoRoles: ((l = (i = k(_)) == null ? void 0 : i.info) == null ? void 0 : l.roles) || [],
                        userRoles: s == null ? void 0 : s.roles
                    }).include, A = {
                        id: u,
                        name: f,
                        roles: d,
                        hasRole: v,
                        isReferred: p,
                        includedRoles: w,
                        intercomHash: h,
                        hasPassword: E,
                        hasEmailVerified: m,
                        isAuthenticated: !0,
                        hasTfaEnabled: b,
                        hasOauth: S,
                        isMaxBetEnabled: !!R,
                        isSportsbookExcluded: g,
                        hasPhoneNumberVerified: x
                    };
                    n.set(A)
                }
            }
        })()
    },
    c = "__stores__meta",
    q = () => {
        const e = {
            meta: V()
        };
        return U(c, e), e
    },
    o = t => {
        throw new Error(`Cannot ${t} session store before subscribing`)
    },
    r = {
        subscribe: t => {
            const e = y();
            return r.set = e.meta.set, r.setUser = e.meta.setUser, r.update = e.meta.update, e.meta.subscribe(t)
        },
        set: () => o("set"),
        update: () => o("update"),
        setUser: () => o("update")
    },
    y = () => L(c);
export {
    q as c, y as g, r as m
};