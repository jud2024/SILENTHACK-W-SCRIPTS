import {
    c as u
} from "./object.KBCZ3_4R.js";
import {
    r as c
} from "./messages.Cz2watLL.js";
import "./index.B4-7gKq3.js";
const l = (e, r) => {
        if (e.includes(" OPR/")) return e.includes("Mini") ? "Opera Mini" : "Opera";
        if (/(BlackBerry|PlayBook|BB10)/i.test(e)) return "BlackBerry";
        if (e.includes("IEMobile") || e.includes("WPDesktop")) return "Internet Explorer Mobile";
        if (e.includes("Edge")) return "Microsoft Edge";
        if (e.includes("FBIOS")) return "Facebook Mobile";
        if (e.includes("Chrome")) return "Chrome";
        if (e.includes("CriOS")) return "Chrome iOS";
        if (e.includes("UCWEB") || e.includes("UCBrowser")) return "UC Browser";
        if (e.includes("FxiOS")) return "Firefox iOS";
        if (r.includes("Apple")) return e.includes("Mobile") ? "Mobile Safari" : "Safari";
        if (e.includes("Android")) return "Android Mobile";
        if (e.includes("Konqueror")) return "Konqueror";
        if (e.includes("Firefox")) return "Firefox";
        if (e.includes("MSIE") || e.includes("Trident/")) return "Internet Explorer";
        if (e.includes("Gecko")) return "Mozilla"
    },
    f = (e, r) => {
        const i = l(e, r);
        if (!i) return;
        const t = {
            "internet explorer mobile": /rv:(\d+(\.\d+)?)/,
            "microsoft edge": /Edge\/(\d+(\.\d+)?)/,
            chrome: /Chrome\/(\d+(\.\d+)?)/,
            "chrome ios": /CriOS\/(\d+(\.\d+)?)/,
            "uc browser": /(UCBrowser|UCWEB)\/(\d+(\.\d+)?)/,
            safari: /Version\/(\d+(\.\d+)?)/,
            "mobile safari": /Version\/(\d+(\.\d+)?)/,
            opera: /(Opera|OPR)\/(\d+(\.\d+)?)/,
            firefox: /Firefox\/(\d+(\.\d+)?)/,
            "firefox ios": /FxiOS\/(\d+(\.\d+)?)/,
            konqueror: /Konqueror:(\d+(\.\d+)?)/,
            blackBerry: /BlackBerry (\d+(\.\d+)?)/,
            "android mobile": /android\s(\d+(\.\d+)?)/,
            "internet explorer": /(rv:|MSIE )(\d+(\.\d+)?)/,
            mozilla: /rv:(\d+(\.\d+)?)/
        }[i.toLowerCase()];
        if (t === void 0) return;
        const o = e.match(t);
        if (o) return parseFloat(o[o.length - 2]).toString()
    },
    m = e => {
        if (/Windows/i.test(e)) return /Phone/.test(e) || /WPDesktop/.test(e) ? "Windows Phone" : "Windows";
        if (/(iPhone|iPad|iPod)/.test(e)) return "iOS";
        if (/Android/.test(e)) return "Android";
        if (/(BlackBerry|PlayBook|BB10)/i.test(e)) return "BlackBerry";
        if (/Mac/i.test(e)) return "Mac OS X";
        if (/Linux/.test(e)) return "Linux";
        if (/CrOS/.test(e)) return "Chrome OS"
    },
    B = e => {
        if (/Windows Phone/i.test(e) || /WPDesktop/.test(e)) return "Windows Phone";
        if (/iPad/.test(e)) return "iPad";
        if (/iPod/.test(e)) return "iPod Touch";
        if (/iPhone/.test(e)) return "iPhone";
        if (/(BlackBerry|PlayBook|BB10)/i.test(e)) return "BlackBerry";
        if (/Android/.test(e)) return "Android"
    },
    w = e => {
        if (!e) return;
        const r = e.split("/");
        return r.length >= 3 ? r[2] : void 0
    },
    h = () => {
        if (typeof window > "u") return null;
        const {
            userAgent: e
        } = window.navigator, r = window.navigator.vendor || "", i = window.document.referrer || void 0, n = l(e, r), t = f(e, r), o = B(e), d = m(e), s = w(i);
        return {
            browser: n,
            browserVersion: t,
            device: o,
            os: d,
            referrer: i,
            referringDomain: s
        }
    },
    M = () => {
        const e = h();
        return (e != null && e.browser ? `${e==null?void 0:e.browser} (${(e==null?void 0:e.device)||"Unknown"})`.slice(0, 255) : null) || "Unknown"
    },
    a = e => {
        const r = new Date,
            [i, n, t] = e.split("/") || [null, null, null];
        if (Number(t) && Number(i) && Number(n)) {
            const o = new Date;
            o.setFullYear(Number(t)), o.setMonth(Number(i) - 1), o.setDate(Number(n));
            const d = r.getMonth() - o.getMonth();
            let s = r.getFullYear() - o.getFullYear();
            return (d < 0 || d === 0 && r.getDate() < o.getDate()) && (s -= 1), s
        }
        return NaN
    },
    P = (e, r) => u().required(String(e._(c.dateOfBirthRequired))).test({
        name: "isAdult",
        message: String(e._(c.minimumAge(r))),
        test: i => a(i) >= r
    }).test({
        name: "isTooOld",
        message: String(e._(c.maximumAge)),
        test: i => a(i) < 120
    }),
    k = "RegisterForm";
export {
    k as M, h as a, M as g, P as y
};