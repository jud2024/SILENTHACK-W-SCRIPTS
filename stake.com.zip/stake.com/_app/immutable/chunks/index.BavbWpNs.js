import {
    s as D,
    a as E,
    K as y,
    e as _,
    d as h,
    f as m,
    i as v,
    F as g,
    Q as k,
    V as c,
    j as I,
    k as W,
    u as C,
    g as S,
    b as T,
    L as V,
    v as X,
    M as j
} from "./scheduler.DXu26z7T.js";
import {
    S as q,
    i as F,
    t as K,
    b as L
} from "./index.Dz_MmNB3.js";
import {
    g as M
} from "./spread.CgU5AtxT.js";

function N(i) {
    let t, a, r, u, n;
    const f = i[4].default,
        e = E(f, i, i[3], null);
    let d = [{
            class: "tabs-wrapper scrollX"
        }, i[2]],
        l = {};
    for (let s = 0; s < d.length; s += 1) l = y(l, d[s]);
    return {
        c() {
            t = _("div"), a = _("div"), r = _("div"), e && e.c(), this.h()
        },
        l(s) {
            t = h(s, "DIV", {
                class: !0
            });
            var o = m(t);
            a = h(o, "DIV", {
                class: !0
            });
            var p = m(a);
            r = h(p, "DIV", {
                class: !0
            });
            var b = m(r);
            e && e.l(b), b.forEach(v), p.forEach(v), o.forEach(v), this.h()
        },
        h() {
            g(r, "class", "content-wrapper svelte-1vkrcyy"), g(a, "class", u = "slider variant-" + i[0] + " svelte-1vkrcyy"), k(t, l), c(t, "fullWidth", i[1]), c(t, "svelte-1vkrcyy", !0)
        },
        m(s, o) {
            I(s, t, o), W(t, a), W(a, r), e && e.m(r, null), n = !0
        },
        p(s, [o]) {
            e && e.p && (!n || o & 8) && C(e, f, s, s[3], n ? T(f, s[3], o, null) : S(s[3]), null), (!n || o & 1 && u !== (u = "slider variant-" + s[0] + " svelte-1vkrcyy")) && g(a, "class", u), k(t, l = M(d, [{
                class: "tabs-wrapper scrollX"
            }, o & 4 && s[2]])), c(t, "fullWidth", s[1]), c(t, "svelte-1vkrcyy", !0)
        },
        i(s) {
            n || (K(e, s), n = !0)
        },
        o(s) {
            L(e, s), n = !1
        },
        d(s) {
            s && v(t), e && e.d(s)
        }
    }
}

function P(i, t, a) {
    const r = ["variant", "fullWidth"];
    let u = V(t, r),
        {
            $$slots: n = {},
            $$scope: f
        } = t,
        {
            variant: e = "dark"
        } = t,
        {
            fullWidth: d = !1
        } = t;
    return X("parent", "subNav"), i.$$set = l => {
        t = y(y({}, t), j(l)), a(2, u = V(t, r)), "variant" in l && a(0, e = l.variant), "fullWidth" in l && a(1, d = l.fullWidth), "$$scope" in l && a(3, f = l.$$scope)
    }, [e, d, u, f, n]
}
class B extends q {
    constructor(t) {
        super(), F(this, t, P, N, D, {
            variant: 0,
            fullWidth: 1
        })
    }
}
export {
    B as T
};