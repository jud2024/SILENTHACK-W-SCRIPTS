import {
    h as r
} from "./index.B4-7gKq3.js";
import "./index.ByMdEFI5.js";
import {
    E as t
} from "./Error.DAkWdr3O.js";
const n = o => ({
    body: (o == null ? void 0 : o.message) || "",
    title: r._("Error"),
    icon: t,
    type: "negative"
});
export {
    n as c
};