import {
    s as ie,
    e as V,
    O as D,
    d as C,
    f as O,
    P as E,
    i as k,
    F as w,
    V as te,
    j as h,
    k as A,
    W as ue,
    a3 as $e,
    r as Ne,
    c as J,
    X as Fe,
    N as fe,
    t as G,
    h as L,
    l as P,
    a as nn,
    u as tn,
    g as an,
    b as ln,
    a6 as rn,
    a1 as ke,
    G as De,
    m as H,
    n as ee,
    o as Sn,
    I as _e,
    J as ge,
    q as hn
} from "./scheduler.DXu26z7T.js";
import {
    S as ae,
    i as le,
    c as $,
    a as N,
    m as F,
    t as _,
    g as W,
    b as S,
    e as K,
    d as b,
    f as sn
} from "./index.Dz_MmNB3.js";
import "./index.ByMdEFI5.js";
import {
    h as x,
    i as be,
    p as Ee,
    r as gn,
    a9 as $n,
    X as Nn,
    _ as ce,
    aK as Fn,
    n as bn
} from "./index.B4-7gKq3.js";
import "./index.B3dW9TVs.js";
import {
    a as he
} from "./index.CY6-K88d.js";
import {
    D as yn,
    a as wn,
    b as Tn
} from "./DropdownContent.DaecMGoH.js";
import {
    D as Dn
} from "./DropdownArrow.C_ADoLvp.js";
import {
    S as En
} from "./Search.Dsf-x3-k.js";
import {
    B as ne
} from "./button.BwmFDw8u.js";
import {
    C as on
} from "./Cross.DFKMr_Np.js";
import {
    f as dn
} from "./index.Bhhzp5qA.js";
import {
    b as Vn
} from "./blockTouchBodyScroll.cXxkc2Ey.js";
import {
    e as Z,
    u as un,
    o as mn
} from "./each.DvgCmocI.js";
import {
    K as Cn
} from "./KuratorGameQuery.generated.D_RF3oUR.js";
import {
    T as Y
} from "./index.D7nbRHfU.js";
import {
    B as cn
} from "./index.DlOe5U6J.js";
import {
    K as fn
} from "./index.Dyyr8xUD.js";
import {
    d as pe,
    e as ve
} from "./index.1CTKaDY2.js";
import {
    d as In
} from "./index.C2-CG2CN.js";
import {
    b as On,
    a as Rn,
    o as An,
    d as Ve
} from "./index.B43rDWIe.js";
import {
    _ as Mn
} from "./tslib.es6.CYhxggkG.js";
import {
    f as qn
} from "./dateTimestampProvider.DBRuHdww.js";
import {
    d as Gn,
    f as Ln
} from "./distinctUntilChanged.DlIsPrLg.js";
import {
    t as Ce
} from "./tap.C8oT6H3h.js";
import {
    d as Bn
} from "./debounceTime.Bb8mI86N.js";
import {
    s as Pn
} from "./switchMap.DLhHjf4W.js";
import {
    T as kn
} from "./index.BavbWpNs.js";
import {
    a as zn,
    F as Qn,
    L as Wn
} from "./index.BRT09uIB.js";
import {
    P as Kn
} from "./index.B1KDSkU5.js";
import {
    L as Un
} from "./index.DJurAkTj.js";
import {
    R as jn,
    a as Hn
} from "./RaceCountdownLive.DVPQx9ap.js";
import {
    f as Xn
} from "./index.Nhx66bSE.js";
import {
    r as pn
} from "./resizeObserver.A9wvMie0.js";
import {
    P as Jn
} from "./index.D1aiuvC7.js";
import {
    z as Se
} from "./variables.CIGccMR5.js";
import {
    c as Yn
} from "./popper.Dvb6l-Oe.js";
var Ie = function(r) {
    Mn(e, r);

    function e(n) {
        var t = r.call(this) || this;
        return t._value = n, t
    }
    return Object.defineProperty(e.prototype, "value", {
        get: function() {
            return this.getValue()
        },
        enumerable: !1,
        configurable: !0
    }), e.prototype._subscribe = function(n) {
        var t = r.prototype._subscribe.call(this, n);
        return !t.closed && n.next(this._value), t
    }, e.prototype.getValue = function() {
        var n = this,
            t = n.hasError,
            i = n.thrownError,
            a = n._value;
        if (t) throw i;
        return this._throwIfClosed(), a
    }, e.prototype.next = function(n) {
        r.prototype.next.call(this, this._value = n)
    }, e
}(qn);
const B = {
    minimumCharacters: x._("Search requires at least 3 characters."),
    noResults: x._("No results found."),
    recentSearches: x._("Recent Searches"),
    searchResults: x._("Search Results"),
    popularSearches: x._("Popular searches"),
    clearSearch: x._("Clear Search"),
    casino: x._("Casino"),
    sports: x._("Sports"),
    casinoPlaceholder: x._("Search your game"),
    sportsPlaceholder: x._("Search your event"),
    searchError: x._("Search Error")
};

function Oe(r) {
    let e, n, t;
    return n = new yn({
        props: {
            $$slots: {
                default: [tt, ({
                    state: i
                }) => ({
                    15: i
                }), ({
                    state: i
                }) => i ? 32768 : 0]
            },
            $$scope: {
                ctx: r
            }
        }
    }), {
        c() {
            e = V("div"), $(n.$$.fragment), this.h()
        },
        l(i) {
            e = C(i, "DIV", {
                class: !0
            });
            var a = O(e);
            N(n.$$.fragment, a), a.forEach(k), this.h()
        },
        h() {
            w(e, "class", "search-selector-wrap svelte-17iva6n")
        },
        m(i, a) {
            h(i, e, a), F(n, e, null), t = !0
        },
        p(i, a) {
            const s = {};
            a & 98370 && (s.$$scope = {
                dirty: a,
                ctx: i
            }), n.$set(s)
        },
        i(i) {
            t || (_(n.$$.fragment, i), t = !0)
        },
        o(i) {
            S(n.$$.fragment, i), t = !1
        },
        d(i) {
            i && k(e), b(n)
        }
    }
}

function Zn(r) {
    let e, n = r[6]._(B[r[1]]) + "",
        t, i, a, s;
    return a = new Dn({
        props: {
            style: "font-size: var(--text-size-default)"
        }
    }), {
        c() {
            e = V("span"), t = G(n), i = D(), $(a.$$.fragment), this.h()
        },
        l(o) {
            e = C(o, "SPAN", {
                class: !0
            });
            var l = O(e);
            t = L(l, n), l.forEach(k), i = E(o), N(a.$$.fragment, o), this.h()
        },
        h() {
            w(e, "class", "search-toggle svelte-17iva6n")
        },
        m(o, l) {
            h(o, e, l), A(e, t), h(o, i, l), F(a, o, l), s = !0
        },
        p(o, l) {
            (!s || l & 66) && n !== (n = o[6]._(B[o[1]]) + "") && P(t, n)
        },
        i(o) {
            s || (_(a.$$.fragment, o), s = !0)
        },
        o(o) {
            S(a.$$.fragment, o), s = !1
        },
        d(o) {
            o && (k(e), k(i)), b(a, o)
        }
    }
}

function xn(r) {
    let e, n = r[6]._(B.casino) + "",
        t;
    return {
        c() {
            e = V("span"), t = G(n), this.h()
        },
        l(i) {
            e = C(i, "SPAN", {
                class: !0
            });
            var a = O(e);
            t = L(a, n), a.forEach(k), this.h()
        },
        h() {
            w(e, "class", "button-inner svelte-17iva6n")
        },
        m(i, a) {
            h(i, e, a), A(e, t)
        },
        p(i, a) {
            a & 64 && n !== (n = i[6]._(B.casino) + "") && P(t, n)
        },
        d(i) {
            i && k(e)
        }
    }
}

function et(r) {
    let e, n = r[6]._(B.sports) + "",
        t;
    return {
        c() {
            e = V("span"), t = G(n), this.h()
        },
        l(i) {
            e = C(i, "SPAN", {
                class: !0
            });
            var a = O(e);
            t = L(a, n), a.forEach(k), this.h()
        },
        h() {
            w(e, "class", "svelte-17iva6n")
        },
        m(i, a) {
            h(i, e, a), A(e, t)
        },
        p(i, a) {
            a & 64 && n !== (n = i[6]._(B.sports) + "") && P(t, n)
        },
        d(i) {
            i && k(e)
        }
    }
}

function nt(r) {
    let e, n, t, i;

    function a() {
        return r[11](r[15])
    }
    e = new ne({
        props: {
            class: "justify-start",
            variant: "dropdown",
            $$slots: {
                default: [xn]
            },
            $$scope: {
                ctx: r
            }
        }
    }), e.$on("click", a);

    function s() {
        return r[12](r[15])
    }
    return t = new ne({
        props: {
            class: "justify-start",
            variant: "dropdown",
            $$slots: {
                default: [et]
            },
            $$scope: {
                ctx: r
            }
        }
    }), t.$on("click", s), {
        c() {
            $(e.$$.fragment), n = D(), $(t.$$.fragment)
        },
        l(o) {
            N(e.$$.fragment, o), n = E(o), N(t.$$.fragment, o)
        },
        m(o, l) {
            F(e, o, l), h(o, n, l), F(t, o, l), i = !0
        },
        p(o, l) {
            r = o;
            const d = {};
            l & 65600 && (d.$$scope = {
                dirty: l,
                ctx: r
            }), e.$set(d);
            const u = {};
            l & 65600 && (u.$$scope = {
                dirty: l,
                ctx: r
            }), t.$set(u)
        },
        i(o) {
            i || (_(e.$$.fragment, o), _(t.$$.fragment, o), i = !0)
        },
        o(o) {
            S(e.$$.fragment, o), S(t.$$.fragment, o), i = !1
        },
        d(o) {
            o && k(n), b(e, o), b(t, o)
        }
    }
}

function tt(r) {
    let e, n, t, i;
    return e = new wn({
        props: {
            $$slots: {
                default: [Zn]
            },
            $$scope: {
                ctx: r
            }
        }
    }), t = new Tn({
        props: {
            $$slots: {
                default: [nt]
            },
            $$scope: {
                ctx: r
            }
        }
    }), {
        c() {
            $(e.$$.fragment), n = D(), $(t.$$.fragment)
        },
        l(a) {
            N(e.$$.fragment, a), n = E(a), N(t.$$.fragment, a)
        },
        m(a, s) {
            F(e, a, s), h(a, n, s), F(t, a, s), i = !0
        },
        p(a, s) {
            const o = {};
            s & 65602 && (o.$$scope = {
                dirty: s,
                ctx: a
            }), e.$set(o);
            const l = {};
            s & 98368 && (l.$$scope = {
                dirty: s,
                ctx: a
            }), t.$set(l)
        },
        i(a) {
            i || (_(e.$$.fragment, a), _(t.$$.fragment, a), i = !0)
        },
        o(a) {
            S(e.$$.fragment, a), S(t.$$.fragment, a), i = !1
        },
        d(a) {
            a && k(n), b(e, a), b(t, a)
        }
    }
}

function Re(r) {
    let e, n, t;
    return n = new ne({
        props: {
            size: "md",
            variant: "subtle-link",
            $$slots: {
                default: [it]
            },
            $$scope: {
                ctx: r
            }
        }
    }), n.$on("click", r[14]), {
        c() {
            e = V("div"), $(n.$$.fragment), this.h()
        },
        l(i) {
            e = C(i, "DIV", {
                class: !0
            });
            var a = O(e);
            N(n.$$.fragment, a), a.forEach(k), this.h()
        },
        h() {
            w(e, "class", "cross-icon svelte-17iva6n")
        },
        m(i, a) {
            h(i, e, a), F(n, e, null), t = !0
        },
        p(i, a) {
            const s = {};
            a & 65536 && (s.$$scope = {
                dirty: a,
                ctx: i
            }), n.$set(s)
        },
        i(i) {
            t || (_(n.$$.fragment, i), t = !0)
        },
        o(i) {
            S(n.$$.fragment, i), t = !1
        },
        d(i) {
            i && k(e), b(n)
        }
    }
}

function it(r) {
    let e, n;
    return e = new on({}), {
        c() {
            $(e.$$.fragment)
        },
        l(t) {
            N(e.$$.fragment, t)
        },
        m(t, i) {
            F(e, t, i), n = !0
        },
        i(t) {
            n || (_(e.$$.fragment, t), n = !0)
        },
        o(t) {
            S(e.$$.fragment, t), n = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function at(r) {
    let e, n, t, i, a, s, o, l, d, u, c, f = r[2] && r[1] && Oe(r);
    i = new En({});
    let p = (r[0].length > 0 || r[3]) && Re(r);
    return {
        c() {
            e = V("div"), f && f.c(), n = D(), t = V("div"), $(i.$$.fragment), a = D(), s = V("input"), l = D(), p && p.c(), this.h()
        },
        l(v) {
            e = C(v, "DIV", {
                class: !0
            });
            var T = O(e);
            f && f.l(T), n = E(T), t = C(T, "DIV", {
                class: !0
            });
            var R = O(t);
            N(i.$$.fragment, R), R.forEach(k), a = E(T), s = C(T, "INPUT", {
                "data-testid": !0,
                "data-analytics": !0,
                placeholder: !0,
                class: !0
            }), l = E(T), p && p.l(T), T.forEach(k), this.h()
        },
        h() {
            w(t, "class", "search-icon svelte-17iva6n"), w(s, "data-testid", "search"), w(s, "data-analytics", r[4]), s.value = r[0], w(s, "placeholder", o = r[6]._(r[1] === "sports" ? B.sportsPlaceholder : B.casinoPlaceholder)), w(s, "class", "svelte-17iva6n"), w(e, "class", "input-wrap svelte-17iva6n"), te(e, "mobile", r[5])
        },
        m(v, T) {
            h(v, e, T), f && f.m(e, null), A(e, n), A(e, t), F(i, t, null), A(e, a), A(e, s), A(e, l), p && p.m(e, null), d = !0, u || (c = [ue(s, "input", r[13]), ue(s, "focus", r[10]), $e(r[8].call(null, s))], u = !0)
        },
        p(v, [T]) {
            v[2] && v[1] ? f ? (f.p(v, T), T & 6 && _(f, 1)) : (f = Oe(v), f.c(), _(f, 1), f.m(e, n)) : f && (W(), S(f, 1, 1, () => {
                f = null
            }), K()), (!d || T & 16) && w(s, "data-analytics", v[4]), (!d || T & 1 && s.value !== v[0]) && (s.value = v[0]), (!d || T & 66 && o !== (o = v[6]._(v[1] === "sports" ? B.sportsPlaceholder : B.casinoPlaceholder))) && w(s, "placeholder", o), v[0].length > 0 || v[3] ? p ? (p.p(v, T), T & 9 && _(p, 1)) : (p = Re(v), p.c(), _(p, 1), p.m(e, null)) : p && (W(), S(p, 1, 1, () => {
                p = null
            }), K()), (!d || T & 32) && te(e, "mobile", v[5])
        },
        i(v) {
            d || (_(f), _(i.$$.fragment, v), _(p), d = !0)
        },
        o(v) {
            S(f), S(i.$$.fragment, v), S(p), d = !1
        },
        d(v) {
            v && k(e), f && f.d(), b(i), p && p.d(), u = !1, Ne(c)
        }
    }
}

function lt(r, e, n) {
    let t, i;
    J(r, he, m => n(5, t = m)), J(r, be, m => n(6, i = m));
    let {
        value: a = ""
    } = e, {
        chosenType: s = null
    } = e, {
        isGlobal: o = !1
    } = e, {
        focusOnMount: l = !1
    } = e, {
        showSearchOverlay: d = !1
    } = e, {
        dataAnalytics: u = void 0
    } = e;
    const c = Fe(),
        f = m => {
            l && m.focus()
        };

    function p(m) {
        fe.call(this, r, m)
    }
    const v = m => {
            m.closeDropdown(), c("changeType", {
                value: "casino"
            })
        },
        T = m => {
            c("changeType", {
                value: "sports"
            }), m.closeDropdown()
        },
        R = m => c("input", m),
        X = () => {
            c("close")
        };
    return r.$$set = m => {
        "value" in m && n(0, a = m.value), "chosenType" in m && n(1, s = m.chosenType), "isGlobal" in m && n(2, o = m.isGlobal), "focusOnMount" in m && n(9, l = m.focusOnMount), "showSearchOverlay" in m && n(3, d = m.showSearchOverlay), "dataAnalytics" in m && n(4, u = m.dataAnalytics)
    }, [a, s, o, d, u, t, i, c, f, l, p, v, T, R, X]
}
class rt extends ae {
    constructor(e) {
        super(), le(this, e, lt, at, ie, {
            value: 0,
            chosenType: 1,
            isGlobal: 2,
            focusOnMount: 9,
            showSearchOverlay: 3,
            dataAnalytics: 4
        })
    }
}

function st(r) {
    let e, n, t, i, a;
    const s = r[2].default,
        o = nn(s, r, r[1], null);
    return {
        c() {
            e = V("div"), o && o.c(), this.h()
        },
        l(l) {
            e = C(l, "DIV", {
                class: !0
            });
            var d = O(e);
            o && o.l(d), d.forEach(k), this.h()
        },
        h() {
            w(e, "class", "results-wrapper scrollY svelte-15c4jgu"), te(e, "mobile", r[0])
        },
        m(l, d) {
            h(l, e, d), o && o.m(e, null), t = !0, i || (a = $e(Vn.call(null, e)), i = !0)
        },
        p(l, [d]) {
            o && o.p && (!t || d & 2) && tn(o, s, l, l[1], t ? ln(s, l[1], d, null) : an(l[1]), null), (!t || d & 1) && te(e, "mobile", l[0])
        },
        i(l) {
            t || (_(o, l), n || rn(() => {
                n = sn(e, dn, {
                    duration: 200,
                    delay: 0
                }), n.start()
            }), t = !0)
        },
        o(l) {
            S(o, l), t = !1
        },
        d(l) {
            l && k(e), o && o.d(l), i = !1, a()
        }
    }
}

function ot(r, e, n) {
    let t;
    J(r, he, s => n(0, t = s));
    let {
        $$slots: i = {},
        $$scope: a
    } = e;
    return r.$$set = s => {
        "$$scope" in s && n(1, a = s.$$scope)
    }, [t, a, i]
}
class dt extends ae {
    constructor(e) {
        super(), le(this, e, ot, st, ie, {})
    }
}

function Ae(r, e, n) {
    const t = r.slice();
    return t[5] = e[n], t
}

function ut(r) {
    let e = r[5] + "",
        n;
    return {
        c() {
            n = G(e)
        },
        l(t) {
            n = L(t, e)
        },
        m(t, i) {
            h(t, n, i)
        },
        p(t, i) {
            i & 1 && e !== (e = t[5] + "") && P(n, e)
        },
        d(t) {
            t && k(n)
        }
    }
}

function mt(r) {
    let e, n;
    return e = new on({}), {
        c() {
            $(e.$$.fragment)
        },
        l(t) {
            N(e.$$.fragment, t)
        },
        m(t, i) {
            F(e, t, i), n = !0
        },
        i(t) {
            n || (_(e.$$.fragment, t), n = !0)
        },
        o(t) {
            S(e.$$.fragment, t), n = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function ct(r) {
    let e, n, t, i, a, s;

    function o() {
        return r[3](r[5])
    }
    n = new ne({
        props: {
            size: "xs",
            variant: "subtle-link",
            $$slots: {
                default: [ut]
            },
            $$scope: {
                ctx: r
            }
        }
    }), n.$on("click", o);

    function l() {
        return r[4](r[5])
    }
    return i = new ne({
        props: {
            size: "xs",
            variant: "subtle-link",
            $$slots: {
                default: [mt]
            },
            $$scope: {
                ctx: r
            }
        }
    }), i.$on("click", l), {
        c() {
            e = V("div"), $(n.$$.fragment), t = D(), $(i.$$.fragment), a = D(), this.h()
        },
        l(d) {
            e = C(d, "DIV", {
                class: !0
            });
            var u = O(e);
            N(n.$$.fragment, u), t = E(u), N(i.$$.fragment, u), u.forEach(k), a = E(d), this.h()
        },
        h() {
            w(e, "class", "recent-search-inner-wrap svelte-1p39wq6")
        },
        m(d, u) {
            h(d, e, u), F(n, e, null), A(e, t), F(i, e, null), h(d, a, u), s = !0
        },
        p(d, u) {
            r = d;
            const c = {};
            u & 257 && (c.$$scope = {
                dirty: u,
                ctx: r
            }), n.$set(c);
            const f = {};
            u & 256 && (f.$$scope = {
                dirty: u,
                ctx: r
            }), i.$set(f)
        },
        i(d) {
            s || (_(n.$$.fragment, d), _(i.$$.fragment, d), s = !0)
        },
        o(d) {
            S(n.$$.fragment, d), S(i.$$.fragment, d), s = !1
        },
        d(d) {
            d && (k(e), k(a)), b(n), b(i)
        }
    }
}

function Me(r) {
    let e, n;
    return e = new cn({
        props: {
            rounded: !0,
            size: "sm",
            $$slots: {
                default: [ct]
            },
            $$scope: {
                ctx: r
            }
        }
    }), {
        c() {
            $(e.$$.fragment)
        },
        l(t) {
            N(e.$$.fragment, t)
        },
        m(t, i) {
            F(e, t, i), n = !0
        },
        p(t, i) {
            const a = {};
            i & 257 && (a.$$scope = {
                dirty: i,
                ctx: t
            }), e.$set(a)
        },
        i(t) {
            n || (_(e.$$.fragment, t), n = !0)
        },
        o(t) {
            S(e.$$.fragment, t), n = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function ft(r) {
    let e, n, t = Z(r[0]),
        i = [];
    for (let s = 0; s < t.length; s += 1) i[s] = Me(Ae(r, t, s));
    const a = s => S(i[s], 1, 1, () => {
        i[s] = null
    });
    return {
        c() {
            e = V("div");
            for (let s = 0; s < i.length; s += 1) i[s].c();
            this.h()
        },
        l(s) {
            e = C(s, "DIV", {
                class: !0
            });
            var o = O(e);
            for (let l = 0; l < i.length; l += 1) i[l].l(o);
            o.forEach(k), this.h()
        },
        h() {
            w(e, "class", "recent-search-wrap svelte-1p39wq6"), te(e, "mobile", r[1])
        },
        m(s, o) {
            h(s, e, o);
            for (let l = 0; l < i.length; l += 1) i[l] && i[l].m(e, null);
            n = !0
        },
        p(s, [o]) {
            if (o & 5) {
                t = Z(s[0]);
                let l;
                for (l = 0; l < t.length; l += 1) {
                    const d = Ae(s, t, l);
                    i[l] ? (i[l].p(d, o), _(i[l], 1)) : (i[l] = Me(d), i[l].c(), _(i[l], 1), i[l].m(e, null))
                }
                for (W(), l = t.length; l < i.length; l += 1) a(l);
                K()
            }(!n || o & 2) && te(e, "mobile", s[1])
        },
        i(s) {
            if (!n) {
                for (let o = 0; o < t.length; o += 1) _(i[o]);
                n = !0
            }
        },
        o(s) {
            i = i.filter(Boolean);
            for (let o = 0; o < i.length; o += 1) S(i[o]);
            n = !1
        },
        d(s) {
            s && k(e), ke(i, s)
        }
    }
}

function kt(r, e, n) {
    let t;
    J(r, he, l => n(1, t = l));
    let {
        searchList: i
    } = e;
    const a = Fe(),
        s = l => {
            a("select", l)
        },
        o = l => {
            a("remove", l)
        };
    return r.$$set = l => {
        "searchList" in l && n(0, i = l.searchList)
    }, [i, t, a, s, o]
}
class vn extends ae {
    constructor(e) {
        super(), le(this, e, kt, ft, ie, {
            searchList: 0
        })
    }
}

function _n({
    query: r,
    options: e
}) {
    const n = new Ie(""),
        t = new Ie(!1);
    let i = "";
    const a = t.pipe(Gn()),
        s = n.pipe(Ln(l => l.length >= ((e == null ? void 0 : e.minSearchCharacters) ? ? 0)), Ce(l => {
            i = l, t.next(!0)
        }), Bn(275), Pn(l => On({ ...r(l),
            load: {
                fetch,
                data: De(Ee).data,
                parent: async () => De(Ee).data
            }
        }).pipe(Rn(d => An({
            errors: [{
                message: d.message
            }],
            data: null
        })), Ce(d => {
            l === i && (d.errors && (e != null && e.onError) ? e.onError(d.errors) : d.data && (e != null && e.onSuccess) && (e == null || e.onSuccess(d.data)), t.next(!1))
        }))));
    return {
        query: In([Ve(s), Ve(a)], ([l, d]) => ({
            loading: d,
            ...l
        })),
        input$: n,
        loading$: t
    }
}
const ye = 3;

function qe(r, e, n) {
    const t = r.slice();
    return t[11] = e[n], t
}

function pt(r) {
    let e, n, t;
    return n = new Y({
        props: {
            variant: "subtle",
            align: "center",
            weight: "semibold",
            $$slots: {
                default: [_t]
            },
            $$scope: {
                ctx: r
            }
        }
    }), {
        c() {
            e = V("div"), $(n.$$.fragment), this.h()
        },
        l(i) {
            e = C(i, "DIV", {
                class: !0
            });
            var a = O(e);
            N(n.$$.fragment, a), a.forEach(k), this.h()
        },
        h() {
            w(e, "class", "exception-wrap svelte-4te59m")
        },
        m(i, a) {
            h(i, e, a), F(n, e, null), t = !0
        },
        p(i, a) {
            const s = {};
            a & 16392 && (s.$$scope = {
                dirty: a,
                ctx: i
            }), n.$set(s)
        },
        i(i) {
            t || (_(n.$$.fragment, i), t = !0)
        },
        o(i) {
            S(n.$$.fragment, i), t = !1
        },
        d(i) {
            i && k(e), b(n)
        }
    }
}

function vt(r) {
    let e, n, t;
    return n = new Y({
        props: {
            variant: "subtle",
            align: "center",
            weight: "semibold",
            $$slots: {
                default: [St]
            },
            $$scope: {
                ctx: r
            }
        }
    }), {
        c() {
            e = V("div"), $(n.$$.fragment), this.h()
        },
        l(i) {
            e = C(i, "DIV", {
                class: !0
            });
            var a = O(e);
            N(n.$$.fragment, a), a.forEach(k), this.h()
        },
        h() {
            w(e, "class", "exception-wrap svelte-4te59m")
        },
        m(i, a) {
            h(i, e, a), F(n, e, null), t = !0
        },
        p(i, a) {
            const s = {};
            a & 16392 && (s.$$scope = {
                dirty: a,
                ctx: i
            }), n.$set(s)
        },
        i(i) {
            t || (_(n.$$.fragment, i), t = !0)
        },
        o(i) {
            S(n.$$.fragment, i), t = !1
        },
        d(i) {
            i && k(e), b(n)
        }
    }
}

function _t(r) {
    let e = r[3]._(B.noResults) + "",
        n;
    return {
        c() {
            n = G(e)
        },
        l(t) {
            n = L(t, e)
        },
        m(t, i) {
            h(t, n, i)
        },
        p(t, i) {
            i & 8 && e !== (e = t[3]._(B.noResults) + "") && P(n, e)
        },
        d(t) {
            t && k(n)
        }
    }
}

function St(r) {
    let e = r[3]._(B.minimumCharacters) + "",
        n;
    return {
        c() {
            n = G(e)
        },
        l(t) {
            n = L(t, e)
        },
        m(t, i) {
            h(t, n, i)
        },
        p(t, i) {
            i & 8 && e !== (e = t[3]._(B.minimumCharacters) + "") && P(n, e)
        },
        d(t) {
            t && k(n)
        }
    }
}

function Ge(r) {
    let e, n, t, i;
    n = new Y({
        props: {
            size: "lg",
            variant: "danger",
            align: "center",
            weight: "semibold",
            $$slots: {
                default: [ht]
            },
            $$scope: {
                ctx: r
            }
        }
    });
    let a = Z(r[1].errors ? ? []),
        s = [];
    for (let l = 0; l < a.length; l += 1) s[l] = Le(qe(r, a, l));
    const o = l => S(s[l], 1, 1, () => {
        s[l] = null
    });
    return {
        c() {
            e = V("div"), $(n.$$.fragment), t = D();
            for (let l = 0; l < s.length; l += 1) s[l].c();
            this.h()
        },
        l(l) {
            e = C(l, "DIV", {
                class: !0
            });
            var d = O(e);
            N(n.$$.fragment, d), t = E(d);
            for (let u = 0; u < s.length; u += 1) s[u].l(d);
            d.forEach(k), this.h()
        },
        h() {
            w(e, "class", "exception-wrap svelte-4te59m")
        },
        m(l, d) {
            h(l, e, d), F(n, e, null), A(e, t);
            for (let u = 0; u < s.length; u += 1) s[u] && s[u].m(e, null);
            i = !0
        },
        p(l, d) {
            const u = {};
            if (d & 16392 && (u.$$scope = {
                    dirty: d,
                    ctx: l
                }), n.$set(u), d & 2) {
                a = Z(l[1].errors ? ? []);
                let c;
                for (c = 0; c < a.length; c += 1) {
                    const f = qe(l, a, c);
                    s[c] ? (s[c].p(f, d), _(s[c], 1)) : (s[c] = Le(f), s[c].c(), _(s[c], 1), s[c].m(e, null))
                }
                for (W(), c = a.length; c < s.length; c += 1) o(c);
                K()
            }
        },
        i(l) {
            if (!i) {
                _(n.$$.fragment, l);
                for (let d = 0; d < a.length; d += 1) _(s[d]);
                i = !0
            }
        },
        o(l) {
            S(n.$$.fragment, l), s = s.filter(Boolean);
            for (let d = 0; d < s.length; d += 1) S(s[d]);
            i = !1
        },
        d(l) {
            l && k(e), b(n), ke(s, l)
        }
    }
}

function ht(r) {
    let e = r[3]._(B.searchError) + "",
        n;
    return {
        c() {
            n = G(e)
        },
        l(t) {
            n = L(t, e)
        },
        m(t, i) {
            h(t, n, i)
        },
        p(t, i) {
            i & 8 && e !== (e = t[3]._(B.searchError) + "") && P(n, e)
        },
        d(t) {
            t && k(n)
        }
    }
}

function gt(r) {
    let e = r[11].message + "",
        n, t;
    return {
        c() {
            n = G(e), t = D()
        },
        l(i) {
            n = L(i, e), t = E(i)
        },
        m(i, a) {
            h(i, n, a), h(i, t, a)
        },
        p(i, a) {
            a & 2 && e !== (e = i[11].message + "") && P(n, e)
        },
        d(i) {
            i && (k(n), k(t))
        }
    }
}

function Le(r) {
    let e, n;
    return e = new Y({
        props: {
            variant: "subtle",
            align: "center",
            $$slots: {
                default: [gt]
            },
            $$scope: {
                ctx: r
            }
        }
    }), {
        c() {
            $(e.$$.fragment)
        },
        l(t) {
            N(e.$$.fragment, t)
        },
        m(t, i) {
            F(e, t, i), n = !0
        },
        p(t, i) {
            const a = {};
            i & 16386 && (a.$$scope = {
                dirty: i,
                ctx: t
            }), e.$set(a)
        },
        i(t) {
            n || (_(e.$$.fragment, t), n = !0)
        },
        o(t) {
            S(e.$$.fragment, t), n = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function Be(r) {
    let e, n, t, i, a, s, o, l;
    return t = new Y({
        props: {
            variant: "subtle",
            weight: "bold",
            $$slots: {
                default: [$t]
            },
            $$scope: {
                ctx: r
            }
        }
    }), a = new ne({
        props: {
            variant: "subtle-link",
            $$slots: {
                default: [Nt]
            },
            $$scope: {
                ctx: r
            }
        }
    }), a.$on("click", r[7]), o = new vn({
        props: {
            searchList: r[4]
        }
    }), o.$on("select", r[8]), o.$on("remove", r[9]), {
        c() {
            e = V("div"), n = V("div"), $(t.$$.fragment), i = D(), $(a.$$.fragment), s = D(), $(o.$$.fragment), this.h()
        },
        l(d) {
            e = C(d, "DIV", {
                class: !0
            });
            var u = O(e);
            n = C(u, "DIV", {
                class: !0
            });
            var c = O(n);
            N(t.$$.fragment, c), i = E(c), N(a.$$.fragment, c), c.forEach(k), s = E(u), N(o.$$.fragment, u), u.forEach(k), this.h()
        },
        h() {
            w(n, "class", "content-header svelte-4te59m"), w(e, "class", "content svelte-4te59m")
        },
        m(d, u) {
            h(d, e, u), A(e, n), F(t, n, null), A(n, i), F(a, n, null), A(e, s), F(o, e, null), l = !0
        },
        p(d, u) {
            const c = {};
            u & 16392 && (c.$$scope = {
                dirty: u,
                ctx: d
            }), t.$set(c);
            const f = {};
            u & 16408 && (f.$$scope = {
                dirty: u,
                ctx: d
            }), a.$set(f);
            const p = {};
            u & 16 && (p.searchList = d[4]), o.$set(p)
        },
        i(d) {
            l || (_(t.$$.fragment, d), _(a.$$.fragment, d), _(o.$$.fragment, d), l = !0)
        },
        o(d) {
            S(t.$$.fragment, d), S(a.$$.fragment, d), S(o.$$.fragment, d), l = !1
        },
        d(d) {
            d && k(e), b(t), b(a), b(o)
        }
    }
}

function $t(r) {
    let e = r[3]._(B.recentSearches) + "",
        n;
    return {
        c() {
            n = G(e)
        },
        l(t) {
            n = L(t, e)
        },
        m(t, i) {
            h(t, n, i)
        },
        p(t, i) {
            i & 8 && e !== (e = t[3]._(B.recentSearches) + "") && P(n, e)
        },
        d(t) {
            t && k(n)
        }
    }
}

function Nt(r) {
    let e = r[3]._(B.clearSearch) + "",
        n, t, i = r[4].length + "",
        a, s;
    return {
        c() {
            n = G(e), t = G(" ("), a = G(i), s = G(")")
        },
        l(o) {
            n = L(o, e), t = L(o, " ("), a = L(o, i), s = L(o, ")")
        },
        m(o, l) {
            h(o, n, l), h(o, t, l), h(o, a, l), h(o, s, l)
        },
        p(o, l) {
            l & 8 && e !== (e = o[3]._(B.clearSearch) + "") && P(n, e), l & 16 && i !== (i = o[4].length + "") && P(a, i)
        },
        d(o) {
            o && (k(n), k(t), k(a), k(s))
        }
    }
}

function Ft(r) {
    var i;
    let e, n, t;
    return n = new fn({
        props: {
            list: ((i = r[0]) == null ? void 0 : i.kuratorGameQuery) ? ? []
        }
    }), {
        c() {
            e = V("div"), $(n.$$.fragment), this.h()
        },
        l(a) {
            e = C(a, "DIV", {
                class: !0
            });
            var s = O(e);
            N(n.$$.fragment, s), s.forEach(k), this.h()
        },
        h() {
            w(e, "class", "content svelte-4te59m")
        },
        m(a, s) {
            h(a, e, s), F(n, e, null), t = !0
        },
        p(a, s) {
            var l;
            const o = {};
            s & 1 && (o.list = ((l = a[0]) == null ? void 0 : l.kuratorGameQuery) ? ? []), n.$set(o)
        },
        i(a) {
            t || (_(n.$$.fragment, a), t = !0)
        },
        o(a) {
            S(n.$$.fragment, a), t = !1
        },
        d(a) {
            a && k(e), b(n)
        }
    }
}

function bt(r) {
    let e, n, t;
    return n = new fn({
        props: {
            loading: !0,
            list: [{
                id: "loading_1"
            }, {
                id: "loading_2"
            }, {
                id: "loading_3"
            }, {
                id: "loading_4"
            }, {
                id: "loading_5"
            }]
        }
    }), {
        c() {
            e = V("div"), $(n.$$.fragment), this.h()
        },
        l(i) {
            e = C(i, "DIV", {
                class: !0
            });
            var a = O(e);
            N(n.$$.fragment, a), a.forEach(k), this.h()
        },
        h() {
            w(e, "class", "content svelte-4te59m")
        },
        m(i, a) {
            h(i, e, a), F(n, e, null), t = !0
        },
        p: ee,
        i(i) {
            t || (_(n.$$.fragment, i), t = !0)
        },
        o(i) {
            S(n.$$.fragment, i), t = !1
        },
        d(i) {
            i && k(e), b(n)
        }
    }
}

function yt(r) {
    let e, n, t, i, a, s, o, l, d;
    const u = [vt, pt],
        c = [];

    function f(m, g) {
        return m[2] === "characterLimit" ? 0 : m[2] === "empty" ? 1 : -1
    }~(e = f(r)) && (n = c[e] = u[e](r));
    let p = r[2] === "error" && Ge(r),
        v = (r[2] === "characterLimit" || r[2] === "empty") && r[4].length && Be(r);
    const T = [bt, Ft],
        R = [];

    function X(m, g) {
        return m[2] === "loading" ? 0 : m[2] === "success" ? 1 : -1
    }
    return ~(s = X(r)) && (o = R[s] = T[s](r)), {
        c() {
            n && n.c(), t = D(), p && p.c(), i = D(), v && v.c(), a = D(), o && o.c(), l = H()
        },
        l(m) {
            n && n.l(m), t = E(m), p && p.l(m), i = E(m), v && v.l(m), a = E(m), o && o.l(m), l = H()
        },
        m(m, g) {
            ~e && c[e].m(m, g), h(m, t, g), p && p.m(m, g), h(m, i, g), v && v.m(m, g), h(m, a, g), ~s && R[s].m(m, g), h(m, l, g), d = !0
        },
        p(m, [g]) {
            let U = e;
            e = f(m), e === U ? ~e && c[e].p(m, g) : (n && (W(), S(c[U], 1, 1, () => {
                c[U] = null
            }), K()), ~e ? (n = c[e], n ? n.p(m, g) : (n = c[e] = u[e](m), n.c()), _(n, 1), n.m(t.parentNode, t)) : n = null), m[2] === "error" ? p ? (p.p(m, g), g & 4 && _(p, 1)) : (p = Ge(m), p.c(), _(p, 1), p.m(i.parentNode, i)) : p && (W(), S(p, 1, 1, () => {
                p = null
            }), K()), (m[2] === "characterLimit" || m[2] === "empty") && m[4].length ? v ? (v.p(m, g), g & 20 && _(v, 1)) : (v = Be(m), v.c(), _(v, 1), v.m(a.parentNode, a)) : v && (W(), S(v, 1, 1, () => {
                v = null
            }), K());
            let I = s;
            s = X(m), s === I ? ~s && R[s].p(m, g) : (o && (W(), S(R[I], 1, 1, () => {
                R[I] = null
            }), K()), ~s ? (o = R[s], o ? o.p(m, g) : (o = R[s] = T[s](m), o.c()), _(o, 1), o.m(l.parentNode, l)) : o = null)
        },
        i(m) {
            d || (_(n), _(p), _(v), _(o), d = !0)
        },
        o(m) {
            S(n), S(p), S(v), S(o), d = !1
        },
        d(m) {
            m && (k(t), k(i), k(a), k(l)), ~e && c[e].d(m), p && p.d(m), v && v.d(m), ~s && R[s].d(m)
        }
    }
}

function wt(r, e, n) {
    let t, i, a, s, o;
    J(r, be, v => n(3, s = v)), J(r, pe, v => n(4, o = v));
    let {
        query: l
    } = e;
    const {
        input$: d,
        query: u
    } = _n({
        query: v => ({
            doc: Cn,
            variables: {
                query: v
            }
        }),
        options: {
            minSearchCharacters: 3,
            onSuccess: v => {
                var T;
                ((T = v.kuratorGameQuery) == null ? void 0 : T.length) !== 0 && pe.save(l)
            }
        }
    });
    J(r, u, v => n(1, a = v));
    const c = () => pe.removeAll();

    function f(v) {
        fe.call(this, r, v)
    }
    const p = v => pe.remove(v.detail);
    return r.$$set = v => {
        "query" in v && n(6, l = v.query)
    }, r.$$.update = () => {
        var v;
        r.$$.dirty & 64 && d.next(l), r.$$.dirty & 2 && n(0, t = a.data), r.$$.dirty & 67 && n(2, i = l.length < ye ? "characterLimit" : a.loading ? "loading" : ((v = t == null ? void 0 : t.kuratorGameQuery) == null ? void 0 : v.length) === 0 ? "empty" : a.errors ? "error" : "success")
    }, [t, a, i, s, o, u, l, c, f, p]
}
class Tt extends ae {
    constructor(e) {
        super(), le(this, e, wt, yt, ie, {
            query: 6
        })
    }
}
const Dt = {
    kind: "Document",
    definitions: [{
        kind: "OperationDefinition",
        operation: "query",
        name: {
            kind: "Name",
            value: "SportsSearchResults_SportFixture"
        },
        variableDefinitions: [{
            kind: "VariableDefinition",
            variable: {
                kind: "Variable",
                name: {
                    kind: "Name",
                    value: "query"
                }
            },
            type: {
                kind: "NonNullType",
                type: {
                    kind: "NamedType",
                    name: {
                        kind: "Name",
                        value: "String"
                    }
                }
            }
        }, {
            kind: "VariableDefinition",
            variable: {
                kind: "Variable",
                name: {
                    kind: "Name",
                    value: "groups"
                }
            },
            type: {
                kind: "NonNullType",
                type: {
                    kind: "NamedType",
                    name: {
                        kind: "Name",
                        value: "String"
                    }
                }
            }
        }, {
            kind: "VariableDefinition",
            variable: {
                kind: "Variable",
                name: {
                    kind: "Name",
                    value: "templateLimit"
                }
            },
            type: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "Int"
                }
            },
            defaultValue: {
                kind: "IntValue",
                value: "0"
            }
        }, {
            kind: "VariableDefinition",
            variable: {
                kind: "Variable",
                name: {
                    kind: "Name",
                    value: "marketLimit"
                }
            },
            type: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "Int"
                }
            },
            defaultValue: {
                kind: "IntValue",
                value: "0"
            }
        }, {
            kind: "VariableDefinition",
            variable: {
                kind: "Variable",
                name: {
                    kind: "Name",
                    value: "includeEmpty"
                }
            },
            type: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "Boolean"
                }
            },
            defaultValue: {
                kind: "BooleanValue",
                value: !1
            }
        }],
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "sportFixtureQuery"
                },
                arguments: [{
                    kind: "Argument",
                    name: {
                        kind: "Name",
                        value: "query"
                    },
                    value: {
                        kind: "Variable",
                        name: {
                            kind: "Name",
                            value: "query"
                        }
                    }
                }],
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "fixture"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "InlineFragment",
                                typeCondition: {
                                    kind: "NamedType",
                                    name: {
                                        kind: "Name",
                                        value: "SportFixture"
                                    }
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "__typename"
                                        }
                                    }, {
                                        kind: "FragmentSpread",
                                        name: {
                                            kind: "Name",
                                            value: "FixtureList_SportFixture"
                                        }
                                    }]
                                }
                            }, {
                                kind: "InlineFragment",
                                typeCondition: {
                                    kind: "NamedType",
                                    name: {
                                        kind: "Name",
                                        value: "RacingEvent"
                                    }
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "FragmentSpread",
                                        name: {
                                            kind: "Name",
                                            value: "RacingResultTemplate_RacingEvent"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "SportFixtureDataOutright_SportFixture"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixture"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "provider"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "marketCount"
                },
                arguments: [{
                    kind: "Argument",
                    name: {
                        kind: "Name",
                        value: "status"
                    },
                    value: {
                        kind: "ListValue",
                        values: [{
                            kind: "EnumValue",
                            value: "active"
                        }, {
                            kind: "EnumValue",
                            value: "suspended"
                        }]
                    }
                }]
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "data"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportCricketScore"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "name"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureDataOutright"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "name"
                                }
                            }]
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "tournament"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "id"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "slug"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "name"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "category"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "id"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "slug"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "name"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "sport"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "id"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "slug"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "FixtureMatchScore_SportFixture"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixture"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "status"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "tournament"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "category"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "sport"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "slug"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "eventStatus"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureEventStatusData"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "homeScore"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "awayScore"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "periodScores"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "homeScore"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "awayScore"
                                        }
                                    }]
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "EsportFixtureEventStatus"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "homeScore"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "awayScore"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "periodScores"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "homeScore"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "awayScore"
                                        }
                                    }]
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "scoreboard"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "homeKills"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "homeWonRounds"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "awayKills"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "awayWonRounds"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "FixtureOptionsOddin_SportFixture"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixture"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "extId"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "provider"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "status"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "widgetUrl"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "liveWidgetUrl"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "imgArenaStream"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "exists"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "geniussportsStream"
                },
                arguments: [{
                    kind: "Argument",
                    name: {
                        kind: "Name",
                        value: "deliveryType"
                    },
                    value: {
                        kind: "EnumValue",
                        value: "hls"
                    }
                }],
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "exists"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "betradarStream"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "exists"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "tournament"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "slug"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "frontRowSeatEvent"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "identifier"
                                }
                            }]
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "category"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "slug"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "sport"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "slug"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "data"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureDataMatch"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "competitors"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "abbreviation"
                                        }
                                    }]
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "tvChannels"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "streamUrl"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "language"
                                        }
                                    }]
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "startTime"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureDataOutright"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "name"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "startTime"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportCricketScore"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "competitors"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "abbreviation"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "FixtureOptionsBetRadar_SportFixture"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixture"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "extId"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "provider"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "status"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "widgetUrl"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "liveWidgetUrl"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "imgArenaStream"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "exists"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "geniussportsStream"
                },
                arguments: [{
                    kind: "Argument",
                    name: {
                        kind: "Name",
                        value: "deliveryType"
                    },
                    value: {
                        kind: "EnumValue",
                        value: "hls"
                    }
                }],
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "exists"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "betradarStream"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "exists"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "frontRowSeatFight"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "fightId"
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "tournament"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "slug"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "frontRowSeatEvent"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "identifier"
                                }
                            }]
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "category"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "slug"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "sport"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "slug"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "data"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureDataMatch"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "competitors"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "abbreviation"
                                        }
                                    }]
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "tvChannels"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "streamUrl"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "language"
                                        }
                                    }]
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "startTime"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureDataOutright"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "name"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "startTime"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportCricketScore"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "competitors"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "abbreviation"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "FixtureOptions_SportFixture"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixture"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "FixtureOptionsOddin_SportFixture"
                }
            }, {
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "FixtureOptionsBetRadar_SportFixture"
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "FixtureScore_SportFixture"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixture"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "provider"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "eventStatus"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureEventStatusData"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "homeScore"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "awayScore"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "periodScores"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "homeScore"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "awayScore"
                                        }
                                    }]
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "EsportFixtureEventStatus"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "homeScore"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "awayScore"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "periodScores"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "homeScore"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "awayScore"
                                        }
                                    }]
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "scoreboard"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "homeKills"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "homeWonRounds"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "awayKills"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "awayWonRounds"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "tournament"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "category"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "sport"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "slug"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "Live_SportFixture"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixture"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "FixtureScore_SportFixture"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "provider"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "eventStatus"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureEventStatusData"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "matchStatus"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "periodScores"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "matchStatus"
                                        }
                                    }]
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "clock"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "matchTime"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "remainingTime"
                                        }
                                    }]
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "EsportFixtureEventStatus"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "matchStatus"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "periodScores"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "matchStatus"
                                        }
                                    }]
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "scoreboard"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "gameTime"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "remainingGameTime"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "tournament"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "category"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "sport"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "slug"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "Active_SportFixture"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixture"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "data"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureDataOutright"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "endTime"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureDataMatch"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "startTime"
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "FixtureStatus_SportFixture"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixture"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "status"
                }
            }, {
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "FixtureOptions_SportFixture"
                }
            }, {
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "Live_SportFixture"
                }
            }, {
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "Active_SportFixture"
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "Frame_SportFixture"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixture"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "FixtureMatchScore_SportFixture"
                }
            }, {
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "FixtureOptionsOddin_SportFixture"
                }
            }, {
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "FixtureOptionsBetRadar_SportFixture"
                }
            }, {
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "FixtureStatus_SportFixture"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "name"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "slug"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "eventStatus"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureEventStatusData"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "currentTeamServing"
                                }
                            }]
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "marketCount"
                },
                arguments: [{
                    kind: "Argument",
                    name: {
                        kind: "Name",
                        value: "status"
                    },
                    value: {
                        kind: "ListValue",
                        values: [{
                            kind: "EnumValue",
                            value: "active"
                        }, {
                            kind: "EnumValue",
                            value: "suspended"
                        }]
                    }
                }]
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "data"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureDataMatch"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "competitors"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "tournament"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "id"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "name"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "slug"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "category"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "id"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "name"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "slug"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "sport"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "id"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "slug"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "SportBetOutcome_SportFixture"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixture"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "status"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "provider"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "data"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportCricketScore"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "competitors"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }]
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureDataMatch"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "competitors"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "abbreviation"
                                        }
                                    }]
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "startTime"
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureDataOutright"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "name"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "startTime"
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "Market_SportFixture"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixture"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "SportBetOutcome_SportFixture"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "status"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "data"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureDataMatch"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "teams"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "qualifier"
                                        }
                                    }]
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "competitors"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }, {
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "abbreviation"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "Preview_SportFixture"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixture"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "Frame_SportFixture"
                }
            }, {
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "Market_SportFixture"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "provider"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "status"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "slug"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "marketCount"
                },
                arguments: [{
                    kind: "Argument",
                    name: {
                        kind: "Name",
                        value: "status"
                    },
                    value: {
                        kind: "ListValue",
                        values: [{
                            kind: "EnumValue",
                            value: "active"
                        }, {
                            kind: "EnumValue",
                            value: "suspended"
                        }]
                    }
                }]
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "tournament"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "slug"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "category"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "slug"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "sport"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "slug"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "data"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportCricketScore"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "competitors"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }]
                                }
                            }]
                        }
                    }, {
                        kind: "InlineFragment",
                        typeCondition: {
                            kind: "NamedType",
                            name: {
                                kind: "Name",
                                value: "SportFixtureDataMatch"
                            }
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "competitors"
                                },
                                selectionSet: {
                                    kind: "SelectionSet",
                                    selections: [{
                                        kind: "Field",
                                        name: {
                                            kind: "Name",
                                            value: "name"
                                        }
                                    }]
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "SportBetOutcome_SportMarket"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportMarket"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "extId"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "name"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "status"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "specifiers"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "customBetAvailable"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "provider"
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "SportBetOutcome_SportMarketOutcome"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportMarketOutcome"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "active"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "odds"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "name"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "customBetAvailable"
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "Market_SportMarket"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportMarket"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "SportBetOutcome_SportMarket"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "name"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "status"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "extId"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "specifiers"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "customBetAvailable"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "provider"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "outcomes"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "FragmentSpread",
                        name: {
                            kind: "Name",
                            value: "SportBetOutcome_SportMarketOutcome"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "active"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "id"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "odds"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "name"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "customBetAvailable"
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "Preview_SportGroupTemplate"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportGroupTemplate"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "extId"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "name"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "markets"
                },
                arguments: [{
                    kind: "Argument",
                    name: {
                        kind: "Name",
                        value: "limit"
                    },
                    value: {
                        kind: "Variable",
                        name: {
                            kind: "Name",
                            value: "marketLimit"
                        }
                    }
                }],
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "FragmentSpread",
                        name: {
                            kind: "Name",
                            value: "Market_SportMarket"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "specifiers"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "status"
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "SportFixtureDataMatch_SportFixture"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixture"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "Preview_SportFixture"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "groups"
                },
                arguments: [{
                    kind: "Argument",
                    name: {
                        kind: "Name",
                        value: "groups"
                    },
                    value: {
                        kind: "ListValue",
                        values: [{
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "groups"
                            }
                        }]
                    }
                }, {
                    kind: "Argument",
                    name: {
                        kind: "Name",
                        value: "status"
                    },
                    value: {
                        kind: "ListValue",
                        values: [{
                            kind: "EnumValue",
                            value: "active"
                        }, {
                            kind: "EnumValue",
                            value: "suspended"
                        }, {
                            kind: "EnumValue",
                            value: "deactivated"
                        }]
                    }
                }],
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "templates"
                        },
                        arguments: [{
                            kind: "Argument",
                            name: {
                                kind: "Name",
                                value: "limit"
                            },
                            value: {
                                kind: "Variable",
                                name: {
                                    kind: "Name",
                                    value: "templateLimit"
                                }
                            }
                        }, {
                            kind: "Argument",
                            name: {
                                kind: "Name",
                                value: "includeEmpty"
                            },
                            value: {
                                kind: "Variable",
                                name: {
                                    kind: "Name",
                                    value: "includeEmpty"
                                }
                            }
                        }],
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "FragmentSpread",
                                name: {
                                    kind: "Name",
                                    value: "Preview_SportGroupTemplate"
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "FixtureList_SportFixture"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "SportFixture"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "SportFixtureDataOutright_SportFixture"
                }
            }, {
                kind: "FragmentSpread",
                name: {
                    kind: "Name",
                    value: "SportFixtureDataMatch_SportFixture"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "data"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "__typename"
                        }
                    }]
                }
            }]
        }
    }, {
        kind: "FragmentDefinition",
        name: {
            kind: "Name",
            value: "RacingResultTemplate_RacingEvent"
        },
        typeCondition: {
            kind: "NamedType",
            name: {
                kind: "Name",
                value: "RacingEvent"
            }
        },
        selectionSet: {
            kind: "SelectionSet",
            selections: [{
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "__typename"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "id"
                }
            }, {
                kind: "Field",
                alias: {
                    kind: "Name",
                    value: "racingSlug"
                },
                name: {
                    kind: "Name",
                    value: "slug"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "name"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "startTime"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "eventNumber"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "distance"
                }
            }, {
                kind: "Field",
                alias: {
                    kind: "Name",
                    value: "racingStatus"
                },
                name: {
                    kind: "Name",
                    value: "status"
                }
            }, {
                kind: "Field",
                name: {
                    kind: "Name",
                    value: "meeting"
                },
                selectionSet: {
                    kind: "SelectionSet",
                    selections: [{
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "slug"
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "venue"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "name"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "geoBlocked"
                                }
                            }]
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "racingGroup"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "slug"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "name"
                                }
                            }]
                        }
                    }, {
                        kind: "Field",
                        name: {
                            kind: "Name",
                            value: "racing"
                        },
                        selectionSet: {
                            kind: "SelectionSet",
                            selections: [{
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "slug"
                                }
                            }, {
                                kind: "Field",
                                name: {
                                    kind: "Name",
                                    value: "name"
                                }
                            }]
                        }
                    }]
                }
            }]
        }
    }]
};

function Pe(r, e, n) {
    const t = r.slice();
    return t[5] = e[n], t
}

function Et(r) {
    let e = r[5].name + "",
        n;
    return {
        c() {
            n = G(e)
        },
        l(t) {
            n = L(t, e)
        },
        m(t, i) {
            h(t, n, i)
        },
        p(t, i) {
            i & 1 && e !== (e = t[5].name + "") && P(n, e)
        },
        d(t) {
            t && k(n)
        }
    }
}

function Vt(r) {
    let e, n = r[8] + "",
        t;
    return {
        c() {
            e = V("span"), t = G(n), this.h()
        },
        l(i) {
            e = C(i, "SPAN", {
                class: !0
            });
            var a = O(e);
            t = L(a, n), a.forEach(k), this.h()
        },
        h() {
            w(e, "class", "text-white font-semibold text-xs")
        },
        m(i, a) {
            h(i, e, a), A(e, t)
        },
        p(i, a) {
            a & 256 && n !== (n = i[8] + "") && P(t, n)
        },
        i: ee,
        o: ee,
        d(i) {
            i && k(e)
        }
    }
}

function Ct(r) {
    let e, n;
    return e = new Hn({
        props: {
            $$slots: {
                default: [It]
            },
            $$scope: {
                ctx: r
            }
        }
    }), {
        c() {
            $(e.$$.fragment)
        },
        l(t) {
            N(e.$$.fragment, t)
        },
        m(t, i) {
            F(e, t, i), n = !0
        },
        p(t, i) {
            const a = {};
            i & 1280 && (a.$$scope = {
                dirty: i,
                ctx: t
            }), e.$set(a)
        },
        i(t) {
            n || (_(e.$$.fragment, t), n = !0)
        },
        o(t) {
            S(e.$$.fragment, t), n = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function It(r) {
    let e, n = r[8] + "",
        t;
    return {
        c() {
            e = V("span"), t = G(n), this.h()
        },
        l(i) {
            e = C(i, "SPAN", {
                class: !0
            });
            var a = O(e);
            t = L(a, n), a.forEach(k), this.h()
        },
        h() {
            w(e, "class", "text-white font-semibold text-xs")
        },
        m(i, a) {
            h(i, e, a), A(e, t)
        },
        p(i, a) {
            a & 256 && n !== (n = i[8] + "") && P(t, n)
        },
        d(i) {
            i && k(e)
        }
    }
}

function Ot(r) {
    let e, n, t, i;
    const a = [Ct, Vt],
        s = [];

    function o(l, d) {
        return l[9] === "live" ? 0 : 1
    }
    return e = o(r), n = s[e] = a[e](r), {
        c() {
            n.c(), t = H()
        },
        l(l) {
            n.l(l), t = H()
        },
        m(l, d) {
            s[e].m(l, d), h(l, t, d), i = !0
        },
        p(l, d) {
            let u = e;
            e = o(l), e === u ? s[e].p(l, d) : (W(), S(s[u], 1, 1, () => {
                s[u] = null
            }), K(), n = s[e], n ? n.p(l, d) : (n = s[e] = a[e](l), n.c()), _(n, 1), n.m(t.parentNode, t))
        },
        i(l) {
            i || (_(n), i = !0)
        },
        o(l) {
            S(n), i = !1
        },
        d(l) {
            l && k(t), s[e].d(l)
        }
    }
}

function Rt(r) {
    let e = r[1].format(new Date(r[5].startTime)) + "",
        n;
    return {
        c() {
            n = G(e)
        },
        l(t) {
            n = L(t, e)
        },
        m(t, i) {
            h(t, n, i)
        },
        p(t, i) {
            i & 1 && e !== (e = t[1].format(new Date(t[5].startTime)) + "") && P(n, e)
        },
        d(t) {
            t && k(n)
        }
    }
}

function At(r) {
    let e = `R${r[5].eventNumber}`,
        n;
    return {
        c() {
            n = G(e)
        },
        l(t) {
            n = L(t, e)
        },
        m(t, i) {
            h(t, n, i)
        },
        p(t, i) {
            i & 1 && e !== (e = `R${t[5].eventNumber}`) && P(n, e)
        },
        d(t) {
            t && k(n)
        }
    }
}

function Mt(r) {
    let e = r[5].distance + "",
        n;
    return {
        c() {
            n = G(e)
        },
        l(t) {
            n = L(t, e)
        },
        m(t, i) {
            h(t, n, i)
        },
        p(t, i) {
            i & 1 && e !== (e = t[5].distance + "") && P(n, e)
        },
        d(t) {
            t && k(n)
        }
    }
}

function ze(r, e) {
    let n, t, i, a, s, o, l, d, u, c, f, p, v, T, R, X, m, g, U;
    return t = new Un({
        props: {
            variant: "link",
            to: e[2](e[5]),
            $$slots: {
                default: [Et]
            },
            $$scope: {
                ctx: e
            }
        }
    }), s = new jn({
        props: {
            startTime: e[5].startTime,
            $$slots: {
                default: [Ot, ({
                    countdown: I,
                    countdownState: q
                }) => ({
                    8: I,
                    9: q
                }), ({
                    countdown: I,
                    countdownState: q
                }) => (I ? 256 : 0) | (q ? 512 : 0)]
            },
            $$scope: {
                ctx: e
            }
        }
    }), l = new Y({
        props: {
            size: "sm",
            $$slots: {
                default: [Rt]
            },
            $$scope: {
                ctx: e
            }
        }
    }), f = new Y({
        props: {
            size: "sm",
            $$slots: {
                default: [At]
            },
            $$scope: {
                ctx: e
            }
        }
    }), R = new Y({
        props: {
            size: "sm",
            $$slots: {
                default: [Mt]
            },
            $$scope: {
                ctx: e
            }
        }
    }), m = new zn({
        props: {
            list: Qe(e[5]),
            mobileView: !1,
            sportType: "racing"
        }
    }), {
        key: r,
        first: null,
        c() {
            n = V("div"), $(t.$$.fragment), i = D(), a = V("div"), $(s.$$.fragment), o = D(), $(l.$$.fragment), d = D(), u = V("div"), c = D(), $(f.$$.fragment), p = D(), v = V("div"), T = D(), $(R.$$.fragment), X = D(), $(m.$$.fragment), g = D(), this.h()
        },
        l(I) {
            n = C(I, "DIV", {
                class: !0
            });
            var q = O(n);
            N(t.$$.fragment, q), i = E(q), a = C(q, "DIV", {
                class: !0
            });
            var z = O(a);
            N(s.$$.fragment, z), o = E(z), N(l.$$.fragment, z), d = E(z), u = C(z, "DIV", {
                class: !0
            }), O(u).forEach(k), c = E(z), N(f.$$.fragment, z), p = E(z), v = C(z, "DIV", {
                class: !0
            }), O(v).forEach(k), T = E(z), N(R.$$.fragment, z), z.forEach(k), X = E(q), N(m.$$.fragment, q), g = E(q), q.forEach(k), this.h()
        },
        h() {
            w(u, "class", "dot svelte-1qox5eg"), w(v, "class", "dot svelte-1qox5eg"), w(a, "class", "result-details svelte-1qox5eg"), w(n, "class", "racing-result-template svelte-1qox5eg"), this.first = n
        },
        m(I, q) {
            h(I, n, q), F(t, n, null), A(n, i), A(n, a), F(s, a, null), A(a, o), F(l, a, null), A(a, d), A(a, u), A(a, c), F(f, a, null), A(a, p), A(a, v), A(a, T), F(R, a, null), A(n, X), F(m, n, null), A(n, g), U = !0
        },
        p(I, q) {
            e = I;
            const z = {};
            q & 1 && (z.to = e[2](e[5])), q & 1025 && (z.$$scope = {
                dirty: q,
                ctx: e
            }), t.$set(z);
            const re = {};
            q & 1 && (re.startTime = e[5].startTime), q & 1792 && (re.$$scope = {
                dirty: q,
                ctx: e
            }), s.$set(re);
            const de = {};
            q & 1025 && (de.$$scope = {
                dirty: q,
                ctx: e
            }), l.$set(de);
            const se = {};
            q & 1025 && (se.$$scope = {
                dirty: q,
                ctx: e
            }), f.$set(se);
            const oe = {};
            q & 1025 && (oe.$$scope = {
                dirty: q,
                ctx: e
            }), R.$set(oe);
            const M = {};
            q & 1 && (M.list = Qe(e[5])), m.$set(M)
        },
        i(I) {
            U || (_(t.$$.fragment, I), _(s.$$.fragment, I), _(l.$$.fragment, I), _(f.$$.fragment, I), _(R.$$.fragment, I), _(m.$$.fragment, I), U = !0)
        },
        o(I) {
            S(t.$$.fragment, I), S(s.$$.fragment, I), S(l.$$.fragment, I), S(f.$$.fragment, I), S(R.$$.fragment, I), S(m.$$.fragment, I), U = !1
        },
        d(I) {
            I && k(n), b(t), b(s), b(l), b(f), b(R), b(m)
        }
    }
}

function qt(r) {
    let e = [],
        n = new Map,
        t, i, a = Z(r[0]);
    const s = o => o[5].id;
    for (let o = 0; o < a.length; o += 1) {
        let l = Pe(r, a, o),
            d = s(l);
        n.set(d, e[o] = ze(d, l))
    }
    return {
        c() {
            for (let o = 0; o < e.length; o += 1) e[o].c();
            t = H()
        },
        l(o) {
            for (let l = 0; l < e.length; l += 1) e[l].l(o);
            t = H()
        },
        m(o, l) {
            for (let d = 0; d < e.length; d += 1) e[d] && e[d].m(o, l);
            h(o, t, l), i = !0
        },
        p(o, [l]) {
            l & 775 && (a = Z(o[0]), W(), e = un(e, l, s, 1, o, a, n, t.parentNode, mn, ze, t, Pe), K())
        },
        i(o) {
            if (!i) {
                for (let l = 0; l < a.length; l += 1) _(e[l]);
                i = !0
            }
        },
        o(o) {
            for (let l = 0; l < e.length; l += 1) S(e[l]);
            i = !1
        },
        d(o) {
            o && k(t);
            for (let l = 0; l < e.length; l += 1) e[l].d(o)
        }
    }
}

function Qe(r) {
    var e, n;
    return [{
        name: r.meeting.racing.name,
        slug: r.meeting.racing.slug || ""
    }, {
        name: ((e = r.meeting.racingGroup) == null ? void 0 : e.name) || "",
        slug: ((n = r.meeting.racingGroup) == null ? void 0 : n.slug) || ""
    }, {
        name: r.meeting.venue.name,
        slug: r.meeting.slug || ""
    }]
}

function Gt(r, e, n) {
    let t, i;
    J(r, gn, l => n(3, t = l)), J(r, $n, l => n(4, i = l));
    let {
        eventList: a = []
    } = e;
    const s = Intl.DateTimeFormat(i, {
        weekday: "short",
        month: "short",
        day: "2-digit"
    });

    function o(l) {
        var d;
        return t(`/sports/racing/${l.meeting.racing.slug}/${(d=l.meeting.racingGroup)==null?void 0:d.slug}/meeting/${l.meeting.slug}/${l.racingSlug}`)
    }
    return r.$$set = l => {
        "eventList" in l && n(0, a = l.eventList)
    }, [a, s, o]
}
class Lt extends ae {
    constructor(e) {
        super(), le(this, e, Gt, qt, ie, {
            eventList: 0
        })
    }
}

function We(r, e, n) {
    const t = r.slice();
    return t[28] = e[n], t
}

function Bt(r, e, n) {
    const t = r.slice();
    return t[23] = e[n], t
}

function Pt(r, e, n) {
    const t = r.slice();
    return t[23] = e[n], t
}

function Ke(r, e, n) {
    const t = r.slice();
    return t[31] = e[n], t
}

function zt(r) {
    let e, n, t;
    return n = new Y({
        props: {
            variant: "subtle",
            align: "center",
            weight: "semibold",
            $$slots: {
                default: [Wt]
            },
            $$scope: {
                ctx: r
            }
        }
    }), {
        c() {
            e = V("div"), $(n.$$.fragment), this.h()
        },
        l(i) {
            e = C(i, "DIV", {
                class: !0
            });
            var a = O(e);
            N(n.$$.fragment, a), a.forEach(k), this.h()
        },
        h() {
            w(e, "class", "exception-wrap svelte-581c9u")
        },
        m(i, a) {
            h(i, e, a), F(n, e, null), t = !0
        },
        p(i, a) {
            const s = {};
            a[0] & 128 | a[1] & 8 && (s.$$scope = {
                dirty: a,
                ctx: i
            }), n.$set(s)
        },
        i(i) {
            t || (_(n.$$.fragment, i), t = !0)
        },
        o(i) {
            S(n.$$.fragment, i), t = !1
        },
        d(i) {
            i && k(e), b(n)
        }
    }
}

function Qt(r) {
    let e, n, t;
    return n = new Y({
        props: {
            variant: "subtle",
            align: "center",
            weight: "semibold",
            $$slots: {
                default: [Kt]
            },
            $$scope: {
                ctx: r
            }
        }
    }), {
        c() {
            e = V("div"), $(n.$$.fragment), this.h()
        },
        l(i) {
            e = C(i, "DIV", {
                class: !0
            });
            var a = O(e);
            N(n.$$.fragment, a), a.forEach(k), this.h()
        },
        h() {
            w(e, "class", "exception-wrap svelte-581c9u")
        },
        m(i, a) {
            h(i, e, a), F(n, e, null), t = !0
        },
        p(i, a) {
            const s = {};
            a[0] & 128 | a[1] & 8 && (s.$$scope = {
                dirty: a,
                ctx: i
            }), n.$set(s)
        },
        i(i) {
            t || (_(n.$$.fragment, i), t = !0)
        },
        o(i) {
            S(n.$$.fragment, i), t = !1
        },
        d(i) {
            i && k(e), b(n)
        }
    }
}

function Wt(r) {
    let e = r[7]._(B.noResults) + "",
        n;
    return {
        c() {
            n = G(e)
        },
        l(t) {
            n = L(t, e)
        },
        m(t, i) {
            h(t, n, i)
        },
        p(t, i) {
            i[0] & 128 && e !== (e = t[7]._(B.noResults) + "") && P(n, e)
        },
        d(t) {
            t && k(n)
        }
    }
}

function Kt(r) {
    let e = r[7]._(B.minimumCharacters) + "",
        n;
    return {
        c() {
            n = G(e)
        },
        l(t) {
            n = L(t, e)
        },
        m(t, i) {
            h(t, n, i)
        },
        p(t, i) {
            i[0] & 128 && e !== (e = t[7]._(B.minimumCharacters) + "") && P(n, e)
        },
        d(t) {
            t && k(n)
        }
    }
}

function Ue(r) {
    let e, n, t, i, a, s, o, l;
    return t = new Y({
        props: {
            variant: "subtle",
            weight: "bold",
            $$slots: {
                default: [Ut]
            },
            $$scope: {
                ctx: r
            }
        }
    }), a = new ne({
        props: {
            variant: "subtle-link",
            $$slots: {
                default: [jt]
            },
            $$scope: {
                ctx: r
            }
        }
    }), a.$on("click", r[14]), o = new vn({
        props: {
            searchList: r[8]
        }
    }), o.$on("select", r[15]), o.$on("remove", r[16]), {
        c() {
            e = V("div"), n = V("div"), $(t.$$.fragment), i = D(), $(a.$$.fragment), s = D(), $(o.$$.fragment), this.h()
        },
        l(d) {
            e = C(d, "DIV", {
                class: !0
            });
            var u = O(e);
            n = C(u, "DIV", {
                class: !0
            });
            var c = O(n);
            N(t.$$.fragment, c), i = E(c), N(a.$$.fragment, c), c.forEach(k), s = E(u), N(o.$$.fragment, u), u.forEach(k), this.h()
        },
        h() {
            w(n, "class", "content-header svelte-581c9u"), w(e, "class", "content svelte-581c9u")
        },
        m(d, u) {
            h(d, e, u), A(e, n), F(t, n, null), A(n, i), F(a, n, null), A(e, s), F(o, e, null), l = !0
        },
        p(d, u) {
            const c = {};
            u[0] & 128 | u[1] & 8 && (c.$$scope = {
                dirty: u,
                ctx: d
            }), t.$set(c);
            const f = {};
            u[0] & 384 | u[1] & 8 && (f.$$scope = {
                dirty: u,
                ctx: d
            }), a.$set(f);
            const p = {};
            u[0] & 256 && (p.searchList = d[8]), o.$set(p)
        },
        i(d) {
            l || (_(t.$$.fragment, d), _(a.$$.fragment, d), _(o.$$.fragment, d), l = !0)
        },
        o(d) {
            S(t.$$.fragment, d), S(a.$$.fragment, d), S(o.$$.fragment, d), l = !1
        },
        d(d) {
            d && k(e), b(t), b(a), b(o)
        }
    }
}

function Ut(r) {
    let e = r[7]._(B.recentSearches) + "",
        n;
    return {
        c() {
            n = G(e)
        },
        l(t) {
            n = L(t, e)
        },
        m(t, i) {
            h(t, n, i)
        },
        p(t, i) {
            i[0] & 128 && e !== (e = t[7]._(B.recentSearches) + "") && P(n, e)
        },
        d(t) {
            t && k(n)
        }
    }
}

function jt(r) {
    let e = r[7]._(B.clearSearch) + "",
        n, t, i = r[8].length + "",
        a, s;
    return {
        c() {
            n = G(e), t = G(" ("), a = G(i), s = G(")")
        },
        l(o) {
            n = L(o, e), t = L(o, " ("), a = L(o, i), s = L(o, ")")
        },
        m(o, l) {
            h(o, n, l), h(o, t, l), h(o, a, l), h(o, s, l)
        },
        p(o, l) {
            l[0] & 128 && e !== (e = o[7]._(B.clearSearch) + "") && P(n, e), l[0] & 256 && i !== (i = o[8].length + "") && P(a, i)
        },
        d(o) {
            o && (k(n), k(t), k(a), k(s))
        }
    }
}

function je(r) {
    let e, n, t, i;
    n = new Y({
        props: {
            size: "lg",
            variant: "danger",
            align: "center",
            weight: "semibold",
            $$slots: {
                default: [Ht]
            },
            $$scope: {
                ctx: r
            }
        }
    });
    let a = Z(r[3].errors ? ? []),
        s = [];
    for (let l = 0; l < a.length; l += 1) s[l] = He(Ke(r, a, l));
    const o = l => S(s[l], 1, 1, () => {
        s[l] = null
    });
    return {
        c() {
            e = V("div"), $(n.$$.fragment), t = D();
            for (let l = 0; l < s.length; l += 1) s[l].c();
            this.h()
        },
        l(l) {
            e = C(l, "DIV", {
                class: !0
            });
            var d = O(e);
            N(n.$$.fragment, d), t = E(d);
            for (let u = 0; u < s.length; u += 1) s[u].l(d);
            d.forEach(k), this.h()
        },
        h() {
            w(e, "class", "exception-wrap svelte-581c9u")
        },
        m(l, d) {
            h(l, e, d), F(n, e, null), A(e, t);
            for (let u = 0; u < s.length; u += 1) s[u] && s[u].m(e, null);
            i = !0
        },
        p(l, d) {
            const u = {};
            if (d[0] & 128 | d[1] & 8 && (u.$$scope = {
                    dirty: d,
                    ctx: l
                }), n.$set(u), d[0] & 8) {
                a = Z(l[3].errors ? ? []);
                let c;
                for (c = 0; c < a.length; c += 1) {
                    const f = Ke(l, a, c);
                    s[c] ? (s[c].p(f, d), _(s[c], 1)) : (s[c] = He(f), s[c].c(), _(s[c], 1), s[c].m(e, null))
                }
                for (W(), c = a.length; c < s.length; c += 1) o(c);
                K()
            }
        },
        i(l) {
            if (!i) {
                _(n.$$.fragment, l);
                for (let d = 0; d < a.length; d += 1) _(s[d]);
                i = !0
            }
        },
        o(l) {
            S(n.$$.fragment, l), s = s.filter(Boolean);
            for (let d = 0; d < s.length; d += 1) S(s[d]);
            i = !1
        },
        d(l) {
            l && k(e), b(n), ke(s, l)
        }
    }
}

function Ht(r) {
    let e = r[7]._(B.searchError) + "",
        n;
    return {
        c() {
            n = G(e)
        },
        l(t) {
            n = L(t, e)
        },
        m(t, i) {
            h(t, n, i)
        },
        p(t, i) {
            i[0] & 128 && e !== (e = t[7]._(B.searchError) + "") && P(n, e)
        },
        d(t) {
            t && k(n)
        }
    }
}

function Xt(r) {
    let e = r[31].message + "",
        n, t;
    return {
        c() {
            n = G(e), t = D()
        },
        l(i) {
            n = L(i, e), t = E(i)
        },
        m(i, a) {
            h(i, n, a), h(i, t, a)
        },
        p(i, a) {
            a[0] & 8 && e !== (e = i[31].message + "") && P(n, e)
        },
        d(i) {
            i && (k(n), k(t))
        }
    }
}

function He(r) {
    let e, n;
    return e = new Y({
        props: {
            variant: "subtle",
            align: "center",
            $$slots: {
                default: [Xt]
            },
            $$scope: {
                ctx: r
            }
        }
    }), {
        c() {
            $(e.$$.fragment)
        },
        l(t) {
            N(e.$$.fragment, t)
        },
        m(t, i) {
            F(e, t, i), n = !0
        },
        p(t, i) {
            const a = {};
            i[0] & 8 | i[1] & 8 && (a.$$scope = {
                dirty: i,
                ctx: t
            }), e.$set(a)
        },
        i(t) {
            n || (_(e.$$.fragment, t), n = !0)
        },
        o(t) {
            S(e.$$.fragment, t), n = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function Jt(r) {
    var d;
    let e, n, t, i, a, s;
    n = new kn({
        props: {
            variant: "light",
            $$slots: {
                default: [ei]
            },
            $$scope: {
                ctx: r
            }
        }
    });
    let o = r[6].length && Je(r),
        l = ((d = r[1]) == null ? void 0 : d.racing.length) && Ye(r);
    return {
        c() {
            e = V("div"), $(n.$$.fragment), t = D(), i = V("div"), o && o.c(), a = D(), l && l.c(), this.h()
        },
        l(u) {
            e = C(u, "DIV", {
                class: !0
            });
            var c = O(e);
            N(n.$$.fragment, c), t = E(c), i = C(c, "DIV", {
                class: !0
            });
            var f = O(i);
            o && o.l(f), a = E(f), l && l.l(f), f.forEach(k), c.forEach(k), this.h()
        },
        h() {
            w(i, "class", "fixture-list svelte-581c9u"), w(e, "class", "wrap svelte-581c9u")
        },
        m(u, c) {
            h(u, e, c), F(n, e, null), A(e, t), A(e, i), o && o.m(i, null), A(i, a), l && l.m(i, null), s = !0
        },
        p(u, c) {
            var p;
            const f = {};
            c[0] & 5 | c[1] & 8 && (f.$$scope = {
                dirty: c,
                ctx: u
            }), n.$set(f), u[6].length ? o ? (o.p(u, c), c[0] & 64 && _(o, 1)) : (o = Je(u), o.c(), _(o, 1), o.m(i, a)) : o && (W(), S(o, 1, 1, () => {
                o = null
            }), K()), (p = u[1]) != null && p.racing.length ? l ? (l.p(u, c), c[0] & 2 && _(l, 1)) : (l = Ye(u), l.c(), _(l, 1), l.m(i, null)) : l && (W(), S(l, 1, 1, () => {
                l = null
            }), K())
        },
        i(u) {
            s || (_(n.$$.fragment, u), _(o), _(l), s = !0)
        },
        o(u) {
            S(n.$$.fragment, u), S(o), S(l), s = !1
        },
        d(u) {
            u && k(e), b(n), o && o.d(), l && l.d()
        }
    }
}

function Yt(r) {
    let e, n, t, i, a;
    n = new kn({
        props: {
            variant: "light",
            $$slots: {
                default: [ai]
            },
            $$scope: {
                ctx: r
            }
        }
    });
    let s = Z(Array.apply(null, Array(10))),
        o = [];
    for (let l = 0; l < s.length; l += 1) o[l] = li(Bt(r, s, l));
    return {
        c() {
            e = V("div"), $(n.$$.fragment), t = D(), i = V("div");
            for (let l = 0; l < o.length; l += 1) o[l].c();
            this.h()
        },
        l(l) {
            e = C(l, "DIV", {
                class: !0
            });
            var d = O(e);
            N(n.$$.fragment, d), t = E(d), i = C(d, "DIV", {
                class: !0
            });
            var u = O(i);
            for (let c = 0; c < o.length; c += 1) o[c].l(u);
            u.forEach(k), d.forEach(k), this.h()
        },
        h() {
            w(i, "class", "fixture-list loading svelte-581c9u"), w(e, "class", "wrap svelte-581c9u")
        },
        m(l, d) {
            h(l, e, d), F(n, e, null), A(e, t), A(e, i);
            for (let u = 0; u < o.length; u += 1) o[u] && o[u].m(i, null);
            a = !0
        },
        p(l, d) {
            const u = {};
            d[1] & 8 && (u.$$scope = {
                dirty: d,
                ctx: l
            }), n.$set(u)
        },
        i(l) {
            if (!a) {
                _(n.$$.fragment, l);
                for (let d = 0; d < s.length; d += 1) _(o[d]);
                a = !0
            }
        },
        o(l) {
            S(n.$$.fragment, l), o = o.filter(Boolean);
            for (let d = 0; d < o.length; d += 1) S(o[d]);
            a = !1
        },
        d(l) {
            l && k(e), b(n), ke(o, l)
        }
    }
}

function Zt(r) {
    var t, i;
    let e = ((i = (t = r[28]) == null ? void 0 : t.fixtureList) == null ? void 0 : i.length) + "",
        n;
    return {
        c() {
            n = G(e)
        },
        l(a) {
            n = L(a, e)
        },
        m(a, s) {
            h(a, n, s)
        },
        p(a, s) {
            var o, l;
            s[0] & 4 && e !== (e = ((l = (o = a[28]) == null ? void 0 : o.fixtureList) == null ? void 0 : l.length) + "") && P(n, e)
        },
        d(a) {
            a && k(n)
        }
    }
}

function xt(r) {
    let e, n = r[28].name + "",
        t, i, a, s, o;
    return a = new cn({
        props: {
            rounded: !0,
            $$slots: {
                default: [Zt]
            },
            $$scope: {
                ctx: r
            }
        }
    }), {
        c() {
            e = V("span"), t = G(n), i = D(), $(a.$$.fragment), s = D()
        },
        l(l) {
            e = C(l, "SPAN", {});
            var d = O(e);
            t = L(d, n), d.forEach(k), i = E(l), N(a.$$.fragment, l), s = E(l)
        },
        m(l, d) {
            h(l, e, d), A(e, t), h(l, i, d), F(a, l, d), h(l, s, d), o = !0
        },
        p(l, d) {
            (!o || d[0] & 4) && n !== (n = l[28].name + "") && P(t, n);
            const u = {};
            d[0] & 4 | d[1] & 8 && (u.$$scope = {
                dirty: d,
                ctx: l
            }), a.$set(u)
        },
        i(l) {
            o || (_(a.$$.fragment, l), o = !0)
        },
        o(l) {
            S(a.$$.fragment, l), o = !1
        },
        d(l) {
            l && (k(e), k(i), k(s)), b(a, l)
        }
    }
}

function Xe(r, e) {
    let n, t, i;

    function a() {
        return e[17](e[28])
    }
    return t = new ne({
        props: {
            size: "sm",
            active: e[0] === e[28].name,
            $$slots: {
                default: [xt]
            },
            $$scope: {
                ctx: e
            }
        }
    }), t.$on("click", a), {
        key: r,
        first: null,
        c() {
            n = H(), $(t.$$.fragment), this.h()
        },
        l(s) {
            n = H(), N(t.$$.fragment, s), this.h()
        },
        h() {
            this.first = n
        },
        m(s, o) {
            h(s, n, o), F(t, s, o), i = !0
        },
        p(s, o) {
            e = s;
            const l = {};
            o[0] & 5 && (l.active = e[0] === e[28].name), o[0] & 4 | o[1] & 8 && (l.$$scope = {
                dirty: o,
                ctx: e
            }), t.$set(l)
        },
        i(s) {
            i || (_(t.$$.fragment, s), i = !0)
        },
        o(s) {
            S(t.$$.fragment, s), i = !1
        },
        d(s) {
            s && k(n), b(t, s)
        }
    }
}

function ei(r) {
    let e = [],
        n = new Map,
        t, i, a = Z(r[2]);
    const s = o => o[28].name;
    for (let o = 0; o < a.length; o += 1) {
        let l = We(r, a, o),
            d = s(l);
        n.set(d, e[o] = Xe(d, l))
    }
    return {
        c() {
            for (let o = 0; o < e.length; o += 1) e[o].c();
            t = H()
        },
        l(o) {
            for (let l = 0; l < e.length; l += 1) e[l].l(o);
            t = H()
        },
        m(o, l) {
            for (let d = 0; d < e.length; d += 1) e[d] && e[d].m(o, l);
            h(o, t, l), i = !0
        },
        p(o, l) {
            l[0] & 5 && (a = Z(o[2]), W(), e = un(e, l, s, 1, o, a, n, t.parentNode, mn, Xe, t, We), K())
        },
        i(o) {
            if (!i) {
                for (let l = 0; l < a.length; l += 1) _(e[l]);
                i = !0
            }
        },
        o(o) {
            for (let l = 0; l < e.length; l += 1) S(e[l]);
            i = !1
        },
        d(o) {
            o && k(t);
            for (let l = 0; l < e.length; l += 1) e[l].d(o)
        }
    }
}

function Je(r) {
    let e, n;
    return e = new Qn({
        props: {
            fixtureList: r[6],
            sortedTemplates: [],
            group: r[0],
            isSearchFixture: !0,
            $$slots: {
                divider: [ni]
            },
            $$scope: {
                ctx: r
            }
        }
    }), {
        c() {
            $(e.$$.fragment)
        },
        l(t) {
            N(e.$$.fragment, t)
        },
        m(t, i) {
            F(e, t, i), n = !0
        },
        p(t, i) {
            const a = {};
            i[0] & 64 && (a.fixtureList = t[6]), i[0] & 1 && (a.group = t[0]), i[1] & 8 && (a.$$scope = {
                dirty: i,
                ctx: t
            }), e.$set(a)
        },
        i(t) {
            n || (_(e.$$.fragment, t), n = !0)
        },
        o(t) {
            S(e.$$.fragment, t), n = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function ni(r) {
    let e;
    return {
        c() {
            e = V("div"), this.h()
        },
        l(n) {
            e = C(n, "DIV", {
                slot: !0,
                class: !0
            }), O(e).forEach(k), this.h()
        },
        h() {
            w(e, "slot", "divider"), w(e, "class", "divider svelte-581c9u")
        },
        m(n, t) {
            h(n, e, t)
        },
        p: ee,
        d(n) {
            n && k(e)
        }
    }
}

function Ye(r) {
    let e, n;
    return e = new Lt({
        props: {
            eventList: r[5]
        }
    }), {
        c() {
            $(e.$$.fragment)
        },
        l(t) {
            N(e.$$.fragment, t)
        },
        m(t, i) {
            F(e, t, i), n = !0
        },
        p(t, i) {
            const a = {};
            i[0] & 32 && (a.eventList = t[5]), e.$set(a)
        },
        i(t) {
            n || (_(e.$$.fragment, t), n = !0)
        },
        o(t) {
            S(e.$$.fragment, t), n = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function ti(r) {
    let e, n, t;
    return e = new Kn({
        props: {
            width: "5ch"
        }
    }), {
        c() {
            $(e.$$.fragment), n = D()
        },
        l(i) {
            N(e.$$.fragment, i), n = E(i)
        },
        m(i, a) {
            F(e, i, a), h(i, n, a), t = !0
        },
        p: ee,
        i(i) {
            t || (_(e.$$.fragment, i), t = !0)
        },
        o(i) {
            S(e.$$.fragment, i), t = !1
        },
        d(i) {
            i && k(n), b(e, i)
        }
    }
}

function ii(r) {
    let e, n;
    return e = new ne({
        props: {
            disabled: !0,
            size: "sm",
            $$slots: {
                default: [ti]
            },
            $$scope: {
                ctx: r
            }
        }
    }), {
        c() {
            $(e.$$.fragment)
        },
        l(t) {
            N(e.$$.fragment, t)
        },
        m(t, i) {
            F(e, t, i), n = !0
        },
        p(t, i) {
            const a = {};
            i[1] & 8 && (a.$$scope = {
                dirty: i,
                ctx: t
            }), e.$set(a)
        },
        i(t) {
            n || (_(e.$$.fragment, t), n = !0)
        },
        o(t) {
            S(e.$$.fragment, t), n = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function ai(r) {
    let e, n, t = Z([1, 2, 3]),
        i = [];
    for (let a = 0; a < 3; a += 1) i[a] = ii(Pt(r, t, a));
    return {
        c() {
            for (let a = 0; a < 3; a += 1) i[a].c();
            e = H()
        },
        l(a) {
            for (let s = 0; s < 3; s += 1) i[s].l(a);
            e = H()
        },
        m(a, s) {
            for (let o = 0; o < 3; o += 1) i[o] && i[o].m(a, s);
            h(a, e, s), n = !0
        },
        p: ee,
        i(a) {
            if (!n) {
                for (let s = 0; s < 3; s += 1) _(i[s]);
                n = !0
            }
        },
        o(a) {
            i = i.filter(Boolean);
            for (let s = 0; s < 3; s += 1) S(i[s]);
            n = !1
        },
        d(a) {
            a && k(e), ke(i, a)
        }
    }
}

function li(r) {
    let e, n;
    return e = new Wn({
        props: {
            isSearchFixture: !0
        }
    }), {
        c() {
            $(e.$$.fragment)
        },
        l(t) {
            N(e.$$.fragment, t)
        },
        m(t, i) {
            F(e, t, i), n = !0
        },
        p: ee,
        i(t) {
            n || (_(e.$$.fragment, t), n = !0)
        },
        o(t) {
            S(e.$$.fragment, t), n = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function ri(r) {
    let e, n, t, i, a, s, o, l, d;
    const u = [Qt, zt],
        c = [];

    function f(m, g) {
        return m[4] === "characterLimit" ? 0 : m[4] === "empty" ? 1 : -1
    }~(e = f(r)) && (n = c[e] = u[e](r));
    let p = (r[4] === "characterLimit" || r[4] === "empty") && r[8].length && Ue(r),
        v = r[4] === "error" && je(r);
    const T = [Yt, Jt],
        R = [];

    function X(m, g) {
        return m[4] === "loading" ? 0 : m[4] === "success" ? 1 : -1
    }
    return ~(s = X(r)) && (o = R[s] = T[s](r)), {
        c() {
            n && n.c(), t = D(), p && p.c(), i = D(), v && v.c(), a = D(), o && o.c(), l = H()
        },
        l(m) {
            n && n.l(m), t = E(m), p && p.l(m), i = E(m), v && v.l(m), a = E(m), o && o.l(m), l = H()
        },
        m(m, g) {
            ~e && c[e].m(m, g), h(m, t, g), p && p.m(m, g), h(m, i, g), v && v.m(m, g), h(m, a, g), ~s && R[s].m(m, g), h(m, l, g), d = !0
        },
        p(m, g) {
            let U = e;
            e = f(m), e === U ? ~e && c[e].p(m, g) : (n && (W(), S(c[U], 1, 1, () => {
                c[U] = null
            }), K()), ~e ? (n = c[e], n ? n.p(m, g) : (n = c[e] = u[e](m), n.c()), _(n, 1), n.m(t.parentNode, t)) : n = null), (m[4] === "characterLimit" || m[4] === "empty") && m[8].length ? p ? (p.p(m, g), g[0] & 272 && _(p, 1)) : (p = Ue(m), p.c(), _(p, 1), p.m(i.parentNode, i)) : p && (W(), S(p, 1, 1, () => {
                p = null
            }), K()), m[4] === "error" ? v ? (v.p(m, g), g[0] & 16 && _(v, 1)) : (v = je(m), v.c(), _(v, 1), v.m(a.parentNode, a)) : v && (W(), S(v, 1, 1, () => {
                v = null
            }), K());
            let I = s;
            s = X(m), s === I ? ~s && R[s].p(m, g) : (o && (W(), S(R[I], 1, 1, () => {
                R[I] = null
            }), K()), ~s ? (o = R[s], o ? o.p(m, g) : (o = R[s] = T[s](m), o.c()), _(o, 1), o.m(l.parentNode, l)) : o = null)
        },
        i(m) {
            d || (_(n), _(p), _(v), _(o), d = !0)
        },
        o(m) {
            S(n), S(p), S(v), S(o), d = !1
        },
        d(m) {
            m && (k(t), k(i), k(a), k(l)), ~e && c[e].d(m), p && p.d(m), v && v.d(m), ~s && R[s].d(m)
        }
    }
}

function si(r, e, n) {
    var se, oe;
    let t, i, a, s, o, l, d, u, c, f, p, v;
    J(r, Xn, M => n(18, f = M)), J(r, be, M => n(7, p = M)), J(r, ve, M => n(8, v = M));
    let {
        query: T
    } = e;
    const R = (oe = (se = f == null ? void 0 : f[Nn.racing_flag]) == null ? void 0 : se.config) == null ? void 0 : oe.enabled,
        X = M => {
            const j = ce.groupBy(M, Q => Q == null ? void 0 : Q.tournament.category.sport.name);
            return ce.mapValues(j, Q => {
                var y;
                return {
                    fixtureList: Q,
                    name: (y = Q[0]) == null ? void 0 : y.tournament.category.sport.name
                }
            })
        },
        m = M => {
            const j = ce.groupBy(M, Q => Q == null ? void 0 : Q.meeting.racing.name);
            return ce.mapValues(j, Q => {
                var y;
                return {
                    fixtureList: Q,
                    name: (y = Q[0]) == null ? void 0 : y.meeting.racing.name
                }
            })
        };
    let g = null;
    const {
        input$: U,
        query: I
    } = _n({
        query: M => ({
            doc: Dt,
            variables: {
                query: M,
                groups: Fn
            }
        }),
        options: {
            minSearchCharacters: 3,
            onSuccess: M => {
                var j;
                ((j = M.sportFixtureQuery) == null ? void 0 : j.length) !== 0 && ve.save(T)
            }
        }
    });
    J(r, I, M => n(3, c = M));
    const q = () => ve.removeAll();

    function z(M) {
        fe.call(this, r, M)
    }
    const re = M => ve.remove(M.detail),
        de = M => {
            n(0, g = M.name)
        };
    return r.$$set = M => {
        "query" in M && n(10, T = M.query)
    }, r.$$.update = () => {
        var M;
        r.$$.dirty[0] & 1024 && U.next(T), r.$$.dirty[0] & 8 && n(1, t = (M = c.data) == null ? void 0 : M.sportFixtureQuery.reduce((j, Q) => {
            var y, me;
            return ((y = Q.fixture) == null ? void 0 : y.__typename) === "SportFixture" ? j.sport = [...j.sport, Q.fixture] : ((me = Q.fixture) == null ? void 0 : me.__typename) === "RacingEvent" && (j.racing = [...j.racing, Q.fixture]), j
        }, {
            sport: [],
            racing: []
        })), r.$$.dirty[0] & 2 && n(13, i = X((t == null ? void 0 : t.sport) || [])), r.$$.dirty[0] & 2 && n(12, a = R ? m((t == null ? void 0 : t.racing) || []) : {}), r.$$.dirty[0] & 12288 && n(2, s = ce.values({ ...i,
            ...a
        })), r.$$.dirty[0] & 4 && n(11, o = s.map(({
            name: j
        }) => j)), r.$$.dirty[0] & 2048 && o.length !== 0 && n(0, g = o[0]), r.$$.dirty[0] & 8193 && n(6, l = g && g in i ? i[g].fixtureList : []), r.$$.dirty[0] & 4097 && n(5, d = g && g in a ? a[g].fixtureList : []), r.$$.dirty[0] & 1034 && n(4, u = T.length < ye ? "characterLimit" : c.loading ? "loading" : c.errors ? "error" : t != null && t.sport && (t == null ? void 0 : t.sport.length) > 0 || t != null && t.racing && t.racing.length > 0 && R ? "success" : "empty")
    }, [g, t, s, c, u, d, l, p, v, I, T, o, a, i, q, z, re, de]
}
class oi extends ae {
    constructor(e) {
        super(), le(this, e, si, ri, ie, {
            query: 10
        }, null, [-1, -1])
    }
}

function Ze(r) {
    let e;
    return {
        c() {
            e = V("div")
        },
        l(n) {
            e = C(n, "DIV", {}), O(e).forEach(k)
        },
        m(n, t) {
            h(n, e, t), r[6](e)
        },
        p: ee,
        d(n) {
            n && k(e), r[6](null)
        }
    }
}

function di(r) {
    let e, n;
    const t = r[5].default,
        i = nn(t, r, r[8], null);
    return {
        c() {
            e = V("div"), i && i.c(), this.h()
        },
        l(a) {
            e = C(a, "DIV", {
                style: !0
            });
            var s = O(e);
            i && i.l(s), s.forEach(k), this.h()
        },
        h() {
            _e(e, "z-index", Se.search), _e(e, "width", r[1] + "px")
        },
        m(a, s) {
            h(a, e, s), i && i.m(e, null), r[7](e), n = !0
        },
        p(a, s) {
            i && i.p && (!n || s & 256) && tn(i, t, a, a[8], n ? ln(t, a[8], s, null) : an(a[8]), null), (!n || s & 2) && _e(e, "width", a[1] + "px")
        },
        i(a) {
            n || (_(i, a), n = !0)
        },
        o(a) {
            S(i, a), n = !1
        },
        d(a) {
            a && k(e), i && i.d(a), r[7](null)
        }
    }
}

function ui(r) {
    let e, n, t, i = !r[0] && Ze(r);
    return n = new Jn({
        props: {
            $$slots: {
                default: [di]
            },
            $$scope: {
                ctx: r
            }
        }
    }), {
        c() {
            i && i.c(), e = D(), $(n.$$.fragment)
        },
        l(a) {
            i && i.l(a), e = E(a), N(n.$$.fragment, a)
        },
        m(a, s) {
            i && i.m(a, s), h(a, e, s), F(n, a, s), t = !0
        },
        p(a, [s]) {
            a[0] ? i && (i.d(1), i = null) : i ? i.p(a, s) : (i = Ze(a), i.c(), i.m(e.parentNode, e));
            const o = {};
            s & 262 && (o.$$scope = {
                dirty: s,
                ctx: a
            }), n.$set(o)
        },
        i(a) {
            t || (_(n.$$.fragment, a), t = !0)
        },
        o(a) {
            S(n.$$.fragment, a), t = !1
        },
        d(a) {
            a && k(e), i && i.d(a), b(n, a)
        }
    }
}

function mi(r, e, n) {
    let {
        $$slots: t = {},
        $$scope: i
    } = e, {
        parentNode: a
    } = e, {
        parentWidth: s
    } = e, {
        containerNode: o = void 0
    } = e, l, d;
    Sn(() => {
        const f = Yn(a || d.parentElement, l, {
                strategy: "fixed",
                placement: "bottom",
                modifiers: [{
                    name: "offset",
                    options: {
                        offset: [0, 10]
                    }
                }]
            }),
            p = pn(o ? ? l, () => {
                f.update()
            });
        return () => {
            f.destroy(), p.destroy()
        }
    });

    function u(f) {
        ge[f ? "unshift" : "push"](() => {
            d = f, n(3, d)
        })
    }

    function c(f) {
        ge[f ? "unshift" : "push"](() => {
            l = f, n(2, l)
        })
    }
    return r.$$set = f => {
        "parentNode" in f && n(0, a = f.parentNode), "parentWidth" in f && n(1, s = f.parentWidth), "containerNode" in f && n(4, o = f.containerNode), "$$scope" in f && n(8, i = f.$$scope)
    }, [a, s, l, d, o, t, u, c, i]
}
class ci extends ae {
    constructor(e) {
        super(), le(this, e, mi, ui, ie, {
            parentNode: 0,
            parentWidth: 1,
            containerNode: 4
        })
    }
}

function xe(r) {
    let e, n, t, i;
    return {
        c() {
            e = V("div"), this.h()
        },
        l(a) {
            e = C(a, "DIV", {
                role: !0,
                class: !0,
                style: !0,
                tabindex: !0
            }), O(e).forEach(k), this.h()
        },
        h() {
            w(e, "role", "button"), w(e, "class", "search-overlay svelte-12b0zpm"), _e(e, "z-index", Se.search), w(e, "tabindex", "0"), te(e, "mobile", r[9])
        },
        m(a, s) {
            h(a, e, s), t || (i = [ue(e, "click", r[14]), ue(e, "keydown", r[15]), ue(e, "wheel", Si)], t = !0)
        },
        p(a, s) {
            s & 512 && te(e, "mobile", a[9])
        },
        i(a) {
            n || rn(() => {
                n = sn(e, dn, {
                    duration: 200,
                    delay: 0
                }), n.start()
            })
        },
        o: ee,
        d(a) {
            a && k(e), t = !1, Ne(i)
        }
    }
}

function en(r) {
    var t;
    let e, n;
    return e = new ci({
        props: {
            parentNode: r[6],
            parentWidth: (t = r[7]) == null ? void 0 : t.width,
            containerNode: r[3],
            $$slots: {
                default: [vi]
            },
            $$scope: {
                ctx: r
            }
        }
    }), {
        c() {
            $(e.$$.fragment)
        },
        l(i) {
            N(e.$$.fragment, i)
        },
        m(i, a) {
            F(e, i, a), n = !0
        },
        p(i, a) {
            var o;
            const s = {};
            a & 64 && (s.parentNode = i[6]), a & 128 && (s.parentWidth = (o = i[7]) == null ? void 0 : o.width), a & 8 && (s.containerNode = i[3]), a & 268435744 && (s.$$scope = {
                dirty: a,
                ctx: i
            }), e.$set(s)
        },
        i(i) {
            n || (_(e.$$.fragment, i), n = !0)
        },
        o(i) {
            S(e.$$.fragment, i), n = !1
        },
        d(i) {
            b(e, i)
        }
    }
}

function fi(r) {
    let e, n;
    return e = new oi({
        props: {
            query: r[5]
        }
    }), e.$on("select", r[24]), {
        c() {
            $(e.$$.fragment)
        },
        l(t) {
            N(e.$$.fragment, t)
        },
        m(t, i) {
            F(e, t, i), n = !0
        },
        p(t, i) {
            const a = {};
            i & 32 && (a.query = t[5]), e.$set(a)
        },
        i(t) {
            n || (_(e.$$.fragment, t), n = !0)
        },
        o(t) {
            S(e.$$.fragment, t), n = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function ki(r) {
    let e, n;
    return e = new Tt({
        props: {
            query: r[5]
        }
    }), e.$on("select", r[23]), {
        c() {
            $(e.$$.fragment)
        },
        l(t) {
            N(e.$$.fragment, t)
        },
        m(t, i) {
            F(e, t, i), n = !0
        },
        p(t, i) {
            const a = {};
            i & 32 && (a.query = t[5]), e.$set(a)
        },
        i(t) {
            n || (_(e.$$.fragment, t), n = !0)
        },
        o(t) {
            S(e.$$.fragment, t), n = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function pi(r) {
    let e, n, t, i;
    const a = [ki, fi],
        s = [];

    function o(l, d) {
        return l[8] === "casino" ? 0 : 1
    }
    return e = o(r), n = s[e] = a[e](r), {
        c() {
            n.c(), t = H()
        },
        l(l) {
            n.l(l), t = H()
        },
        m(l, d) {
            s[e].m(l, d), h(l, t, d), i = !0
        },
        p(l, d) {
            let u = e;
            e = o(l), e === u ? s[e].p(l, d) : (W(), S(s[u], 1, 1, () => {
                s[u] = null
            }), K(), n = s[e], n ? n.p(l, d) : (n = s[e] = a[e](l), n.c()), _(n, 1), n.m(t.parentNode, t))
        },
        i(l) {
            i || (_(n), i = !0)
        },
        o(l) {
            S(n), i = !1
        },
        d(l) {
            l && k(t), s[e].d(l)
        }
    }
}

function vi(r) {
    let e, n;
    return e = new dt({
        props: {
            $$slots: {
                default: [pi]
            },
            $$scope: {
                ctx: r
            }
        }
    }), {
        c() {
            $(e.$$.fragment)
        },
        l(t) {
            N(e.$$.fragment, t)
        },
        m(t, i) {
            F(e, t, i), n = !0
        },
        p(t, i) {
            const a = {};
            i & 268435744 && (a.$$scope = {
                dirty: i,
                ctx: t
            }), e.$set(a)
        },
        i(t) {
            n || (_(e.$$.fragment, t), n = !0)
        },
        o(t) {
            S(e.$$.fragment, t), n = !1
        },
        d(t) {
            b(e, t)
        }
    }
}

function _i(r) {
    let e, n, t, i, a, s, o, l, d, u = r[0] && xe(r);
    t = new rt({
        props: {
            showSearchOverlay: r[0],
            isGlobal: r[1],
            focusOnMount: r[2],
            value: r[5],
            chosenType: r[8],
            dataAnalytics: r[4]
        }
    }), t.$on("focus", r[16]), t.$on("focus", r[17]), t.$on("close", r[18]), t.$on("blur", r[19]), t.$on("changeType", r[20]), t.$on("changeType", r[21]), t.$on("input", r[22]);
    let c = r[0] && en(r);
    return {
        c() {
            u && u.c(), e = D(), n = V("div"), $(t.$$.fragment), i = D(), c && c.c(), this.h()
        },
        l(f) {
            u && u.l(f), e = E(f), n = C(f, "DIV", {
                class: !0,
                style: !0
            });
            var p = O(n);
            N(t.$$.fragment, p), i = E(p), c && c.l(p), p.forEach(k), this.h()
        },
        h() {
            w(n, "class", "search-wrap svelte-12b0zpm"), w(n, "style", a = r[0] ? `z-index:${Se.search};` : "")
        },
        m(f, p) {
            u && u.m(f, p), h(f, e, p), h(f, n, p), F(t, n, null), A(n, i), c && c.m(n, null), r[25](n), o = !0, l || (d = [$e(s = pn.call(null, n, r[26])), ue(n, "wheel", r[27])], l = !0)
        },
        p(f, [p]) {
            f[0] ? u ? (u.p(f, p), p & 1 && _(u, 1)) : (u = xe(f), u.c(), _(u, 1), u.m(e.parentNode, e)) : u && (u.d(1), u = null);
            const v = {};
            p & 1 && (v.showSearchOverlay = f[0]), p & 2 && (v.isGlobal = f[1]), p & 4 && (v.focusOnMount = f[2]), p & 32 && (v.value = f[5]), p & 256 && (v.chosenType = f[8]), p & 16 && (v.dataAnalytics = f[4]), t.$set(v), f[0] ? c ? (c.p(f, p), p & 1 && _(c, 1)) : (c = en(f), c.c(), _(c, 1), c.m(n, null)) : c && (W(), S(c, 1, 1, () => {
                c = null
            }), K()), (!o || p & 1 && a !== (a = f[0] ? `z-index:${Se.search};` : "")) && w(n, "style", a), s && hn(s.update) && p & 128 && s.update.call(null, f[26])
        },
        i(f) {
            o || (_(u), _(t.$$.fragment, f), _(c), o = !0)
        },
        o(f) {
            S(t.$$.fragment, f), S(c), o = !1
        },
        d(f) {
            f && (k(e), k(n)), u && u.d(f), b(t), c && c.d(), r[25](null), l = !1, Ne(d)
        }
    }
}
const Si = r => r.preventDefault();

function hi(r, e, n) {
    let t, i, a, s;
    J(r, bn, y => n(13, a = y)), J(r, he, y => n(9, s = y));
    let {
        type: o = null
    } = e, {
        showSearchOverlay: l = !1
    } = e, {
        isGlobal: d = !1
    } = e, {
        focusOnMount: u = !1
    } = e, {
        containerNode: c = void 0
    } = e, {
        dataAnalytics: f = void 0
    } = e, p = "";
    const v = Fe();
    let T, R;
    const X = () => {
            n(0, l = !1), v("close")
        },
        m = () => {
            n(0, l = !1), v("close")
        };

    function g(y) {
        fe.call(this, r, y)
    }
    const U = () => n(0, l = !0),
        I = () => {
            p.length >= ye ? n(5, p = "") : (n(0, l = !1), v("close"))
        },
        q = () => n(0, l = !1);

    function z(y) {
        fe.call(this, r, y)
    }
    const re = y => n(8, t = y.detail.value),
        de = y => n(5, p = y.detail.currentTarget.value),
        se = y => n(5, p = y.detail),
        oe = y => n(5, p = y.detail);

    function M(y) {
        ge[y ? "unshift" : "push"](() => {
            T = y, n(6, T)
        })
    }
    const j = y => n(7, R = y),
        Q = y => {
            l && y.preventDefault()
        };
    return r.$$set = y => {
        "type" in y && n(11, o = y.type), "showSearchOverlay" in y && n(0, l = y.showSearchOverlay), "isGlobal" in y && n(1, d = y.isGlobal), "focusOnMount" in y && n(2, u = y.focusOnMount), "containerNode" in y && n(3, c = y.containerNode), "dataAnalytics" in y && n(4, f = y.dataAnalytics)
    }, r.$$.update = () => {
        var y, me, we, Te;
        r.$$.dirty & 2048 && n(8, t = o), r.$$.dirty & 8192 && n(12, i = ((me = (y = a == null ? void 0 : a.to) == null ? void 0 : y.url) == null ? void 0 : me.pathname) !== ((Te = (we = a == null ? void 0 : a.from) == null ? void 0 : we.url) == null ? void 0 : Te.pathname)), r.$$.dirty & 4096 && i && v("close")
    }, [l, d, u, c, f, p, T, R, t, s, v, o, i, a, X, m, g, U, I, q, z, re, de, se, oe, M, j, Q]
}
class ia extends ae {
    constructor(e) {
        super(), le(this, e, hi, _i, ie, {
            type: 11,
            showSearchOverlay: 0,
            isGlobal: 1,
            focusOnMount: 2,
            containerNode: 3,
            dataAnalytics: 4
        })
    }
}
export {
    ia as S
};