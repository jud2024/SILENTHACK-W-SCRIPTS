import {
    s as y,
    a as v,
    e as c,
    d as _,
    f as m,
    i as f,
    I as b,
    j as E,
    k as C,
    u as S,
    g as w,
    b as I,
    o as N,
    J as h
} from "./scheduler.DXu26z7T.js";
import {
    S as k,
    i as M,
    t as T,
    b as q
} from "./index.Dz_MmNB3.js";

function A(a) {
    let i, s, r;
    const d = a[5].default,
        n = v(d, a, a[4], null);
    return {
        c() {
            i = c("div"), s = c("div"), n && n.c(), this.h()
        },
        l(e) {
            i = _(e, "DIV", {
                style: !0
            });
            var o = m(i);
            s = _(o, "DIV", {});
            var l = m(s);
            n && n.l(l), l.forEach(f), o.forEach(f), this.h()
        },
        h() {
            b(i, "display", "none")
        },
        m(e, o) {
            E(e, i, o), C(i, s), n && n.m(s, null), a[6](s), a[7](i), r = !0
        },
        p(e, [o]) {
            n && n.p && (!r || o & 16) && S(n, d, e, e[4], r ? I(d, e[4], o, null) : w(e[4]), null)
        },
        i(e) {
            r || (T(n, e), r = !0)
        },
        o(e) {
            q(n, e), r = !1
        },
        d(e) {
            e && f(i), n && n.d(e), a[6](null), a[7](null)
        }
    }
}

function D(a, i, s) {
    let {
        $$slots: r = {},
        $$scope: d
    } = i, {
        target: n = document.body
    } = i, e, o, {
        node: l = void 0
    } = i, {
        parentNode: u = void 0
    } = i;
    N(() => {
        if (typeof n == "string") {
            if (e = document.querySelector(n), e === null) return () => {}
        } else if (n instanceof HTMLElement) e = n;
        else throw new TypeError(`Unknown target type: ${typeof n}. Allowed types: String (CSS selector), HTMLElement.`);
        let t = document.createElement("div");
        return t.setAttribute("data-portal", "true"), e.appendChild(t), t.appendChild(o), () => {
            t.contains(o) && t.removeChild(o), e != null && e.contains(t) && e.removeChild(t)
        }
    });

    function p(t) {
        h[t ? "unshift" : "push"](() => {
            o = t, s(1, o)
        })
    }

    function g(t) {
        h[t ? "unshift" : "push"](() => {
            l = t, s(0, l)
        })
    }
    return a.$$set = t => {
        "target" in t && s(2, n = t.target), "node" in t && s(0, l = t.node), "parentNode" in t && s(3, u = t.parentNode), "$$scope" in t && s(4, d = t.$$scope)
    }, a.$$.update = () => {
        a.$$.dirty & 9 && l && l != null && l.parentElement && u && u.set(l.parentElement)
    }, [l, o, n, u, d, r, p, g]
}
class P extends k {
    constructor(i) {
        super(), M(this, i, D, A, y, {
            target: 2,
            node: 0,
            parentNode: 3
        })
    }
}
export {
    P
};