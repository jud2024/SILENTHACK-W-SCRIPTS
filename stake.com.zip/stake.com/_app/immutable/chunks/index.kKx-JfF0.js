import {
    s as r,
    a as u,
    e as f,
    d as c,
    f as _,
    i as o,
    F as d,
    j as m,
    u as p,
    g as h,
    b as $
} from "./scheduler.DXu26z7T.js";
import {
    S as v,
    i as g,
    t as b,
    b as y
} from "./index.Dz_MmNB3.js";

function C(i) {
    let e, a;
    const n = i[1].default,
        t = u(n, i, i[0], null);
    return {
        c() {
            e = f("div"), t && t.c(), this.h()
        },
        l(s) {
            e = c(s, "DIV", {
                class: !0
            });
            var l = _(e);
            t && t.l(l), l.forEach(o), this.h()
        },
        h() {
            d(e, "class", "card-focus svelte-ilyy5c")
        },
        m(s, l) {
            m(s, e, l), t && t.m(e, null), a = !0
        },
        p(s, [l]) {
            t && t.p && (!a || l & 1) && p(t, n, s, s[0], a ? $(n, s[0], l, null) : h(s[0]), null)
        },
        i(s) {
            a || (b(t, s), a = !0)
        },
        o(s) {
            y(t, s), a = !1
        },
        d(s) {
            s && o(e), t && t.d(s)
        }
    }
}

function F(i, e, a) {
    let {
        $$slots: n = {},
        $$scope: t
    } = e;
    return i.$$set = s => {
        "$$scope" in s && a(0, t = s.$$scope)
    }, [t, n]
}
class q extends v {
    constructor(e) {
        super(), g(this, e, F, C, r, {})
    }
}
export {
    q as C
};