var n = /\b(?:an?d?|a[st]|because|but|by|en|for|i[fn]|neither|nor|o[fnr]|only|over|per|so|some|tha[tn]|the|to|up|upon|vs?\.?|versus|via|when|with|without|yet)\b/i,
    u = /[^\s:–—-]+|./g,
    v = /\s/,
    A = /.(?=[A-Z]|\..)/,
    l = /[A-Za-z0-9\u00C0-\u00FF]/;

function o(r) {
    for (var a = "", s;
        (s = u.exec(r)) !== null;) {
        var e = s[0],
            t = s.index;
        if (!A.test(e) && (!n.test(e) || t === 0 || t + e.length === r.length) && (r.charAt(t + e.length) !== ":" || v.test(r.charAt(t + e.length + 1)))) {
            a += e.replace(l, function(h) {
                return h.toUpperCase()
            });
            continue
        }
        a += e
    }
    return a
}
export {
    o as t
};