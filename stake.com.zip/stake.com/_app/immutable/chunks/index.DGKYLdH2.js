import {
    _ as s
} from "./index.B4-7gKq3.js";
import {
    w as n
} from "./index.C2-CG2CN.js";
import {
    n as i
} from "./index.Cpg-fJ3N.js";
const h = (() => {
        const t = n([]);
        return { ...t,
            remove: e => {
                t.update(o => o.filter(a => a.id !== e))
            },
            open: e => {
                t.update(o => o.some(r => s.isEqual(s.omit(r, "id"), e)) ? o : [{ ...e,
                    id: i()
                }, ...o])
            }
        }
    })(),
    N = n(!1);
export {
    N as h, h as n
};