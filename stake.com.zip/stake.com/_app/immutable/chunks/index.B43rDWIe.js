import {
    cB as Z,
    a$ as U,
    w as $,
    aG as A,
    h as R,
    bq as D,
    bW as H,
    bv as J
} from "./index.B4-7gKq3.js";
import {
    o as Q
} from "./scheduler.DXu26z7T.js";
import {
    _ as K,
    a as V,
    b as X,
    j as Y,
    i as E
} from "./tslib.es6.CYhxggkG.js";
import {
    f as P,
    d as q,
    a as j,
    o as S,
    c as O,
    O as h,
    g as L
} from "./dateTimestampProvider.DBRuHdww.js";
import {
    i as b,
    a as z,
    r as B,
    b as ee,
    c as ne,
    d as re,
    e as te,
    f as ie,
    g as oe,
    h as ae
} from "./innerFrom.BRHulYBS.js";
var ue = function(e) {
    K(n, e);

    function n(t, r, i) {
        t === void 0 && (t = 1 / 0), r === void 0 && (r = 1 / 0), i === void 0 && (i = q);
        var o = e.call(this) || this;
        return o._bufferSize = t, o._windowTime = r, o._timestampProvider = i, o._buffer = [], o._infiniteTimeWindow = !0, o._infiniteTimeWindow = r === 1 / 0, o._bufferSize = Math.max(1, t), o._windowTime = Math.max(1, r), o
    }
    return n.prototype.next = function(t) {
        var r = this,
            i = r.isStopped,
            o = r._buffer,
            a = r._infiniteTimeWindow,
            u = r._timestampProvider,
            s = r._windowTime;
        i || (o.push(t), !a && o.push(u.now() + s)), this._trimBuffer(), e.prototype.next.call(this, t)
    }, n.prototype._subscribe = function(t) {
        this._throwIfClosed(), this._trimBuffer();
        for (var r = this._innerSubscribe(t), i = this, o = i._infiniteTimeWindow, a = i._buffer, u = a.slice(), s = 0; s < u.length && !t.closed; s += o ? 1 : 2) t.next(u[s]);
        return this._checkFinalizedStatuses(t), r
    }, n.prototype._trimBuffer = function() {
        var t = this,
            r = t._bufferSize,
            i = t._timestampProvider,
            o = t._buffer,
            a = t._infiniteTimeWindow,
            u = (a ? 1 : 2) * r;
        if (r < 1 / 0 && u < o.length && o.splice(0, o.length - u), !a) {
            for (var s = i.now(), d = 0, f = 1; f < o.length && o[f] <= s; f += 2) d = f;
            d && o.splice(0, d + 1)
        }
    }, n
}(P);

function se(e) {
    return e && j(e.schedule)
}

function F(e) {
    return e[e.length - 1]
}

function fe(e) {
    return se(F(e)) ? e.pop() : void 0
}

function Oe(e, n) {
    return typeof F(e) == "number" ? e.pop() : n
}

function v(e, n, t, r, i) {
    r === void 0 && (r = 0), i === void 0 && (i = !1);
    var o = n.schedule(function() {
        t(), i ? e.add(this.schedule(null, r)) : this.unsubscribe()
    }, r);
    if (e.add(o), !i) return o
}

function k(e, n) {
    return n === void 0 && (n = 0), S(function(t, r) {
        t.subscribe(O(r, function(i) {
            return v(r, e, function() {
                return r.next(i)
            }, n)
        }, function() {
            return v(r, e, function() {
                return r.complete()
            }, n)
        }, function(i) {
            return v(r, e, function() {
                return r.error(i)
            }, n)
        }))
    })
}

function W(e, n) {
    return n === void 0 && (n = 0), S(function(t, r) {
        r.add(e.schedule(function() {
            return t.subscribe(r)
        }, n))
    })
}

function ce(e, n) {
    return b(e).pipe(W(n), k(n))
}

function le(e, n) {
    return b(e).pipe(W(n), k(n))
}

function de(e, n) {
    return new h(function(t) {
        var r = 0;
        return n.schedule(function() {
            r === e.length ? t.complete() : (t.next(e[r++]), t.closed || this.schedule())
        })
    })
}

function ve(e, n) {
    return new h(function(t) {
        var r;
        return v(t, n, function() {
                r = e[z](), v(t, n, function() {
                    var i, o, a;
                    try {
                        i = r.next(), o = i.value, a = i.done
                    } catch (u) {
                        t.error(u);
                        return
                    }
                    a ? t.complete() : t.next(o)
                }, 0, !0)
            }),
            function() {
                return j(r == null ? void 0 : r.return) && r.return()
            }
    })
}

function G(e, n) {
    if (!e) throw new Error("Iterable cannot be null");
    return new h(function(t) {
        v(t, n, function() {
            var r = e[Symbol.asyncIterator]();
            v(t, n, function() {
                r.next().then(function(i) {
                    i.done ? t.complete() : t.next(i.value)
                })
            }, 0, !0)
        })
    })
}

function be(e, n) {
    return G(B(e), n)
}

function me(e, n) {
    if (e != null) {
        if (ee(e)) return ce(e, n);
        if (ne(e)) return de(e, n);
        if (re(e)) return le(e, n);
        if (te(e)) return G(e, n);
        if (ie(e)) return ve(e, n);
        if (oe(e)) return be(e, n)
    }
    throw ae(e)
}

function he(e, n) {
    return n ? me(e, n) : b(e)
}

function pe() {
    for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
    var t = fe(e);
    return he(e, t)
}

function M(e) {
    return S(function(n, t) {
        var r = null,
            i = !1,
            o;
        r = n.subscribe(O(t, void 0, void 0, function(a) {
            o = b(e(a, M(e)(n))), r ? (r.unsubscribe(), r = null, o.subscribe(t)) : i = !0
        })), i && (r.unsubscribe(), r = null, o.subscribe(t))
    })
}

function _e(e) {
    e === void 0 && (e = {});
    var n = e.connector,
        t = n === void 0 ? function() {
            return new P
        } : n,
        r = e.resetOnError,
        i = r === void 0 ? !0 : r,
        o = e.resetOnComplete,
        a = o === void 0 ? !0 : o,
        u = e.resetOnRefCountZero,
        s = u === void 0 ? !0 : u;
    return function(d) {
        var f, c, l, p = 0,
            _ = !1,
            w = !1,
            g = function() {
                c == null || c.unsubscribe(), c = void 0
            },
            I = function() {
                g(), f = l = void 0, _ = w = !1
            },
            N = function() {
                var m = f;
                I(), m == null || m.unsubscribe()
            };
        return S(function(m, T) {
            p++, !w && !_ && g();
            var x = l = l ? ? t();
            T.add(function() {
                p--, p === 0 && !w && !_ && (c = C(N, s))
            }), x.subscribe(T), !f && p > 0 && (f = new L({
                next: function(y) {
                    return x.next(y)
                },
                error: function(y) {
                    w = !0, g(), c = C(I, i, y), x.error(y)
                },
                complete: function() {
                    _ = !0, g(), c = C(I, a), x.complete()
                }
            }), b(m).subscribe(f))
        })(d)
    }
}

function C(e, n) {
    for (var t = [], r = 2; r < arguments.length; r++) t[r - 2] = arguments[r];
    if (n === !0) {
        e();
        return
    }
    if (n !== !1) {
        var i = new L({
            next: function() {
                i.unsubscribe(), e()
            }
        });
        return b(n.apply(void 0, V([], X(t)))).subscribe(i)
    }
}

function we(e, n, t) {
    var r, i, o, a, u = !1;
    return e && typeof e == "object" ? (r = e.bufferSize, a = r === void 0 ? 1 / 0 : r, i = e.windowTime, n = i === void 0 ? 1 / 0 : i, o = e.refCount, u = o === void 0 ? !1 : o, t = e.scheduler) : a = e ? ? 1 / 0, _e({
        connector: function() {
            return new ue(a, n, t)
        },
        resetOnError: !0,
        resetOnComplete: !1,
        resetOnRefCountZero: u
    })
}

function ge(e, n) {
    n === void 0 && (n = {});
    var t = n.selector,
        r = Y(n, ["selector"]);
    return new h(function(i) {
        var o = new AbortController,
            a = o.signal,
            u = !0,
            s = r.signal;
        if (s)
            if (s.aborted) o.abort();
            else {
                var d = function() {
                    a.aborted || o.abort()
                };
                s.addEventListener("abort", d), i.add(function() {
                    return s.removeEventListener("abort", d)
                })
            }
        var f = E(E({}, r), {
                signal: a
            }),
            c = function(l) {
                u = !1, i.error(l)
            };
        return fetch(e, f).then(function(l) {
                t ? b(t(l)).subscribe(O(i, void 0, function() {
                    u = !1, i.complete()
                }, c)) : (u = !1, i.next(l), i.complete())
            }).catch(c),
            function() {
                u && o.abort()
            }
    })
}

function Te(e, n) {
    Q(() => {
        const t = e.subscribe(n);
        return () => {
            t.unsubscribe()
        }
    })
}

function Re(e) {
    return {
        subscribe: n => {
            const t = e.subscribe(n);
            return () => {
                t.unsubscribe()
            }
        }
    }
}

function Ee(e) {
    const {
        doc: n
    } = e, t = "variables" in e && e.variables ? e.variables : {}, r = new Headers(Z), i = U(), o = $();
    return i && r.set("x-access-token", i), o && r.set("x-language", o), ge(D, {
        method: "POST",
        headers: r,
        body: JSON.stringify({
            query: A(n),
            variables: t
        }),
        selector: async a => {
            if (a.status !== 200) return {
                errors: [{
                    message: R._("Failed to fetch - bad response")
                }],
                data: null,
                response: a
            };
            try {
                return await a.json()
            } catch {
                return {
                    errors: [{
                        message: R._("Failed to fetch")
                    }],
                    data: null,
                    response: a
                }
            }
        }
    }).pipe(M(a => pe({
        errors: [{
            message: a.message
        }],
        data: null
    })))
}

function Ae({
    query: e,
    variables: n
}) {
    return new h(t => {
        const r = H.subscribe({
            query: A(e),
            variables: n
        }, {
            error: i => {
                t.error(i)
            },
            complete: () => t.complete(),
            next: i => {
                var o, a, u;
                if (t.next(i.data), i.errors && J) {
                    const s = (u = (a = (o = e == null ? void 0 : e.definitions) == null ? void 0 : o[0]) == null ? void 0 : a.name) == null ? void 0 : u.value;
                    console.error(s, "next subscription error", n, i.errors)
                }
            }
        });
        return () => {
            r()
        }
    })
}

function Pe(e) {
    return e.pipe(we({
        bufferSize: 1,
        refCount: !0
    }))
}

function je({
    publishersMap: e,
    makePublisherFn: n,
    getEntityId: t
}) {
    return (r, i) => {
        const o = t(r),
            a = e.get(o);
        if (a) return a;
        const u = n(r, i);
        return e.set(o, u), u
    }
}
export {
    M as a, Ee as b, Ae as c, Re as d, v as e, he as f, je as g, Oe as h, se as i, pe as o, fe as p, Pe as r, Te as s
};