import {
    s as H,
    a as I,
    e as g,
    O,
    d as v,
    f as b,
    i as d,
    P as S,
    F as p,
    V as f,
    j as k,
    k as V,
    a3 as w,
    q as L,
    u as q,
    g as C,
    b as j
} from "./scheduler.DXu26z7T.js";
import {
    S as F,
    i as M,
    t as P,
    b as A
} from "./index.Dz_MmNB3.js";
import {
    s as B
} from "./context.BYnTbg5S.js";
import {
    r as G
} from "./resizeObserver.A9wvMie0.js";
import {
    i as J
} from "./variables.CIGccMR5.js";
import {
    c as K
} from "./context.UnLgwODO.js";
const N = l => ({
        mobile: l & 4
    }),
    E = l => ({
        mobile: l[2]
    });

function Q(l) {
    let t, o, n, u, _, r, i, h, m;
    const c = l[6].default,
        e = I(c, l, l[5], E);
    return {
        c() {
            t = g("div"), o = g("div"), n = g("div"), _ = O(), r = g("div"), e && e.c(), this.h()
        },
        l(s) {
            t = v(s, "DIV", {
                class: !0
            });
            var a = b(t);
            o = v(a, "DIV", {
                class: !0
            });
            var z = b(o);
            n = v(z, "DIV", {
                class: !0
            }), b(n).forEach(d), z.forEach(d), _ = S(a), r = v(a, "DIV", {
                class: !0
            });
            var D = b(r);
            e && e.l(D), D.forEach(d), a.forEach(d), this.h()
        },
        h() {
            p(n, "class", "sizer svelte-1p5gbm2"), p(o, "class", "ctainer no-height svelte-1p5gbm2"), f(o, "reset", l[0]), p(r, "class", "ctainer svelte-1p5gbm2"), f(r, "reset", l[0]), f(r, "full-height", l[1]), p(t, "class", "parent svelte-1p5gbm2"), f(t, "mobile", l[2]), f(t, "reset", l[0]), f(t, "full-height", l[1])
        },
        m(s, a) {
            k(s, t, a), V(t, o), V(o, n), V(t, _), V(t, r), e && e.m(r, null), i = !0, h || (m = w(u = G.call(null, n, l[7])), h = !0)
        },
        p(s, [a]) {
            u && L(u.update) && a & 4 && u.update.call(null, s[7]), (!i || a & 1) && f(o, "reset", s[0]), e && e.p && (!i || a & 36) && q(e, c, s, s[5], i ? j(c, s[5], a, N) : C(s[5]), E), (!i || a & 1) && f(r, "reset", s[0]), (!i || a & 2) && f(r, "full-height", s[1]), (!i || a & 4) && f(t, "mobile", s[2]), (!i || a & 1) && f(t, "reset", s[0]), (!i || a & 2) && f(t, "full-height", s[1])
        },
        i(s) {
            i || (P(e, s), i = !0)
        },
        o(s) {
            A(e, s), i = !1
        },
        d(s) {
            s && d(t), e && e.d(s), h = !1, m()
        }
    }
}

function T(l, t, o) {
    let {
        $$slots: n = {},
        $$scope: u
    } = t, {
        reset: _ = !1
    } = t, {
        fullHeight: r = !1
    } = t;
    const i = K();
    let h = B(),
        m = !1;
    const c = e => {
        i.set(e.width), h.set(e.width), o(2, m = J(e.width))
    };
    return l.$$set = e => {
        "reset" in e && o(0, _ = e.reset), "fullHeight" in e && o(1, r = e.fullHeight), "$$scope" in e && o(5, u = e.$$scope)
    }, [_, r, m, i, h, u, n, c]
}
class R extends F {
    constructor(t) {
        super(), M(this, t, T, Q, H, {
            reset: 0,
            fullHeight: 1
        })
    }
}
export {
    R as L
};