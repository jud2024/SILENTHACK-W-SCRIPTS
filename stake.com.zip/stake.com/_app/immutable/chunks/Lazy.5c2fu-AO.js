import {
    i as a
} from "./object.KBCZ3_4R.js";

function h(i) {
    return new l(i)
}
class l {
    constructor(e) {
        this.type = "lazy", this.__isYupSchema__ = !0, this.__inputType = void 0, this.__outputType = void 0, this._resolve = (r, t = {}) => {
            let s = this.builder(r, t);
            if (!a(s)) throw new TypeError("lazy() functions must return a valid schema");
            return s.resolve(t)
        }, this.builder = e
    }
    resolve(e) {
        return this._resolve(e.value, e)
    }
    cast(e, r) {
        return this._resolve(e, r).cast(e, r)
    }
    validate(e, r, t) {
        return this._resolve(e, r).validate(e, r, t)
    }
    validateSync(e, r) {
        return this._resolve(e, r).validateSync(e, r)
    }
    validateAt(e, r, t) {
        return this._resolve(r, t).validateAt(e, r, t)
    }
    validateSyncAt(e, r, t) {
        return this._resolve(r, t).validateSyncAt(e, r, t)
    }
    describe() {
        return null
    }
    isValid(e, r) {
        return this._resolve(e, r).isValid(e, r)
    }
    isValidSync(e, r) {
        return this._resolve(e, r).isValidSync(e, r)
    }
}
export {
    h as c
};