import {
    s as m,
    C as o,
    H as f,
    D as u,
    f as v,
    E as _,
    i as h,
    F as n,
    j as g,
    n as r
} from "./scheduler.DXu26z7T.js";
import {
    S as y,
    i as Z
} from "./index.Dz_MmNB3.js";

function d(i) {
    let l, s, a = ` <title>${i[1]||""}</title> <path d="M62.8 7.2h-1.2L48 12 34.401 7.2c-2.4-.8-5.199.801-5.6 3.6v10c0 2.798 2.4 4.8 4.8 4.8h1.2l13.2-6 13.598 6c2.8.8 5.2-.802 6-3.6V12c0-2.799-2.4-4.8-4.8-4.8ZM41.199 82.8l-18-60c-1.2-2.4-3.6-3.6-6.399-2.799l-6 2.001c-2.001.4-3.201 2.4-3.201 4.401l-3.6 57.6c0 2.8 2.001 4.8 4.401 5.2h27.999c2.799 0 4.8-2.002 4.8-4.8.399-.4 0-1.204 0-1.603Zm47.202-56.4c0-2-1.2-3.6-3.2-4.4l-6-2.4c-2.4-.802-5.2.398-6 2.798l-18 60c-.802 2.4.8 5.2 3.2 6 .4 0 .801.4 1.6.4h27.6c2.798 0 4.8-2.002 4.8-4.8l-4-57.598Z"></path>`,
        c;
    return {
        c() {
            l = o("svg"), s = new f(!0), this.h()
        },
        l(e) {
            l = u(e, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var t = v(l);
            s = _(t, !0), t.forEach(h), this.h()
        },
        h() {
            s.a = null, n(l, "fill", "currentColor"), n(l, "viewBox", "0 0 96 96"), n(l, "class", c = "svg-icon " + i[2]), n(l, "style", i[0])
        },
        m(e, t) {
            g(e, l, t), s.m(a, l)
        },
        p(e, [t]) {
            t & 2 && a !== (a = ` <title>${e[1]||""}</title> <path d="M62.8 7.2h-1.2L48 12 34.401 7.2c-2.4-.8-5.199.801-5.6 3.6v10c0 2.798 2.4 4.8 4.8 4.8h1.2l13.2-6 13.598 6c2.8.8 5.2-.802 6-3.6V12c0-2.799-2.4-4.8-4.8-4.8ZM41.199 82.8l-18-60c-1.2-2.4-3.6-3.6-6.399-2.799l-6 2.001c-2.001.4-3.201 2.4-3.201 4.401l-3.6 57.6c0 2.8 2.001 4.8 4.401 5.2h27.999c2.799 0 4.8-2.002 4.8-4.8.399-.4 0-1.204 0-1.603Zm47.202-56.4c0-2-1.2-3.6-3.2-4.4l-6-2.4c-2.4-.802-5.2.398-6 2.798l-18 60c-.802 2.4.8 5.2 3.2 6 .4 0 .801.4 1.6.4h27.6c2.798 0 4.8-2.002 4.8-4.8l-4-57.598Z"></path>`) && s.p(a), t & 4 && c !== (c = "svg-icon " + e[2]) && n(l, "class", c), t & 1 && n(l, "style", e[0])
        },
        i: r,
        o: r,
        d(e) {
            e && h(l)
        }
    }
}

function w(i, l, s) {
    let {
        style: a = ""
    } = l, {
        alt: c = ""
    } = l, {
        class: e = ""
    } = l;
    return i.$$set = t => {
        "style" in t && s(0, a = t.style), "alt" in t && s(1, c = t.alt), "class" in t && s(2, e = t.class)
    }, [a, c, e]
}
class C extends y {
    constructor(l) {
        super(), Z(this, l, w, d, m, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    C as L
};