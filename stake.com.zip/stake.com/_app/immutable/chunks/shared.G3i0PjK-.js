import {
    w as l
} from "./index.C2-CG2CN.js";
import {
    w as m,
    G as r
} from "./scheduler.DXu26z7T.js";
const t = l(!1),
    a = l(void 0),
    d = () => {
        let e, o;
        const s = l(!1);

        function i() {
            e && clearTimeout(e), o && clearTimeout(o)
        }

        function n() {
            clearTimeout(r(a)), i();
            const c = r(t);
            s.set(!0), c === !1 && (o = setTimeout(() => {
                t.set(!0)
            }, 250))
        }

        function u() {
            s.set(!1), clearTimeout(r(a)), i(), e = setTimeout(() => {
                t.set(!1)
            }, 750), a.set(e)
        }
        return m(() => {
            i()
        }), {
            hovering: s,
            sharedHovering: t,
            enter: n,
            leave: u
        }
    };
export {
    d as c
};