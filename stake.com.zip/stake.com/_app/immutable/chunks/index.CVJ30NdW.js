import {
    s as f,
    e as l,
    d as c,
    f as m,
    i,
    F as o,
    j as p,
    k as _,
    n as h
} from "./scheduler.DXu26z7T.js";
import {
    S as v,
    i as $,
    c as x,
    a as g,
    m as w,
    t as y,
    b as z,
    d as D
} from "./index.Dz_MmNB3.js";
import {
    R as E
} from "./index.Cakithnr.js";

function I(u) {
    let t, s, a, r;
    return a = new E({}), {
        c() {
            t = l("div"), s = l("div"), x(a.$$.fragment), this.h()
        },
        l(e) {
            t = c(e, "DIV", {
                class: !0,
                "data-test": !0,
                "data-testid": !0
            });
            var n = m(t);
            s = c(n, "DIV", {
                class: !0
            });
            var d = m(s);
            g(a.$$.fragment, d), d.forEach(i), n.forEach(i), this.h()
        },
        h() {
            o(s, "class", "content svelte-1f0wzxx"), o(t, "class", "wrap svelte-1f0wzxx"), o(t, "data-test", "modal-loader"), o(t, "data-testid", "modal-loader")
        },
        m(e, n) {
            p(e, t, n), _(t, s), w(a, s, null), r = !0
        },
        p: h,
        i(e) {
            r || (y(a.$$.fragment, e), r = !0)
        },
        o(e) {
            z(a.$$.fragment, e), r = !1
        },
        d(e) {
            e && i(t), D(a)
        }
    }
}
class S extends v {
    constructor(t) {
        super(), $(this, t, null, I, f, {})
    }
}
export {
    S as M
};