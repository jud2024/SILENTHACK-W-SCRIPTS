import {
    _ as p
} from "./preload-helper.BqjOJQfC.js";
import {
    v as d
} from "./entry.GPJbNZcP.js";
import {
    w as c,
    x as u,
    L as m,
    p as V
} from "./index.B4-7gKq3.js";
import {
    b as I,
    c as P,
    d as _,
    e as v,
    f as R
} from "./index.B81orGJm.js";
const h = {
        "vip-none": "NonVIP",
        "vip-bronze": "NonVIP",
        "vip-silver": "NonVIP",
        "vip-gold": "NonVIP",
        "vip-platinum-1": "VIP",
        "vip-platinum-2": "VIP",
        "vip-platinum-3": "VIP",
        "vip-platinum-4": "VIP",
        "vip-platinum-5": "VIP",
        "vip-platinum-6": "VIP",
        "vip-diamond-1": "VIP",
        "vip-diamond-2": "VIP",
        "vip-diamond-3": "VIP",
        "vip-diamond-4": "VIP",
        "vip-diamond-5": "VIP",
        "vip-obsidian-1": "HighValueVIP",
        "vip-obsidian-2": "HighValueVIP",
        "vip-opal-1": "HighValueVIP",
        "vip-opal-2": "HighValueVIP",
        "vip-plutonium-1": "HighValueVIP"
    },
    l = {
        NonVIP: {
            sessionSampleRateThreshold: .05,
            sessionReplayRateThreshold: 1
        },
        VIP: {
            sessionSampleRateThreshold: 10,
            sessionReplayRateThreshold: 10
        },
        HighValueVIP: {
            sessionSampleRateThreshold: 100,
            sessionReplayRateThreshold: 100
        }
    },
    T = t => h[t],
    g = t => l[t].sessionSampleRateThreshold,
    S = t => l[t].sessionReplayRateThreshold,
    y = async t => {
        const e = T(t),
            a = g(e),
            s = S(e);
        await p(async () => {
            const {
                datadogRum: o
            } = await
            import ("./main.CDxq_JzX.js");
            return {
                datadogRum: o
            }
        }, []).then(({
            datadogRum: o
        }) => {
            let r = c().toString() || u.toString();
            o.init({
                applicationId: I,
                clientToken: P,
                site: "datadoghq.com",
                actionNameAttribute: "data-analytics",
                service: "svelte-stake",
                env: `${_}-${v}-${R}`,
                sessionSampleRate: a,
                sessionReplaySampleRate: s,
                trackUserInteractions: !0,
                traceSampleRate: 20,
                trackResources: !0,
                trackLongTasks: !0,
                allowedTracingUrls: [{
                    match: i => i.includes("_api/graphql"),
                    propagatorTypes: ["tracecontext"]
                }],
                defaultPrivacyLevel: "mask-user-input",
                version: d,
                beforeSend: i => {
                    const n = i.view.url.split("/");
                    return m.includes(n[0]) && (r = n[0].toString(), n.splice(0, 1)), i.view.url = n.join("/"), !0
                }
            }), o.setGlobalContextProperty("language", r)
        })
    },
    L = () => V.subscribe(t => {
        const e = t.url.searchParams.get("modal"),
            a = t.url.searchParams.get("tab");
        e && D(`Open modal - ${e} - ${a}`)
    }),
    U = t => {
        var e, a;
        (a = (e = window == null ? void 0 : window.DD_RUM) == null ? void 0 : e.addError) == null || a.call(e, t)
    },
    D = (t, e) => {
        var a, s;
        (s = (a = window == null ? void 0 : window.DD_RUM) == null ? void 0 : a.addAction) == null || s.call(a, t, e)
    },
    O = t => {
        var e, a;
        (a = (e = window == null ? void 0 : window.DD_RUM) == null ? void 0 : e.setUser) == null || a.call(e, t)
    },
    N = (t, e) => {
        var a, s;
        (s = (a = window == null ? void 0 : window.DD_RUM) == null ? void 0 : a.setGlobalContextProperty) == null || s.call(a, t, e)
    };
export {
    D as a, N as b, U as c, L as e, y as i, O as s
};