import {
    s as c,
    a as v,
    e as d,
    d as h,
    f as g,
    i as r,
    F as u,
    a5 as _,
    V as m,
    j as y,
    u as b,
    g as B,
    b as S
} from "./scheduler.DXu26z7T.js";
import {
    S as V,
    i as j,
    t as q,
    b as C
} from "./index.Dz_MmNB3.js";

function D(i) {
    let t, n, a;
    const f = i[4].default,
        s = v(f, i, i[3], null);
    return {
        c() {
            t = d("div"), s && s.c(), this.h()
        },
        l(e) {
            t = h(e, "DIV", {
                style: !0,
                class: !0
            });
            var l = g(t);
            s && s.l(l), l.forEach(r), this.h()
        },
        h() {
            u(t, "style", i[0]), u(t, "class", n = _(i[2]) + " svelte-tgp09d"), m(t, "is-relative", i[1])
        },
        m(e, l) {
            y(e, t, l), s && s.m(t, null), a = !0
        },
        p(e, [l]) {
            s && s.p && (!a || l & 8) && b(s, f, e, e[3], a ? S(f, e[3], l, null) : B(e[3]), null), (!a || l & 1) && u(t, "style", e[0]), (!a || l & 4 && n !== (n = _(e[2]) + " svelte-tgp09d")) && u(t, "class", n), (!a || l & 6) && m(t, "is-relative", e[1])
        },
        i(e) {
            a || (q(s, e), a = !0)
        },
        o(e) {
            C(s, e), a = !1
        },
        d(e) {
            e && r(t), s && s.d(e)
        }
    }
}

function E(i, t, n) {
    let {
        $$slots: a = {},
        $$scope: f
    } = t, {
        style: s = void 0
    } = t, {
        relative: e = !1
    } = t, {
        animation: l = "scale-up"
    } = t;
    return i.$$set = o => {
        "style" in o && n(0, s = o.style), "relative" in o && n(1, e = o.relative), "animation" in o && n(2, l = o.animation), "$$scope" in o && n(3, f = o.$$scope)
    }, [s, e, l, f, a]
}
class k extends V {
    constructor(t) {
        super(), j(this, t, E, D, c, {
            style: 0,
            relative: 1,
            animation: 2
        })
    }
}
export {
    k as B
};