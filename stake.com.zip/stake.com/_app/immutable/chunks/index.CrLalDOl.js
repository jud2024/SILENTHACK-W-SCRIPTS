import {
    s as m,
    a as p,
    e as b,
    d as g,
    f as h,
    i as f,
    j as v,
    u as I,
    g as C,
    b as E,
    o as L,
    J as M
} from "./scheduler.DXu26z7T.js";
import {
    S as T,
    i as y,
    t as O,
    b as S
} from "./index.Dz_MmNB3.js";
import {
    a as V
} from "./index.B81orGJm.js";
const j = s => ({
        visible: s & 1
    }),
    _ = s => ({
        visible: s[0]
    });

function k(s) {
    let n, i;
    const a = s[3].default,
        t = p(a, s, s[2], _);
    return {
        c() {
            n = b("div"), t && t.c()
        },
        l(e) {
            n = g(e, "DIV", {});
            var o = h(n);
            t && t.l(o), o.forEach(f)
        },
        m(e, o) {
            v(e, n, o), t && t.m(n, null), s[4](n), i = !0
        },
        p(e, [o]) {
            t && t.p && (!i || o & 5) && I(t, a, e, e[2], i ? E(a, e[2], o, j) : C(e[2]), _)
        },
        i(e) {
            i || (O(t, e), i = !0)
        },
        o(e) {
            S(t, e), i = !1
        },
        d(e) {
            e && f(n), t && t.d(e), s[4](null)
        }
    }
}
let q = "100px";

function w(s, n, i) {
    let {
        $$slots: a = {},
        $$scope: t
    } = n, e = !1, o;
    L(() => {
        V && i(0, e = !0);
        let r = {
            root: null,
            rootMargin: q
        };
        const l = new IntersectionObserver(u => {
            u.forEach(d => {
                d.isIntersecting && !e && i(0, e = !0)
            })
        }, r);
        return l.observe(o), () => l.disconnect()
    });

    function c(r) {
        M[r ? "unshift" : "push"](() => {
            o = r, i(1, o)
        })
    }
    return s.$$set = r => {
        "$$scope" in r && i(2, t = r.$$scope)
    }, [e, o, t, a, c]
}
class H extends T {
    constructor(n) {
        super(), y(this, n, w, k, m, {})
    }
}
export {
    H as L
};