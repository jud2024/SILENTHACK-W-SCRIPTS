import {
    s as q,
    e as D,
    d as I,
    f as L,
    i as _,
    F as z,
    j as d,
    m as p,
    t as U,
    h as C,
    l as F,
    K as we,
    O as M,
    P,
    k as N,
    n as V,
    U as J,
    a5 as G,
    c as Te,
    a1 as ze
} from "./scheduler.DXu26z7T.js";
import {
    S as H,
    i as O,
    g as E,
    e as T,
    t as u,
    b as h,
    c as k,
    a as b,
    m as v,
    d as w
} from "./index.Dz_MmNB3.js";
import {
    e as B,
    u as W,
    o as R,
    d as Le
} from "./each.DvgCmocI.js";
import {
    g as De,
    a as Ie
} from "./spread.CgU5AtxT.js";
import {
    T as j
} from "./index.D7nbRHfU.js";
import {
    E as Be
} from "./externalLink.D-xTc-p4.js";
import "./index.ByMdEFI5.js";
import {
    L as Se
} from "./index.DJurAkTj.js";
import {
    P as Ne
} from "./Popout.fuVBZN-2.js";
import {
    T as ye
} from "./index.oTMdB5Eh.js";
import {
    g as Me
} from "./context.UnLgwODO.js";
import {
    M as Pe
} from "./index.BRT09uIB.js";
import {
    V as Ee
} from "./index.BdzuYyUh.js";
import {
    F as Ve
} from "./index.B4mPmVgF.js";

function Q(o, t, l) {
    const e = o.slice();
    return e[5] = t[l]._type, e[6] = t[l].text, e[7] = t[l].marks, e[9] = l, e
}

function qe(o) {
    var e;
    const t = o.slice(),
        l = Ge(((e = t[2]) == null ? void 0 : e.find(function(...n) {
            return o[4](t[7], ...n)
        }).href) || "");
    return t[10] = l, t
}

function Ue(o) {
    let t, l;
    return t = new j({
        props: {
            responsiveTypeScale: !0,
            inline: !0,
            size: o[0],
            lineHeight: "150pct",
            tag: o[7].includes("em") ? "em" : o[5],
            weight: o[7].includes("strong") ? "semibold" : "normal",
            $$slots: {
                default: [Fe]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            k(t.$$.fragment)
        },
        l(e) {
            b(t.$$.fragment, e)
        },
        m(e, r) {
            v(t, e, r), l = !0
        },
        p(e, r) {
            const n = {};
            r & 1 && (n.size = e[0]), r & 2 && (n.tag = e[7].includes("em") ? "em" : e[5]), r & 2 && (n.weight = e[7].includes("strong") ? "semibold" : "normal"), r & 2050 && (n.$$scope = {
                dirty: r,
                ctx: e
            }), t.$set(n)
        },
        i(e) {
            l || (u(t.$$.fragment, e), l = !0)
        },
        o(e) {
            h(t.$$.fragment, e), l = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function Ce(o) {
    let t, l, e, r;
    const n = [Oe, He],
        f = [];

    function s(i, a) {
        return i[10].external ? 0 : 1
    }
    return t = s(o), l = f[t] = n[t](o), {
        c() {
            l.c(), e = p()
        },
        l(i) {
            l.l(i), e = p()
        },
        m(i, a) {
            f[t].m(i, a), d(i, e, a), r = !0
        },
        p(i, a) {
            let c = t;
            t = s(i), t === c ? f[t].p(i, a) : (E(), h(f[c], 1, 1, () => {
                f[c] = null
            }), T(), l = f[t], l ? l.p(i, a) : (l = f[t] = n[t](i), l.c()), u(l, 1), l.m(e.parentNode, e))
        },
        i(i) {
            r || (u(l), r = !0)
        },
        o(i) {
            h(l), r = !1
        },
        d(i) {
            i && _(e), f[t].d(i)
        }
    }
}

function Fe(o) {
    let t = o[6] + "",
        l;
    return {
        c() {
            l = U(t)
        },
        l(e) {
            l = C(e, t)
        },
        m(e, r) {
            d(e, l, r)
        },
        p(e, r) {
            r & 2 && t !== (t = e[6] + "") && F(l, t)
        },
        d(e) {
            e && _(l)
        }
    }
}

function He(o) {
    let t, l;
    const e = [{
        class: "inline"
    }, {
        size: o[0]
    }, {
        variant: "subtle-link"
    }, o[10]];
    let r = {
        $$slots: {
            default: [We]
        },
        $$scope: {
            ctx: o
        }
    };
    for (let n = 0; n < e.length; n += 1) r = we(r, e[n]);
    return t = new Se({
        props: r
    }), {
        c() {
            k(t.$$.fragment)
        },
        l(n) {
            b(t.$$.fragment, n)
        },
        m(n, f) {
            v(t, n, f), l = !0
        },
        p(n, f) {
            const s = f & 7 ? De(e, [e[0], f & 1 && {
                size: n[0]
            }, e[2], f & 6 && Ie(n[10])]) : {};
            f & 2050 && (s.$$scope = {
                dirty: f,
                ctx: n
            }), t.$set(s)
        },
        i(n) {
            l || (u(t.$$.fragment, n), l = !0)
        },
        o(n) {
            h(t.$$.fragment, n), l = !1
        },
        d(n) {
            w(t, n)
        }
    }
}

function Oe(o) {
    let t, l;
    const e = [{
        class: "inline"
    }, {
        size: o[0]
    }, {
        variant: "subtle-link"
    }, o[10]];
    let r = {
        $$slots: {
            default: [Re]
        },
        $$scope: {
            ctx: o
        }
    };
    for (let n = 0; n < e.length; n += 1) r = we(r, e[n]);
    return t = new Be({
        props: r
    }), {
        c() {
            k(t.$$.fragment)
        },
        l(n) {
            b(t.$$.fragment, n)
        },
        m(n, f) {
            v(t, n, f), l = !0
        },
        p(n, f) {
            const s = f & 7 ? De(e, [e[0], f & 1 && {
                size: n[0]
            }, e[2], f & 6 && Ie(n[10])]) : {};
            f & 2050 && (s.$$scope = {
                dirty: f,
                ctx: n
            }), t.$set(s)
        },
        i(n) {
            l || (u(t.$$.fragment, n), l = !0)
        },
        o(n) {
            h(t.$$.fragment, n), l = !1
        },
        d(n) {
            w(t, n)
        }
    }
}

function We(o) {
    let t, l = o[6] + "",
        e, r;
    return {
        c() {
            t = D("span"), e = U(l), r = M()
        },
        l(n) {
            t = I(n, "SPAN", {});
            var f = L(t);
            e = C(f, l), f.forEach(_), r = P(n)
        },
        m(n, f) {
            d(n, t, f), N(t, e), d(n, r, f)
        },
        p(n, f) {
            f & 2 && l !== (l = n[6] + "") && F(e, l)
        },
        d(n) {
            n && (_(t), _(r))
        }
    }
}

function Re(o) {
    let t, l = o[6] + "",
        e, r, n, f, s;
    return n = new Ne({}), {
        c() {
            t = D("span"), e = U(l), r = M(), k(n.$$.fragment), f = M()
        },
        l(i) {
            t = I(i, "SPAN", {});
            var a = L(t);
            e = C(a, l), a.forEach(_), r = P(i), b(n.$$.fragment, i), f = P(i)
        },
        m(i, a) {
            d(i, t, a), N(t, e), d(i, r, a), v(n, i, a), d(i, f, a), s = !0
        },
        p(i, a) {
            (!s || a & 2) && l !== (l = i[6] + "") && F(e, l)
        },
        i(i) {
            s || (u(n.$$.fragment, i), s = !0)
        },
        o(i) {
            h(n.$$.fragment, i), s = !1
        },
        d(i) {
            i && (_(t), _(r), _(f)), w(n, i)
        }
    }
}

function X(o, t) {
    let l, e, r, n, f, s;

    function i(...g) {
        return t[3](t[7], ...g)
    }
    const a = [Ce, Ue],
        c = [];

    function m(g, S) {
        var y;
        return S & 6 && (e = null), e == null && (e = !!(g[7] && ((y = g[2]) != null && y.some(i)))), e ? 0 : 1
    }

    function $(g, S) {
        return S === 0 ? qe(g) : g
    }
    return r = m(t, -1), n = c[r] = a[r]($(t, r)), {
        key: o,
        first: null,
        c() {
            l = p(), n.c(), f = p(), this.h()
        },
        l(g) {
            l = p(), n.l(g), f = p(), this.h()
        },
        h() {
            this.first = l
        },
        m(g, S) {
            d(g, l, S), c[r].m(g, S), d(g, f, S), s = !0
        },
        p(g, S) {
            t = g;
            let y = r;
            r = m(t, S), r === y ? c[r].p($(t, r), S) : (E(), h(c[y], 1, 1, () => {
                c[y] = null
            }), T(), n = c[r], n ? n.p($(t, r), S) : (n = c[r] = a[r]($(t, r)), n.c()), u(n, 1), n.m(f.parentNode, f))
        },
        i(g) {
            s || (u(n), s = !0)
        },
        o(g) {
            h(n), s = !1
        },
        d(g) {
            g && (_(l), _(f)), c[r].d(g)
        }
    }
}

function je(o) {
    let t, l = [],
        e = new Map,
        r, n = B(o[1]);
    const f = s => s[9];
    for (let s = 0; s < n.length; s += 1) {
        let i = Q(o, n, s),
            a = f(i);
        e.set(a, l[s] = X(a, i))
    }
    return {
        c() {
            t = D("p");
            for (let s = 0; s < l.length; s += 1) l[s].c();
            this.h()
        },
        l(s) {
            t = I(s, "P", {
                class: !0
            });
            var i = L(t);
            for (let a = 0; a < l.length; a += 1) l[a].l(i);
            i.forEach(_), this.h()
        },
        h() {
            z(t, "class", "inline-text")
        },
        m(s, i) {
            d(s, t, i);
            for (let a = 0; a < l.length; a += 1) l[a] && l[a].m(t, null);
            r = !0
        },
        p(s, [i]) {
            i & 7 && (n = B(s[1]), E(), l = W(l, i, f, 1, s, n, e, t, R, X, null, Q), T())
        },
        i(s) {
            if (!r) {
                for (let i = 0; i < n.length; i += 1) u(l[i]);
                r = !0
            }
        },
        o(s) {
            for (let i = 0; i < l.length; i += 1) h(l[i]);
            r = !1
        },
        d(s) {
            s && _(t);
            for (let i = 0; i < l.length; i += 1) l[i].d()
        }
    }
}

function Ge(o) {
    let t = ["https://stake.com", "https://stake.us"],
        l = t.some(function(r) {
            return o.startsWith(r)
        }),
        e = l ? o.replace(t[0], "").replace(t[1], "") : o;
    return {
        external: !l && o.startsWith("/") === !1,
        to: e
    }
}

function Ke(o, t, l) {
    let {
        size: e = "md"
    } = t, {
        children: r
    } = t, {
        markDefs: n
    } = t;
    const f = (i, {
            _key: a,
            _type: c
        }) => i.includes(a) && c === "link",
        s = (i, {
            _key: a
        }) => i.includes(a);
    return o.$$set = i => {
        "size" in i && l(0, e = i.size), "children" in i && l(1, r = i.children), "markDefs" in i && l(2, n = i.markDefs)
    }, [e, r, n, f, s]
}
class K extends H {
    constructor(t) {
        super(), O(this, t, Ke, je, q, {
            size: 0,
            children: 1,
            markDefs: 2
        })
    }
}

function Y(o, t, l) {
    const e = o.slice();
    return e[7] = t[l], e[3] = l, e
}

function Z(o, t, l) {
    const e = o.slice();
    return e[1] = t[l], e[3] = l, e
}

function A(o, t, l) {
    const e = o.slice();
    return e[4] = t[l], e[6] = l, e
}

function Je(o) {
    let t = o[7] + "",
        l;
    return {
        c() {
            l = U(t)
        },
        l(e) {
            l = C(e, t)
        },
        m(e, r) {
            d(e, l, r)
        },
        p(e, r) {
            r & 1 && t !== (t = e[7] + "") && F(l, t)
        },
        d(e) {
            e && _(l)
        }
    }
}

function x(o, t) {
    let l, e, r, n;
    return e = new j({
        props: {
            tag: "span",
            weight: "bold",
            variant: "highlighted",
            $$slots: {
                default: [Je]
            },
            $$scope: {
                ctx: t
            }
        }
    }), {
        key: o,
        first: null,
        c() {
            l = D("th"), k(e.$$.fragment), r = M(), this.h()
        },
        l(f) {
            l = I(f, "TH", {});
            var s = L(l);
            b(e.$$.fragment, s), r = P(s), s.forEach(_), this.h()
        },
        h() {
            this.first = l
        },
        m(f, s) {
            d(f, l, s), v(e, l, null), N(l, r), n = !0
        },
        p(f, s) {
            t = f;
            const i = {};
            s & 513 && (i.$$scope = {
                dirty: s,
                ctx: t
            }), e.$set(i)
        },
        i(f) {
            n || (u(e.$$.fragment, f), n = !0)
        },
        o(f) {
            h(e.$$.fragment, f), n = !1
        },
        d(f) {
            f && _(l), w(e)
        }
    }
}

function Qe(o) {
    let t, l, e = [],
        r = new Map,
        n, f = B(o[0][0].cells);
    const s = i => i[3];
    for (let i = 0; i < f.length; i += 1) {
        let a = Y(o, f, i),
            c = s(a);
        r.set(c, e[i] = x(c, a))
    }
    return {
        c() {
            t = D("thead"), l = D("tr");
            for (let i = 0; i < e.length; i += 1) e[i].c();
            this.h()
        },
        l(i) {
            t = I(i, "THEAD", {
                slot: !0
            });
            var a = L(t);
            l = I(a, "TR", {});
            var c = L(l);
            for (let m = 0; m < e.length; m += 1) e[m].l(c);
            c.forEach(_), a.forEach(_), this.h()
        },
        h() {
            z(t, "slot", "thead")
        },
        m(i, a) {
            d(i, t, a), N(t, l);
            for (let c = 0; c < e.length; c += 1) e[c] && e[c].m(l, null);
            n = !0
        },
        p(i, a) {
            a & 1 && (f = B(i[0][0].cells), E(), e = W(e, a, s, 1, i, f, r, l, R, x, null, Y), T())
        },
        i(i) {
            if (!n) {
                for (let a = 0; a < f.length; a += 1) u(e[a]);
                n = !0
            }
        },
        o(i) {
            for (let a = 0; a < e.length; a += 1) h(e[a]);
            n = !1
        },
        d(i) {
            i && _(t);
            for (let a = 0; a < e.length; a += 1) e[a].d()
        }
    }
}

function Xe(o) {
    let t, l = [],
        e = new Map,
        r, n, f = B(o[1].cells);
    const s = i => i[6];
    for (let i = 0; i < f.length; i += 1) {
        let a = A(o, f, i),
            c = s(a);
        e.set(c, l[i] = ee(c, a))
    }
    return {
        c() {
            t = D("tr");
            for (let i = 0; i < l.length; i += 1) l[i].c();
            r = M()
        },
        l(i) {
            t = I(i, "TR", {});
            var a = L(t);
            for (let c = 0; c < l.length; c += 1) l[c].l(a);
            r = P(a), a.forEach(_)
        },
        m(i, a) {
            d(i, t, a);
            for (let c = 0; c < l.length; c += 1) l[c] && l[c].m(t, null);
            N(t, r), n = !0
        },
        p(i, a) {
            a & 1 && (f = B(i[1].cells), E(), l = W(l, a, s, 1, i, f, e, t, R, ee, r, A), T())
        },
        i(i) {
            if (!n) {
                for (let a = 0; a < f.length; a += 1) u(l[a]);
                n = !0
            }
        },
        o(i) {
            for (let a = 0; a < l.length; a += 1) h(l[a]);
            n = !1
        },
        d(i) {
            i && _(t);
            for (let a = 0; a < l.length; a += 1) l[a].d()
        }
    }
}

function Ye(o) {
    return {
        c: V,
        l: V,
        m: V,
        p: V,
        i: V,
        o: V,
        d: V
    }
}

function Ze(o) {
    let t = o[4] + "",
        l;
    return {
        c() {
            l = U(t)
        },
        l(e) {
            l = C(e, t)
        },
        m(e, r) {
            d(e, l, r)
        },
        p(e, r) {
            r & 1 && t !== (t = e[4] + "") && F(l, t)
        },
        d(e) {
            e && _(l)
        }
    }
}

function ee(o, t) {
    let l, e, r;
    return e = new j({
        props: {
            tag: "span",
            $$slots: {
                default: [Ze]
            },
            $$scope: {
                ctx: t
            }
        }
    }), {
        key: o,
        first: null,
        c() {
            l = D("td"), k(e.$$.fragment), this.h()
        },
        l(n) {
            l = I(n, "TD", {});
            var f = L(l);
            b(e.$$.fragment, f), f.forEach(_), this.h()
        },
        h() {
            this.first = l
        },
        m(n, f) {
            d(n, l, f), v(e, l, null), r = !0
        },
        p(n, f) {
            t = n;
            const s = {};
            f & 513 && (s.$$scope = {
                dirty: f,
                ctx: t
            }), e.$set(s)
        },
        i(n) {
            r || (u(e.$$.fragment, n), r = !0)
        },
        o(n) {
            h(e.$$.fragment, n), r = !1
        },
        d(n) {
            n && _(l), w(e)
        }
    }
}

function te(o, t) {
    let l, e, r, n, f;
    const s = [Ye, Xe],
        i = [];

    function a(c, m) {
        return c[3] === 0 ? 0 : 1
    }
    return e = a(t), r = i[e] = s[e](t), {
        key: o,
        first: null,
        c() {
            l = p(), r.c(), n = p(), this.h()
        },
        l(c) {
            l = p(), r.l(c), n = p(), this.h()
        },
        h() {
            this.first = l
        },
        m(c, m) {
            d(c, l, m), i[e].m(c, m), d(c, n, m), f = !0
        },
        p(c, m) {
            t = c;
            let $ = e;
            e = a(t), e === $ ? i[e].p(t, m) : (E(), h(i[$], 1, 1, () => {
                i[$] = null
            }), T(), r = i[e], r ? r.p(t, m) : (r = i[e] = s[e](t), r.c()), u(r, 1), r.m(n.parentNode, n))
        },
        i(c) {
            f || (u(r), f = !0)
        },
        o(c) {
            h(r), f = !1
        },
        d(c) {
            c && (_(l), _(n)), i[e].d(c)
        }
    }
}

function Ae(o) {
    let t = [],
        l = new Map,
        e, r, n = B(o[0]);
    const f = s => s[3];
    for (let s = 0; s < n.length; s += 1) {
        let i = Z(o, n, s),
            a = f(i);
        l.set(a, t[s] = te(a, i))
    }
    return {
        c() {
            for (let s = 0; s < t.length; s += 1) t[s].c();
            e = p()
        },
        l(s) {
            for (let i = 0; i < t.length; i += 1) t[i].l(s);
            e = p()
        },
        m(s, i) {
            for (let a = 0; a < t.length; a += 1) t[a] && t[a].m(s, i);
            d(s, e, i), r = !0
        },
        p(s, i) {
            i & 1 && (n = B(s[0]), E(), t = W(t, i, f, 1, s, n, l, e.parentNode, R, te, e, Z), T())
        },
        i(s) {
            if (!r) {
                for (let i = 0; i < n.length; i += 1) u(t[i]);
                r = !0
            }
        },
        o(s) {
            for (let i = 0; i < t.length; i += 1) h(t[i]);
            r = !1
        },
        d(s) {
            s && _(e);
            for (let i = 0; i < t.length; i += 1) t[i].d(s)
        }
    }
}

function xe(o) {
    let t, l, e;
    return l = new ye({
        props: {
            $$slots: {
                body: [Ae],
                thead: [Qe]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            t = D("div"), k(l.$$.fragment), this.h()
        },
        l(r) {
            t = I(r, "DIV", {
                class: !0
            });
            var n = L(t);
            b(l.$$.fragment, n), n.forEach(_), this.h()
        },
        h() {
            z(t, "class", "table-wrap svelte-1et1lpi")
        },
        m(r, n) {
            d(r, t, n), v(l, t, null), e = !0
        },
        p(r, [n]) {
            const f = {};
            n & 513 && (f.$$scope = {
                dirty: n,
                ctx: r
            }), l.$set(f)
        },
        i(r) {
            e || (u(l.$$.fragment, r), e = !0)
        },
        o(r) {
            h(l.$$.fragment, r), e = !1
        },
        d(r) {
            r && _(t), w(l)
        }
    }
}

function et(o, t, l) {
    let {
        rows: e
    } = t;
    return o.$$set = r => {
        "rows" in r && l(0, e = r.rows)
    }, [e]
}
class tt extends H {
    constructor(t) {
        super(), O(this, t, et, xe, q, {
            rows: 0
        })
    }
}

function le(o, t, l) {
    const e = o.slice();
    return e[3] = t[l].text, e[5] = l, e
}

function re(o, t) {
    let l, e = t[3] + "",
        r, n, f;
    return {
        key: o,
        first: null,
        c() {
            l = D("span"), r = U(e), n = M(), this.h()
        },
        l(s) {
            l = I(s, "SPAN", {
                id: !0
            });
            var i = L(l);
            r = C(i, e), n = P(i), i.forEach(_), this.h()
        },
        h() {
            z(l, "id", f = t[3].replace(/\s/g, "_")), this.first = l
        },
        m(s, i) {
            d(s, l, i), N(l, r), N(l, n)
        },
        p(s, i) {
            t = s, i & 1 && e !== (e = t[3] + "") && F(r, e), i & 1 && f !== (f = t[3].replace(/\s/g, "_")) && z(l, "id", f)
        },
        d(s) {
            s && _(l)
        }
    }
}

function lt(o) {
    let t = [],
        l = new Map,
        e, r = B(o[0]);
    const n = f => f[5];
    for (let f = 0; f < r.length; f += 1) {
        let s = le(o, r, f),
            i = n(s);
        l.set(i, t[f] = re(i, s))
    }
    return {
        c() {
            for (let f = 0; f < t.length; f += 1) t[f].c();
            e = p()
        },
        l(f) {
            for (let s = 0; s < t.length; s += 1) t[s].l(f);
            e = p()
        },
        m(f, s) {
            for (let i = 0; i < t.length; i += 1) t[i] && t[i].m(f, s);
            d(f, e, s)
        },
        p(f, s) {
            s & 1 && (r = B(f[0]), t = W(t, s, n, 1, f, r, l, e.parentNode, Le, re, e, le))
        },
        d(f) {
            f && _(e);
            for (let s = 0; s < t.length; s += 1) t[s].d(f)
        }
    }
}

function rt(o) {
    let t, l;
    return t = new j({
        props: {
            inline: !0,
            tag: o[1],
            size: o[2],
            variant: "highlighted",
            responsiveTypeScale: !0,
            $$slots: {
                default: [lt]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            k(t.$$.fragment)
        },
        l(e) {
            b(t.$$.fragment, e)
        },
        m(e, r) {
            v(t, e, r), l = !0
        },
        p(e, [r]) {
            const n = {};
            r & 2 && (n.tag = e[1]), r & 4 && (n.size = e[2]), r & 65 && (n.$$scope = {
                dirty: r,
                ctx: e
            }), t.$set(n)
        },
        i(e) {
            l || (u(t.$$.fragment, e), l = !0)
        },
        o(e) {
            h(t.$$.fragment, e), l = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function nt(o, t, l) {
    let {
        children: e
    } = t, {
        tag: r
    } = t, {
        size: n
    } = t;
    return o.$$set = f => {
        "children" in f && l(0, e = f.children), "tag" in f && l(1, r = f.tag), "size" in f && l(2, n = f.size)
    }, [e, r, n]
}
class it extends H {
    constructor(t) {
        super(), O(this, t, nt, rt, q, {
            children: 0,
            tag: 1,
            size: 2
        })
    }
}

function st(o) {
    let t, l, e, r;
    return {
        c() {
            t = D("div"), l = D("img"), this.h()
        },
        l(n) {
            t = I(n, "DIV", {
                class: !0
            });
            var f = L(t);
            l = I(f, "IMG", {
                class: !0,
                alt: !0,
                src: !0
            }), f.forEach(_), this.h()
        },
        h() {
            var n, f;
            z(l, "class", "thumbnail svelte-1oxio9w"), z(l, "alt", e = (n = o[0]) == null ? void 0 : n.altText), J(l.src, r = ((f = o[0]) == null ? void 0 : f.url) + "?q=80&auto=format") || z(l, "src", r), z(t, "class", "thumbnail-wrapper")
        },
        m(n, f) {
            d(n, t, f), N(t, l)
        },
        p(n, [f]) {
            var s, i;
            f & 1 && e !== (e = (s = n[0]) == null ? void 0 : s.altText) && z(l, "alt", e), f & 1 && !J(l.src, r = ((i = n[0]) == null ? void 0 : i.url) + "?q=80&auto=format") && z(l, "src", r)
        },
        i: V,
        o: V,
        d(n) {
            n && _(t)
        }
    }
}

function ft(o, t, l) {
    let {
        image: e
    } = t;
    return o.$$set = r => {
        "image" in r && l(0, e = r.image)
    }, [e]
}
class ot extends H {
    constructor(t) {
        super(), O(this, t, ft, st, q, {
            image: 0
        })
    }
}

function ne(o, t, l) {
    const e = o.slice();
    return e[2] = t[l], e[4] = l, e
}

function ie(o, t) {
    let l, e, r, n, f;
    return e = new K({
        props: {
            children: t[2].children,
            markDefs: t[2].markDefs,
            size: t[1]
        }
    }), {
        key: o,
        first: null,
        c() {
            l = D("li"), k(e.$$.fragment), r = M(), this.h()
        },
        l(s) {
            l = I(s, "LI", {
                class: !0
            });
            var i = L(l);
            b(e.$$.fragment, i), r = P(i), i.forEach(_), this.h()
        },
        h() {
            var s;
            z(l, "class", n = G(`level-${(s=t[2])==null?void 0:s.level}`) + " svelte-fae7ut"), this.first = l
        },
        m(s, i) {
            d(s, l, i), v(e, l, null), N(l, r), f = !0
        },
        p(s, i) {
            var c;
            t = s;
            const a = {};
            i & 1 && (a.children = t[2].children), i & 1 && (a.markDefs = t[2].markDefs), i & 2 && (a.size = t[1]), e.$set(a), (!f || i & 1 && n !== (n = G(`level-${(c=t[2])==null?void 0:c.level}`) + " svelte-fae7ut")) && z(l, "class", n)
        },
        i(s) {
            f || (u(e.$$.fragment, s), f = !0)
        },
        o(s) {
            h(e.$$.fragment, s), f = !1
        },
        d(s) {
            s && _(l), w(e)
        }
    }
}

function at(o) {
    let t, l = [],
        e = new Map,
        r, n = B(o[0]);
    const f = s => s[4];
    for (let s = 0; s < n.length; s += 1) {
        let i = ne(o, n, s),
            a = f(i);
        e.set(a, l[s] = ie(a, i))
    }
    return {
        c() {
            t = D("ul");
            for (let s = 0; s < l.length; s += 1) l[s].c();
            this.h()
        },
        l(s) {
            t = I(s, "UL", {
                class: !0
            });
            var i = L(t);
            for (let a = 0; a < l.length; a += 1) l[a].l(i);
            i.forEach(_), this.h()
        },
        h() {
            z(t, "class", "svelte-fae7ut")
        },
        m(s, i) {
            d(s, t, i);
            for (let a = 0; a < l.length; a += 1) l[a] && l[a].m(t, null);
            r = !0
        },
        p(s, [i]) {
            i & 3 && (n = B(s[0]), E(), l = W(l, i, f, 1, s, n, e, t, R, ie, null, ne), T())
        },
        i(s) {
            if (!r) {
                for (let i = 0; i < n.length; i += 1) u(l[i]);
                r = !0
            }
        },
        o(s) {
            for (let i = 0; i < l.length; i += 1) h(l[i]);
            r = !1
        },
        d(s) {
            s && _(t);
            for (let i = 0; i < l.length; i += 1) l[i].d()
        }
    }
}

function ct(o, t, l) {
    let {
        blocks: e
    } = t, {
        size: r = "base"
    } = t;
    return o.$$set = n => {
        "blocks" in n && l(0, e = n.blocks), "size" in n && l(1, r = n.size)
    }, [e, r]
}
class ut extends H {
    constructor(t) {
        super(), O(this, t, ct, at, q, {
            blocks: 0,
            size: 1
        })
    }
}

function se(o, t, l) {
    const e = o.slice();
    return e[2] = t[l], e[4] = l, e
}

function fe(o, t) {
    let l, e, r, n, f;
    return e = new K({
        props: {
            children: t[2].children,
            markDefs: t[2].markDefs,
            size: t[1]
        }
    }), {
        key: o,
        first: null,
        c() {
            l = D("li"), k(e.$$.fragment), r = M(), this.h()
        },
        l(s) {
            l = I(s, "LI", {
                class: !0
            });
            var i = L(l);
            b(e.$$.fragment, i), r = P(i), i.forEach(_), this.h()
        },
        h() {
            var s;
            z(l, "class", n = G(`level-${(s=t[2])==null?void 0:s.level}`) + " svelte-rusq0o"), this.first = l
        },
        m(s, i) {
            d(s, l, i), v(e, l, null), N(l, r), f = !0
        },
        p(s, i) {
            var c;
            t = s;
            const a = {};
            i & 1 && (a.children = t[2].children), i & 1 && (a.markDefs = t[2].markDefs), i & 2 && (a.size = t[1]), e.$set(a), (!f || i & 1 && n !== (n = G(`level-${(c=t[2])==null?void 0:c.level}`) + " svelte-rusq0o")) && z(l, "class", n)
        },
        i(s) {
            f || (u(e.$$.fragment, s), f = !0)
        },
        o(s) {
            h(e.$$.fragment, s), f = !1
        },
        d(s) {
            s && _(l), w(e)
        }
    }
}

function _t(o) {
    let t, l = [],
        e = new Map,
        r, n = B(o[0]);
    const f = s => s[4];
    for (let s = 0; s < n.length; s += 1) {
        let i = se(o, n, s),
            a = f(i);
        e.set(a, l[s] = fe(a, i))
    }
    return {
        c() {
            t = D("ol");
            for (let s = 0; s < l.length; s += 1) l[s].c();
            this.h()
        },
        l(s) {
            t = I(s, "OL", {
                class: !0
            });
            var i = L(t);
            for (let a = 0; a < l.length; a += 1) l[a].l(i);
            i.forEach(_), this.h()
        },
        h() {
            z(t, "class", "svelte-rusq0o")
        },
        m(s, i) {
            d(s, t, i);
            for (let a = 0; a < l.length; a += 1) l[a] && l[a].m(t, null);
            r = !0
        },
        p(s, [i]) {
            i & 3 && (n = B(s[0]), E(), l = W(l, i, f, 1, s, n, e, t, R, fe, null, se), T())
        },
        i(s) {
            if (!r) {
                for (let i = 0; i < n.length; i += 1) u(l[i]);
                r = !0
            }
        },
        o(s) {
            for (let i = 0; i < l.length; i += 1) h(l[i]);
            r = !1
        },
        d(s) {
            s && _(t);
            for (let i = 0; i < l.length; i += 1) l[i].d()
        }
    }
}

function ht(o, t, l) {
    let {
        blocks: e
    } = t, {
        size: r = "base"
    } = t;
    return o.$$set = n => {
        "blocks" in n && l(0, e = n.blocks), "size" in n && l(1, r = n.size)
    }, [e, r]
}
class mt extends H {
    constructor(t) {
        super(), O(this, t, ht, _t, q, {
            blocks: 0,
            size: 1
        })
    }
}

function oe(o) {
    let t, l;
    return t = new j({
        props: {
            variant: "subtle",
            tag: "h3",
            $$slots: {
                default: [gt]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            k(t.$$.fragment)
        },
        l(e) {
            b(t.$$.fragment, e)
        },
        m(e, r) {
            v(t, e, r), l = !0
        },
        p(e, r) {
            const n = {};
            r & 17 && (n.$$scope = {
                dirty: r,
                ctx: e
            }), t.$set(n)
        },
        i(e) {
            l || (u(t.$$.fragment, e), l = !0)
        },
        o(e) {
            h(t.$$.fragment, e), l = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function gt(o) {
    let t = o[0].title + "",
        l;
    return {
        c() {
            l = U(t)
        },
        l(e) {
            l = C(e, t)
        },
        m(e, r) {
            d(e, l, r)
        },
        p(e, r) {
            r & 1 && t !== (t = e[0].title + "") && F(l, t)
        },
        d(e) {
            e && _(l)
        }
    }
}

function ae(o) {
    let t, l;
    return t = new j({
        props: {
            $$slots: {
                default: [dt]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            k(t.$$.fragment)
        },
        l(e) {
            b(t.$$.fragment, e)
        },
        m(e, r) {
            v(t, e, r), l = !0
        },
        p(e, r) {
            const n = {};
            r & 17 && (n.$$scope = {
                dirty: r,
                ctx: e
            }), t.$set(n)
        },
        i(e) {
            l || (u(t.$$.fragment, e), l = !0)
        },
        o(e) {
            h(t.$$.fragment, e), l = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function dt(o) {
    let t = o[0].description + "",
        l;
    return {
        c() {
            l = U(t)
        },
        l(e) {
            l = C(e, t)
        },
        m(e, r) {
            d(e, l, r)
        },
        p(e, r) {
            r & 1 && t !== (t = e[0].description + "") && F(l, t)
        },
        d(e) {
            e && _(l)
        }
    }
}

function ce(o) {
    let t, l;
    return t = new Pe({
        props: {
            stacked: o[1],
            marketId: o[0].marketId
        }
    }), {
        c() {
            k(t.$$.fragment)
        },
        l(e) {
            b(t.$$.fragment, e)
        },
        m(e, r) {
            v(t, e, r), l = !0
        },
        p(e, r) {
            const n = {};
            r & 2 && (n.stacked = e[1]), r & 1 && (n.marketId = e[0].marketId), t.$set(n)
        },
        i(e) {
            l || (u(t.$$.fragment, e), l = !0)
        },
        o(e) {
            h(t.$$.fragment, e), l = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function $t(o) {
    var c, m;
    let t, l, e, r, n, f, s = ((c = o[0]) == null ? void 0 : c.title) && oe(o),
        i = ((m = o[0]) == null ? void 0 : m.description) && ae(o),
        a = o[0].marketId && ce(o);
    return {
        c() {
            t = D("div"), s && s.c(), l = M(), i && i.c(), e = M(), r = D("div"), n = D("div"), a && a.c(), this.h()
        },
        l($) {
            t = I($, "DIV", {
                class: !0
            });
            var g = L(t);
            s && s.l(g), l = P(g), i && i.l(g), e = P(g), r = I(g, "DIV", {
                class: !0
            });
            var S = L(r);
            n = I(S, "DIV", {
                class: !0
            });
            var y = L(n);
            a && a.l(y), y.forEach(_), S.forEach(_), g.forEach(_), this.h()
        },
        h() {
            z(n, "class", "outcome-wrapper svelte-22b2ce"), z(r, "class", "outcome-wrap svelte-22b2ce"), z(t, "class", "news-market svelte-22b2ce")
        },
        m($, g) {
            d($, t, g), s && s.m(t, null), N(t, l), i && i.m(t, null), N(t, e), N(t, r), N(r, n), a && a.m(n, null), f = !0
        },
        p($, [g]) {
            var S, y;
            (S = $[0]) != null && S.title ? s ? (s.p($, g), g & 1 && u(s, 1)) : (s = oe($), s.c(), u(s, 1), s.m(t, l)) : s && (E(), h(s, 1, 1, () => {
                s = null
            }), T()), (y = $[0]) != null && y.description ? i ? (i.p($, g), g & 1 && u(i, 1)) : (i = ae($), i.c(), u(i, 1), i.m(t, e)) : i && (E(), h(i, 1, 1, () => {
                i = null
            }), T()), $[0].marketId ? a ? (a.p($, g), g & 1 && u(a, 1)) : (a = ce($), a.c(), u(a, 1), a.m(n, null)) : a && (E(), h(a, 1, 1, () => {
                a = null
            }), T())
        },
        i($) {
            f || (u(s), u(i), u(a), f = !0)
        },
        o($) {
            h(s), h(i), h(a), f = !1
        },
        d($) {
            $ && _(t), s && s.d(), i && i.d(), a && a.d()
        }
    }
}

function pt(o, t, l) {
    let e, r, {
        market: n
    } = t;
    const f = Me();
    return Te(o, f, s => l(3, r = s)), o.$$set = s => {
        "market" in s && l(0, n = s.market)
    }, o.$$.update = () => {
        o.$$.dirty & 8 && l(1, e = r < 600)
    }, [n, e, f, r]
}
class kt extends H {
    constructor(t) {
        super(), O(this, t, pt, $t, q, {
            market: 0
        })
    }
}
const bt = o => {
    var e;
    let t = {
        listTag: null,
        listBlocks: []
    };
    const l = [];
    if (o != null && o.length)
        for (let r = 0; r < o.length; r++) {
            const n = o[r];
            ((n == null ? void 0 : n.listItem) === void 0 || (n == null ? void 0 : n.listItem) !== ((e = o[r - 1]) == null ? void 0 : e.listItem)) && (t.listBlocks.length && l.push(t), t = {
                listTag: null,
                listBlocks: []
            }), (n == null ? void 0 : n.listItem) === void 0 ? l.push(n) : (n == null ? void 0 : n.listItem) === "bullet" ? (t.listTag = "ul", t.listBlocks = [...t.listBlocks, n]) : (n == null ? void 0 : n.listItem) === "number" && (t.listTag = "ol", t.listBlocks = [...t.listBlocks, n]), r + 1 === o.length && t.listBlocks.length && l.push(t)
        }
    return l
};

function ue(o, t, l) {
    const e = o.slice();
    return e[7] = t[l], e[9] = l, e
}

function _e(o, t, l) {
    const e = o.slice();
    return e[13] = t[l], e
}

function he(o, t, l) {
    const e = o.slice();
    return e[10] = t[l], e
}

function vt(o) {
    var e, r;
    let t, l;
    return t = new K({
        props: {
            children: (e = o[7]) == null ? void 0 : e.children,
            markDefs: (r = o[7]) == null ? void 0 : r.markDefs,
            size: o[1]
        }
    }), {
        c() {
            k(t.$$.fragment)
        },
        l(n) {
            b(t.$$.fragment, n)
        },
        m(n, f) {
            v(t, n, f), l = !0
        },
        p(n, f) {
            var i, a;
            const s = {};
            f & 16 && (s.children = (i = n[7]) == null ? void 0 : i.children), f & 16 && (s.markDefs = (a = n[7]) == null ? void 0 : a.markDefs), f & 2 && (s.size = n[1]), t.$set(s)
        },
        i(n) {
            l || (u(t.$$.fragment, n), l = !0)
        },
        o(n) {
            h(t.$$.fragment, n), l = !1
        },
        d(n) {
            w(t, n)
        }
    }
}

function wt(o) {
    let t, l;
    return t = new it({
        props: {
            tag: o[7].style,
            size: o[0],
            children: o[7].children
        }
    }), {
        c() {
            k(t.$$.fragment)
        },
        l(e) {
            b(t.$$.fragment, e)
        },
        m(e, r) {
            v(t, e, r), l = !0
        },
        p(e, r) {
            const n = {};
            r & 16 && (n.tag = e[7].style), r & 1 && (n.size = e[0]), r & 16 && (n.children = e[7].children), t.$set(n)
        },
        i(e) {
            l || (u(t.$$.fragment, e), l = !0)
        },
        o(e) {
            h(t.$$.fragment, e), l = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function zt(o) {
    let t, l;
    return t = new K({
        props: {
            children: o[7].children,
            markDefs: o[7].markDefs,
            size: o[1]
        }
    }), {
        c() {
            k(t.$$.fragment)
        },
        l(e) {
            b(t.$$.fragment, e)
        },
        m(e, r) {
            v(t, e, r), l = !0
        },
        p(e, r) {
            const n = {};
            r & 16 && (n.children = e[7].children), r & 16 && (n.markDefs = e[7].markDefs), r & 2 && (n.size = e[1]), t.$set(n)
        },
        i(e) {
            l || (u(t.$$.fragment, e), l = !0)
        },
        o(e) {
            h(t.$$.fragment, e), l = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function Dt(o) {
    let t, l;
    return t = new Ee({
        props: {
            type: o[7]._type,
            src: o[7].youtubeID
        }
    }), {
        c() {
            k(t.$$.fragment)
        },
        l(e) {
            b(t.$$.fragment, e)
        },
        m(e, r) {
            v(t, e, r), l = !0
        },
        p(e, r) {
            const n = {};
            r & 16 && (n.type = e[7]._type), r & 16 && (n.src = e[7].youtubeID), t.$set(n)
        },
        i(e) {
            l || (u(t.$$.fragment, e), l = !0)
        },
        o(e) {
            h(t.$$.fragment, e), l = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function It(o) {
    let t, l;
    return t = new Ee({
        props: {
            type: o[7]._type,
            src: "https://player.vimeo.com/video/" + o[7].vimeoId + "?title=0&byline=0&portrait=0"
        }
    }), {
        c() {
            k(t.$$.fragment)
        },
        l(e) {
            b(t.$$.fragment, e)
        },
        m(e, r) {
            v(t, e, r), l = !0
        },
        p(e, r) {
            const n = {};
            r & 16 && (n.type = e[7]._type), r & 16 && (n.src = "https://player.vimeo.com/video/" + e[7].vimeoId + "?title=0&byline=0&portrait=0"), t.$set(n)
        },
        i(e) {
            l || (u(t.$$.fragment, e), l = !0)
        },
        o(e) {
            h(t.$$.fragment, e), l = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function Et(o) {
    let t, l, e = o[2] && me(o);
    return {
        c() {
            e && e.c(), t = p()
        },
        l(r) {
            e && e.l(r), t = p()
        },
        m(r, n) {
            e && e.m(r, n), d(r, t, n), l = !0
        },
        p(r, n) {
            r[2] ? e ? (e.p(r, n), n & 4 && u(e, 1)) : (e = me(r), e.c(), u(e, 1), e.m(t.parentNode, t)) : e && (E(), h(e, 1, 1, () => {
                e = null
            }), T())
        },
        i(r) {
            l || (u(e), l = !0)
        },
        o(r) {
            h(e), l = !1
        },
        d(r) {
            r && _(t), e && e.d(r)
        }
    }
}

function Tt(o) {
    let t, l, e = o[3] && pe(o);
    return {
        c() {
            e && e.c(), t = p()
        },
        l(r) {
            e && e.l(r), t = p()
        },
        m(r, n) {
            e && e.m(r, n), d(r, t, n), l = !0
        },
        p(r, n) {
            r[3] ? e ? (e.p(r, n), n & 8 && u(e, 1)) : (e = pe(r), e.c(), u(e, 1), e.m(t.parentNode, t)) : e && (E(), h(e, 1, 1, () => {
                e = null
            }), T())
        },
        i(r) {
            l || (u(e), l = !0)
        },
        o(r) {
            h(e), l = !1
        },
        d(r) {
            r && _(t), e && e.d(r)
        }
    }
}

function Lt(o) {
    let t, l;
    return t = new ot({
        props: {
            image: o[7].asset
        }
    }), {
        c() {
            k(t.$$.fragment)
        },
        l(e) {
            b(t.$$.fragment, e)
        },
        m(e, r) {
            v(t, e, r), l = !0
        },
        p(e, r) {
            const n = {};
            r & 16 && (n.image = e[7].asset), t.$set(n)
        },
        i(e) {
            l || (u(t.$$.fragment, e), l = !0)
        },
        o(e) {
            h(t.$$.fragment, e), l = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function Bt(o) {
    let t, l;
    return t = new tt({
        props: {
            rows: o[7].rows
        }
    }), {
        c() {
            k(t.$$.fragment)
        },
        l(e) {
            b(t.$$.fragment, e)
        },
        m(e, r) {
            v(t, e, r), l = !0
        },
        p(e, r) {
            const n = {};
            r & 16 && (n.rows = e[7].rows), t.$set(n)
        },
        i(e) {
            l || (u(t.$$.fragment, e), l = !0)
        },
        o(e) {
            h(t.$$.fragment, e), l = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function St(o) {
    let t, l;
    return t = new mt({
        props: {
            blocks: o[7].listBlocks,
            size: o[1]
        }
    }), {
        c() {
            k(t.$$.fragment)
        },
        l(e) {
            b(t.$$.fragment, e)
        },
        m(e, r) {
            v(t, e, r), l = !0
        },
        p(e, r) {
            const n = {};
            r & 16 && (n.blocks = e[7].listBlocks), r & 2 && (n.size = e[1]), t.$set(n)
        },
        i(e) {
            l || (u(t.$$.fragment, e), l = !0)
        },
        o(e) {
            h(t.$$.fragment, e), l = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function Nt(o) {
    let t, l;
    return t = new ut({
        props: {
            blocks: o[7].listBlocks,
            size: o[1]
        }
    }), {
        c() {
            k(t.$$.fragment)
        },
        l(e) {
            b(t.$$.fragment, e)
        },
        m(e, r) {
            v(t, e, r), l = !0
        },
        p(e, r) {
            const n = {};
            r & 16 && (n.blocks = e[7].listBlocks), r & 2 && (n.size = e[1]), t.$set(n)
        },
        i(e) {
            l || (u(t.$$.fragment, e), l = !0)
        },
        o(e) {
            h(t.$$.fragment, e), l = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function me(o) {
    let t, l, e = B(o[2]),
        r = [];
    for (let f = 0; f < e.length; f += 1) r[f] = $e(_e(o, e, f));
    const n = f => h(r[f], 1, 1, () => {
        r[f] = null
    });
    return {
        c() {
            for (let f = 0; f < r.length; f += 1) r[f].c();
            t = p()
        },
        l(f) {
            for (let s = 0; s < r.length; s += 1) r[s].l(f);
            t = p()
        },
        m(f, s) {
            for (let i = 0; i < r.length; i += 1) r[i] && r[i].m(f, s);
            d(f, t, s), l = !0
        },
        p(f, s) {
            if (s & 20) {
                e = B(f[2]);
                let i;
                for (i = 0; i < e.length; i += 1) {
                    const a = _e(f, e, i);
                    r[i] ? (r[i].p(a, s), u(r[i], 1)) : (r[i] = $e(a), r[i].c(), u(r[i], 1), r[i].m(t.parentNode, t))
                }
                for (E(), i = e.length; i < r.length; i += 1) n(i);
                T()
            }
        },
        i(f) {
            if (!l) {
                for (let s = 0; s < e.length; s += 1) u(r[s]);
                l = !0
            }
        },
        o(f) {
            r = r.filter(Boolean);
            for (let s = 0; s < r.length; s += 1) h(r[s]);
            l = !1
        },
        d(f) {
            f && _(t), ze(r, f)
        }
    }
}

function ge(o) {
    let t, l, e, r = o[13] && de(o);
    return {
        c() {
            t = D("div"), r && r.c(), l = M(), this.h()
        },
        l(n) {
            t = I(n, "DIV", {
                class: !0
            });
            var f = L(t);
            r && r.l(f), l = P(f), f.forEach(_), this.h()
        },
        h() {
            z(t, "class", "group")
        },
        m(n, f) {
            d(n, t, f), r && r.m(t, null), N(t, l), e = !0
        },
        p(n, f) {
            n[13] ? r ? (r.p(n, f), f & 4 && u(r, 1)) : (r = de(n), r.c(), u(r, 1), r.m(t, l)) : r && (E(), h(r, 1, 1, () => {
                r = null
            }), T())
        },
        i(n) {
            e || (u(r), e = !0)
        },
        o(n) {
            h(r), e = !1
        },
        d(n) {
            n && _(t), r && r.d()
        }
    }
}

function de(o) {
    let t, l;
    return t = new Ve({
        props: {
            isOpenByDefault: !0,
            addTimeElements: !0,
            removePadding: !0,
            group: o[13].group,
            loading: !1,
            name: o[13].name,
            fixtureCount: o[13].activeFixtureCount,
            fixtureList: o[13].fixtureList,
            sortedTemplates: o[13].category.sport.templates || []
        }
    }), {
        c() {
            k(t.$$.fragment)
        },
        l(e) {
            b(t.$$.fragment, e)
        },
        m(e, r) {
            v(t, e, r), l = !0
        },
        p(e, r) {
            const n = {};
            r & 4 && (n.group = e[13].group), r & 4 && (n.name = e[13].name), r & 4 && (n.fixtureCount = e[13].activeFixtureCount), r & 4 && (n.fixtureList = e[13].fixtureList), r & 4 && (n.sortedTemplates = e[13].category.sport.templates || []), t.$set(n)
        },
        i(e) {
            l || (u(t.$$.fragment, e), l = !0)
        },
        o(e) {
            h(t.$$.fragment, e), l = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function $e(o) {
    let t, l, e = o[13].slug === o[7].tournament && ge(o);
    return {
        c() {
            e && e.c(), t = p()
        },
        l(r) {
            e && e.l(r), t = p()
        },
        m(r, n) {
            e && e.m(r, n), d(r, t, n), l = !0
        },
        p(r, n) {
            r[13].slug === r[7].tournament ? e ? (e.p(r, n), n & 20 && u(e, 1)) : (e = ge(r), e.c(), u(e, 1), e.m(t.parentNode, t)) : e && (E(), h(e, 1, 1, () => {
                e = null
            }), T())
        },
        i(r) {
            l || (u(e), l = !0)
        },
        o(r) {
            h(e), l = !1
        },
        d(r) {
            r && _(t), e && e.d(r)
        }
    }
}

function pe(o) {
    let t, l, e = B(o[3]),
        r = [];
    for (let f = 0; f < e.length; f += 1) r[f] = be(he(o, e, f));
    const n = f => h(r[f], 1, 1, () => {
        r[f] = null
    });
    return {
        c() {
            for (let f = 0; f < r.length; f += 1) r[f].c();
            t = p()
        },
        l(f) {
            for (let s = 0; s < r.length; s += 1) r[s].l(f);
            t = p()
        },
        m(f, s) {
            for (let i = 0; i < r.length; i += 1) r[i] && r[i].m(f, s);
            d(f, t, s), l = !0
        },
        p(f, s) {
            if (s & 24) {
                e = B(f[3]);
                let i;
                for (i = 0; i < e.length; i += 1) {
                    const a = he(f, e, i);
                    r[i] ? (r[i].p(a, s), u(r[i], 1)) : (r[i] = be(a), r[i].c(), u(r[i], 1), r[i].m(t.parentNode, t))
                }
                for (E(), i = e.length; i < r.length; i += 1) n(i);
                T()
            }
        },
        i(f) {
            if (!l) {
                for (let s = 0; s < e.length; s += 1) u(r[s]);
                l = !0
            }
        },
        o(f) {
            r = r.filter(Boolean);
            for (let s = 0; s < r.length; s += 1) h(r[s]);
            l = !1
        },
        d(f) {
            f && _(t), ze(r, f)
        }
    }
}

function ke(o) {
    let t, l;
    return t = new kt({
        props: {
            market: o[10]
        }
    }), {
        c() {
            k(t.$$.fragment)
        },
        l(e) {
            b(t.$$.fragment, e)
        },
        m(e, r) {
            v(t, e, r), l = !0
        },
        p(e, r) {
            const n = {};
            r & 8 && (n.market = e[10]), t.$set(n)
        },
        i(e) {
            l || (u(t.$$.fragment, e), l = !0)
        },
        o(e) {
            h(t.$$.fragment, e), l = !1
        },
        d(e) {
            w(t, e)
        }
    }
}

function be(o) {
    var r, n;
    let t, l, e = ((r = o[10]) == null ? void 0 : r.id) === ((n = o[7]) == null ? void 0 : n.marketId) && ke(o);
    return {
        c() {
            e && e.c(), t = p()
        },
        l(f) {
            e && e.l(f), t = p()
        },
        m(f, s) {
            e && e.m(f, s), d(f, t, s), l = !0
        },
        p(f, s) {
            var i, a;
            ((i = f[10]) == null ? void 0 : i.id) === ((a = f[7]) == null ? void 0 : a.marketId) ? e ? (e.p(f, s), s & 24 && u(e, 1)) : (e = ke(f), e.c(), u(e, 1), e.m(t.parentNode, t)): e && (E(), h(e, 1, 1, () => {
                e = null
            }), T())
        },
        i(f) {
            l || (u(e), l = !0)
        },
        o(f) {
            h(e), l = !1
        },
        d(f) {
            f && _(t), e && e.d(f)
        }
    }
}

function ve(o, t) {
    let l, e, r, n, f, s;
    const i = [Nt, St, Bt, Lt, Tt, Et, It, Dt, zt, wt, vt],
        a = [];

    function c(m, $) {
        return $ & 16 && (e = null), m[7].listTag === "ul" ? 0 : m[7].listTag === "ol" ? 1 : m[7]._type === "table" ? 2 : m[7]._type === "image" ? 3 : m[7]._type === "market" ? 4 : m[7]._type === "tournament" ? 5 : m[7]._type === "vimeo" ? 6 : m[7]._type === "youtube" ? 7 : m[7].style === "normal" ? 8 : (e == null && (e = !!m[5].includes(m[7].style)), e ? 9 : 10)
    }
    return r = c(t, -1), n = a[r] = i[r](t), {
        key: o,
        first: null,
        c() {
            l = p(), n.c(), f = p(), this.h()
        },
        l(m) {
            l = p(), n.l(m), f = p(), this.h()
        },
        h() {
            this.first = l
        },
        m(m, $) {
            d(m, l, $), a[r].m(m, $), d(m, f, $), s = !0
        },
        p(m, $) {
            t = m;
            let g = r;
            r = c(t, $), r === g ? a[r].p(t, $) : (E(), h(a[g], 1, 1, () => {
                a[g] = null
            }), T(), n = a[r], n ? n.p(t, $) : (n = a[r] = i[r](t), n.c()), u(n, 1), n.m(f.parentNode, f))
        },
        i(m) {
            s || (u(n), s = !0)
        },
        o(m) {
            h(n), s = !1
        },
        d(m) {
            m && (_(l), _(f)), a[r].d(m)
        }
    }
}

function yt(o) {
    let t, l = [],
        e = new Map,
        r, n = B(o[4]);
    const f = s => s[9];
    for (let s = 0; s < n.length; s += 1) {
        let i = ue(o, n, s),
            a = f(i);
        e.set(a, l[s] = ve(a, i))
    }
    return {
        c() {
            t = D("div");
            for (let s = 0; s < l.length; s += 1) l[s].c();
            this.h()
        },
        l(s) {
            t = I(s, "DIV", {
                class: !0
            });
            var i = L(t);
            for (let a = 0; a < l.length; a += 1) l[a].l(i);
            i.forEach(_), this.h()
        },
        h() {
            z(t, "class", "content-block svelte-70tzz6")
        },
        m(s, i) {
            d(s, t, i);
            for (let a = 0; a < l.length; a += 1) l[a] && l[a].m(t, null);
            r = !0
        },
        p(s, [i]) {
            i & 63 && (n = B(s[4]), E(), l = W(l, i, f, 1, s, n, e, t, R, ve, null, ue), T())
        },
        i(s) {
            if (!r) {
                for (let i = 0; i < n.length; i += 1) u(l[i]);
                r = !0
            }
        },
        o(s) {
            for (let i = 0; i < l.length; i += 1) h(l[i]);
            r = !1
        },
        d(s) {
            s && _(t);
            for (let i = 0; i < l.length; i += 1) l[i].d()
        }
    }
}

function Mt(o, t, l) {
    let e, {
            headingSize: r = void 0
        } = t,
        {
            textSize: n = "base"
        } = t,
        {
            tournaments: f = []
        } = t,
        {
            markets: s = void 0
        } = t,
        {
            blocks: i
        } = t;
    const a = ["h1", "h2", "h3", "h4", "h5", "h6"];
    return o.$$set = c => {
        "headingSize" in c && l(0, r = c.headingSize), "textSize" in c && l(1, n = c.textSize), "tournaments" in c && l(2, f = c.tournaments), "markets" in c && l(3, s = c.markets), "blocks" in c && l(6, i = c.blocks)
    }, o.$$.update = () => {
        o.$$.dirty & 64 && l(4, e = bt(i))
    }, [r, n, f, s, e, a, i]
}
class Qt extends H {
    constructor(t) {
        super(), O(this, t, Mt, yt, q, {
            headingSize: 0,
            textSize: 1,
            tournaments: 2,
            markets: 3,
            blocks: 6
        })
    }
}
export {
    kt as M, Qt as S, bt as g
};