const t = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "periods",
            scoreboard: "periods"
        },
        displayStreamComingSoonIcon: !0
    },
    s = {
        outrightFirstSport: !0
    },
    n = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "homeAway",
            scoreboard: "periods"
        }
    },
    c = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "periods",
            scoreboard: "periods"
        },
        displayStreamComingSoonIcon: !0
    },
    g = {
        outrightFirstSport: !0
    },
    d = {
        scoring: {
            preview: "homeAway",
            scoreboard: "periods"
        }
    },
    a = {
        outrightFirstSport: !0
    },
    u = {
        scoring: {
            preview: "periods",
            scoreboard: "periods"
        }
    },
    p = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "homeAway",
            scoreboard: "periods"
        }
    },
    l = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "homeAway",
            scoreboard: "periods"
        }
    },
    f = {
        scoring: {
            preview: "periods",
            scoreboard: "periods"
        }
    },
    S = {
        outrightFirstSport: !0
    },
    m = {
        hideResultsInFixtureStatus: !0
    },
    $ = {
        scoring: {
            preview: "homeAway",
            scoreboard: "periods"
        }
    },
    w = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "periods",
            scoreboard: "periods"
        },
        displayStreamComingSoonIcon: !0
    },
    b = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "periods",
            scoreboard: "periods"
        },
        displayStreamComingSoonIcon: !0
    },
    h = {
        scoring: {
            preview: "periods",
            scoreboard: "periods"
        },
        displayStreamComingSoonIcon: !0
    },
    F = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "periods",
            scoreboard: "periods"
        },
        displayStreamComingSoonIcon: !0
    },
    y = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "homeAway",
            scoreboard: "periods"
        }
    },
    v = {
        outrightFirstSport: !0
    },
    x = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "periods",
            scoreboard: "periods"
        },
        displayStreamComingSoonIcon: !0
    },
    W = {
        outrightFirstSport: !0
    },
    C = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "periods",
            scoreboard: "periods"
        }
    },
    I = {
        scoring: {
            preview: "periods",
            scoreboard: "periods"
        },
        loadFixtureWidget: !0,
        displayStreamComingSoonIcon: !0
    },
    k = {
        outrightFirstSport: !0
    },
    A = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "homeAway",
            scoreboard: "homeAway"
        }
    },
    R = {
        scoring: {
            preview: "homeAway",
            scoreboard: "periods"
        }
    },
    q = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "homeAway",
            scoreboard: "periods"
        },
        displayStreamComingSoonIcon: !0
    },
    M = {
        outrightFirstSport: !0,
        displayStreamComingSoonIcon: !0
    },
    j = {
        scoring: {
            preview: "homeAway",
            scoreboard: "periods"
        },
        scoreboard: {
            displayCards: !0,
            displayCorners: !0
        }
    },
    B = {
        outrightFirstSport: !0
    },
    E = {
        outrightFirstSport: !0
    },
    G = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "periods",
            scoreboard: "periods"
        },
        displayStreamComingSoonIcon: !0
    },
    L = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "periods",
            scoreboard: "periods"
        }
    },
    T = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "periods",
            scoreboard: "periods"
        },
        displayStreamComingSoonIcon: !0
    },
    z = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "homeAway",
            scoreboard: "periods"
        }
    },
    D = {
        outrightFirstSport: !0
    },
    H = {},
    J = {
        outrightFirstSport: !0
    },
    K = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "homeAway",
            scoreboard: "periods"
        },
        displayStreamComingSoonIcon: !0
    },
    N = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "periods",
            scoreboard: "periods"
        }
    },
    O = {
        loadFixtureWidget: !0,
        hideResultsInFixtureStatus: !0
    },
    P = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "periods",
            scoreboard: "periods"
        },
        displayStreamComingSoonIcon: !0
    },
    Q = {
        outrightFirstSport: !0
    },
    U = {
        outrightFirstSport: !0
    },
    V = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "homeAway",
            scoreboard: "periods"
        }
    },
    X = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "periods",
            scoreboard: "periods"
        },
        displayStreamComingSoonIcon: !0
    },
    Y = {
        outrightFirstSport: !0
    },
    Z = {
        outrightFirstSport: !0
    },
    _ = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "periods",
            scoreboard: "periods"
        },
        displayStreamComingSoonIcon: !0
    },
    oo = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "homeAway",
            scoreboard: "periods"
        }
    },
    ro = {
        outrightFirstSport: !0
    },
    eo = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "homeAway",
            scoreboard: "periods"
        }
    },
    io = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "homeAway",
            scoreboard: "periods"
        },
        scoreboard: {
            displayCards: !0,
            displayCorners: !0
        }
    },
    to = {
        scoring: {
            preview: "periods",
            scoreboard: "periods"
        }
    },
    so = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "periods",
            scoreboard: "periods"
        },
        displayStreamComingSoonIcon: !0
    },
    no = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "periods",
            scoreboard: "periods"
        },
        displayStreamComingSoonIcon: !0
    },
    co = {
        outrightFirstSport: !0
    },
    go = {
        outrightFirstSport: !0
    },
    ao = {
        outrightFirstSport: !0
    },
    uo = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "periods",
            scoreboard: "periods"
        }
    },
    po = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "periods",
            scoreboard: "periods"
        }
    },
    lo = {
        outrightFirstSport: !0
    },
    fo = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "periods",
            scoreboard: "periods"
        },
        displayStreamComingSoonIcon: !0
    },
    So = {
        loadFixtureWidget: !0,
        scoring: {
            preview: "periods",
            scoreboard: "periods"
        }
    },
    mo = {
        scoring: {
            preview: "periods",
            scoreboard: "periods"
        }
    },
    $o = {
        scoring: {
            preview: "periods",
            scoreboard: "periods"
        },
        displayStreamComingSoonIcon: !0
    },
    wo = {
        outrightFirstSport: !0
    },
    bo = {
        outrightFirstSport: !0
    },
    ho = {
        outrightFirstSport: !0
    },
    Fo = {
        outrightFirstSport: !0
    },
    yo = {
        outrightFirstSport: !0
    },
    vo = {
        outrightFirstSport: !0
    },
    xo = {
        outrightFirstSport: !0
    },
    Wo = {
        outrightFirstSport: !0
    },
    Co = {
        outrightFirstSport: !0
    },
    Io = {
        outrightFirstSport: !0
    },
    ko = {
        outrightFirstSport: !0
    },
    Ao = {
        "age-of-empires": t,
        "alpine-skiing": s,
        "american-football": n,
        "arena-of-valor": c,
        "artistic-swimming": a,
        athletics: g,
        "aussie-rules": d,
        badminton: u,
        baseball: p,
        basketball: l,
        "beach-volleyball": f,
        biathlon: S,
        boxing: m,
        bowls: $,
        "call-of-duty": w,
        "counter-strike-global-offensive": b,
        "counter-strike-2-duels": h,
        "counter-strike": F,
        cricket: y,
        "cross-country": v,
        "csgo-wingman": x,
        cycling: W,
        darts: C,
        "dota-2": I,
        diving: k,
        ecricket: A,
        "field-hockey": R,
        fifa: q,
        "formula-1": M,
        futsal: j,
        "gaelic-hurling": B,
        golf: E,
        halo: G,
        handball: L,
        hearthstone: T,
        "ice-hockey": z,
        "indy-racing": D,
        kabaddi: H,
        "kick-specials": J,
        "kings-of-glory": K,
        "league-of-legends": N,
        mma: O,
        "mobile-legends": P,
        "motorcycle-racing": Q,
        motorsport: U,
        nba2k: V,
        overwatch: X,
        olympics: Y,
        "politics-entertainment": Z,
        "rocket-league": _,
        rugby: oo,
        "ski-jumping": ro,
        snooker: eo,
        soccer: io,
        squash: to,
        "starcraft-2": so,
        starcraft: no,
        surfing: go,
        "stock-car-racing": co,
        "table-tennis": uo,
        tennis: po,
        valorant: fo,
        volleyball: So,
        waterpolo: mo,
        "wild-rift": $o,
        wrestling: wo,
        rowing: bo,
        breaking: ho,
        archery: Fo,
        equestrian: yo,
        gymnastics: vo,
        "sport-climbing": xo,
        weightlifting: Wo,
        swimming: ao,
        triathlon: lo,
        sailing: Co,
        shooting: Io,
        skateboarding: ko
    },
    Ro = {
        loadFixtureWidget: !1,
        hideResultsInFixtureStatus: !1,
        displayStreamComingSoonIcon: !1,
        outrightFirstSport: !1,
        scoring: {
            preview: "none",
            scoreboard: "none"
        },
        scoreboard: {
            displayCards: !1,
            displayCorners: !1
        }
    },
    qo = {
        defaultMarketGroup: "main",
        rowsToShowBeforeLoadMore: 3,
        defaultCashoutEdge: .95
    },
    o = Ao;

function Mo(i, r) {
    var e;
    return ((e = o == null ? void 0 : o[i]) == null ? void 0 : e[r]) || Ro[r]
}
const jo = { ...qo,
    ...o
};
export {
    Mo as g, jo as s
};