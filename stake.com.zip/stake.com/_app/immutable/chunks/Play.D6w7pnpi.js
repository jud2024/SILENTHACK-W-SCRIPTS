import {
    s as o,
    C as f,
    H as u,
    D as m,
    f as v,
    E as _,
    i as c,
    F as r,
    j as g,
    n as h
} from "./scheduler.DXu26z7T.js";
import {
    S as y,
    i as d
} from "./index.Dz_MmNB3.js";

function w(n) {
    let t, l, s = ` <title>${n[1]||""}</title> <path d="M87.984 44.286 12.254.573a4.269 4.269 0 0 0-6.403 3.695v87.464a4.269 4.269 0 0 0 6.423 3.685l-.02.01 75.73-43.713a4.272 4.272 0 0 0 .023-7.418l-.02-.01h-.002Z"></path>`,
        i;
    return {
        c() {
            t = f("svg"), l = new u(!0), this.h()
        },
        l(e) {
            t = m(e, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var a = v(t);
            l = _(a, !0), a.forEach(c), this.h()
        },
        h() {
            l.a = null, r(t, "fill", "currentColor"), r(t, "viewBox", "0 0 96 96"), r(t, "class", i = "svg-icon " + n[2]), r(t, "style", n[0])
        },
        m(e, a) {
            g(e, t, a), l.m(s, t)
        },
        p(e, [a]) {
            a & 2 && s !== (s = ` <title>${e[1]||""}</title> <path d="M87.984 44.286 12.254.573a4.269 4.269 0 0 0-6.403 3.695v87.464a4.269 4.269 0 0 0 6.423 3.685l-.02.01 75.73-43.713a4.272 4.272 0 0 0 .023-7.418l-.02-.01h-.002Z"></path>`) && l.p(s), a & 4 && i !== (i = "svg-icon " + e[2]) && r(t, "class", i), a & 1 && r(t, "style", e[0])
        },
        i: h,
        o: h,
        d(e) {
            e && c(t)
        }
    }
}

function C(n, t, l) {
    let {
        style: s = ""
    } = t, {
        alt: i = ""
    } = t, {
        class: e = ""
    } = t;
    return n.$$set = a => {
        "style" in a && l(0, s = a.style), "alt" in a && l(1, i = a.alt), "class" in a && l(2, e = a.class)
    }, [s, i, e]
}
class E extends y {
    constructor(t) {
        super(), d(this, t, C, w, o, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    E as P
};