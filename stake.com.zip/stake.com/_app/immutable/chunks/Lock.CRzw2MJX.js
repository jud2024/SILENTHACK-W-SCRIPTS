import {
    s as v,
    C as m,
    H as o,
    D as f,
    f as u,
    E as _,
    i as h,
    F as c,
    j as g,
    n as r
} from "./scheduler.DXu26z7T.js";
import {
    S as V,
    i as y
} from "./index.Dz_MmNB3.js";

function C(n) {
    let t, a, l = ` <title>${n[1]||""}</title> <path d="M53.998 31V21C53.874 9.382 44.432.01 32.8 0h-1.6C19.496.012 10.012 9.496 10 21.198V31H6.62v33h50.76V31h-3.382Zm-36-9.8c.006-7.288 5.912-13.194 13.2-13.2h1.6c7.288.006 13.194 5.912 13.2 13.2V31h-28v-9.8Zm17 29V55a3.001 3.001 0 0 1-6 0v-4.81c-1.806-1.056-3-2.988-3-5.196a6 6 0 1 1 9.028 5.18l-.028.016v.01Z"></path>`,
        i;
    return {
        c() {
            t = m("svg"), a = new o(!0), this.h()
        },
        l(s) {
            t = f(s, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var e = u(t);
            a = _(e, !0), e.forEach(h), this.h()
        },
        h() {
            a.a = null, c(t, "fill", "currentColor"), c(t, "viewBox", "0 0 64 64"), c(t, "class", i = "svg-icon " + n[2]), c(t, "style", n[0])
        },
        m(s, e) {
            g(s, t, e), a.m(l, t)
        },
        p(s, [e]) {
            e & 2 && l !== (l = ` <title>${s[1]||""}</title> <path d="M53.998 31V21C53.874 9.382 44.432.01 32.8 0h-1.6C19.496.012 10.012 9.496 10 21.198V31H6.62v33h50.76V31h-3.382Zm-36-9.8c.006-7.288 5.912-13.194 13.2-13.2h1.6c7.288.006 13.194 5.912 13.2 13.2V31h-28v-9.8Zm17 29V55a3.001 3.001 0 0 1-6 0v-4.81c-1.806-1.056-3-2.988-3-5.196a6 6 0 1 1 9.028 5.18l-.028.016v.01Z"></path>`) && a.p(l), e & 4 && i !== (i = "svg-icon " + s[2]) && c(t, "class", i), e & 1 && c(t, "style", s[0])
        },
        i: r,
        o: r,
        d(s) {
            s && h(t)
        }
    }
}

function Z(n, t, a) {
    let {
        style: l = ""
    } = t, {
        alt: i = ""
    } = t, {
        class: s = ""
    } = t;
    return n.$$set = e => {
        "style" in e && a(0, l = e.style), "alt" in e && a(1, i = e.alt), "class" in e && a(2, s = e.class)
    }, [l, i, s]
}
class w extends V {
    constructor(t) {
        super(), y(this, t, Z, C, v, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    w as L
};