import "./index.B3dW9TVs.js";
import {
    x as n
} from "./scheduler.DXu26z7T.js";
const o = () => n("parent"),
    a = {
        sidebarTabs: "minimal",
        tabs: "tab",
        "dropdown-light": "dropdown",
        "dropdown-dark": "link",
        input: "link",
        subNav: "tabmenu",
        leftsidebar: "minimal"
    },
    e = ({
        parent: t
    }) => t && t in a ? a[t] : "link";
export {
    e as a, o as g
};