import {
    s as v,
    e as f,
    d as h,
    f as m,
    i as u,
    F as r,
    j as _,
    k as y,
    n as d,
    U as w
} from "./scheduler.DXu26z7T.js";
import {
    S as b,
    i as F
} from "./index.Dz_MmNB3.js";

function k(a) {
    let e, t;
    return {
        c() {
            e = f("iframe"), this.h()
        },
        l(l) {
            e = h(l, "IFRAME", {
                title: !0,
                src: !0,
                allow: !0,
                class: !0
            }), m(e).forEach(u), this.h()
        },
        h() {
            r(e, "title", "video"), w(e.src, t = a[0]) || r(e, "src", t), r(e, "allow", a[1]), e.allowFullscreen = a[2], r(e, "class", "svelte-1ktsnhq")
        },
        m(l, s) {
            _(l, e, s)
        },
        p(l, s) {
            s & 1 && !w(e.src, t = l[0]) && r(e, "src", t), s & 2 && r(e, "allow", l[1]), s & 4 && (e.allowFullscreen = l[2])
        },
        d(l) {
            l && u(e)
        }
    }
}

function q(a) {
    let e, t;
    return {
        c() {
            e = f("iframe"), this.h()
        },
        l(l) {
            e = h(l, "IFRAME", {
                title: !0,
                src: !0,
                allow: !0,
                class: !0
            }), m(e).forEach(u), this.h()
        },
        h() {
            r(e, "title", "youtube video"), w(e.src, t = "https://www.youtube.com/embed/" + a[0]) || r(e, "src", t), r(e, "allow", a[1]), e.allowFullscreen = a[2], r(e, "class", "svelte-1ktsnhq")
        },
        m(l, s) {
            _(l, e, s)
        },
        p(l, s) {
            s & 1 && !w(e.src, t = "https://www.youtube.com/embed/" + l[0]) && r(e, "src", t), s & 2 && r(e, "allow", l[1]), s & 4 && (e.allowFullscreen = l[2])
        },
        d(l) {
            l && u(e)
        }
    }
}

function E(a) {
    let e, t;

    function l(i, o) {
        return i[4] === "youtube" ? q : k
    }
    let s = l(a),
        c = s(a);
    return {
        c() {
            e = f("div"), t = f("div"), c.c(), this.h()
        },
        l(i) {
            e = h(i, "DIV", {
                class: !0,
                style: !0
            });
            var o = m(e);
            t = h(o, "DIV", {
                class: !0
            });
            var n = m(t);
            c.l(n), n.forEach(u), o.forEach(u), this.h()
        },
        h() {
            r(t, "class", "video-wrapper chromatic-ignore svelte-1ktsnhq"), r(e, "class", "video-container svelte-1ktsnhq"), r(e, "style", a[3])
        },
        m(i, o) {
            _(i, e, o), y(e, t), c.m(t, null)
        },
        p(i, [o]) {
            s === (s = l(i)) && c ? c.p(i, o) : (c.d(1), c = s(i), c && (c.c(), c.m(t, null))), o & 8 && r(e, "style", i[3])
        },
        i: d,
        o: d,
        d(i) {
            i && u(e), c.d()
        }
    }
}

function S(a, e, t) {
    let {
        src: l = void 0
    } = e, {
        allow: s = "autoplay; fullscreen; picture-in-picture"
    } = e, {
        allowFullScreen: c = !0
    } = e, {
        style: i = void 0
    } = e, {
        type: o = void 0
    } = e;
    return a.$$set = n => {
        "src" in n && t(0, l = n.src), "allow" in n && t(1, s = n.allow), "allowFullScreen" in n && t(2, c = n.allowFullScreen), "style" in n && t(3, i = n.style), "type" in n && t(4, o = n.type)
    }, [l, s, c, i, o]
}
class g extends b {
    constructor(e) {
        super(), F(this, e, S, E, v, {
            src: 0,
            allow: 1,
            allowFullScreen: 2,
            style: 3,
            type: 4
        })
    }
}
export {
    g as V
};