import {
    _ as c
} from "./index.B4-7gKq3.js";
const r = n => n.reduce((o, e) => ({ ...o,
        [e.name]: e
    }), {}),
    d = (n, o) => {
        var l;
        const e = ((l = o[n]) == null ? void 0 : l.include) || [],
            s = c.flatten(e.map(u => d(u, o)));
        return [n, ...s]
    },
    f = ({
        userRoles: n,
        infoRoles: o
    }) => {
        const e = r(o),
            s = c.flatten(n.map(({
                name: t
            }) => d(t, e))),
            l = c.flatten(s.map(t => e[t].exclude || [])),
            u = c.uniq(s.filter(t => !l.includes(t))),
            i = c.uniq(c.flatten(u.map(t => e[t].modify || [])));
        return {
            include: u,
            modify: i
        }
    };
export {
    f as g
};