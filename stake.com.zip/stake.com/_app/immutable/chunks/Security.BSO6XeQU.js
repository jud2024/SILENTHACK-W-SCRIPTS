import {
    s as m,
    C as o,
    H as u,
    D as f,
    f as v,
    E as _,
    i as r,
    F as c,
    j as g,
    n as h
} from "./scheduler.DXu26z7T.js";
import {
    S as y,
    i as d
} from "./index.Dz_MmNB3.js";

function C(n) {
    let t, l, a = ` <title>${n[1]||""}</title> <path d="M32 0 5.654 11.306C5.654 52.692 32 64 32 64s26.346-11.306 26.346-52.694L32 0Zm3.546 33.014v13.2h-7.12v-13.2c-3.174-1.41-5.346-4.532-5.346-8.164a8.907 8.907 0 1 1 12.522 8.142l-.056.022Z"></path>`,
        i;
    return {
        c() {
            t = o("svg"), l = new u(!0), this.h()
        },
        l(s) {
            t = f(s, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var e = v(t);
            l = _(e, !0), e.forEach(r), this.h()
        },
        h() {
            l.a = null, c(t, "fill", "currentColor"), c(t, "viewBox", "0 0 64 64"), c(t, "class", i = "svg-icon " + n[2]), c(t, "style", n[0])
        },
        m(s, e) {
            g(s, t, e), l.m(a, t)
        },
        p(s, [e]) {
            e & 2 && a !== (a = ` <title>${s[1]||""}</title> <path d="M32 0 5.654 11.306C5.654 52.692 32 64 32 64s26.346-11.306 26.346-52.694L32 0Zm3.546 33.014v13.2h-7.12v-13.2c-3.174-1.41-5.346-4.532-5.346-8.164a8.907 8.907 0 1 1 12.522 8.142l-.056.022Z"></path>`) && l.p(a), e & 4 && i !== (i = "svg-icon " + s[2]) && c(t, "class", i), e & 1 && c(t, "style", s[0])
        },
        i: h,
        o: h,
        d(s) {
            s && r(t)
        }
    }
}

function w(n, t, l) {
    let {
        style: a = ""
    } = t, {
        alt: i = ""
    } = t, {
        class: s = ""
    } = t;
    return n.$$set = e => {
        "style" in e && l(0, a = e.style), "alt" in e && l(1, i = e.alt), "class" in e && l(2, s = e.class)
    }, [a, i, s]
}
class H extends y {
    constructor(t) {
        super(), d(this, t, w, C, m, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    H as S
};