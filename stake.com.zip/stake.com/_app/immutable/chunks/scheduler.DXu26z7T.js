var F = Object.defineProperty;
var G = (t, e, n) => e in t ? F(t, e, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: n
}) : t[e] = n;
var f = (t, e, n) => G(t, typeof e != "symbol" ? e + "" : e, n);

function L() {}
const mt = t => t;

function U(t, e) {
    for (const n in e) t[n] = e[n];
    return t
}

function pt(t) {
    return !!t && (typeof t == "object" || typeof t == "function") && typeof t.then == "function"
}

function J(t) {
    return t()
}

function yt() {
    return Object.create(null)
}

function K(t) {
    t.forEach(J)
}

function Q(t) {
    return typeof t == "function"
}

function gt(t, e) {
    return t != t ? e == e : t !== e || t && typeof t == "object" || typeof t == "function"
}
let p;

function bt(t, e) {
    return t === e ? !0 : (p || (p = document.createElement("a")), p.href = e, t === p.href)
}

function xt(t, e) {
    return t != t ? e == e : t !== e
}

function wt(t) {
    return Object.keys(t).length === 0
}

function M(t, ...e) {
    if (t == null) {
        for (const i of e) i(void 0);
        return L
    }
    const n = t.subscribe(...e);
    return n.unsubscribe ? () => n.unsubscribe() : n
}

function Et(t) {
    let e;
    return M(t, n => e = n)(), e
}

function Tt(t, e, n) {
    t.$$.on_destroy.push(M(e, n))
}

function vt(t, e, n, i) {
    if (t) {
        const s = S(t, e, n, i);
        return t[0](s)
    }
}

function S(t, e, n, i) {
    return t[1] && i ? U(n.ctx.slice(), t[1](i(e))) : n.ctx
}

function Nt(t, e, n, i) {
    if (t[2] && i) {
        const s = t[2](i(n));
        if (e.dirty === void 0) return s;
        if (typeof s == "object") {
            const r = [],
                o = Math.max(e.dirty.length, s.length);
            for (let l = 0; l < o; l += 1) r[l] = e.dirty[l] | s[l];
            return r
        }
        return e.dirty | s
    }
    return e.dirty
}

function At(t, e, n, i, s, r) {
    if (s) {
        const o = S(e, n, i, r);
        t.p(o, s)
    }
}

function kt(t) {
    if (t.ctx.length > 32) {
        const e = [],
            n = t.ctx.length / 32;
        for (let i = 0; i < n; i++) e[i] = -1;
        return e
    }
    return -1
}

function Ct(t) {
    const e = {};
    for (const n in t) n[0] !== "$" && (e[n] = t[n]);
    return e
}

function jt(t, e) {
    const n = {};
    e = new Set(e);
    for (const i in t) !e.has(i) && i[0] !== "$" && (n[i] = t[i]);
    return n
}

function Dt(t) {
    const e = {};
    for (const n in t) e[n] = !0;
    return e
}

function Ht(t) {
    return t ? ? ""
}

function Lt(t, e, n) {
    return t.set(n), e
}

function Mt(t) {
    return t && Q(t.destroy) ? t.destroy : L
}

function St(t) {
    const e = typeof t == "string" && t.match(/^\s*(-?[\d.]+)([^\s]*)\s*$/);
    return e ? [parseFloat(e[1]), e[2] || "px"] : [t, "px"]
}
let x = !1;

function Ot() {
    x = !0
}

function Pt() {
    x = !1
}

function V(t, e, n, i) {
    for (; t < e;) {
        const s = t + (e - t >> 1);
        n(s) <= i ? t = s + 1 : e = s
    }
    return t
}

function X(t) {
    if (t.hydrate_init) return;
    t.hydrate_init = !0;
    let e = t.childNodes;
    if (t.nodeName === "HEAD") {
        const c = [];
        for (let a = 0; a < e.length; a++) {
            const u = e[a];
            u.claim_order !== void 0 && c.push(u)
        }
        e = c
    }
    const n = new Int32Array(e.length + 1),
        i = new Int32Array(e.length);
    n[0] = -1;
    let s = 0;
    for (let c = 0; c < e.length; c++) {
        const a = e[c].claim_order,
            u = (s > 0 && e[n[s]].claim_order <= a ? s + 1 : V(1, s, I => e[n[I]].claim_order, a)) - 1;
        i[c] = n[u] + 1;
        const C = u + 1;
        n[C] = c, s = Math.max(C, s)
    }
    const r = [],
        o = [];
    let l = e.length - 1;
    for (let c = n[s] + 1; c != 0; c = i[c - 1]) {
        for (r.push(e[c - 1]); l >= c; l--) o.push(e[l]);
        l--
    }
    for (; l >= 0; l--) o.push(e[l]);
    r.reverse(), o.sort((c, a) => c.claim_order - a.claim_order);
    for (let c = 0, a = 0; c < o.length; c++) {
        for (; a < r.length && o[c].claim_order >= r[a].claim_order;) a++;
        const u = a < r.length ? r[a] : null;
        t.insertBefore(o[c], u)
    }
}

function O(t, e) {
    t.appendChild(e)
}

function Y(t) {
    if (!t) return document;
    const e = t.getRootNode ? t.getRootNode() : t.ownerDocument;
    return e && e.host ? e : t.ownerDocument
}

function qt(t) {
    const e = w("style");
    return e.textContent = "/* empty */", Z(Y(t), e), e.sheet
}

function Z(t, e) {
    return O(t.head || t, e), e.sheet
}

function $(t, e) {
    if (x) {
        for (X(t), (t.actual_end_child === void 0 || t.actual_end_child !== null && t.actual_end_child.parentNode !== t) && (t.actual_end_child = t.firstChild); t.actual_end_child !== null && t.actual_end_child.claim_order === void 0;) t.actual_end_child = t.actual_end_child.nextSibling;
        e !== t.actual_end_child ? (e.claim_order !== void 0 || e.parentNode !== t) && t.insertBefore(e, t.actual_end_child) : t.actual_end_child = e.nextSibling
    } else(e.parentNode !== t || e.nextSibling !== null) && t.appendChild(e)
}

function tt(t, e, n) {
    t.insertBefore(e, n || null)
}

function et(t, e, n) {
    x && !n ? $(t, e) : (e.parentNode !== t || e.nextSibling != n) && t.insertBefore(e, n || null)
}

function g(t) {
    t.parentNode && t.parentNode.removeChild(t)
}

function zt(t, e) {
    for (let n = 0; n < t.length; n += 1) t[n] && t[n].d(e)
}

function w(t) {
    return document.createElement(t)
}

function P(t) {
    return document.createElementNS("http://www.w3.org/2000/svg", t)
}

function k(t) {
    return document.createTextNode(t)
}

function Bt() {
    return k(" ")
}

function Rt() {
    return k("")
}

function j(t, e, n, i) {
    return t.addEventListener(e, n, i), () => t.removeEventListener(e, n, i)
}

function Wt(t) {
    return function(e) {
        return e.preventDefault(), t.call(this, e)
    }
}

function q(t, e, n) {
    n == null ? t.removeAttribute(e) : t.getAttribute(e) !== n && t.setAttribute(e, n)
}
const nt = ["width", "height"];

function it(t, e) {
    const n = Object.getOwnPropertyDescriptors(t.__proto__);
    for (const i in e) e[i] == null ? t.removeAttribute(i) : i === "style" ? t.style.cssText = e[i] : i === "__value" ? t.value = t[i] = e[i] : n[i] && n[i].set && nt.indexOf(i) === -1 ? t[i] = e[i] : q(t, i, e[i])
}

function st(t, e) {
    Object.keys(e).forEach(n => {
        ot(t, n, e[n])
    })
}

function ot(t, e, n) {
    const i = e.toLowerCase();
    i in t ? t[i] = typeof t[i] == "boolean" && n === "" ? !0 : n : e in t ? t[e] = typeof t[e] == "boolean" && n === "" ? !0 : n : q(t, e, n)
}

function It(t) {
    return /-/.test(t) ? st : it
}

function Ft(t) {
    return t.dataset.svelteH
}

function Gt(t) {
    return Array.from(t.childNodes)
}

function z(t) {
    t.claim_info === void 0 && (t.claim_info = {
        last_index: 0,
        total_claimed: 0
    })
}

function B(t, e, n, i, s = !1) {
    z(t);
    const r = (() => {
        for (let o = t.claim_info.last_index; o < t.length; o++) {
            const l = t[o];
            if (e(l)) {
                const c = n(l);
                return c === void 0 ? t.splice(o, 1) : t[o] = c, s || (t.claim_info.last_index = o), l
            }
        }
        for (let o = t.claim_info.last_index - 1; o >= 0; o--) {
            const l = t[o];
            if (e(l)) {
                const c = n(l);
                return c === void 0 ? t.splice(o, 1) : t[o] = c, s ? c === void 0 && t.claim_info.last_index-- : t.claim_info.last_index = o, l
            }
        }
        return i()
    })();
    return r.claim_order = t.claim_info.total_claimed, t.claim_info.total_claimed += 1, r
}

function R(t, e, n, i) {
    return B(t, s => s.nodeName === e, s => {
        const r = [];
        for (let o = 0; o < s.attributes.length; o++) {
            const l = s.attributes[o];
            n[l.name] || r.push(l.name)
        }
        r.forEach(o => s.removeAttribute(o))
    }, () => i(e))
}

function Ut(t, e, n) {
    return R(t, e, n, w)
}

function Jt(t, e, n) {
    return R(t, e, n, P)
}

function rt(t, e) {
    return B(t, n => n.nodeType === 3, n => {
        const i = "" + e;
        if (n.data.startsWith(i)) {
            if (n.data.length !== i.length) return n.splitText(i.length)
        } else n.data = i
    }, () => k(e), !0)
}

function Kt(t) {
    return rt(t, " ")
}

function D(t, e, n) {
    for (let i = n; i < t.length; i += 1) {
        const s = t[i];
        if (s.nodeType === 8 && s.textContent.trim() === e) return i
    }
    return -1
}

function Qt(t, e) {
    const n = D(t, "HTML_TAG_START", 0),
        i = D(t, "HTML_TAG_END", n + 1);
    if (n === -1 || i === -1) return new E(e);
    z(t);
    const s = t.splice(n, i - n + 1);
    g(s[0]), g(s[s.length - 1]);
    const r = s.slice(1, s.length - 1);
    if (r.length === 0) return new E(e);
    for (const o of r) o.claim_order = t.claim_info.total_claimed, t.claim_info.total_claimed += 1;
    return new E(e, r)
}

function Vt(t, e) {
    e = "" + e, t.data !== e && (t.data = e)
}

function Xt(t, e) {
    t.value = e ? ? ""
}

function Yt(t, e, n, i) {
    n == null ? t.style.removeProperty(e) : t.style.setProperty(e, n, i ? "important" : "")
}

function Zt(t, e, n) {
    for (let i = 0; i < t.options.length; i += 1) {
        const s = t.options[i];
        if (s.__value === e) {
            s.selected = !0;
            return
        }
    }(!n || e !== void 0) && (t.selectedIndex = -1)
}

function $t(t, e) {
    for (let n = 0; n < t.options.length; n += 1) {
        const i = t.options[n];
        i.selected = ~e.indexOf(i.__value)
    }
}
let y;

function ct() {
    if (y === void 0) {
        y = !1;
        try {
            typeof window < "u" && window.parent && window.parent.document
        } catch {
            y = !0
        }
    }
    return y
}

function te(t, e) {
    getComputedStyle(t).position === "static" && (t.style.position = "relative");
    const i = w("iframe");
    i.setAttribute("style", "display: block; position: absolute; top: 0; left: 0; width: 100%; height: 100%; overflow: hidden; border: 0; opacity: 0; pointer-events: none; z-index: -1;"), i.setAttribute("aria-hidden", "true"), i.tabIndex = -1;
    const s = ct();
    let r;
    return s ? (i.src = "data:text/html,<script>onresize=function(){parent.postMessage(0,'*')}<\/script>", r = j(window, "message", o => {
        o.source === i.contentWindow && e()
    })) : (i.src = "about:blank", i.onload = () => {
        r = j(i.contentWindow, "resize", e), e()
    }), O(t, i), () => {
        (s || r && i.contentWindow) && r(), g(i)
    }
}

function ee(t, e, n) {
    t.classList.toggle(e, !!n)
}

function lt(t, e, {
    bubbles: n = !1,
    cancelable: i = !1
} = {}) {
    return new CustomEvent(t, {
        detail: e,
        bubbles: n,
        cancelable: i
    })
}

function ne(t, e) {
    const n = [];
    let i = 0;
    for (const s of e.childNodes)
        if (s.nodeType === 8) {
            const r = s.textContent.trim();
            r === `HEAD_${t}_END` ? (i -= 1, n.push(s)) : r === `HEAD_${t}_START` && (i += 1, n.push(s))
        } else i > 0 && n.push(s);
    return n
}
class at {
    constructor(e = !1) {
        f(this, "is_svg", !1);
        f(this, "e");
        f(this, "n");
        f(this, "t");
        f(this, "a");
        this.is_svg = e, this.e = this.n = null
    }
    c(e) {
        this.h(e)
    }
    m(e, n, i = null) {
        this.e || (this.is_svg ? this.e = P(n.nodeName) : this.e = w(n.nodeType === 11 ? "TEMPLATE" : n.nodeName), this.t = n.tagName !== "TEMPLATE" ? n : n.content, this.c(e)), this.i(i)
    }
    h(e) {
        this.e.innerHTML = e, this.n = Array.from(this.e.nodeName === "TEMPLATE" ? this.e.content.childNodes : this.e.childNodes)
    }
    i(e) {
        for (let n = 0; n < this.n.length; n += 1) tt(this.t, this.n[n], e)
    }
    p(e) {
        this.d(), this.h(e), this.i(this.a)
    }
    d() {
        this.n.forEach(g)
    }
}
class E extends at {
    constructor(n = !1, i) {
        super(n);
        f(this, "l");
        this.e = this.n = null, this.l = i
    }
    c(n) {
        this.l ? this.n = this.l : super.c(n)
    }
    i(n) {
        for (let i = 0; i < this.n.length; i += 1) et(this.t, this.n[i], n)
    }
}

function ie(t, e) {
    return new t(e)
}
let b;

function T(t) {
    b = t
}

function _() {
    if (!b) throw new Error("Function called outside component initialization");
    return b
}

function se(t) {
    _().$$.before_update.push(t)
}

function oe(t) {
    _().$$.on_mount.push(t)
}

function re(t) {
    _().$$.after_update.push(t)
}

function ce(t) {
    _().$$.on_destroy.push(t)
}

function le() {
    const t = _();
    return (e, n, {
        cancelable: i = !1
    } = {}) => {
        const s = t.$$.callbacks[e];
        if (s) {
            const r = lt(e, n, {
                cancelable: i
            });
            return s.slice().forEach(o => {
                o.call(t, r)
            }), !r.defaultPrevented
        }
        return !0
    }
}

function ae(t, e) {
    return _().$$.context.set(t, e), e
}

function ue(t) {
    return _().$$.context.get(t)
}

function fe(t, e) {
    const n = t.$$.callbacks[e.type];
    n && n.slice().forEach(i => i.call(this, e))
}
const m = [],
    H = [];
let h = [];
const N = [],
    W = Promise.resolve();
let A = !1;

function ut() {
    A || (A = !0, W.then(_t))
}

function _e() {
    return ut(), W
}

function ft(t) {
    h.push(t)
}

function de(t) {
    N.push(t)
}
const v = new Set;
let d = 0;

function _t() {
    if (d !== 0) return;
    const t = b;
    do {
        try {
            for (; d < m.length;) {
                const e = m[d];
                d++, T(e), dt(e.$$)
            }
        } catch (e) {
            throw m.length = 0, d = 0, e
        }
        for (T(null), m.length = 0, d = 0; H.length;) H.pop()();
        for (let e = 0; e < h.length; e += 1) {
            const n = h[e];
            v.has(n) || (v.add(n), n())
        }
        h.length = 0
    } while (m.length);
    for (; N.length;) N.pop()();
    A = !1, v.clear(), T(t)
}

function dt(t) {
    if (t.fragment !== null) {
        t.update(), K(t.before_update);
        const e = t.dirty;
        t.dirty = [-1], t.fragment && t.fragment.p(t.ctx, e), t.after_update.forEach(ft)
    }
}

function he(t) {
    const e = [],
        n = [];
    h.forEach(i => t.indexOf(i) === -1 ? e.push(i) : n.push(i)), n.forEach(i => i()), h = e
}
export {
    Xt as $, T as A, _t as B, P as C, Jt as D, Qt as E, q as F, Et as G, E as H, Yt as I, H as J, U as K, jt as L, Ct as M, fe as N, Bt as O, Kt as P, it as Q, ie as R, Ft as S, Lt as T, bt as U, ee as V, j as W, le as X, Dt as Y, $t as Z, Zt as _, vt as a, mt as a0, zt as a1, ne as a2, Mt as a3, St as a4, Ht as a5, ft as a6, de as a7, It as a8, xt as a9, re as aa, _e as ab, Wt as ac, Y as ad, qt as ae, lt as af, yt as ag, wt as ah, he as ai, b as aj, J as ak, m as al, ut as am, Ot as an, Pt as ao, te as ap, se as aq, Nt as b, Tt as c, Ut as d, w as e, Gt as f, kt as g, rt as h, g as i, et as j, $ as k, Vt as l, Rt as m, L as n, oe as o, M as p, Q as q, K as r, gt as s, k as t, At as u, ae as v, ce as w, ue as x, pt as y, _ as z
};