import {
    s as p,
    K as f,
    L as c,
    M as g,
    N as d,
    a as k,
    u as b,
    g as h,
    b as L
} from "./scheduler.DXu26z7T.js";
import {
    S as $,
    i as C,
    c as E,
    a as S,
    m as j,
    t as _,
    b as u,
    d as q
} from "./index.Dz_MmNB3.js";
import {
    g as K,
    a as M
} from "./spread.CgU5AtxT.js";
import {
    L as N
} from "./index.DJurAkTj.js";
import "./index.ByMdEFI5.js";

function O(n) {
    let e;
    const a = n[2].default,
        t = k(a, n, n[4], null);
    return {
        c() {
            t && t.c()
        },
        l(o) {
            t && t.l(o)
        },
        m(o, s) {
            t && t.m(o, s), e = !0
        },
        p(o, s) {
            t && t.p && (!e || s & 16) && b(t, a, o, o[4], e ? L(a, o[4], s, null) : h(o[4]), null)
        },
        i(o) {
            e || (_(t, o), e = !0)
        },
        o(o) {
            u(t, o), e = !1
        },
        d(o) {
            t && t.d(o)
        }
    }
}

function P(n) {
    let e, a;
    const t = [{
        target: "_blank"
    }, {
        to: n[0]
    }, {
        rel: "external noreferrer noopener"
    }, {
        prefetch: "off"
    }, {
        scrollTopOnClick: !1
    }, n[1]];
    let o = {
        $$slots: {
            default: [O]
        },
        $$scope: {
            ctx: n
        }
    };
    for (let s = 0; s < t.length; s += 1) o = f(o, t[s]);
    return e = new N({
        props: o
    }), e.$on("click", n[3]), {
        c() {
            E(e.$$.fragment)
        },
        l(s) {
            S(e.$$.fragment, s)
        },
        m(s, l) {
            j(e, s, l), a = !0
        },
        p(s, [l]) {
            const i = l & 3 ? K(t, [t[0], l & 1 && {
                to: s[0]
            }, t[2], t[3], t[4], l & 2 && M(s[1])]) : {};
            l & 16 && (i.$$scope = {
                dirty: l,
                ctx: s
            }), e.$set(i)
        },
        i(s) {
            a || (_(e.$$.fragment, s), a = !0)
        },
        o(s) {
            u(e.$$.fragment, s), a = !1
        },
        d(s) {
            q(e, s)
        }
    }
}

function T(n, e, a) {
    const t = ["to"];
    let o = c(e, t),
        {
            $$slots: s = {},
            $$scope: l
        } = e,
        {
            to: i
        } = e;

    function m(r) {
        d.call(this, n, r)
    }
    return n.$$set = r => {
        e = f(f({}, e), g(r)), a(1, o = c(e, t)), "to" in r && a(0, i = r.to), "$$scope" in r && a(4, l = r.$$scope)
    }, [i, o, s, m, l]
}
class F extends $ {
    constructor(e) {
        super(), C(this, e, T, P, p, {
            to: 0
        })
    }
}
export {
    F as E
};