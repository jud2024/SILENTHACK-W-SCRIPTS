import {
    s as O,
    c as H,
    e as v,
    O as R,
    d as k,
    f as P,
    P as F,
    i as u,
    F as $,
    j as b,
    k as w,
    t as I,
    h as M,
    l as E,
    m as B,
    L as q,
    K as N,
    M as Z,
    n as x,
    V
} from "./scheduler.DXu26z7T.js";
import {
    S as K,
    i as L,
    c as _,
    a as p,
    m as d,
    t as m,
    b as h,
    d as g,
    g as y,
    e as J
} from "./index.Dz_MmNB3.js";
import {
    g as ee,
    a as te
} from "./spread.CgU5AtxT.js";
import "./index.ByMdEFI5.js";
import {
    m as se
} from "./utils.92_vUFxq.js";
import {
    h as j,
    i as Q,
    az as ne
} from "./index.B4-7gKq3.js";
import {
    H as W
} from "./index.u8ZD9oiA.js";
import {
    U as re
} from "./index.DTS6WF86.js";
import {
    T as ae
} from "./index.rqxo2ccV.js";
import "./index.B3dW9TVs.js";
import {
    m as oe
} from "./index.Ci34scWy.js";
import {
    T as le
} from "./index.D7nbRHfU.js";
import {
    G as X
} from "./GhostModeOn.cYfUwU7X.js";
import {
    c as C
} from "./index.BljstGtu.js";
import {
    B as ie
} from "./button.BwmFDw8u.js";
const z = {
    hidden: j._("Hidden"),
    hiddenTooltip: j._("This user has privacy enabled")
};

function fe(o) {
    let e, s = o[0]._(z.hidden) + "",
        t;
    return {
        c() {
            e = v("span"), t = I(s)
        },
        l(r) {
            e = k(r, "SPAN", {});
            var n = P(e);
            t = M(n, s), n.forEach(u)
        },
        m(r, n) {
            b(r, e, n), w(e, t)
        },
        p(r, n) {
            n & 1 && s !== (s = r[0]._(z.hidden) + "") && E(t, s)
        },
        d(r) {
            r && u(e)
        }
    }
}

function ce(o) {
    let e, s, t, r, n, a;
    return s = new X({}), n = new le({
        props: {
            inline: !0,
            lineHeight: "default",
            variant: "subtle",
            weight: "semibold",
            $$slots: {
                default: [fe]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            e = v("div"), _(s.$$.fragment), t = R(), r = v("span"), _(n.$$.fragment), this.h()
        },
        l(i) {
            e = k(i, "DIV", {
                class: !0
            });
            var l = P(e);
            p(s.$$.fragment, l), t = F(l), r = k(l, "SPAN", {
                class: !0
            });
            var c = P(r);
            p(n.$$.fragment, c), c.forEach(u), l.forEach(u), this.h()
        },
        h() {
            $(r, "class", "truncate"), $(e, "class", "flex gap-1 items-center w-full")
        },
        m(i, l) {
            b(i, e, l), d(s, e, null), w(e, t), w(e, r), d(n, r, null), a = !0
        },
        p(i, l) {
            const c = {};
            l & 3 && (c.$$scope = {
                dirty: l,
                ctx: i
            }), n.$set(c)
        },
        i(i) {
            a || (m(s.$$.fragment, i), m(n.$$.fragment, i), a = !0)
        },
        o(i) {
            h(s.$$.fragment, i), h(n.$$.fragment, i), a = !1
        },
        d(i) {
            i && u(e), g(s), g(n)
        }
    }
}

function ue(o) {
    let e, s = o[0]._(z.hiddenTooltip) + "",
        t;
    return {
        c() {
            e = v("span"), t = I(s), this.h()
        },
        l(r) {
            e = k(r, "SPAN", {
                slot: !0
            });
            var n = P(e);
            t = M(n, s), n.forEach(u), this.h()
        },
        h() {
            $(e, "slot", "tooltip")
        },
        m(r, n) {
            b(r, e, n), w(e, t)
        },
        p(r, n) {
            n & 1 && s !== (s = r[0]._(z.hiddenTooltip) + "") && E(t, s)
        },
        d(r) {
            r && u(e)
        }
    }
}

function me(o) {
    let e, s;
    return e = new W({
        props: {
            $$slots: {
                tooltip: [ue],
                default: [ce]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            _(e.$$.fragment)
        },
        l(t) {
            p(e.$$.fragment, t)
        },
        m(t, r) {
            d(e, t, r), s = !0
        },
        p(t, [r]) {
            const n = {};
            r & 3 && (n.$$scope = {
                dirty: r,
                ctx: t
            }), e.$set(n)
        },
        i(t) {
            s || (m(e.$$.fragment, t), s = !0)
        },
        o(t) {
            h(e.$$.fragment, t), s = !1
        },
        d(t) {
            g(e, t)
        }
    }
}

function he(o, e, s) {
    let t;
    return H(o, Q, r => s(0, t = r)), [t]
}
class _e extends K {
    constructor(e) {
        super(), L(this, e, he, me, O, {})
    }
}

function pe(o) {
    let e, s;
    return e = new _e({}), {
        c() {
            _(e.$$.fragment)
        },
        l(t) {
            p(e.$$.fragment, t)
        },
        m(t, r) {
            d(e, t, r), s = !0
        },
        p: x,
        i(t) {
            s || (m(e.$$.fragment, t), s = !0)
        },
        o(t) {
            h(e.$$.fragment, t), s = !1
        },
        d(t) {
            g(e, t)
        }
    }
}

function de(o) {
    let e, s, t, r, n = o[6] && D(o);
    return t = new re({
        props: {
            showIsMe: o[3],
            user: o[0],
            $$slots: {
                default: [ke]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            e = v("div"), n && n.c(), s = R(), _(t.$$.fragment), this.h()
        },
        l(a) {
            e = k(a, "DIV", {
                class: !0,
                style: !0
            });
            var i = P(e);
            n && n.l(i), s = F(i), p(t.$$.fragment, i), i.forEach(u), this.h()
        },
        h() {
            $(e, "class", "wrap svelte-z6sq38"), $(e, "style", o[4]), V(e, "ghost", o[6])
        },
        m(a, i) {
            b(a, e, i), n && n.m(e, null), w(e, s), d(t, e, null), r = !0
        },
        p(a, i) {
            a[6] ? n ? (n.p(a, i), i & 64 && m(n, 1)) : (n = D(a), n.c(), m(n, 1), n.m(e, s)) : n && (y(), h(n, 1, 1, () => {
                n = null
            }), J());
            const l = {};
            i & 8 && (l.showIsMe = a[3]), i & 1 && (l.user = a[0]), i & 4391 && (l.$$scope = {
                dirty: i,
                ctx: a
            }), t.$set(l), (!r || i & 16) && $(e, "style", a[4]), (!r || i & 64) && V(e, "ghost", a[6])
        },
        i(a) {
            r || (m(n), m(t.$$.fragment, a), r = !0)
        },
        o(a) {
            h(n), h(t.$$.fragment, a), r = !1
        },
        d(a) {
            a && u(e), n && n.d(), g(t)
        }
    }
}

function D(o) {
    let e, s, t;
    return s = new W({
        props: {
            $$slots: {
                tooltip: [$e],
                default: [ge]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            e = v("span"), _(s.$$.fragment), this.h()
        },
        l(r) {
            e = k(r, "SPAN", {
                class: !0
            });
            var n = P(e);
            p(s.$$.fragment, n), n.forEach(u), this.h()
        },
        h() {
            $(e, "class", "ghost svelte-z6sq38")
        },
        m(r, n) {
            b(r, e, n), d(s, e, null), t = !0
        },
        p(r, n) {
            const a = {};
            n & 4224 && (a.$$scope = {
                dirty: n,
                ctx: r
            }), s.$set(a)
        },
        i(r) {
            t || (m(s.$$.fragment, r), t = !0)
        },
        o(r) {
            h(s.$$.fragment, r), t = !1
        },
        d(r) {
            r && u(e), g(s)
        }
    }
}

function ge(o) {
    let e, s;
    return e = new X({}), {
        c() {
            _(e.$$.fragment)
        },
        l(t) {
            p(e.$$.fragment, t)
        },
        m(t, r) {
            d(e, t, r), s = !0
        },
        i(t) {
            s || (m(e.$$.fragment, t), s = !0)
        },
        o(t) {
            h(e.$$.fragment, t), s = !1
        },
        d(t) {
            g(e, t)
        }
    }
}

function $e(o) {
    let e, s = o[7]._(z.hiddenTooltip) + "",
        t;
    return {
        c() {
            e = v("span"), t = I(s), this.h()
        },
        l(r) {
            e = k(r, "SPAN", {
                slot: !0
            });
            var n = P(e);
            t = M(n, s), n.forEach(u), this.h()
        },
        h() {
            $(e, "slot", "tooltip")
        },
        m(r, n) {
            b(r, e, n), w(e, t)
        },
        p(r, n) {
            n & 128 && s !== (s = r[7]._(z.hiddenTooltip) + "") && E(t, s)
        },
        d(r) {
            r && u(e)
        }
    }
}

function be(o) {
    let e = o[0].name + "",
        s;
    return {
        c() {
            s = I(e)
        },
        l(t) {
            s = M(t, e)
        },
        m(t, r) {
            b(t, s, r)
        },
        p(t, r) {
            r & 1 && e !== (e = t[0].name + "") && E(s, e)
        },
        d(t) {
            t && u(s)
        }
    }
}

function ve(o) {
    let e, s;
    return e = new ae({
        props: {
            $$slots: {
                default: [be]
            },
            $$scope: {
                ctx: o
            }
        }
    }), {
        c() {
            _(e.$$.fragment)
        },
        l(t) {
            p(e.$$.fragment, t)
        },
        m(t, r) {
            d(e, t, r), s = !0
        },
        p(t, r) {
            const n = {};
            r & 4097 && (n.$$scope = {
                dirty: r,
                ctx: t
            }), e.$set(n)
        },
        i(t) {
            s || (m(e.$$.fragment, t), s = !0)
        },
        o(t) {
            h(e.$$.fragment, t), s = !1
        },
        d(t) {
            g(e, t)
        }
    }
}

function ke(o) {
    let e, s;
    const t = [{
        "data-analytics": "global-betsBoard-user-button"
    }, o[8], {
        class: C(o[5], "leading-normal")
    }, {
        size: o[2]
    }, {
        variant: o[1]
    }];
    let r = {
        $$slots: {
            default: [ve]
        },
        $$scope: {
            ctx: o
        }
    };
    for (let n = 0; n < t.length; n += 1) r = N(r, t[n]);
    return e = new ie({
        props: r
    }), e.$on("click", o[11]), {
        c() {
            _(e.$$.fragment)
        },
        l(n) {
            p(e.$$.fragment, n)
        },
        m(n, a) {
            d(e, n, a), s = !0
        },
        p(n, a) {
            const i = a & 294 ? ee(t, [t[0], a & 256 && te(n[8]), a & 32 && {
                class: C(n[5], "leading-normal")
            }, a & 4 && {
                size: n[2]
            }, a & 2 && {
                variant: n[1]
            }]) : {};
            a & 4097 && (i.$$scope = {
                dirty: a,
                ctx: n
            }), e.$set(i)
        },
        i(n) {
            s || (m(e.$$.fragment, n), s = !0)
        },
        o(n) {
            h(e.$$.fragment, n), s = !1
        },
        d(n) {
            g(e, n)
        }
    }
}

function Pe(o) {
    let e, s, t, r;
    const n = [de, pe],
        a = [];

    function i(l, c) {
        return l[0] ? 0 : 1
    }
    return e = i(o), s = a[e] = n[e](o), {
        c() {
            s.c(), t = B()
        },
        l(l) {
            s.l(l), t = B()
        },
        m(l, c) {
            a[e].m(l, c), b(l, t, c), r = !0
        },
        p(l, [c]) {
            let T = e;
            e = i(l), e === T ? a[e].p(l, c) : (y(), h(a[T], 1, 1, () => {
                a[T] = null
            }), J(), s = a[e], s ? s.p(l, c) : (s = a[e] = n[e](l), s.c()), m(s, 1), s.m(t.parentNode, t))
        },
        i(l) {
            r || (m(s), r = !0)
        },
        o(l) {
            h(s), r = !1
        },
        d(l) {
            l && u(t), a[e].d(l)
        }
    }
}

function Te(o, e, s) {
    let t;
    const r = ["user", "variant", "size", "showIsMe", "showGhostPreference", "style", "class"];
    let n = q(e, r),
        a, i;
    H(o, oe, f => s(10, a = f)), H(o, Q, f => s(7, i = f));
    let {
        user: l
    } = e, {
        variant: c = "link"
    } = e, {
        size: T = "md"
    } = e, {
        showIsMe: S = !1
    } = e, {
        showGhostPreference: G = !1
    } = e, {
        style: U = ""
    } = e, {
        class: A = ""
    } = e;
    const Y = () => (l == null ? void 0 : l.name) && se.user.open({
        name: l.name
    });
    return o.$$set = f => {
        e = N(N({}, e), Z(f)), s(8, n = q(e, r)), "user" in f && s(0, l = f.user), "variant" in f && s(1, c = f.variant), "size" in f && s(2, T = f.size), "showIsMe" in f && s(3, S = f.showIsMe), "showGhostPreference" in f && s(9, G = f.showGhostPreference), "style" in f && s(4, U = f.style), "class" in f && s(5, A = f.class)
    }, o.$$.update = () => {
        o.$$.dirty & 1537 && s(6, t = G && l && "preferenceHideBets" in l && l.preferenceHideBets && a.includedRoles.includes(ne.support))
    }, [l, c, T, S, U, A, t, i, n, G, a, Y]
}
class Ce extends K {
    constructor(e) {
        super(), L(this, e, Te, Pe, O, {
            user: 0,
            variant: 1,
            size: 2,
            showIsMe: 3,
            showGhostPreference: 9,
            style: 4,
            class: 5
        })
    }
}
export {
    Ce as U, _e as a, z as m
};