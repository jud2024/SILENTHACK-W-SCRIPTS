import {
    R as a
} from "./RestrictedRegion.generated.TUGGhl-h.js";
import {
    w as r
} from "./index.C2-CG2CN.js";
import {
    f as t
} from "./index.B4-7gKq3.js";
async function l(o) {
    return await t({
        doc: a,
        variables: {},
        load: o
    }) || null
}
const c = r(null);
export {
    c as d, l
};