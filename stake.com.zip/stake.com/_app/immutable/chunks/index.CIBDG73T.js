import {
    s as z,
    c as H,
    a as S,
    u as T,
    g as k,
    b as V,
    t as y,
    h as j,
    j as q,
    l as C,
    i as N
} from "./scheduler.DXu26z7T.js";
import {
    S as A,
    i as B,
    c as E,
    a as G,
    m as I,
    t as D,
    b as w,
    d as J
} from "./index.Dz_MmNB3.js";
import {
    i as K
} from "./index.B4-7gKq3.js";
import {
    T as L
} from "./index.D7nbRHfU.js";
const M = s => ({
        formattedValue: s & 64
    }),
    v = s => ({
        formattedValue: s[6]
    });

function O(s) {
    let e;
    return {
        c() {
            e = y(s[6])
        },
        l(t) {
            e = j(t, s[6])
        },
        m(t, i) {
            q(t, e, i)
        },
        p(t, i) {
            i & 64 && C(e, t[6])
        },
        d(t) {
            t && N(e)
        }
    }
}

function P(s) {
    let e;
    const t = s[13].default,
        i = S(t, s, s[14], v),
        n = i || O(s);
    return {
        c() {
            n && n.c()
        },
        l(a) {
            n && n.l(a)
        },
        m(a, m) {
            n && n.m(a, m), e = !0
        },
        p(a, m) {
            i ? i.p && (!e || m & 16448) && T(i, t, a, a[14], e ? V(t, a[14], m, M) : k(a[14]), v) : n && n.p && (!e || m & 64) && n.p(a, e ? m : -1)
        },
        i(a) {
            e || (D(n, a), e = !0)
        },
        o(a) {
            w(n, a), e = !1
        },
        d(a) {
            n && n.d(a)
        }
    }
}

function Q(s) {
    let e, t;
    return e = new L({
        props: {
            weight: s[0],
            numeric: s[1],
            size: s[2],
            variant: s[3],
            align: s[4],
            lineHeight: s[5],
            $$slots: {
                default: [P]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        c() {
            E(e.$$.fragment)
        },
        l(i) {
            G(e.$$.fragment, i)
        },
        m(i, n) {
            I(e, i, n), t = !0
        },
        p(i, [n]) {
            const a = {};
            n & 1 && (a.weight = i[0]), n & 2 && (a.numeric = i[1]), n & 4 && (a.size = i[2]), n & 8 && (a.variant = i[3]), n & 16 && (a.align = i[4]), n & 32 && (a.lineHeight = i[5]), n & 16448 && (a.$$scope = {
                dirty: n,
                ctx: i
            }), e.$set(a)
        },
        i(i) {
            t || (D(e.$$.fragment, i), t = !0)
        },
        o(i) {
            w(e.$$.fragment, i), t = !1
        },
        d(i) {
            J(e, i)
        }
    }
}

function R(s, e, t) {
    let i, n;
    H(s, K, l => t(12, n = l));
    let {
        $$slots: a = {},
        $$scope: m
    } = e, {
        value: f
    } = e, {
        minimumFractionDigits: u = 2
    } = e, {
        maximumFractionDigits: o = 2
    } = e, {
        weight: _ = void 0
    } = e, {
        style: c = void 0
    } = e, {
        numeric: g = !0
    } = e, {
        size: h = void 0
    } = e, {
        variant: b = void 0
    } = e, {
        align: F = void 0
    } = e, {
        responsiveTypeScale: r = !1
    } = e, {
        lineHeight: d = r ? "responsive" : "default"
    } = e;
    return s.$$set = l => {
        "value" in l && t(7, f = l.value), "minimumFractionDigits" in l && t(8, u = l.minimumFractionDigits), "maximumFractionDigits" in l && t(9, o = l.maximumFractionDigits), "weight" in l && t(0, _ = l.weight), "style" in l && t(10, c = l.style), "numeric" in l && t(1, g = l.numeric), "size" in l && t(2, h = l.size), "variant" in l && t(3, b = l.variant), "align" in l && t(4, F = l.align), "responsiveTypeScale" in l && t(11, r = l.responsiveTypeScale), "lineHeight" in l && t(5, d = l.lineHeight), "$$scope" in l && t(14, m = l.$$scope)
    }, s.$$.update = () => {
        s.$$.dirty & 6016 && t(6, i = n.number(f, {
            minimumFractionDigits: u,
            maximumFractionDigits: o,
            style: c
        }))
    }, [_, g, h, b, F, d, i, f, u, o, c, r, n, a, m]
}
class Z extends A {
    constructor(e) {
        super(), B(this, e, R, Q, z, {
            value: 7,
            minimumFractionDigits: 8,
            maximumFractionDigits: 9,
            weight: 0,
            style: 10,
            numeric: 1,
            size: 2,
            variant: 3,
            align: 4,
            responsiveTypeScale: 11,
            lineHeight: 5
        })
    }
}
export {
    Z as F
};