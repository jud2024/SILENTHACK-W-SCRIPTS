import {
    _ as h,
    a as o,
    b as a
} from "./tslib.es6.CYhxggkG.js";
import {
    S as d,
    b as f,
    d as v
} from "./dateTimestampProvider.DBRuHdww.js";
var p = function(s) {
        h(i, s);

        function i(e, t) {
            return s.call(this) || this
        }
        return i.prototype.schedule = function(e, t) {
            return this
        }, i
    }(d),
    u = {
        setInterval: function(s, i) {
            for (var e = [], t = 2; t < arguments.length; t++) e[t - 2] = arguments[t];
            return setInterval.apply(void 0, o([s, i], a(e)))
        },
        clearInterval: function(s) {
            var i = u.delegate;
            return ((i == null ? void 0 : i.clearInterval) || clearInterval)(s)
        },
        delegate: void 0
    },
    y = function(s) {
        h(i, s);

        function i(e, t) {
            var r = s.call(this, e, t) || this;
            return r.scheduler = e, r.work = t, r.pending = !1, r
        }
        return i.prototype.schedule = function(e, t) {
            var r;
            if (t === void 0 && (t = 0), this.closed) return this;
            this.state = e;
            var n = this.id,
                c = this.scheduler;
            return n != null && (this.id = this.recycleAsyncId(c, n, t)), this.pending = !0, this.delay = t, this.id = (r = this.id) !== null && r !== void 0 ? r : this.requestAsyncId(c, this.id, t), this
        }, i.prototype.requestAsyncId = function(e, t, r) {
            return r === void 0 && (r = 0), u.setInterval(e.flush.bind(e, this), r)
        }, i.prototype.recycleAsyncId = function(e, t, r) {
            if (r === void 0 && (r = 0), r != null && this.delay === r && this.pending === !1) return t;
            t != null && u.clearInterval(t)
        }, i.prototype.execute = function(e, t) {
            if (this.closed) return new Error("executing a cancelled action");
            this.pending = !1;
            var r = this._execute(e, t);
            if (r) return r;
            this.pending === !1 && this.id != null && (this.id = this.recycleAsyncId(this.scheduler, this.id, null))
        }, i.prototype._execute = function(e, t) {
            var r = !1,
                n;
            try {
                this.work(e)
            } catch (c) {
                r = !0, n = c || new Error("Scheduled action threw falsy error")
            }
            if (r) return this.unsubscribe(), n
        }, i.prototype.unsubscribe = function() {
            if (!this.closed) {
                var e = this,
                    t = e.id,
                    r = e.scheduler,
                    n = r.actions;
                this.work = this.state = this.scheduler = null, this.pending = !1, f(n, this), t != null && (this.id = this.recycleAsyncId(r, t, null)), this.delay = null, s.prototype.unsubscribe.call(this)
            }
        }, i
    }(p),
    l = function() {
        function s(i, e) {
            e === void 0 && (e = s.now), this.schedulerActionCtor = i, this.now = e
        }
        return s.prototype.schedule = function(i, e, t) {
            return e === void 0 && (e = 0), new this.schedulerActionCtor(this, i).schedule(t, e)
        }, s.now = v.now, s
    }(),
    A = function(s) {
        h(i, s);

        function i(e, t) {
            t === void 0 && (t = l.now);
            var r = s.call(this, e, t) || this;
            return r.actions = [], r._active = !1, r
        }
        return i.prototype.flush = function(e) {
            var t = this.actions;
            if (this._active) {
                t.push(e);
                return
            }
            var r;
            this._active = !0;
            do
                if (r = e.execute(e.state, e.delay)) break; while (e = t.shift());
            if (this._active = !1, r) {
                for (; e = t.shift();) e.unsubscribe();
                throw r
            }
        }, i
    }(l),
    b = new A(y),
    w = b;
export {
    b as a, w as b
};