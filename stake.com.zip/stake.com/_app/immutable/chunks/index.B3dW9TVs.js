import "./index.Dz_MmNB3.js";
import {
    t as ve,
    e as ge
} from "./bundle-mjs.BQkiJtvj.js";
import {
    d as Z,
    w as ye,
    r as $
} from "./index.C2-CG2CN.js";
import {
    o as pe,
    w as he,
    G as Q
} from "./scheduler.DXu26z7T.js";

function me(e) {
    return Object.keys(e).reduce((n, t) => e[t] === void 0 ? n : n + `${t}:${e[t]};`, "")
}

function Ge(e) {
    return e ? !0 : void 0
}
me({
    position: "absolute",
    opacity: 0,
    "pointer-events": "none",
    margin: 0,
    transform: "translateX(-100%)"
});

function We(e) {
    if (e !== null) return ""
}

function B(e) {
    function n(t) {
        return t(e), () => {}
    }
    return {
        subscribe: n
    }
}

function Ke(e) {
    if (!xe) return null;
    const n = document.querySelector(`[data-melt-id="${e}"]`);
    return z(n) ? n : null
}
const S = e => new Proxy(e, {
        get(n, t, a) {
            return Reflect.get(n, t, a)
        },
        ownKeys(n) {
            return Reflect.ownKeys(n).filter(t => t !== "action")
        }
    }),
    I = e => typeof e == "function";
we("empty");

function we(e, n) {
    const {
        stores: t,
        action: a,
        returned: f
    } = n ? ? {}, r = (() => {
        if (t && f) return Z(t, v => {
            const l = f(v);
            if (I(l)) {
                const w = (...y) => S({ ...l(...y),
                    [`data-melt-${e}`]: "",
                    action: a ? ? O
                });
                return w.action = a ? ? O, w
            }
            return S({ ...l,
                [`data-melt-${e}`]: "",
                action: a ? ? O
            })
        }); {
            const v = f,
                l = v == null ? void 0 : v();
            if (I(l)) {
                const w = (...y) => S({ ...l(...y),
                    [`data-melt-${e}`]: "",
                    action: a ? ? O
                });
                return w.action = a ? ? O, B(w)
            }
            return B(S({ ...l,
                [`data-melt-${e}`]: "",
                action: a ? ? O
            }))
        }
    })(), u = a ? ? (() => {});
    return u.subscribe = r.subscribe, u
}

function He(e) {
    const n = r => r ? `${e}-${r}` : e,
        t = r => `data-melt-${e}${r?`-${r}`:""}`,
        a = r => `[data-melt-${e}${r?`-${r}`:""}]`;
    return {
        name: n,
        attribute: t,
        selector: a,
        getEl: r => document.querySelector(a(r))
    }
}
const xe = typeof document < "u",
    Ae = e => typeof e == "function";

function Ue(e) {
    return e instanceof Element
}

function z(e) {
    return e instanceof HTMLElement
}

function ke(e) {
    return e !== null && typeof e == "object"
}

function Ee(e) {
    return ke(e) && "subscribe" in e
}

function Oe(...e) {
    return (...n) => {
        for (const t of e) typeof t == "function" && t(...n)
    }
}

function O() {}

function Y(e, n, t, a) {
    const f = Array.isArray(n) ? n : [n];
    return f.forEach(r => e.addEventListener(r, t, a)), () => {
        f.forEach(r => e.removeEventListener(r, t, a))
    }
}

function Be(e, n, t, a) {
    const f = Array.isArray(n) ? n : [n];
    if (typeof t == "function") {
        const r = $e(u => t(u));
        return f.forEach(u => e.addEventListener(u, r, a)), () => {
            f.forEach(u => e.removeEventListener(u, r, a))
        }
    }
    return () => void 0
}

function Fe(e) {
    const n = e.currentTarget;
    if (!z(n)) return null;
    const t = new CustomEvent(`m-${e.type}`, {
        detail: {
            originalEvent: e
        },
        cancelable: !0
    });
    return n.dispatchEvent(t), t
}

function $e(e) {
    return n => {
        const t = Fe(n);
        if (!(t != null && t.defaultPrevented)) return e(n)
    }
}
const Ie = e => {
        try {
            pe(e)
        } catch {
            return e
        }
    },
    je = e => {
        try {
            he(e)
        } catch {
            return e
        }
    };

function Ve(e, ...n) {
    const t = {};
    for (const a of Object.keys(e)) n.includes(a) || (t[a] = e[a]);
    return t
}

function ee(e) {
    return { ...e,
        get: () => Q(e)
    }
}
ee.writable = function(e) {
    const n = ye(e);
    let t = e;
    return {
        subscribe: n.subscribe,
        set(a) {
            n.set(a), t = a
        },
        update(a) {
            const f = a(t);
            n.set(f), t = f
        },
        get() {
            return t
        }
    }
};
ee.derived = function(e, n) {
    const t = new Map,
        a = () => {
            const r = Array.isArray(e) ? e.map(u => u.get()) : e.get();
            return n(r)
        };
    return {
        get: a,
        subscribe: r => {
            const u = [];
            return (Array.isArray(e) ? e : [e]).forEach(l => {
                u.push(l.subscribe(() => {
                    r(a())
                }))
            }), r(a()), t.set(r, u), () => {
                const l = t.get(r);
                if (l)
                    for (const w of l) w();
                t.delete(r)
            }
        }
    }
};
const Me = {
    ALT: "Alt",
    ARROW_DOWN: "ArrowDown",
    ARROW_LEFT: "ArrowLeft",
    ARROW_RIGHT: "ArrowRight",
    ARROW_UP: "ArrowUp",
    BACKSPACE: "Backspace",
    CAPS_LOCK: "CapsLock",
    CONTROL: "Control",
    DELETE: "Delete",
    END: "End",
    ENTER: "Enter",
    ESCAPE: "Escape",
    F1: "F1",
    F10: "F10",
    F11: "F11",
    F12: "F12",
    F2: "F2",
    F3: "F3",
    F4: "F4",
    F5: "F5",
    F6: "F6",
    F7: "F7",
    F8: "F8",
    F9: "F9",
    HOME: "Home",
    META: "Meta",
    PAGE_DOWN: "PageDown",
    PAGE_UP: "PageUp",
    SHIFT: "Shift",
    SPACE: " ",
    TAB: "Tab",
    CTRL: "Control",
    ASTERISK: "*",
    A: "a",
    P: "p"
};

function _e(e, n) {
    let t;
    const a = Z(e, r => {
            t == null || t(), t = n(r)
        }).subscribe(O),
        f = () => {
            a(), t == null || t()
        };
    return je(f), f
}
$(void 0, e => {
    function n(a) {
        e(a), e(void 0)
    }
    return Y(document, "pointerup", n, {
        passive: !1,
        capture: !0
    })
});
const Ce = $(void 0, e => {
        function n(a) {
            a && a.key === Me.ESCAPE && e(a), e(void 0)
        }
        return Y(document, "keydown", n, {
            passive: !1
        })
    }),
    qe = (e, n = {}) => {
        let t = O;

        function a(f = {}) {
            t();
            const r = {
                    enabled: !0,
                    ...f
                },
                u = Ee(r.enabled) ? r.enabled : $(r.enabled);
            t = Oe(Ce.subscribe(v => {
                var w;
                if (!v || !Q(u)) return;
                const l = v.target;
                if (!(!z(l) || l.closest("[data-escapee]") !== e)) {
                    if (v.preventDefault(), r.ignore) {
                        if (Ae(r.ignore)) {
                            if (r.ignore(v)) return
                        } else if (Array.isArray(r.ignore) && r.ignore.length > 0 && r.ignore.some(y => y && l === y)) return
                    }(w = r.handler) == null || w.call(r, v)
                }
            }), _e(u, v => {
                v ? e.dataset.escapee = "" : delete e.dataset.escapee
            }))
        }
        return a(n), {
            update: a,
            destroy() {
                e.removeAttribute("data-escapee"), t()
            }
        }
    };
$(!1), $(!1), $(void 0);
const De = {
    isDateDisabled: void 0,
    isDateUnavailable: void 0,
    value: void 0,
    preventDeselect: !1,
    numberOfMonths: 1,
    pagedNavigation: !1,
    weekStartsOn: 0,
    fixedWeeks: !1,
    calendarLabel: "Event Date",
    locale: "en",
    minValue: void 0,
    maxValue: void 0,
    disabled: !1,
    readonly: !1,
    weekdayFormat: "narrow"
};
({ ...Ve(De, "isDateDisabled", "isDateUnavailable", "value", "locale", "disabled", "readonly", "minValue", "maxValue", "weekdayFormat")
});
var q = e => typeof e == "boolean" ? `${e}` : e === 0 ? "0" : e,
    x = e => !e || typeof e != "object" || Object.keys(e).length === 0,
    Se = (e, n) => JSON.stringify(e) === JSON.stringify(n);

function te(e, n) {
    e.forEach(function(t) {
        Array.isArray(t) ? te(t, n) : n.push(t)
    })
}

function ne(e) {
    let n = [];
    return te(e, n), n
}
var re = (...e) => ne(e).filter(Boolean),
    ae = (e, n) => {
        let t = {},
            a = Object.keys(e),
            f = Object.keys(n);
        for (let r of a)
            if (f.includes(r)) {
                let u = e[r],
                    v = n[r];
                typeof u == "object" && typeof v == "object" ? t[r] = ae(u, v) : Array.isArray(u) || Array.isArray(v) ? t[r] = re(v, u) : t[r] = v + " " + u
            } else t[r] = e[r];
        for (let r of f) a.includes(r) || (t[r] = n[r]);
        return t
    },
    J = e => !e || typeof e != "string" ? e : e.replace(/\s+/g, " ").trim(),
    Te = {
        twMerge: !0,
        twMergeConfig: {},
        responsiveVariants: !1
    },
    ie = e => e || void 0,
    _ = (...e) => ie(ne(e).filter(Boolean).join(" ")),
    P = null,
    k = {},
    N = !1,
    M = (...e) => n => n.twMerge ? ((!P || N) && (N = !1, P = x(k) ? ve : ge({ ...k,
        extend: {
            theme: k.theme,
            classGroups: k.classGroups,
            conflictingClassGroupModifiers: k.conflictingClassGroupModifiers,
            conflictingClassGroups: k.conflictingClassGroups,
            ...k.extend
        }
    })), ie(P(_(e)))) : _(e),
    X = (e, n) => {
        for (let t in n) e.hasOwnProperty(t) ? e[t] = _(e[t], n[t]) : e[t] = n[t];
        return e
    },
    Re = (e, n) => {
        let {
            extend: t = null,
            slots: a = {},
            variants: f = {},
            compoundVariants: r = [],
            compoundSlots: u = [],
            defaultVariants: v = {}
        } = e, l = { ...Te,
            ...n
        }, w = t != null && t.base ? _(t.base, e == null ? void 0 : e.base) : e == null ? void 0 : e.base, y = t != null && t.variants && !x(t.variants) ? ae(f, t.variants) : f, C = t != null && t.defaultVariants && !x(t.defaultVariants) ? { ...t.defaultVariants,
            ...v
        } : v;
        !x(l.twMergeConfig) && !Se(l.twMergeConfig, k) && (N = !0, k = l.twMergeConfig);
        let D = x(t == null ? void 0 : t.slots),
            T = x(a) ? {} : {
                base: _(e == null ? void 0 : e.base, D && (t == null ? void 0 : t.base)),
                ...a
            },
            j = D ? T : X({ ...t == null ? void 0 : t.slots
            }, x(T) ? {
                base: e == null ? void 0 : e.base
            } : T),
            F = x(t == null ? void 0 : t.compoundVariants) ? r : re(t == null ? void 0 : t.compoundVariants, r),
            A = h => {
                if (x(y) && x(a) && D) return M(w, h == null ? void 0 : h.class, h == null ? void 0 : h.className)(l);
                if (F && !Array.isArray(F)) throw new TypeError(`The "compoundVariants" prop must be an array. Received: ${typeof F}`);
                if (u && !Array.isArray(u)) throw new TypeError(`The "compoundSlots" prop must be an array. Received: ${typeof u}`);
                let oe = (i, o, s = [], d) => {
                        let c = s;
                        if (typeof o == "string") c = c.concat(J(o).split(" ").map(b => `${i}:${b}`));
                        else if (Array.isArray(o)) c = c.concat(o.reduce((b, g) => b.concat(`${i}:${g}`), []));
                        else if (typeof o == "object" && typeof d == "string") {
                            for (let b in o)
                                if (o.hasOwnProperty(b) && b === d) {
                                    let g = o[b];
                                    if (g && typeof g == "string") {
                                        let p = J(g);
                                        c[d] ? c[d] = c[d].concat(p.split(" ").map(m => `${i}:${m}`)) : c[d] = p.split(" ").map(m => `${i}:${m}`)
                                    } else Array.isArray(g) && g.length > 0 && (c[d] = g.reduce((p, m) => p.concat(`${i}:${m}`), []))
                                }
                        }
                        return c
                    },
                    G = (i, o = y, s = null, d = null) => {
                        var c;
                        let b = o[i];
                        if (!b || x(b)) return null;
                        let g = (c = d == null ? void 0 : d[i]) != null ? c : h == null ? void 0 : h[i];
                        if (g === null) return null;
                        let p = q(g),
                            m = Array.isArray(l.responsiveVariants) && l.responsiveVariants.length > 0 || l.responsiveVariants === !0,
                            V = C == null ? void 0 : C[i],
                            E = [];
                        if (typeof p == "object" && m)
                            for (let [L, U] of Object.entries(p)) {
                                let be = b[U];
                                if (L === "initial") {
                                    V = U;
                                    continue
                                }
                                Array.isArray(l.responsiveVariants) && !l.responsiveVariants.includes(L) || (E = oe(L, be, E, s))
                            }
                        let fe = p != null && typeof p != "object" ? p : q(V),
                            R = b[fe || "false"];
                        return typeof E == "object" && typeof s == "string" && E[s] ? X(E, R) : E.length > 0 ? (E.push(R), E) : R
                    },
                    le = () => y ? Object.keys(y).map(i => G(i, y)) : null,
                    ue = (i, o) => {
                        if (!y || typeof y != "object") return null;
                        let s = new Array;
                        for (let d in y) {
                            let c = G(d, y, i, o),
                                b = i === "base" && typeof c == "string" ? c : c && c[i];
                            b && (s[s.length] = b)
                        }
                        return s
                    },
                    W = {};
                for (let i in h) h[i] !== void 0 && (W[i] = h[i]);
                let K = (i, o) => {
                        var s;
                        let d = typeof(h == null ? void 0 : h[i]) == "object" ? {
                            [i]: (s = h[i]) == null ? void 0 : s.initial
                        } : {};
                        return { ...C,
                            ...W,
                            ...d,
                            ...o
                        }
                    },
                    H = (i = [], o) => {
                        let s = [];
                        for (let {
                                class: d,
                                className: c,
                                ...b
                            } of i) {
                            let g = !0;
                            for (let [p, m] of Object.entries(b)) {
                                let V = K(p, o);
                                if (Array.isArray(m)) {
                                    if (!m.includes(V[p])) {
                                        g = !1;
                                        break
                                    }
                                } else if (V[p] !== m) {
                                    g = !1;
                                    break
                                }
                            }
                            g && (d && s.push(d), c && s.push(c))
                        }
                        return s
                    },
                    ce = i => {
                        let o = H(F, i);
                        if (!Array.isArray(o)) return o;
                        let s = {};
                        for (let d of o)
                            if (typeof d == "string" && (s.base = M(s.base, d)(l)), typeof d == "object")
                                for (let [c, b] of Object.entries(d)) s[c] = M(s[c], b)(l);
                        return s
                    },
                    de = i => {
                        if (u.length < 1) return null;
                        let o = {};
                        for (let {
                                slots: s = [],
                                class: d,
                                className: c,
                                ...b
                            } of u) {
                            if (!x(b)) {
                                let g = !0;
                                for (let p of Object.keys(b)) {
                                    let m = K(p, i)[p];
                                    if (m === void 0 || (Array.isArray(b[p]) ? !b[p].includes(m) : b[p] !== m)) {
                                        g = !1;
                                        break
                                    }
                                }
                                if (!g) continue
                            }
                            for (let g of s) o[g] = o[g] || [], o[g].push([d, c])
                        }
                        return o
                    };
                if (!x(a) || !D) {
                    let i = {};
                    if (typeof j == "object" && !x(j))
                        for (let o of Object.keys(j)) i[o] = s => {
                            var d, c;
                            return M(j[o], ue(o, s), ((d = ce(s)) != null ? d : [])[o], ((c = de(s)) != null ? c : [])[o], s == null ? void 0 : s.class, s == null ? void 0 : s.className)(l)
                        };
                    return i
                }
                return M(w, le(), H(F), h == null ? void 0 : h.class, h == null ? void 0 : h.className)(l)
            },
            se = () => {
                if (!(!y || typeof y != "object")) return Object.keys(y)
            };
        return A.variantKeys = se(), A.extend = t, A.base = w, A.slots = j, A.variants = y, A.defaultVariants = C, A.compoundSlots = u, A.compoundVariants = F, A
    };
const Je = Re({
    base: "inline-flex relative items-center gap-2 justify-center rounded-sm font-semibold whitespace-nowrap ring-offset-background transition disabled:pointer-events-none disabled:opacity-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 active:scale-[0.98]",
    variants: {
        variant: {
            tab: "bg-grey-700 text-white betterhover:hover:bg-grey-900 betterhover:hover:text-white focus-visible:outline-white",
            dropdown: "bg-transparent text-grey-400 betterhover:hover:bg-grey-200 betterhover:hover:text-neutral-black focus-visible:outline-grey-300",
            minimal: "bg-transparent text-white betterhover:hover:bg-grey-900 betterhover:hover:text-white focus-visible:outline-white",
            danger: "bg-red-500 text-white betterhover:hover:bg-red-600 betterhover:hover:text-white focus-visible:outline-white",
            tabmenu: "bg-transparent text-white betterhover:hover:bg-grey-400 betterhover:hover:text-white focus-visible:outline-white",
            neutral: "bg-grey-400 text-white betterhover:hover:bg-grey-300 betterhover:hover:text-white focus-visible:outline-white",
            "subtle-link": "bg-transparent text-grey-200 betterhover:hover:bg-transparent betterhover:hover:text-white focus-visible:text-white focus-visible:outline-none",
            link: "bg-transparent text-white betterhover:hover:bg-transparent betterhover:hover:text-white focus-visible:outline-none",
            success: "bg-green-500 text-neutral-black betterhover:hover:bg-green-400 betterhover:hover:text-neutral-black focus-visible:outline-white",
            action: "bg-blue-500 text-white betterhover:hover:bg-blue-600 betterhover:hover:text-white focus-visible:outline-white",
            outlined: "bg-transparent text-white betterhover:hover:bg-grey-400 betterhover:hover:text-white border border-solid border-white"
        },
        size: {
            xs: "text-xs leading-none",
            sm: "text-sm leading-none",
            md: "text-sm leading-none",
            lg: "text-base leading-none",
            xl: "text-base leading-none"
        },
        iconOnly: {
            true: ""
        },
        active: {
            true: ""
        }
    },
    defaultVariants: {
        variant: "link",
        size: "md",
        iconOnly: !1
    },
    compoundVariants: [{
        variant: "link",
        iconOnly: !1,
        class: "[&_svg]:text-grey-200 [&:hover>svg]:text-white"
    }, {
        variant: "tabmenu",
        iconOnly: !1,
        class: "[&_svg]:text-grey-200 [&:hover>svg]:text-white"
    }, {
        variant: "minimal",
        iconOnly: !1,
        class: "[&_svg]:text-grey-200 [&:hover>svg]:text-white"
    }, {
        variant: "dropdown",
        iconOnly: !1,
        class: "[&_svg]:text-grey-400 [&:hover>svg]:text-grey-400"
    }, {
        variant: "tab",
        iconOnly: !1,
        class: "[&_svg]:text-grey-200 [&:hover>svg]:text-white"
    }, {
        variant: ["success", "action", "danger", "neutral"],
        class: "shadow-md"
    }, {
        size: "xs",
        variant: ["success", "action", "danger", "tab", "minimal", "tabmenu", "neutral", "outlined"],
        class: "py-[0.75rem] px-[0.75rem]"
    }, {
        size: "sm",
        variant: ["success", "action", "danger", "tab", "minimal", "tabmenu", "neutral", "outlined"],
        class: "py-[0.8125rem] px-[1rem]"
    }, {
        size: "md",
        variant: ["success", "action", "danger", "tab", "minimal", "tabmenu", "neutral", "outlined"],
        class: "py-[0.9375rem] px-[1.25rem]"
    }, {
        size: "lg",
        variant: ["success", "action", "danger", "tab", "minimal", "tabmenu", "neutral", "outlined"],
        class: "py-4 px-5"
    }, {
        variant: ["success", "action", "danger", "tab", "minimal", "tabmenu", "neutral", "outlined"],
        size: "xl",
        class: "py-[1.125rem] px-[1.75rem]"
    }, {
        variant: ["dropdown"],
        class: "px-3 py-3"
    }, {
        variant: ["tab", "minimal", "tabmenu"],
        class: "rounded-full"
    }, {
        variant: ["dropdown"],
        class: "rounded-none"
    }, {
        variant: "tab",
        class: "!bg-grey-900 !text-white [&_svg]:!text-white",
        active: !0
    }, {
        variant: "dropdown",
        class: "!bg-transparent !text-blue-500 [&_svg]:!text-blue-500",
        active: !0
    }, {
        variant: "minimal",
        class: "!bg-grey-900 !text-white [&_svg]:!text-white",
        active: !0
    }, {
        variant: "danger",
        class: "!bg-red-600 !text-white [&_svg]:!text-white",
        active: !0
    }, {
        variant: "tabmenu",
        class: "!bg-grey-400 !text-white [&_svg]:!text-white",
        active: !0
    }, {
        variant: "neutral",
        class: "!bg-grey-700 !text-grey-200 [&_svg]:!text-white",
        active: !0
    }, {
        variant: "subtle-link",
        class: "!bg-transparent !text-white [&_svg]:!text-white focus-visible:text-white focus-visible!:[&_svg]:text-white",
        active: !0
    }, {
        variant: "link",
        class: "!bg-transparent !text-white [&_svg]:!text-white",
        active: !0
    }, {
        variant: "success",
        class: "!bg-green-400 !text-green-700 [&_svg]:!text-green-700",
        active: !0
    }, {
        variant: "action",
        class: "!bg-blue-500 !text-grey-200 [&_svg]:!text-white",
        active: !0
    }, {
        size: "xs",
        variant: ["link", "subtle-link"],
        iconOnly: !0,
        class: "py-[0.75rem] px-[0.75rem]"
    }, {
        size: "sm",
        variant: ["link", "subtle-link"],
        iconOnly: !0,
        class: "py-[0.8125rem] px-[1rem]"
    }, {
        size: "md",
        variant: ["link", "subtle-link"],
        iconOnly: !0,
        class: "py-[0.9375rem] px-[1.25rem]"
    }, {
        size: "lg",
        variant: ["link", "subtle-link"],
        iconOnly: !0,
        class: "py-4 px-5"
    }, {
        variant: ["link", "subtle-link"],
        iconOnly: !0,
        size: "xl",
        class: "py-[1.125rem] px-[1.75rem]"
    }]
});
export {
    He as a, Je as b, Re as c, Ge as d, Oe as e, Be as f, Ke as g, Ae as h, z as i, Ue as j, Me as k, Y as l, we as m, O as n, Ve as o, Ie as p, xe as q, We as r, me as s, _e as t, qe as u, ee as w
};