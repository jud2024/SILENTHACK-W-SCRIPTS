import {
    s as h,
    C as u,
    H as f,
    D as m,
    f as v,
    E as _,
    i as r,
    F as c,
    j as d,
    n as o
} from "./scheduler.DXu26z7T.js";
import {
    S as g,
    i as y
} from "./index.Dz_MmNB3.js";

function C(n) {
    let l, a, s = ` <title>${n[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M31.943 13.08c-9.37 0-17.128 6.904-18.476 16.004l4.798-.002-9.146 12.96-9.12-12.96h5.334l.012-.124C6.889 15.536 18.291 5.112 32.127 5.112a26.823 26.823 0 0 1 17.5 6.452l-5.334 6.186.02.018a18.584 18.584 0 0 0-12.37-4.688Zm22.937 8.752L64 34.792h-5.174l-.01.12C57.332 48.398 45.902 58.888 32.02 58.888a26.826 26.826 0 0 1-17.646-6.576l5.334-6.186a18.597 18.597 0 0 0 12.47 4.776c9.406 0 17.188-6.96 18.49-16.11h-4.934l9.146-12.96ZM19.708 46.126l-.016-.014.016.014Z"></path>`,
        i;
    return {
        c() {
            l = u("svg"), a = new f(!0), this.h()
        },
        l(t) {
            l = m(t, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var e = v(l);
            a = _(e, !0), e.forEach(r), this.h()
        },
        h() {
            a.a = null, c(l, "fill", "currentColor"), c(l, "viewBox", "0 0 64 64"), c(l, "class", i = "svg-icon " + n[2]), c(l, "style", n[0])
        },
        m(t, e) {
            d(t, l, e), a.m(s, l)
        },
        p(t, [e]) {
            e & 2 && s !== (s = ` <title>${t[1]||""}</title> <path fill-rule="evenodd" clip-rule="evenodd" d="M31.943 13.08c-9.37 0-17.128 6.904-18.476 16.004l4.798-.002-9.146 12.96-9.12-12.96h5.334l.012-.124C6.889 15.536 18.291 5.112 32.127 5.112a26.823 26.823 0 0 1 17.5 6.452l-5.334 6.186.02.018a18.584 18.584 0 0 0-12.37-4.688Zm22.937 8.752L64 34.792h-5.174l-.01.12C57.332 48.398 45.902 58.888 32.02 58.888a26.826 26.826 0 0 1-17.646-6.576l5.334-6.186a18.597 18.597 0 0 0 12.47 4.776c9.406 0 17.188-6.96 18.49-16.11h-4.934l9.146-12.96ZM19.708 46.126l-.016-.014.016.014Z"></path>`) && a.p(s), e & 4 && i !== (i = "svg-icon " + t[2]) && c(l, "class", i), e & 1 && c(l, "style", t[0])
        },
        i: o,
        o,
        d(t) {
            t && r(l)
        }
    }
}

function Z(n, l, a) {
    let {
        style: s = ""
    } = l, {
        alt: i = ""
    } = l, {
        class: t = ""
    } = l;
    return n.$$set = e => {
        "style" in e && a(0, s = e.style), "alt" in e && a(1, i = e.alt), "class" in e && a(2, t = e.class)
    }, [s, i, t]
}
class H extends g {
    constructor(l) {
        super(), y(this, l, Z, C, h, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    H as R
};