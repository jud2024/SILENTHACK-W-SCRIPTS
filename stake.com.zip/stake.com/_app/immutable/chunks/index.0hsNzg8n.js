import {
    w as e
} from "./index.C2-CG2CN.js";
const p = (() => {
    const t = e(null);
    return { ...t,
        openSubscription: (n, o) => {
            t.update(r => (r != null && r.unsubscribe && (r == null || r.unsubscribe()), {
                type: n,
                unsubscribe: o
            }))
        }
    }
})();
export {
    p as o
};