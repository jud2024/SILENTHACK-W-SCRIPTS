import {
    s as C,
    m as u,
    j as S,
    n as m,
    i as c,
    e as M,
    t as P,
    d as I,
    f as V,
    h as j,
    F as d,
    V as g,
    k as q
} from "./scheduler.DXu26z7T.js";
import {
    e as y,
    u as z,
    d as E
} from "./each.DvgCmocI.js";
import {
    S as N,
    i as T
} from "./index.Dz_MmNB3.js";
import {
    a as p
} from "./index.B81orGJm.js"; /* empty css                                            */
const f = ["57%", "70%", "54%", "70%", "62%", "64%", "100%", "50%", "75%", "91%", "84%", "86%", "53%", "68%", "74%", "81%", "56%", "79%", "80%", "91%", "85%", "80%", "65%", "86%", "85%", "89%", "55%", "72%", "72%", "100%", "69%", "77%", "61%", "96%", "61%", "63%", "83%", "51%", "56%", "79%", "65%", "59%", "83%", "84%", "81%", "83%", "67%", "52%", "81%", "93%", "88%", "66%", "78%", "90%", "91%", "94%", "80%", "60%", "76%", "97%", "77%", "58%", "63%", "80%", "58%", "93%", "92%", "72%", "55%", "67%", "54%", "70%", "66%", "58%", "83%", "85%", "88%", "67%", "52%", "73%", "93%", "93%", "95%", "75%", "99%", "55%", "88%", "58%", "79%", "84%", "69%", "56%", "63%", "80%", "75%", "68%", "64%", "87%", "57%", "100%"];

function w(h, e, i) {
    const n = h.slice();
    return n[7] = e[i], n[9] = i, n
}

function k(h, e) {
    let i, n, s;
    return {
        key: h,
        first: null,
        c() {
            i = M("span"), n = P(` 
  `), this.h()
        },
        l(o) {
            i = I(o, "SPAN", {
                class: !0,
                style: !0
            });
            var t = V(i);
            n = j(t, ` 
  `), t.forEach(c), this.h()
        },
        h() {
            d(i, "class", "line chromatic-ignore svelte-hvwfol"), d(i, "style", s = "width: " + e[3](e[7].width) + "; height: " + e[3](e[7].height) + "; " + e[0]), g(i, "is-rounded", e[1]), this.first = i
        },
        m(o, t) {
            S(o, i, t), q(i, n)
        },
        p(o, t) {
            e = o, t & 5 && s !== (s = "width: " + e[3](e[7].width) + "; height: " + e[3](e[7].height) + "; " + e[0]) && d(i, "style", s), t & 2 && g(i, "is-rounded", e[1])
        },
        d(o) {
            o && c(i)
        }
    }
}

function B(h) {
    let e = [],
        i = new Map,
        n, s = y(h[2]);
    const o = t => t[9];
    for (let t = 0; t < s.length; t += 1) {
        let l = w(h, s, t),
            r = o(l);
        i.set(r, e[t] = k(r, l))
    }
    return {
        c() {
            for (let t = 0; t < e.length; t += 1) e[t].c();
            n = u()
        },
        l(t) {
            for (let l = 0; l < e.length; l += 1) e[l].l(t);
            n = u()
        },
        m(t, l) {
            for (let r = 0; r < e.length; r += 1) e[r] && e[r].m(t, l);
            S(t, n, l)
        },
        p(t, [l]) {
            l & 15 && (s = y(t[2]), e = z(e, l, o, 1, t, s, i, n.parentNode, E, k, n, w))
        },
        i: m,
        o: m,
        d(t) {
            t && c(n);
            for (let l = 0; l < e.length; l += 1) e[l].d(t)
        }
    }
}
const F = (h, e) => Math.floor(Math.random() * (e - h + 1)) + h;

function G(h, e, i) {
    let {
        width: n = 0
    } = e, {
        lines: s = 1
    } = e, {
        height: o = "auto"
    } = e, {
        style: t = ""
    } = e, {
        rounded: l = !1
    } = e, r;
    const b = a => typeof a == "string" ? a : `${a}px`;
    return h.$$set = a => {
        "width" in a && i(4, n = a.width), "lines" in a && i(5, s = a.lines), "height" in a && i(6, o = a.height), "style" in a && i(0, t = a.style), "rounded" in a && i(1, l = a.rounded)
    }, h.$$.update = () => {
        h.$$.dirty & 112 && i(2, r = Array(s).fill(0).map((a, _) => ({
            width: n && n || s && _ === s - 1 && "100%" || (p ? (f == null ? void 0 : f[_]) || "100%" : `${F(50,100)}%`),
            height: o
        })))
    }, [t, l, r, b, n, s, o]
}
class R extends N {
    constructor(e) {
        super(), T(this, e, G, B, C, {
            width: 4,
            lines: 5,
            height: 6,
            style: 0,
            rounded: 1
        })
    }
}
export {
    R as P, F as g
};