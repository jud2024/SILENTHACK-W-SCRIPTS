import "./index.ByMdEFI5.js";
import {
    a as d,
    d as m
} from "./index.B81orGJm.js";
import "./index.lhCIiKC2.js";
import {
    G as l
} from "./scheduler.DXu26z7T.js";
import {
    f as o,
    r as k
} from "./index.B4-7gKq3.js";
import "./messages.BhHwkfmF.js";
import "./index.DGKYLdH2.js";
const r = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "query",
            name: {
                kind: "Name",
                value: "SportMarketNews"
            },
            variableDefinitions: [{
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "marketId"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "String"
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "provider"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "SportsbookOddsProviderEnum"
                        }
                    }
                }
            }],
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "sportMarket"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "marketId"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "marketId"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "provider"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "provider"
                            }
                        }
                    }],
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "SportMarket"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "outcomes"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "SportMarketOutcome"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "fixture"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "id"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "status"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "data"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "FragmentSpread",
                                            name: {
                                                kind: "Name",
                                                value: "SportFixtureDataMatch"
                                            }
                                        }, {
                                            kind: "FragmentSpread",
                                            name: {
                                                kind: "Name",
                                                value: "SportFixtureDataOutright"
                                            }
                                        }, {
                                            kind: "Field",
                                            name: {
                                                kind: "Name",
                                                value: "__typename"
                                            }
                                        }]
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "tournament"
                                    },
                                    selectionSet: {
                                        kind: "SelectionSet",
                                        selections: [{
                                            kind: "FragmentSpread",
                                            name: {
                                                kind: "Name",
                                                value: "TournamentTree"
                                            }
                                        }]
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportFixtureCompetitor"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportFixtureCompetitor"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "extId"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "countryCode"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "abbreviation"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "iconPath"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "CategoryTree"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportCategory"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "slug"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "sport"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "slug"
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportMarket"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportMarket"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "status"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "extId"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "specifiers"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "customBetAvailable"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "provider"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportMarketOutcome"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportMarketOutcome"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "active"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "odds"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "customBetAvailable"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportFixtureDataMatch"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportFixtureDataMatch"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "startTime"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "competitors"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "SportFixtureCompetitor"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "teams"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "qualifier"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "tvChannels"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "language"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "streamUrl"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportFixtureDataOutright"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportFixtureDataOutright"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "startTime"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "endTime"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "TournamentTree"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportTournament"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "id"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "slug"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "category"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "CategoryTree"
                            }
                        }]
                    }
                }]
            }
        }]
    },
    F = e => {
        const n = {};
        return e.split("|").forEach(i => {
            const [a, t] = i.split("=");
            n[a] = t.charAt(0).toUpperCase() + t.slice(1)
        }), n
    },
    y = e => {
        const n = ["th", "st", "nd", "rd"],
            i = e % 100;
        return e + (n[(i - 20) % 10] || n[i] || n[0])
    },
    f = (e = "") => {
        const [n, i = null] = e.split(":");
        return {
            address: n,
            tag: i
        }
    },
    D = e => d ? `${e}?q=1&auto=format&blur=200` : `${e}?q=80&auto=format`;

function g(e) {
    return (e == null ? void 0 : e.amount) === 0 ? (e == null ? void 0 : e.payout) ? ? 0 : ((e == null ? void 0 : e.payoutMultiplier) > 0 ? (e == null ? void 0 : e.payoutMultiplier) >= 1 ? e == null ? void 0 : e.payout : (e == null ? void 0 : e.payout) - (e == null ? void 0 : e.amount) : -(e == null ? void 0 : e.amount)) || 0
}
const h = async (e, n) => {
        try {
            const i = await o({
                doc: r,
                variables: { ...e
                },
                load: n
            });
            return i == null ? void 0 : i.sportMarket
        } catch (i) {
            console.error(i)
        }
    },
    C = (e, n) => {
        const i = l(k);
        return n != null && n.startsWith(i("/casino")) || m === "sweeps" ? "casino" : n != null && n.startsWith(i("/sports")) ? "sports" : e.startsWith(i("/casino")) ? "casino" : e.startsWith(i("/sports")) ? "sports" : void 0
    },
    M = e => e * 100;
export {
    r as S, D as a, g as b, M as c, F as d, C as e, f, y as g, h as l
};