import {
    s as y,
    a as q,
    K as _,
    e as B,
    d as S,
    f as V,
    i as v,
    Q as c,
    V as o,
    j,
    u as C,
    g as D,
    b as E,
    L as h,
    M as z
} from "./scheduler.DXu26z7T.js";
import {
    S as I,
    i as K,
    t as L,
    b as M
} from "./index.Dz_MmNB3.js";
import {
    g as P
} from "./spread.CgU5AtxT.js";
import {
    c as b
} from "./index.BljstGtu.js";

function Q(i) {
    let e, l, u;
    const f = i[8].default,
        t = q(f, i, i[7], null);
    let d = [i[5], {
            class: l = b(`badge variant-${i[0]} size-${i[3]} text-size-${i[3]}`, i[6].class)
        }, {
            style: i[4]
        }],
        r = {};
    for (let s = 0; s < d.length; s += 1) r = _(r, d[s]);
    return {
        c() {
            e = B("div"), t && t.c(), this.h()
        },
        l(s) {
            e = S(s, "DIV", {
                class: !0,
                style: !0
            });
            var a = V(e);
            t && t.l(a), a.forEach(v), this.h()
        },
        h() {
            c(e, r), o(e, "is-inline", i[2]), o(e, "is-rounded", i[1]), o(e, "svelte-1nsqxew", !0)
        },
        m(s, a) {
            j(s, e, a), t && t.m(e, null), u = !0
        },
        p(s, [a]) {
            t && t.p && (!u || a & 128) && C(t, f, s, s[7], u ? E(f, s[7], a, null) : D(s[7]), null), c(e, r = P(d, [a & 32 && s[5], (!u || a & 73 && l !== (l = b(`badge variant-${s[0]} size-${s[3]} text-size-${s[3]}`, s[6].class))) && {
                class: l
            }, (!u || a & 16) && {
                style: s[4]
            }])), o(e, "is-inline", s[2]), o(e, "is-rounded", s[1]), o(e, "svelte-1nsqxew", !0)
        },
        i(s) {
            u || (L(t, s), u = !0)
        },
        o(s) {
            M(t, s), u = !1
        },
        d(s) {
            s && v(e), t && t.d(s)
        }
    }
}

function k(i, e, l) {
    const u = ["variant", "rounded", "inline", "size", "style"];
    let f = h(e, u),
        {
            $$slots: t = {},
            $$scope: d
        } = e,
        {
            variant: r = "default"
        } = e,
        {
            rounded: s = !1
        } = e,
        {
            inline: a = !0
        } = e,
        {
            size: m = "inherit"
        } = e,
        {
            style: g = void 0
        } = e;
    return i.$$set = n => {
        l(6, e = _(_({}, e), z(n))), l(5, f = h(e, u)), "variant" in n && l(0, r = n.variant), "rounded" in n && l(1, s = n.rounded), "inline" in n && l(2, a = n.inline), "size" in n && l(3, m = n.size), "style" in n && l(4, g = n.style), "$$scope" in n && l(7, d = n.$$scope)
    }, e = z(e), [r, s, a, m, g, f, e, d, t]
}
class J extends I {
    constructor(e) {
        super(), K(this, e, k, Q, y, {
            variant: 0,
            rounded: 1,
            inline: 2,
            size: 3,
            style: 4
        })
    }
}
export {
    J as B
};