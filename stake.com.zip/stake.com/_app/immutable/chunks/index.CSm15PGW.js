import {
    s as Q,
    m as h,
    j as $,
    i as g,
    c as Y,
    e as M,
    O as F,
    d as D,
    f as G,
    P as K,
    F as J,
    V as U,
    k as L,
    t as Z,
    h as y,
    l as x
} from "./scheduler.DXu26z7T.js";
import {
    S as ee,
    i as le,
    t as m,
    g as A,
    b as p,
    e as I,
    c as b,
    a as k,
    m as v,
    d as w
} from "./index.Dz_MmNB3.js";
import {
    e as V,
    u as j,
    o as q
} from "./each.DvgCmocI.js";
import {
    h as re,
    W as te,
    f as oe,
    Y as ie,
    i as se
} from "./index.B4-7gKq3.js";
import {
    K as ne
} from "./KuratorCollection.generated.C8c5aVgv.js";
import {
    G as H
} from "./index.D6LqCNuL.js";
import {
    C as ae
} from "./index.D-7TT9-T.js";
import {
    R as fe,
    T as ue,
    A as ce,
    S as _e
} from "./Slide.B1qMR9s0.js";
import {
    g as me
} from "./helpers.DrdznBvg.js";
import {
    S as pe
} from "./constants.CW0Xv01T.js";
const N = {
    providers: re._("Providers")
};

function R(u, e, o) {
    const r = u.slice();
    return r[12] = e[o], r
}

function X(u, e, o) {
    const r = u.slice();
    return r[12] = e[o], r[14] = o, r
}

function z(u) {
    let e, o, r, t;
    const l = [de, ge],
        a = [];

    function n(i, c) {
        return i[1] ? 0 : 1
    }
    return e = n(u), o = a[e] = l[e](u), {
        c() {
            o.c(), r = h()
        },
        l(i) {
            o.l(i), r = h()
        },
        m(i, c) {
            a[e].m(i, c), $(i, r, c), t = !0
        },
        p(i, c) {
            let f = e;
            e = n(i), e === f ? a[e].p(i, c) : (A(), p(a[f], 1, 1, () => {
                a[f] = null
            }), I(), o = a[e], o ? o.p(i, c) : (o = a[e] = l[e](i), o.c()), m(o, 1), o.m(r.parentNode, r))
        },
        i(i) {
            t || (m(o), t = !0)
        },
        o(i) {
            p(o), t = !1
        },
        d(i) {
            i && g(r), a[e].d(i)
        }
    }
}

function ge(u) {
    let e, o, r, t, l = [],
        a = new Map,
        n;
    o = new ae({
        props: {
            icon: "group-providers",
            to: "/casino/collections/provider",
            $$slots: {
                default: [he]
            },
            $$scope: {
                ctx: u
            }
        }
    });
    let i = V(u[2]);
    const c = f => f[12].id;
    for (let f = 0; f < i.length; f += 1) {
        let s = R(u, i, f),
            _ = c(s);
        a.set(_, l[f] = B(_, s))
    }
    return {
        c() {
            e = M("div"), b(o.$$.fragment), r = F(), t = M("div");
            for (let f = 0; f < l.length; f += 1) l[f].c();
            this.h()
        },
        l(f) {
            e = D(f, "DIV", {});
            var s = G(e);
            k(o.$$.fragment, s), r = K(s), t = D(s, "DIV", {
                class: !0
            });
            var _ = G(t);
            for (let d = 0; d < l.length; d += 1) l[d].l(_);
            _.forEach(g), s.forEach(g), this.h()
        },
        h() {
            J(t, "class", "wrap scrollX svelte-1nkmpx3"), U(t, "wrap", u[1]), U(t, "scrollX", u[1])
        },
        m(f, s) {
            $(f, e, s), v(o, e, null), L(e, r), L(e, t);
            for (let _ = 0; _ < l.length; _ += 1) l[_] && l[_].m(t, null);
            n = !0
        },
        p(f, s) {
            const _ = {};
            s & 131200 && (_.$$scope = {
                dirty: s,
                ctx: f
            }), o.$set(_), s & 4 && (i = V(f[2]), A(), l = j(l, s, c, 1, f, i, a, t, q, B, null, R), I()), (!n || s & 2) && U(t, "wrap", f[1]), (!n || s & 2) && U(t, "scrollX", f[1])
        },
        i(f) {
            if (!n) {
                m(o.$$.fragment, f);
                for (let s = 0; s < i.length; s += 1) m(l[s]);
                n = !0
            }
        },
        o(f) {
            p(o.$$.fragment, f);
            for (let s = 0; s < l.length; s += 1) p(l[s]);
            n = !1
        },
        d(f) {
            f && g(e), w(o);
            for (let s = 0; s < l.length; s += 1) l[s].d()
        }
    }
}

function de(u) {
    var r;
    let e, o;
    return e = new fe({
        props: {
            "data-content": pe,
            slideCount: (r = u[2]) == null ? void 0 : r.length,
            mobileView: u[3],
            gap: u[6],
            slidesToScroll: u[4],
            slidesToShow: u[5],
            width: u[0],
            $$slots: {
                header: [ke, ({
                    disableNext: t,
                    disablePrevious: l,
                    next: a,
                    previous: n
                }) => ({
                    8: t,
                    9: l,
                    10: a,
                    11: n
                }), ({
                    disableNext: t,
                    disablePrevious: l,
                    next: a,
                    previous: n
                }) => (t ? 256 : 0) | (l ? 512 : 0) | (a ? 1024 : 0) | (n ? 2048 : 0)],
                default: [be]
            },
            $$scope: {
                ctx: u
            }
        }
    }), {
        c() {
            b(e.$$.fragment)
        },
        l(t) {
            k(e.$$.fragment, t)
        },
        m(t, l) {
            v(e, t, l), o = !0
        },
        p(t, l) {
            var n;
            const a = {};
            l & 4 && (a.slideCount = (n = t[2]) == null ? void 0 : n.length), l & 8 && (a.mobileView = t[3]), l & 64 && (a.gap = t[6]), l & 16 && (a.slidesToScroll = t[4]), l & 32 && (a.slidesToShow = t[5]), l & 1 && (a.width = t[0]), l & 135108 && (a.$$scope = {
                dirty: l,
                ctx: t
            }), e.$set(a)
        },
        i(t) {
            o || (m(e.$$.fragment, t), o = !0)
        },
        o(t) {
            p(e.$$.fragment, t), o = !1
        },
        d(t) {
            w(e, t)
        }
    }
}

function he(u) {
    let e, o = u[7]._(N.providers) + "",
        r;
    return {
        c() {
            e = M("span"), r = Z(o)
        },
        l(t) {
            e = D(t, "SPAN", {});
            var l = G(e);
            r = y(l, o), l.forEach(g)
        },
        m(t, l) {
            $(t, e, l), L(e, r)
        },
        p(t, l) {
            l & 128 && o !== (o = t[7]._(N.providers) + "") && x(r, o)
        },
        d(t) {
            t && g(e)
        }
    }
}

function B(u, e) {
    var l, a, n, i, c, f;
    let o, r, t;
    return r = new H({
        props: {
            size: "5/2",
            name: (a = (l = e[12]) == null ? void 0 : l.group) == null ? void 0 : a.name,
            slug: (i = (n = e[12]) == null ? void 0 : n.group) == null ? void 0 : i.slug,
            thumbnailUrl: (f = (c = e[12]) == null ? void 0 : c.group) == null ? void 0 : f.thumbnailUrl,
            loading: !1
        }
    }), {
        key: u,
        first: null,
        c() {
            o = h(), b(r.$$.fragment), this.h()
        },
        l(s) {
            o = h(), k(r.$$.fragment, s), this.h()
        },
        h() {
            this.first = o
        },
        m(s, _) {
            $(s, o, _), v(r, s, _), t = !0
        },
        p(s, _) {
            var S, C, P, T, E, O;
            e = s;
            const d = {};
            _ & 4 && (d.name = (C = (S = e[12]) == null ? void 0 : S.group) == null ? void 0 : C.name), _ & 4 && (d.slug = (T = (P = e[12]) == null ? void 0 : P.group) == null ? void 0 : T.slug), _ & 4 && (d.thumbnailUrl = (O = (E = e[12]) == null ? void 0 : E.group) == null ? void 0 : O.thumbnailUrl), r.$set(d)
        },
        i(s) {
            t || (m(r.$$.fragment, s), t = !0)
        },
        o(s) {
            p(r.$$.fragment, s), t = !1
        },
        d(s) {
            s && g(o), w(r, s)
        }
    }
}

function $e(u) {
    var t, l, a, n, i, c;
    let e, o, r;
    return e = new H({
        props: {
            size: "5/2",
            name: (l = (t = u[12]) == null ? void 0 : t.group) == null ? void 0 : l.translation,
            slug: (n = (a = u[12]) == null ? void 0 : a.group) == null ? void 0 : n.slug,
            thumbnailUrl: (c = (i = u[12]) == null ? void 0 : i.group) == null ? void 0 : c.thumbnailUrl,
            isMobile: u[6] === 5
        }
    }), {
        c() {
            b(e.$$.fragment), o = F()
        },
        l(f) {
            k(e.$$.fragment, f), o = K(f)
        },
        m(f, s) {
            v(e, f, s), $(f, o, s), r = !0
        },
        p(f, s) {
            var d, S, C, P, T, E;
            const _ = {};
            s & 4 && (_.name = (S = (d = f[12]) == null ? void 0 : d.group) == null ? void 0 : S.translation), s & 4 && (_.slug = (P = (C = f[12]) == null ? void 0 : C.group) == null ? void 0 : P.slug), s & 4 && (_.thumbnailUrl = (E = (T = f[12]) == null ? void 0 : T.group) == null ? void 0 : E.thumbnailUrl), s & 64 && (_.isMobile = f[6] === 5), e.$set(_)
        },
        i(f) {
            r || (m(e.$$.fragment, f), r = !0)
        },
        o(f) {
            p(e.$$.fragment, f), r = !1
        },
        d(f) {
            f && g(o), w(e, f)
        }
    }
}

function W(u, e) {
    let o, r, t;
    return r = new _e({
        props: {
            index: e[14],
            gap: e[6],
            $$slots: {
                default: [$e]
            },
            $$scope: {
                ctx: e
            }
        }
    }), {
        key: u,
        first: null,
        c() {
            o = h(), b(r.$$.fragment), this.h()
        },
        l(l) {
            o = h(), k(r.$$.fragment, l), this.h()
        },
        h() {
            this.first = o
        },
        m(l, a) {
            $(l, o, a), v(r, l, a), t = !0
        },
        p(l, a) {
            e = l;
            const n = {};
            a & 4 && (n.index = e[14]), a & 64 && (n.gap = e[6]), a & 131140 && (n.$$scope = {
                dirty: a,
                ctx: e
            }), r.$set(n)
        },
        i(l) {
            t || (m(r.$$.fragment, l), t = !0)
        },
        o(l) {
            p(r.$$.fragment, l), t = !1
        },
        d(l) {
            l && g(o), w(r, l)
        }
    }
}

function be(u) {
    let e = [],
        o = new Map,
        r, t, l = V(u[2]);
    const a = n => n[12].id;
    for (let n = 0; n < l.length; n += 1) {
        let i = X(u, l, n),
            c = a(i);
        o.set(c, e[n] = W(c, i))
    }
    return {
        c() {
            for (let n = 0; n < e.length; n += 1) e[n].c();
            r = h()
        },
        l(n) {
            for (let i = 0; i < e.length; i += 1) e[i].l(n);
            r = h()
        },
        m(n, i) {
            for (let c = 0; c < e.length; c += 1) e[c] && e[c].m(n, i);
            $(n, r, i), t = !0
        },
        p(n, i) {
            i & 68 && (l = V(n[2]), A(), e = j(e, i, a, 1, n, l, o, r.parentNode, q, W, r, X), I())
        },
        i(n) {
            if (!t) {
                for (let i = 0; i < l.length; i += 1) m(e[i]);
                t = !0
            }
        },
        o(n) {
            for (let i = 0; i < e.length; i += 1) p(e[i]);
            t = !1
        },
        d(n) {
            n && g(r);
            for (let i = 0; i < e.length; i += 1) e[i].d(n)
        }
    }
}

function ke(u) {
    let e, o, r, t;
    return e = new ue({
        props: {
            group: {
                to: "/casino/collection/provider",
                translation: u[7]._(N.providers),
                icon: "group-providers"
            },
            loading: !1
        }
    }), r = new ce({
        props: {
            previous: u[11],
            next: u[10],
            disablePrevious: u[9],
            disableNext: u[8]
        }
    }), {
        c() {
            b(e.$$.fragment), o = F(), b(r.$$.fragment)
        },
        l(l) {
            k(e.$$.fragment, l), o = K(l), k(r.$$.fragment, l)
        },
        m(l, a) {
            v(e, l, a), $(l, o, a), v(r, l, a), t = !0
        },
        p(l, a) {
            const n = {};
            a & 128 && (n.group = {
                to: "/casino/collection/provider",
                translation: l[7]._(N.providers),
                icon: "group-providers"
            }), e.$set(n);
            const i = {};
            a & 2048 && (i.previous = l[11]), a & 1024 && (i.next = l[10]), a & 512 && (i.disablePrevious = l[9]), a & 256 && (i.disableNext = l[8]), r.$set(i)
        },
        i(l) {
            t || (m(e.$$.fragment, l), m(r.$$.fragment, l), t = !0)
        },
        o(l) {
            p(e.$$.fragment, l), p(r.$$.fragment, l), t = !1
        },
        d(l) {
            l && g(o), w(e, l), w(r, l)
        }
    }
}

function ve(u) {
    let e, o, r = u[2] && z(u);
    return {
        c() {
            r && r.c(), e = h()
        },
        l(t) {
            r && r.l(t), e = h()
        },
        m(t, l) {
            r && r.m(t, l), $(t, e, l), o = !0
        },
        p(t, [l]) {
            t[2] ? r ? (r.p(t, l), l & 4 && m(r, 1)) : (r = z(t), r.c(), m(r, 1), r.m(e.parentNode, e)) : r && (A(), p(r, 1, 1, () => {
                r = null
            }), I())
        },
        i(t) {
            o || (m(r), o = !0)
        },
        o(t) {
            p(r), o = !1
        },
        d(t) {
            t && g(e), r && r.d(t)
        }
    }
}
async function Me(u) {
    var o, r;
    const e = ((r = (o = await u.parent()) == null ? void 0 : o.session) == null ? void 0 : r.locale) || te.en;
    return oe({
        doc: ne,
        variables: {
            type: ie.provider,
            isActivePlayersFeatureFlagOn: !1,
            language: e
        },
        load: u,
        cache: {
            name: "kuratorCollection-providers"
        }
    })
}

function we(u, e, o) {
    let r, t, l, a;
    Y(u, se, s => o(7, a = s));
    let {
        width: n
    } = e, {
        slidey: i
    } = e, {
        kuratorCollection: c = []
    } = e, {
        mobileView: f = !1
    } = e;
    return u.$$set = s => {
        "width" in s && o(0, n = s.width), "slidey" in s && o(1, i = s.slidey), "kuratorCollection" in s && o(2, c = s.kuratorCollection), "mobileView" in s && o(3, f = s.mobileView)
    }, u.$$.update = () => {
        u.$$.dirty & 1 && o(6, {
            gap: r,
            slidesToShow: t,
            slidesToScroll: l
        } = me(n), r, (o(5, t), o(0, n)), (o(4, l), o(0, n)))
    }, [n, i, c, f, l, t, r, a]
}
class De extends ee {
    constructor(e) {
        super(), le(this, e, we, ve, Q, {
            width: 0,
            slidey: 1,
            kuratorCollection: 2,
            mobileView: 3
        })
    }
}
export {
    De as P, Me as f
};