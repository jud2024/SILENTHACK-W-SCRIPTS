import {
    s as o,
    C as v,
    H as f,
    D as m,
    f as u,
    E as _,
    i as c,
    F as r,
    j as g,
    n as h
} from "./scheduler.DXu26z7T.js";
import {
    S as y,
    i as H
} from "./index.Dz_MmNB3.js";

function Z(n) {
    let t, a, l = ` <title>${n[1]||""}</title> <path d="M32 0C14.326 0 0 14.326 0 32s14.326 32 32 32 32-14.326 32-32S49.674 0 32 0Zm5.24 51.68H26.76v-21h10.48v21ZM32 24.56a6.12 6.12 0 1 1 6.12-6.12v.04a6.08 6.08 0 0 1-6.08 6.08h-.042H32Z"></path>`,
        i;
    return {
        c() {
            t = v("svg"), a = new f(!0), this.h()
        },
        l(e) {
            t = m(e, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var s = u(t);
            a = _(s, !0), s.forEach(c), this.h()
        },
        h() {
            a.a = null, r(t, "fill", "currentColor"), r(t, "viewBox", "0 0 64 64"), r(t, "class", i = "svg-icon " + n[2]), r(t, "style", n[0])
        },
        m(e, s) {
            g(e, t, s), a.m(l, t)
        },
        p(e, [s]) {
            s & 2 && l !== (l = ` <title>${e[1]||""}</title> <path d="M32 0C14.326 0 0 14.326 0 32s14.326 32 32 32 32-14.326 32-32S49.674 0 32 0Zm5.24 51.68H26.76v-21h10.48v21ZM32 24.56a6.12 6.12 0 1 1 6.12-6.12v.04a6.08 6.08 0 0 1-6.08 6.08h-.042H32Z"></path>`) && a.p(l), s & 4 && i !== (i = "svg-icon " + e[2]) && r(t, "class", i), s & 1 && r(t, "style", e[0])
        },
        i: h,
        o: h,
        d(e) {
            e && c(t)
        }
    }
}

function d(n, t, a) {
    let {
        style: l = ""
    } = t, {
        alt: i = ""
    } = t, {
        class: e = ""
    } = t;
    return n.$$set = s => {
        "style" in s && a(0, l = s.style), "alt" in s && a(1, i = s.alt), "class" in s && a(2, e = s.class)
    }, [l, i, e]
}
class M extends y {
    constructor(t) {
        super(), H(this, t, d, Z, o, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
export {
    M as I
};