import {
    s as Te,
    C as Ee,
    H as Pe,
    D as Ie,
    f as E,
    E as Ge,
    i as p,
    F as $,
    j as k,
    n as U,
    a9 as st,
    m as he,
    e as I,
    d as G,
    I as P,
    U as Be,
    o as lt,
    O as R,
    P as B,
    V as F,
    k as L,
    c as rt,
    t as X,
    h as Q,
    l as x,
    a1 as ot
} from "./scheduler.DXu26z7T.js";
import {
    S as Ne,
    i as Fe,
    t as g,
    g as K,
    b as h,
    e as z,
    c as j,
    a as T,
    m as D,
    d as C
} from "./index.Dz_MmNB3.js";
import {
    g as mt
} from "./globals.D0QH3NT1.js";
import {
    e as Ve
} from "./each.DvgCmocI.js";
import "./index.ByMdEFI5.js";
import {
    a as Re
} from "./index.Cn-rinD1.js";
import {
    g as pe
} from "./index.CUgLGuIE.js";
import {
    g as ut
} from "./helpers.CobRd3cj.js";
import {
    F as ct
} from "./utils.PGvbthip.js";
import {
    _ as je,
    bZ as _e,
    h as _
} from "./index.B4-7gKq3.js";
import {
    T as Z
} from "./index.D7nbRHfU.js";
import {
    P as ge
} from "./index.B1KDSkU5.js";
import {
    F as nt
} from "./index.Drh4nwD9.js";
import {
    w as dt
} from "./index.C2-CG2CN.js";

function ft(i) {
    let e, n, t = ` <title>${i[1]||""}</title> <path d="M41.52 53.333A43.04 43.04 0 0 0 10.667 22.48V0H0v64h64V53.333H41.52Zm-30.853 0V33.6A32.454 32.454 0 0 1 30.4 53.333H10.667Z"></path>`,
        a;
    return {
        c() {
            e = Ee("svg"), n = new Pe(!0), this.h()
        },
        l(s) {
            e = Ie(s, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var l = E(e);
            n = Ge(l, !0), l.forEach(p), this.h()
        },
        h() {
            n.a = null, $(e, "fill", "currentColor"), $(e, "viewBox", "0 0 64 64"), $(e, "class", a = "svg-icon " + i[2]), $(e, "style", i[0])
        },
        m(s, l) {
            k(s, e, l), n.m(t, e)
        },
        p(s, [l]) {
            l & 2 && t !== (t = ` <title>${s[1]||""}</title> <path d="M41.52 53.333A43.04 43.04 0 0 0 10.667 22.48V0H0v64h64V53.333H41.52Zm-30.853 0V33.6A32.454 32.454 0 0 1 30.4 53.333H10.667Z"></path>`) && n.p(t), l & 4 && a !== (a = "svg-icon " + s[2]) && $(e, "class", a), l & 1 && $(e, "style", s[0])
        },
        i: U,
        o: U,
        d(s) {
            s && p(e)
        }
    }
}

function pt(i, e, n) {
    let {
        style: t = ""
    } = e, {
        alt: a = ""
    } = e, {
        class: s = ""
    } = e;
    return i.$$set = l => {
        "style" in l && n(0, t = l.style), "alt" in l && n(1, a = l.alt), "class" in l && n(2, s = l.class)
    }, [t, a, s]
}
class gt extends Ne {
    constructor(e) {
        super(), Fe(this, e, pt, ft, Te, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}

function _t(i) {
    let e, n, t = ` <title>${i[1]||""}</title> <path d="M23.64 0h48.72a6.391 6.391 0 0 1 6.39 6.39v83.22A6.391 6.391 0 0 1 72.36 96H23.64a6.391 6.391 0 0 1-6.39-6.39V6.39A6.391 6.391 0 0 1 23.64 0Z" fill="#ED4163"></path>`,
        a;
    return {
        c() {
            e = Ee("svg"), n = new Pe(!0), this.h()
        },
        l(s) {
            e = Ie(s, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var l = E(e);
            n = Ge(l, !0), l.forEach(p), this.h()
        },
        h() {
            n.a = null, $(e, "fill", "none"), $(e, "viewBox", "0 0 96 96"), $(e, "class", a = "svg-icon " + i[2]), $(e, "style", i[0])
        },
        m(s, l) {
            k(s, e, l), n.m(t, e)
        },
        p(s, [l]) {
            l & 2 && t !== (t = ` <title>${s[1]||""}</title> <path d="M23.64 0h48.72a6.391 6.391 0 0 1 6.39 6.39v83.22A6.391 6.391 0 0 1 72.36 96H23.64a6.391 6.391 0 0 1-6.39-6.39V6.39A6.391 6.391 0 0 1 23.64 0Z" fill="#ED4163"></path>`) && n.p(t), l & 4 && a !== (a = "svg-icon " + s[2]) && $(e, "class", a), l & 1 && $(e, "style", s[0])
        },
        i: U,
        o: U,
        d(s) {
            s && p(e)
        }
    }
}

function ht(i, e, n) {
    let {
        style: t = ""
    } = e, {
        alt: a = ""
    } = e, {
        class: s = ""
    } = e;
    return i.$$set = l => {
        "style" in l && n(0, t = l.style), "alt" in l && n(1, a = l.alt), "class" in l && n(2, s = l.class)
    }, [t, a, s]
}
class kt extends Ne {
    constructor(e) {
        super(), Fe(this, e, ht, _t, Te, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}

function vt(i) {
    let e, n, t = ` <title>${i[1]||""}</title> <path d="M23.64 0h48.72a6.391 6.391 0 0 1 6.39 6.39v83.22A6.391 6.391 0 0 1 72.36 96H23.64a6.391 6.391 0 0 1-6.39-6.39V6.39A6.391 6.391 0 0 1 23.64 0Z" fill="#FF9D00"></path>`,
        a;
    return {
        c() {
            e = Ee("svg"), n = new Pe(!0), this.h()
        },
        l(s) {
            e = Ie(s, "svg", {
                fill: !0,
                viewBox: !0,
                class: !0,
                style: !0
            });
            var l = E(e);
            n = Ge(l, !0), l.forEach(p), this.h()
        },
        h() {
            n.a = null, $(e, "fill", "none"), $(e, "viewBox", "0 0 96 96"), $(e, "class", a = "svg-icon " + i[2]), $(e, "style", i[0])
        },
        m(s, l) {
            k(s, e, l), n.m(t, e)
        },
        p(s, [l]) {
            l & 2 && t !== (t = ` <title>${s[1]||""}</title> <path d="M23.64 0h48.72a6.391 6.391 0 0 1 6.39 6.39v83.22A6.391 6.391 0 0 1 72.36 96H23.64a6.391 6.391 0 0 1-6.39-6.39V6.39A6.391 6.391 0 0 1 23.64 0Z" fill="#FF9D00"></path>`) && n.p(t), l & 4 && a !== (a = "svg-icon " + s[2]) && $(e, "class", a), l & 1 && $(e, "style", s[0])
        },
        i: U,
        o: U,
        d(s) {
            s && p(e)
        }
    }
}

function bt(i, e, n) {
    let {
        style: t = ""
    } = e, {
        alt: a = ""
    } = e, {
        class: s = ""
    } = e;
    return i.$$set = l => {
        "style" in l && n(0, t = l.style), "alt" in l && n(1, a = l.alt), "class" in l && n(2, s = l.class)
    }, [t, a, s]
}
class $t extends Ne {
    constructor(e) {
        super(), Fe(this, e, bt, vt, Te, {
            style: 0,
            alt: 1,
            class: 2
        })
    }
}
const jn = {
        kind: "Document",
        definitions: [{
            kind: "OperationDefinition",
            operation: "subscription",
            name: {
                kind: "Name",
                value: "fixtureEventStatus"
            },
            variableDefinitions: [{
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "fixtureId"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "String"
                        }
                    }
                }
            }, {
                kind: "VariableDefinition",
                variable: {
                    kind: "Variable",
                    name: {
                        kind: "Name",
                        value: "provider"
                    }
                },
                type: {
                    kind: "NonNullType",
                    type: {
                        kind: "NamedType",
                        name: {
                            kind: "Name",
                            value: "SportsbookOddsProviderEnum"
                        }
                    }
                }
            }],
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "sportFixture"
                    },
                    arguments: [{
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "fixtureId"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "fixtureId"
                            }
                        }
                    }, {
                        kind: "Argument",
                        name: {
                            kind: "Name",
                            value: "provider"
                        },
                        value: {
                            kind: "Variable",
                            name: {
                                kind: "Name",
                                value: "provider"
                            }
                        }
                    }],
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "id"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "status"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "marketCount"
                            },
                            arguments: [{
                                kind: "Argument",
                                name: {
                                    kind: "Name",
                                    value: "status"
                                },
                                value: {
                                    kind: "ListValue",
                                    values: [{
                                        kind: "EnumValue",
                                        value: "active"
                                    }, {
                                        kind: "EnumValue",
                                        value: "suspended"
                                    }]
                                }
                            }]
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "eventStatus"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "SportFixtureEventStatus"
                                    }
                                }, {
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "EsportFixtureEventStatus"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "data"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "SportFixtureDataMatch"
                                    }
                                }, {
                                    kind: "FragmentSpread",
                                    name: {
                                        kind: "Name",
                                        value: "SportFixtureDataOutright"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "__typename"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportFixtureCompetitor"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportFixtureCompetitor"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "extId"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "countryCode"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "abbreviation"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "iconPath"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportFixtureEventStatus"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportFixtureEventStatusData"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "homeScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "awayScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "matchStatus"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "clock"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "matchTime"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "remainingTime"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "periodScores"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "matchStatus"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "currentTeamServing"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "homeGameScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "awayGameScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "statistic"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "yellowCards"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "away"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "home"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "redCards"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "away"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "home"
                                    }
                                }]
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "corners"
                            },
                            selectionSet: {
                                kind: "SelectionSet",
                                selections: [{
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "home"
                                    }
                                }, {
                                    kind: "Field",
                                    name: {
                                        kind: "Name",
                                        value: "away"
                                    }
                                }]
                            }
                        }]
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "EsportFixtureEventStatus"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "EsportFixtureEventStatus"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "matchStatus"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "homeScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "awayScore"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "scoreboard"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeGold"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayGold"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "gameTime"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeDestroyedTowers"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayDestroyedTurrets"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currentRound"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currentCtTeam"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "currentDefTeam"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "time"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "remainingGameTime"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "periodScores"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "type"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "number"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeGoals"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeKills"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeScore"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "awayWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "homeWonRounds"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "matchStatus"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportFixtureDataMatch"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportFixtureDataMatch"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "startTime"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "competitors"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "FragmentSpread",
                            name: {
                                kind: "Name",
                                value: "SportFixtureCompetitor"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "teams"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "qualifier"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "tvChannels"
                    },
                    selectionSet: {
                        kind: "SelectionSet",
                        selections: [{
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "language"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "name"
                            }
                        }, {
                            kind: "Field",
                            name: {
                                kind: "Name",
                                value: "streamUrl"
                            }
                        }]
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }]
            }
        }, {
            kind: "FragmentDefinition",
            name: {
                kind: "Name",
                value: "SportFixtureDataOutright"
            },
            typeCondition: {
                kind: "NamedType",
                name: {
                    kind: "Name",
                    value: "SportFixtureDataOutright"
                }
            },
            selectionSet: {
                kind: "SelectionSet",
                selections: [{
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "name"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "startTime"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "endTime"
                    }
                }, {
                    kind: "Field",
                    name: {
                        kind: "Name",
                        value: "__typename"
                    }
                }]
            }
        }]
    },
    De = (i, e = "big") => i ? `https://img-cdn001.akamaized.net/ls/crest/${e}/${je.last(i.split(":"))}.png` : "",
    wt = ["tennis"];

function Ae(i) {
    let e, n, t, a;
    return {
        c() {
            e = I("img"), this.h()
        },
        l(s) {
            e = G(s, "IMG", {
                style: !0,
                width: !0,
                height: !0,
                alt: !0,
                src: !0
            }), this.h()
        },
        h() {
            P(e, "width", i[2] + "px"), P(e, "height", i[1] + "px"), $(e, "width", n = i[2] + "px"), $(e, "height", t = i[1] + "px"), $(e, "alt", i[0]), Be(e.src, a = i[3]) || $(e, "src", a)
        },
        m(s, l) {
            k(s, e, l)
        },
        p(s, l) {
            l & 4 && P(e, "width", s[2] + "px"), l & 2 && P(e, "height", s[1] + "px"), l & 4 && n !== (n = s[2] + "px") && $(e, "width", n), l & 2 && t !== (t = s[1] + "px") && $(e, "height", t), l & 1 && $(e, "alt", s[0]), l & 8 && !Be(e.src, a = s[3]) && $(e, "src", a)
        },
        d(s) {
            s && p(e)
        }
    }
}

function yt(i) {
    let e, n = i[4] && Ae(i);
    return {
        c() {
            n && n.c(), e = he()
        },
        l(t) {
            n && n.l(t), e = he()
        },
        m(t, a) {
            n && n.m(t, a), k(t, e, a)
        },
        p(t, [a]) {
            t[4] ? n ? n.p(t, a) : (n = Ae(t), n.c(), n.m(e.parentNode, e)) : n && (n.d(1), n = null)
        },
        i: U,
        o: U,
        d(t) {
            t && p(e), n && n.d(t)
        }
    }
}

function St(i, e, n) {
    let t, a, s, l, u;
    const o = {
        small: 20,
        medium: 50,
        big: 100
    };
    let {
        competitor: f = {
            extId: "",
            iconPath: ""
        }
    } = e, {
        sport: r
    } = e, {
        size: c = "big"
    } = e;
    return i.$$set = m => {
        "competitor" in m && n(5, f = m.competitor), "sport" in m && n(0, r = m.sport), "size" in m && n(6, c = m.size)
    }, i.$$.update = () => {
        var m;
        i.$$.dirty & 64 && n(7, t = o[c]), i.$$.dirty & 1 && n(4, a = wt.includes(r) === !1), i.$$.dirty & 96 && n(3, s = (f == null ? void 0 : f.iconPath) ? ? De(je.last((m = f.extId) == null ? void 0 : m.split(":")), c)), i.$$.dirty & 128 && n(2, l = t * .4), i.$$.dirty & 128 && n(1, u = t * .4)
    }, [r, u, l, s, a, f, c, t]
}
class it extends Ne {
    constructor(e) {
        super(), Fe(this, e, St, yt, st, {
            competitor: 5,
            sport: 0,
            size: 6
        })
    }
}
const Ce = "/_app/immutable/assets/default-sports-background.Ci6F42lg.jpg",
    re = "/_app/immutable/assets/default-esports-background.DcoWeT1o.jpg",
    Oe = "/_app/immutable/assets/alpine-skiing.BcIZ2Mbj.jpg",
    Nt = "/_app/immutable/assets/basketball.Csdpvd7d.jpg",
    Ft = "/_app/immutable/assets/chess.DpH6HUII.jpg",
    jt = "/_app/immutable/assets/handball.B-UgBkj2.jpg",
    Tt = "/_app/immutable/assets/motorsport.CJ1yfaS7.jpg",
    Dt = "/_app/immutable/assets/snowboard.CTXFeZS3.jpg",
    Ct = "/_app/immutable/assets/table-tennis.Ci-YJkMv.jpg",
    Et = "/_app/immutable/assets/american-football.DwtsYkaS.jpg",
    Pt = "/_app/immutable/assets/beach-soccer.jqKY5Url.jpg",
    He = "/_app/immutable/assets/soccer.yGbWRTyy.jpg",
    It = "/_app/immutable/assets/tennis.Dx-LXZ4h.jpg",
    Gt = "/_app/immutable/assets/athletics.Qs78fUcw.jpg",
    Rt = "/_app/immutable/assets/beach-volley.Bb0hbHVL.jpg",
    Me = "/_app/immutable/assets/cricket.CqDi4YAx.jpg",
    Bt = "/_app/immutable/assets/field-hockey.Cu_GHbLk.jpg",
    Vt = "/_app/immutable/assets/rugby.By84yPQV.jpg",
    At = "/_app/immutable/assets/volleyball.BouZPByU.jpg",
    Ot = "/_app/immutable/assets/australian-rules.CuJ3sYwz.jpg",
    Ht = "/_app/immutable/assets/biathlon.C4dxR4Y1.jpg",
    Mt = "/_app/immutable/assets/curling.DaR2MbGd.jpg",
    Wt = "/_app/immutable/assets/ice-hockey.mrkck1xz.jpg",
    We = "/_app/immutable/assets/figure-skating.DsXCArbC.jpg",
    Yt = "/_app/immutable/assets/sailing.Dwvx7m_x.jpg",
    Zt = "/_app/immutable/assets/badminton.DFS--wdA.jpg",
    qt = "/_app/immutable/assets/bobsleigh.DtPiNWrb.jpg",
    Lt = "/_app/immutable/assets/cycling.Cq0v74ZD.jpg",
    Kt = "/_app/immutable/assets/floorball.B0bZSRaY.jpg",
    zt = "/_app/immutable/assets/skeleton.BdfyYvPB.jpg",
    Ut = "/_app/immutable/assets/speed-skating.CtyhXV-w.jpg",
    Xt = "/_app/immutable/assets/bowls.DPOxUo4b.jpg",
    Qt = "/_app/immutable/assets/darts.BpXONm3d.jpg",
    Jt = "/_app/immutable/assets/freestyle-skiing.D1jE6RWY.jpg",
    xt = "/_app/immutable/assets/luge.CBvBnQjw.jpg",
    ea = "/_app/immutable/assets/snooker.BLq3KZ8k.jpg",
    ta = "/_app/immutable/assets/squash.Cy8zBDHg.jpg",
    aa = "/_app/immutable/assets/baseball.pyX637ha.jpg",
    na = "/_app/immutable/assets/greyhound.CiIZKehD.jpg",
    ia = "/_app/immutable/assets/mma.CvKqGv4S.jpg",
    Ye = "/_app/immutable/assets/swimming.CbBwZ5Jx.jpg",
    sa = "/_app/immutable/assets/boxing.VXrg64CQ.jpg",
    la = "/_app/immutable/assets/golf.CFgcpvCL.jpg",
    ra = "/_app/immutable/assets/league-of-legends.DirWQCUn.jpg",
    oa = "/_app/immutable/assets/starcraft.CZTouuh9.jpg",
    ma = "/_app/immutable/assets/dota-2.B-3-MPmO.jpg",
    ua = "/_app/immutable/assets/counter-strike.WthYwU-V.jpg",
    ca = "/_app/immutable/assets/call-of-duty.DLyvmCnH.jpg",
    da = "/_app/immutable/assets/pubg.VVgm-iMz.jpg",
    fa = "/_app/immutable/assets/age-of-empires.DLXKqCgT.jpg",
    pa = "/_app/immutable/assets/arena-of-valor.Cxcf-fhH.jpg",
    ga = "/_app/immutable/assets/counter-strike-global-offensive.DswRaXGo.jpg",
    _a = "/_app/immutable/assets/counter-strike-global-offensive-wingman.CgMihI_T.jpg",
    ha = "/_app/immutable/assets/halo.BNIPGS0h.jpg",
    ka = "/_app/immutable/assets/kings-of-glory.B3g7krpx.jpg",
    va = "/_app/immutable/assets/mobile-legends.ByI19Dtb.jpg",
    ba = "/_app/immutable/assets/overwatch.DEhsJeAO.jpg",
    $a = "/_app/immutable/assets/rainbow-six-siege.D67TWp08.jpg",
    wa = "/_app/immutable/assets/rocket-league.PRDUBEVX.jpg",
    ya = "/_app/immutable/assets/rush-football.DHgAglnu.jpg",
    Sa = "/_app/immutable/assets/starcraft-2.BCLgr50Y.jpg",
    Na = "/_app/immutable/assets/valorant.DjAPy5Z-.jpg",
    Fa = "/_app/immutable/assets/virtual-soccer.Rnkm5Rie.jpg",
    ja = "/_app/immutable/assets/warcraft-3.kwwUfyOw.jpg",
    Ta = "/_app/immutable/assets/wild-rift.CGNXps0C.jpg",
    Ze = {
        "alpine-skiing": Oe,
        basketball: Nt,
        chess: Ft,
        "dota-2": ma,
        handball: jt,
        motorsport: Tt,
        snowboard: Dt,
        "table-tennis": Ct,
        "american-football": Et,
        "beach-soccer": Pt,
        "counter-strike": ua,
        soccer: He,
        tennis: It,
        athletics: Gt,
        "beach-volley": Rt,
        cricket: Me,
        ecricket: Me,
        "field-hockey": Bt,
        "ice-hockey": Wt,
        rugby: Vt,
        volleyball: At,
        "aussie-rules": Ot,
        biathlon: Ht,
        curling: Mt,
        "figure-skating": We,
        sailing: Yt,
        badminton: Zt,
        bobsleigh: qt,
        cycling: Lt,
        floorball: Kt,
        skeleton: zt,
        "speed-skating": Ut,
        bandy: We,
        bowls: Xt,
        darts: Qt,
        "freestyle-skiing": Jt,
        luge: xt,
        snooker: ea,
        squash: ta,
        baseball: aa,
        "call-of-duty": ca,
        greyhound: na,
        mma: ia,
        boxing: sa,
        swimming: Ye,
        waterpolo: Ye,
        pubg: da,
        golf: la,
        "cross-country": Ce,
        futsal: He,
        hearthstone: re,
        "ski-jumping": Oe,
        fifa: re,
        "street-fighter-v": re,
        starcraft: oa,
        "league-of-legends": ra,
        "world-of-warcraft": re,
        "age-of-empires": fa,
        "arena-of-valor": pa,
        "counter-strike-2-duels": re,
        "counter-strike-global-offensive": ga,
        "counter-strike-global-offensive-wingman": _a,
        halo: ha,
        "kings-of-glory": ka,
        "mobile-legends": va,
        overwatch: ba,
        "rainbow-six": $a,
        "rocket-league": wa,
        "rush-football": ya,
        "starcraft-2": Sa,
        valorant: Na,
        "virtual-soccer": Fa,
        "warcraft-3": ja,
        "wild-rift": Ta,
        "forumla-e": re,
        specials: Ce,
        "soccer-mythical": re,
        "electronic-leagues": re,
        nba2k: re,
        nhl21: re
    },
    Da = i => i in Ze ? Ze[i] : Ce,
    Ca = (i, e, n) => {
        const t = "big",
            a = i && i.find(l => l.homeTeam),
            s = i && i.find(l => !l.homeTeam);
        lt(async () => {
            if (a && s) try {
                await Promise.all([qe(De(je.last(a.extId.split(":")) || "", t)), qe(De(je.last(s.extId.split(":")) || "", t))])
            } catch {
                e()
            } finally {
                n.set(!1)
            }
        })
    },
    qe = i => new Promise((e, n) => {
        const t = new Image;
        t.src = i, t.onload = () => {
            try {
                t.naturalWidth === 1 ? n(new Error("No Image")) : e(t)
            } catch {}
        }, t.onerror = a => {
            n(a)
        }
    }),
    Ea = i => {
        if (i) {
            if (i.__typename === "SportFixtureDataMatch") return {
                startTime: i.startTime,
                name: i.competitors.map(e => e.name).join(" - "),
                abbreviation: i.competitors.map(e => e.abbreviation).join(" - ")
            };
            if (i.__typename === "SportFixtureDataOutright") return {
                startTime: i.startTime,
                name: i.name,
                abbreviation: null
            };
            if (i.__typename === "SportCricketScore") return {
                startTime: null,
                name: i.name,
                abbreviation: null
            }
        }
        return {
            startTime: null,
            name: null,
            abbreviation: null
        }
    },
    Pa = i => {
        var a, s, l, u, o, f, r;
        const e = ((a = i.data) == null ? void 0 : a.__typename) === "SportCricketScore" ? i.data.scheduledStart : (s = i == null ? void 0 : i.data) == null ? void 0 : s.startTime,
            n = ((l = i == null ? void 0 : i.data) == null ? void 0 : l.__typename) === "SportFixtureDataMatch" ? (u = i.data) == null ? void 0 : u.tvChannels : [],
            t = n && n.length >= 1 || !1;
        return {
            providerId: i == null ? void 0 : i.extId,
            provider: i == null ? void 0 : i.provider,
            startDateTime: e,
            eventStatus: i.eventStatus,
            name: i == null ? void 0 : i.name,
            status: (i == null ? void 0 : i.status) ? ? e,
            matchStatus: (o = i.eventStatus) == null ? void 0 : o.matchStatus,
            stream: {
                exists: t,
                platform: "any"
            },
            competitors: ((f = i == null ? void 0 : i.data) == null ? void 0 : f.__typename) === "SportFixtureDataOutright" || (r = i == null ? void 0 : i.data) == null ? void 0 : r.competitors.map((c, m) => {
                var d, b, S, A;
                return { ...c,
                    homeTeam: i.provider === _e.betradar ? m === 0 : ((d = i == null ? void 0 : i.data) == null ? void 0 : d.__typename) === "SportFixtureDataMatch" ? ((A = (S = (b = i == null ? void 0 : i.data) == null ? void 0 : b.teams) == null ? void 0 : S.find(ee => ee.name === c.name)) == null ? void 0 : A.qualifier) === "home" : !1
                }
            }).sort((c, m) => Number(m.homeTeam) - Number(c.homeTeam)),
            tvChannels: n
        }
    },
    {
        Boolean: Ia
    } = mt;

function Le(i, e, n) {
    const t = i.slice();
    return t[27] = e[n], t[29] = n, t
}

function Ke(i) {
    let e, n;
    return e = new ct({
        props: {
            sport: i[1],
            clock: i[13]
        }
    }), {
        c() {
            j(e.$$.fragment)
        },
        l(t) {
            T(e.$$.fragment, t)
        },
        m(t, a) {
            D(e, t, a), n = !0
        },
        p(t, a) {
            const s = {};
            a & 2 && (s.sport = t[1]), a & 8192 && (s.clock = t[13]), e.$set(s)
        },
        i(t) {
            n || (g(e.$$.fragment, t), n = !0)
        },
        o(t) {
            h(e.$$.fragment, t), n = !1
        },
        d(t) {
            C(e, t)
        }
    }
}

function Ga(i) {
    let e, n;
    return e = new ge({
        props: {
            width: "5ch"
        }
    }), {
        c() {
            j(e.$$.fragment)
        },
        l(t) {
            T(e.$$.fragment, t)
        },
        m(t, a) {
            D(e, t, a), n = !0
        },
        p: U,
        i(t) {
            n || (g(e.$$.fragment, t), n = !0)
        },
        o(t) {
            h(e.$$.fragment, t), n = !1
        },
        d(t) {
            C(e, t)
        }
    }
}

function Ra(i) {
    let e, n;
    return e = new Z({
        props: {
            $$slots: {
                default: [Va]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            j(e.$$.fragment)
        },
        l(t) {
            T(e.$$.fragment, t)
        },
        m(t, a) {
            D(e, t, a), n = !0
        },
        p(t, a) {
            const s = {};
            a & 1073741825 && (s.$$scope = {
                dirty: a,
                ctx: t
            }), e.$set(s)
        },
        i(t) {
            n || (g(e.$$.fragment, t), n = !0)
        },
        o(t) {
            h(e.$$.fragment, t), n = !1
        },
        d(t) {
            C(e, t)
        }
    }
}

function Ba(i) {
    let e, n, t;
    return n = new Z({
        props: {
            $$slots: {
                default: [Ha]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            e = I("span"), j(n.$$.fragment), this.h()
        },
        l(a) {
            e = G(a, "SPAN", {
                style: !0,
                class: !0
            });
            var s = E(e);
            T(n.$$.fragment, s), s.forEach(p), this.h()
        },
        h() {
            var a, s;
            P(e, "margin-left", (a = i[13]) != null && a.matchTime || (s = i[13]) != null && s.remainingTime ? "var(--space-2)" : 0), $(e, "class", "match-status-label svelte-1jl15xp")
        },
        m(a, s) {
            k(a, e, s), D(n, e, null), t = !0
        },
        p(a, s) {
            var u, o;
            const l = {};
            s & 1073741841 && (l.$$scope = {
                dirty: s,
                ctx: a
            }), n.$set(l), (!t || s & 8192) && P(e, "margin-left", (u = a[13]) != null && u.matchTime || (o = a[13]) != null && o.remainingTime ? "var(--space-2)" : 0)
        },
        i(a) {
            t || (g(n.$$.fragment, a), t = !0)
        },
        o(a) {
            h(n.$$.fragment, a), t = !1
        },
        d(a) {
            a && p(e), C(n)
        }
    }
}

function Va(i) {
    var t;
    let e, n;
    return e = new nt({
        props: {
            value: (t = i[0]) == null ? void 0 : t.data.startTime,
            short: !0
        }
    }), {
        c() {
            j(e.$$.fragment)
        },
        l(a) {
            T(e.$$.fragment, a)
        },
        m(a, s) {
            D(e, a, s), n = !0
        },
        p(a, s) {
            var u;
            const l = {};
            s & 1 && (l.value = (u = a[0]) == null ? void 0 : u.data.startTime), e.$set(l)
        },
        i(a) {
            n || (g(e.$$.fragment, a), n = !0)
        },
        o(a) {
            h(e.$$.fragment, a), n = !1
        },
        d(a) {
            C(e, a)
        }
    }
}

function Aa(i) {
    let e, n;
    return e = new nt({
        props: {
            value: i[4].matchStatus,
            short: !0
        }
    }), {
        c() {
            j(e.$$.fragment)
        },
        l(t) {
            T(e.$$.fragment, t)
        },
        m(t, a) {
            D(e, t, a), n = !0
        },
        p(t, a) {
            const s = {};
            a & 16 && (s.value = t[4].matchStatus), e.$set(s)
        },
        i(t) {
            n || (g(e.$$.fragment, t), n = !0)
        },
        o(t) {
            h(e.$$.fragment, t), n = !1
        },
        d(t) {
            C(e, t)
        }
    }
}

function Oa(i) {
    let e = i[4].matchStatus + "",
        n;
    return {
        c() {
            n = X(e)
        },
        l(t) {
            n = Q(t, e)
        },
        m(t, a) {
            k(t, n, a)
        },
        p(t, a) {
            a & 16 && e !== (e = t[4].matchStatus + "") && x(n, e)
        },
        i: U,
        o: U,
        d(t) {
            t && p(n)
        }
    }
}

function Ha(i) {
    let e, n, t, a;
    const s = [Oa, Aa],
        l = [];

    function u(o, f) {
        var r, c;
        return ((r = o[0]) == null ? void 0 : r.status) === "live" || ((c = o[0]) == null ? void 0 : c.status) === "suspended" ? 0 : o[4].matchStatus ? 1 : -1
    }
    return ~(e = u(i)) && (n = l[e] = s[e](i)), {
        c() {
            n && n.c(), t = he()
        },
        l(o) {
            n && n.l(o), t = he()
        },
        m(o, f) {
            ~e && l[e].m(o, f), k(o, t, f), a = !0
        },
        p(o, f) {
            let r = e;
            e = u(o), e === r ? ~e && l[e].p(o, f) : (n && (K(), h(l[r], 1, 1, () => {
                l[r] = null
            }), z()), ~e ? (n = l[e], n ? n.p(o, f) : (n = l[e] = s[e](o), n.c()), g(n, 1), n.m(t.parentNode, t)) : n = null)
        },
        i(o) {
            a || (g(n), a = !0)
        },
        o(o) {
            h(n), a = !1
        },
        d(o) {
            o && p(t), ~e && l[e].d(o)
        }
    }
}

function Ma(i) {
    let e, n, t, a;
    return e = new ge({
        props: {
            width: "20px",
            height: "20px"
        }
    }), t = new ge({
        props: {
            width: "10ch",
            style: "margin-left: var(--space-3);"
        }
    }), {
        c() {
            j(e.$$.fragment), n = R(), j(t.$$.fragment)
        },
        l(s) {
            T(e.$$.fragment, s), n = B(s), T(t.$$.fragment, s)
        },
        m(s, l) {
            D(e, s, l), k(s, n, l), D(t, s, l), a = !0
        },
        p: U,
        i(s) {
            a || (g(e.$$.fragment, s), g(t.$$.fragment, s), a = !0)
        },
        o(s) {
            h(e.$$.fragment, s), h(t.$$.fragment, s), a = !1
        },
        d(s) {
            s && p(n), C(e, s), C(t, s)
        }
    }
}

function Wa(i) {
    let e, n, t, a, s, l, u, o = i[17] === "home" && ze(i);
    const f = [Za, Ya],
        r = [];

    function c(m, d) {
        var b;
        return m[20] ? 0 : m[10] || (b = m[15]) != null && b.iconPath ? 1 : -1
    }
    return ~(n = c(i)) && (t = r[n] = f[n](i)), l = new Z({
        props: {
            variant: "highlighted",
            $$slots: {
                default: [qa]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            o && o.c(), e = R(), t && t.c(), a = R(), s = I("span"), j(l.$$.fragment)
        },
        l(m) {
            o && o.l(m), e = B(m), t && t.l(m), a = B(m), s = G(m, "SPAN", {});
            var d = E(s);
            T(l.$$.fragment, d), d.forEach(p)
        },
        m(m, d) {
            o && o.m(m, d), k(m, e, d), ~n && r[n].m(m, d), k(m, a, d), k(m, s, d), D(l, s, null), u = !0
        },
        p(m, d) {
            m[17] === "home" ? o ? (o.p(m, d), d & 131072 && g(o, 1)) : (o = ze(m), o.c(), g(o, 1), o.m(e.parentNode, e)) : o && (K(), h(o, 1, 1, () => {
                o = null
            }), z());
            let b = n;
            n = c(m), n === b ? ~n && r[n].p(m, d) : (t && (K(), h(r[b], 1, 1, () => {
                r[b] = null
            }), z()), ~n ? (t = r[n], t ? t.p(m, d) : (t = r[n] = f[n](m), t.c()), g(t, 1), t.m(a.parentNode, a)) : t = null);
            const S = {};
            d & 1073774592 && (S.$$scope = {
                dirty: d,
                ctx: m
            }), l.$set(S)
        },
        i(m) {
            u || (g(o), g(t), g(l.$$.fragment, m), u = !0)
        },
        o(m) {
            h(o), h(t), h(l.$$.fragment, m), u = !1
        },
        d(m) {
            m && (p(e), p(a), p(s)), o && o.d(m), ~n && r[n].d(m), C(l)
        }
    }
}

function ze(i) {
    let e, n, t;
    return n = new Re({
        props: {
            icon: i[1],
            style: "fill: var(--yellow-500); height: 0.875rem; width: 0.875rem;"
        }
    }), {
        c() {
            e = I("div"), j(n.$$.fragment), this.h()
        },
        l(a) {
            e = G(a, "DIV", {
                class: !0
            });
            var s = E(e);
            T(n.$$.fragment, s), s.forEach(p), this.h()
        },
        h() {
            $(e, "class", "server-icon svelte-1jl15xp")
        },
        m(a, s) {
            k(a, e, s), D(n, e, null), t = !0
        },
        p(a, s) {
            const l = {};
            s & 2 && (l.icon = a[1]), n.$set(l)
        },
        i(a) {
            t || (g(n.$$.fragment, a), t = !0)
        },
        o(a) {
            h(n.$$.fragment, a), t = !1
        },
        d(a) {
            a && p(e), C(n)
        }
    }
}

function Ya(i) {
    var t, a;
    let e, n;
    return e = new it({
        props: {
            sport: i[1],
            competitor: {
                extId: (t = i[15]) == null ? void 0 : t.extId,
                iconPath: (a = i[15]) == null ? void 0 : a.iconPath
            },
            size: "medium"
        }
    }), {
        c() {
            j(e.$$.fragment)
        },
        l(s) {
            T(e.$$.fragment, s)
        },
        m(s, l) {
            D(e, s, l), n = !0
        },
        p(s, l) {
            var o, f;
            const u = {};
            l & 2 && (u.sport = s[1]), l & 32768 && (u.competitor = {
                extId: (o = s[15]) == null ? void 0 : o.extId,
                iconPath: (f = s[15]) == null ? void 0 : f.iconPath
            }), e.$set(u)
        },
        i(s) {
            n || (g(e.$$.fragment, s), n = !0)
        },
        o(s) {
            h(e.$$.fragment, s), n = !1
        },
        d(s) {
            C(e, s)
        }
    }
}

function Za(i) {
    let e, n;
    return e = new ge({
        props: {
            width: "2ch",
            height: "2ch",
            style: "margin-right: var(--space-1);"
        }
    }), {
        c() {
            j(e.$$.fragment)
        },
        l(t) {
            T(e.$$.fragment, t)
        },
        m(t, a) {
            D(e, t, a), n = !0
        },
        p: U,
        i(t) {
            n || (g(e.$$.fragment, t), n = !0)
        },
        o(t) {
            h(e.$$.fragment, t), n = !1
        },
        d(t) {
            C(e, t)
        }
    }
}

function qa(i) {
    var t;
    let e = ((t = i[15]) == null ? void 0 : t.name) + "",
        n;
    return {
        c() {
            n = X(e)
        },
        l(a) {
            n = Q(a, e)
        },
        m(a, s) {
            k(a, n, s)
        },
        p(a, s) {
            var l;
            s & 32768 && e !== (e = ((l = a[15]) == null ? void 0 : l.name) + "") && x(n, e)
        },
        d(a) {
            a && p(n)
        }
    }
}

function La(i) {
    let e, n, t, a;
    return e = new ge({
        props: {
            width: "20px",
            height: "20px"
        }
    }), t = new ge({
        props: {
            width: "10ch",
            style: "margin-left: var(--space-3);"
        }
    }), {
        c() {
            j(e.$$.fragment), n = R(), j(t.$$.fragment)
        },
        l(s) {
            T(e.$$.fragment, s), n = B(s), T(t.$$.fragment, s)
        },
        m(s, l) {
            D(e, s, l), k(s, n, l), D(t, s, l), a = !0
        },
        p: U,
        i(s) {
            a || (g(e.$$.fragment, s), g(t.$$.fragment, s), a = !0)
        },
        o(s) {
            h(e.$$.fragment, s), h(t.$$.fragment, s), a = !1
        },
        d(s) {
            s && p(n), C(e, s), C(t, s)
        }
    }
}

function Ka(i) {
    let e, n, t, a, s, l, u, o = i[17] === "away" && Ue(i);
    const f = [Ua, za],
        r = [];

    function c(m, d) {
        var b;
        return m[20] ? 0 : m[10] || (b = m[14]) != null && b.iconPath ? 1 : -1
    }
    return ~(n = c(i)) && (t = r[n] = f[n](i)), l = new Z({
        props: {
            variant: "highlighted",
            $$slots: {
                default: [Xa]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            o && o.c(), e = R(), t && t.c(), a = R(), s = I("span"), j(l.$$.fragment)
        },
        l(m) {
            o && o.l(m), e = B(m), t && t.l(m), a = B(m), s = G(m, "SPAN", {});
            var d = E(s);
            T(l.$$.fragment, d), d.forEach(p)
        },
        m(m, d) {
            o && o.m(m, d), k(m, e, d), ~n && r[n].m(m, d), k(m, a, d), k(m, s, d), D(l, s, null), u = !0
        },
        p(m, d) {
            m[17] === "away" ? o ? (o.p(m, d), d & 131072 && g(o, 1)) : (o = Ue(m), o.c(), g(o, 1), o.m(e.parentNode, e)) : o && (K(), h(o, 1, 1, () => {
                o = null
            }), z());
            let b = n;
            n = c(m), n === b ? ~n && r[n].p(m, d) : (t && (K(), h(r[b], 1, 1, () => {
                r[b] = null
            }), z()), ~n ? (t = r[n], t ? t.p(m, d) : (t = r[n] = f[n](m), t.c()), g(t, 1), t.m(a.parentNode, a)) : t = null);
            const S = {};
            d & 1073758208 && (S.$$scope = {
                dirty: d,
                ctx: m
            }), l.$set(S)
        },
        i(m) {
            u || (g(o), g(t), g(l.$$.fragment, m), u = !0)
        },
        o(m) {
            h(o), h(t), h(l.$$.fragment, m), u = !1
        },
        d(m) {
            m && (p(e), p(a), p(s)), o && o.d(m), ~n && r[n].d(m), C(l)
        }
    }
}

function Ue(i) {
    let e, n, t;
    return n = new Re({
        props: {
            icon: i[1],
            style: "fill: var(--yellow-500); height: 0.875rem; width: 0.875rem;"
        }
    }), {
        c() {
            e = I("div"), j(n.$$.fragment), this.h()
        },
        l(a) {
            e = G(a, "DIV", {
                class: !0
            });
            var s = E(e);
            T(n.$$.fragment, s), s.forEach(p), this.h()
        },
        h() {
            $(e, "class", "server-icon svelte-1jl15xp")
        },
        m(a, s) {
            k(a, e, s), D(n, e, null), t = !0
        },
        p(a, s) {
            const l = {};
            s & 2 && (l.icon = a[1]), n.$set(l)
        },
        i(a) {
            t || (g(n.$$.fragment, a), t = !0)
        },
        o(a) {
            h(n.$$.fragment, a), t = !1
        },
        d(a) {
            a && p(e), C(n)
        }
    }
}

function za(i) {
    var t, a;
    let e, n;
    return e = new it({
        props: {
            sport: i[1],
            competitor: {
                extId: (t = i[14]) == null ? void 0 : t.extId,
                iconPath: (a = i[14]) == null ? void 0 : a.iconPath
            },
            size: "medium"
        }
    }), {
        c() {
            j(e.$$.fragment)
        },
        l(s) {
            T(e.$$.fragment, s)
        },
        m(s, l) {
            D(e, s, l), n = !0
        },
        p(s, l) {
            var o, f;
            const u = {};
            l & 2 && (u.sport = s[1]), l & 16384 && (u.competitor = {
                extId: (o = s[14]) == null ? void 0 : o.extId,
                iconPath: (f = s[14]) == null ? void 0 : f.iconPath
            }), e.$set(u)
        },
        i(s) {
            n || (g(e.$$.fragment, s), n = !0)
        },
        o(s) {
            h(e.$$.fragment, s), n = !1
        },
        d(s) {
            C(e, s)
        }
    }
}

function Ua(i) {
    let e, n;
    return e = new ge({
        props: {
            width: "2ch",
            height: "2ch",
            style: "margin-right: var(--space-1);"
        }
    }), {
        c() {
            j(e.$$.fragment)
        },
        l(t) {
            T(e.$$.fragment, t)
        },
        m(t, a) {
            D(e, t, a), n = !0
        },
        p: U,
        i(t) {
            n || (g(e.$$.fragment, t), n = !0)
        },
        o(t) {
            h(e.$$.fragment, t), n = !1
        },
        d(t) {
            C(e, t)
        }
    }
}

function Xa(i) {
    var t;
    let e = ((t = i[14]) == null ? void 0 : t.name) + "",
        n;
    return {
        c() {
            n = X(e)
        },
        l(a) {
            n = Q(a, e)
        },
        m(a, s) {
            k(a, n, s)
        },
        p(a, s) {
            var l;
            s & 16384 && e !== (e = ((l = a[14]) == null ? void 0 : l.name) + "") && x(n, e)
        },
        d(a) {
            a && p(n)
        }
    }
}

function Xe(i) {
    let e, n, t, a, s, l, u, o, f;
    return n = new gt({}), s = new Z({
        props: {
            $$slots: {
                default: [Qa]
            },
            $$scope: {
                ctx: i
            }
        }
    }), o = new Z({
        props: {
            $$slots: {
                default: [Ja]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            e = I("div"), j(n.$$.fragment), t = R(), a = I("span"), j(s.$$.fragment), l = R(), u = I("span"), j(o.$$.fragment), this.h()
        },
        l(r) {
            e = G(r, "DIV", {
                class: !0,
                style: !0
            });
            var c = E(e);
            T(n.$$.fragment, c), c.forEach(p), t = B(r), a = G(r, "SPAN", {
                class: !0,
                style: !0
            });
            var m = E(a);
            T(s.$$.fragment, m), m.forEach(p), l = B(r), u = G(r, "SPAN", {
                class: !0,
                style: !0
            });
            var d = E(u);
            T(o.$$.fragment, d), d.forEach(p), this.h()
        },
        h() {
            $(e, "class", "heading center svelte-1jl15xp"), P(e, "grid-area", "corners_title"), $(a, "class", "border-item fill-frame svelte-1jl15xp"), P(a, "grid-area", "corners_home"), F(a, "light-grey", (i[9].home || 0) < (i[9].away || 0)), $(u, "class", "fill-frame svelte-1jl15xp"), P(u, "grid-area", "corners_away"), F(u, "light-grey", (i[9].home || 0) > (i[9].away || 0))
        },
        m(r, c) {
            k(r, e, c), D(n, e, null), k(r, t, c), k(r, a, c), D(s, a, null), k(r, l, c), k(r, u, c), D(o, u, null), f = !0
        },
        p(r, c) {
            const m = {};
            c & 1073742336 && (m.$$scope = {
                dirty: c,
                ctx: r
            }), s.$set(m), (!f || c & 512) && F(a, "light-grey", (r[9].home || 0) < (r[9].away || 0));
            const d = {};
            c & 1073742336 && (d.$$scope = {
                dirty: c,
                ctx: r
            }), o.$set(d), (!f || c & 512) && F(u, "light-grey", (r[9].home || 0) > (r[9].away || 0))
        },
        i(r) {
            f || (g(n.$$.fragment, r), g(s.$$.fragment, r), g(o.$$.fragment, r), f = !0)
        },
        o(r) {
            h(n.$$.fragment, r), h(s.$$.fragment, r), h(o.$$.fragment, r), f = !1
        },
        d(r) {
            r && (p(e), p(t), p(a), p(l), p(u)), C(n), C(s), C(o)
        }
    }
}

function Qa(i) {
    let e = (i[9].home ? ? "-") + "",
        n;
    return {
        c() {
            n = X(e)
        },
        l(t) {
            n = Q(t, e)
        },
        m(t, a) {
            k(t, n, a)
        },
        p(t, a) {
            a & 512 && e !== (e = (t[9].home ? ? "-") + "") && x(n, e)
        },
        d(t) {
            t && p(n)
        }
    }
}

function Ja(i) {
    let e = (i[9].away ? ? "-") + "",
        n;
    return {
        c() {
            n = X(e)
        },
        l(t) {
            n = Q(t, e)
        },
        m(t, a) {
            k(t, n, a)
        },
        p(t, a) {
            a & 512 && e !== (e = (t[9].away ? ? "-") + "") && x(n, e)
        },
        d(t) {
            t && p(n)
        }
    }
}

function Qe(i) {
    let e, n, t, a, s, l, u, o, f;
    return n = new kt({}), s = new Z({
        props: {
            $$slots: {
                default: [xa]
            },
            $$scope: {
                ctx: i
            }
        }
    }), o = new Z({
        props: {
            $$slots: {
                default: [en]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            e = I("div"), j(n.$$.fragment), t = R(), a = I("span"), j(s.$$.fragment), l = R(), u = I("span"), j(o.$$.fragment), this.h()
        },
        l(r) {
            e = G(r, "DIV", {
                class: !0,
                style: !0
            });
            var c = E(e);
            T(n.$$.fragment, c), c.forEach(p), t = B(r), a = G(r, "SPAN", {
                class: !0,
                style: !0
            });
            var m = E(a);
            T(s.$$.fragment, m), m.forEach(p), l = B(r), u = G(r, "SPAN", {
                class: !0,
                style: !0
            });
            var d = E(u);
            T(o.$$.fragment, d), d.forEach(p), this.h()
        },
        h() {
            $(e, "class", "heading center svelte-1jl15xp"), P(e, "grid-area", "redCards_title"), $(a, "class", "border-item fill-frame svelte-1jl15xp"), P(a, "grid-area", "redCards_home"), F(a, "light-grey", (i[7].home || 0) < (i[7].away || 0)), $(u, "class", "fill-frame svelte-1jl15xp"), P(u, "grid-area", "redCards_away"), F(u, "light-grey", (i[7].home || 0) > (i[7].away || 0))
        },
        m(r, c) {
            k(r, e, c), D(n, e, null), k(r, t, c), k(r, a, c), D(s, a, null), k(r, l, c), k(r, u, c), D(o, u, null), f = !0
        },
        p(r, c) {
            const m = {};
            c & 1073741952 && (m.$$scope = {
                dirty: c,
                ctx: r
            }), s.$set(m), (!f || c & 128) && F(a, "light-grey", (r[7].home || 0) < (r[7].away || 0));
            const d = {};
            c & 1073741952 && (d.$$scope = {
                dirty: c,
                ctx: r
            }), o.$set(d), (!f || c & 128) && F(u, "light-grey", (r[7].home || 0) > (r[7].away || 0))
        },
        i(r) {
            f || (g(n.$$.fragment, r), g(s.$$.fragment, r), g(o.$$.fragment, r), f = !0)
        },
        o(r) {
            h(n.$$.fragment, r), h(s.$$.fragment, r), h(o.$$.fragment, r), f = !1
        },
        d(r) {
            r && (p(e), p(t), p(a), p(l), p(u)), C(n), C(s), C(o)
        }
    }
}

function xa(i) {
    let e = (i[7].home ? ? "-") + "",
        n;
    return {
        c() {
            n = X(e)
        },
        l(t) {
            n = Q(t, e)
        },
        m(t, a) {
            k(t, n, a)
        },
        p(t, a) {
            a & 128 && e !== (e = (t[7].home ? ? "-") + "") && x(n, e)
        },
        d(t) {
            t && p(n)
        }
    }
}

function en(i) {
    let e = (i[7].away ? ? "-") + "",
        n;
    return {
        c() {
            n = X(e)
        },
        l(t) {
            n = Q(t, e)
        },
        m(t, a) {
            k(t, n, a)
        },
        p(t, a) {
            a & 128 && e !== (e = (t[7].away ? ? "-") + "") && x(n, e)
        },
        d(t) {
            t && p(n)
        }
    }
}

function Je(i) {
    let e, n, t, a, s, l, u, o, f;
    return n = new $t({}), s = new Z({
        props: {
            $$slots: {
                default: [tn]
            },
            $$scope: {
                ctx: i
            }
        }
    }), o = new Z({
        props: {
            $$slots: {
                default: [an]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            e = I("div"), j(n.$$.fragment), t = R(), a = I("span"), j(s.$$.fragment), l = R(), u = I("span"), j(o.$$.fragment), this.h()
        },
        l(r) {
            e = G(r, "DIV", {
                class: !0,
                style: !0
            });
            var c = E(e);
            T(n.$$.fragment, c), c.forEach(p), t = B(r), a = G(r, "SPAN", {
                class: !0,
                style: !0
            });
            var m = E(a);
            T(s.$$.fragment, m), m.forEach(p), l = B(r), u = G(r, "SPAN", {
                class: !0,
                style: !0
            });
            var d = E(u);
            T(o.$$.fragment, d), d.forEach(p), this.h()
        },
        h() {
            $(e, "class", "heading center svelte-1jl15xp"), P(e, "grid-area", "yellowCards_title"), $(a, "class", "border-item fill-frame svelte-1jl15xp"), P(a, "grid-area", "yellowCards_home"), F(a, "light-grey", (i[8].home || 0) < (i[8].away || 0)), $(u, "class", "fill-frame svelte-1jl15xp"), P(u, "grid-area", "yellowCards_away"), F(u, "light-grey", i[8].home && i[8].away && i[8].home > i[8].away)
        },
        m(r, c) {
            k(r, e, c), D(n, e, null), k(r, t, c), k(r, a, c), D(s, a, null), k(r, l, c), k(r, u, c), D(o, u, null), f = !0
        },
        p(r, c) {
            const m = {};
            c & 1073742080 && (m.$$scope = {
                dirty: c,
                ctx: r
            }), s.$set(m), (!f || c & 256) && F(a, "light-grey", (r[8].home || 0) < (r[8].away || 0));
            const d = {};
            c & 1073742080 && (d.$$scope = {
                dirty: c,
                ctx: r
            }), o.$set(d), (!f || c & 256) && F(u, "light-grey", r[8].home && r[8].away && r[8].home > r[8].away)
        },
        i(r) {
            f || (g(n.$$.fragment, r), g(s.$$.fragment, r), g(o.$$.fragment, r), f = !0)
        },
        o(r) {
            h(n.$$.fragment, r), h(s.$$.fragment, r), h(o.$$.fragment, r), f = !1
        },
        d(r) {
            r && (p(e), p(t), p(a), p(l), p(u)), C(n), C(s), C(o)
        }
    }
}

function tn(i) {
    let e = (i[8].home ? ? "-") + "",
        n;
    return {
        c() {
            n = X(e)
        },
        l(t) {
            n = Q(t, e)
        },
        m(t, a) {
            k(t, n, a)
        },
        p(t, a) {
            a & 256 && e !== (e = (t[8].home ? ? "-") + "") && x(n, e)
        },
        d(t) {
            t && p(n)
        }
    }
}

function an(i) {
    let e = (i[8].away ? ? "-") + "",
        n;
    return {
        c() {
            n = X(e)
        },
        l(t) {
            n = Q(t, e)
        },
        m(t, a) {
            k(t, n, a)
        },
        p(t, a) {
            a & 256 && e !== (e = (t[8].away ? ? "-") + "") && x(n, e)
        },
        d(t) {
            t && p(n)
        }
    }
}

function xe(i) {
    let e, n, t = Ve(i[6]),
        a = [];
    for (let l = 0; l < t.length; l += 1) a[l] = et(Le(i, t, l));
    const s = l => h(a[l], 1, 1, () => {
        a[l] = null
    });
    return {
        c() {
            for (let l = 0; l < a.length; l += 1) a[l].c();
            e = he()
        },
        l(l) {
            for (let u = 0; u < a.length; u += 1) a[u].l(l);
            e = he()
        },
        m(l, u) {
            for (let o = 0; o < a.length; o += 1) a[o] && a[o].m(l, u);
            k(l, e, u), n = !0
        },
        p(l, u) {
            if (u & 65) {
                t = Ve(l[6]);
                let o;
                for (o = 0; o < t.length; o += 1) {
                    const f = Le(l, t, o);
                    a[o] ? (a[o].p(f, u), g(a[o], 1)) : (a[o] = et(f), a[o].c(), g(a[o], 1), a[o].m(e.parentNode, e))
                }
                for (K(), o = t.length; o < a.length; o += 1) s(o);
                z()
            }
        },
        i(l) {
            if (!n) {
                for (let u = 0; u < t.length; u += 1) g(a[u]);
                n = !0
            }
        },
        o(l) {
            a = a.filter(Ia);
            for (let u = 0; u < a.length; u += 1) h(a[u]);
            n = !1
        },
        d(l) {
            l && p(e), ot(a, l)
        }
    }
}

function nn(i) {
    let e = ut(i[29] + 1) + "",
        n;
    return {
        c() {
            n = X(e)
        },
        l(t) {
            n = Q(t, e)
        },
        m(t, a) {
            k(t, n, a)
        },
        p: U,
        d(t) {
            t && p(n)
        }
    }
}

function sn(i) {
    let e = (i[27].homeWonRounds ? ? i[27].homeKills ? ? i[27].homeGoals ? ? i[27].homeScore ? ? "-") + "",
        n;
    return {
        c() {
            n = X(e)
        },
        l(t) {
            n = Q(t, e)
        },
        m(t, a) {
            k(t, n, a)
        },
        p(t, a) {
            a & 64 && e !== (e = (t[27].homeWonRounds ? ? t[27].homeKills ? ? t[27].homeGoals ? ? t[27].homeScore ? ? "-") + "") && x(n, e)
        },
        d(t) {
            t && p(n)
        }
    }
}

function ln(i) {
    let e = (i[27].awayWonRounds ? ? i[27].awayKills ? ? i[27].awayGoals ? ? i[27].awayScore ? ? "-") + "",
        n;
    return {
        c() {
            n = X(e)
        },
        l(t) {
            n = Q(t, e)
        },
        m(t, a) {
            k(t, n, a)
        },
        p(t, a) {
            a & 64 && e !== (e = (t[27].awayWonRounds ? ? t[27].awayKills ? ? t[27].awayGoals ? ? t[27].awayScore ? ? "-") + "") && x(n, e)
        },
        d(t) {
            t && p(n)
        }
    }
}

function et(i) {
    var c, m;
    let e, n, t, a, s, l, u, o, f, r;
    return n = new Z({
        props: {
            $$slots: {
                default: [nn]
            },
            $$scope: {
                ctx: i
            }
        }
    }), s = new Z({
        props: {
            weight: ((c = i[0]) == null ? void 0 : c.provider) === _e.oddin && i[27].homeScore === 1 ? "bold" : "normal",
            $$slots: {
                default: [sn]
            },
            $$scope: {
                ctx: i
            }
        }
    }), o = new Z({
        props: {
            weight: ((m = i[0]) == null ? void 0 : m.provider) === _e.oddin && i[27].awayScore === 1 ? "bold" : "normal",
            $$slots: {
                default: [ln]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            e = I("div"), j(n.$$.fragment), t = R(), a = I("span"), j(s.$$.fragment), l = R(), u = I("span"), j(o.$$.fragment), f = R(), this.h()
        },
        l(d) {
            e = G(d, "DIV", {
                class: !0,
                style: !0
            });
            var b = E(e);
            T(n.$$.fragment, b), b.forEach(p), t = B(d), a = G(d, "SPAN", {
                class: !0,
                style: !0
            });
            var S = E(a);
            T(s.$$.fragment, S), S.forEach(p), l = B(d), u = G(d, "SPAN", {
                class: !0,
                style: !0
            });
            var A = E(u);
            T(o.$$.fragment, A), f = B(A), A.forEach(p), this.h()
        },
        h() {
            $(e, "class", "heading center light-grey svelte-1jl15xp"), P(e, "grid-area", "period_title_" + i[29]), $(a, "class", "border-item fill-frame svelte-1jl15xp"), P(a, "grid-area", "period_home_" + i[29]), F(a, "light-grey", i[27].homeScore < i[27].awayScore), $(u, "class", "fill-frame svelte-1jl15xp"), P(u, "grid-area", "period_away_" + i[29]), F(u, "light-grey", i[27].homeScore > i[27].awayScore)
        },
        m(d, b) {
            k(d, e, b), D(n, e, null), k(d, t, b), k(d, a, b), D(s, a, null), k(d, l, b), k(d, u, b), D(o, u, null), L(u, f), r = !0
        },
        p(d, b) {
            var se, le;
            const S = {};
            b & 1073741824 && (S.$$scope = {
                dirty: b,
                ctx: d
            }), n.$set(S);
            const A = {};
            b & 65 && (A.weight = ((se = d[0]) == null ? void 0 : se.provider) === _e.oddin && d[27].homeScore === 1 ? "bold" : "normal"), b & 1073741888 && (A.$$scope = {
                dirty: b,
                ctx: d
            }), s.$set(A), (!r || b & 64) && F(a, "light-grey", d[27].homeScore < d[27].awayScore);
            const ee = {};
            b & 65 && (ee.weight = ((le = d[0]) == null ? void 0 : le.provider) === _e.oddin && d[27].awayScore === 1 ? "bold" : "normal"), b & 1073741888 && (ee.$$scope = {
                dirty: b,
                ctx: d
            }), o.$set(ee), (!r || b & 64) && F(u, "light-grey", d[27].homeScore > d[27].awayScore)
        },
        i(d) {
            r || (g(n.$$.fragment, d), g(s.$$.fragment, d), g(o.$$.fragment, d), r = !0)
        },
        o(d) {
            h(n.$$.fragment, d), h(s.$$.fragment, d), h(o.$$.fragment, d), r = !1
        },
        d(d) {
            d && (p(e), p(t), p(a), p(l), p(u)), C(n), C(s), C(o)
        }
    }
}

function tt(i) {
    let e, n, t, a, s, l, u, o, f, r;
    return t = new Re({
        props: {
            icon: i[1]
        }
    }), l = new Z({
        props: {
            weight: "semibold",
            variant: i[16] !== "ended" ? "warn" : void 0,
            $$slots: {
                default: [rn]
            },
            $$scope: {
                ctx: i
            }
        }
    }), f = new Z({
        props: {
            weight: "semibold",
            variant: i[16] !== "ended" ? "warn" : void 0,
            $$slots: {
                default: [on]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            e = I("div"), n = I("span"), j(t.$$.fragment), a = R(), s = I("div"), j(l.$$.fragment), u = R(), o = I("div"), j(f.$$.fragment), this.h()
        },
        l(c) {
            e = G(c, "DIV", {
                class: !0,
                style: !0
            });
            var m = E(e);
            n = G(m, "SPAN", {});
            var d = E(n);
            T(t.$$.fragment, d), d.forEach(p), m.forEach(p), a = B(c), s = G(c, "DIV", {
                class: !0,
                style: !0
            });
            var b = E(s);
            T(l.$$.fragment, b), b.forEach(p), u = B(c), o = G(c, "DIV", {
                class: !0,
                style: !0
            });
            var S = E(o);
            T(f.$$.fragment, S), S.forEach(p), this.h()
        },
        h() {
            $(e, "class", "heading center svelte-1jl15xp"), P(e, "grid-area", "matchScore_title"), $(s, "class", "match-score border-item fill-frame svelte-1jl15xp"), P(s, "grid-area", "matchScore_home"), F(s, "completed", i[16] === "ended" && i[19] > i[18]), $(o, "class", "match-score fill-frame svelte-1jl15xp"), P(o, "grid-area", "matchScore_away"), F(o, "completed", i[16] === "ended" && i[19] < i[18])
        },
        m(c, m) {
            k(c, e, m), L(e, n), D(t, n, null), k(c, a, m), k(c, s, m), D(l, s, null), k(c, u, m), k(c, o, m), D(f, o, null), r = !0
        },
        p(c, m) {
            const d = {};
            m & 2 && (d.icon = c[1]), t.$set(d);
            const b = {};
            m & 65536 && (b.variant = c[16] !== "ended" ? "warn" : void 0), m & 1074266112 && (b.$$scope = {
                dirty: m,
                ctx: c
            }), l.$set(b), (!r || m & 851968) && F(s, "completed", c[16] === "ended" && c[19] > c[18]);
            const S = {};
            m & 65536 && (S.variant = c[16] !== "ended" ? "warn" : void 0), m & 1074003968 && (S.$$scope = {
                dirty: m,
                ctx: c
            }), f.$set(S), (!r || m & 851968) && F(o, "completed", c[16] === "ended" && c[19] < c[18])
        },
        i(c) {
            r || (g(t.$$.fragment, c), g(l.$$.fragment, c), g(f.$$.fragment, c), r = !0)
        },
        o(c) {
            h(t.$$.fragment, c), h(l.$$.fragment, c), h(f.$$.fragment, c), r = !1
        },
        d(c) {
            c && (p(e), p(a), p(s), p(u), p(o)), C(t), C(l), C(f)
        }
    }
}

function rn(i) {
    let e;
    return {
        c() {
            e = X(i[19])
        },
        l(n) {
            e = Q(n, i[19])
        },
        m(n, t) {
            k(n, e, t)
        },
        p(n, t) {
            t & 524288 && x(e, n[19])
        },
        d(n) {
            n && p(e)
        }
    }
}

function on(i) {
    let e;
    return {
        c() {
            e = X(i[18])
        },
        l(n) {
            e = Q(n, i[18])
        },
        m(n, t) {
            k(n, e, t)
        },
        p(n, t) {
            t & 262144 && x(e, n[18])
        },
        d(n) {
            n && p(e)
        }
    }
}

function at(i) {
    let e, n, t, a, s, l, u, o;
    return a = new Z({
        props: {
            $$slots: {
                default: [mn]
            },
            $$scope: {
                ctx: i
            }
        }
    }), u = new Z({
        props: {
            $$slots: {
                default: [un]
            },
            $$scope: {
                ctx: i
            }
        }
    }), {
        c() {
            e = I("div"), n = R(), t = I("span"), j(a.$$.fragment), s = R(), l = I("span"), j(u.$$.fragment), this.h()
        },
        l(f) {
            e = G(f, "DIV", {
                class: !0,
                style: !0
            }), E(e).forEach(p), n = B(f), t = G(f, "SPAN", {
                class: !0,
                style: !0
            });
            var r = E(t);
            T(a.$$.fragment, r), r.forEach(p), s = B(f), l = G(f, "SPAN", {
                class: !0,
                style: !0
            });
            var c = E(l);
            T(u.$$.fragment, c), c.forEach(p), this.h()
        },
        h() {
            $(e, "class", "heading center svelte-1jl15xp"), P(e, "grid-area", "gameScore_title"), $(t, "class", "border-item fill-frame svelte-1jl15xp"), P(t, "grid-area", "gameScore_home"), F(t, "light-grey", i[5].homeGameScore < i[5].awayGameScore), $(l, "class", "fill-frame svelte-1jl15xp"), P(l, "grid-area", "gameScore_away"), F(l, "light-grey", i[5].homeGameScore > i[5].awayGameScore)
        },
        m(f, r) {
            k(f, e, r), k(f, n, r), k(f, t, r), D(a, t, null), k(f, s, r), k(f, l, r), D(u, l, null), o = !0
        },
        p(f, r) {
            const c = {};
            r & 1073741856 && (c.$$scope = {
                dirty: r,
                ctx: f
            }), a.$set(c), (!o || r & 32) && F(t, "light-grey", f[5].homeGameScore < f[5].awayGameScore);
            const m = {};
            r & 1073741856 && (m.$$scope = {
                dirty: r,
                ctx: f
            }), u.$set(m), (!o || r & 32) && F(l, "light-grey", f[5].homeGameScore > f[5].awayGameScore)
        },
        i(f) {
            o || (g(a.$$.fragment, f), g(u.$$.fragment, f), o = !0)
        },
        o(f) {
            h(a.$$.fragment, f), h(u.$$.fragment, f), o = !1
        },
        d(f) {
            f && (p(e), p(n), p(t), p(s), p(l)), C(a), C(u)
        }
    }
}

function mn(i) {
    var t;
    let e = ((t = i[5]) == null ? void 0 : t.homeGameScore) + "",
        n;
    return {
        c() {
            n = X(e)
        },
        l(a) {
            n = Q(a, e)
        },
        m(a, s) {
            k(a, n, s)
        },
        p(a, s) {
            var l;
            s & 32 && e !== (e = ((l = a[5]) == null ? void 0 : l.homeGameScore) + "") && x(n, e)
        },
        d(a) {
            a && p(n)
        }
    }
}

function un(i) {
    var t;
    let e = ((t = i[5]) == null ? void 0 : t.awayGameScore) + "",
        n;
    return {
        c() {
            n = X(e)
        },
        l(a) {
            n = Q(a, e)
        },
        m(a, s) {
            k(a, n, s)
        },
        p(a, s) {
            var l;
            s & 32 && e !== (e = ((l = a[5]) == null ? void 0 : l.awayGameScore) + "") && x(n, e)
        },
        d(a) {
            a && p(n)
        }
    }
}

function cn(i) {
    var fe, we;
    let e, n, t, a, s, l, u, o, f, r, c, m, d, b, S, A, ee, se, le, ce, oe = i[4] && pe(i[1], "scoring").scoreboard !== "none",
        de, J, w = i[13] && Ke(i);
    const te = [Ba, Ra, Ga],
        ne = [];

    function ke(v, N) {
        var me;
        return v[4] ? 0 : (me = v[0]) != null && me.data && "startTime" in v[0].data ? 1 : 2
    }
    l = ke(i), u = ne[l] = te[l](i);
    const ve = [Wa, Ma],
        ae = [];

    function q(v, N) {
        return v[15] ? 0 : 1
    }
    r = q(i), c = ae[r] = ve[r](i);
    const be = [Ka, La],
        ie = [];

    function $e(v, N) {
        return v[14] ? 0 : 1
    }
    b = $e(i), S = ie[b] = be[b](i);
    let O = i[9] && Xe(i),
        H = i[7] && Qe(i),
        M = i[8] && Je(i),
        W = i[6] && xe(i),
        y = oe && tt(i),
        V = ((fe = i[5]) == null ? void 0 : fe.homeGameScore) && ((we = i[5]) == null ? void 0 : we.awayGameScore) && at(i);
    return {
        c() {
            e = I("div"), n = I("div"), t = I("div"), a = I("div"), w && w.c(), s = R(), u.c(), o = R(), f = I("div"), c.c(), m = R(), d = I("div"), S.c(), A = R(), O && O.c(), ee = R(), H && H.c(), se = R(), M && M.c(), le = R(), W && W.c(), ce = R(), y && y.c(), de = R(), V && V.c(), this.h()
        },
        l(v) {
            e = G(v, "DIV", {
                class: !0,
                style: !0
            });
            var N = E(e);
            n = G(N, "DIV", {
                class: !0
            });
            var me = E(n);
            t = G(me, "DIV", {
                style: !0,
                class: !0
            });
            var Y = E(t);
            a = G(Y, "DIV", {
                class: !0,
                style: !0
            });
            var ue = E(a);
            w && w.l(ue), s = B(ue), u.l(ue), ue.forEach(p), o = B(Y), f = G(Y, "DIV", {
                class: !0,
                style: !0
            });
            var ye = E(f);
            c.l(ye), ye.forEach(p), m = B(Y), d = G(Y, "DIV", {
                class: !0,
                style: !0
            });
            var Se = E(d);
            S.l(Se), Se.forEach(p), A = B(Y), O && O.l(Y), ee = B(Y), H && H.l(Y), se = B(Y), M && M.l(Y), le = B(Y), W && W.l(Y), ce = B(Y), y && y.l(Y), de = B(Y), V && V.l(Y), Y.forEach(p), me.forEach(p), N.forEach(p), this.h()
        },
        h() {
            $(a, "class", "heading chromatic-ignore svelte-1jl15xp"), P(a, "grid-area", "competitor_title"), P(a, "text-align", "'left;"), F(a, "remove-background", i[2]), $(f, "class", "competitor-item border-item svelte-1jl15xp"), P(f, "grid-area", "competitor_home"), $(d, "class", "competitor-item svelte-1jl15xp"), P(d, "grid-area", "competitor_away"), P(t, "grid-template-areas", i[11]), $(t, "class", "content scrollX svelte-1jl15xp"), F(t, "remove-background", i[2]), F(t, "remove-box-shadow", i[3]), $(n, "class", "wrapper svelte-1jl15xp"), F(n, "has-background", !i[2]), F(n, "box-shadow", !i[3]), $(e, "class", "match-statistics svelte-1jl15xp"), P(e, "--sport-image", "url(" + i[12] + ")"), F(e, "background", !i[2])
        },
        m(v, N) {
            k(v, e, N), L(e, n), L(n, t), L(t, a), w && w.m(a, null), L(a, s), ne[l].m(a, null), L(t, o), L(t, f), ae[r].m(f, null), L(t, m), L(t, d), ie[b].m(d, null), L(t, A), O && O.m(t, null), L(t, ee), H && H.m(t, null), L(t, se), M && M.m(t, null), L(t, le), W && W.m(t, null), L(t, ce), y && y.m(t, null), L(t, de), V && V.m(t, null), J = !0
        },
        p(v, [N]) {
            var ye, Se;
            v[13] ? w ? (w.p(v, N), N & 8192 && g(w, 1)) : (w = Ke(v), w.c(), g(w, 1), w.m(a, s)) : w && (K(), h(w, 1, 1, () => {
                w = null
            }), z());
            let me = l;
            l = ke(v), l === me ? ne[l].p(v, N) : (K(), h(ne[me], 1, 1, () => {
                ne[me] = null
            }), z(), u = ne[l], u ? u.p(v, N) : (u = ne[l] = te[l](v), u.c()), g(u, 1), u.m(a, null)), (!J || N & 4) && F(a, "remove-background", v[2]);
            let Y = r;
            r = q(v), r === Y ? ae[r].p(v, N) : (K(), h(ae[Y], 1, 1, () => {
                ae[Y] = null
            }), z(), c = ae[r], c ? c.p(v, N) : (c = ae[r] = ve[r](v), c.c()), g(c, 1), c.m(f, null));
            let ue = b;
            b = $e(v), b === ue ? ie[b].p(v, N) : (K(), h(ie[ue], 1, 1, () => {
                ie[ue] = null
            }), z(), S = ie[b], S ? S.p(v, N) : (S = ie[b] = be[b](v), S.c()), g(S, 1), S.m(d, null)), v[9] ? O ? (O.p(v, N), N & 512 && g(O, 1)) : (O = Xe(v), O.c(), g(O, 1), O.m(t, ee)) : O && (K(), h(O, 1, 1, () => {
                O = null
            }), z()), v[7] ? H ? (H.p(v, N), N & 128 && g(H, 1)) : (H = Qe(v), H.c(), g(H, 1), H.m(t, se)) : H && (K(), h(H, 1, 1, () => {
                H = null
            }), z()), v[8] ? M ? (M.p(v, N), N & 256 && g(M, 1)) : (M = Je(v), M.c(), g(M, 1), M.m(t, le)) : M && (K(), h(M, 1, 1, () => {
                M = null
            }), z()), v[6] ? W ? (W.p(v, N), N & 64 && g(W, 1)) : (W = xe(v), W.c(), g(W, 1), W.m(t, ce)) : W && (K(), h(W, 1, 1, () => {
                W = null
            }), z()), N & 18 && (oe = v[4] && pe(v[1], "scoring").scoreboard !== "none"), oe ? y ? (y.p(v, N), N & 18 && g(y, 1)) : (y = tt(v), y.c(), g(y, 1), y.m(t, de)) : y && (K(), h(y, 1, 1, () => {
                y = null
            }), z()), (ye = v[5]) != null && ye.homeGameScore && ((Se = v[5]) != null && Se.awayGameScore) ? V ? (V.p(v, N), N & 32 && g(V, 1)) : (V = at(v), V.c(), g(V, 1), V.m(t, null)) : V && (K(), h(V, 1, 1, () => {
                V = null
            }), z()), (!J || N & 2048) && P(t, "grid-template-areas", v[11]), (!J || N & 4) && F(t, "remove-background", v[2]), (!J || N & 8) && F(t, "remove-box-shadow", v[3]), (!J || N & 4) && F(n, "has-background", !v[2]), (!J || N & 8) && F(n, "box-shadow", !v[3]), (!J || N & 4096) && P(e, "--sport-image", "url(" + v[12] + ")"), (!J || N & 4) && F(e, "background", !v[2])
        },
        i(v) {
            J || (g(w), g(u), g(c), g(S), g(O), g(H), g(M), g(W), g(y), g(V), J = !0)
        },
        o(v) {
            h(w), h(u), h(c), h(S), h(O), h(H), h(M), h(W), h(y), h(V), J = !1
        },
        d(v) {
            v && p(e), w && w.d(), ne[l].d(), ae[r].d(), ie[b].d(), O && O.d(), H && H.d(), M && M.d(), W && W.d(), y && y.d(), V && V.d()
        }
    }
}

function dn(i, e, n) {
    let t, a, s, l, u, o, f, r, c, m, d, b, S, A, ee, se, le, ce, oe, de, J, {
            fixture: w
        } = e,
        {
            sport: te
        } = e,
        {
            removeBackground: ne = !1
        } = e,
        {
            removeBoxShadow: ke = !1
        } = e,
        ve = !0,
        ae = dt(!0);
    return rt(i, ae, q => n(20, J = q)), i.$$set = q => {
        "fixture" in q && n(0, w = q.fixture), "sport" in q && n(1, te = q.sport), "removeBackground" in q && n(2, ne = q.removeBackground), "removeBoxShadow" in q && n(3, ke = q.removeBoxShadow)
    }, i.$$.update = () => {
        var q, be, ie, $e, O, H, M, W;
        i.$$.dirty & 1 && n(24, t = w && Pa(w)), i.$$.dirty & 1 && n(4, a = w && w.eventStatus ? { ...w.eventStatus,
            matchStatus: w.status === "live" || w.status === "suspended" ? (q = w == null ? void 0 : w.eventStatus) == null ? void 0 : q.matchStatus : Ea(w.data).startTime
        } : null), i.$$.dirty & 16 && n(19, s = a && "homeScore" in a && typeof a.homeScore == "number" ? a.homeScore : "-"), i.$$.dirty & 16 && n(18, l = a && "awayScore" in a && typeof a.awayScore == "number" ? a.awayScore : "-"), i.$$.dirty & 18 && n(6, u = pe(te, "scoring").scoreboard === "periods" && ((be = a == null ? void 0 : a.periodScores) == null ? void 0 : be.map(y => {
            var V, fe, we, v;
            return (a == null ? void 0 : a.__typename) === "EsportFixtureEventStatus" && (a == null ? void 0 : a.matchStatus) === y.matchStatus ? { ...y,
                homeScore: ((V = a == null ? void 0 : a.scoreboard) == null ? void 0 : V.homeKills) ? ? ((fe = a == null ? void 0 : a.scoreboard) == null ? void 0 : fe.homeWonRounds) ? ? 0,
                awayScore: ((we = a == null ? void 0 : a.scoreboard) == null ? void 0 : we.awayKills) ? ? ((v = a == null ? void 0 : a.scoreboard) == null ? void 0 : v.awayWonRounds) ? ? 0
            } : { ...y,
                homeScore: y.homeScore ? ? 0,
                awayScore: y.awayScore ? ? 0
            }
        }))), i.$$.dirty & 18 && n(26, o = (te === "tennis" && a && "homeGameScore" in a && typeof a.homeGameScore == "string" && (a == null ? void 0 : a.homeGameScore)) ? ? !1), i.$$.dirty & 18 && n(25, f = (te === "tennis" && a && "awayGameScore" in a && typeof a.awayGameScore == "string" && (a == null ? void 0 : a.awayGameScore)) ? ? !1), i.$$.dirty & 100663297 && n(5, r = w && w.status !== "ended" ? {
            homeGameScore: o,
            awayGameScore: f
        } : {}), i.$$.dirty & 18 && n(7, c = (a == null ? void 0 : a.__typename) === "SportFixtureEventStatusData" && pe(te, "scoreboard").displayCards && ((ie = a == null ? void 0 : a.statistic) == null ? void 0 : ie.redCards)), i.$$.dirty & 18 && n(8, m = (a == null ? void 0 : a.__typename) === "SportFixtureEventStatusData" && pe(te, "scoreboard").displayCards && (($e = a == null ? void 0 : a.statistic) == null ? void 0 : $e.yellowCards)), i.$$.dirty & 18 && n(9, d = (a == null ? void 0 : a.__typename) === "SportFixtureEventStatusData" && pe(te, "scoreboard").displayCorners && ((O = a == null ? void 0 : a.statistic) == null ? void 0 : O.corners)), i.$$.dirty & 16 && n(17, b = a && "currentTeamServing" in a && typeof a.currentTeamServing == "string" ? a == null ? void 0 : a.currentTeamServing : null), i.$$.dirty & 1 && n(16, S = w == null ? void 0 : w.status), i.$$.dirty & 16777216 && n(22, A = t && (t.competitors ? ? [])), i.$$.dirty & 4194304 && n(15, ee = A && A.find(y => y.homeTeam)), i.$$.dirty & 4194304 && n(14, se = A && A.find(y => !y.homeTeam)), i.$$.dirty & 17 && n(13, le = (w == null ? void 0 : w.provider) === _e.betradar ? (a == null ? void 0 : a.__typename) === "SportFixtureEventStatusData" ? a.clock : null : ((H = w == null ? void 0 : w.eventStatus) == null ? void 0 : H.__typename) === "EsportFixtureEventStatus" ? {
            matchTime: (M = w.eventStatus.scoreboard) == null ? void 0 : M.gameTime,
            remainingTime: (W = w.eventStatus.scoreboard) == null ? void 0 : W.remainingGameTime
        } : null), i.$$.dirty & 2 && n(12, ce = Da(te)), i.$$.dirty & 1010 && n(23, oe = y => [`competitor_${y} competitor_${y}`, d && `corners_${y}`, m && `yellowCards_${y}`, c && `redCards_${y}`, ...u ? u.map((V, fe) => `period_${y}_${fe}`) : [], (r == null ? void 0 : r.homeGameScore) && (r == null ? void 0 : r.awayGameScore) && `gameScore_${y}`, pe(te, "scoring").scoreboard !== "none" && a && `matchScore_${y}`].filter(Boolean).join(" ")), i.$$.dirty & 8388608 && n(11, de = `
    "${oe("title")}"
    "${oe("home")}"
    "${oe("away")}"
    `), i.$$.dirty & 4194304 && A && Ca(A, () => n(10, ve = !1), ae)
    }, [w, te, ne, ke, a, r, u, c, m, d, ve, de, ce, le, se, ee, S, b, l, s, J, ae, A, oe, t, f, o]
}
class Tn extends Ne {
    constructor(e) {
        super(), Fe(this, e, dn, cn, Te, {
            fixture: 0,
            sport: 1,
            removeBackground: 2,
            removeBoxShadow: 3
        })
    }
}
const Dn = {
    pending: _._("Pending"),
    points: _._("Points"),
    rebounds: _._("Rebounds"),
    assists: _._("Assists"),
    threesmade: _._("Three's Made"),
    steals: _._("Steals"),
    blocks: _._("Blocks"),
    turnovers: _._("Turnovers"),
    "points+rebounds": _._("Points + Rebounds"),
    "points+assists": _._("Points + Assists"),
    "points+assists+rebounds": _._("Points + Assists + Rebounds"),
    "assists+rebounds": _._("Assists + Rebounds"),
    "steals+blocks": _._("Steals + Blocks"),
    doubledouble: _._("Double-Double"),
    tripledouble: _._("Triple-Double"),
    firstscorer: _._("First Scorer"),
    firstscorerfreethrowmade: _._("First Scorer Free Throw Made"),
    firstquarterrebounds: _._("First Quarter Rebounds"),
    "first quarter rebounds": _._("First Quarter Rebounds"),
    "first quarter points": _._("First Quarter Points"),
    "first quarter assists": _._("First Quarter Assists"),
    anytimetouchdown: _._("Anytime Touchdown"),
    strikeouts: _._("Strikeouts"),
    "earned runs": _._("Earned Runs"),
    "hits allowed": _._("Hits Allowed"),
    outs: _._("Outs"),
    walks: _._("Walks"),
    "win probability": _._("Win Probability"),
    winner: _._("Winner"),
    hits: _._("Hits"),
    "home runs": _._("Home Runs"),
    RBIs: _._("RBIs"),
    "total bases": _._("Total Bases"),
    runs: _._("Runs"),
    singles: _._("Singles"),
    doubles: _._("Doubles"),
    triples: _._("Triples"),
    "passing yards": _._("Passing Yards"),
    "passing completions": _._("Passing Completions"),
    "passing touchdowns": _._("Passing Touchdowns"),
    "passing attempts": _._("Passing Attempts"),
    "longest passing completion": _._("Longest Passing Completion"),
    "first touchdown": _._("First Touchdown"),
    interceptions: _._("Interceptions"),
    "anytime touchdown": _._("Anytime Touchdown"),
    "rushing yards": _._("Rushing Yards"),
    "rushing touchdowns": _._("Rushing Touchdowns"),
    "rushing attempts": _._("Rushing Attempts"),
    "passing+rushing yards": _._("Passing + Rushing Yards"),
    "passing + rushing yards": _._("Passing + Rushing Yards"),
    "passingyards+rushingyards": _._("Passing Yards + Rushing Yards"),
    "longest rush": _._("Longest Rush"),
    "receiving yards": _._("Receiving Yards"),
    "receiving touchdowns": _._("Receiving Touchdowns"),
    receptions: _._("Receptions"),
    "longest reception": _._("Longest Reception"),
    "rushing + receiving yards": _._("Rushing + Receiving Yards"),
    "rushingyards+receivingyards": _._("Rushing Yards + Receiving Yards"),
    "field goal made": _._("Field Goal Made"),
    "extra points made": _._("Extra Points Made"),
    "kicking points": _._("Kicking Points"),
    tackles: _._("Tackles"),
    sacks: _._("Sacks"),
    "defensive interceptions": _._("Defensive Interceptions"),
    "tackles + assists": _._("Tackles + Assists"),
    moneyline: _._("Winner (Incl. Overtime)"),
    spread: _._("Handicap (Incl. Overtime)"),
    totals: _._("Total (Incl. Overtime)")
};
export {
    jn as F, Tn as M, De as g, Dn as m
};