import {
    s as b,
    a as I,
    u as y,
    g as S,
    b as C,
    c as T,
    o as O
} from "./scheduler.DXu26z7T.js";
import {
    S as F,
    i as R,
    t as g,
    b as p,
    c as q,
    a as H,
    m as L,
    d as P
} from "./index.Dz_MmNB3.js";
import {
    i as V,
    a9 as X,
    ar as j
} from "./index.B4-7gKq3.js";
import {
    a as D
} from "./index.B81orGJm.js";
import {
    r as k
} from "./constants.DX75DoF3.js";
import {
    B as z
} from "./index.DlOe5U6J.js";
const G = r => ({
        countdown: r & 2,
        countdownState: r & 1
    }),
    M = r => ({
        countdown: r[1],
        countdownState: r[0]
    });

function J(r) {
    let n;
    const o = r[11].default,
        t = I(o, r, r[10], M);
    return {
        c() {
            t && t.c()
        },
        l(e) {
            t && t.l(e)
        },
        m(e, a) {
            t && t.m(e, a), n = !0
        },
        p(e, [a]) {
            t && t.p && (!n || a & 1027) && y(t, o, e, e[10], n ? C(o, e[10], a, G) : S(e[10]), M)
        },
        i(e) {
            n || (g(t, e), n = !0)
        },
        o(e) {
            p(t, e), n = !1
        },
        d(e) {
            t && t.d(e)
        }
    }
}

function K(r, n, o) {
    let t, e, a, l, h, f, c;
    T(r, V, s => o(9, f = s)), T(r, X, s => o(12, c = s));
    let {
        $$slots: N = {},
        $$scope: w
    } = n, {
        startTime: _
    } = n, {
        chromaticDate: i = null
    } = n;
    const A = 30 * 60 * 1e3,
        E = new Intl.DateTimeFormat(c, {
            hourCycle: "h23",
            hour: "2-digit",
            minute: "2-digit"
        }),
        d = new Intl.NumberFormat(c, {
            style: "unit",
            unit: "minute",
            unitDisplay: "narrow"
        }),
        B = new Intl.NumberFormat(c, {
            style: "unit",
            unit: "second",
            unitDisplay: "narrow"
        });
    let u, m = D && i ? new Date(i).getTime() : Date.now();
    return O(() => {
        if (D) return;
        let s = setInterval(() => {
            o(4, m = Date.now())
        }, j);
        return () => {
            clearInterval(s)
        }
    }), r.$$set = s => {
        "startTime" in s && o(2, _ = s.startTime), "chromaticDate" in s && o(3, i = s.chromaticDate), "$$scope" in s && o(10, w = s.$$scope)
    }, r.$$.update = () => {
        r.$$.dirty & 4 && o(8, t = new Date(_)), r.$$.dirty & 256 && o(7, e = E.format(t)), r.$$.dirty & 272 && o(5, a = Math.floor((t.getTime() - m) / 1e3)), r.$$.dirty & 272 && o(6, l = t.getTime() < m - A), r.$$.dirty & 736 && o(1, h = a >= 60 * 30 ? (o(0, u = "upcoming"), e) : a >= 60 * 10 ? (o(0, u = "near"), d.format(Math.trunc(a / 60))) : a <= -60 * 5 ? l ? (o(0, u = "ended"), f._(k.ended)) : (o(0, u = "live"), d.format(Math.trunc(a / 60))) : (o(0, u = "live"), d.format(Math.trunc(a / 60)) + B.format(Math.abs(Math.trunc(a % 60)))))
    }, [u, h, _, i, m, a, l, e, t, f, w, N]
}
class et extends F {
    constructor(n) {
        super(), R(this, n, K, J, b, {
            startTime: 2,
            chromaticDate: 3
        })
    }
}

function Q(r) {
    let n;
    const o = r[0].default,
        t = I(o, r, r[1], null);
    return {
        c() {
            t && t.c()
        },
        l(e) {
            t && t.l(e)
        },
        m(e, a) {
            t && t.m(e, a), n = !0
        },
        p(e, a) {
            t && t.p && (!n || a & 2) && y(t, o, e, e[1], n ? C(o, e[1], a, null) : S(e[1]), null)
        },
        i(e) {
            n || (g(t, e), n = !0)
        },
        o(e) {
            p(t, e), n = !1
        },
        d(e) {
            t && t.d(e)
        }
    }
}

function U(r) {
    let n, o;
    return n = new z({
        props: {
            variant: "live",
            style: "padding: 0 4px;",
            $$slots: {
                default: [Q]
            },
            $$scope: {
                ctx: r
            }
        }
    }), {
        c() {
            q(n.$$.fragment)
        },
        l(t) {
            H(n.$$.fragment, t)
        },
        m(t, e) {
            L(n, t, e), o = !0
        },
        p(t, [e]) {
            const a = {};
            e & 2 && (a.$$scope = {
                dirty: e,
                ctx: t
            }), n.$set(a)
        },
        i(t) {
            o || (g(n.$$.fragment, t), o = !0)
        },
        o(t) {
            p(n.$$.fragment, t), o = !1
        },
        d(t) {
            P(n, t)
        }
    }
}

function W(r, n, o) {
    let {
        $$slots: t = {},
        $$scope: e
    } = n;
    return r.$$set = a => {
        "$$scope" in a && o(1, e = a.$$scope)
    }, [t, e]
}
class nt extends F {
    constructor(n) {
        super(), R(this, n, W, U, b, {})
    }
}
export {
    et as R, nt as a
};